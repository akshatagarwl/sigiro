import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface ActivateDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID to activate. */
    targetId: string;
}
export declare const ActivateDevtoolBrowserTargetRequest: S.Schema<ActivateDevtoolBrowserTargetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ActivateDevtoolBrowserTargetResponse {
    /** Target activated. */
    message: string;
}
export declare const ActivateDevtoolBrowserTargetResponse: S.Schema<ActivateDevtoolBrowserTargetResponse>;
export interface CloseDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID to close. */
    targetId: string;
}
export declare const CloseDevtoolBrowserTargetRequest: S.Schema<CloseDevtoolBrowserTargetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CloseDevtoolBrowserTargetResponse {
    /** Target is closing. */
    message: string;
}
export declare const CloseDevtoolBrowserTargetResponse: S.Schema<CloseDevtoolBrowserTargetResponse>;
export interface ConnectDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID to connect to. */
    sessionId: string;
    /** Keep-alive time in ms (only valid when acquiring new session). */
    keepAlive?: number;
    /** Use experimental browser. */
    lab?: boolean;
    recording?: boolean;
}
export declare const ConnectDevtoolBrowserRequest: S.Schema<ConnectDevtoolBrowserRequest>;
export interface ConnectDevtoolBrowserResponse {
}
export declare const ConnectDevtoolBrowserResponse: S.Schema<ConnectDevtoolBrowserResponse>;
export interface ContentCreateRequestAddScriptTagItem {
    id?: string;
    content?: string;
    type?: string;
    url?: string;
}
export declare const ContentCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type ContentCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const ContentCreateRequestAddScriptTagList: S.Schema<ContentCreateRequestAddScriptTagList>;
export interface ContentCreateRequestAddStyleTagItem {
    content?: string;
    url?: string;
}
export declare const ContentCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type ContentCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const ContentCreateRequestAddStyleTagList: S.Schema<ContentCreateRequestAddStyleTagList>;
export type ContentCreateRequestAllowRequestPatternList = Array<string>;
export declare const ContentCreateRequestAllowRequestPatternList: S.Schema<ContentCreateRequestAllowRequestPatternList>;
export type ContentCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const ContentCreateRequestAllowResourceTypesItem: any;
export type ContentCreateRequestAllowResourceTypesList = Array<ContentCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const ContentCreateRequestAllowResourceTypesList: S.Schema<ContentCreateRequestAllowResourceTypesList>;
export interface ContentCreateRequestAuthenticate {
    password: string;
    username: string;
}
export declare const ContentCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type ContentCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const ContentCreateRequestCookiesItemPriority: any;
export type ContentCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const ContentCreateRequestCookiesItemSameSite: any;
export type ContentCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const ContentCreateRequestCookiesItemSourceScheme: any;
export interface ContentCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: ContentCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: ContentCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: ContentCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const ContentCreateRequestCookiesItem: S.Schema<ContentCreateRequestCookiesItem>;
export type ContentCreateRequestCookiesList = Array<ContentCreateRequestCookiesItem>;
export declare const ContentCreateRequestCookiesList: S.Schema<ContentCreateRequestCookiesList>;
export type ContentCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const ContentCreateRequestGotoOptionsWaitUntilCase0: any;
export type ContentCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const ContentCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type ContentCreateRequestGotoOptionsWaitUntilCase1List = Array<ContentCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const ContentCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<ContentCreateRequestGotoOptionsWaitUntilCase1List>;
export type ContentCreateRequestGotoOptionsWaitUntil = ContentCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | ContentCreateRequestGotoOptionsWaitUntilCase1List;
export declare const ContentCreateRequestGotoOptionsWaitUntil: any;
export interface ContentCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: ContentCreateRequestGotoOptionsWaitUntil;
}
export declare const ContentCreateRequestGotoOptions: S.Schema<ContentCreateRequestGotoOptions>;
export type ContentCreateRequestRejectRequestPatternList = Array<string>;
export declare const ContentCreateRequestRejectRequestPatternList: S.Schema<ContentCreateRequestRejectRequestPatternList>;
export type ContentCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const ContentCreateRequestRejectResourceTypesItem: any;
export type ContentCreateRequestRejectResourceTypesList = Array<ContentCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const ContentCreateRequestRejectResourceTypesList: S.Schema<ContentCreateRequestRejectResourceTypesList>;
export type ContentCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ContentCreateRequestSetExtraHTTPHeadersMap: S.Schema<ContentCreateRequestSetExtraHTTPHeadersMap>;
export interface ContentCreateRequestViewport {
    height: number;
    width: number;
    deviceScaleFactor?: number;
    hasTouch?: boolean;
    isLandscape?: boolean;
    isMobile?: boolean;
}
export declare const ContentCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export interface ContentCreateRequestWaitForSelector {
    selector: string;
    hidden?: boolean;
    timeout?: number;
    visible?: boolean;
}
export declare const ContentCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateContentRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: ContentCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: ContentCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: ContentCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: ContentCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: ContentCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: ContentCreateRequestGotoOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: ContentCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: ContentCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: ContentCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
}
export declare const CreateContentRequest: S.Schema<CreateContentRequest>;
export type CreateContentResponse = string;
export declare const CreateContentResponse: S.Schema<CreateContentResponse>;
export type CrawlCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const CrawlCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type CrawlCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const CrawlCreateRequestAddScriptTagList: S.Schema<CrawlCreateRequestAddScriptTagList>;
export type CrawlCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const CrawlCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type CrawlCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const CrawlCreateRequestAddStyleTagList: S.Schema<CrawlCreateRequestAddStyleTagList>;
export type CrawlCreateRequestAllowRequestPatternList = Array<string>;
export declare const CrawlCreateRequestAllowRequestPatternList: S.Schema<CrawlCreateRequestAllowRequestPatternList>;
export type CrawlCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const CrawlCreateRequestAllowResourceTypesItem: any;
export type CrawlCreateRequestAllowResourceTypesList = Array<CrawlCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const CrawlCreateRequestAllowResourceTypesList: S.Schema<CrawlCreateRequestAllowResourceTypesList>;
export type CrawlCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const CrawlCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type CrawlCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const CrawlCreateRequestCookiesItemPriority: any;
export type CrawlCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const CrawlCreateRequestCookiesItemSameSite: any;
export type CrawlCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const CrawlCreateRequestCookiesItemSourceScheme: any;
export interface CrawlCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: CrawlCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: CrawlCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: CrawlCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const CrawlCreateRequestCookiesItem: S.Schema<CrawlCreateRequestCookiesItem>;
export type CrawlCreateRequestCookiesList = Array<CrawlCreateRequestCookiesItem>;
export declare const CrawlCreateRequestCookiesList: S.Schema<CrawlCreateRequestCookiesList>;
export type CrawlCreateRequestCrawlPurposesItem = "search" | "ai-input" | "ai-train";
export declare const CrawlCreateRequestCrawlPurposesItem: any;
export type CrawlCreateRequestCrawlPurposesList = Array<CrawlCreateRequestCrawlPurposesItem | (string & {})>;
export declare const CrawlCreateRequestCrawlPurposesList: S.Schema<CrawlCreateRequestCrawlPurposesList>;
export type CrawlCreateRequestFormatsItem = "html" | "markdown" | "json";
export declare const CrawlCreateRequestFormatsItem: any;
export type CrawlCreateRequestFormatsList = Array<CrawlCreateRequestFormatsItem | (string & {})>;
export declare const CrawlCreateRequestFormatsList: S.Schema<CrawlCreateRequestFormatsList>;
export type CrawlCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const CrawlCreateRequestGotoOptionsWaitUntilCase0: any;
export type CrawlCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const CrawlCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type CrawlCreateRequestGotoOptionsWaitUntilCase1List = Array<CrawlCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const CrawlCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<CrawlCreateRequestGotoOptionsWaitUntilCase1List>;
export type CrawlCreateRequestGotoOptionsWaitUntil = CrawlCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | CrawlCreateRequestGotoOptionsWaitUntilCase1List;
export declare const CrawlCreateRequestGotoOptionsWaitUntil: any;
export interface CrawlCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: CrawlCreateRequestGotoOptionsWaitUntil;
}
export declare const CrawlCreateRequestGotoOptions: S.Schema<CrawlCreateRequestGotoOptions>;
export interface CrawlCreateRequestJsonOptionsCustomAiItem {
    /** AI model to use for the request. Must be formed as `<provider>/<model_name>`, e.g. `workers-ai/@cf/meta/llama-3.3-70b-instruct-fp8-fast`. */
    model: string;
    /** Authorization token for the AI model: `Bearer <token>`. Not needed for workers-ai models. */
    authorization?: string;
}
export declare const CrawlCreateRequestJsonOptionsCustomAiItem: S.Schema<CrawlCreateRequestJsonOptionsCustomAiItem>;
export type CrawlCreateRequestJsonOptionsCustomAiList = Array<CrawlCreateRequestJsonOptionsCustomAiItem>;
export declare const CrawlCreateRequestJsonOptionsCustomAiList: S.Schema<CrawlCreateRequestJsonOptionsCustomAiList>;
export interface CrawlCreateRequestJsonOptionsResponseFormat {
    type: string;
    /** Schema for the response format. More information here: https://developers.cloudflare.com/workers-ai/json-mode/ */
    jsonSchema?: unknown;
}
export declare const CrawlCreateRequestJsonOptionsResponseFormat: S.Schema<CrawlCreateRequestJsonOptionsResponseFormat>;
export interface CrawlCreateRequestJsonOptions {
    /** Optional list of custom AI models to use for the request. The models will be tried in the order provided, and in case a model returns an error, the next one will be used as fallback. */
    customAi?: CrawlCreateRequestJsonOptionsCustomAiList;
    prompt?: string;
    responseFormat?: CrawlCreateRequestJsonOptionsResponseFormat;
}
export declare const CrawlCreateRequestJsonOptions: S.Schema<CrawlCreateRequestJsonOptions>;
export type CrawlCreateRequestOptionsExcludePatternsList = Array<string>;
export declare const CrawlCreateRequestOptionsExcludePatternsList: S.Schema<CrawlCreateRequestOptionsExcludePatternsList>;
export type CrawlCreateRequestOptionsIncludePatternsList = Array<string>;
export declare const CrawlCreateRequestOptionsIncludePatternsList: S.Schema<CrawlCreateRequestOptionsIncludePatternsList>;
export interface CrawlCreateRequestOptions {
    /** Exclude links matching the provided wildcard patterns in the crawl job. Example: 'https://example.com/privacy/**'. */
    excludePatterns?: CrawlCreateRequestOptionsExcludePatternsList;
    /** Include external links in the crawl job. If set to true, includeSubdomains is ignored. */
    includeExternalLinks?: boolean;
    /** Include only links matching the provided wildcard patterns in the crawl job. Include patterns are evaluated before exclude patterns. URLs that match any of the specified include patterns will be included in the crawl job. Example: 'https://example.com/blog/**'. */
    includePatterns?: CrawlCreateRequestOptionsIncludePatternsList;
    /** Include links to subdomains in the crawl job. This option is ignored if includeExternalLinks is true. */
    includeSubdomains?: boolean;
}
export declare const CrawlCreateRequestOptions: S.Schema<CrawlCreateRequestOptions>;
export type CrawlCreateRequestRejectRequestPatternList = Array<string>;
export declare const CrawlCreateRequestRejectRequestPatternList: S.Schema<CrawlCreateRequestRejectRequestPatternList>;
export type CrawlCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const CrawlCreateRequestRejectResourceTypesItem: any;
export type CrawlCreateRequestRejectResourceTypesList = Array<CrawlCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const CrawlCreateRequestRejectResourceTypesList: S.Schema<CrawlCreateRequestRejectResourceTypesList>;
export type CrawlCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const CrawlCreateRequestSetExtraHTTPHeadersMap: S.Schema<CrawlCreateRequestSetExtraHTTPHeadersMap>;
export type CrawlCreateRequestSource = "sitemaps" | "links" | "all";
export declare const CrawlCreateRequestSource: any;
export type CrawlCreateRequestViewport = ContentCreateRequestViewport;
export declare const CrawlCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type CrawlCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const CrawlCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateCrawlRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: CrawlCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: CrawlCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: CrawlCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: CrawlCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: CrawlCreateRequestCookiesList;
    /** List of crawl purposes to respect Content-Signal directives in robots.txt. Allowed values: 'search', 'ai-input', 'ai-train'. Learn more: https://contentsignals.org/. Default: ['search', 'ai-input', 'ai-train']. */
    crawlPurposes?: CrawlCreateRequestCrawlPurposesList;
    /** Maximum number of levels deep the crawler will traverse from the starting URL. */
    depth?: number;
    emulateMediaType?: string;
    /** Formats to return. Default is `html`. */
    formats?: CrawlCreateRequestFormatsList;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: CrawlCreateRequestGotoOptions;
    /** Options for JSON extraction. */
    jsonOptions?: CrawlCreateRequestJsonOptions;
    /** Maximum number of URLs to crawl. */
    limit?: number;
    /** Maximum age of a resource that can be returned from cache in seconds. Default is 1 day. */
    maxAge?: number;
    /** Unix timestamp (seconds since epoch) indicating to only crawl pages that were modified since this time. For sitemap URLs with a lastmod field, this is compared directly. For other URLs, the crawler will use If-Modified-Since header when fetching. URLs without modification information (no lastmod in sitemap and no Last-Modified header support) will be crawled. Note: This works in conjunction with maxAge - both filters must pass for a cached resource to be used. Must be within the last year and not in the future. */
    modifiedSince?: number;
    /** Additional options for the crawler. */
    options?: CrawlCreateRequestOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: CrawlCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: CrawlCreateRequestRejectResourceTypesList;
    /** Whether to render the page or fetch static content. True by default. */
    render?: boolean;
    setExtraHTTPHeaders?: CrawlCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    /** Source of links to crawl. 'sitemaps' - only crawl URLs from sitemaps, 'links' - only crawl URLs scraped from pages, 'all' - crawl both sitemap and scraped links (default). */
    source?: CrawlCreateRequestSource | (string & {});
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
}
export declare const CreateCrawlRequest: S.Schema<CreateCrawlRequest>;
export type CreateCrawlResponse = string;
export declare const CreateCrawlResponse: S.Schema<CreateCrawlResponse>;
export interface CreateDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Keep-alive time in milliseconds. */
    keepAlive?: number;
    /** Use experimental browser. */
    lab?: boolean;
    /** How long the live view URL remains valid, in milliseconds (max 60 minutes). Only used when targets is true. */
    liveViewUrlExpiresInMs?: number;
    recording?: boolean;
    /** Include browser targets in response. */
    targets?: boolean;
}
export declare const CreateDevtoolBrowserRequest: S.Schema<CreateDevtoolBrowserRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateDevtoolBrowserResponse {
    /** Browser session ID. */
    sessionId: string;
    /** WebSocket URL for the session. */
    webSocketDebuggerUrl?: string | null;
}
export declare const CreateDevtoolBrowserResponse: S.Schema<CreateDevtoolBrowserResponse>;
export interface CreateDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** How long the live view URL remains valid, in milliseconds (max 60 minutes) */
    liveViewUrlExpiresInMs?: number;
    url?: string;
}
export declare const CreateDevtoolBrowserTargetRequest: S.Schema<CreateDevtoolBrowserTargetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateDevtoolBrowserTargetResponse {
    /** Target ID. */
    id: string;
    /** Target type (page, background_page, worker, etc.). */
    type: string;
    /** URL of the target. */
    url: string;
    /** Target description. */
    description?: string | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Title of the target. */
    title?: string | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export declare const CreateDevtoolBrowserTargetResponse: S.Schema<CreateDevtoolBrowserTargetResponse>;
export type JsonCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const JsonCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type JsonCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const JsonCreateRequestAddScriptTagList: S.Schema<JsonCreateRequestAddScriptTagList>;
export type JsonCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const JsonCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type JsonCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const JsonCreateRequestAddStyleTagList: S.Schema<JsonCreateRequestAddStyleTagList>;
export type JsonCreateRequestAllowRequestPatternList = Array<string>;
export declare const JsonCreateRequestAllowRequestPatternList: S.Schema<JsonCreateRequestAllowRequestPatternList>;
export type JsonCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const JsonCreateRequestAllowResourceTypesItem: any;
export type JsonCreateRequestAllowResourceTypesList = Array<JsonCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const JsonCreateRequestAllowResourceTypesList: S.Schema<JsonCreateRequestAllowResourceTypesList>;
export type JsonCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const JsonCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type JsonCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const JsonCreateRequestCookiesItemPriority: any;
export type JsonCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const JsonCreateRequestCookiesItemSameSite: any;
export type JsonCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const JsonCreateRequestCookiesItemSourceScheme: any;
export interface JsonCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: JsonCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: JsonCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: JsonCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const JsonCreateRequestCookiesItem: S.Schema<JsonCreateRequestCookiesItem>;
export type JsonCreateRequestCookiesList = Array<JsonCreateRequestCookiesItem>;
export declare const JsonCreateRequestCookiesList: S.Schema<JsonCreateRequestCookiesList>;
export type JsonCreateRequestCustomAiItem = CrawlCreateRequestJsonOptionsCustomAiItem;
export declare const JsonCreateRequestCustomAiItem: S.Schema<CrawlCreateRequestJsonOptionsCustomAiItem>;
export type JsonCreateRequestCustomAiList = Array<CrawlCreateRequestJsonOptionsCustomAiItem>;
export declare const JsonCreateRequestCustomAiList: S.Schema<JsonCreateRequestCustomAiList>;
export type JsonCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const JsonCreateRequestGotoOptionsWaitUntilCase0: any;
export type JsonCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const JsonCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type JsonCreateRequestGotoOptionsWaitUntilCase1List = Array<JsonCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const JsonCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<JsonCreateRequestGotoOptionsWaitUntilCase1List>;
export type JsonCreateRequestGotoOptionsWaitUntil = JsonCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | JsonCreateRequestGotoOptionsWaitUntilCase1List;
export declare const JsonCreateRequestGotoOptionsWaitUntil: any;
export interface JsonCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: JsonCreateRequestGotoOptionsWaitUntil;
}
export declare const JsonCreateRequestGotoOptions: S.Schema<JsonCreateRequestGotoOptions>;
export type JsonCreateRequestRejectRequestPatternList = Array<string>;
export declare const JsonCreateRequestRejectRequestPatternList: S.Schema<JsonCreateRequestRejectRequestPatternList>;
export type JsonCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const JsonCreateRequestRejectResourceTypesItem: any;
export type JsonCreateRequestRejectResourceTypesList = Array<JsonCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const JsonCreateRequestRejectResourceTypesList: S.Schema<JsonCreateRequestRejectResourceTypesList>;
export type JsonCreateRequestResponseFormat = CrawlCreateRequestJsonOptionsResponseFormat;
export declare const JsonCreateRequestResponseFormat: S.Schema<CrawlCreateRequestJsonOptionsResponseFormat>;
export type JsonCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const JsonCreateRequestSetExtraHTTPHeadersMap: S.Schema<JsonCreateRequestSetExtraHTTPHeadersMap>;
export type JsonCreateRequestViewport = ContentCreateRequestViewport;
export declare const JsonCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type JsonCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const JsonCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateJsonRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: JsonCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: JsonCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: JsonCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: JsonCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: JsonCreateRequestCookiesList;
    /** Optional list of custom AI models to use for the request. The models will be tried in the order provided, and in case a model returns an error, the next one will be used as fallback. */
    customAi?: JsonCreateRequestCustomAiList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: JsonCreateRequestGotoOptions;
    prompt?: string;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: JsonCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: JsonCreateRequestRejectResourceTypesList;
    responseFormat?: CrawlCreateRequestJsonOptionsResponseFormat;
    setExtraHTTPHeaders?: JsonCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
}
export declare const CreateJsonRequest: S.Schema<CreateJsonRequest>;
export type JsonCreateResultMap = {
    [key: string]: unknown | undefined;
};
export declare const JsonCreateResultMap: S.Schema<JsonCreateResultMap>;
export type CreateJsonResponse = JsonCreateResultMap;
export declare const CreateJsonResponse: S.Schema<CreateJsonResponse>;
export type LinksCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const LinksCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type LinksCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const LinksCreateRequestAddScriptTagList: S.Schema<LinksCreateRequestAddScriptTagList>;
export type LinksCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const LinksCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type LinksCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const LinksCreateRequestAddStyleTagList: S.Schema<LinksCreateRequestAddStyleTagList>;
export type LinksCreateRequestAllowRequestPatternList = Array<string>;
export declare const LinksCreateRequestAllowRequestPatternList: S.Schema<LinksCreateRequestAllowRequestPatternList>;
export type LinksCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const LinksCreateRequestAllowResourceTypesItem: any;
export type LinksCreateRequestAllowResourceTypesList = Array<LinksCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const LinksCreateRequestAllowResourceTypesList: S.Schema<LinksCreateRequestAllowResourceTypesList>;
export type LinksCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const LinksCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type LinksCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const LinksCreateRequestCookiesItemPriority: any;
export type LinksCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const LinksCreateRequestCookiesItemSameSite: any;
export type LinksCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const LinksCreateRequestCookiesItemSourceScheme: any;
export interface LinksCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: LinksCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: LinksCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: LinksCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const LinksCreateRequestCookiesItem: S.Schema<LinksCreateRequestCookiesItem>;
export type LinksCreateRequestCookiesList = Array<LinksCreateRequestCookiesItem>;
export declare const LinksCreateRequestCookiesList: S.Schema<LinksCreateRequestCookiesList>;
export type LinksCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const LinksCreateRequestGotoOptionsWaitUntilCase0: any;
export type LinksCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const LinksCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type LinksCreateRequestGotoOptionsWaitUntilCase1List = Array<LinksCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const LinksCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<LinksCreateRequestGotoOptionsWaitUntilCase1List>;
export type LinksCreateRequestGotoOptionsWaitUntil = LinksCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | LinksCreateRequestGotoOptionsWaitUntilCase1List;
export declare const LinksCreateRequestGotoOptionsWaitUntil: any;
export interface LinksCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: LinksCreateRequestGotoOptionsWaitUntil;
}
export declare const LinksCreateRequestGotoOptions: S.Schema<LinksCreateRequestGotoOptions>;
export type LinksCreateRequestRejectRequestPatternList = Array<string>;
export declare const LinksCreateRequestRejectRequestPatternList: S.Schema<LinksCreateRequestRejectRequestPatternList>;
export type LinksCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const LinksCreateRequestRejectResourceTypesItem: any;
export type LinksCreateRequestRejectResourceTypesList = Array<LinksCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const LinksCreateRequestRejectResourceTypesList: S.Schema<LinksCreateRequestRejectResourceTypesList>;
export type LinksCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const LinksCreateRequestSetExtraHTTPHeadersMap: S.Schema<LinksCreateRequestSetExtraHTTPHeadersMap>;
export type LinksCreateRequestViewport = ContentCreateRequestViewport;
export declare const LinksCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type LinksCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const LinksCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateLinkRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: LinksCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: LinksCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: LinksCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: LinksCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: LinksCreateRequestCookiesList;
    emulateMediaType?: string;
    excludeExternalLinks?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: LinksCreateRequestGotoOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: LinksCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: LinksCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: LinksCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    visibleLinksOnly?: boolean;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
}
export declare const CreateLinkRequest: S.Schema<CreateLinkRequest>;
export type LinksCreateResultList = Array<string>;
export declare const LinksCreateResultList: S.Schema<LinksCreateResultList>;
export type CreateLinkResponse = LinksCreateResultList;
export declare const CreateLinkResponse: S.Schema<CreateLinkResponse>;
export type MarkdownCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const MarkdownCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type MarkdownCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const MarkdownCreateRequestAddScriptTagList: S.Schema<MarkdownCreateRequestAddScriptTagList>;
export type MarkdownCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const MarkdownCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type MarkdownCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const MarkdownCreateRequestAddStyleTagList: S.Schema<MarkdownCreateRequestAddStyleTagList>;
export type MarkdownCreateRequestAllowRequestPatternList = Array<string>;
export declare const MarkdownCreateRequestAllowRequestPatternList: S.Schema<MarkdownCreateRequestAllowRequestPatternList>;
export type MarkdownCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const MarkdownCreateRequestAllowResourceTypesItem: any;
export type MarkdownCreateRequestAllowResourceTypesList = Array<MarkdownCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const MarkdownCreateRequestAllowResourceTypesList: S.Schema<MarkdownCreateRequestAllowResourceTypesList>;
export type MarkdownCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const MarkdownCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type MarkdownCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const MarkdownCreateRequestCookiesItemPriority: any;
export type MarkdownCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const MarkdownCreateRequestCookiesItemSameSite: any;
export type MarkdownCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const MarkdownCreateRequestCookiesItemSourceScheme: any;
export interface MarkdownCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: MarkdownCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: MarkdownCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: MarkdownCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const MarkdownCreateRequestCookiesItem: S.Schema<MarkdownCreateRequestCookiesItem>;
export type MarkdownCreateRequestCookiesList = Array<MarkdownCreateRequestCookiesItem>;
export declare const MarkdownCreateRequestCookiesList: S.Schema<MarkdownCreateRequestCookiesList>;
export type MarkdownCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const MarkdownCreateRequestGotoOptionsWaitUntilCase0: any;
export type MarkdownCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const MarkdownCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type MarkdownCreateRequestGotoOptionsWaitUntilCase1List = Array<MarkdownCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const MarkdownCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<MarkdownCreateRequestGotoOptionsWaitUntilCase1List>;
export type MarkdownCreateRequestGotoOptionsWaitUntil = MarkdownCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | MarkdownCreateRequestGotoOptionsWaitUntilCase1List;
export declare const MarkdownCreateRequestGotoOptionsWaitUntil: any;
export interface MarkdownCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: MarkdownCreateRequestGotoOptionsWaitUntil;
}
export declare const MarkdownCreateRequestGotoOptions: S.Schema<MarkdownCreateRequestGotoOptions>;
export type MarkdownCreateRequestRejectRequestPatternList = Array<string>;
export declare const MarkdownCreateRequestRejectRequestPatternList: S.Schema<MarkdownCreateRequestRejectRequestPatternList>;
export type MarkdownCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const MarkdownCreateRequestRejectResourceTypesItem: any;
export type MarkdownCreateRequestRejectResourceTypesList = Array<MarkdownCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const MarkdownCreateRequestRejectResourceTypesList: S.Schema<MarkdownCreateRequestRejectResourceTypesList>;
export type MarkdownCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const MarkdownCreateRequestSetExtraHTTPHeadersMap: S.Schema<MarkdownCreateRequestSetExtraHTTPHeadersMap>;
export type MarkdownCreateRequestViewport = ContentCreateRequestViewport;
export declare const MarkdownCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type MarkdownCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const MarkdownCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateMarkdownRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: MarkdownCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: MarkdownCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: MarkdownCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: MarkdownCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: MarkdownCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: MarkdownCreateRequestGotoOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: MarkdownCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: MarkdownCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: MarkdownCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
}
export declare const CreateMarkdownRequest: S.Schema<CreateMarkdownRequest>;
export type CreateMarkdownResponse = string;
export declare const CreateMarkdownResponse: S.Schema<CreateMarkdownResponse>;
export type PdfCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const PdfCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type PdfCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const PdfCreateRequestAddScriptTagList: S.Schema<PdfCreateRequestAddScriptTagList>;
export type PdfCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const PdfCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type PdfCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const PdfCreateRequestAddStyleTagList: S.Schema<PdfCreateRequestAddStyleTagList>;
export type PdfCreateRequestAllowRequestPatternList = Array<string>;
export declare const PdfCreateRequestAllowRequestPatternList: S.Schema<PdfCreateRequestAllowRequestPatternList>;
export type PdfCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const PdfCreateRequestAllowResourceTypesItem: any;
export type PdfCreateRequestAllowResourceTypesList = Array<PdfCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const PdfCreateRequestAllowResourceTypesList: S.Schema<PdfCreateRequestAllowResourceTypesList>;
export type PdfCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const PdfCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type PdfCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const PdfCreateRequestCookiesItemPriority: any;
export type PdfCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const PdfCreateRequestCookiesItemSameSite: any;
export type PdfCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const PdfCreateRequestCookiesItemSourceScheme: any;
export interface PdfCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: PdfCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: PdfCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: PdfCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const PdfCreateRequestCookiesItem: S.Schema<PdfCreateRequestCookiesItem>;
export type PdfCreateRequestCookiesList = Array<PdfCreateRequestCookiesItem>;
export declare const PdfCreateRequestCookiesList: S.Schema<PdfCreateRequestCookiesList>;
export type PdfCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const PdfCreateRequestGotoOptionsWaitUntilCase0: any;
export type PdfCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const PdfCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type PdfCreateRequestGotoOptionsWaitUntilCase1List = Array<PdfCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const PdfCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<PdfCreateRequestGotoOptionsWaitUntilCase1List>;
export type PdfCreateRequestGotoOptionsWaitUntil = PdfCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | PdfCreateRequestGotoOptionsWaitUntilCase1List;
export declare const PdfCreateRequestGotoOptionsWaitUntil: any;
export interface PdfCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: PdfCreateRequestGotoOptionsWaitUntil;
}
export declare const PdfCreateRequestGotoOptions: S.Schema<PdfCreateRequestGotoOptions>;
export type PdfCreateRequestPdfOptionsFormat = "letter" | "legal" | "tabloid" | "ledger" | "a0" | "a1" | "a2" | "a3" | "a4" | "a5" | "a6";
export declare const PdfCreateRequestPdfOptionsFormat: any;
export type PdfCreateRequestPdfOptionsHeight = string | number;
export declare const PdfCreateRequestPdfOptionsHeight: any;
export type PdfCreateRequestPdfOptionsMarginBottom = string | number;
export declare const PdfCreateRequestPdfOptionsMarginBottom: any;
export type PdfCreateRequestPdfOptionsMarginLeft = string | number;
export declare const PdfCreateRequestPdfOptionsMarginLeft: any;
export type PdfCreateRequestPdfOptionsMarginRight = string | number;
export declare const PdfCreateRequestPdfOptionsMarginRight: any;
export type PdfCreateRequestPdfOptionsMarginTop = string | number;
export declare const PdfCreateRequestPdfOptionsMarginTop: any;
export interface PdfCreateRequestPdfOptionsMargin {
    bottom?: PdfCreateRequestPdfOptionsMarginBottom;
    left?: PdfCreateRequestPdfOptionsMarginLeft;
    right?: PdfCreateRequestPdfOptionsMarginRight;
    top?: PdfCreateRequestPdfOptionsMarginTop;
}
export declare const PdfCreateRequestPdfOptionsMargin: S.Schema<PdfCreateRequestPdfOptionsMargin>;
export type PdfCreateRequestPdfOptionsWidth = string | number;
export declare const PdfCreateRequestPdfOptionsWidth: any;
export interface PdfCreateRequestPdfOptions {
    /** Whether to show the header and footer. */
    displayHeaderFooter?: boolean;
    /** HTML template for the print footer. */
    footerTemplate?: string;
    /** Paper format. Takes priority over width and height if set. */
    format?: PdfCreateRequestPdfOptionsFormat | (string & {});
    /** HTML template for the print header. */
    headerTemplate?: string;
    /** Sets the height of paper. Can be a number or string with unit. */
    height?: PdfCreateRequestPdfOptionsHeight;
    /** Whether to print in landscape orientation. */
    landscape?: boolean;
    /** Set the PDF margins. Useful when setting header and footer. */
    margin?: PdfCreateRequestPdfOptionsMargin;
    /** Hides default white background and allows generating pdfs with transparency. */
    omitBackground?: boolean;
    /** Generate document outline. */
    outline?: boolean;
    /** Paper ranges to print, e.g. '1-5, 8, 11-13'. */
    pageRanges?: string;
    /** Give CSS @page size priority over other size declarations. */
    preferCSSPageSize?: boolean;
    /** Set to true to print background graphics. */
    printBackground?: boolean;
    /** Scales the rendering of the web page. Amount must be between 0.1 and 2. */
    scale?: number;
    /** Generate tagged (accessible) PDF. */
    tagged?: boolean;
    /** Timeout in milliseconds. */
    timeout?: number;
    /** Sets the width of paper. Can be a number or string with unit. */
    width?: PdfCreateRequestPdfOptionsWidth;
}
export declare const PdfCreateRequestPdfOptions: S.Schema<PdfCreateRequestPdfOptions>;
export type PdfCreateRequestRejectRequestPatternList = Array<string>;
export declare const PdfCreateRequestRejectRequestPatternList: S.Schema<PdfCreateRequestRejectRequestPatternList>;
export type PdfCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const PdfCreateRequestRejectResourceTypesItem: any;
export type PdfCreateRequestRejectResourceTypesList = Array<PdfCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const PdfCreateRequestRejectResourceTypesList: S.Schema<PdfCreateRequestRejectResourceTypesList>;
export type PdfCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const PdfCreateRequestSetExtraHTTPHeadersMap: S.Schema<PdfCreateRequestSetExtraHTTPHeadersMap>;
export type PdfCreateRequestViewport = ContentCreateRequestViewport;
export declare const PdfCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type PdfCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const PdfCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreatePdfRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: PdfCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: PdfCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: PdfCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: PdfCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: PdfCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: PdfCreateRequestGotoOptions;
    /** Check [options](https://pptr.dev/api/puppeteer.pdfoptions). */
    pdfOptions?: PdfCreateRequestPdfOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: PdfCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: PdfCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: PdfCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
}
export declare const CreatePdfRequest: S.Schema<CreatePdfRequest>;
export interface CreatePdfResponse {
}
export declare const CreatePdfResponse: S.Schema<CreatePdfResponse>;
export interface ScrapeCreateRequestElementsItem {
    selector: string;
}
export declare const ScrapeCreateRequestElementsItem: S.Schema<ScrapeCreateRequestElementsItem>;
export type ScrapeCreateRequestElementsList = Array<ScrapeCreateRequestElementsItem>;
export declare const ScrapeCreateRequestElementsList: S.Schema<ScrapeCreateRequestElementsList>;
export type ScrapeCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const ScrapeCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type ScrapeCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const ScrapeCreateRequestAddScriptTagList: S.Schema<ScrapeCreateRequestAddScriptTagList>;
export type ScrapeCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const ScrapeCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type ScrapeCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const ScrapeCreateRequestAddStyleTagList: S.Schema<ScrapeCreateRequestAddStyleTagList>;
export type ScrapeCreateRequestAllowRequestPatternList = Array<string>;
export declare const ScrapeCreateRequestAllowRequestPatternList: S.Schema<ScrapeCreateRequestAllowRequestPatternList>;
export type ScrapeCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const ScrapeCreateRequestAllowResourceTypesItem: any;
export type ScrapeCreateRequestAllowResourceTypesList = Array<ScrapeCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const ScrapeCreateRequestAllowResourceTypesList: S.Schema<ScrapeCreateRequestAllowResourceTypesList>;
export type ScrapeCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const ScrapeCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type ScrapeCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const ScrapeCreateRequestCookiesItemPriority: any;
export type ScrapeCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const ScrapeCreateRequestCookiesItemSameSite: any;
export type ScrapeCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const ScrapeCreateRequestCookiesItemSourceScheme: any;
export interface ScrapeCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: ScrapeCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: ScrapeCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: ScrapeCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const ScrapeCreateRequestCookiesItem: S.Schema<ScrapeCreateRequestCookiesItem>;
export type ScrapeCreateRequestCookiesList = Array<ScrapeCreateRequestCookiesItem>;
export declare const ScrapeCreateRequestCookiesList: S.Schema<ScrapeCreateRequestCookiesList>;
export type ScrapeCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const ScrapeCreateRequestGotoOptionsWaitUntilCase0: any;
export type ScrapeCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const ScrapeCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type ScrapeCreateRequestGotoOptionsWaitUntilCase1List = Array<ScrapeCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const ScrapeCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<ScrapeCreateRequestGotoOptionsWaitUntilCase1List>;
export type ScrapeCreateRequestGotoOptionsWaitUntil = ScrapeCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | ScrapeCreateRequestGotoOptionsWaitUntilCase1List;
export declare const ScrapeCreateRequestGotoOptionsWaitUntil: any;
export interface ScrapeCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: ScrapeCreateRequestGotoOptionsWaitUntil;
}
export declare const ScrapeCreateRequestGotoOptions: S.Schema<ScrapeCreateRequestGotoOptions>;
export type ScrapeCreateRequestRejectRequestPatternList = Array<string>;
export declare const ScrapeCreateRequestRejectRequestPatternList: S.Schema<ScrapeCreateRequestRejectRequestPatternList>;
export type ScrapeCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const ScrapeCreateRequestRejectResourceTypesItem: any;
export type ScrapeCreateRequestRejectResourceTypesList = Array<ScrapeCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const ScrapeCreateRequestRejectResourceTypesList: S.Schema<ScrapeCreateRequestRejectResourceTypesList>;
export type ScrapeCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ScrapeCreateRequestSetExtraHTTPHeadersMap: S.Schema<ScrapeCreateRequestSetExtraHTTPHeadersMap>;
export type ScrapeCreateRequestViewport = ContentCreateRequestViewport;
export declare const ScrapeCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type ScrapeCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const ScrapeCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateScrapeRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    elements: ScrapeCreateRequestElementsList;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: ScrapeCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: ScrapeCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: ScrapeCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: ScrapeCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: ScrapeCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: ScrapeCreateRequestGotoOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: ScrapeCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: ScrapeCreateRequestRejectResourceTypesList;
    setExtraHTTPHeaders?: ScrapeCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
}
export declare const CreateScrapeRequest: S.Schema<CreateScrapeRequest>;
export interface ScrapeCreateResultItemResultsAttributesItem {
    /** Attribute name. */
    name: string;
    /** Attribute value. */
    value: string;
}
export declare const ScrapeCreateResultItemResultsAttributesItem: S.Schema<ScrapeCreateResultItemResultsAttributesItem>;
export type ScrapeCreateResultItemResultsAttributesList = Array<ScrapeCreateResultItemResultsAttributesItem>;
export declare const ScrapeCreateResultItemResultsAttributesList: S.Schema<ScrapeCreateResultItemResultsAttributesList>;
export interface ScrapeCreateResultItemResults {
    attributes: ScrapeCreateResultItemResultsAttributesList;
    /** Element height. */
    height: number;
    /** HTML content. */
    html: string;
    /** Element left. */
    left: number;
    /** Text content. */
    text: string;
    /** Element top. */
    top: number;
    /** Element width. */
    width: number;
}
export declare const ScrapeCreateResultItemResults: S.Schema<ScrapeCreateResultItemResults>;
export interface ScrapeCreateResultItem {
    results: ScrapeCreateResultItemResults;
    /** Selector. */
    selector: string;
}
export declare const ScrapeCreateResultItem: S.Schema<ScrapeCreateResultItem>;
export type ScrapeCreateResultList = Array<ScrapeCreateResultItem>;
export declare const ScrapeCreateResultList: S.Schema<ScrapeCreateResultList>;
export type CreateScrapeResponse = ScrapeCreateResultList;
export declare const CreateScrapeResponse: S.Schema<CreateScrapeResponse>;
export type ScreenshotCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const ScreenshotCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type ScreenshotCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const ScreenshotCreateRequestAddScriptTagList: S.Schema<ScreenshotCreateRequestAddScriptTagList>;
export type ScreenshotCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const ScreenshotCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type ScreenshotCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const ScreenshotCreateRequestAddStyleTagList: S.Schema<ScreenshotCreateRequestAddStyleTagList>;
export type ScreenshotCreateRequestAllowRequestPatternList = Array<string>;
export declare const ScreenshotCreateRequestAllowRequestPatternList: S.Schema<ScreenshotCreateRequestAllowRequestPatternList>;
export type ScreenshotCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const ScreenshotCreateRequestAllowResourceTypesItem: any;
export type ScreenshotCreateRequestAllowResourceTypesList = Array<ScreenshotCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const ScreenshotCreateRequestAllowResourceTypesList: S.Schema<ScreenshotCreateRequestAllowResourceTypesList>;
export type ScreenshotCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const ScreenshotCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type ScreenshotCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const ScreenshotCreateRequestCookiesItemPriority: any;
export type ScreenshotCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const ScreenshotCreateRequestCookiesItemSameSite: any;
export type ScreenshotCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const ScreenshotCreateRequestCookiesItemSourceScheme: any;
export interface ScreenshotCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: ScreenshotCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: ScreenshotCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: ScreenshotCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const ScreenshotCreateRequestCookiesItem: S.Schema<ScreenshotCreateRequestCookiesItem>;
export type ScreenshotCreateRequestCookiesList = Array<ScreenshotCreateRequestCookiesItem>;
export declare const ScreenshotCreateRequestCookiesList: S.Schema<ScreenshotCreateRequestCookiesList>;
export type ScreenshotCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const ScreenshotCreateRequestGotoOptionsWaitUntilCase0: any;
export type ScreenshotCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const ScreenshotCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type ScreenshotCreateRequestGotoOptionsWaitUntilCase1List = Array<ScreenshotCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const ScreenshotCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<ScreenshotCreateRequestGotoOptionsWaitUntilCase1List>;
export type ScreenshotCreateRequestGotoOptionsWaitUntil = ScreenshotCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | ScreenshotCreateRequestGotoOptionsWaitUntilCase1List;
export declare const ScreenshotCreateRequestGotoOptionsWaitUntil: any;
export interface ScreenshotCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: ScreenshotCreateRequestGotoOptionsWaitUntil;
}
export declare const ScreenshotCreateRequestGotoOptions: S.Schema<ScreenshotCreateRequestGotoOptions>;
export type ScreenshotCreateRequestRejectRequestPatternList = Array<string>;
export declare const ScreenshotCreateRequestRejectRequestPatternList: S.Schema<ScreenshotCreateRequestRejectRequestPatternList>;
export type ScreenshotCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const ScreenshotCreateRequestRejectResourceTypesItem: any;
export type ScreenshotCreateRequestRejectResourceTypesList = Array<ScreenshotCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const ScreenshotCreateRequestRejectResourceTypesList: S.Schema<ScreenshotCreateRequestRejectResourceTypesList>;
export interface ScreenshotCreateRequestScreenshotOptionsClip {
    height: number;
    width: number;
    x: number;
    y: number;
    scale?: number;
}
export declare const ScreenshotCreateRequestScreenshotOptionsClip: S.Schema<ScreenshotCreateRequestScreenshotOptionsClip>;
export type ScreenshotCreateRequestScreenshotOptionsEncoding = "binary" | "base64";
export declare const ScreenshotCreateRequestScreenshotOptionsEncoding: any;
export type ScreenshotCreateRequestScreenshotOptionsType = "png" | "jpeg" | "webp";
export declare const ScreenshotCreateRequestScreenshotOptionsType: any;
export interface ScreenshotCreateRequestScreenshotOptions {
    captureBeyondViewport?: boolean;
    clip?: ScreenshotCreateRequestScreenshotOptionsClip;
    encoding?: ScreenshotCreateRequestScreenshotOptionsEncoding | (string & {});
    fromSurface?: boolean;
    fullPage?: boolean;
    omitBackground?: boolean;
    optimizeForSpeed?: boolean;
    quality?: number;
    type?: ScreenshotCreateRequestScreenshotOptionsType | (string & {});
}
export declare const ScreenshotCreateRequestScreenshotOptions: S.Schema<ScreenshotCreateRequestScreenshotOptions>;
export type ScreenshotCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ScreenshotCreateRequestSetExtraHTTPHeadersMap: S.Schema<ScreenshotCreateRequestSetExtraHTTPHeadersMap>;
export type ScreenshotCreateRequestViewport = ContentCreateRequestViewport;
export declare const ScreenshotCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type ScreenshotCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const ScreenshotCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateScreenshotRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: ScreenshotCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: ScreenshotCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: ScreenshotCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: ScreenshotCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: ScreenshotCreateRequestCookiesList;
    emulateMediaType?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: ScreenshotCreateRequestGotoOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: ScreenshotCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: ScreenshotCreateRequestRejectResourceTypesList;
    /** Check [options](https://pptr.dev/api/puppeteer.screenshotoptions). */
    screenshotOptions?: ScreenshotCreateRequestScreenshotOptions;
    scrollPage?: boolean;
    selector?: string;
    setExtraHTTPHeaders?: ScreenshotCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
}
export declare const CreateScreenshotRequest: S.Schema<CreateScreenshotRequest>;
export interface CreateScreenshotResponse {
}
export declare const CreateScreenshotResponse: S.Schema<CreateScreenshotResponse>;
export type SnapshotCreateRequestAddScriptTagItem = ContentCreateRequestAddScriptTagItem;
export declare const SnapshotCreateRequestAddScriptTagItem: S.Schema<ContentCreateRequestAddScriptTagItem>;
export type SnapshotCreateRequestAddScriptTagList = Array<ContentCreateRequestAddScriptTagItem>;
export declare const SnapshotCreateRequestAddScriptTagList: S.Schema<SnapshotCreateRequestAddScriptTagList>;
export type SnapshotCreateRequestAddStyleTagItem = ContentCreateRequestAddStyleTagItem;
export declare const SnapshotCreateRequestAddStyleTagItem: S.Schema<ContentCreateRequestAddStyleTagItem>;
export type SnapshotCreateRequestAddStyleTagList = Array<ContentCreateRequestAddStyleTagItem>;
export declare const SnapshotCreateRequestAddStyleTagList: S.Schema<SnapshotCreateRequestAddStyleTagList>;
export type SnapshotCreateRequestAllowRequestPatternList = Array<string>;
export declare const SnapshotCreateRequestAllowRequestPatternList: S.Schema<SnapshotCreateRequestAllowRequestPatternList>;
export type SnapshotCreateRequestAllowResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const SnapshotCreateRequestAllowResourceTypesItem: any;
export type SnapshotCreateRequestAllowResourceTypesList = Array<SnapshotCreateRequestAllowResourceTypesItem | (string & {})>;
export declare const SnapshotCreateRequestAllowResourceTypesList: S.Schema<SnapshotCreateRequestAllowResourceTypesList>;
export type SnapshotCreateRequestAuthenticate = ContentCreateRequestAuthenticate;
export declare const SnapshotCreateRequestAuthenticate: S.Schema<ContentCreateRequestAuthenticate>;
export type SnapshotCreateRequestCookiesItemPriority = "Low" | "Medium" | "High";
export declare const SnapshotCreateRequestCookiesItemPriority: any;
export type SnapshotCreateRequestCookiesItemSameSite = "Strict" | "Lax" | "None";
export declare const SnapshotCreateRequestCookiesItemSameSite: any;
export type SnapshotCreateRequestCookiesItemSourceScheme = "Unset" | "NonSecure" | "Secure";
export declare const SnapshotCreateRequestCookiesItemSourceScheme: any;
export interface SnapshotCreateRequestCookiesItem {
    /** Cookie name. */
    name: string;
    value: string;
    domain?: string;
    expires?: number;
    httpOnly?: boolean;
    partitionKey?: string;
    path?: string;
    priority?: SnapshotCreateRequestCookiesItemPriority | (string & {});
    sameParty?: boolean;
    sameSite?: SnapshotCreateRequestCookiesItemSameSite | (string & {});
    secure?: boolean;
    sourcePort?: number;
    sourceScheme?: SnapshotCreateRequestCookiesItemSourceScheme | (string & {});
    url?: string;
}
export declare const SnapshotCreateRequestCookiesItem: S.Schema<SnapshotCreateRequestCookiesItem>;
export type SnapshotCreateRequestCookiesList = Array<SnapshotCreateRequestCookiesItem>;
export declare const SnapshotCreateRequestCookiesList: S.Schema<SnapshotCreateRequestCookiesList>;
export type SnapshotCreateRequestFormatsItem = "content" | "screenshot" | "markdown" | "accessibilityTree";
export declare const SnapshotCreateRequestFormatsItem: any;
export type SnapshotCreateRequestFormatsList = Array<SnapshotCreateRequestFormatsItem | (string & {})>;
export declare const SnapshotCreateRequestFormatsList: S.Schema<SnapshotCreateRequestFormatsList>;
export type SnapshotCreateRequestGotoOptionsWaitUntilCase0 = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const SnapshotCreateRequestGotoOptionsWaitUntilCase0: any;
export type SnapshotCreateRequestGotoOptionsWaitUntilCase1Item = "load" | "domcontentloaded" | "networkidle0" | "networkidle2";
export declare const SnapshotCreateRequestGotoOptionsWaitUntilCase1Item: any;
export type SnapshotCreateRequestGotoOptionsWaitUntilCase1List = Array<SnapshotCreateRequestGotoOptionsWaitUntilCase1Item | (string & {})>;
export declare const SnapshotCreateRequestGotoOptionsWaitUntilCase1List: S.Schema<SnapshotCreateRequestGotoOptionsWaitUntilCase1List>;
export type SnapshotCreateRequestGotoOptionsWaitUntil = SnapshotCreateRequestGotoOptionsWaitUntilCase0 | (string & {}) | SnapshotCreateRequestGotoOptionsWaitUntilCase1List;
export declare const SnapshotCreateRequestGotoOptionsWaitUntil: any;
export interface SnapshotCreateRequestGotoOptions {
    referer?: string;
    referrerPolicy?: string;
    timeout?: number;
    waitUntil?: SnapshotCreateRequestGotoOptionsWaitUntil;
}
export declare const SnapshotCreateRequestGotoOptions: S.Schema<SnapshotCreateRequestGotoOptions>;
export type SnapshotCreateRequestRejectRequestPatternList = Array<string>;
export declare const SnapshotCreateRequestRejectRequestPatternList: S.Schema<SnapshotCreateRequestRejectRequestPatternList>;
export type SnapshotCreateRequestRejectResourceTypesItem = "document" | "stylesheet" | "image" | "media" | "font" | "script" | "texttrack" | "xhr" | "fetch" | "prefetch" | "eventsource" | "websocket" | "manifest" | "signedexchange" | "ping" | "cspviolationreport" | "preflight" | "other";
export declare const SnapshotCreateRequestRejectResourceTypesItem: any;
export type SnapshotCreateRequestRejectResourceTypesList = Array<SnapshotCreateRequestRejectResourceTypesItem | (string & {})>;
export declare const SnapshotCreateRequestRejectResourceTypesList: S.Schema<SnapshotCreateRequestRejectResourceTypesList>;
export type SnapshotCreateRequestScreenshotOptionsClip = ScreenshotCreateRequestScreenshotOptionsClip;
export declare const SnapshotCreateRequestScreenshotOptionsClip: S.Schema<ScreenshotCreateRequestScreenshotOptionsClip>;
export type SnapshotCreateRequestScreenshotOptionsType = "png" | "jpeg" | "webp";
export declare const SnapshotCreateRequestScreenshotOptionsType: any;
export interface SnapshotCreateRequestScreenshotOptions {
    captureBeyondViewport?: boolean;
    clip?: ScreenshotCreateRequestScreenshotOptionsClip;
    fromSurface?: boolean;
    fullPage?: boolean;
    omitBackground?: boolean;
    optimizeForSpeed?: boolean;
    quality?: number;
    type?: SnapshotCreateRequestScreenshotOptionsType | (string & {});
}
export declare const SnapshotCreateRequestScreenshotOptions: S.Schema<SnapshotCreateRequestScreenshotOptions>;
export type SnapshotCreateRequestSetExtraHTTPHeadersMap = {
    [key: string]: string | undefined;
};
export declare const SnapshotCreateRequestSetExtraHTTPHeadersMap: S.Schema<SnapshotCreateRequestSetExtraHTTPHeadersMap>;
export type SnapshotCreateRequestViewport = ContentCreateRequestViewport;
export declare const SnapshotCreateRequestViewport: S.Schema<ContentCreateRequestViewport>;
export type SnapshotCreateRequestWaitForSelector = ContentCreateRequestWaitForSelector;
export declare const SnapshotCreateRequestWaitForSelector: S.Schema<ContentCreateRequestWaitForSelector>;
export interface CreateSnapshotRequest {
    /** Account ID. */
    accountId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Set the content of the page, eg: `<h1>Hello World!!</h1>`. Either `html` or `url` must be set. */
    html?: string;
    /** The maximum duration allowed for the browser action to complete after the page has loaded (such as taking screenshots, extracting content, or generating PDFs). If this time limit is exceeded, the action stops and returns a timeout error. */
    actionTimeout?: number;
    /** Adds a `<script>` tag into the page with the desired URL or content. */
    addScriptTag?: SnapshotCreateRequestAddScriptTagList;
    /** Adds a `<link rel="stylesheet">` tag into the page with the desired URL or a `<style type="text/css">` tag with the content. */
    addStyleTag?: SnapshotCreateRequestAddStyleTagList;
    /** Only allow requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    allowRequestPattern?: SnapshotCreateRequestAllowRequestPatternList;
    /** Only allow requests that match the provided resource types, eg. 'image' or 'script'. */
    allowResourceTypes?: SnapshotCreateRequestAllowResourceTypesList;
    /** Provide credentials for HTTP authentication. */
    authenticate?: ContentCreateRequestAuthenticate;
    /** Attempt to proceed when 'awaited' events fail or timeout. */
    bestAttempt?: boolean;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setcookie). */
    cookies?: SnapshotCreateRequestCookiesList;
    emulateMediaType?: string;
    formats?: SnapshotCreateRequestFormatsList;
    /** Check [options](https://pptr.dev/api/puppeteer.gotooptions). */
    gotoOptions?: SnapshotCreateRequestGotoOptions;
    /** Block undesired requests that match the provided regex patterns, eg. '/^.*.(css)'. */
    rejectRequestPattern?: SnapshotCreateRequestRejectRequestPatternList;
    /** Block undesired requests that match the provided resource types, eg. 'image' or 'script'. */
    rejectResourceTypes?: SnapshotCreateRequestRejectResourceTypesList;
    screenshotOptions?: SnapshotCreateRequestScreenshotOptions;
    setExtraHTTPHeaders?: SnapshotCreateRequestSetExtraHTTPHeadersMap;
    setJavaScriptEnabled?: boolean;
    userAgent?: string;
    /** Check [options](https://pptr.dev/api/puppeteer.page.setviewport). */
    viewport?: ContentCreateRequestViewport;
    /** Wait for the selector to appear in page. Check [options](https://pptr.dev/api/puppeteer.page.waitforselector). */
    waitForSelector?: ContentCreateRequestWaitForSelector;
    /** Waits for a specified timeout before continuing. */
    waitForTimeout?: number;
    /** URL to navigate to, eg. `https://example.com`. */
    url?: string;
}
export declare const CreateSnapshotRequest: S.Schema<CreateSnapshotRequest>;
export type SnapshotCreateResponseAccessibilityTreeChecked = "mixed";
export declare const SnapshotCreateResponseAccessibilityTreeChecked: any;
export type SnapshotCreateResponseAccessibilityTreeChecked2 = SnapshotCreateResponseAccessibilityTreeChecked | boolean;
export declare const SnapshotCreateResponseAccessibilityTreeChecked2: any;
export type SnapshotCreateResponseAccessibilityTreeChildrenList = Array<unknown>;
export declare const SnapshotCreateResponseAccessibilityTreeChildrenList: S.Schema<SnapshotCreateResponseAccessibilityTreeChildrenList>;
export type SnapshotCreateResponseAccessibilityTreePressed = "mixed";
export declare const SnapshotCreateResponseAccessibilityTreePressed: any;
export type SnapshotCreateResponseAccessibilityTreePressed2 = SnapshotCreateResponseAccessibilityTreePressed | boolean;
export declare const SnapshotCreateResponseAccessibilityTreePressed2: any;
export type SnapshotCreateResponseAccessibilityTreeValue = string | number;
export declare const SnapshotCreateResponseAccessibilityTreeValue: any;
export interface SnapshotCreateResponseAccessibilityTree {
    role: string;
    autocomplete?: string | null;
    checked?: SnapshotCreateResponseAccessibilityTreeChecked2 | null;
    children?: SnapshotCreateResponseAccessibilityTreeChildrenList | null;
    description?: string | null;
    disabled?: boolean | null;
    expanded?: boolean | null;
    focused?: boolean | null;
    haspopup?: string | null;
    invalid?: string | null;
    keyshortcuts?: string | null;
    level?: number | null;
    modal?: boolean | null;
    multiline?: boolean | null;
    multiselectable?: boolean | null;
    name?: string | null;
    orientation?: string | null;
    pressed?: SnapshotCreateResponseAccessibilityTreePressed2 | null;
    readonly?: boolean | null;
    required?: boolean | null;
    roledescription?: string | null;
    selected?: boolean | null;
    value?: SnapshotCreateResponseAccessibilityTreeValue | null;
    valuemax?: number | null;
    valuemin?: number | null;
    valuetext?: string | null;
}
export declare const SnapshotCreateResponseAccessibilityTree: S.Schema<SnapshotCreateResponseAccessibilityTree>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSnapshotResponse {
    /** Accessibility tree node */
    accessibilityTree?: SnapshotCreateResponseAccessibilityTree | null;
    /** HTML content. */
    content?: string | null;
    /** Markdown content. */
    markdown?: string | null;
    /** Base64 encoded image. */
    screenshot?: string | null;
}
export declare const CreateSnapshotResponse: S.Schema<CreateSnapshotResponse>;
export interface DeleteCrawlRequest {
    /** Account ID. */
    accountId: string;
    /** The ID of the crawl job to cancel. */
    jobId: string;
}
export declare const DeleteCrawlRequest: S.Schema<DeleteCrawlRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCrawlResponse {
    /** The ID of the cancelled job. */
    jobId: string;
    /** Cancellation confirmation message. */
    message: string;
}
export declare const DeleteCrawlResponse: S.Schema<DeleteCrawlResponse>;
export interface DeleteDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID to close. */
    sessionId: string;
}
export declare const DeleteDevtoolBrowserRequest: S.Schema<DeleteDevtoolBrowserRequest>;
export type DevtoolsBrowserDeleteResponseStatus = "closing" | "closed";
export declare const DevtoolsBrowserDeleteResponseStatus: any;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteDevtoolBrowserResponse {
    status: DevtoolsBrowserDeleteResponseStatus;
}
export declare const DeleteDevtoolBrowserResponse: S.Schema<DeleteDevtoolBrowserResponse>;
export type CrawlGetRequestStatus = "queued" | "errored" | "completed" | "disallowed" | "skipped" | "cancelled";
export declare const CrawlGetRequestStatus: any;
export interface GetCrawlRequest {
    /** Account ID. */
    accountId: string;
    /** Crawl job ID. */
    jobId: string;
    /** Cache TTL default is 5s. Set to 0 to disable. */
    cacheTTL?: number;
    /** Cursor for pagination. */
    cursor?: number;
    /** Limit for pagination. */
    limit?: number;
    /** Filter by URL status. */
    status?: CrawlGetRequestStatus | (string & {});
}
export declare const GetCrawlRequest: S.Schema<GetCrawlRequest>;
export interface CrawlGetResponseRecordsItemMetadata {
    /** HTTP status code of the crawled page. */
    status: number;
    /** Final URL of the crawled page. */
    url: string;
    /** Title of the crawled page. */
    title?: string | null;
}
export declare const CrawlGetResponseRecordsItemMetadata: S.Schema<CrawlGetResponseRecordsItemMetadata>;
export type CrawlGetResponseRecordsItemStatus = "queued" | "errored" | "completed" | "disallowed" | "skipped" | "cancelled";
export declare const CrawlGetResponseRecordsItemStatus: any;
export type CrawlGetResponseRecordsItemJsonMap = {
    [key: string]: unknown | undefined;
};
export declare const CrawlGetResponseRecordsItemJsonMap: S.Schema<CrawlGetResponseRecordsItemJsonMap>;
export interface CrawlGetResponseRecordsItem {
    metadata?: CrawlGetResponseRecordsItemMetadata | null;
    /** Current status of the crawled URL. */
    status: CrawlGetResponseRecordsItemStatus;
    /** Crawled URL. */
    url: string;
    /** HTML content of the crawled URL. */
    html?: string | null;
    /** JSON of the content of the crawled URL. */
    json?: CrawlGetResponseRecordsItemJsonMap | null;
    /** Markdown of the content of the crawled URL. */
    markdown?: string | null;
}
export declare const CrawlGetResponseRecordsItem: S.Schema<CrawlGetResponseRecordsItem>;
export type CrawlGetResponseRecordsList = Array<CrawlGetResponseRecordsItem>;
export declare const CrawlGetResponseRecordsList: S.Schema<CrawlGetResponseRecordsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCrawlResponse {
    /** Crawl job ID. */
    id: string;
    /** Total seconds spent in browser so far. */
    browserSecondsUsed: number;
    /** Total number of URLs that have been crawled so far. */
    finished: number;
    /** List of crawl job records. */
    records: CrawlGetResponseRecordsList;
    /** Total number of URLs that were skipped due to include/exclude/subdomain filters. Skipped URLs are included in records but are not counted toward total/finished. */
    skipped: number;
    /** Current crawl job status. */
    status: string;
    /** Total current number of URLs in the crawl job. */
    total: number;
    /** Cursor for pagination. */
    cursor?: number | null;
}
export declare const GetCrawlResponse: S.Schema<GetCrawlResponse>;
export interface GetDevtoolBrowserPageRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID, e.g. page ID. */
    targetId: string;
}
export declare const GetDevtoolBrowserPageRequest: S.Schema<GetDevtoolBrowserPageRequest>;
export interface GetDevtoolBrowserPageResponse {
}
export declare const GetDevtoolBrowserPageResponse: S.Schema<GetDevtoolBrowserPageResponse>;
export interface GetDevtoolBrowserTargetRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** Target ID. */
    targetId: string;
}
export declare const GetDevtoolBrowserTargetRequest: S.Schema<GetDevtoolBrowserTargetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetDevtoolBrowserTargetResponse {
    /** Target ID. */
    id: string;
    /** Target type (page, background_page, worker, etc.). */
    type: string;
    /** URL of the target. */
    url: string;
    /** Target description. */
    description?: string | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Title of the target. */
    title?: string | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export declare const GetDevtoolBrowserTargetResponse: S.Schema<GetDevtoolBrowserTargetResponse>;
export interface GetDevtoolSessionRequest {
    /** Account ID. */
    accountId: string;
    /** Session ID. */
    sessionId: string;
}
export declare const GetDevtoolSessionRequest: S.Schema<GetDevtoolSessionRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetDevtoolSessionResponse {
    /** Session ID. */
    sessionId: string;
    /** Reason for session closure. */
    closeReason?: string | null;
    /** Human-readable close reason. */
    closeReasonText?: string | null;
    /** Connection end time. */
    connectionEndTime?: number | null;
    /** Connection ID. */
    connectionId?: string | null;
    /** Connection start time. */
    connectionStartTime?: number | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Session end time. */
    endTime?: number | null;
    /** Last updated timestamp. */
    lastUpdated?: number | null;
    /** Session start time. */
    startTime?: number | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export declare const GetDevtoolSessionResponse: S.Schema<GetDevtoolSessionResponse>;
export interface LaunchDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Keep-alive time in ms (only valid when acquiring new session). */
    keepAlive?: number;
    /** Use experimental browser. */
    lab?: boolean;
    recording?: boolean;
}
export declare const LaunchDevtoolBrowserRequest: S.Schema<LaunchDevtoolBrowserRequest>;
export interface LaunchDevtoolBrowserResponse {
}
export declare const LaunchDevtoolBrowserResponse: S.Schema<LaunchDevtoolBrowserResponse>;
export interface ListDevtoolBrowserTargetsRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
    /** How long the live view URLs remain valid, in milliseconds (max 60 minutes) */
    liveViewUrlExpiresInMs?: number;
}
export declare const ListDevtoolBrowserTargetsRequest: S.Schema<ListDevtoolBrowserTargetsRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDevtoolBrowserTargetsResponse {
    /** Target ID. */
    id: string;
    /** Target type (page, background_page, worker, etc.). */
    type: string;
    /** URL of the target. */
    url: string;
    /** Target description. */
    description?: string | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Title of the target. */
    title?: string | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export declare const ListDevtoolBrowserTargetsResponse: S.Schema<ListDevtoolBrowserTargetsResponse>;
export interface ListDevtoolSessionsRequest {
    /** Account ID. */
    accountId: string;
    limit?: number;
    offset?: number;
}
export declare const ListDevtoolSessionsRequest: S.Schema<ListDevtoolSessionsRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDevtoolSessionsResponse {
    /** Session ID. */
    sessionId: string;
    /** Reason for session closure. */
    closeReason?: string | null;
    /** Human-readable close reason. */
    closeReasonText?: string | null;
    /** Connection end time. */
    connectionEndTime?: number | null;
    /** Connection ID. */
    connectionId?: string | null;
    /** Connection start time. */
    connectionStartTime?: number | null;
    /** DevTools frontend URL. */
    devtoolsFrontendUrl?: string | null;
    /** Session end time. */
    endTime?: number | null;
    /** Last updated timestamp. */
    lastUpdated?: number | null;
    /** Session start time. */
    startTime?: number | null;
    /** WebSocket URL for debugging this target. */
    webSocketDebuggerUrl?: string | null;
}
export declare const ListDevtoolSessionsResponse: S.Schema<ListDevtoolSessionsResponse>;
export interface ProtocolDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
}
export declare const ProtocolDevtoolBrowserRequest: S.Schema<ProtocolDevtoolBrowserRequest>;
export type DevtoolsBrowserProtocolResponseDomainsItemCommandsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DevtoolsBrowserProtocolResponseDomainsItemCommandsItemMap: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemCommandsItemMap>;
export type DevtoolsBrowserProtocolResponseDomainsItemCommandsList = Array<DevtoolsBrowserProtocolResponseDomainsItemCommandsItemMap>;
export declare const DevtoolsBrowserProtocolResponseDomainsItemCommandsList: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemCommandsList>;
export type DevtoolsBrowserProtocolResponseDomainsItemDependenciesList = Array<string>;
export declare const DevtoolsBrowserProtocolResponseDomainsItemDependenciesList: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemDependenciesList>;
export type DevtoolsBrowserProtocolResponseDomainsItemEventsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DevtoolsBrowserProtocolResponseDomainsItemEventsItemMap: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemEventsItemMap>;
export type DevtoolsBrowserProtocolResponseDomainsItemEventsList = Array<DevtoolsBrowserProtocolResponseDomainsItemEventsItemMap>;
export declare const DevtoolsBrowserProtocolResponseDomainsItemEventsList: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemEventsList>;
export type DevtoolsBrowserProtocolResponseDomainsItemTypesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DevtoolsBrowserProtocolResponseDomainsItemTypesItemMap: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemTypesItemMap>;
export type DevtoolsBrowserProtocolResponseDomainsItemTypesList = Array<DevtoolsBrowserProtocolResponseDomainsItemTypesItemMap>;
export declare const DevtoolsBrowserProtocolResponseDomainsItemTypesList: S.Schema<DevtoolsBrowserProtocolResponseDomainsItemTypesList>;
export interface DevtoolsBrowserProtocolResponseDomainsItem {
    /** Domain name. */
    domain: string;
    /** Available commands. */
    commands?: DevtoolsBrowserProtocolResponseDomainsItemCommandsList | null;
    /** Domain dependencies. */
    dependencies?: DevtoolsBrowserProtocolResponseDomainsItemDependenciesList | null;
    /** Available events. */
    events?: DevtoolsBrowserProtocolResponseDomainsItemEventsList | null;
    /** Whether this domain is experimental. */
    experimental?: boolean | null;
    /** Type definitions. */
    types?: DevtoolsBrowserProtocolResponseDomainsItemTypesList | null;
}
export declare const DevtoolsBrowserProtocolResponseDomainsItem: S.Schema<DevtoolsBrowserProtocolResponseDomainsItem>;
export type DevtoolsBrowserProtocolResponseDomainsList = Array<DevtoolsBrowserProtocolResponseDomainsItem>;
export declare const DevtoolsBrowserProtocolResponseDomainsList: S.Schema<DevtoolsBrowserProtocolResponseDomainsList>;
export interface DevtoolsBrowserProtocolResponseVersion {
    /** Major version. */
    major: string;
    /** Minor version. */
    minor: string;
}
export declare const DevtoolsBrowserProtocolResponseVersion: S.Schema<DevtoolsBrowserProtocolResponseVersion>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ProtocolDevtoolBrowserResponse {
    /** List of protocol domains. */
    domains: DevtoolsBrowserProtocolResponseDomainsList;
    /** Protocol version. */
    version?: DevtoolsBrowserProtocolResponseVersion | null;
}
export declare const ProtocolDevtoolBrowserResponse: S.Schema<ProtocolDevtoolBrowserResponse>;
export interface VersionDevtoolBrowserRequest {
    /** Account ID. */
    accountId: string;
    /** Browser session ID. */
    sessionId: string;
}
export declare const VersionDevtoolBrowserRequest: S.Schema<VersionDevtoolBrowserRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface VersionDevtoolBrowserResponse {
    /** Browser name and version. */
    browser: string;
    /** Chrome DevTools Protocol version. */
    protocolVersion: string;
    /** User agent string. */
    userAgent: string;
    /** V8 JavaScript engine version. */
    v8Version: string;
    /** WebKit version. */
    webKitVersion: string;
    /** WebSocket URL for debugging the browser. */
    webSocketDebuggerUrl: string;
}
export declare const VersionDevtoolBrowserResponse: S.Schema<VersionDevtoolBrowserResponse>;
export type ActivateDevtoolBrowserTargetError = CloudflareOpError;
/** Activates (brings to front) a specific browser target by its ID. */
export declare const activateDevtoolBrowserTarget: API.OperationMethod<ActivateDevtoolBrowserTargetRequest, ActivateDevtoolBrowserTargetResponse, ActivateDevtoolBrowserTargetError, CloudflareOpContext>;
export type CloseDevtoolBrowserTargetError = CloudflareOpError;
/** Closes a specific browser target (tab, page, etc.) by its ID. Returns 'Target is closing' on success or an error if the target is not found. */
export declare const closeDevtoolBrowserTarget: API.OperationMethod<CloseDevtoolBrowserTargetRequest, CloseDevtoolBrowserTargetResponse, CloseDevtoolBrowserTargetError, CloudflareOpContext>;
export type ConnectDevtoolBrowserError = CloudflareOpError;
/** Establishes a WebSocket connection to an existing browser session. */
export declare const connectDevtoolBrowser: API.OperationMethod<ConnectDevtoolBrowserRequest, ConnectDevtoolBrowserResponse, ConnectDevtoolBrowserError, CloudflareOpContext>;
export type CreateContentError = CloudflareOpError;
/** Fetches rendered HTML content from provided URL or HTML. Check available options like `gotoOptions` and `waitFor*` to control page load behaviour. */
export declare const createContent: API.OperationMethod<CreateContentRequest, CreateContentResponse, CreateContentError, CloudflareOpContext>;
export type CreateCrawlError = CloudflareOpError;
/** Starts a crawl job for the provided URL and its children. Check available options like `gotoOptions` and `waitFor*` to control page load behaviour. */
export declare const createCrawl: API.OperationMethod<CreateCrawlRequest, CreateCrawlResponse, CreateCrawlError, CloudflareOpContext>;
export type CreateDevtoolBrowserError = CloudflareOpError;
/** Acquires a browser and returns its session ID and websocket URL. */
export declare const createDevtoolBrowser: API.OperationMethod<CreateDevtoolBrowserRequest, CreateDevtoolBrowserResponse, CreateDevtoolBrowserError, CloudflareOpContext>;
export type CreateDevtoolBrowserTargetError = CloudflareOpError;
/** Opens a new tab in the browser. Optionally specify a URL to navigate to. */
export declare const createDevtoolBrowserTarget: API.OperationMethod<CreateDevtoolBrowserTargetRequest, CreateDevtoolBrowserTargetResponse, CreateDevtoolBrowserTargetError, CloudflareOpContext>;
export type CreateJsonError = CloudflareOpError;
/** Gets json from a webpage from a provided URL or HTML. Pass `prompt` or `schema` in the body. Control page loading with `gotoOptions` and `waitFor*` options. */
export declare const createJson: API.OperationMethod<CreateJsonRequest, CreateJsonResponse, CreateJsonError, CloudflareOpContext>;
export type CreateLinkError = CloudflareOpError;
/** Get links from a web page. */
export declare const createLink: API.OperationMethod<CreateLinkRequest, CreateLinkResponse, CreateLinkError, CloudflareOpContext>;
export type CreateMarkdownError = CloudflareOpError;
/** Gets markdown of a webpage from provided URL or HTML. Control page loading with `gotoOptions` and `waitFor*` options. */
export declare const createMarkdown: API.OperationMethod<CreateMarkdownRequest, CreateMarkdownResponse, CreateMarkdownError, CloudflareOpContext>;
export type CreatePdfError = CloudflareOpError;
/** Fetches rendered PDF from provided URL or HTML. Check available options like `gotoOptions` and `waitFor*` to control page load behaviour. */
export declare const createPdf: API.OperationMethod<CreatePdfRequest, CreatePdfResponse, CreatePdfError, CloudflareOpContext>;
export type CreateScrapeError = CloudflareOpError;
/** Get meta attributes like height, width, text and others of selected elements. */
export declare const createScrape: API.OperationMethod<CreateScrapeRequest, CreateScrapeResponse, CreateScrapeError, CloudflareOpContext>;
export type CreateScreenshotError = CloudflareOpError;
/** Takes a screenshot of a webpage from provided URL or HTML. Control page loading with `gotoOptions` and `waitFor*` options. Customize screenshots with `viewport`, `fullPage`, `clip` and others. */
export declare const createScreenshot: API.OperationMethod<CreateScreenshotRequest, CreateScreenshotResponse, CreateScreenshotError, CloudflareOpContext>;
export type CreateSnapshotError = CloudflareOpError;
/** Returns the page's HTML content and screenshot. Control page loading with `gotoOptions` and `waitFor*` options. Customize screenshots with `viewport`, `fullPage`, `clip` and others. */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest, CreateSnapshotResponse, CreateSnapshotError, CloudflareOpContext>;
export type DeleteCrawlError = CloudflareOpError;
/** Cancels an ongoing crawl job by setting its status to cancelled and stopping all queued URLs. */
export declare const deleteCrawl: API.OperationMethod<DeleteCrawlRequest, DeleteCrawlResponse, DeleteCrawlError, CloudflareOpContext>;
export type DeleteDevtoolBrowserError = CloudflareOpError;
/** Closes an existing browser session. */
export declare const deleteDevtoolBrowser: API.OperationMethod<DeleteDevtoolBrowserRequest, DeleteDevtoolBrowserResponse, DeleteDevtoolBrowserError, CloudflareOpContext>;
export type GetCrawlError = CloudflareOpError;
/** Returns the result of a crawl job. */
export declare const getCrawl: API.OperationMethod<GetCrawlRequest, GetCrawlResponse, GetCrawlError, CloudflareOpContext>;
export type GetDevtoolBrowserPageError = CloudflareOpError;
/** Establishes a WebSocket connection to a specific Chrome DevTools target or page. */
export declare const getDevtoolBrowserPage: API.OperationMethod<GetDevtoolBrowserPageRequest, GetDevtoolBrowserPageResponse, GetDevtoolBrowserPageError, CloudflareOpContext>;
export type GetDevtoolBrowserTargetError = CloudflareOpError;
/** Returns the debuggable target with the given ID. */
export declare const getDevtoolBrowserTarget: API.OperationMethod<GetDevtoolBrowserTargetRequest, GetDevtoolBrowserTargetResponse, GetDevtoolBrowserTargetError, CloudflareOpContext>;
export type GetDevtoolSessionError = CloudflareOpError;
/** Get details for a specific browser session. */
export declare const getDevtoolSession: API.OperationMethod<GetDevtoolSessionRequest, GetDevtoolSessionResponse, GetDevtoolSessionError, CloudflareOpContext>;
export type LaunchDevtoolBrowserError = CloudflareOpError;
/** Acquires and establishes a WebSocket connection to a browser session. */
export declare const launchDevtoolBrowser: API.OperationMethod<LaunchDevtoolBrowserRequest, LaunchDevtoolBrowserResponse, LaunchDevtoolBrowserError, CloudflareOpContext>;
export type ListDevtoolBrowserTargetsError = CloudflareOpError;
/** Returns a list of all debuggable targets including tabs, pages, service workers, and other browser contexts. */
export declare const listDevtoolBrowserTargets: API.OperationMethod<ListDevtoolBrowserTargetsRequest, ListDevtoolBrowserTargetsResponse, ListDevtoolBrowserTargetsError, CloudflareOpContext>;
export type ListDevtoolSessionsError = CloudflareOpError;
/** List active browser sessions. */
export declare const listDevtoolSessions: API.OperationMethod<ListDevtoolSessionsRequest, ListDevtoolSessionsResponse, ListDevtoolSessionsError, CloudflareOpContext>;
export type ProtocolDevtoolBrowserError = CloudflareOpError;
/** Returns the complete Chrome DevTools Protocol schema including all domains, commands, events, and types. This schema describes the entire CDP API surface. */
export declare const protocolDevtoolBrowser: API.OperationMethod<ProtocolDevtoolBrowserRequest, ProtocolDevtoolBrowserResponse, ProtocolDevtoolBrowserError, CloudflareOpContext>;
export type VersionDevtoolBrowserError = CloudflareOpError;
/** Get browser version metadata. */
export declare const versionDevtoolBrowser: API.OperationMethod<VersionDevtoolBrowserRequest, VersionDevtoolBrowserResponse, VersionDevtoolBrowserError, CloudflareOpContext>;
//# sourceMappingURL=browser_rendering.d.ts.map