import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LoadBalancerNotFound_base: S.Class<LoadBalancerNotFound, S.TaggedStruct<"LoadBalancerNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LoadBalancerNotFound extends /*@__PURE__*/ LoadBalancerNotFound_base {
}
declare const LoadBalancingNotEnabledForZone_base: S.Class<LoadBalancingNotEnabledForZone, S.TaggedStruct<"LoadBalancingNotEnabledForZone", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LoadBalancingNotEnabledForZone extends /*@__PURE__*/ LoadBalancingNotEnabledForZone_base {
}
declare const MonitorGroupInUse_base: S.Class<MonitorGroupInUse, S.TaggedStruct<"MonitorGroupInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MonitorGroupInUse extends /*@__PURE__*/ MonitorGroupInUse_base {
}
declare const MonitorGroupNotFound_base: S.Class<MonitorGroupNotFound, S.TaggedStruct<"MonitorGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MonitorGroupNotFound extends /*@__PURE__*/ MonitorGroupNotFound_base {
}
declare const MonitorGroupsNotEnabled_base: S.Class<MonitorGroupsNotEnabled, S.TaggedStruct<"MonitorGroupsNotEnabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MonitorGroupsNotEnabled extends /*@__PURE__*/ MonitorGroupsNotEnabled_base {
}
declare const MonitorIntervalOutOfRange_base: S.Class<MonitorIntervalOutOfRange, S.TaggedStruct<"MonitorIntervalOutOfRange", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MonitorIntervalOutOfRange extends /*@__PURE__*/ MonitorIntervalOutOfRange_base {
}
declare const MonitorInUse_base: S.Class<MonitorInUse, S.TaggedStruct<"MonitorInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MonitorInUse extends /*@__PURE__*/ MonitorInUse_base {
}
declare const MonitorNotFound_base: S.Class<MonitorNotFound, S.TaggedStruct<"MonitorNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MonitorNotFound extends /*@__PURE__*/ MonitorNotFound_base {
}
declare const PoolAccessFailed_base: S.Class<PoolAccessFailed, S.TaggedStruct<"PoolAccessFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PoolAccessFailed extends /*@__PURE__*/ PoolAccessFailed_base {
}
declare const PoolInUse_base: S.Class<PoolInUse, S.TaggedStruct<"PoolInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PoolInUse extends /*@__PURE__*/ PoolInUse_base {
}
declare const PoolNotFound_base: S.Class<PoolNotFound, S.TaggedStruct<"PoolNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PoolNotFound extends /*@__PURE__*/ PoolNotFound_base {
}
export type PoolsBulkEditRequestNotificationEmail = "";
export declare const PoolsBulkEditRequestNotificationEmail: any;
export interface BulkPatchPoolsRequest {
    /** Identifier. */
    accountId: string;
    /** The email address to send health status notifications to. This field is now deprecated in favor of Cloudflare Notifications for Load Balancing, so only resetting this field with an empty string `""` is accepted. */
    notificationEmail?: PoolsBulkEditRequestNotificationEmail | (string & {});
}
export declare const BulkPatchPoolsRequest: S.Schema<BulkPatchPoolsRequest>;
export type PoolsBulkEditResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsBulkEditResultItemCheckRegionsItem: any;
export type PoolsBulkEditResultItemCheckRegionsList = Array<PoolsBulkEditResultItemCheckRegionsItem>;
export declare const PoolsBulkEditResultItemCheckRegionsList: S.Schema<PoolsBulkEditResultItemCheckRegionsList>;
export type PoolsBulkEditResultItemLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsBulkEditResultItemLoadSheddingDefaultPolicy: any;
export type PoolsBulkEditResultItemLoadSheddingSessionPolicy = "hash";
export declare const PoolsBulkEditResultItemLoadSheddingSessionPolicy: any;
export interface PoolsBulkEditResultItemLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsBulkEditResultItemLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsBulkEditResultItemLoadSheddingSessionPolicy | null;
}
export declare const PoolsBulkEditResultItemLoadShedding: S.Schema<PoolsBulkEditResultItemLoadShedding>;
export type PoolsBulkEditResultItemNetworksList = Array<string>;
export declare const PoolsBulkEditResultItemNetworksList: S.Schema<PoolsBulkEditResultItemNetworksList>;
export interface PoolsBulkEditResultItemNotificationFilterOrigin {
    /** If set true, disable notifications for this type of resource (pool or origin). */
    disable?: boolean | null;
    /** If present, send notifications only for this health status (e.g. false for only DOWN events). Use null to reset (all events). */
    healthy?: boolean | null;
}
export declare const PoolsBulkEditResultItemNotificationFilterOrigin: S.Schema<PoolsBulkEditResultItemNotificationFilterOrigin>;
export interface PoolsBulkEditResultItemNotificationFilter {
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    origin?: PoolsBulkEditResultItemNotificationFilterOrigin | null;
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    pool?: PoolsBulkEditResultItemNotificationFilterOrigin | null;
}
export declare const PoolsBulkEditResultItemNotificationFilter: S.Schema<PoolsBulkEditResultItemNotificationFilter>;
export type PoolsBulkEditResultItemOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsBulkEditResultItemOriginSteeringPolicy: any;
export interface PoolsBulkEditResultItemOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsBulkEditResultItemOriginSteeringPolicy | null;
}
export declare const PoolsBulkEditResultItemOriginSteering: S.Schema<PoolsBulkEditResultItemOriginSteering>;
export type PoolsBulkEditResultItemOriginsItemHeaderHostList = Array<string>;
export declare const PoolsBulkEditResultItemOriginsItemHeaderHostList: S.Schema<PoolsBulkEditResultItemOriginsItemHeaderHostList>;
export interface PoolsBulkEditResultItemOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsBulkEditResultItemOriginsItemHeaderHostList | null;
}
export declare const PoolsBulkEditResultItemOriginsItemHeader: S.Schema<PoolsBulkEditResultItemOriginsItemHeader>;
export interface PoolsBulkEditResultItemOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsBulkEditResultItemOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export declare const PoolsBulkEditResultItemOriginsItem: S.Schema<PoolsBulkEditResultItemOriginsItem>;
export type PoolsBulkEditResultItemOriginsList = Array<PoolsBulkEditResultItemOriginsItem>;
export declare const PoolsBulkEditResultItemOriginsList: S.Schema<PoolsBulkEditResultItemOriginsList>;
export interface PoolsBulkEditResultItem {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsBulkEditResultItemCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsBulkEditResultItemLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsBulkEditResultItemNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsBulkEditResultItemOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsBulkEditResultItemOriginsList | null;
}
export declare const PoolsBulkEditResultItem: S.Schema<PoolsBulkEditResultItem>;
export type PoolsBulkEditResultList = Array<PoolsBulkEditResultItem>;
export declare const PoolsBulkEditResultList: S.Schema<PoolsBulkEditResultList>;
export interface BulkPatchPoolsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoolsBulkEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkPatchPoolsResponse: S.Schema<BulkPatchPoolsResponse>;
export type CreateRequestDefaultPoolsList = Array<string>;
export declare const CreateRequestDefaultPoolsList: S.Schema<CreateRequestDefaultPoolsList>;
export interface CreateRequestAdaptiveRouting {
    /** Extends zero-downtime failover of requests to healthy origins from alternate pools, when no healthy alternate exists in the same pool, according to the failover order defined by traffic and origin steering. When set false (the default) zero-downtime failover will only occur between origins within the same pool. See `session_affinity_attributes` for control over when sessions are broken or reassigned. */
    failoverAcrossPools?: boolean;
}
export declare const CreateRequestAdaptiveRouting: S.Schema<CreateRequestAdaptiveRouting>;
export type CreateRequestCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRequestCountryPoolsMap: S.Schema<CreateRequestCountryPoolsMap>;
export type CreateRequestLocationStrategyMode = "pop" | "resolver_ip";
export declare const CreateRequestLocationStrategyMode: any;
export type CreateRequestLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const CreateRequestLocationStrategyPreferEcs: any;
export interface CreateRequestLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: CreateRequestLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: CreateRequestLocationStrategyPreferEcs | (string & {});
}
export declare const CreateRequestLocationStrategy: S.Schema<CreateRequestLocationStrategy>;
export type CreateRequestNetworksList = Array<string>;
export declare const CreateRequestNetworksList: S.Schema<CreateRequestNetworksList>;
export type CreateRequestPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRequestPopPoolsMap: S.Schema<CreateRequestPopPoolsMap>;
export type CreateRequestRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const CreateRequestRandomSteeringPoolWeightsMap: S.Schema<CreateRequestRandomSteeringPoolWeightsMap>;
export interface CreateRequestRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: CreateRequestRandomSteeringPoolWeightsMap;
}
export declare const CreateRequestRandomSteering: S.Schema<CreateRequestRandomSteering>;
export type CreateRequestRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRequestRegionPoolsMap: S.Schema<CreateRequestRegionPoolsMap>;
export interface CreateRequestRulesItemFixedResponse {
    /** The http 'Content-Type' header to include in the response. */
    contentType?: string;
    /** The http 'Location' header to include in the response. */
    location?: string;
    /** Text to include as the http body. */
    messageBody?: string;
    /** The http status code to respond with. */
    statusCode?: number;
}
export declare const CreateRequestRulesItemFixedResponse: S.Schema<CreateRequestRulesItemFixedResponse>;
export type CreateRequestRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRequestRulesItemOverridesCountryPoolsMap: S.Schema<CreateRequestRulesItemOverridesCountryPoolsMap>;
export type CreateRequestRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const CreateRequestRulesItemOverridesDefaultPoolsList: S.Schema<CreateRequestRulesItemOverridesDefaultPoolsList>;
export type CreateRequestRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRequestRulesItemOverridesPopPoolsMap: S.Schema<CreateRequestRulesItemOverridesPopPoolsMap>;
export type CreateRequestRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRequestRulesItemOverridesRegionPoolsMap: S.Schema<CreateRequestRulesItemOverridesRegionPoolsMap>;
export type CreateRequestRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const CreateRequestRulesItemOverridesSessionAffinity: any;
export type CreateRequestRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const CreateRequestRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<CreateRequestRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type CreateRequestRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const CreateRequestRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type CreateRequestRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const CreateRequestRulesItemOverridesSessionAffinityAttributesSecure: any;
export type CreateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const CreateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface CreateRequestRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: CreateRequestRulesItemOverridesSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: CreateRequestRulesItemOverridesSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: CreateRequestRulesItemOverridesSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: CreateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export declare const CreateRequestRulesItemOverridesSessionAffinityAttributes: S.Schema<CreateRequestRulesItemOverridesSessionAffinityAttributes>;
export type CreateRequestRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const CreateRequestRulesItemOverridesSteeringPolicy: any;
export interface CreateRequestRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateRequestRulesItemOverridesCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: CreateRequestRulesItemOverridesDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateRequestLocationStrategy;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateRequestRulesItemOverridesPopPoolsMap;
    /** Configures pool weights. */
    randomSteering?: CreateRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateRequestRulesItemOverridesRegionPoolsMap;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export declare const CreateRequestRulesItemOverrides: S.Schema<CreateRequestRulesItemOverrides>;
export interface CreateRequestRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateRequestRulesItemFixedResponse;
    /** Name of this rule. Only used for human readability. */
    name?: string;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: CreateRequestRulesItemOverrides;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean;
}
export declare const CreateRequestRulesItem: S.Schema<CreateRequestRulesItem>;
export type CreateRequestRulesList = Array<CreateRequestRulesItem>;
export declare const CreateRequestRulesList: S.Schema<CreateRequestRulesList>;
export interface CreateLoadBalancerRequest {
    zoneId: string;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools: CreateRequestDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool: string;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name: string;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateRequestCountryPoolsMap;
    /** Object description. */
    description?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateRequestLocationStrategy;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: CreateRequestNetworksList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateRequestPopPoolsMap;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean;
    /** Configures pool weights. */
    randomSteering?: CreateRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateRequestRegionPoolsMap;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: CreateRequestRulesList;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export declare const CreateLoadBalancerRequest: S.Schema<CreateLoadBalancerRequest>;
export interface CreateResponseAdaptiveRouting {
    /** Extends zero-downtime failover of requests to healthy origins from alternate pools, when no healthy alternate exists in the same pool, according to the failover order defined by traffic and origin steering. When set false (the default) zero-downtime failover will only occur between origins within the same pool. See `session_affinity_attributes` for control over when sessions are broken or reassigned. */
    failoverAcrossPools?: boolean | null;
}
export declare const CreateResponseAdaptiveRouting: S.Schema<CreateResponseAdaptiveRouting>;
export type CreateResponseCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponseCountryPoolsMap: S.Schema<CreateResponseCountryPoolsMap>;
export type CreateResponseDefaultPoolsList = Array<string>;
export declare const CreateResponseDefaultPoolsList: S.Schema<CreateResponseDefaultPoolsList>;
export type CreateResponseLocationStrategyMode = "pop" | "resolver_ip";
export declare const CreateResponseLocationStrategyMode: any;
export type CreateResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const CreateResponseLocationStrategyPreferEcs: any;
export interface CreateResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: CreateResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: CreateResponseLocationStrategyPreferEcs | null;
}
export declare const CreateResponseLocationStrategy: S.Schema<CreateResponseLocationStrategy>;
export type CreateResponseNetworksList = Array<string>;
export declare const CreateResponseNetworksList: S.Schema<CreateResponseNetworksList>;
export type CreateResponsePopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponsePopPoolsMap: S.Schema<CreateResponsePopPoolsMap>;
export type CreateResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const CreateResponseRandomSteeringPoolWeightsMap: S.Schema<CreateResponseRandomSteeringPoolWeightsMap>;
export interface CreateResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: CreateResponseRandomSteeringPoolWeightsMap | null;
}
export declare const CreateResponseRandomSteering: S.Schema<CreateResponseRandomSteering>;
export type CreateResponseRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponseRegionPoolsMap: S.Schema<CreateResponseRegionPoolsMap>;
export interface CreateResponseRulesItemFixedResponse {
    /** The http 'Content-Type' header to include in the response. */
    contentType?: string | null;
    /** The http 'Location' header to include in the response. */
    location?: string | null;
    /** Text to include as the http body. */
    messageBody?: string | null;
    /** The http status code to respond with. */
    statusCode?: number | null;
}
export declare const CreateResponseRulesItemFixedResponse: S.Schema<CreateResponseRulesItemFixedResponse>;
export type CreateResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponseRulesItemOverridesCountryPoolsMap: S.Schema<CreateResponseRulesItemOverridesCountryPoolsMap>;
export type CreateResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const CreateResponseRulesItemOverridesDefaultPoolsList: S.Schema<CreateResponseRulesItemOverridesDefaultPoolsList>;
export type CreateResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponseRulesItemOverridesPopPoolsMap: S.Schema<CreateResponseRulesItemOverridesPopPoolsMap>;
export type CreateResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponseRulesItemOverridesRegionPoolsMap: S.Schema<CreateResponseRulesItemOverridesRegionPoolsMap>;
export type CreateResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const CreateResponseRulesItemOverridesSessionAffinity: any;
export type CreateResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const CreateResponseRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<CreateResponseRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type CreateResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const CreateResponseRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type CreateResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const CreateResponseRulesItemOverridesSessionAffinityAttributesSecure: any;
export type CreateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const CreateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface CreateResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: CreateResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: CreateResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: CreateResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: CreateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export declare const CreateResponseRulesItemOverridesSessionAffinityAttributes: S.Schema<CreateResponseRulesItemOverridesSessionAffinityAttributes>;
export type CreateResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const CreateResponseRulesItemOverridesSteeringPolicy: any;
export interface CreateResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: CreateResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateResponseLocationStrategy | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: CreateResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export declare const CreateResponseRulesItemOverrides: S.Schema<CreateResponseRulesItemOverrides>;
export interface CreateResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateResponseRulesItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: CreateResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export declare const CreateResponseRulesItem: S.Schema<CreateResponseRulesItem>;
export type CreateResponseRulesList = Array<CreateResponseRulesItem>;
export declare const CreateResponseRulesList: S.Schema<CreateResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: CreateResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: CreateResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: CreateResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: CreateResponseNetworksList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: CreateResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: CreateResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: CreateResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: CreateResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: CreateResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: CreateResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: CreateResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export declare const CreateLoadBalancerResponse: S.Schema<CreateLoadBalancerResponse>;
export type MonitorsCreateRequestHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsCreateRequestHeaderMap: S.Schema<MonitorsCreateRequestHeaderMap>;
export type MonitorsCreateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsCreateRequestType: any;
export interface CreateMonitorRequest {
    /** Identifier. */
    accountId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsCreateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsCreateRequestType | (string & {});
}
export declare const CreateMonitorRequest: S.Schema<CreateMonitorRequest>;
export type MonitorsCreateResponseHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsCreateResponseHeaderMap: S.Schema<MonitorsCreateResponseHeaderMap>;
export type MonitorsCreateResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsCreateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsCreateResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsCreateResponseType | null;
}
export declare const CreateMonitorResponse: S.Schema<CreateMonitorResponse>;
export interface MonitorGroupsCreateRequestMembersItem {
    /** Whether this monitor is enabled in the group */
    enabled: boolean;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitorId: string;
    /** Whether this monitor is used for monitoring only (does not affect pool health) */
    monitoringOnly: boolean;
    /** Whether this monitor must be healthy for the pool to be considered healthy */
    mustBeHealthy: boolean;
    /** The timestamp of when the monitor was added to the group */
    createdAt?: string;
    /** The timestamp of when the monitor group member was last updated */
    updatedAt?: string;
}
export declare const MonitorGroupsCreateRequestMembersItem: S.Schema<MonitorGroupsCreateRequestMembersItem>;
export type MonitorGroupsCreateRequestMembersList = Array<MonitorGroupsCreateRequestMembersItem>;
export declare const MonitorGroupsCreateRequestMembersList: S.Schema<MonitorGroupsCreateRequestMembersList>;
export interface CreateMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsCreateRequestMembersList;
}
export declare const CreateMonitorGroupRequest: S.Schema<CreateMonitorGroupRequest>;
export interface MonitorGroupsCreateResponseMembersItem {
    /** Whether this monitor is enabled in the group */
    enabled: boolean;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitorId: string;
    /** Whether this monitor is used for monitoring only (does not affect pool health) */
    monitoringOnly: boolean;
    /** Whether this monitor must be healthy for the pool to be considered healthy */
    mustBeHealthy: boolean;
    /** The timestamp of when the monitor was added to the group */
    createdAt?: string | null;
    /** The timestamp of when the monitor group member was last updated */
    updatedAt?: string | null;
}
export declare const MonitorGroupsCreateResponseMembersItem: S.Schema<MonitorGroupsCreateResponseMembersItem>;
export type MonitorGroupsCreateResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export declare const MonitorGroupsCreateResponseMembersList: S.Schema<MonitorGroupsCreateResponseMembersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsCreateResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export declare const CreateMonitorGroupResponse: S.Schema<CreateMonitorGroupResponse>;
export type MonitorsPreviewsCreateRequestHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsPreviewsCreateRequestHeaderMap: S.Schema<MonitorsPreviewsCreateRequestHeaderMap>;
export type MonitorsPreviewsCreateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsPreviewsCreateRequestType: any;
export interface CreateMonitorPreviewRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsPreviewsCreateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsPreviewsCreateRequestType | (string & {});
}
export declare const CreateMonitorPreviewRequest: S.Schema<CreateMonitorPreviewRequest>;
export type MonitorsPreviewsCreateResponsePoolsMap = {
    [key: string]: string | undefined;
};
export declare const MonitorsPreviewsCreateResponsePoolsMap: S.Schema<MonitorsPreviewsCreateResponsePoolsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMonitorPreviewResponse {
    /** Monitored pool IDs mapped to their respective names. */
    pools?: MonitorsPreviewsCreateResponsePoolsMap | null;
    previewId?: string | null;
}
export declare const CreateMonitorPreviewResponse: S.Schema<CreateMonitorPreviewResponse>;
export type PoolsCreateRequestOriginsItemHeaderHostList = Array<string>;
export declare const PoolsCreateRequestOriginsItemHeaderHostList: S.Schema<PoolsCreateRequestOriginsItemHeaderHostList>;
export interface PoolsCreateRequestOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsCreateRequestOriginsItemHeaderHostList;
}
export declare const PoolsCreateRequestOriginsItemHeader: S.Schema<PoolsCreateRequestOriginsItemHeader>;
export interface PoolsCreateRequestOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsCreateRequestOriginsItemHeader;
    /** A human-identifiable name for the origin. */
    name?: string;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number;
}
export declare const PoolsCreateRequestOriginsItem: S.Schema<PoolsCreateRequestOriginsItem>;
export type PoolsCreateRequestOriginsList = Array<PoolsCreateRequestOriginsItem>;
export declare const PoolsCreateRequestOriginsList: S.Schema<PoolsCreateRequestOriginsList>;
export type PoolsCreateRequestLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsCreateRequestLoadSheddingDefaultPolicy: any;
export type PoolsCreateRequestLoadSheddingSessionPolicy = "hash";
export declare const PoolsCreateRequestLoadSheddingSessionPolicy: any;
export interface PoolsCreateRequestLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsCreateRequestLoadSheddingDefaultPolicy | (string & {});
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsCreateRequestLoadSheddingSessionPolicy | (string & {});
}
export declare const PoolsCreateRequestLoadShedding: S.Schema<PoolsCreateRequestLoadShedding>;
export interface PoolsCreateRequestNotificationFilterOrigin {
    /** If set true, disable notifications for this type of resource (pool or origin). */
    disable?: boolean;
    /** If present, send notifications only for this health status (e.g. false for only DOWN events). Use null to reset (all events). */
    healthy?: boolean;
}
export declare const PoolsCreateRequestNotificationFilterOrigin: S.Schema<PoolsCreateRequestNotificationFilterOrigin>;
export interface PoolsCreateRequestNotificationFilter {
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    origin?: PoolsCreateRequestNotificationFilterOrigin;
    /** Filter options for a particular resource type (pool or origin). Use null to reset. */
    pool?: PoolsCreateRequestNotificationFilterOrigin;
}
export declare const PoolsCreateRequestNotificationFilter: S.Schema<PoolsCreateRequestNotificationFilter>;
export type PoolsCreateRequestOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsCreateRequestOriginSteeringPolicy: any;
export interface PoolsCreateRequestOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsCreateRequestOriginSteeringPolicy | (string & {});
}
export declare const PoolsCreateRequestOriginSteering: S.Schema<PoolsCreateRequestOriginSteering>;
export interface CreatePoolRequest {
    /** Identifier. */
    accountId: string;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name: string;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins: PoolsCreateRequestOriginsList;
    /** A human-readable description of the pool. */
    description?: string;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsCreateRequestLoadShedding;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsCreateRequestNotificationFilter;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsCreateRequestOriginSteering;
}
export declare const CreatePoolRequest: S.Schema<CreatePoolRequest>;
export type PoolsCreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsCreateResponseCheckRegionsItem: any;
export type PoolsCreateResponseCheckRegionsList = Array<PoolsCreateResponseCheckRegionsItem>;
export declare const PoolsCreateResponseCheckRegionsList: S.Schema<PoolsCreateResponseCheckRegionsList>;
export type PoolsCreateResponseLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsCreateResponseLoadSheddingDefaultPolicy: any;
export type PoolsCreateResponseLoadSheddingSessionPolicy = "hash";
export declare const PoolsCreateResponseLoadSheddingSessionPolicy: any;
export interface PoolsCreateResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsCreateResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsCreateResponseLoadSheddingSessionPolicy | null;
}
export declare const PoolsCreateResponseLoadShedding: S.Schema<PoolsCreateResponseLoadShedding>;
export type PoolsCreateResponseNetworksList = Array<string>;
export declare const PoolsCreateResponseNetworksList: S.Schema<PoolsCreateResponseNetworksList>;
export type PoolsCreateResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export declare const PoolsCreateResponseNotificationFilterOrigin: S.Schema<PoolsBulkEditResultItemNotificationFilterOrigin>;
export type PoolsCreateResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export declare const PoolsCreateResponseNotificationFilter: S.Schema<PoolsBulkEditResultItemNotificationFilter>;
export type PoolsCreateResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsCreateResponseOriginSteeringPolicy: any;
export interface PoolsCreateResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsCreateResponseOriginSteeringPolicy | null;
}
export declare const PoolsCreateResponseOriginSteering: S.Schema<PoolsCreateResponseOriginSteering>;
export type PoolsCreateResponseOriginsItemHeaderHostList = Array<string>;
export declare const PoolsCreateResponseOriginsItemHeaderHostList: S.Schema<PoolsCreateResponseOriginsItemHeaderHostList>;
export interface PoolsCreateResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsCreateResponseOriginsItemHeaderHostList | null;
}
export declare const PoolsCreateResponseOriginsItemHeader: S.Schema<PoolsCreateResponseOriginsItemHeader>;
export interface PoolsCreateResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsCreateResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export declare const PoolsCreateResponseOriginsItem: S.Schema<PoolsCreateResponseOriginsItem>;
export type PoolsCreateResponseOriginsList = Array<PoolsCreateResponseOriginsItem>;
export declare const PoolsCreateResponseOriginsList: S.Schema<PoolsCreateResponseOriginsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsCreateResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsCreateResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsCreateResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsCreateResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsCreateResponseOriginsList | null;
}
export declare const CreatePoolResponse: S.Schema<CreatePoolResponse>;
export type PoolsHealthCreateRequestHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const PoolsHealthCreateRequestHeaderMap: S.Schema<PoolsHealthCreateRequestHeaderMap>;
export type PoolsHealthCreateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const PoolsHealthCreateRequestType: any;
export interface CreatePoolHealthRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: PoolsHealthCreateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: PoolsHealthCreateRequestType | (string & {});
}
export declare const CreatePoolHealthRequest: S.Schema<CreatePoolHealthRequest>;
export type PoolsHealthCreateResponsePoolsMap = {
    [key: string]: string | undefined;
};
export declare const PoolsHealthCreateResponsePoolsMap: S.Schema<PoolsHealthCreateResponsePoolsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePoolHealthResponse {
    /** Monitored pool IDs mapped to their respective names. */
    pools?: PoolsHealthCreateResponsePoolsMap | null;
    previewId?: string | null;
}
export declare const CreatePoolHealthResponse: S.Schema<CreatePoolHealthResponse>;
export interface DeleteLoadBalancerRequest {
    zoneId: string;
    loadBalancerId: string;
}
export declare const DeleteLoadBalancerRequest: S.Schema<DeleteLoadBalancerRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteLoadBalancerResponse {
    id?: string | null;
}
export declare const DeleteLoadBalancerResponse: S.Schema<DeleteLoadBalancerResponse>;
export interface DeleteMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
}
export declare const DeleteMonitorRequest: S.Schema<DeleteMonitorRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMonitorResponse {
    id?: string | null;
}
export declare const DeleteMonitorResponse: S.Schema<DeleteMonitorResponse>;
export interface DeleteMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
}
export declare const DeleteMonitorGroupRequest: S.Schema<DeleteMonitorGroupRequest>;
export type MonitorGroupsDeleteResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export declare const MonitorGroupsDeleteResponseMembersItem: S.Schema<MonitorGroupsCreateResponseMembersItem>;
export type MonitorGroupsDeleteResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export declare const MonitorGroupsDeleteResponseMembersList: S.Schema<MonitorGroupsDeleteResponseMembersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsDeleteResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export declare const DeleteMonitorGroupResponse: S.Schema<DeleteMonitorGroupResponse>;
export interface DeletePoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export declare const DeletePoolRequest: S.Schema<DeletePoolRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePoolResponse {
    id?: string | null;
}
export declare const DeletePoolResponse: S.Schema<DeletePoolResponse>;
export interface GetLoadBalancerRequest {
    zoneId: string;
    loadBalancerId: string;
}
export declare const GetLoadBalancerRequest: S.Schema<GetLoadBalancerRequest>;
export type GetResponseAdaptiveRouting = CreateResponseAdaptiveRouting;
export declare const GetResponseAdaptiveRouting: S.Schema<CreateResponseAdaptiveRouting>;
export type GetResponseCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponseCountryPoolsMap: S.Schema<GetResponseCountryPoolsMap>;
export type GetResponseDefaultPoolsList = Array<string>;
export declare const GetResponseDefaultPoolsList: S.Schema<GetResponseDefaultPoolsList>;
export type GetResponseLocationStrategyMode = "pop" | "resolver_ip";
export declare const GetResponseLocationStrategyMode: any;
export type GetResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const GetResponseLocationStrategyPreferEcs: any;
export interface GetResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: GetResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: GetResponseLocationStrategyPreferEcs | null;
}
export declare const GetResponseLocationStrategy: S.Schema<GetResponseLocationStrategy>;
export type GetResponseNetworksList = Array<string>;
export declare const GetResponseNetworksList: S.Schema<GetResponseNetworksList>;
export type GetResponsePopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponsePopPoolsMap: S.Schema<GetResponsePopPoolsMap>;
export type GetResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const GetResponseRandomSteeringPoolWeightsMap: S.Schema<GetResponseRandomSteeringPoolWeightsMap>;
export interface GetResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: GetResponseRandomSteeringPoolWeightsMap | null;
}
export declare const GetResponseRandomSteering: S.Schema<GetResponseRandomSteering>;
export type GetResponseRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponseRegionPoolsMap: S.Schema<GetResponseRegionPoolsMap>;
export type GetResponseRulesItemFixedResponse = CreateResponseRulesItemFixedResponse;
export declare const GetResponseRulesItemFixedResponse: S.Schema<CreateResponseRulesItemFixedResponse>;
export type GetResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponseRulesItemOverridesCountryPoolsMap: S.Schema<GetResponseRulesItemOverridesCountryPoolsMap>;
export type GetResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const GetResponseRulesItemOverridesDefaultPoolsList: S.Schema<GetResponseRulesItemOverridesDefaultPoolsList>;
export type GetResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponseRulesItemOverridesPopPoolsMap: S.Schema<GetResponseRulesItemOverridesPopPoolsMap>;
export type GetResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponseRulesItemOverridesRegionPoolsMap: S.Schema<GetResponseRulesItemOverridesRegionPoolsMap>;
export type GetResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const GetResponseRulesItemOverridesSessionAffinity: any;
export type GetResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const GetResponseRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<GetResponseRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type GetResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const GetResponseRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type GetResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const GetResponseRulesItemOverridesSessionAffinityAttributesSecure: any;
export type GetResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const GetResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface GetResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: GetResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: GetResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: GetResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: GetResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export declare const GetResponseRulesItemOverridesSessionAffinityAttributes: S.Schema<GetResponseRulesItemOverridesSessionAffinityAttributes>;
export type GetResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const GetResponseRulesItemOverridesSteeringPolicy: any;
export interface GetResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: GetResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: GetResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: GetResponseLocationStrategy | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: GetResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: GetResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: GetResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: GetResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: GetResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: GetResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export declare const GetResponseRulesItemOverrides: S.Schema<GetResponseRulesItemOverrides>;
export interface GetResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateResponseRulesItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: GetResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export declare const GetResponseRulesItem: S.Schema<GetResponseRulesItem>;
export type GetResponseRulesList = Array<GetResponseRulesItem>;
export declare const GetResponseRulesList: S.Schema<GetResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: GetResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: GetResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: GetResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: GetResponseNetworksList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: GetResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: GetResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: GetResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: GetResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: GetResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: GetResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: GetResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export declare const GetLoadBalancerResponse: S.Schema<GetLoadBalancerResponse>;
export interface GetMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
}
export declare const GetMonitorRequest: S.Schema<GetMonitorRequest>;
export type MonitorsGetResponseHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsGetResponseHeaderMap: S.Schema<MonitorsGetResponseHeaderMap>;
export type MonitorsGetResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsGetResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsGetResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsGetResponseType | null;
}
export declare const GetMonitorResponse: S.Schema<GetMonitorResponse>;
export interface GetMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
}
export declare const GetMonitorGroupRequest: S.Schema<GetMonitorGroupRequest>;
export type MonitorGroupsGetResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export declare const MonitorGroupsGetResponseMembersItem: S.Schema<MonitorGroupsCreateResponseMembersItem>;
export type MonitorGroupsGetResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export declare const MonitorGroupsGetResponseMembersList: S.Schema<MonitorGroupsGetResponseMembersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsGetResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export declare const GetMonitorGroupResponse: S.Schema<GetMonitorGroupResponse>;
export interface GetMonitorGroupReferenceRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
}
export declare const GetMonitorGroupReferenceRequest: S.Schema<GetMonitorGroupReferenceRequest>;
export type MonitorGroupsReferencesGetResultItemReferenceType = "*" | "referral" | "referrer";
export declare const MonitorGroupsReferencesGetResultItemReferenceType: any;
export interface MonitorGroupsReferencesGetResultItem {
    referenceType?: MonitorGroupsReferencesGetResultItemReferenceType | null;
    resourceId?: string | null;
    resourceName?: string | null;
    resourceType?: string | null;
}
export declare const MonitorGroupsReferencesGetResultItem: S.Schema<MonitorGroupsReferencesGetResultItem>;
export type MonitorGroupsReferencesGetResultList = Array<MonitorGroupsReferencesGetResultItem>;
export declare const MonitorGroupsReferencesGetResultList: S.Schema<MonitorGroupsReferencesGetResultList>;
export interface GetMonitorGroupReferenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorGroupsReferencesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetMonitorGroupReferenceResponse: S.Schema<GetMonitorGroupReferenceResponse>;
export interface GetMonitorReferenceRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
}
export declare const GetMonitorReferenceRequest: S.Schema<GetMonitorReferenceRequest>;
export type MonitorsReferencesGetResultItemReferenceType = "*" | "referral" | "referrer";
export declare const MonitorsReferencesGetResultItemReferenceType: any;
export interface MonitorsReferencesGetResultItem {
    referenceType?: MonitorsReferencesGetResultItemReferenceType | null;
    resourceId?: string | null;
    resourceName?: string | null;
    resourceType?: string | null;
}
export declare const MonitorsReferencesGetResultItem: S.Schema<MonitorsReferencesGetResultItem>;
export type MonitorsReferencesGetResultList = Array<MonitorsReferencesGetResultItem>;
export declare const MonitorsReferencesGetResultList: S.Schema<MonitorsReferencesGetResultList>;
export interface GetMonitorReferenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorsReferencesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetMonitorReferenceResponse: S.Schema<GetMonitorReferenceResponse>;
export interface GetPoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export declare const GetPoolRequest: S.Schema<GetPoolRequest>;
export type PoolsGetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsGetResponseCheckRegionsItem: any;
export type PoolsGetResponseCheckRegionsList = Array<PoolsGetResponseCheckRegionsItem>;
export declare const PoolsGetResponseCheckRegionsList: S.Schema<PoolsGetResponseCheckRegionsList>;
export type PoolsGetResponseLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsGetResponseLoadSheddingDefaultPolicy: any;
export type PoolsGetResponseLoadSheddingSessionPolicy = "hash";
export declare const PoolsGetResponseLoadSheddingSessionPolicy: any;
export interface PoolsGetResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsGetResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsGetResponseLoadSheddingSessionPolicy | null;
}
export declare const PoolsGetResponseLoadShedding: S.Schema<PoolsGetResponseLoadShedding>;
export type PoolsGetResponseNetworksList = Array<string>;
export declare const PoolsGetResponseNetworksList: S.Schema<PoolsGetResponseNetworksList>;
export type PoolsGetResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export declare const PoolsGetResponseNotificationFilterOrigin: S.Schema<PoolsBulkEditResultItemNotificationFilterOrigin>;
export type PoolsGetResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export declare const PoolsGetResponseNotificationFilter: S.Schema<PoolsBulkEditResultItemNotificationFilter>;
export type PoolsGetResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsGetResponseOriginSteeringPolicy: any;
export interface PoolsGetResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsGetResponseOriginSteeringPolicy | null;
}
export declare const PoolsGetResponseOriginSteering: S.Schema<PoolsGetResponseOriginSteering>;
export type PoolsGetResponseOriginsItemHeaderHostList = Array<string>;
export declare const PoolsGetResponseOriginsItemHeaderHostList: S.Schema<PoolsGetResponseOriginsItemHeaderHostList>;
export interface PoolsGetResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsGetResponseOriginsItemHeaderHostList | null;
}
export declare const PoolsGetResponseOriginsItemHeader: S.Schema<PoolsGetResponseOriginsItemHeader>;
export interface PoolsGetResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsGetResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export declare const PoolsGetResponseOriginsItem: S.Schema<PoolsGetResponseOriginsItem>;
export type PoolsGetResponseOriginsList = Array<PoolsGetResponseOriginsItem>;
export declare const PoolsGetResponseOriginsList: S.Schema<PoolsGetResponseOriginsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsGetResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsGetResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsGetResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsGetResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsGetResponseOriginsList | null;
}
export declare const GetPoolResponse: S.Schema<GetPoolResponse>;
export interface GetPoolHealthRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export declare const GetPoolHealthRequest: S.Schema<GetPoolHealthRequest>;
export interface PoolsHealthGetResponsePopHealthOriginsItemIp {
    /** Failure reason. */
    failureReason?: string | null;
    /** Origin health status. */
    healthy?: boolean | null;
    /** Response code from origin health check. */
    responseCode?: number | null;
    /** Origin RTT (Round Trip Time) response. */
    rtt?: string | null;
}
export declare const PoolsHealthGetResponsePopHealthOriginsItemIp: S.Schema<PoolsHealthGetResponsePopHealthOriginsItemIp>;
export interface PoolsHealthGetResponsePopHealthOriginsItem {
    ip?: PoolsHealthGetResponsePopHealthOriginsItemIp | null;
}
export declare const PoolsHealthGetResponsePopHealthOriginsItem: S.Schema<PoolsHealthGetResponsePopHealthOriginsItem>;
export type PoolsHealthGetResponsePopHealthOriginsList = Array<PoolsHealthGetResponsePopHealthOriginsItem>;
export declare const PoolsHealthGetResponsePopHealthOriginsList: S.Schema<PoolsHealthGetResponsePopHealthOriginsList>;
export interface PoolsHealthGetResponsePopHealth {
    /** Whether health check in region is healthy. */
    healthy?: boolean | null;
    origins?: PoolsHealthGetResponsePopHealthOriginsList | null;
}
export declare const PoolsHealthGetResponsePopHealth: S.Schema<PoolsHealthGetResponsePopHealth>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPoolHealthResponse {
    /** Pool ID. */
    poolId?: string | null;
    /** List of regions and associated health status. */
    popHealth?: PoolsHealthGetResponsePopHealth | null;
}
export declare const GetPoolHealthResponse: S.Schema<GetPoolHealthResponse>;
export interface GetPoolReferenceRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
}
export declare const GetPoolReferenceRequest: S.Schema<GetPoolReferenceRequest>;
export type PoolsReferencesGetResultItemReferenceType = "*" | "referral" | "referrer";
export declare const PoolsReferencesGetResultItemReferenceType: any;
export interface PoolsReferencesGetResultItem {
    referenceType?: PoolsReferencesGetResultItemReferenceType | null;
    resourceId?: string | null;
    resourceName?: string | null;
    resourceType?: string | null;
}
export declare const PoolsReferencesGetResultItem: S.Schema<PoolsReferencesGetResultItem>;
export type PoolsReferencesGetResultList = Array<PoolsReferencesGetResultItem>;
export declare const PoolsReferencesGetResultList: S.Schema<PoolsReferencesGetResultList>;
export interface GetPoolReferenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoolsReferencesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetPoolReferenceResponse: S.Schema<GetPoolReferenceResponse>;
export interface GetPreviewRequest {
    /** Identifier. */
    accountId: string;
    previewId: string;
}
export declare const GetPreviewRequest: S.Schema<GetPreviewRequest>;
export interface PreviewsGetResultValueOriginsItemValue {
    failureReason?: string | null;
    healthy?: boolean | null;
    responseCode?: number | null;
    rtt?: string | null;
}
export declare const PreviewsGetResultValueOriginsItemValue: S.Schema<PreviewsGetResultValueOriginsItemValue>;
export type PreviewsGetResultValueOriginsItemMap = {
    [key: string]: PreviewsGetResultValueOriginsItemValue | undefined;
};
export declare const PreviewsGetResultValueOriginsItemMap: S.Schema<PreviewsGetResultValueOriginsItemMap>;
export type PreviewsGetResultValueOriginsList = Array<PreviewsGetResultValueOriginsItemMap>;
export declare const PreviewsGetResultValueOriginsList: S.Schema<PreviewsGetResultValueOriginsList>;
export interface PreviewsGetResultValue {
    healthy?: boolean | null;
    origins?: PreviewsGetResultValueOriginsList | null;
}
export declare const PreviewsGetResultValue: S.Schema<PreviewsGetResultValue>;
export type PreviewsGetResultMap = {
    [key: string]: PreviewsGetResultValue | undefined;
};
export declare const PreviewsGetResultMap: S.Schema<PreviewsGetResultMap>;
export type GetPreviewResponse = PreviewsGetResultMap;
export declare const GetPreviewResponse: S.Schema<GetPreviewResponse>;
export type RegionsGetRequestRegionId = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS";
export declare const RegionsGetRequestRegionId: any;
export interface GetRegionRequest {
    /** Identifier. */
    accountId: string;
    /** A list of Cloudflare regions. WNAM: Western North America, ENAM: Eastern North America, WEU: Western Europe, EEU: Eastern Europe, NSAM: Northern South America, SSAM: Southern South America, OC: Oceania, ME: Middle East, NAF: North Africa, SAF: South Africa, SAS: Southern Asia, SEAS: South East Asia, NEAS: North East Asia). */
    regionId: RegionsGetRequestRegionId | (string & {});
}
export declare const GetRegionRequest: S.Schema<GetRegionRequest>;
export type GetRegionResponse = unknown;
export declare const GetRegionResponse: S.Schema<GetRegionResponse>;
export interface ListLoadBalancersRequest {
    zoneId: string;
}
export declare const ListLoadBalancersRequest: S.Schema<ListLoadBalancersRequest>;
export type ListResultItemAdaptiveRouting = CreateResponseAdaptiveRouting;
export declare const ListResultItemAdaptiveRouting: S.Schema<CreateResponseAdaptiveRouting>;
export type ListResultItemCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemCountryPoolsMap: S.Schema<ListResultItemCountryPoolsMap>;
export type ListResultItemDefaultPoolsList = Array<string>;
export declare const ListResultItemDefaultPoolsList: S.Schema<ListResultItemDefaultPoolsList>;
export type ListResultItemLocationStrategyMode = "pop" | "resolver_ip";
export declare const ListResultItemLocationStrategyMode: any;
export type ListResultItemLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const ListResultItemLocationStrategyPreferEcs: any;
export interface ListResultItemLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: ListResultItemLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: ListResultItemLocationStrategyPreferEcs | null;
}
export declare const ListResultItemLocationStrategy: S.Schema<ListResultItemLocationStrategy>;
export type ListResultItemNetworksList = Array<string>;
export declare const ListResultItemNetworksList: S.Schema<ListResultItemNetworksList>;
export type ListResultItemPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemPopPoolsMap: S.Schema<ListResultItemPopPoolsMap>;
export type ListResultItemRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const ListResultItemRandomSteeringPoolWeightsMap: S.Schema<ListResultItemRandomSteeringPoolWeightsMap>;
export interface ListResultItemRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: ListResultItemRandomSteeringPoolWeightsMap | null;
}
export declare const ListResultItemRandomSteering: S.Schema<ListResultItemRandomSteering>;
export type ListResultItemRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemRegionPoolsMap: S.Schema<ListResultItemRegionPoolsMap>;
export type ListResultItemRulesItemFixedResponse = CreateResponseRulesItemFixedResponse;
export declare const ListResultItemRulesItemFixedResponse: S.Schema<CreateResponseRulesItemFixedResponse>;
export type ListResultItemRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemRulesItemOverridesCountryPoolsMap: S.Schema<ListResultItemRulesItemOverridesCountryPoolsMap>;
export type ListResultItemRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const ListResultItemRulesItemOverridesDefaultPoolsList: S.Schema<ListResultItemRulesItemOverridesDefaultPoolsList>;
export type ListResultItemRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemRulesItemOverridesPopPoolsMap: S.Schema<ListResultItemRulesItemOverridesPopPoolsMap>;
export type ListResultItemRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemRulesItemOverridesRegionPoolsMap: S.Schema<ListResultItemRulesItemOverridesRegionPoolsMap>;
export type ListResultItemRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const ListResultItemRulesItemOverridesSessionAffinity: any;
export type ListResultItemRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const ListResultItemRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<ListResultItemRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type ListResultItemRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const ListResultItemRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type ListResultItemRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const ListResultItemRulesItemOverridesSessionAffinityAttributesSecure: any;
export type ListResultItemRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const ListResultItemRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface ListResultItemRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: ListResultItemRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: ListResultItemRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: ListResultItemRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: ListResultItemRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export declare const ListResultItemRulesItemOverridesSessionAffinityAttributes: S.Schema<ListResultItemRulesItemOverridesSessionAffinityAttributes>;
export type ListResultItemRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const ListResultItemRulesItemOverridesSteeringPolicy: any;
export interface ListResultItemRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: ListResultItemRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: ListResultItemRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: ListResultItemLocationStrategy | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: ListResultItemRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: ListResultItemRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: ListResultItemRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: ListResultItemRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: ListResultItemRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: ListResultItemRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export declare const ListResultItemRulesItemOverrides: S.Schema<ListResultItemRulesItemOverrides>;
export interface ListResultItemRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateResponseRulesItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: ListResultItemRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export declare const ListResultItemRulesItem: S.Schema<ListResultItemRulesItem>;
export type ListResultItemRulesList = Array<ListResultItemRulesItem>;
export declare const ListResultItemRulesList: S.Schema<ListResultItemRulesList>;
export interface ListResultItem {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: ListResultItemCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: ListResultItemDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: ListResultItemLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: ListResultItemNetworksList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: ListResultItemPopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: ListResultItemRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: ListResultItemRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: ListResultItemRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: ListResultItemRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: ListResultItemRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: ListResultItemRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListLoadBalancersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLoadBalancersResponse: S.Schema<ListLoadBalancersResponse>;
export interface ListMonitorGroupsRequest {
    /** Identifier. */
    accountId: string;
}
export declare const ListMonitorGroupsRequest: S.Schema<ListMonitorGroupsRequest>;
export type MonitorGroupsListResultItemMembersItem = MonitorGroupsCreateResponseMembersItem;
export declare const MonitorGroupsListResultItemMembersItem: S.Schema<MonitorGroupsCreateResponseMembersItem>;
export type MonitorGroupsListResultItemMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export declare const MonitorGroupsListResultItemMembersList: S.Schema<MonitorGroupsListResultItemMembersList>;
export interface MonitorGroupsListResultItem {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsListResultItemMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export declare const MonitorGroupsListResultItem: S.Schema<MonitorGroupsListResultItem>;
export type MonitorGroupsListResultList = Array<MonitorGroupsListResultItem>;
export declare const MonitorGroupsListResultList: S.Schema<MonitorGroupsListResultList>;
export interface ListMonitorGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListMonitorGroupsResponse: S.Schema<ListMonitorGroupsResponse>;
export interface ListMonitorsRequest {
    /** Identifier. */
    accountId: string;
}
export declare const ListMonitorsRequest: S.Schema<ListMonitorsRequest>;
export type MonitorsListResultItemHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsListResultItemHeaderMap: S.Schema<MonitorsListResultItemHeaderMap>;
export type MonitorsListResultItemType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsListResultItemType: any;
export interface MonitorsListResultItem {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsListResultItemHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsListResultItemType | null;
}
export declare const MonitorsListResultItem: S.Schema<MonitorsListResultItem>;
export type MonitorsListResultList = Array<MonitorsListResultItem>;
export declare const MonitorsListResultList: S.Schema<MonitorsListResultList>;
export interface ListMonitorsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MonitorsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListMonitorsResponse: S.Schema<ListMonitorsResponse>;
export interface ListPoolsRequest {
    /** Identifier. */
    accountId: string;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
}
export declare const ListPoolsRequest: S.Schema<ListPoolsRequest>;
export type PoolsListResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsListResultItemCheckRegionsItem: any;
export type PoolsListResultItemCheckRegionsList = Array<PoolsListResultItemCheckRegionsItem>;
export declare const PoolsListResultItemCheckRegionsList: S.Schema<PoolsListResultItemCheckRegionsList>;
export type PoolsListResultItemLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsListResultItemLoadSheddingDefaultPolicy: any;
export type PoolsListResultItemLoadSheddingSessionPolicy = "hash";
export declare const PoolsListResultItemLoadSheddingSessionPolicy: any;
export interface PoolsListResultItemLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsListResultItemLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsListResultItemLoadSheddingSessionPolicy | null;
}
export declare const PoolsListResultItemLoadShedding: S.Schema<PoolsListResultItemLoadShedding>;
export type PoolsListResultItemNetworksList = Array<string>;
export declare const PoolsListResultItemNetworksList: S.Schema<PoolsListResultItemNetworksList>;
export type PoolsListResultItemNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export declare const PoolsListResultItemNotificationFilterOrigin: S.Schema<PoolsBulkEditResultItemNotificationFilterOrigin>;
export type PoolsListResultItemNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export declare const PoolsListResultItemNotificationFilter: S.Schema<PoolsBulkEditResultItemNotificationFilter>;
export type PoolsListResultItemOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsListResultItemOriginSteeringPolicy: any;
export interface PoolsListResultItemOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsListResultItemOriginSteeringPolicy | null;
}
export declare const PoolsListResultItemOriginSteering: S.Schema<PoolsListResultItemOriginSteering>;
export type PoolsListResultItemOriginsItemHeaderHostList = Array<string>;
export declare const PoolsListResultItemOriginsItemHeaderHostList: S.Schema<PoolsListResultItemOriginsItemHeaderHostList>;
export interface PoolsListResultItemOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsListResultItemOriginsItemHeaderHostList | null;
}
export declare const PoolsListResultItemOriginsItemHeader: S.Schema<PoolsListResultItemOriginsItemHeader>;
export interface PoolsListResultItemOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsListResultItemOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export declare const PoolsListResultItemOriginsItem: S.Schema<PoolsListResultItemOriginsItem>;
export type PoolsListResultItemOriginsList = Array<PoolsListResultItemOriginsItem>;
export declare const PoolsListResultItemOriginsList: S.Schema<PoolsListResultItemOriginsList>;
export interface PoolsListResultItem {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsListResultItemCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsListResultItemLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsListResultItemNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsListResultItemOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsListResultItemOriginsList | null;
}
export declare const PoolsListResultItem: S.Schema<PoolsListResultItem>;
export type PoolsListResultList = Array<PoolsListResultItem>;
export declare const PoolsListResultList: S.Schema<PoolsListResultList>;
export interface ListPoolsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoolsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPoolsResponse: S.Schema<ListPoolsResponse>;
export interface ListRegionsRequest {
    /** Identifier. */
    accountId: string;
    /** Two-letter alpha-2 country code followed in ISO 3166-1. */
    countryCodeA2?: string;
    /** Two-letter subdivision code followed in ISO 3166-2. */
    subdivisionCode?: string;
    /** Two-letter subdivision code followed in ISO 3166-2. */
    subdivisionCodeA2?: string;
}
export declare const ListRegionsRequest: S.Schema<ListRegionsRequest>;
export type ListRegionsResponse = unknown;
export declare const ListRegionsResponse: S.Schema<ListRegionsResponse>;
export type SearchesListRequestReferences = "" | "*" | "referral" | "referrer";
export declare const SearchesListRequestReferences: any;
export interface ListSearchesRequest {
    /** Identifier. */
    accountId: string;
    page?: number;
    perPage?: number;
    /** Search query term. */
    query?: string;
    /** The type of references to include. "*" to include both referral and referrer references. "" to not include any reference information. */
    references?: SearchesListRequestReferences | (string & {});
}
export declare const ListSearchesRequest: S.Schema<ListSearchesRequest>;
export type SearchesListResponseResourcesItemReferenceType = "referral" | "referrer";
export declare const SearchesListResponseResourcesItemReferenceType: any;
export type SearchesListResponseResourcesItemReferencesList = Array<unknown>;
export declare const SearchesListResponseResourcesItemReferencesList: S.Schema<SearchesListResponseResourcesItemReferencesList>;
export type SearchesListResponseResourcesItemResourceType = "load_balancer" | "monitor" | "pool";
export declare const SearchesListResponseResourcesItemResourceType: any;
export interface SearchesListResponseResourcesItem {
    /** When listed as a reference, the type (direction) of the reference. */
    referenceType?: SearchesListResponseResourcesItemReferenceType | null;
    /** A list of references to (referrer) or from (referral) this resource. */
    references?: SearchesListResponseResourcesItemReferencesList | null;
    resourceId?: string | null;
    /** The human-identifiable name of the resource. */
    resourceName?: string | null;
    /** The type of the resource. */
    resourceType?: SearchesListResponseResourcesItemResourceType | null;
}
export declare const SearchesListResponseResourcesItem: S.Schema<SearchesListResponseResourcesItem>;
export type SearchesListResponseResourcesList = Array<SearchesListResponseResourcesItem>;
export declare const SearchesListResponseResourcesList: S.Schema<SearchesListResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListSearchesResponse {
    /** A list of resources matching the search query. */
    resources?: SearchesListResponseResourcesList | null;
}
export declare const ListSearchesResponse: S.Schema<ListSearchesResponse>;
export type EditRequestAdaptiveRouting = CreateRequestAdaptiveRouting;
export declare const EditRequestAdaptiveRouting: S.Schema<CreateRequestAdaptiveRouting>;
export type EditRequestCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRequestCountryPoolsMap: S.Schema<EditRequestCountryPoolsMap>;
export type EditRequestDefaultPoolsList = Array<string>;
export declare const EditRequestDefaultPoolsList: S.Schema<EditRequestDefaultPoolsList>;
export type EditRequestLocationStrategyMode = "pop" | "resolver_ip";
export declare const EditRequestLocationStrategyMode: any;
export type EditRequestLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const EditRequestLocationStrategyPreferEcs: any;
export interface EditRequestLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: EditRequestLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: EditRequestLocationStrategyPreferEcs | (string & {});
}
export declare const EditRequestLocationStrategy: S.Schema<EditRequestLocationStrategy>;
export type EditRequestPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRequestPopPoolsMap: S.Schema<EditRequestPopPoolsMap>;
export type EditRequestRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const EditRequestRandomSteeringPoolWeightsMap: S.Schema<EditRequestRandomSteeringPoolWeightsMap>;
export interface EditRequestRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: EditRequestRandomSteeringPoolWeightsMap;
}
export declare const EditRequestRandomSteering: S.Schema<EditRequestRandomSteering>;
export type EditRequestRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRequestRegionPoolsMap: S.Schema<EditRequestRegionPoolsMap>;
export type EditRequestRulesItemFixedResponse = CreateRequestRulesItemFixedResponse;
export declare const EditRequestRulesItemFixedResponse: S.Schema<CreateRequestRulesItemFixedResponse>;
export type EditRequestRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRequestRulesItemOverridesCountryPoolsMap: S.Schema<EditRequestRulesItemOverridesCountryPoolsMap>;
export type EditRequestRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const EditRequestRulesItemOverridesDefaultPoolsList: S.Schema<EditRequestRulesItemOverridesDefaultPoolsList>;
export type EditRequestRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRequestRulesItemOverridesPopPoolsMap: S.Schema<EditRequestRulesItemOverridesPopPoolsMap>;
export type EditRequestRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRequestRulesItemOverridesRegionPoolsMap: S.Schema<EditRequestRulesItemOverridesRegionPoolsMap>;
export type EditRequestRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const EditRequestRulesItemOverridesSessionAffinity: any;
export type EditRequestRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const EditRequestRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<EditRequestRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type EditRequestRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const EditRequestRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type EditRequestRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const EditRequestRulesItemOverridesSessionAffinityAttributesSecure: any;
export type EditRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const EditRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface EditRequestRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: EditRequestRulesItemOverridesSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: EditRequestRulesItemOverridesSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: EditRequestRulesItemOverridesSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: EditRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export declare const EditRequestRulesItemOverridesSessionAffinityAttributes: S.Schema<EditRequestRulesItemOverridesSessionAffinityAttributes>;
export type EditRequestRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const EditRequestRulesItemOverridesSteeringPolicy: any;
export interface EditRequestRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditRequestRulesItemOverridesCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditRequestRulesItemOverridesDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditRequestLocationStrategy;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditRequestRulesItemOverridesPopPoolsMap;
    /** Configures pool weights. */
    randomSteering?: EditRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditRequestRulesItemOverridesRegionPoolsMap;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export declare const EditRequestRulesItemOverrides: S.Schema<EditRequestRulesItemOverrides>;
export interface EditRequestRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateRequestRulesItemFixedResponse;
    /** Name of this rule. Only used for human readability. */
    name?: string;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: EditRequestRulesItemOverrides;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean;
}
export declare const EditRequestRulesItem: S.Schema<EditRequestRulesItem>;
export type EditRequestRulesList = Array<EditRequestRulesItem>;
export declare const EditRequestRulesList: S.Schema<EditRequestRulesList>;
export interface PatchLoadBalancerRequest {
    zoneId: string;
    loadBalancerId: string;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditRequestCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditRequestDefaultPoolsList;
    /** Object description. */
    description?: string;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditRequestLocationStrategy;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditRequestPopPoolsMap;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean;
    /** Configures pool weights. */
    randomSteering?: EditRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditRequestRegionPoolsMap;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: EditRequestRulesList;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export declare const PatchLoadBalancerRequest: S.Schema<PatchLoadBalancerRequest>;
export type EditResponseAdaptiveRouting = CreateResponseAdaptiveRouting;
export declare const EditResponseAdaptiveRouting: S.Schema<CreateResponseAdaptiveRouting>;
export type EditResponseCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditResponseCountryPoolsMap: S.Schema<EditResponseCountryPoolsMap>;
export type EditResponseDefaultPoolsList = Array<string>;
export declare const EditResponseDefaultPoolsList: S.Schema<EditResponseDefaultPoolsList>;
export type EditResponseLocationStrategyMode = "pop" | "resolver_ip";
export declare const EditResponseLocationStrategyMode: any;
export type EditResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const EditResponseLocationStrategyPreferEcs: any;
export interface EditResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: EditResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: EditResponseLocationStrategyPreferEcs | null;
}
export declare const EditResponseLocationStrategy: S.Schema<EditResponseLocationStrategy>;
export type EditResponseNetworksList = Array<string>;
export declare const EditResponseNetworksList: S.Schema<EditResponseNetworksList>;
export type EditResponsePopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditResponsePopPoolsMap: S.Schema<EditResponsePopPoolsMap>;
export type EditResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const EditResponseRandomSteeringPoolWeightsMap: S.Schema<EditResponseRandomSteeringPoolWeightsMap>;
export interface EditResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: EditResponseRandomSteeringPoolWeightsMap | null;
}
export declare const EditResponseRandomSteering: S.Schema<EditResponseRandomSteering>;
export type EditResponseRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditResponseRegionPoolsMap: S.Schema<EditResponseRegionPoolsMap>;
export type EditResponseRulesItemFixedResponse = CreateResponseRulesItemFixedResponse;
export declare const EditResponseRulesItemFixedResponse: S.Schema<CreateResponseRulesItemFixedResponse>;
export type EditResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditResponseRulesItemOverridesCountryPoolsMap: S.Schema<EditResponseRulesItemOverridesCountryPoolsMap>;
export type EditResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const EditResponseRulesItemOverridesDefaultPoolsList: S.Schema<EditResponseRulesItemOverridesDefaultPoolsList>;
export type EditResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditResponseRulesItemOverridesPopPoolsMap: S.Schema<EditResponseRulesItemOverridesPopPoolsMap>;
export type EditResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const EditResponseRulesItemOverridesRegionPoolsMap: S.Schema<EditResponseRulesItemOverridesRegionPoolsMap>;
export type EditResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const EditResponseRulesItemOverridesSessionAffinity: any;
export type EditResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const EditResponseRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<EditResponseRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type EditResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const EditResponseRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type EditResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const EditResponseRulesItemOverridesSessionAffinityAttributesSecure: any;
export type EditResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const EditResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface EditResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: EditResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: EditResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: EditResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: EditResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export declare const EditResponseRulesItemOverridesSessionAffinityAttributes: S.Schema<EditResponseRulesItemOverridesSessionAffinityAttributes>;
export type EditResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const EditResponseRulesItemOverridesSteeringPolicy: any;
export interface EditResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditResponseLocationStrategy | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: EditResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export declare const EditResponseRulesItemOverrides: S.Schema<EditResponseRulesItemOverrides>;
export interface EditResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateResponseRulesItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: EditResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export declare const EditResponseRulesItem: S.Schema<EditResponseRulesItem>;
export type EditResponseRulesList = Array<EditResponseRulesItem>;
export declare const EditResponseRulesList: S.Schema<EditResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: EditResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: EditResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: EditResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: EditResponseNetworksList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: EditResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: EditResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: EditResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: EditResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: EditResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: EditResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: EditResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export declare const PatchLoadBalancerResponse: S.Schema<PatchLoadBalancerResponse>;
export type MonitorsEditRequestHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsEditRequestHeaderMap: S.Schema<MonitorsEditRequestHeaderMap>;
export type MonitorsEditRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsEditRequestType: any;
export interface PatchMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsEditRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsEditRequestType | (string & {});
}
export declare const PatchMonitorRequest: S.Schema<PatchMonitorRequest>;
export type MonitorsEditResponseHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsEditResponseHeaderMap: S.Schema<MonitorsEditResponseHeaderMap>;
export type MonitorsEditResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsEditResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsEditResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsEditResponseType | null;
}
export declare const PatchMonitorResponse: S.Schema<PatchMonitorResponse>;
export type MonitorGroupsEditRequestMembersItem = MonitorGroupsCreateRequestMembersItem;
export declare const MonitorGroupsEditRequestMembersItem: S.Schema<MonitorGroupsCreateRequestMembersItem>;
export type MonitorGroupsEditRequestMembersList = Array<MonitorGroupsCreateRequestMembersItem>;
export declare const MonitorGroupsEditRequestMembersList: S.Schema<MonitorGroupsEditRequestMembersList>;
export interface PatchMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsEditRequestMembersList;
}
export declare const PatchMonitorGroupRequest: S.Schema<PatchMonitorGroupRequest>;
export type MonitorGroupsEditResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export declare const MonitorGroupsEditResponseMembersItem: S.Schema<MonitorGroupsCreateResponseMembersItem>;
export type MonitorGroupsEditResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export declare const MonitorGroupsEditResponseMembersList: S.Schema<MonitorGroupsEditResponseMembersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsEditResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export declare const PatchMonitorGroupResponse: S.Schema<PatchMonitorGroupResponse>;
export type PoolsEditRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsEditRequestCheckRegionsItem: any;
export type PoolsEditRequestCheckRegionsList = Array<PoolsEditRequestCheckRegionsItem | (string & {})>;
export declare const PoolsEditRequestCheckRegionsList: S.Schema<PoolsEditRequestCheckRegionsList>;
export type PoolsEditRequestLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsEditRequestLoadSheddingDefaultPolicy: any;
export type PoolsEditRequestLoadSheddingSessionPolicy = "hash";
export declare const PoolsEditRequestLoadSheddingSessionPolicy: any;
export interface PoolsEditRequestLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsEditRequestLoadSheddingDefaultPolicy | (string & {});
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsEditRequestLoadSheddingSessionPolicy | (string & {});
}
export declare const PoolsEditRequestLoadShedding: S.Schema<PoolsEditRequestLoadShedding>;
export type PoolsEditRequestNotificationFilterOrigin = PoolsCreateRequestNotificationFilterOrigin;
export declare const PoolsEditRequestNotificationFilterOrigin: S.Schema<PoolsCreateRequestNotificationFilterOrigin>;
export type PoolsEditRequestNotificationFilter = PoolsCreateRequestNotificationFilter;
export declare const PoolsEditRequestNotificationFilter: S.Schema<PoolsCreateRequestNotificationFilter>;
export type PoolsEditRequestOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsEditRequestOriginSteeringPolicy: any;
export interface PoolsEditRequestOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsEditRequestOriginSteeringPolicy | (string & {});
}
export declare const PoolsEditRequestOriginSteering: S.Schema<PoolsEditRequestOriginSteering>;
export type PoolsEditRequestOriginsItemHeaderHostList = Array<string>;
export declare const PoolsEditRequestOriginsItemHeaderHostList: S.Schema<PoolsEditRequestOriginsItemHeaderHostList>;
export interface PoolsEditRequestOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsEditRequestOriginsItemHeaderHostList;
}
export declare const PoolsEditRequestOriginsItemHeader: S.Schema<PoolsEditRequestOriginsItemHeader>;
export interface PoolsEditRequestOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsEditRequestOriginsItemHeader;
    /** A human-identifiable name for the origin. */
    name?: string;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number;
}
export declare const PoolsEditRequestOriginsItem: S.Schema<PoolsEditRequestOriginsItem>;
export type PoolsEditRequestOriginsList = Array<PoolsEditRequestOriginsItem>;
export declare const PoolsEditRequestOriginsList: S.Schema<PoolsEditRequestOriginsList>;
export interface PatchPoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsEditRequestCheckRegionsList;
    /** A human-readable description of the pool. */
    description?: string;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsEditRequestLoadShedding;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsCreateRequestNotificationFilter;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsEditRequestOriginSteering;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsEditRequestOriginsList;
}
export declare const PatchPoolRequest: S.Schema<PatchPoolRequest>;
export type PoolsEditResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsEditResponseCheckRegionsItem: any;
export type PoolsEditResponseCheckRegionsList = Array<PoolsEditResponseCheckRegionsItem>;
export declare const PoolsEditResponseCheckRegionsList: S.Schema<PoolsEditResponseCheckRegionsList>;
export type PoolsEditResponseLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsEditResponseLoadSheddingDefaultPolicy: any;
export type PoolsEditResponseLoadSheddingSessionPolicy = "hash";
export declare const PoolsEditResponseLoadSheddingSessionPolicy: any;
export interface PoolsEditResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsEditResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsEditResponseLoadSheddingSessionPolicy | null;
}
export declare const PoolsEditResponseLoadShedding: S.Schema<PoolsEditResponseLoadShedding>;
export type PoolsEditResponseNetworksList = Array<string>;
export declare const PoolsEditResponseNetworksList: S.Schema<PoolsEditResponseNetworksList>;
export type PoolsEditResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export declare const PoolsEditResponseNotificationFilterOrigin: S.Schema<PoolsBulkEditResultItemNotificationFilterOrigin>;
export type PoolsEditResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export declare const PoolsEditResponseNotificationFilter: S.Schema<PoolsBulkEditResultItemNotificationFilter>;
export type PoolsEditResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsEditResponseOriginSteeringPolicy: any;
export interface PoolsEditResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsEditResponseOriginSteeringPolicy | null;
}
export declare const PoolsEditResponseOriginSteering: S.Schema<PoolsEditResponseOriginSteering>;
export type PoolsEditResponseOriginsItemHeaderHostList = Array<string>;
export declare const PoolsEditResponseOriginsItemHeaderHostList: S.Schema<PoolsEditResponseOriginsItemHeaderHostList>;
export interface PoolsEditResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsEditResponseOriginsItemHeaderHostList | null;
}
export declare const PoolsEditResponseOriginsItemHeader: S.Schema<PoolsEditResponseOriginsItemHeader>;
export interface PoolsEditResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsEditResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export declare const PoolsEditResponseOriginsItem: S.Schema<PoolsEditResponseOriginsItem>;
export type PoolsEditResponseOriginsList = Array<PoolsEditResponseOriginsItem>;
export declare const PoolsEditResponseOriginsList: S.Schema<PoolsEditResponseOriginsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsEditResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsEditResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsEditResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsEditResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsEditResponseOriginsList | null;
}
export declare const PatchPoolResponse: S.Schema<PatchPoolResponse>;
export type UpdateRequestDefaultPoolsList = Array<string>;
export declare const UpdateRequestDefaultPoolsList: S.Schema<UpdateRequestDefaultPoolsList>;
export type UpdateRequestAdaptiveRouting = CreateRequestAdaptiveRouting;
export declare const UpdateRequestAdaptiveRouting: S.Schema<CreateRequestAdaptiveRouting>;
export type UpdateRequestCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestCountryPoolsMap: S.Schema<UpdateRequestCountryPoolsMap>;
export type UpdateRequestLocationStrategyMode = "pop" | "resolver_ip";
export declare const UpdateRequestLocationStrategyMode: any;
export type UpdateRequestLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const UpdateRequestLocationStrategyPreferEcs: any;
export interface UpdateRequestLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: UpdateRequestLocationStrategyMode | (string & {});
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: UpdateRequestLocationStrategyPreferEcs | (string & {});
}
export declare const UpdateRequestLocationStrategy: S.Schema<UpdateRequestLocationStrategy>;
export type UpdateRequestNetworksList = Array<string>;
export declare const UpdateRequestNetworksList: S.Schema<UpdateRequestNetworksList>;
export type UpdateRequestPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestPopPoolsMap: S.Schema<UpdateRequestPopPoolsMap>;
export type UpdateRequestRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const UpdateRequestRandomSteeringPoolWeightsMap: S.Schema<UpdateRequestRandomSteeringPoolWeightsMap>;
export interface UpdateRequestRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: UpdateRequestRandomSteeringPoolWeightsMap;
}
export declare const UpdateRequestRandomSteering: S.Schema<UpdateRequestRandomSteering>;
export type UpdateRequestRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestRegionPoolsMap: S.Schema<UpdateRequestRegionPoolsMap>;
export type UpdateRequestRulesItemFixedResponse = CreateRequestRulesItemFixedResponse;
export declare const UpdateRequestRulesItemFixedResponse: S.Schema<CreateRequestRulesItemFixedResponse>;
export type UpdateRequestRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestRulesItemOverridesCountryPoolsMap: S.Schema<UpdateRequestRulesItemOverridesCountryPoolsMap>;
export type UpdateRequestRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const UpdateRequestRulesItemOverridesDefaultPoolsList: S.Schema<UpdateRequestRulesItemOverridesDefaultPoolsList>;
export type UpdateRequestRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestRulesItemOverridesPopPoolsMap: S.Schema<UpdateRequestRulesItemOverridesPopPoolsMap>;
export type UpdateRequestRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestRulesItemOverridesRegionPoolsMap: S.Schema<UpdateRequestRulesItemOverridesRegionPoolsMap>;
export type UpdateRequestRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const UpdateRequestRulesItemOverridesSessionAffinity: any;
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const UpdateRequestRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<UpdateRequestRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const UpdateRequestRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const UpdateRequestRulesItemOverridesSessionAffinityAttributesSecure: any;
export type UpdateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const UpdateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface UpdateRequestRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: UpdateRequestRulesItemOverridesSessionAffinityAttributesHeadersList;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: UpdateRequestRulesItemOverridesSessionAffinityAttributesSamesite | (string & {});
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: UpdateRequestRulesItemOverridesSessionAffinityAttributesSecure | (string & {});
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: UpdateRequestRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | (string & {});
}
export declare const UpdateRequestRulesItemOverridesSessionAffinityAttributes: S.Schema<UpdateRequestRulesItemOverridesSessionAffinityAttributes>;
export type UpdateRequestRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const UpdateRequestRulesItemOverridesSteeringPolicy: any;
export interface UpdateRequestRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateRequestRulesItemOverridesCountryPoolsMap;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: UpdateRequestRulesItemOverridesDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateRequestLocationStrategy;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateRequestRulesItemOverridesPopPoolsMap;
    /** Configures pool weights. */
    randomSteering?: UpdateRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateRequestRulesItemOverridesRegionPoolsMap;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export declare const UpdateRequestRulesItemOverrides: S.Schema<UpdateRequestRulesItemOverrides>;
export interface UpdateRequestRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateRequestRulesItemFixedResponse;
    /** Name of this rule. Only used for human readability. */
    name?: string;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: UpdateRequestRulesItemOverrides;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean;
}
export declare const UpdateRequestRulesItem: S.Schema<UpdateRequestRulesItem>;
export type UpdateRequestRulesList = Array<UpdateRequestRulesItem>;
export declare const UpdateRequestRulesList: S.Schema<UpdateRequestRulesList>;
export interface UpdateLoadBalancerRequest {
    zoneId: string;
    loadBalancerId: string;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools: UpdateRequestDefaultPoolsList;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool: string;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name: string;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateRequestAdaptiveRouting;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateRequestCountryPoolsMap;
    /** Object description. */
    description?: string;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateRequestLocationStrategy;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: UpdateRequestNetworksList;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateRequestPopPoolsMap;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean;
    /** Configures pool weights. */
    randomSteering?: UpdateRequestRandomSteering;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateRequestRegionPoolsMap;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: UpdateRequestRulesList;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateRequestRulesItemOverridesSessionAffinity | (string & {});
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateRequestRulesItemOverridesSessionAffinityAttributes;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateRequestRulesItemOverridesSteeringPolicy | (string & {});
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number;
}
export declare const UpdateLoadBalancerRequest: S.Schema<UpdateLoadBalancerRequest>;
export type UpdateResponseAdaptiveRouting = CreateResponseAdaptiveRouting;
export declare const UpdateResponseAdaptiveRouting: S.Schema<CreateResponseAdaptiveRouting>;
export type UpdateResponseCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponseCountryPoolsMap: S.Schema<UpdateResponseCountryPoolsMap>;
export type UpdateResponseDefaultPoolsList = Array<string>;
export declare const UpdateResponseDefaultPoolsList: S.Schema<UpdateResponseDefaultPoolsList>;
export type UpdateResponseLocationStrategyMode = "pop" | "resolver_ip";
export declare const UpdateResponseLocationStrategyMode: any;
export type UpdateResponseLocationStrategyPreferEcs = "always" | "never" | "proximity" | "geo";
export declare const UpdateResponseLocationStrategyPreferEcs: any;
export interface UpdateResponseLocationStrategy {
    /** Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. */
    mode?: UpdateResponseLocationStrategyMode | null;
    /** Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. */
    preferEcs?: UpdateResponseLocationStrategyPreferEcs | null;
}
export declare const UpdateResponseLocationStrategy: S.Schema<UpdateResponseLocationStrategy>;
export type UpdateResponseNetworksList = Array<string>;
export declare const UpdateResponseNetworksList: S.Schema<UpdateResponseNetworksList>;
export type UpdateResponsePopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponsePopPoolsMap: S.Schema<UpdateResponsePopPoolsMap>;
export type UpdateResponseRandomSteeringPoolWeightsMap = {
    [key: string]: number | undefined;
};
export declare const UpdateResponseRandomSteeringPoolWeightsMap: S.Schema<UpdateResponseRandomSteeringPoolWeightsMap>;
export interface UpdateResponseRandomSteering {
    /** The default weight for pools in the load balancer that are not specified in the pool_weights map. */
    defaultWeight?: number | null;
    /** A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer. */
    poolWeights?: UpdateResponseRandomSteeringPoolWeightsMap | null;
}
export declare const UpdateResponseRandomSteering: S.Schema<UpdateResponseRandomSteering>;
export type UpdateResponseRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponseRegionPoolsMap: S.Schema<UpdateResponseRegionPoolsMap>;
export type UpdateResponseRulesItemFixedResponse = CreateResponseRulesItemFixedResponse;
export declare const UpdateResponseRulesItemFixedResponse: S.Schema<CreateResponseRulesItemFixedResponse>;
export type UpdateResponseRulesItemOverridesCountryPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponseRulesItemOverridesCountryPoolsMap: S.Schema<UpdateResponseRulesItemOverridesCountryPoolsMap>;
export type UpdateResponseRulesItemOverridesDefaultPoolsList = Array<string>;
export declare const UpdateResponseRulesItemOverridesDefaultPoolsList: S.Schema<UpdateResponseRulesItemOverridesDefaultPoolsList>;
export type UpdateResponseRulesItemOverridesPopPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponseRulesItemOverridesPopPoolsMap: S.Schema<UpdateResponseRulesItemOverridesPopPoolsMap>;
export type UpdateResponseRulesItemOverridesRegionPoolsMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponseRulesItemOverridesRegionPoolsMap: S.Schema<UpdateResponseRulesItemOverridesRegionPoolsMap>;
export type UpdateResponseRulesItemOverridesSessionAffinity = "none" | "cookie" | "ip_cookie" | "header";
export declare const UpdateResponseRulesItemOverridesSessionAffinity: any;
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesHeadersList = Array<string>;
export declare const UpdateResponseRulesItemOverridesSessionAffinityAttributesHeadersList: S.Schema<UpdateResponseRulesItemOverridesSessionAffinityAttributesHeadersList>;
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesSamesite = "Auto" | "Lax" | "None" | "Strict";
export declare const UpdateResponseRulesItemOverridesSessionAffinityAttributesSamesite: any;
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesSecure = "Auto" | "Always" | "Never";
export declare const UpdateResponseRulesItemOverridesSessionAffinityAttributesSecure: any;
export type UpdateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover = "none" | "temporary" | "sticky";
export declare const UpdateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover: any;
export interface UpdateResponseRulesItemOverridesSessionAffinityAttributes {
    /** Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. */
    drainDuration?: number | null;
    /** Configures the names of HTTP headers to base session affinity on when header `session_affinity` is enabled. At least one HTTP header name must be provided. To specify the exact cookies to be used, include an item in the following format: `"cookie:<cookie-name-1>,<cookie-name-2>"` (example) where everything after the colon is a comma-separated list of cookie names. Providing only `"cookie"` will result in all cookies being used. The default max number of HTTP header names that can be provided depends on your plan: 5 for Enterprise, 1 for all other plans. */
    headers?: UpdateResponseRulesItemOverridesSessionAffinityAttributesHeadersList | null;
    /** When header `session_affinity` is enabled, this option can be used to specify how HTTP headers on load balancing requests will be used. The supported values are: - `"true"`: Load balancing requests must contain *all* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. - `"false"`: Load balancing requests must contain *at least one* of the HTTP headers specified by the `headers` session affinity attribute, otherwise sessions aren't created. */
    requireAllHeaders?: boolean | null;
    /** Configures the SameSite attribute on session affinity cookie. Value "Auto" will be translated to "Lax" or "None" depending if Always Use HTTPS is enabled. Note: when using value "None", the secure attribute can not be set to "Never". */
    samesite?: UpdateResponseRulesItemOverridesSessionAffinityAttributesSamesite | null;
    /** Configures the Secure attribute on session affinity cookie. Value "Always" indicates the Secure attribute will be set in the Set-Cookie header, "Never" indicates the Secure attribute will not be set, and "Auto" will set the Secure attribute depending if Always Use HTTPS is enabled. */
    secure?: UpdateResponseRulesItemOverridesSessionAffinityAttributesSecure | null;
    /** Configures the zero-downtime failover between origins within a pool when session affinity is enabled. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. The supported values are: - `"none"`: No failover takes place for sessions pinned to the origin (default). - `"temporary"`: Traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. - `"sticky"`: The session affinity cookie is updated and subsequent requests are sent to the new origin. Note: Zero-downtime failover with sticky sessions is currently not supported for session affinity by header. */
    zeroDowntimeFailover?: UpdateResponseRulesItemOverridesSessionAffinityAttributesZeroDowntimeFailover | null;
}
export declare const UpdateResponseRulesItemOverridesSessionAffinityAttributes: S.Schema<UpdateResponseRulesItemOverridesSessionAffinityAttributes>;
export type UpdateResponseRulesItemOverridesSteeringPolicy = "off" | "geo" | "random" | "dynamic_latency" | "proximity" | "least_outstanding_requests" | "least_connections" | "";
export declare const UpdateResponseRulesItemOverridesSteeringPolicy: any;
export interface UpdateResponseRulesItemOverrides {
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateResponseRulesItemOverridesCountryPoolsMap | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: UpdateResponseRulesItemOverridesDefaultPoolsList | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateResponseLocationStrategy | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateResponseRulesItemOverridesPopPoolsMap | null;
    /** Configures pool weights. */
    randomSteering?: UpdateResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateResponseRulesItemOverridesRegionPoolsMap | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
}
export declare const UpdateResponseRulesItemOverrides: S.Schema<UpdateResponseRulesItemOverrides>;
export interface UpdateResponseRulesItem {
    /** The condition expressions to evaluate. If the condition evaluates to true, the overrides or fixed_response in this rule will be applied. An empty condition is always true. For more details on condition expressions, please see https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules/expressions. */
    condition?: string | null;
    /** Disable this specific rule. It will no longer be evaluated by this load balancer. */
    disabled?: boolean | null;
    /** A collection of fields used to directly respond to the eyeball instead of routing to a pool. If a fixed_response is supplied the rule will be marked as terminates. */
    fixedResponse?: CreateResponseRulesItemFixedResponse | null;
    /** Name of this rule. Only used for human readability. */
    name?: string | null;
    /** A collection of overrides to apply to the load balancer when this rule's condition is true. All fields are optional. */
    overrides?: UpdateResponseRulesItemOverrides | null;
    /** The order in which rules should be executed in relation to each other. Lower values are executed first. Values do not need to be sequential. If no value is provided for any rule the array order of the rules field will be used to assign a priority. */
    priority?: number | null;
    /** If this rule's condition is true, this causes rule evaluation to stop after processing this rule. */
    terminates?: boolean | null;
}
export declare const UpdateResponseRulesItem: S.Schema<UpdateResponseRulesItem>;
export type UpdateResponseRulesList = Array<UpdateResponseRulesItem>;
export declare const UpdateResponseRulesList: S.Schema<UpdateResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLoadBalancerResponse {
    id?: string | null;
    /** Controls features that modify the routing of requests to pools and origins in response to dynamic conditions, such as during the interval between active health monitoring requests. For example, zero-downtime failover occurs immediately when an origin becomes unavailable due to HTTP 521, 522, or 523 response codes. If there is another healthy origin in the same pool, the request is retried once against this alternate origin. */
    adaptiveRouting?: CreateResponseAdaptiveRouting | null;
    /** A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools. */
    countryPools?: UpdateResponseCountryPoolsMap | null;
    createdOn?: string | null;
    /** A list of pool IDs ordered by their failover priority. Pools defined here are used by default, or when region_pools are not configured for a given region. */
    defaultPools?: UpdateResponseDefaultPoolsList | null;
    /** Object description. */
    description?: string | null;
    /** Whether to enable (the default) this load balancer. */
    enabled?: boolean | null;
    /** The pool ID to use when all other pools are detected as unhealthy. */
    fallbackPool?: string | null;
    /** Controls location-based steering for non-proxied requests. See `steering_policy` to learn how steering is affected. */
    locationStrategy?: UpdateResponseLocationStrategy | null;
    modifiedOn?: string | null;
    /** The DNS hostname to associate with your Load Balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the Load Balancer will take precedence and the DNS record will not be used. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: UpdateResponseNetworksList | null;
    /** Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools. */
    popPools?: UpdateResponsePopPoolsMap | null;
    /** Whether the hostname should be gray clouded (false) or orange clouded (true). */
    proxied?: boolean | null;
    /** Configures pool weights. */
    randomSteering?: UpdateResponseRandomSteering | null;
    /** A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools. */
    regionPools?: UpdateResponseRegionPoolsMap | null;
    /** BETA Field Not General Access: A list of rules for this load balancer to execute. */
    rules?: UpdateResponseRulesList | null;
    /** Specifies the type of session affinity the load balancer should use unless specified as `"none"`. The supported types are: - `"cookie"`: On the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy, then a new origin server is calculated and used. - `"ip_cookie"`: Behaves the same as `"cookie"` except the initial origin selection is stable and based on the client's ip address. - `"header"`: On the first request to a proxied load balancer, a session key based on the configured HTTP headers (see `session_affinity_attributes.headers`) is generated, encoding the request headers used for storing in the load balancer session state which origin the request will be forwarded to. Subsequent requests to the load balancer with the same headers will be sent to the same origin server, for the duration of the session and as long as the origin server remains healthy. If the session has been idle for the duration of `session_affinity_ttl` seconds or the origin server is unhealthy, then a new origin server is calculated and used. See `headers` in `session_affinity_attributes` for additional required configuration. */
    sessionAffinity?: UpdateResponseRulesItemOverridesSessionAffinity | null;
    /** Configures attributes for session affinity. */
    sessionAffinityAttributes?: UpdateResponseRulesItemOverridesSessionAffinityAttributes | null;
    /** Time, in seconds, until a client's session expires after being created. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. The accepted ranges per `session_affinity` policy are: - `"cookie"` / `"ip_cookie"`: The current default of 23 hours will be used unless explicitly set. The accepted range of values is between [1800, 604800]. - `"header"`: The current default of 1800 seconds will be used unless explicitly set. The accepted range of values is between [30, 3600]. Note: With session affinity by header, sessions only expire after they haven't been used for the number of seconds specified. */
    sessionAffinityTtl?: number | null;
    /** Steering Policy for this load balancer. */
    steeringPolicy?: UpdateResponseRulesItemOverridesSteeringPolicy | null;
    /** Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This only applies to gray-clouded (unproxied) load balancers. */
    ttl?: number | null;
    zoneName?: string | null;
}
export declare const UpdateLoadBalancerResponse: S.Schema<UpdateLoadBalancerResponse>;
export type MonitorsUpdateRequestHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsUpdateRequestHeaderMap: S.Schema<MonitorsUpdateRequestHeaderMap>;
export type MonitorsUpdateRequestType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsUpdateRequestType: any;
export interface UpdateMonitorRequest {
    /** Identifier. */
    accountId: string;
    monitorId: string;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number;
    /** Object description. */
    description?: string;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsUpdateRequestHeaderMap;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsUpdateRequestType | (string & {});
}
export declare const UpdateMonitorRequest: S.Schema<UpdateMonitorRequest>;
export type MonitorsUpdateResponseHeaderMap = {
    [key: string]: unknown | undefined;
};
export declare const MonitorsUpdateResponseHeaderMap: S.Schema<MonitorsUpdateResponseHeaderMap>;
export type MonitorsUpdateResponseType = "http" | "https" | "tcp" | "udp_icmp" | "icmp_ping" | "smtp";
export declare const MonitorsUpdateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMonitorResponse {
    id?: string | null;
    /** Do not validate the certificate when monitor use HTTPS. This parameter is currently only valid for HTTP and HTTPS monitors. */
    allowInsecure?: boolean | null;
    /** To be marked unhealthy the monitored origin must fail this healthcheck N consecutive times. */
    consecutiveDown?: number | null;
    /** To be marked healthy the monitored origin must pass this healthcheck N consecutive times. */
    consecutiveUp?: number | null;
    createdOn?: string | null;
    /** Object description. */
    description?: string | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedBody?: string | null;
    /** The expected HTTP response code or code range of the health check. This parameter is only valid for HTTP and HTTPS monitors. */
    expectedCodes?: string | null;
    /** Follow redirects if returned by the origin. This parameter is only valid for HTTP and HTTPS monitors. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. This parameter is only valid for HTTP and HTTPS monitors. */
    header?: MonitorsUpdateResponseHeaderMap | null;
    /** The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. */
    interval?: number | null;
    /** The method to use for the health check. This defaults to 'GET' for HTTP/HTTPS based checks and 'connection_established' for TCP based health checks. */
    method?: string | null;
    modifiedOn?: string | null;
    /** The endpoint path you want to conduct a health check against. This parameter is only valid for HTTP and HTTPS monitors. */
    path?: string | null;
    /** The port number to connect to for the health check. Required for TCP, UDP, and SMTP checks. HTTP and HTTPS checks should only define the port when using a non-standard port (HTTP: default 80, HTTPS: default 443). */
    port?: number | null;
    /** Assign this monitor to emulate the specified zone while probing. This parameter is only valid for HTTP and HTTPS monitors. */
    probeZone?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP','HTTPS', 'TCP', 'ICMP-PING', 'UDP-ICMP', and 'SMTP'. */
    type?: MonitorsUpdateResponseType | null;
}
export declare const UpdateMonitorResponse: S.Schema<UpdateMonitorResponse>;
export type MonitorGroupsUpdateRequestMembersItem = MonitorGroupsCreateRequestMembersItem;
export declare const MonitorGroupsUpdateRequestMembersItem: S.Schema<MonitorGroupsCreateRequestMembersItem>;
export type MonitorGroupsUpdateRequestMembersList = Array<MonitorGroupsCreateRequestMembersItem>;
export declare const MonitorGroupsUpdateRequestMembersList: S.Schema<MonitorGroupsUpdateRequestMembersList>;
export interface UpdateMonitorGroupRequest {
    /** Identifier. */
    accountId: string;
    monitorGroupId: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsUpdateRequestMembersList;
}
export declare const UpdateMonitorGroupRequest: S.Schema<UpdateMonitorGroupRequest>;
export type MonitorGroupsUpdateResponseMembersItem = MonitorGroupsCreateResponseMembersItem;
export declare const MonitorGroupsUpdateResponseMembersItem: S.Schema<MonitorGroupsCreateResponseMembersItem>;
export type MonitorGroupsUpdateResponseMembersList = Array<MonitorGroupsCreateResponseMembersItem>;
export declare const MonitorGroupsUpdateResponseMembersList: S.Schema<MonitorGroupsUpdateResponseMembersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMonitorGroupResponse {
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    id: string;
    /** A short description of the monitor group */
    description: string;
    /** List of monitors in this group */
    members: MonitorGroupsUpdateResponseMembersList;
    /** The timestamp of when the monitor group was created */
    createdOn?: string | null;
    /** The timestamp of when the monitor group was last updated */
    modifiedOn?: string | null;
}
export declare const UpdateMonitorGroupResponse: S.Schema<UpdateMonitorGroupResponse>;
export type PoolsUpdateRequestOriginsItemHeaderHostList = Array<string>;
export declare const PoolsUpdateRequestOriginsItemHeaderHostList: S.Schema<PoolsUpdateRequestOriginsItemHeaderHostList>;
export interface PoolsUpdateRequestOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsUpdateRequestOriginsItemHeaderHostList;
}
export declare const PoolsUpdateRequestOriginsItemHeader: S.Schema<PoolsUpdateRequestOriginsItemHeader>;
export interface PoolsUpdateRequestOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsUpdateRequestOriginsItemHeader;
    /** A human-identifiable name for the origin. */
    name?: string;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number;
}
export declare const PoolsUpdateRequestOriginsItem: S.Schema<PoolsUpdateRequestOriginsItem>;
export type PoolsUpdateRequestOriginsList = Array<PoolsUpdateRequestOriginsItem>;
export declare const PoolsUpdateRequestOriginsList: S.Schema<PoolsUpdateRequestOriginsList>;
export type PoolsUpdateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsUpdateRequestCheckRegionsItem: any;
export type PoolsUpdateRequestCheckRegionsList = Array<PoolsUpdateRequestCheckRegionsItem | (string & {})>;
export declare const PoolsUpdateRequestCheckRegionsList: S.Schema<PoolsUpdateRequestCheckRegionsList>;
export type PoolsUpdateRequestLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsUpdateRequestLoadSheddingDefaultPolicy: any;
export type PoolsUpdateRequestLoadSheddingSessionPolicy = "hash";
export declare const PoolsUpdateRequestLoadSheddingSessionPolicy: any;
export interface PoolsUpdateRequestLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsUpdateRequestLoadSheddingDefaultPolicy | (string & {});
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsUpdateRequestLoadSheddingSessionPolicy | (string & {});
}
export declare const PoolsUpdateRequestLoadShedding: S.Schema<PoolsUpdateRequestLoadShedding>;
export type PoolsUpdateRequestNotificationFilterOrigin = PoolsCreateRequestNotificationFilterOrigin;
export declare const PoolsUpdateRequestNotificationFilterOrigin: S.Schema<PoolsCreateRequestNotificationFilterOrigin>;
export type PoolsUpdateRequestNotificationFilter = PoolsCreateRequestNotificationFilter;
export declare const PoolsUpdateRequestNotificationFilter: S.Schema<PoolsCreateRequestNotificationFilter>;
export type PoolsUpdateRequestOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsUpdateRequestOriginSteeringPolicy: any;
export interface PoolsUpdateRequestOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsUpdateRequestOriginSteeringPolicy | (string & {});
}
export declare const PoolsUpdateRequestOriginSteering: S.Schema<PoolsUpdateRequestOriginSteering>;
export interface UpdatePoolRequest {
    /** Identifier. */
    accountId: string;
    poolId: string;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name: string;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins: PoolsUpdateRequestOriginsList;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsUpdateRequestCheckRegionsList;
    /** A human-readable description of the pool. */
    description?: string;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsUpdateRequestLoadShedding;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsCreateRequestNotificationFilter;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsUpdateRequestOriginSteering;
}
export declare const UpdatePoolRequest: S.Schema<UpdatePoolRequest>;
export type PoolsUpdateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "SAS" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PoolsUpdateResponseCheckRegionsItem: any;
export type PoolsUpdateResponseCheckRegionsList = Array<PoolsUpdateResponseCheckRegionsItem>;
export declare const PoolsUpdateResponseCheckRegionsList: S.Schema<PoolsUpdateResponseCheckRegionsList>;
export type PoolsUpdateResponseLoadSheddingDefaultPolicy = "random" | "hash";
export declare const PoolsUpdateResponseLoadSheddingDefaultPolicy: any;
export type PoolsUpdateResponseLoadSheddingSessionPolicy = "hash";
export declare const PoolsUpdateResponseLoadSheddingSessionPolicy: any;
export interface PoolsUpdateResponseLoadShedding {
    /** The percent of traffic to shed from the pool, according to the default policy. Applies to new sessions and traffic without session affinity. */
    defaultPercent?: number | null;
    /** The default policy to use when load shedding. A random policy randomly sheds a given percent of requests. A hash policy computes a hash over the CF-Connecting-IP address and sheds all requests originating from a percent of IPs. */
    defaultPolicy?: PoolsUpdateResponseLoadSheddingDefaultPolicy | null;
    /** The percent of existing sessions to shed from the pool, according to the session policy. */
    sessionPercent?: number | null;
    /** Only the hash policy is supported for existing sessions (to avoid exponential decay). */
    sessionPolicy?: PoolsUpdateResponseLoadSheddingSessionPolicy | null;
}
export declare const PoolsUpdateResponseLoadShedding: S.Schema<PoolsUpdateResponseLoadShedding>;
export type PoolsUpdateResponseNetworksList = Array<string>;
export declare const PoolsUpdateResponseNetworksList: S.Schema<PoolsUpdateResponseNetworksList>;
export type PoolsUpdateResponseNotificationFilterOrigin = PoolsBulkEditResultItemNotificationFilterOrigin;
export declare const PoolsUpdateResponseNotificationFilterOrigin: S.Schema<PoolsBulkEditResultItemNotificationFilterOrigin>;
export type PoolsUpdateResponseNotificationFilter = PoolsBulkEditResultItemNotificationFilter;
export declare const PoolsUpdateResponseNotificationFilter: S.Schema<PoolsBulkEditResultItemNotificationFilter>;
export type PoolsUpdateResponseOriginSteeringPolicy = "random" | "hash" | "least_outstanding_requests" | "least_connections";
export declare const PoolsUpdateResponseOriginSteeringPolicy: any;
export interface PoolsUpdateResponseOriginSteering {
    /** The type of origin steering policy to use. */
    policy?: PoolsUpdateResponseOriginSteeringPolicy | null;
}
export declare const PoolsUpdateResponseOriginSteering: S.Schema<PoolsUpdateResponseOriginSteering>;
export type PoolsUpdateResponseOriginsItemHeaderHostList = Array<string>;
export declare const PoolsUpdateResponseOriginsItemHeaderHostList: S.Schema<PoolsUpdateResponseOriginsItemHeaderHostList>;
export interface PoolsUpdateResponseOriginsItemHeader {
    /** The 'Host' header allows to override the hostname set in the HTTP request. Current support is 1 'Host' header override per origin. */
    host?: PoolsUpdateResponseOriginsItemHeaderHostList | null;
}
export declare const PoolsUpdateResponseOriginsItemHeader: S.Schema<PoolsUpdateResponseOriginsItemHeader>;
export interface PoolsUpdateResponseOriginsItem {
    /** The IP address (IPv4 or IPv6) of the origin, or its publicly addressable hostname. Hostnames entered here should resolve directly to the origin, and not be a hostname proxied by Cloudflare. To set an internal/reserved address, virtual_network_id must also be set. */
    address?: string | null;
    /** This field shows up only if the origin is disabled. This field is set with the time the origin was disabled. */
    disabledAt?: string | null;
    /** Whether to enable (the default) this origin within the pool. Disabled origins will not receive traffic and are excluded from health checks. The origin will only be disabled for the current pool. */
    enabled?: boolean | null;
    /** Whether to flatten CNAME records for this origin, resolving them to A/AAAA records before returning to the client. When true (the default), the director resolves CNAME addresses to their underlying A/AAAA records. When false, the origin address is returned as a raw CNAME record without resolution. This setting mirrors the DNS API record flatten_cname setting. */
    flattenCname?: boolean | null;
    /** The request header is used to pass additional information with an HTTP request. Currently supported header is 'Host'. */
    header?: PoolsUpdateResponseOriginsItemHeader | null;
    /** A human-identifiable name for the origin. */
    name?: string | null;
    /** The port for upstream connections. A value of 0 means the default port for the protocol will be used. */
    port?: number | null;
    /** The virtual network subnet ID the origin belongs in. Virtual network must also belong to the account. */
    virtualNetworkId?: string | null;
    /** The weight of this origin relative to other origins in the pool. Based on the configured weight the total traffic is distributed among origins within the pool. */
    weight?: number | null;
}
export declare const PoolsUpdateResponseOriginsItem: S.Schema<PoolsUpdateResponseOriginsItem>;
export type PoolsUpdateResponseOriginsList = Array<PoolsUpdateResponseOriginsItem>;
export declare const PoolsUpdateResponseOriginsList: S.Schema<PoolsUpdateResponseOriginsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePoolResponse {
    id?: string | null;
    /** A list of regions from which to run health checks. Null means every Cloudflare data center. */
    checkRegions?: PoolsUpdateResponseCheckRegionsList | null;
    createdOn?: string | null;
    /** A human-readable description of the pool. */
    description?: string | null;
    /** This field shows up only if the pool is disabled. This field is set with the time the pool was disabled at. */
    disabledAt?: string | null;
    /** Whether to enable (the default) or disable this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). */
    enabled?: boolean | null;
    /** The latitude of the data center containing the origins used in this pool in decimal degrees. If this is set, longitude must also be set. */
    latitude?: number | null;
    /** Configures load shedding policies and percentages for the pool. */
    loadShedding?: PoolsUpdateResponseLoadShedding | null;
    /** The longitude of the data center containing the origins used in this pool in decimal degrees. If this is set, latitude must also be set. */
    longitude?: number | null;
    /** The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and will failover to the next available pool. */
    minimumOrigins?: number | null;
    modifiedOn?: string | null;
    /** The ID of the Monitor to use for checking the health of origins within this pool. */
    monitor?: string | null;
    /** The ID of the Monitor Group to use for checking the health of origins within this pool. */
    monitorGroup?: string | null;
    /** A short name (tag) for the pool. Only alphanumeric characters, hyphens, and underscores are allowed. */
    name?: string | null;
    /** List of networks where Load Balancer or Pool is enabled. */
    networks?: PoolsUpdateResponseNetworksList | null;
    /** This field is now deprecated. It has been moved to Cloudflare's Centralized Notification service https://developers.cloudflare.com/fundamentals/notifications/. The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list. */
    notificationEmail?: string | null;
    /** Filter pool and origin health notifications by resource type or health status. Use null to reset. */
    notificationFilter?: PoolsBulkEditResultItemNotificationFilter | null;
    /** Configures origin steering for the pool. Controls how origins are selected for new sessions and traffic without session affinity. */
    originSteering?: PoolsUpdateResponseOriginSteering | null;
    /** The list of origins within this pool. Traffic directed at this pool is balanced across all currently healthy origins, provided the pool itself is healthy. */
    origins?: PoolsUpdateResponseOriginsList | null;
}
export declare const UpdatePoolResponse: S.Schema<UpdatePoolResponse>;
export type BulkPatchPoolsError = CloudflareOpError;
/** Apply changes to a number of existing pools, overwriting the supplied properties. Pools are ordered by ascending `name`. Returns the list of affected pools. Supports the standard pagination query parameters, either `limit`/`offset` or `per_page`/`page`. */
export declare const bulkPatchPools: API.PaginatedOperationMethod<BulkPatchPoolsRequest, BulkPatchPoolsResponse, BulkPatchPoolsError, CloudflareOpContext, PoolsBulkEditResultItem>;
export type CreateLoadBalancerError = LoadBalancingNotEnabledForZone | Forbidden | CloudflareOpError;
/** Create a new load balancer. */
export declare const createLoadBalancer: API.OperationMethod<CreateLoadBalancerRequest, CreateLoadBalancerResponse, CreateLoadBalancerError, CloudflareOpContext>;
export type CreateMonitorError = MonitorIntervalOutOfRange | Forbidden | CloudflareOpError;
/** Create a configured monitor. */
export declare const createMonitor: API.OperationMethod<CreateMonitorRequest, CreateMonitorResponse, CreateMonitorError, CloudflareOpContext>;
export type CreateMonitorGroupError = MonitorGroupsNotEnabled | Forbidden | CloudflareOpError;
/** Create a new monitor group. */
export declare const createMonitorGroup: API.OperationMethod<CreateMonitorGroupRequest, CreateMonitorGroupResponse, CreateMonitorGroupError, CloudflareOpContext>;
export type CreateMonitorPreviewError = CloudflareOpError;
/** Preview pools using the specified monitor with provided monitor details. The returned preview_id can be used in the preview endpoint to retrieve the results. */
export declare const createMonitorPreview: API.OperationMethod<CreateMonitorPreviewRequest, CreateMonitorPreviewResponse, CreateMonitorPreviewError, CloudflareOpContext>;
export type CreatePoolError = PoolAccessFailed | Forbidden | CloudflareOpError;
/** Create a new pool. */
export declare const createPool: API.OperationMethod<CreatePoolRequest, CreatePoolResponse, CreatePoolError, CloudflareOpContext>;
export type CreatePoolHealthError = CloudflareOpError;
/** Preview pool health using provided monitor details. The returned preview_id can be used in the preview endpoint to retrieve the results. */
export declare const createPoolHealth: API.OperationMethod<CreatePoolHealthRequest, CreatePoolHealthResponse, CreatePoolHealthError, CloudflareOpContext>;
export type DeleteLoadBalancerError = LoadBalancerNotFound | Forbidden | CloudflareOpError;
/** Delete a configured load balancer. */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteLoadBalancerRequest, DeleteLoadBalancerResponse, DeleteLoadBalancerError, CloudflareOpContext>;
export type DeleteMonitorError = MonitorNotFound | MonitorInUse | Forbidden | CloudflareOpError;
/** Delete a configured monitor. */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorRequest, DeleteMonitorResponse, DeleteMonitorError, CloudflareOpContext>;
export type DeleteMonitorGroupError = MonitorGroupNotFound | MonitorGroupInUse | Forbidden | CloudflareOpError;
/** Delete a configured monitor group. */
export declare const deleteMonitorGroup: API.OperationMethod<DeleteMonitorGroupRequest, DeleteMonitorGroupResponse, DeleteMonitorGroupError, CloudflareOpContext>;
export type DeletePoolError = PoolNotFound | PoolInUse | Forbidden | CloudflareOpError;
/** Delete a configured pool. */
export declare const deletePool: API.OperationMethod<DeletePoolRequest, DeletePoolResponse, DeletePoolError, CloudflareOpContext>;
export type GetLoadBalancerError = LoadBalancerNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured load balancer. */
export declare const getLoadBalancer: API.OperationMethod<GetLoadBalancerRequest, GetLoadBalancerResponse, GetLoadBalancerError, CloudflareOpContext>;
export type GetMonitorError = MonitorNotFound | Forbidden | CloudflareOpError;
/** List a single configured monitor for an account. */
export declare const getMonitor: API.OperationMethod<GetMonitorRequest, GetMonitorResponse, GetMonitorError, CloudflareOpContext>;
export type GetMonitorGroupError = MonitorGroupNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured monitor group. */
export declare const getMonitorGroup: API.OperationMethod<GetMonitorGroupRequest, GetMonitorGroupResponse, GetMonitorGroupError, CloudflareOpContext>;
export type GetMonitorGroupReferenceError = CloudflareOpError;
/** Get the list of resources that reference the provided monitor group. */
export declare const getMonitorGroupReference: API.PaginatedOperationMethod<GetMonitorGroupReferenceRequest, GetMonitorGroupReferenceResponse, GetMonitorGroupReferenceError, CloudflareOpContext, MonitorGroupsReferencesGetResultItem>;
export type GetMonitorReferenceError = CloudflareOpError;
/** Get the list of resources that reference the provided monitor. */
export declare const getMonitorReference: API.PaginatedOperationMethod<GetMonitorReferenceRequest, GetMonitorReferenceResponse, GetMonitorReferenceError, CloudflareOpContext, MonitorsReferencesGetResultItem>;
export type GetPoolError = PoolNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured pool. */
export declare const getPool: API.OperationMethod<GetPoolRequest, GetPoolResponse, GetPoolError, CloudflareOpContext>;
export type GetPoolHealthError = CloudflareOpError;
/** Fetch the latest pool health status for a single pool. */
export declare const getPoolHealth: API.OperationMethod<GetPoolHealthRequest, GetPoolHealthResponse, GetPoolHealthError, CloudflareOpContext>;
export type GetPoolReferenceError = CloudflareOpError;
/** Get the list of resources that reference the provided pool. */
export declare const getPoolReference: API.PaginatedOperationMethod<GetPoolReferenceRequest, GetPoolReferenceResponse, GetPoolReferenceError, CloudflareOpContext, PoolsReferencesGetResultItem>;
export type GetPreviewError = CloudflareOpError;
/** Get the result of a previous preview operation using the provided preview_id. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, GetPreviewResponse, GetPreviewError, CloudflareOpContext>;
export type GetRegionError = CloudflareOpError;
/** Get a single region mapping. */
export declare const getRegion: API.OperationMethod<GetRegionRequest, GetRegionResponse, GetRegionError, CloudflareOpContext>;
export type ListLoadBalancersError = CloudflareOpError;
/** List configured load balancers. */
export declare const listLoadBalancers: API.PaginatedOperationMethod<ListLoadBalancersRequest, ListLoadBalancersResponse, ListLoadBalancersError, CloudflareOpContext, ListResultItem>;
export type ListMonitorGroupsError = CloudflareOpError;
/** List configured monitor groups. */
export declare const listMonitorGroups: API.PaginatedOperationMethod<ListMonitorGroupsRequest, ListMonitorGroupsResponse, ListMonitorGroupsError, CloudflareOpContext, MonitorGroupsListResultItem>;
export type ListMonitorsError = CloudflareOpError;
/** List configured monitors for an account. */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsRequest, ListMonitorsResponse, ListMonitorsError, CloudflareOpContext, MonitorsListResultItem>;
export type ListPoolsError = CloudflareOpError;
/** List configured pools. */
export declare const listPools: API.PaginatedOperationMethod<ListPoolsRequest, ListPoolsResponse, ListPoolsError, CloudflareOpContext, PoolsListResultItem>;
export type ListRegionsError = CloudflareOpError;
/** List all region mappings. */
export declare const listRegions: API.OperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, CloudflareOpContext>;
export type ListSearchesError = CloudflareOpError;
/** Search for Load Balancing resources. */
export declare const listSearches: API.OperationMethod<ListSearchesRequest, ListSearchesResponse, ListSearchesError, CloudflareOpContext>;
export type PatchLoadBalancerError = CloudflareOpError;
/** Apply changes to an existing load balancer, overwriting the supplied properties. */
export declare const patchLoadBalancer: API.OperationMethod<PatchLoadBalancerRequest, PatchLoadBalancerResponse, PatchLoadBalancerError, CloudflareOpContext>;
export type PatchMonitorError = CloudflareOpError;
/** Apply changes to an existing monitor, overwriting the supplied properties. */
export declare const patchMonitor: API.OperationMethod<PatchMonitorRequest, PatchMonitorResponse, PatchMonitorError, CloudflareOpContext>;
export type PatchMonitorGroupError = CloudflareOpError;
/** Apply changes to an existing monitor group, overwriting the supplied properties. */
export declare const patchMonitorGroup: API.OperationMethod<PatchMonitorGroupRequest, PatchMonitorGroupResponse, PatchMonitorGroupError, CloudflareOpContext>;
export type PatchPoolError = CloudflareOpError;
/** Apply changes to an existing pool, overwriting the supplied properties. */
export declare const patchPool: API.OperationMethod<PatchPoolRequest, PatchPoolResponse, PatchPoolError, CloudflareOpContext>;
export type UpdateLoadBalancerError = LoadBalancerNotFound | LoadBalancingNotEnabledForZone | Forbidden | CloudflareOpError;
/** Update a configured load balancer. */
export declare const updateLoadBalancer: API.OperationMethod<UpdateLoadBalancerRequest, UpdateLoadBalancerResponse, UpdateLoadBalancerError, CloudflareOpContext>;
export type UpdateMonitorError = MonitorNotFound | MonitorIntervalOutOfRange | Forbidden | CloudflareOpError;
/** Modify a configured monitor. */
export declare const updateMonitor: API.OperationMethod<UpdateMonitorRequest, UpdateMonitorResponse, UpdateMonitorError, CloudflareOpContext>;
export type UpdateMonitorGroupError = MonitorGroupNotFound | MonitorGroupsNotEnabled | Forbidden | CloudflareOpError;
/** Modify a configured monitor group. */
export declare const updateMonitorGroup: API.OperationMethod<UpdateMonitorGroupRequest, UpdateMonitorGroupResponse, UpdateMonitorGroupError, CloudflareOpContext>;
export type UpdatePoolError = PoolNotFound | PoolAccessFailed | Forbidden | CloudflareOpError;
/** Modify a configured pool. */
export declare const updatePool: API.OperationMethod<UpdatePoolRequest, UpdatePoolResponse, UpdatePoolError, CloudflareOpContext>;
//# sourceMappingURL=load_balancers.d.ts.map