import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface DeleteUrlNormalizationRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export declare const DeleteUrlNormalizationRequest: S.Schema<DeleteUrlNormalizationRequest>;
export interface DeleteUrlNormalizationResponse {
}
export declare const DeleteUrlNormalizationResponse: S.Schema<DeleteUrlNormalizationResponse>;
export interface GetUrlNormalizationRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export declare const GetUrlNormalizationRequest: S.Schema<GetUrlNormalizationRequest>;
export type GetResponseScope = "incoming" | "both" | "none";
export declare const GetResponseScope: any;
export type GetResponseType = "cloudflare" | "rfc3986";
export declare const GetResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUrlNormalizationResponse {
    /** The scope of the URL normalization. */
    scope: GetResponseScope;
    /** The type of URL normalization performed by Cloudflare. */
    type: GetResponseType;
}
export declare const GetUrlNormalizationResponse: S.Schema<GetUrlNormalizationResponse>;
export type UpdateRequestScope = "incoming" | "both" | "none";
export declare const UpdateRequestScope: any;
export type UpdateRequestType = "cloudflare" | "rfc3986";
export declare const UpdateRequestType: any;
export interface PutUrlNormalizationRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    /** The scope of the URL normalization. */
    scope: UpdateRequestScope | (string & {});
    /** The type of URL normalization performed by Cloudflare. */
    type: UpdateRequestType | (string & {});
}
export declare const PutUrlNormalizationRequest: S.Schema<PutUrlNormalizationRequest>;
export type UpdateResponseScope = "incoming" | "both" | "none";
export declare const UpdateResponseScope: any;
export type UpdateResponseType = "cloudflare" | "rfc3986";
export declare const UpdateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutUrlNormalizationResponse {
    /** The scope of the URL normalization. */
    scope: UpdateResponseScope;
    /** The type of URL normalization performed by Cloudflare. */
    type: UpdateResponseType;
}
export declare const PutUrlNormalizationResponse: S.Schema<PutUrlNormalizationResponse>;
export type DeleteUrlNormalizationError = Forbidden | CloudflareOpError;
/** Deletes the URL Normalization settings. */
export declare const deleteUrlNormalization: API.OperationMethod<DeleteUrlNormalizationRequest, DeleteUrlNormalizationResponse, DeleteUrlNormalizationError, CloudflareOpContext>;
export type GetUrlNormalizationError = Forbidden | CloudflareOpError;
/** Fetches the current URL Normalization settings. */
export declare const getUrlNormalization: API.OperationMethod<GetUrlNormalizationRequest, GetUrlNormalizationResponse, GetUrlNormalizationError, CloudflareOpContext>;
export type PutUrlNormalizationError = Forbidden | CloudflareOpError;
/** Updates the URL Normalization settings. */
export declare const putUrlNormalization: API.OperationMethod<PutUrlNormalizationRequest, PutUrlNormalizationResponse, PutUrlNormalizationError, CloudflareOpContext>;
//# sourceMappingURL=url_normalization.d.ts.map