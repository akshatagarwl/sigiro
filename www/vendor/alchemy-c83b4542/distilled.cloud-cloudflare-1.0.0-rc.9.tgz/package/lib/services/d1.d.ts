import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DatabaseAlreadyExists_base: S.Class<DatabaseAlreadyExists, S.TaggedStruct<"DatabaseAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DatabaseAlreadyExists extends /*@__PURE__*/ DatabaseAlreadyExists_base {
}
declare const DatabaseNotFound_base: S.Class<DatabaseNotFound, S.TaggedStruct<"DatabaseNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DatabaseNotFound extends /*@__PURE__*/ DatabaseNotFound_base {
}
declare const InternalError_base: S.Class<InternalError, S.TaggedStruct<"InternalError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalError extends /*@__PURE__*/ InternalError_base {
}
declare const InvalidObjectIdentifier_base: S.Class<InvalidObjectIdentifier, S.TaggedStruct<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const InvalidProperty_base: S.Class<InvalidProperty, S.TaggedStruct<"InvalidProperty", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidProperty extends /*@__PURE__*/ InvalidProperty_base {
}
declare const InvalidRequest_base: S.Class<InvalidRequest, S.TaggedStruct<"InvalidRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequest extends /*@__PURE__*/ InvalidRequest_base {
}
declare const NoHistoryAvailable_base: S.Class<NoHistoryAvailable, S.TaggedStruct<"NoHistoryAvailable", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoHistoryAvailable extends /*@__PURE__*/ NoHistoryAvailable_base {
}
declare const TimestampTooOld_base: S.Class<TimestampTooOld, S.TaggedStruct<"TimestampTooOld", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TimestampTooOld extends /*@__PURE__*/ TimestampTooOld_base {
}
declare const UnknownError_base: S.Class<UnknownError, S.TaggedStruct<"UnknownError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnknownError extends /*@__PURE__*/ UnknownError_base {
}
export type DatabaseCreateRequestJurisdiction = "eu" | "fedramp";
export declare const DatabaseCreateRequestJurisdiction: any;
export type DatabaseCreateRequestPrimaryLocationHint = "wnam" | "enam" | "weur" | "eeur" | "apac" | "oc";
export declare const DatabaseCreateRequestPrimaryLocationHint: any;
export type DatabaseCreateRequestReadReplicationMode = "auto" | "disabled";
export declare const DatabaseCreateRequestReadReplicationMode: any;
export interface DatabaseCreateRequestReadReplication {
    /** The read replication mode for the database. Use 'auto' to create replicas and allow D1 automatically place them around the world, or 'disabled' to not use any database replicas (it can take a few hours for all replicas to be deleted). */
    mode: DatabaseCreateRequestReadReplicationMode | (string & {});
}
export declare const DatabaseCreateRequestReadReplication: S.Schema<DatabaseCreateRequestReadReplication>;
export interface CreateDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database name. */
    name: string;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseCreateRequestJurisdiction | (string & {});
    /** Specify the region to create the D1 primary, if available. If this option is omitted, the D1 will be created as close as possible to the current user. */
    primaryLocationHint?: DatabaseCreateRequestPrimaryLocationHint | (string & {});
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseCreateRequestReadReplication;
}
export declare const CreateDatabaseRequest: S.Schema<CreateDatabaseRequest>;
export type DatabaseCreateResponseJurisdiction = "eu" | "fedramp";
export declare const DatabaseCreateResponseJurisdiction: any;
export type DatabaseCreateResponseReadReplicationMode = "auto" | "disabled";
export declare const DatabaseCreateResponseReadReplicationMode: any;
export interface DatabaseCreateResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseCreateResponseReadReplicationMode;
}
export declare const DatabaseCreateResponseReadReplication: S.Schema<DatabaseCreateResponseReadReplication>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseCreateResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseCreateResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export declare const CreateDatabaseResponse: S.Schema<CreateDatabaseResponse>;
export interface DeleteDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
}
export declare const DeleteDatabaseRequest: S.Schema<DeleteDatabaseRequest>;
export type DeleteDatabaseResponse = unknown;
export declare const DeleteDatabaseResponse: S.Schema<DeleteDatabaseResponse>;
export type DatabaseExportRequestOutputFormat = "polling";
export declare const DatabaseExportRequestOutputFormat: any;
export type DatabaseExportRequestDumpOptionsTablesList = Array<string>;
export declare const DatabaseExportRequestDumpOptionsTablesList: S.Schema<DatabaseExportRequestDumpOptionsTablesList>;
export interface DatabaseExportRequestDumpOptions {
    /** Export only the table definitions, not their contents */
    noData?: boolean;
    /** Export only each table's contents, not its definition */
    noSchema?: boolean;
    /** Filter the export to just one or more tables. Passing an empty array is the same as not passing anything and means: export all tables. */
    tables?: DatabaseExportRequestDumpOptionsTablesList;
}
export declare const DatabaseExportRequestDumpOptions: S.Schema<DatabaseExportRequestDumpOptions>;
export interface ExportDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Specifies that you will poll this endpoint until the export completes */
    outputFormat: DatabaseExportRequestOutputFormat | (string & {});
    /** To poll an in-progress export, provide the current bookmark (returned by your first polling response) */
    currentBookmark?: string;
    dumpOptions?: DatabaseExportRequestDumpOptions;
}
export declare const ExportDatabaseRequest: S.Schema<ExportDatabaseRequest>;
export type DatabaseExportResponseMessagesList = Array<string>;
export declare const DatabaseExportResponseMessagesList: S.Schema<DatabaseExportResponseMessagesList>;
export interface DatabaseExportResponseResult {
    /** The generated SQL filename. */
    filename?: string | null;
    /** The URL to download the exported SQL. Available for one hour. */
    signedUrl?: string | null;
}
export declare const DatabaseExportResponseResult: S.Schema<DatabaseExportResponseResult>;
export type DatabaseExportResponseStatus = "complete" | "error";
export declare const DatabaseExportResponseStatus: any;
export type DatabaseExportResponseType = "export";
export declare const DatabaseExportResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ExportDatabaseResponse {
    /** The current time-travel bookmark for your D1, used to poll for updates. Will not change for the duration of the export task. */
    atBookmark?: string | null;
    /** Only present when status = 'error'. Contains the error message. */
    error?: string | null;
    /** Logs since the last time you polled */
    messages?: DatabaseExportResponseMessagesList | null;
    /** Only present when status = 'complete' */
    result?: DatabaseExportResponseResult | null;
    status?: DatabaseExportResponseStatus | null;
    success?: boolean | null;
    type?: DatabaseExportResponseType | null;
}
export declare const ExportDatabaseResponse: S.Schema<ExportDatabaseResponse>;
export interface GetBookmarkDatabaseTimeTravelRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** An optional ISO 8601 timestamp. If provided, returns the nearest available bookmark at or before this timestamp. If omitted, returns the current bookmark. */
    timestamp?: string;
}
export declare const GetBookmarkDatabaseTimeTravelRequest: S.Schema<GetBookmarkDatabaseTimeTravelRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBookmarkDatabaseTimeTravelResponse {
    /** A bookmark representing a specific state of the database at a specific point in time. */
    bookmark?: string | null;
}
export declare const GetBookmarkDatabaseTimeTravelResponse: S.Schema<GetBookmarkDatabaseTimeTravelResponse>;
export type DatabaseGetRequestFields = "uuid" | "name" | "created_at" | "version" | "jurisdiction" | "num_tables" | "file_size" | "running_in_region" | "read_replication";
export declare const DatabaseGetRequestFields: any;
export type DatabaseGetRequestFieldsList = Array<DatabaseGetRequestFields | (string & {})>;
export declare const DatabaseGetRequestFieldsList: S.Schema<DatabaseGetRequestFieldsList>;
export interface GetDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Comma-separated list of fields to include in the response. When omitted, */
    fields?: DatabaseGetRequestFieldsList;
}
export declare const GetDatabaseRequest: S.Schema<GetDatabaseRequest>;
export type DatabaseGetResponseJurisdiction = "eu" | "fedramp";
export declare const DatabaseGetResponseJurisdiction: any;
export type DatabaseGetResponseReadReplicationMode = "auto" | "disabled";
export declare const DatabaseGetResponseReadReplicationMode: any;
export interface DatabaseGetResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseGetResponseReadReplicationMode;
}
export declare const DatabaseGetResponseReadReplication: S.Schema<DatabaseGetResponseReadReplication>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseGetResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseGetResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export declare const GetDatabaseResponse: S.Schema<GetDatabaseResponse>;
export type DatabaseImportRequestAction = "init" | "ingest" | "poll";
export declare const DatabaseImportRequestAction: any;
export interface ImportDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Indicates you have a new SQL file to upload. */
    action: DatabaseImportRequestAction | (string & {});
    /** Required when action is 'init' or 'ingest'. An md5 hash of the file you're uploading. Used to check if it already exists, and validate its contents before ingesting. */
    etag?: string;
    /** The filename you have successfully uploaded. */
    filename?: string;
    /** This identifies the currently-running import, checking its status. */
    currentBookmark?: string;
}
export declare const ImportDatabaseRequest: S.Schema<ImportDatabaseRequest>;
export type DatabaseImportResponseMessagesList = Array<string>;
export declare const DatabaseImportResponseMessagesList: S.Schema<DatabaseImportResponseMessagesList>;
export type DatabaseImportResponseResultMetaServedByRegion = "WNAM" | "ENAM" | "WEUR" | "EEUR" | "APAC" | "OC";
export declare const DatabaseImportResponseResultMetaServedByRegion: any;
export interface DatabaseImportResponseResultMetaTimings {
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    sqlDurationMs?: number | null;
}
export declare const DatabaseImportResponseResultMetaTimings: S.Schema<DatabaseImportResponseResultMetaTimings>;
export interface DatabaseImportResponseResultMeta {
    /** Denotes if the database has been altered in some way, like deleting rows. */
    changedDb?: boolean | null;
    /** Rough indication of how many rows were modified by the query, as provided by SQLite's `sqlite3_total_changes()`. */
    changes?: number | null;
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    duration?: number | null;
    /** The row ID of the last inserted row in a table with an `INTEGER PRIMARY KEY` as provided by SQLite. Tables created with `WITHOUT ROWID` do not populate this. */
    lastRowId?: number | null;
    /** Number of rows read during the SQL query execution, including indices (not all rows are necessarily returned). */
    rowsRead?: number | null;
    /** Number of rows written during the SQL query execution, including indices. */
    rowsWritten?: number | null;
    /** The three letters airport code of the colo that handled the query. */
    servedByColo?: string | null;
    /** Denotes if the query has been handled by the database primary instance. */
    servedByPrimary?: boolean | null;
    /** Region location hint of the database instance that handled the query. */
    servedByRegion?: DatabaseImportResponseResultMetaServedByRegion | null;
    /** Size of the database after the query committed, in bytes. */
    sizeAfter?: number | null;
    /** Various durations for the query. */
    timings?: DatabaseImportResponseResultMetaTimings | null;
}
export declare const DatabaseImportResponseResultMeta: S.Schema<DatabaseImportResponseResultMeta>;
export interface DatabaseImportResponseResult {
    /** The time-travel bookmark if you need restore your D1 to directly after the import succeeded. */
    finalBookmark?: string | null;
    meta?: DatabaseImportResponseResultMeta | null;
    /** The total number of queries that were executed during the import. */
    numQueries?: number | null;
}
export declare const DatabaseImportResponseResult: S.Schema<DatabaseImportResponseResult>;
export type DatabaseImportResponseStatus = "complete" | "error";
export declare const DatabaseImportResponseStatus: any;
export type DatabaseImportResponseType = "import";
export declare const DatabaseImportResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ImportDatabaseResponse {
    /** The current time-travel bookmark for your D1, used to poll for updates. Will not change for the duration of the import. Only returned if an import process is currently running or recently finished. */
    atBookmark?: string | null;
    /** Only present when status = 'error'. Contains the error message that prevented the import from succeeding. */
    error?: string | null;
    /** Derived from the database ID and etag, to use in avoiding repeated uploads. Only returned when for the 'init' action. */
    filename?: string | null;
    /** Logs since the last time you polled */
    messages?: DatabaseImportResponseMessagesList | null;
    /** Only present when status = 'complete' */
    result?: DatabaseImportResponseResult | null;
    status?: DatabaseImportResponseStatus | null;
    success?: boolean | null;
    type?: DatabaseImportResponseType | null;
    /** The R2 presigned URL to use for uploading. Only returned when for the 'init' action. */
    uploadUrl?: string | null;
}
export declare const ImportDatabaseResponse: S.Schema<ImportDatabaseResponse>;
export interface ListDatabasesRequest {
    /** Account identifier tag. */
    accountId: string;
    /** a database name to search for. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export declare const ListDatabasesRequest: S.Schema<ListDatabasesRequest>;
export type DatabaseListResultItemJurisdiction = "eu" | "fedramp";
export declare const DatabaseListResultItemJurisdiction: any;
export interface DatabaseListResultItem {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseListResultItemJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export declare const DatabaseListResultItem: S.Schema<DatabaseListResultItem>;
export type DatabaseListResultList = Array<DatabaseListResultItem>;
export declare const DatabaseListResultList: S.Schema<DatabaseListResultList>;
export interface ListDatabasesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatabaseListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDatabasesResponse: S.Schema<ListDatabasesResponse>;
export type DatabaseEditRequestReadReplicationMode = "auto" | "disabled";
export declare const DatabaseEditRequestReadReplicationMode: any;
export interface DatabaseEditRequestReadReplication {
    /** The read replication mode for the database. Use 'auto' to create replicas and allow D1 automatically place them around the world, or 'disabled' to not use any database replicas (it can take a few hours for all replicas to be deleted). */
    mode: DatabaseEditRequestReadReplicationMode | (string & {});
}
export declare const DatabaseEditRequestReadReplication: S.Schema<DatabaseEditRequestReadReplication>;
export interface PatchDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseEditRequestReadReplication;
}
export declare const PatchDatabaseRequest: S.Schema<PatchDatabaseRequest>;
export type DatabaseEditResponseJurisdiction = "eu" | "fedramp";
export declare const DatabaseEditResponseJurisdiction: any;
export type DatabaseEditResponseReadReplicationMode = "auto" | "disabled";
export declare const DatabaseEditResponseReadReplicationMode: any;
export interface DatabaseEditResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseEditResponseReadReplicationMode;
}
export declare const DatabaseEditResponseReadReplication: S.Schema<DatabaseEditResponseReadReplication>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseEditResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseEditResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export declare const PatchDatabaseResponse: S.Schema<PatchDatabaseResponse>;
export type DatabaseQueryRequestParamsList = Array<unknown>;
export declare const DatabaseQueryRequestParamsList: S.Schema<DatabaseQueryRequestParamsList>;
export type DatabaseQueryRequestBatchItemParamsList = Array<unknown>;
export declare const DatabaseQueryRequestBatchItemParamsList: S.Schema<DatabaseQueryRequestBatchItemParamsList>;
export interface DatabaseQueryRequestBatchItem {
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql: string;
    params?: DatabaseQueryRequestBatchItemParamsList;
}
export declare const DatabaseQueryRequestBatchItem: S.Schema<DatabaseQueryRequestBatchItem>;
export type DatabaseQueryRequestBatchList = Array<DatabaseQueryRequestBatchItem>;
export declare const DatabaseQueryRequestBatchList: S.Schema<DatabaseQueryRequestBatchList>;
export interface QueryDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql?: string;
    params?: DatabaseQueryRequestParamsList;
    batch?: DatabaseQueryRequestBatchList;
}
export declare const QueryDatabaseRequest: S.Schema<QueryDatabaseRequest>;
export type DatabaseQueryResultItemMetaServedByRegion = "WNAM" | "ENAM" | "WEUR" | "EEUR" | "APAC" | "OC";
export declare const DatabaseQueryResultItemMetaServedByRegion: any;
export type DatabaseQueryResultItemMetaTimings = DatabaseImportResponseResultMetaTimings;
export declare const DatabaseQueryResultItemMetaTimings: S.Schema<DatabaseImportResponseResultMetaTimings>;
export interface DatabaseQueryResultItemMeta {
    /** Denotes if the database has been altered in some way, like deleting rows. */
    changedDb?: boolean | null;
    /** Rough indication of how many rows were modified by the query, as provided by SQLite's `sqlite3_total_changes()`. */
    changes?: number | null;
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    duration?: number | null;
    /** The row ID of the last inserted row in a table with an `INTEGER PRIMARY KEY` as provided by SQLite. Tables created with `WITHOUT ROWID` do not populate this. */
    lastRowId?: number | null;
    /** Number of rows read during the SQL query execution, including indices (not all rows are necessarily returned). */
    rowsRead?: number | null;
    /** Number of rows written during the SQL query execution, including indices. */
    rowsWritten?: number | null;
    /** The three letters airport code of the colo that handled the query. */
    servedByColo?: string | null;
    /** Denotes if the query has been handled by the database primary instance. */
    servedByPrimary?: boolean | null;
    /** Region location hint of the database instance that handled the query. */
    servedByRegion?: DatabaseQueryResultItemMetaServedByRegion | null;
    /** Size of the database after the query committed, in bytes. */
    sizeAfter?: number | null;
    /** Various durations for the query. */
    timings?: DatabaseImportResponseResultMetaTimings | null;
}
export declare const DatabaseQueryResultItemMeta: S.Schema<DatabaseQueryResultItemMeta>;
export type DatabaseQueryResultItemResultsList = Array<unknown>;
export declare const DatabaseQueryResultItemResultsList: S.Schema<DatabaseQueryResultItemResultsList>;
export interface DatabaseQueryResultItem {
    meta?: DatabaseQueryResultItemMeta | null;
    results?: DatabaseQueryResultItemResultsList | null;
    success?: boolean | null;
}
export declare const DatabaseQueryResultItem: S.Schema<DatabaseQueryResultItem>;
export type DatabaseQueryResultList = Array<DatabaseQueryResultItem>;
export declare const DatabaseQueryResultList: S.Schema<DatabaseQueryResultList>;
export interface QueryDatabaseResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatabaseQueryResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const QueryDatabaseResponse: S.Schema<QueryDatabaseResponse>;
export type DatabaseRawRequestParamsList = Array<unknown>;
export declare const DatabaseRawRequestParamsList: S.Schema<DatabaseRawRequestParamsList>;
export type DatabaseRawRequestBatchItemParamsList = Array<unknown>;
export declare const DatabaseRawRequestBatchItemParamsList: S.Schema<DatabaseRawRequestBatchItemParamsList>;
export interface DatabaseRawRequestBatchItem {
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql: string;
    params?: DatabaseRawRequestBatchItemParamsList;
}
export declare const DatabaseRawRequestBatchItem: S.Schema<DatabaseRawRequestBatchItem>;
export type DatabaseRawRequestBatchList = Array<DatabaseRawRequestBatchItem>;
export declare const DatabaseRawRequestBatchList: S.Schema<DatabaseRawRequestBatchList>;
export interface RawDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Your SQL query. Supports multiple statements, joined by semicolons, which will be executed as a batch. */
    sql?: string;
    params?: DatabaseRawRequestParamsList;
    batch?: DatabaseRawRequestBatchList;
}
export declare const RawDatabaseRequest: S.Schema<RawDatabaseRequest>;
export type DatabaseRawResultItemMetaServedByRegion = "WNAM" | "ENAM" | "WEUR" | "EEUR" | "APAC" | "OC";
export declare const DatabaseRawResultItemMetaServedByRegion: any;
export type DatabaseRawResultItemMetaTimings = DatabaseImportResponseResultMetaTimings;
export declare const DatabaseRawResultItemMetaTimings: S.Schema<DatabaseImportResponseResultMetaTimings>;
export interface DatabaseRawResultItemMeta {
    /** Denotes if the database has been altered in some way, like deleting rows. */
    changedDb?: boolean | null;
    /** Rough indication of how many rows were modified by the query, as provided by SQLite's `sqlite3_total_changes()`. */
    changes?: number | null;
    /** The duration of the SQL query execution inside the database. Does not include any network communication. */
    duration?: number | null;
    /** The row ID of the last inserted row in a table with an `INTEGER PRIMARY KEY` as provided by SQLite. Tables created with `WITHOUT ROWID` do not populate this. */
    lastRowId?: number | null;
    /** Number of rows read during the SQL query execution, including indices (not all rows are necessarily returned). */
    rowsRead?: number | null;
    /** Number of rows written during the SQL query execution, including indices. */
    rowsWritten?: number | null;
    /** The three letters airport code of the colo that handled the query. */
    servedByColo?: string | null;
    /** Denotes if the query has been handled by the database primary instance. */
    servedByPrimary?: boolean | null;
    /** Region location hint of the database instance that handled the query. */
    servedByRegion?: DatabaseRawResultItemMetaServedByRegion | null;
    /** Size of the database after the query committed, in bytes. */
    sizeAfter?: number | null;
    /** Various durations for the query. */
    timings?: DatabaseImportResponseResultMetaTimings | null;
}
export declare const DatabaseRawResultItemMeta: S.Schema<DatabaseRawResultItemMeta>;
export type DatabaseRawResultItemResultsColumnsList = Array<string>;
export declare const DatabaseRawResultItemResultsColumnsList: S.Schema<DatabaseRawResultItemResultsColumnsList>;
export type DatabaseRawResultItemResultsRowsList = Array<unknown>;
export declare const DatabaseRawResultItemResultsRowsList: S.Schema<DatabaseRawResultItemResultsRowsList>;
export interface DatabaseRawResultItemResults {
    columns?: DatabaseRawResultItemResultsColumnsList | null;
    rows?: DatabaseRawResultItemResultsRowsList | null;
}
export declare const DatabaseRawResultItemResults: S.Schema<DatabaseRawResultItemResults>;
export interface DatabaseRawResultItem {
    meta?: DatabaseRawResultItemMeta | null;
    results?: DatabaseRawResultItemResults | null;
    success?: boolean | null;
}
export declare const DatabaseRawResultItem: S.Schema<DatabaseRawResultItem>;
export type DatabaseRawResultList = Array<DatabaseRawResultItem>;
export declare const DatabaseRawResultList: S.Schema<DatabaseRawResultList>;
export interface RawDatabaseResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatabaseRawResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const RawDatabaseResponse: S.Schema<RawDatabaseResponse>;
export interface RestoreDatabaseTimeTravelRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** A bookmark to restore the database to. Required if `timestamp` is not provided. */
    bookmark?: string;
    /** An ISO 8601 timestamp to restore the database to. Required if `bookmark` is not provided. */
    timestamp?: string;
}
export declare const RestoreDatabaseTimeTravelRequest: S.Schema<RestoreDatabaseTimeTravelRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RestoreDatabaseTimeTravelResponse {
    /** The new bookmark representing the state of the database after the restore operation. */
    bookmark?: string | null;
    /** A message describing the result of the restore operation. */
    message?: string | null;
    /** The bookmark representing the state of the database before the restore operation. Can be used to undo the restore if needed. */
    previousBookmark?: string | null;
}
export declare const RestoreDatabaseTimeTravelResponse: S.Schema<RestoreDatabaseTimeTravelResponse>;
export type DatabaseUpdateRequestReadReplicationMode = "auto" | "disabled";
export declare const DatabaseUpdateRequestReadReplicationMode: any;
export interface DatabaseUpdateRequestReadReplication {
    /** The read replication mode for the database. Use 'auto' to create replicas and allow D1 automatically place them around the world, or 'disabled' to not use any database replicas (it can take a few hours for all replicas to be deleted). */
    mode: DatabaseUpdateRequestReadReplicationMode | (string & {});
}
export declare const DatabaseUpdateRequestReadReplication: S.Schema<DatabaseUpdateRequestReadReplication>;
export interface UpdateDatabaseRequest {
    /** Account identifier tag. */
    accountId: string;
    /** D1 database identifier (UUID). */
    databaseId: string;
    /** Configuration for D1 read replication. */
    readReplication: DatabaseUpdateRequestReadReplication;
}
export declare const UpdateDatabaseRequest: S.Schema<UpdateDatabaseRequest>;
export type DatabaseUpdateResponseJurisdiction = "eu" | "fedramp";
export declare const DatabaseUpdateResponseJurisdiction: any;
export type DatabaseUpdateResponseReadReplicationMode = "auto" | "disabled";
export declare const DatabaseUpdateResponseReadReplicationMode: any;
export interface DatabaseUpdateResponseReadReplication {
    /** The read replication mode for the database. Mode 'auto' denotes that D1 creates replicas and automatically places them around the world. Mode 'disabled' denotes that no database replicas are used. */
    mode: DatabaseUpdateResponseReadReplicationMode;
}
export declare const DatabaseUpdateResponseReadReplication: S.Schema<DatabaseUpdateResponseReadReplication>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDatabaseResponse {
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdAt?: string | null;
    /** The D1 database's size, in bytes. */
    fileSize?: number | null;
    /** Specify the location to restrict the D1 database to run and store data. If this option is present, the location hint is ignored. */
    jurisdiction?: DatabaseUpdateResponseJurisdiction | null;
    /** D1 database name. */
    name?: string | null;
    numTables?: number | null;
    /** Configuration for D1 read replication. */
    readReplication?: DatabaseUpdateResponseReadReplication | null;
    /** D1 database identifier (UUID). */
    uuid?: string | null;
    version?: string | null;
}
export declare const UpdateDatabaseResponse: S.Schema<UpdateDatabaseResponse>;
export type CreateDatabaseError = InvalidObjectIdentifier | InvalidProperty | DatabaseAlreadyExists | CloudflareOpError;
/** Returns the created D1 database. */
export declare const createDatabase: API.OperationMethod<CreateDatabaseRequest, CreateDatabaseResponse, CreateDatabaseError, CloudflareOpContext>;
export type DeleteDatabaseError = InvalidObjectIdentifier | DatabaseNotFound | UnknownError | CloudflareOpError;
/** Deletes the specified D1 database. */
export declare const deleteDatabase: API.OperationMethod<DeleteDatabaseRequest, DeleteDatabaseResponse, DeleteDatabaseError, CloudflareOpContext>;
export type ExportDatabaseError = InvalidObjectIdentifier | InvalidRequest | DatabaseNotFound | CloudflareOpError;
/** Returns a URL where the SQL contents of your D1 can be downloaded. Note: this process may take some time for larger DBs, during which your D1 will be unavailable to serve queries. To avoid blocking your DB unnecessarily, an in-progress export must be continually polled or will automatically cancel. */
export declare const exportDatabase: API.OperationMethod<ExportDatabaseRequest, ExportDatabaseResponse, ExportDatabaseError, CloudflareOpContext>;
export type GetBookmarkDatabaseTimeTravelError = InvalidObjectIdentifier | NoHistoryAvailable | TimestampTooOld | DatabaseNotFound | CloudflareOpError;
/** Retrieves the current bookmark, or the nearest bookmark at or before a provided timestamp. Bookmarks can be used with the restore endpoint to revert the database to a previous point in time. */
export declare const getBookmarkDatabaseTimeTravel: API.OperationMethod<GetBookmarkDatabaseTimeTravelRequest, GetBookmarkDatabaseTimeTravelResponse, GetBookmarkDatabaseTimeTravelError, CloudflareOpContext>;
export type GetDatabaseError = InvalidObjectIdentifier | DatabaseNotFound | UnknownError | CloudflareOpError;
/** Returns the specified D1 database. */
export declare const getDatabase: API.OperationMethod<GetDatabaseRequest, GetDatabaseResponse, GetDatabaseError, CloudflareOpContext>;
export type ImportDatabaseError = InvalidObjectIdentifier | CloudflareOpError;
/** Generates a temporary URL for uploading an SQL file to, then instructing the D1 to import it and polling it for status updates. Imports block the D1 for their duration. */
export declare const importDatabase: API.OperationMethod<ImportDatabaseRequest, ImportDatabaseResponse, ImportDatabaseError, CloudflareOpContext>;
export type ListDatabasesError = CloudflareOpError;
/** Returns a list of D1 databases. */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesRequest, ListDatabasesResponse, ListDatabasesError, CloudflareOpContext, DatabaseListResultItem>;
export type PatchDatabaseError = InvalidObjectIdentifier | InternalError | DatabaseNotFound | CloudflareOpError;
/** Updates partially the specified D1 database. */
export declare const patchDatabase: API.OperationMethod<PatchDatabaseRequest, PatchDatabaseResponse, PatchDatabaseError, CloudflareOpContext>;
export type QueryDatabaseError = CloudflareOpError;
/** Returns the query result as an object. */
export declare const queryDatabase: API.PaginatedOperationMethod<QueryDatabaseRequest, QueryDatabaseResponse, QueryDatabaseError, CloudflareOpContext, DatabaseQueryResultItem>;
export type RawDatabaseError = CloudflareOpError;
/** Returns the query result rows as arrays rather than objects. This is a performance-optimized version of the /query endpoint. */
export declare const rawDatabase: API.PaginatedOperationMethod<RawDatabaseRequest, RawDatabaseResponse, RawDatabaseError, CloudflareOpContext, DatabaseRawResultItem>;
export type RestoreDatabaseTimeTravelError = InvalidObjectIdentifier | NoHistoryAvailable | DatabaseNotFound | InvalidProperty | CloudflareOpError;
/** Restores a D1 database to a previous point in time either via a bookmark or a timestamp. */
export declare const restoreDatabaseTimeTravel: API.OperationMethod<RestoreDatabaseTimeTravelRequest, RestoreDatabaseTimeTravelResponse, RestoreDatabaseTimeTravelError, CloudflareOpContext>;
export type UpdateDatabaseError = InvalidObjectIdentifier | InternalError | DatabaseNotFound | CloudflareOpError;
/** Updates the specified D1 database. */
export declare const updateDatabase: API.OperationMethod<UpdateDatabaseRequest, UpdateDatabaseResponse, UpdateDatabaseError, CloudflareOpContext>;
//# sourceMappingURL=d1.d.ts.map