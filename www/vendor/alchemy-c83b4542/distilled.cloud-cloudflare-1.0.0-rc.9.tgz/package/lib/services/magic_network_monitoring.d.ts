import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DuplicateMnmRuleName_base: S.Class<DuplicateMnmRuleName, S.TaggedStruct<"DuplicateMnmRuleName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateMnmRuleName extends /*@__PURE__*/ DuplicateMnmRuleName_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidMnmConfig_base: S.Class<InvalidMnmConfig, S.TaggedStruct<"InvalidMnmConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMnmConfig extends /*@__PURE__*/ InvalidMnmConfig_base {
}
declare const MnmConfigAlreadyExists_base: S.Class<MnmConfigAlreadyExists, S.TaggedStruct<"MnmConfigAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MnmConfigAlreadyExists extends /*@__PURE__*/ MnmConfigAlreadyExists_base {
}
declare const MnmConfigMissing_base: S.Class<MnmConfigMissing, S.TaggedStruct<"MnmConfigMissing", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MnmConfigMissing extends /*@__PURE__*/ MnmConfigMissing_base {
}
declare const MnmConfigNotFound_base: S.Class<MnmConfigNotFound, S.TaggedStruct<"MnmConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MnmConfigNotFound extends /*@__PURE__*/ MnmConfigNotFound_base {
}
declare const MnmRuleNotFound_base: S.Class<MnmRuleNotFound, S.TaggedStruct<"MnmRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MnmRuleNotFound extends /*@__PURE__*/ MnmRuleNotFound_base {
}
export type ConfigsCreateRequestRouterIpsList = Array<string>;
export declare const ConfigsCreateRequestRouterIpsList: S.Schema<ConfigsCreateRequestRouterIpsList>;
export interface ConfigsCreateRequestWarpDevicesItem {
    /** Unique identifier for the warp device. */
    id: string;
    /** Name of the warp device. */
    name: string;
    /** IPv4 CIDR of the router sourcing flow data associated with this warp device. Only /32 addresses are currently supported. */
    routerIp: string;
}
export declare const ConfigsCreateRequestWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsCreateRequestWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsCreateRequestWarpDevicesList: S.Schema<ConfigsCreateRequestWarpDevicesList>;
export interface CreateConfigRequest {
    accountId: string;
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps?: ConfigsCreateRequestRouterIpsList;
    warpDevices?: ConfigsCreateRequestWarpDevicesList;
}
export declare const CreateConfigRequest: S.Schema<CreateConfigRequest>;
export type ConfigsCreateResponseRouterIpsList = Array<string>;
export declare const ConfigsCreateResponseRouterIpsList: S.Schema<ConfigsCreateResponseRouterIpsList>;
export type ConfigsCreateResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsCreateResponseWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsCreateResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsCreateResponseWarpDevicesList: S.Schema<ConfigsCreateResponseWarpDevicesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsCreateResponseRouterIpsList;
    warpDevices: ConfigsCreateResponseWarpDevicesList;
}
export declare const CreateConfigResponse: S.Schema<CreateConfigResponse>;
export type RulesCreateRequestPrefixesList = Array<string>;
export declare const RulesCreateRequestPrefixesList: S.Schema<RulesCreateRequestPrefixesList>;
export type RulesCreateRequestType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesCreateRequestType: any;
export type RulesCreateRequestDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesCreateRequestDuration: any;
export type RulesCreateRequestPrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesCreateRequestPrefixMatch: any;
export type RulesCreateRequestZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesCreateRequestZscoreSensitivity: any;
export type RulesCreateRequestZscoreTarget = "bits" | "packets";
export declare const RulesCreateRequestZscoreTarget: any;
export interface CreateRuleRequest {
    accountId: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesCreateRequestPrefixesList;
    /** MNM rule type. */
    type: RulesCreateRequestType | (string & {});
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesCreateRequestDuration | (string & {});
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesCreateRequestPrefixMatch | (string & {});
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesCreateRequestZscoreSensitivity | (string & {});
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesCreateRequestZscoreTarget | (string & {});
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export type RulesCreateResponsePrefixesList = Array<string>;
export declare const RulesCreateResponsePrefixesList: S.Schema<RulesCreateResponsePrefixesList>;
export type RulesCreateResponseType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesCreateResponseType: any;
export type RulesCreateResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesCreateResponseDuration: any;
export type RulesCreateResponsePrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesCreateResponsePrefixMatch: any;
export type RulesCreateResponseZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesCreateResponseZscoreSensitivity: any;
export type RulesCreateResponseZscoreTarget = "bits" | "packets";
export declare const RulesCreateResponseZscoreTarget: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesCreateResponsePrefixesList;
    /** MNM rule type. */
    type: RulesCreateResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesCreateResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesCreateResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesCreateResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesCreateResponseZscoreTarget | null;
}
export declare const CreateRuleResponse: S.Schema<CreateRuleResponse>;
export interface CreateVpcFlowTokenRequest {
    accountId: string;
}
export declare const CreateVpcFlowTokenRequest: S.Schema<CreateVpcFlowTokenRequest>;
export type CreateVpcFlowTokenResponse = string;
export declare const CreateVpcFlowTokenResponse: S.Schema<CreateVpcFlowTokenResponse>;
export interface DeleteConfigRequest {
    accountId: string;
}
export declare const DeleteConfigRequest: S.Schema<DeleteConfigRequest>;
export type ConfigsDeleteResponseRouterIpsList = Array<string>;
export declare const ConfigsDeleteResponseRouterIpsList: S.Schema<ConfigsDeleteResponseRouterIpsList>;
export type ConfigsDeleteResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsDeleteResponseWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsDeleteResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsDeleteResponseWarpDevicesList: S.Schema<ConfigsDeleteResponseWarpDevicesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsDeleteResponseRouterIpsList;
    warpDevices: ConfigsDeleteResponseWarpDevicesList;
}
export declare const DeleteConfigResponse: S.Schema<DeleteConfigResponse>;
export interface DeleteRuleRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export type RulesDeleteResponsePrefixesList = Array<string>;
export declare const RulesDeleteResponsePrefixesList: S.Schema<RulesDeleteResponsePrefixesList>;
export type RulesDeleteResponseType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesDeleteResponseType: any;
export type RulesDeleteResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesDeleteResponseDuration: any;
export type RulesDeleteResponsePrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesDeleteResponsePrefixMatch: any;
export type RulesDeleteResponseZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesDeleteResponseZscoreSensitivity: any;
export type RulesDeleteResponseZscoreTarget = "bits" | "packets";
export declare const RulesDeleteResponseZscoreTarget: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesDeleteResponsePrefixesList;
    /** MNM rule type. */
    type: RulesDeleteResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesDeleteResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesDeleteResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesDeleteResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesDeleteResponseZscoreTarget | null;
}
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface GetConfigRequest {
    accountId: string;
}
export declare const GetConfigRequest: S.Schema<GetConfigRequest>;
export type ConfigsGetResponseRouterIpsList = Array<string>;
export declare const ConfigsGetResponseRouterIpsList: S.Schema<ConfigsGetResponseRouterIpsList>;
export type ConfigsGetResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsGetResponseWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsGetResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsGetResponseWarpDevicesList: S.Schema<ConfigsGetResponseWarpDevicesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsGetResponseRouterIpsList;
    warpDevices: ConfigsGetResponseWarpDevicesList;
}
export declare const GetConfigResponse: S.Schema<GetConfigResponse>;
export interface GetConfigFullRequest {
    accountId: string;
}
export declare const GetConfigFullRequest: S.Schema<GetConfigFullRequest>;
export type ConfigsFullGetResponseRouterIpsList = Array<string>;
export declare const ConfigsFullGetResponseRouterIpsList: S.Schema<ConfigsFullGetResponseRouterIpsList>;
export type ConfigsFullGetResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsFullGetResponseWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsFullGetResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsFullGetResponseWarpDevicesList: S.Schema<ConfigsFullGetResponseWarpDevicesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigFullResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsFullGetResponseRouterIpsList;
    warpDevices: ConfigsFullGetResponseWarpDevicesList;
}
export declare const GetConfigFullResponse: S.Schema<GetConfigFullResponse>;
export interface GetRuleRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
}
export declare const GetRuleRequest: S.Schema<GetRuleRequest>;
export type RulesGetResponsePrefixesList = Array<string>;
export declare const RulesGetResponsePrefixesList: S.Schema<RulesGetResponsePrefixesList>;
export type RulesGetResponseType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesGetResponseType: any;
export type RulesGetResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesGetResponseDuration: any;
export type RulesGetResponsePrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesGetResponsePrefixMatch: any;
export type RulesGetResponseZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesGetResponseZscoreSensitivity: any;
export type RulesGetResponseZscoreTarget = "bits" | "packets";
export declare const RulesGetResponseZscoreTarget: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesGetResponsePrefixesList;
    /** MNM rule type. */
    type: RulesGetResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesGetResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesGetResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesGetResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesGetResponseZscoreTarget | null;
}
export declare const GetRuleResponse: S.Schema<GetRuleResponse>;
export interface ListRulesRequest {
    accountId: string;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export type RulesListResultItemPrefixesList = Array<string>;
export declare const RulesListResultItemPrefixesList: S.Schema<RulesListResultItemPrefixesList>;
export type RulesListResultItemType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesListResultItemType: any;
export type RulesListResultItemDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesListResultItemDuration: any;
export type RulesListResultItemPrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesListResultItemPrefixMatch: any;
export type RulesListResultItemZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesListResultItemZscoreSensitivity: any;
export type RulesListResultItemZscoreTarget = "bits" | "packets";
export declare const RulesListResultItemZscoreTarget: any;
export interface RulesListResultItem {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesListResultItemPrefixesList;
    /** MNM rule type. */
    type: RulesListResultItemType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesListResultItemDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesListResultItemPrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesListResultItemZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesListResultItemZscoreTarget | null;
}
export declare const RulesListResultItem: S.Schema<RulesListResultItem>;
export type RulesListResultList = Array<RulesListResultItem>;
export declare const RulesListResultList: S.Schema<RulesListResultList>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export type ConfigsEditRequestRouterIpsList = Array<string>;
export declare const ConfigsEditRequestRouterIpsList: S.Schema<ConfigsEditRequestRouterIpsList>;
export type ConfigsEditRequestWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsEditRequestWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsEditRequestWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsEditRequestWarpDevicesList: S.Schema<ConfigsEditRequestWarpDevicesList>;
export interface PatchConfigRequest {
    accountId: string;
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling?: number;
    /** The account name. */
    name?: string;
    routerIps?: ConfigsEditRequestRouterIpsList;
    warpDevices?: ConfigsEditRequestWarpDevicesList;
}
export declare const PatchConfigRequest: S.Schema<PatchConfigRequest>;
export type ConfigsEditResponseRouterIpsList = Array<string>;
export declare const ConfigsEditResponseRouterIpsList: S.Schema<ConfigsEditResponseRouterIpsList>;
export type ConfigsEditResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsEditResponseWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsEditResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsEditResponseWarpDevicesList: S.Schema<ConfigsEditResponseWarpDevicesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsEditResponseRouterIpsList;
    warpDevices: ConfigsEditResponseWarpDevicesList;
}
export declare const PatchConfigResponse: S.Schema<PatchConfigResponse>;
export type RulesEditRequestPrefixesList = Array<string>;
export declare const RulesEditRequestPrefixesList: S.Schema<RulesEditRequestPrefixesList>;
export type RulesEditRequestType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesEditRequestType: any;
export type RulesEditRequestDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesEditRequestDuration: any;
export type RulesEditRequestPrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesEditRequestPrefixMatch: any;
export type RulesEditRequestZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesEditRequestZscoreSensitivity: any;
export type RulesEditRequestZscoreTarget = "bits" | "packets";
export declare const RulesEditRequestZscoreTarget: any;
export interface PatchRuleRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesEditRequestPrefixesList;
    /** MNM rule type. */
    type: RulesEditRequestType | (string & {});
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesEditRequestDuration | (string & {});
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesEditRequestPrefixMatch | (string & {});
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesEditRequestZscoreSensitivity | (string & {});
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesEditRequestZscoreTarget | (string & {});
}
export declare const PatchRuleRequest: S.Schema<PatchRuleRequest>;
export type RulesEditResponsePrefixesList = Array<string>;
export declare const RulesEditResponsePrefixesList: S.Schema<RulesEditResponsePrefixesList>;
export type RulesEditResponseType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesEditResponseType: any;
export type RulesEditResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesEditResponseDuration: any;
export type RulesEditResponsePrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesEditResponsePrefixMatch: any;
export type RulesEditResponseZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesEditResponseZscoreSensitivity: any;
export type RulesEditResponseZscoreTarget = "bits" | "packets";
export declare const RulesEditResponseZscoreTarget: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesEditResponsePrefixesList;
    /** MNM rule type. */
    type: RulesEditResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesEditResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesEditResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesEditResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesEditResponseZscoreTarget | null;
}
export declare const PatchRuleResponse: S.Schema<PatchRuleResponse>;
export interface PatchRuleAdvertisementRequest {
    accountId: string;
    /** The id of the rule. Must be unique. */
    ruleId: string;
}
export declare const PatchRuleAdvertisementRequest: S.Schema<PatchRuleAdvertisementRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRuleAdvertisementResponse {
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
}
export declare const PatchRuleAdvertisementResponse: S.Schema<PatchRuleAdvertisementResponse>;
export type ConfigsUpdateRequestRouterIpsList = Array<string>;
export declare const ConfigsUpdateRequestRouterIpsList: S.Schema<ConfigsUpdateRequestRouterIpsList>;
export type ConfigsUpdateRequestWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsUpdateRequestWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsUpdateRequestWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsUpdateRequestWarpDevicesList: S.Schema<ConfigsUpdateRequestWarpDevicesList>;
export interface UpdateConfigRequest {
    accountId: string;
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps?: ConfigsUpdateRequestRouterIpsList;
    warpDevices?: ConfigsUpdateRequestWarpDevicesList;
}
export declare const UpdateConfigRequest: S.Schema<UpdateConfigRequest>;
export type ConfigsUpdateResponseRouterIpsList = Array<string>;
export declare const ConfigsUpdateResponseRouterIpsList: S.Schema<ConfigsUpdateResponseRouterIpsList>;
export type ConfigsUpdateResponseWarpDevicesItem = ConfigsCreateRequestWarpDevicesItem;
export declare const ConfigsUpdateResponseWarpDevicesItem: S.Schema<ConfigsCreateRequestWarpDevicesItem>;
export type ConfigsUpdateResponseWarpDevicesList = Array<ConfigsCreateRequestWarpDevicesItem>;
export declare const ConfigsUpdateResponseWarpDevicesList: S.Schema<ConfigsUpdateResponseWarpDevicesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateConfigResponse {
    /** Fallback sampling rate of flow messages being sent in packets per second. This should match the packet sampling rate configured on the router. */
    defaultSampling: number;
    /** The account name. */
    name: string;
    routerIps: ConfigsUpdateResponseRouterIpsList;
    warpDevices: ConfigsUpdateResponseWarpDevicesList;
}
export declare const UpdateConfigResponse: S.Schema<UpdateConfigResponse>;
export type RulesUpdateRequestPrefixesList = Array<string>;
export declare const RulesUpdateRequestPrefixesList: S.Schema<RulesUpdateRequestPrefixesList>;
export type RulesUpdateRequestType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesUpdateRequestType: any;
export type RulesUpdateRequestDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesUpdateRequestDuration: any;
export type RulesUpdateRequestPrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesUpdateRequestPrefixMatch: any;
export type RulesUpdateRequestZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesUpdateRequestZscoreSensitivity: any;
export type RulesUpdateRequestZscoreTarget = "bits" | "packets";
export declare const RulesUpdateRequestZscoreTarget: any;
export interface UpdateRuleRequest {
    accountId: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesUpdateRequestPrefixesList;
    /** MNM rule type. */
    type: RulesUpdateRequestType | (string & {});
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesUpdateRequestDuration | (string & {});
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesUpdateRequestPrefixMatch | (string & {});
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesUpdateRequestZscoreSensitivity | (string & {});
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesUpdateRequestZscoreTarget | (string & {});
}
export declare const UpdateRuleRequest: S.Schema<UpdateRuleRequest>;
export type RulesUpdateResponsePrefixesList = Array<string>;
export declare const RulesUpdateResponsePrefixesList: S.Schema<RulesUpdateResponsePrefixesList>;
export type RulesUpdateResponseType = "threshold" | "zscore" | "advanced_ddos";
export declare const RulesUpdateResponseType: any;
export type RulesUpdateResponseDuration = "1m" | "5m" | "10m" | "15m" | "20m" | "30m" | "45m" | "60m";
export declare const RulesUpdateResponseDuration: any;
export type RulesUpdateResponsePrefixMatch = "exact" | "subnet" | "supernet";
export declare const RulesUpdateResponsePrefixMatch: any;
export type RulesUpdateResponseZscoreSensitivity = "low" | "medium" | "high";
export declare const RulesUpdateResponseZscoreSensitivity: any;
export type RulesUpdateResponseZscoreTarget = "bits" | "packets";
export declare const RulesUpdateResponseZscoreTarget: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The id of the rule. Must be unique. */
    id: string;
    /** Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit. */
    automaticAdvertisement: boolean;
    /** The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters. */
    name: string;
    prefixes: RulesUpdateResponsePrefixesList;
    /** MNM rule type. */
    type: RulesUpdateResponseType;
    /** The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    bandwidthThreshold?: number | null;
    /** The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"]. */
    duration?: RulesUpdateResponseDuration | null;
    /** The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum. */
    packetThreshold?: number | null;
    /** Prefix match type to be applied for a prefix auto advertisement when using an advanced_ddos rule. */
    prefixMatch?: RulesUpdateResponsePrefixMatch | null;
    /** Level of sensitivity set for zscore rules. */
    zscoreSensitivity?: RulesUpdateResponseZscoreSensitivity | null;
    /** Target of the zscore rule analysis. */
    zscoreTarget?: RulesUpdateResponseZscoreTarget | null;
}
export declare const UpdateRuleResponse: S.Schema<UpdateRuleResponse>;
export type CreateConfigError = MnmConfigAlreadyExists | InvalidMnmConfig | Forbidden | CloudflareOpError;
/** Create a new network monitoring configuration. */
export declare const createConfig: API.OperationMethod<CreateConfigRequest, CreateConfigResponse, CreateConfigError, CloudflareOpContext>;
export type CreateRuleError = DuplicateMnmRuleName | MnmConfigMissing | Forbidden | CloudflareOpError;
/** Create network monitoring rules for account. Currently only supports creating a single rule per API request. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type CreateVpcFlowTokenError = CloudflareOpError;
/** Generate authentication token for VPC flow logs export. */
export declare const createVpcFlowToken: API.OperationMethod<CreateVpcFlowTokenRequest, CreateVpcFlowTokenResponse, CreateVpcFlowTokenError, CloudflareOpContext>;
export type DeleteConfigError = MnmConfigNotFound | Forbidden | CloudflareOpError;
/** Delete an existing network monitoring configuration. */
export declare const deleteConfig: API.OperationMethod<DeleteConfigRequest, DeleteConfigResponse, DeleteConfigError, CloudflareOpContext>;
export type DeleteRuleError = MnmRuleNotFound | Forbidden | CloudflareOpError;
/** Delete a network monitoring rule for account. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type GetConfigError = Forbidden | CloudflareOpError;
/** Lists default sampling, router IPs and warp devices for account. */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, CloudflareOpContext>;
export type GetConfigFullError = CloudflareOpError;
/** Lists default sampling, router IPs, warp devices, and rules for account. */
export declare const getConfigFull: API.OperationMethod<GetConfigFullRequest, GetConfigFullResponse, GetConfigFullError, CloudflareOpContext>;
export type GetRuleError = MnmRuleNotFound | Forbidden | CloudflareOpError;
/** List a single network monitoring rule for account. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type ListRulesError = Forbidden | CloudflareOpError;
/** Lists network monitoring rules for account. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type PatchConfigError = CloudflareOpError;
/** Update fields in an existing network monitoring configuration. */
export declare const patchConfig: API.OperationMethod<PatchConfigRequest, PatchConfigResponse, PatchConfigError, CloudflareOpContext>;
export type PatchRuleError = MnmRuleNotFound | Forbidden | CloudflareOpError;
/** Update a network monitoring rule for account. */
export declare const patchRule: API.OperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext>;
export type PatchRuleAdvertisementError = CloudflareOpError;
/** Update advertisement for rule. */
export declare const patchRuleAdvertisement: API.OperationMethod<PatchRuleAdvertisementRequest, PatchRuleAdvertisementResponse, PatchRuleAdvertisementError, CloudflareOpContext>;
export type UpdateConfigError = Forbidden | InvalidMnmConfig | CloudflareOpError;
/** Update an existing network monitoring configuration, requires the entire configuration to be updated at once. */
export declare const updateConfig: API.OperationMethod<UpdateConfigRequest, UpdateConfigResponse, UpdateConfigError, CloudflareOpContext>;
export type UpdateRuleError = CloudflareOpError;
/** Update network monitoring rules for account. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
//# sourceMappingURL=magic_network_monitoring.d.ts.map