import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SecurityTxtInvalid_base: S.Class<SecurityTxtInvalid, S.TaggedStruct<"SecurityTxtInvalid", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecurityTxtInvalid extends /*@__PURE__*/ SecurityTxtInvalid_base {
}
export interface DeleteSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const DeleteSecurityTxtRequest: S.Schema<DeleteSecurityTxtRequest>;
export interface DeleteSecurityTxtResponse {
}
export declare const DeleteSecurityTxtResponse: S.Schema<DeleteSecurityTxtResponse>;
export interface GetSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetSecurityTxtRequest: S.Schema<GetSecurityTxtRequest>;
export type GetResponseAcknowledgmentsList = Array<string>;
export declare const GetResponseAcknowledgmentsList: S.Schema<GetResponseAcknowledgmentsList>;
export type GetResponseCanonicalList = Array<string>;
export declare const GetResponseCanonicalList: S.Schema<GetResponseCanonicalList>;
export type GetResponseContactList = Array<string>;
export declare const GetResponseContactList: S.Schema<GetResponseContactList>;
export type GetResponseEncryptionList = Array<string>;
export declare const GetResponseEncryptionList: S.Schema<GetResponseEncryptionList>;
export type GetResponseHiringList = Array<string>;
export declare const GetResponseHiringList: S.Schema<GetResponseHiringList>;
export type GetResponsePolicyList = Array<string>;
export declare const GetResponsePolicyList: S.Schema<GetResponsePolicyList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SecurityTxtFile {
    acknowledgments?: GetResponseAcknowledgmentsList | null;
    canonical?: GetResponseCanonicalList | null;
    contact?: GetResponseContactList | null;
    enabled?: boolean | null;
    encryption?: GetResponseEncryptionList | null;
    expires?: string | null;
    hiring?: GetResponseHiringList | null;
    policy?: GetResponsePolicyList | null;
    preferredLanguages?: string | null;
}
export declare const SecurityTxtFile: S.Schema<SecurityTxtFile>;
export type GetSecurityTxtResponse = SecurityTxtFile;
export declare const GetSecurityTxtResponse: S.Schema<GetSecurityTxtResponse>;
export type UpdateRequestAcknowledgmentsList = Array<string>;
export declare const UpdateRequestAcknowledgmentsList: S.Schema<UpdateRequestAcknowledgmentsList>;
export type UpdateRequestCanonicalList = Array<string>;
export declare const UpdateRequestCanonicalList: S.Schema<UpdateRequestCanonicalList>;
export type UpdateRequestContactList = Array<string>;
export declare const UpdateRequestContactList: S.Schema<UpdateRequestContactList>;
export type UpdateRequestEncryptionList = Array<string>;
export declare const UpdateRequestEncryptionList: S.Schema<UpdateRequestEncryptionList>;
export type UpdateRequestHiringList = Array<string>;
export declare const UpdateRequestHiringList: S.Schema<UpdateRequestHiringList>;
export type UpdateRequestPolicyList = Array<string>;
export declare const UpdateRequestPolicyList: S.Schema<UpdateRequestPolicyList>;
export interface PutSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
    acknowledgments?: UpdateRequestAcknowledgmentsList;
    canonical?: UpdateRequestCanonicalList;
    contact?: UpdateRequestContactList;
    enabled?: boolean;
    encryption?: UpdateRequestEncryptionList;
    expires?: string;
    hiring?: UpdateRequestHiringList;
    policy?: UpdateRequestPolicyList;
    preferredLanguages?: string;
}
export declare const PutSecurityTxtRequest: S.Schema<PutSecurityTxtRequest>;
export interface PutSecurityTxtResponse {
}
export declare const PutSecurityTxtResponse: S.Schema<PutSecurityTxtResponse>;
export type DeleteSecurityTxtError = Forbidden | CloudflareOpError;
/** Removes the security.txt file configuration for a zone. The /.well-known/security.txt endpoint will no longer be served. */
export declare const deleteSecurityTxt: API.OperationMethod<DeleteSecurityTxtRequest, DeleteSecurityTxtResponse, DeleteSecurityTxtError, CloudflareOpContext>;
export type GetSecurityTxtError = Forbidden | CloudflareOpError;
/** Retrieves the current security.txt file configuration for a zone, used for security vulnerability reporting. */
export declare const getSecurityTxt: API.OperationMethod<GetSecurityTxtRequest, GetSecurityTxtResponse, GetSecurityTxtError, CloudflareOpContext>;
export type PutSecurityTxtError = Forbidden | SecurityTxtInvalid | CloudflareOpError;
/** Updates the security.txt file configuration for a zone, which provides security researchers with vulnerability reporting information. */
export declare const putSecurityTxt: API.OperationMethod<PutSecurityTxtRequest, PutSecurityTxtResponse, PutSecurityTxtError, CloudflareOpContext>;
//# sourceMappingURL=security_txt.d.ts.map