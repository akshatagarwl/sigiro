import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type FilesRequestStatus = "completed" | "queued" | "running" | "error";
export declare const FilesRequestStatus: any;
export interface FilesRequest {
    accountId: string;
    /** rag id */
    id: string;
    page?: number;
    perPage?: number;
    search?: string;
    status?: FilesRequestStatus | (string & {});
}
export declare const FilesRequest: S.Schema<FilesRequest>;
export interface FilesResultItem {
    error: string;
    key: string;
}
export declare const FilesResultItem: S.Schema<FilesResultItem>;
export type FilesResultList = Array<FilesResultItem>;
export declare const FilesResultList: S.Schema<FilesResultList>;
export type FilesResponse = FilesResultList;
export declare const FilesResponse: S.Schema<FilesResponse>;
export interface GetJobRequest {
    accountId: string;
    /** rag id */
    id: string;
    jobId: string;
}
export declare const GetJobRequest: S.Schema<GetJobRequest>;
export type GetJobResponseSource = "user" | "schedule";
export declare const GetJobResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetJobResponse {
    id: string;
    source: GetJobResponseSource;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const GetJobResponse: S.Schema<GetJobResponse>;
export interface JobsLogsRequest {
    accountId: string;
    /** rag id */
    id: string;
    jobId: string;
    page?: number;
    perPage?: number;
}
export declare const JobsLogsRequest: S.Schema<JobsLogsRequest>;
export interface JobsLogsResultItem {
    id: number;
    createdAt: number;
    message: string;
    messageType: number;
}
export declare const JobsLogsResultItem: S.Schema<JobsLogsResultItem>;
export type JobsLogsResultList = Array<JobsLogsResultItem>;
export declare const JobsLogsResultList: S.Schema<JobsLogsResultList>;
export type JobsLogsResponse = JobsLogsResultList;
export declare const JobsLogsResponse: S.Schema<JobsLogsResponse>;
export interface ListJobsRequest {
    accountId: string;
    /** rag id */
    id: string;
    page?: number;
    perPage?: number;
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export type ListJobsResultItemSource = "user" | "schedule";
export declare const ListJobsResultItemSource: any;
export interface ListJobsResultItem {
    id: string;
    source: ListJobsResultItemSource;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const ListJobsResultItem: S.Schema<ListJobsResultItem>;
export type ListJobsResultList = Array<ListJobsResultItem>;
export declare const ListJobsResultList: S.Schema<ListJobsResultList>;
export type ListJobsResponse = ListJobsResultList;
export declare const ListJobsResponse: S.Schema<ListJobsResponse>;
export type SearchRequestFiltersCase0Type = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export declare const SearchRequestFiltersCase0Type: any;
export type SearchRequestFiltersCase0Value = string | number | boolean;
export declare const SearchRequestFiltersCase0Value: any;
export interface SearchRequestFiltersCase0 {
    key: string;
    type: SearchRequestFiltersCase0Type | (string & {});
    value: SearchRequestFiltersCase0Value;
}
export declare const SearchRequestFiltersCase0: S.Schema<SearchRequestFiltersCase0>;
export type SearchRequestFiltersCase1FiltersItemType = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export declare const SearchRequestFiltersCase1FiltersItemType: any;
export type SearchRequestFiltersCase1FiltersItemValue = string | number | boolean;
export declare const SearchRequestFiltersCase1FiltersItemValue: any;
export interface SearchRequestFiltersCase1FiltersItem {
    key: string;
    type: SearchRequestFiltersCase1FiltersItemType | (string & {});
    value: SearchRequestFiltersCase1FiltersItemValue;
}
export declare const SearchRequestFiltersCase1FiltersItem: S.Schema<SearchRequestFiltersCase1FiltersItem>;
export type SearchRequestFiltersCase1FiltersList = Array<SearchRequestFiltersCase1FiltersItem>;
export declare const SearchRequestFiltersCase1FiltersList: S.Schema<SearchRequestFiltersCase1FiltersList>;
export type SearchRequestFiltersCase1Type = "and" | "or";
export declare const SearchRequestFiltersCase1Type: any;
export interface SearchRequestFiltersCase1 {
    filters: SearchRequestFiltersCase1FiltersList;
    type: SearchRequestFiltersCase1Type | (string & {});
}
export declare const SearchRequestFiltersCase1: S.Schema<SearchRequestFiltersCase1>;
export type SearchRequestFilters = SearchRequestFiltersCase0 | SearchRequestFiltersCase1;
export declare const SearchRequestFilters: any;
export interface SearchRequestRankingOptions {
    ranker?: string;
    scoreThreshold?: number;
}
export declare const SearchRequestRankingOptions: S.Schema<SearchRequestRankingOptions>;
export type SearchRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const SearchRequestRerankingModel: any;
export interface SearchRequestReranking {
    enabled?: boolean;
    model?: SearchRequestRerankingModel | (string & {});
}
export declare const SearchRequestReranking: S.Schema<SearchRequestReranking>;
export interface SearchRequest {
    accountId: string;
    /** rag id */
    id: string;
    query: string;
    filters?: SearchRequestFilters;
    maxNumResults?: number;
    rankingOptions?: SearchRequestRankingOptions;
    reranking?: SearchRequestReranking;
    rewriteQuery?: boolean;
}
export declare const SearchRequest: S.Schema<SearchRequest>;
export interface SearchResponseDataItemContentItem {
    text?: string | null;
    type?: string | null;
}
export declare const SearchResponseDataItemContentItem: S.Schema<SearchResponseDataItemContentItem>;
export type SearchResponseDataItemContentList = Array<SearchResponseDataItemContentItem>;
export declare const SearchResponseDataItemContentList: S.Schema<SearchResponseDataItemContentList>;
export interface SearchResponseDataItem {
    score: number;
    attributes?: unknown | null;
    content?: SearchResponseDataItemContentList | null;
    fileId?: string | null;
    filename?: string | null;
}
export declare const SearchResponseDataItem: S.Schema<SearchResponseDataItem>;
export type SearchResponseDataList = Array<SearchResponseDataItem>;
export declare const SearchResponseDataList: S.Schema<SearchResponseDataList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchResponse {
    searchQuery: string;
    data?: SearchResponseDataList | null;
    hasMore?: boolean | null;
    nextPage?: string | null;
    object?: string | null;
}
export declare const SearchResponse: S.Schema<SearchResponse>;
export type SearchAiRequestFiltersCase0Type = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export declare const SearchAiRequestFiltersCase0Type: any;
export type SearchAiRequestFiltersCase0Value = string | number | boolean;
export declare const SearchAiRequestFiltersCase0Value: any;
export interface SearchAiRequestFiltersCase0 {
    key: string;
    type: SearchAiRequestFiltersCase0Type | (string & {});
    value: SearchAiRequestFiltersCase0Value;
}
export declare const SearchAiRequestFiltersCase0: S.Schema<SearchAiRequestFiltersCase0>;
export type SearchAiRequestFiltersCase1FiltersItemType = "eq" | "ne" | "gt" | "gte" | "lt" | "lte";
export declare const SearchAiRequestFiltersCase1FiltersItemType: any;
export type SearchAiRequestFiltersCase1FiltersItemValue = string | number | boolean;
export declare const SearchAiRequestFiltersCase1FiltersItemValue: any;
export interface SearchAiRequestFiltersCase1FiltersItem {
    key: string;
    type: SearchAiRequestFiltersCase1FiltersItemType | (string & {});
    value: SearchAiRequestFiltersCase1FiltersItemValue;
}
export declare const SearchAiRequestFiltersCase1FiltersItem: S.Schema<SearchAiRequestFiltersCase1FiltersItem>;
export type SearchAiRequestFiltersCase1FiltersList = Array<SearchAiRequestFiltersCase1FiltersItem>;
export declare const SearchAiRequestFiltersCase1FiltersList: S.Schema<SearchAiRequestFiltersCase1FiltersList>;
export type SearchAiRequestFiltersCase1Type = "and" | "or";
export declare const SearchAiRequestFiltersCase1Type: any;
export interface SearchAiRequestFiltersCase1 {
    filters: SearchAiRequestFiltersCase1FiltersList;
    type: SearchAiRequestFiltersCase1Type | (string & {});
}
export declare const SearchAiRequestFiltersCase1: S.Schema<SearchAiRequestFiltersCase1>;
export type SearchAiRequestFilters = SearchAiRequestFiltersCase0 | SearchAiRequestFiltersCase1;
export declare const SearchAiRequestFilters: any;
export type SearchAiRequestModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const SearchAiRequestModel: any;
export type SearchAiRequestRankingOptions = SearchRequestRankingOptions;
export declare const SearchAiRequestRankingOptions: S.Schema<SearchRequestRankingOptions>;
export type SearchAiRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const SearchAiRequestRerankingModel: any;
export interface SearchAiRequestReranking {
    enabled?: boolean;
    model?: SearchAiRequestRerankingModel | (string & {});
}
export declare const SearchAiRequestReranking: S.Schema<SearchAiRequestReranking>;
export interface SearchAiRequest {
    accountId: string;
    /** rag id */
    id: string;
    query: string;
    filters?: SearchAiRequestFilters;
    maxNumResults?: number;
    model?: SearchAiRequestModel | (string & {});
    rankingOptions?: SearchRequestRankingOptions;
    reranking?: SearchAiRequestReranking;
    rewriteQuery?: boolean;
    stream?: boolean;
    systemPrompt?: string;
}
export declare const SearchAiRequest: S.Schema<SearchAiRequest>;
export type SearchAiResponseDataItemContentItem = SearchResponseDataItemContentItem;
export declare const SearchAiResponseDataItemContentItem: S.Schema<SearchResponseDataItemContentItem>;
export type SearchAiResponseDataItemContentList = Array<SearchResponseDataItemContentItem>;
export declare const SearchAiResponseDataItemContentList: S.Schema<SearchAiResponseDataItemContentList>;
export interface SearchAiResponseDataItem {
    score: number;
    attributes?: unknown | null;
    content?: SearchAiResponseDataItemContentList | null;
    fileId?: string | null;
    filename?: string | null;
}
export declare const SearchAiResponseDataItem: S.Schema<SearchAiResponseDataItem>;
export type SearchAiResponseDataList = Array<SearchAiResponseDataItem>;
export declare const SearchAiResponseDataList: S.Schema<SearchAiResponseDataList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchAiResponse {
    response: string;
    searchQuery: string;
    data?: SearchAiResponseDataList | null;
    hasMore?: boolean | null;
    nextPage?: string | null;
    object?: string | null;
}
export declare const SearchAiResponse: S.Schema<SearchAiResponse>;
export interface SyncRequest {
    accountId: string;
    /** rag id */
    id: string;
}
export declare const SyncRequest: S.Schema<SyncRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SyncResponse {
    jobId: string;
}
export declare const SyncResponse: S.Schema<SyncResponse>;
export type FilesError = CloudflareOpError;
/** Files */
export declare const files: API.OperationMethod<FilesRequest, FilesResponse, FilesError, CloudflareOpContext>;
export type GetJobError = CloudflareOpError;
/** Get a Job Details */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, CloudflareOpContext>;
export type JobsLogsError = CloudflareOpError;
/** List Job Logs */
export declare const jobsLogs: API.OperationMethod<JobsLogsRequest, JobsLogsResponse, JobsLogsError, CloudflareOpContext>;
export type ListJobsError = CloudflareOpError;
/** List Jobs */
export declare const listJobs: API.OperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, CloudflareOpContext>;
export type SearchError = CloudflareOpError;
/** Search */
export declare const search: API.OperationMethod<SearchRequest, SearchResponse, SearchError, CloudflareOpContext>;
export type SearchAiError = CloudflareOpError;
/** AI Search */
export declare const searchAi: API.OperationMethod<SearchAiRequest, SearchAiResponse, SearchAiError, CloudflareOpContext>;
export type SyncError = CloudflareOpError;
/** Sync */
export declare const sync: API.OperationMethod<SyncRequest, SyncResponse, SyncError, CloudflareOpContext>;
//# sourceMappingURL=autorag.d.ts.map