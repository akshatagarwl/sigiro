import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const IndicatorFeedNotFound_base: S.Class<IndicatorFeedNotFound, S.TaggedStruct<"IndicatorFeedNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IndicatorFeedNotFound extends /*@__PURE__*/ IndicatorFeedNotFound_base {
}
declare const IndicatorFeedsNotEntitled_base: S.Class<IndicatorFeedsNotEntitled, S.TaggedStruct<"IndicatorFeedsNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IndicatorFeedsNotEntitled extends /*@__PURE__*/ IndicatorFeedsNotEntitled_base {
}
export type AttackSurfaceReportIssuesClassRequestIssueClassList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestIssueClassList: S.Schema<AttackSurfaceReportIssuesClassRequestIssueClassList>;
export type AttackSurfaceReportIssuesClassRequestIssueClassNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestIssueClassNeqList: S.Schema<AttackSurfaceReportIssuesClassRequestIssueClassNeqList>;
export type AttackSurfaceReportIssuesClassRequestIssueTypeList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestIssueTypeList: S.Schema<AttackSurfaceReportIssuesClassRequestIssueTypeList>;
export type AttackSurfaceReportIssuesClassRequestIssueTypeNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestIssueTypeNeqList: S.Schema<AttackSurfaceReportIssuesClassRequestIssueTypeNeqList>;
export type AttackSurfaceReportIssuesClassRequestProductList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestProductList: S.Schema<AttackSurfaceReportIssuesClassRequestProductList>;
export type AttackSurfaceReportIssuesClassRequestProductNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestProductNeqList: S.Schema<AttackSurfaceReportIssuesClassRequestProductNeqList>;
export type AttackSurfaceReportIssuesClassRequestSeverityList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestSeverityList: S.Schema<AttackSurfaceReportIssuesClassRequestSeverityList>;
export type AttackSurfaceReportIssuesClassRequestSeverityNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestSeverityNeqList: S.Schema<AttackSurfaceReportIssuesClassRequestSeverityNeqList>;
export type AttackSurfaceReportIssuesClassRequestSubjectList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestSubjectList: S.Schema<AttackSurfaceReportIssuesClassRequestSubjectList>;
export type AttackSurfaceReportIssuesClassRequestSubjectNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesClassRequestSubjectNeqList: S.Schema<AttackSurfaceReportIssuesClassRequestSubjectNeqList>;
export interface ClassAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesClassRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesClassRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesClassRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesClassRequestIssueTypeNeqList;
    product?: AttackSurfaceReportIssuesClassRequestProductList;
    productNeq?: AttackSurfaceReportIssuesClassRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesClassRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesClassRequestSeverityNeqList;
    subject?: AttackSurfaceReportIssuesClassRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesClassRequestSubjectNeqList;
}
export declare const ClassAttackSurfaceReportIssueRequest: S.Schema<ClassAttackSurfaceReportIssueRequest>;
export interface AttackSurfaceReportIssuesClassResultItem {
    count?: number | null;
    value?: string | null;
}
export declare const AttackSurfaceReportIssuesClassResultItem: S.Schema<AttackSurfaceReportIssuesClassResultItem>;
export type AttackSurfaceReportIssuesClassResultList = Array<AttackSurfaceReportIssuesClassResultItem>;
export declare const AttackSurfaceReportIssuesClassResultList: S.Schema<AttackSurfaceReportIssuesClassResultList>;
export type ClassAttackSurfaceReportIssueResponse = AttackSurfaceReportIssuesClassResultList;
export declare const ClassAttackSurfaceReportIssueResponse: S.Schema<ClassAttackSurfaceReportIssueResponse>;
export interface CreateIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** The description of the example test */
    description?: string;
    /** The name of the indicator feed */
    name?: string;
}
export declare const CreateIndicatorFeedRequest: S.Schema<CreateIndicatorFeedRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndicatorFeedResponse {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export declare const CreateIndicatorFeedResponse: S.Schema<CreateIndicatorFeedResponse>;
export interface CreateIndicatorFeedPermissionRequest {
    /** Identifier */
    accountId: string;
    /** The Cloudflare account tag of the account to change permissions on */
    accountTag?: string;
    /** The ID of the feed to add/remove permissions on */
    feedId?: number;
}
export declare const CreateIndicatorFeedPermissionRequest: S.Schema<CreateIndicatorFeedPermissionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndicatorFeedPermissionResponse {
    /** Whether the update succeeded or not */
    success?: boolean | null;
}
export declare const CreateIndicatorFeedPermissionResponse: S.Schema<CreateIndicatorFeedPermissionResponse>;
export type MiscategorizationsCreateRequestContentAddsList = Array<number>;
export declare const MiscategorizationsCreateRequestContentAddsList: S.Schema<MiscategorizationsCreateRequestContentAddsList>;
export type MiscategorizationsCreateRequestContentRemovesList = Array<number>;
export declare const MiscategorizationsCreateRequestContentRemovesList: S.Schema<MiscategorizationsCreateRequestContentRemovesList>;
export type MiscategorizationsCreateRequestIndicatorType = "domain" | "ipv4" | "ipv6" | "url";
export declare const MiscategorizationsCreateRequestIndicatorType: any;
export type MiscategorizationsCreateRequestSecurityAddsList = Array<number>;
export declare const MiscategorizationsCreateRequestSecurityAddsList: S.Schema<MiscategorizationsCreateRequestSecurityAddsList>;
export type MiscategorizationsCreateRequestSecurityRemovesList = Array<number>;
export declare const MiscategorizationsCreateRequestSecurityRemovesList: S.Schema<MiscategorizationsCreateRequestSecurityRemovesList>;
export interface CreateMiscategorizationRequest {
    /** Identifier. */
    accountId: string;
    /** Content category IDs to add. */
    contentAdds?: MiscategorizationsCreateRequestContentAddsList;
    /** Content category IDs to remove. */
    contentRemoves?: MiscategorizationsCreateRequestContentRemovesList;
    indicatorType?: MiscategorizationsCreateRequestIndicatorType | (string & {});
    /** Provide only if indicator_type is `ipv4` or `ipv6`. */
    ip?: string;
    /** Security category IDs to add. */
    securityAdds?: MiscategorizationsCreateRequestSecurityAddsList;
    /** Security category IDs to remove. */
    securityRemoves?: MiscategorizationsCreateRequestSecurityRemovesList;
    /** Provide only if indicator_type is `domain` or `url`. Example if indicator_type is `domain`: `example.com`. Example if indicator_type is `url`: `https://example.com/news/`. */
    url?: string;
}
export declare const CreateMiscategorizationRequest: S.Schema<CreateMiscategorizationRequest>;
export interface CreateMiscategorizationResponse {
}
export declare const CreateMiscategorizationResponse: S.Schema<CreateMiscategorizationResponse>;
export interface DataIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
}
export declare const DataIndicatorFeedRequest: S.Schema<DataIndicatorFeedRequest>;
export interface DataIndicatorFeedResponse {
}
export declare const DataIndicatorFeedResponse: S.Schema<DataIndicatorFeedResponse>;
export interface DeleteIndicatorFeedPermissionRequest {
    /** Identifier */
    accountId: string;
    /** The Cloudflare account tag of the account to change permissions on */
    accountTag?: string;
    /** The ID of the feed to add/remove permissions on */
    feedId?: number;
}
export declare const DeleteIndicatorFeedPermissionRequest: S.Schema<DeleteIndicatorFeedPermissionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteIndicatorFeedPermissionResponse {
    /** Whether the update succeeded or not */
    success?: boolean | null;
}
export declare const DeleteIndicatorFeedPermissionResponse: S.Schema<DeleteIndicatorFeedPermissionResponse>;
export interface DismissAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    issueId: string;
    dismiss?: boolean;
}
export declare const DismissAttackSurfaceReportIssueRequest: S.Schema<DismissAttackSurfaceReportIssueRequest>;
export interface DismissAttackSurfaceReportIssueResponse {
}
export declare const DismissAttackSurfaceReportIssueResponse: S.Schema<DismissAttackSurfaceReportIssueResponse>;
export interface GetAsnRequest {
    /** Identifier. */
    accountId: string;
    asn: string;
}
export declare const GetAsnRequest: S.Schema<GetAsnRequest>;
export type GetAsnResponse = unknown;
export declare const GetAsnResponse: S.Schema<GetAsnResponse>;
export interface GetAsnSubnetRequest {
    /** Identifier. */
    accountId: string;
    asn: string;
}
export declare const GetAsnSubnetRequest: S.Schema<GetAsnSubnetRequest>;
export type AsnSubnetsGetResponseSubnetsList = Array<string>;
export declare const AsnSubnetsGetResponseSubnetsList: S.Schema<AsnSubnetsGetResponseSubnetsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAsnSubnetResponse {
    asn?: unknown | null;
    /** Total results returned based on your search parameters. */
    count?: number | null;
    ipCountTotal?: number | null;
    /** Current page within paginated list of results. */
    page?: number | null;
    /** Number of results per page of results. */
    perPage?: number | null;
    subnets?: AsnSubnetsGetResponseSubnetsList | null;
}
export declare const GetAsnSubnetResponse: S.Schema<GetAsnSubnetResponse>;
export interface GetAttackSurfaceReportIssueTypeRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetAttackSurfaceReportIssueTypeRequest: S.Schema<GetAttackSurfaceReportIssueTypeRequest>;
export type AttackSurfaceReportIssueTypesGetResultList = Array<string>;
export declare const AttackSurfaceReportIssueTypesGetResultList: S.Schema<AttackSurfaceReportIssueTypesGetResultList>;
export interface GetAttackSurfaceReportIssueTypeResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AttackSurfaceReportIssueTypesGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetAttackSurfaceReportIssueTypeResponse: S.Schema<GetAttackSurfaceReportIssueTypeResponse>;
export interface GetDomainRequest {
    /** Identifier. */
    accountId: string;
    domain?: string;
    /** Skip DNS resolution lookups for faster response. */
    skipDns?: boolean;
    /** Skip the domain ranking lookup for faster responses. Defaults to */
    skipRanking?: boolean;
}
export declare const GetDomainRequest: S.Schema<GetDomainRequest>;
export interface DomainsGetResponseAdditionalInformation {
    /** Suspected DGA malware family. */
    suspectedMalwareFamily?: string | null;
}
export declare const DomainsGetResponseAdditionalInformation: S.Schema<DomainsGetResponseAdditionalInformation>;
export interface DomainsGetResponseApplication {
    id?: number | null;
    name?: string | null;
}
export declare const DomainsGetResponseApplication: S.Schema<DomainsGetResponseApplication>;
export interface DomainsGetResponseContentCategoriesItem {
    id?: number | null;
    name?: string | null;
    superCategoryId?: number | null;
}
export declare const DomainsGetResponseContentCategoriesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsGetResponseContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsGetResponseContentCategoriesList: S.Schema<DomainsGetResponseContentCategoriesList>;
export type DomainsGetResponseInheritedContentCategoriesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsGetResponseInheritedContentCategoriesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsGetResponseInheritedContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsGetResponseInheritedContentCategoriesList: S.Schema<DomainsGetResponseInheritedContentCategoriesList>;
export type DomainsGetResponseInheritedRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsGetResponseInheritedRiskTypesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsGetResponseInheritedRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsGetResponseInheritedRiskTypesList: S.Schema<DomainsGetResponseInheritedRiskTypesList>;
export interface DomainsGetResponseResolvesToRefsItem {
    /** STIX 2.1 identifier: https://docs.oasis-open.org/cti/stix/v2.1/cs02/stix-v2.1-cs02.html#_64yvzeku5a5c. */
    id?: string | null;
    /** IP address or domain name. */
    value?: string | null;
}
export declare const DomainsGetResponseResolvesToRefsItem: S.Schema<DomainsGetResponseResolvesToRefsItem>;
export type DomainsGetResponseResolvesToRefsList = Array<DomainsGetResponseResolvesToRefsItem>;
export declare const DomainsGetResponseResolvesToRefsList: S.Schema<DomainsGetResponseResolvesToRefsList>;
export type DomainsGetResponseRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsGetResponseRiskTypesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsGetResponseRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsGetResponseRiskTypesList: S.Schema<DomainsGetResponseRiskTypesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDomainResponse {
    /** Additional information related to the host name. */
    additionalInformation?: DomainsGetResponseAdditionalInformation | null;
    /** Application that the hostname belongs to. */
    application?: DomainsGetResponseApplication | null;
    contentCategories?: DomainsGetResponseContentCategoriesList | null;
    domain?: string | null;
    inheritedContentCategories?: DomainsGetResponseInheritedContentCategoriesList | null;
    /** Domain from which `inherited_content_categories` and `inherited_risk_types` are inherited, if applicable. */
    inheritedFrom?: string | null;
    inheritedRiskTypes?: DomainsGetResponseInheritedRiskTypesList | null;
    /** Global Cloudflare 100k ranking for the last 30 days, if available for the hostname. The top ranked domain is 1, the lowest ranked domain is 100,000. */
    popularityRank?: number | null;
    /** Specifies a list of references to one or more IP addresses or domain names that the domain name currently resolves to. */
    resolvesToRefs?: DomainsGetResponseResolvesToRefsList | null;
    /** Hostname risk score, which is a value between 0 (lowest risk) to 1 (highest risk). */
    riskScore?: number | null;
    riskTypes?: DomainsGetResponseRiskTypesList | null;
}
export declare const GetDomainResponse: S.Schema<GetDomainResponse>;
export type DomainsBulksGetRequestDomainList = Array<string>;
export declare const DomainsBulksGetRequestDomainList: S.Schema<DomainsBulksGetRequestDomainList>;
export interface GetDomainBulkRequest {
    /** Identifier. */
    accountId: string;
    /** Accepts multiple values like `?domain=cloudflare.com&domain=example.com`. */
    domain?: DomainsBulksGetRequestDomainList;
    /** Whether to include domain ranking data in the response. Defaults to */
    includeRanking?: boolean;
    /** **Deprecated.** Previously controlled whether the ranking lookup */
    skipRanking?: boolean;
}
export declare const GetDomainBulkRequest: S.Schema<GetDomainBulkRequest>;
export type DomainsBulksGetResultItemAdditionalInformation = DomainsGetResponseAdditionalInformation;
export declare const DomainsBulksGetResultItemAdditionalInformation: S.Schema<DomainsGetResponseAdditionalInformation>;
export type DomainsBulksGetResultItemApplication = DomainsGetResponseApplication;
export declare const DomainsBulksGetResultItemApplication: S.Schema<DomainsGetResponseApplication>;
export type DomainsBulksGetResultItemContentCategoriesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsBulksGetResultItemContentCategoriesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsBulksGetResultItemContentCategoriesList: S.Schema<DomainsBulksGetResultItemContentCategoriesList>;
export type DomainsBulksGetResultItemInheritedContentCategoriesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsBulksGetResultItemInheritedContentCategoriesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemInheritedContentCategoriesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsBulksGetResultItemInheritedContentCategoriesList: S.Schema<DomainsBulksGetResultItemInheritedContentCategoriesList>;
export type DomainsBulksGetResultItemInheritedRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsBulksGetResultItemInheritedRiskTypesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemInheritedRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsBulksGetResultItemInheritedRiskTypesList: S.Schema<DomainsBulksGetResultItemInheritedRiskTypesList>;
export type DomainsBulksGetResultItemRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export declare const DomainsBulksGetResultItemRiskTypesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type DomainsBulksGetResultItemRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const DomainsBulksGetResultItemRiskTypesList: S.Schema<DomainsBulksGetResultItemRiskTypesList>;
export interface DomainsBulksGetResultItem {
    /** Additional information related to the host name. */
    additionalInformation?: DomainsGetResponseAdditionalInformation | null;
    /** Application that the hostname belongs to. */
    application?: DomainsGetResponseApplication | null;
    contentCategories?: DomainsBulksGetResultItemContentCategoriesList | null;
    domain?: string | null;
    inheritedContentCategories?: DomainsBulksGetResultItemInheritedContentCategoriesList | null;
    /** Domain from which `inherited_content_categories` and `inherited_risk_types` are inherited, if applicable. */
    inheritedFrom?: string | null;
    inheritedRiskTypes?: DomainsBulksGetResultItemInheritedRiskTypesList | null;
    /** Global Cloudflare 100k ranking for the last 30 days, if available for the hostname. The top ranked domain is 1, the lowest ranked domain is 100,000. */
    popularityRank?: number | null;
    /** Hostname risk score, which is a value between 0 (lowest risk) to 1 (highest risk). */
    riskScore?: number | null;
    riskTypes?: DomainsBulksGetResultItemRiskTypesList | null;
}
export declare const DomainsBulksGetResultItem: S.Schema<DomainsBulksGetResultItem>;
export type DomainsBulksGetResultList = Array<DomainsBulksGetResultItem>;
export declare const DomainsBulksGetResultList: S.Schema<DomainsBulksGetResultList>;
export type GetDomainBulkResponse = DomainsBulksGetResultList;
export declare const GetDomainBulkResponse: S.Schema<GetDomainBulkResponse>;
export interface GetDomainHistoryRequest {
    /** Identifier. */
    accountId: string;
    domain?: string;
}
export declare const GetDomainHistoryRequest: S.Schema<GetDomainHistoryRequest>;
export type DomainHistoryGetResultItemCategorizationsItemCategoriesItem = DomainsGetResponseApplication;
export declare const DomainHistoryGetResultItemCategorizationsItemCategoriesItem: S.Schema<DomainsGetResponseApplication>;
export type DomainHistoryGetResultItemCategorizationsItemCategoriesList = Array<DomainsGetResponseApplication>;
export declare const DomainHistoryGetResultItemCategorizationsItemCategoriesList: S.Schema<DomainHistoryGetResultItemCategorizationsItemCategoriesList>;
export interface DomainHistoryGetResultItemCategorizationsItem {
    categories?: DomainHistoryGetResultItemCategorizationsItemCategoriesList | null;
    end?: string | null;
    start?: string | null;
}
export declare const DomainHistoryGetResultItemCategorizationsItem: S.Schema<DomainHistoryGetResultItemCategorizationsItem>;
export type DomainHistoryGetResultItemCategorizationsList = Array<DomainHistoryGetResultItemCategorizationsItem>;
export declare const DomainHistoryGetResultItemCategorizationsList: S.Schema<DomainHistoryGetResultItemCategorizationsList>;
export interface DomainHistoryGetResultItem {
    categorizations?: DomainHistoryGetResultItemCategorizationsList | null;
    domain?: string | null;
}
export declare const DomainHistoryGetResultItem: S.Schema<DomainHistoryGetResultItem>;
export type DomainHistoryGetResultList = Array<DomainHistoryGetResultItem>;
export declare const DomainHistoryGetResultList: S.Schema<DomainHistoryGetResultList>;
export type GetDomainHistoryResponse = DomainHistoryGetResultList;
export declare const GetDomainHistoryResponse: S.Schema<GetDomainHistoryResponse>;
export interface GetIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
}
export declare const GetIndicatorFeedRequest: S.Schema<GetIndicatorFeedRequest>;
export interface IndicatorFeedsGetResponseLastUploadSummaryPersisted {
    domainsAdded?: number | null;
    domainsRemoved?: number | null;
    ipsAdded?: number | null;
    ipsRemoved?: number | null;
    urlsAdded?: number | null;
    urlsRemoved?: number | null;
}
export declare const IndicatorFeedsGetResponseLastUploadSummaryPersisted: S.Schema<IndicatorFeedsGetResponseLastUploadSummaryPersisted>;
export interface IndicatorFeedsGetResponseLastUploadSummarySkipped {
    /** Domains filtered by the global popularity allowlist at QS */
    allowlistedDomains?: number | null;
    /** Indicators in the upload whose valid_until is already in */
    expiredIndicators?: number | null;
    /** Reserved for future use. Currently always 0 — the unifier */
    invalidIndicators?: number | null;
}
export declare const IndicatorFeedsGetResponseLastUploadSummarySkipped: S.Schema<IndicatorFeedsGetResponseLastUploadSummarySkipped>;
export interface IndicatorFeedsGetResponseLastUploadSummaryUploaded {
    /** Number of domain indicators in the upload */
    domains?: number | null;
    /** Number of IP indicators in the upload */
    ips?: number | null;
    /** Number of URL indicators in the upload */
    urls?: number | null;
}
export declare const IndicatorFeedsGetResponseLastUploadSummaryUploaded: S.Schema<IndicatorFeedsGetResponseLastUploadSummaryUploaded>;
export interface IndicatorFeedsGetResponseLastUploadSummary {
    /** Net delta applied to feed indicators by this upload. Snapshot */
    persisted?: IndicatorFeedsGetResponseLastUploadSummaryPersisted | null;
    /** Counts of indicators that were uploaded but did not reach */
    skipped?: IndicatorFeedsGetResponseLastUploadSummarySkipped | null;
    /** Indicator counts from the unified file the loader received */
    uploaded?: IndicatorFeedsGetResponseLastUploadSummaryUploaded | null;
}
export declare const IndicatorFeedsGetResponseLastUploadSummary: S.Schema<IndicatorFeedsGetResponseLastUploadSummary>;
export type IndicatorFeedsGetResponseLatestUploadStatus = "Mirroring" | "Unifying" | "Loading" | "Provisioning" | "Complete" | "Error";
export declare const IndicatorFeedsGetResponseLatestUploadStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIndicatorFeedResponse {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** Summary of indicator counts from the last successful upload to this */
    lastUploadSummary?: IndicatorFeedsGetResponseLastUploadSummary | null;
    /** Human-readable error message describing why the latest upload */
    latestUploadError?: string | null;
    /** Status of the latest snapshot uploaded */
    latestUploadStatus?: IndicatorFeedsGetResponseLatestUploadStatus | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
    /** The unique identifier for the provider */
    providerId?: number | null;
    /** The provider of the indicator feed */
    providerName?: string | null;
}
export declare const GetIndicatorFeedResponse: S.Schema<GetIndicatorFeedResponse>;
export interface GetIpRequest {
    /** Identifier. */
    accountId: string;
    ipv4?: string;
    ipv6?: string;
}
export declare const GetIpRequest: S.Schema<GetIpRequest>;
export type IpsGetResultItemBelongsToRefType = "hosting_provider" | "isp" | "organization";
export declare const IpsGetResultItemBelongsToRefType: any;
export interface IpsGetResultItemBelongsToRef {
    id?: string | null;
    country?: string | null;
    description?: string | null;
    /** Infrastructure type of this ASN. */
    type?: IpsGetResultItemBelongsToRefType | null;
    value?: string | null;
}
export declare const IpsGetResultItemBelongsToRef: S.Schema<IpsGetResultItemBelongsToRef>;
export type IpsGetResultItemRiskTypesItem = DomainsGetResponseContentCategoriesItem;
export declare const IpsGetResultItemRiskTypesItem: S.Schema<DomainsGetResponseContentCategoriesItem>;
export type IpsGetResultItemRiskTypesList = Array<DomainsGetResponseContentCategoriesItem>;
export declare const IpsGetResultItemRiskTypesList: S.Schema<IpsGetResultItemRiskTypesList>;
export interface IpsGetResultItem {
    /** Specifies a reference to the autonomous systems (AS) that the IP address belongs to. */
    belongsToRef?: IpsGetResultItemBelongsToRef | null;
    ip?: string | null;
    riskTypes?: IpsGetResultItemRiskTypesList | null;
}
export declare const IpsGetResultItem: S.Schema<IpsGetResultItem>;
export type IpsGetResultList = Array<IpsGetResultItem>;
export declare const IpsGetResultList: S.Schema<IpsGetResultList>;
export type GetIpResponse = IpsGetResultList;
export declare const GetIpResponse: S.Schema<GetIpResponse>;
export interface GetWhoiRequest {
    /** Use to uniquely identify or reference the resource. */
    accountId: string;
    domain?: string;
}
export declare const GetWhoiRequest: S.Schema<GetWhoiRequest>;
export type WhoisGetResponseNameserversList = Array<string>;
export declare const WhoisGetResponseNameserversList: S.Schema<WhoisGetResponseNameserversList>;
export type WhoisGetResponseStatusList = Array<string>;
export declare const WhoisGetResponseStatusList: S.Schema<WhoisGetResponseStatusList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWhoiResponse {
    dnssec: boolean;
    domain: string;
    extension: string;
    found: boolean;
    nameservers: WhoisGetResponseNameserversList;
    punycode: string;
    registrant: string;
    registrar: string;
    id?: string | null;
    administrativeCity?: string | null;
    administrativeCountry?: string | null;
    administrativeEmail?: string | null;
    administrativeFax?: string | null;
    administrativeFaxExt?: string | null;
    administrativeId?: string | null;
    administrativeName?: string | null;
    administrativeOrg?: string | null;
    administrativePhone?: string | null;
    administrativePhoneExt?: string | null;
    administrativePostalCode?: string | null;
    administrativeProvince?: string | null;
    administrativeReferralUrl?: string | null;
    administrativeStreet?: string | null;
    billingCity?: string | null;
    billingCountry?: string | null;
    billingEmail?: string | null;
    billingFax?: string | null;
    billingFaxExt?: string | null;
    billingId?: string | null;
    billingName?: string | null;
    billingOrg?: string | null;
    billingPhone?: string | null;
    billingPhoneExt?: string | null;
    billingPostalCode?: string | null;
    billingProvince?: string | null;
    billingReferralUrl?: string | null;
    billingStreet?: string | null;
    createdDate?: string | null;
    createdDateRaw?: string | null;
    expirationDate?: string | null;
    expirationDateRaw?: string | null;
    registrantCity?: string | null;
    registrantCountry?: string | null;
    registrantEmail?: string | null;
    registrantFax?: string | null;
    registrantFaxExt?: string | null;
    registrantId?: string | null;
    registrantName?: string | null;
    registrantOrg?: string | null;
    registrantPhone?: string | null;
    registrantPhoneExt?: string | null;
    registrantPostalCode?: string | null;
    registrantProvince?: string | null;
    registrantReferralUrl?: string | null;
    registrantStreet?: string | null;
    registrarCity?: string | null;
    registrarCountry?: string | null;
    registrarEmail?: string | null;
    registrarFax?: string | null;
    registrarFaxExt?: string | null;
    registrarId?: string | null;
    registrarName?: string | null;
    registrarOrg?: string | null;
    registrarPhone?: string | null;
    registrarPhoneExt?: string | null;
    registrarPostalCode?: string | null;
    registrarProvince?: string | null;
    registrarReferralUrl?: string | null;
    registrarStreet?: string | null;
    status?: WhoisGetResponseStatusList | null;
    technicalCity?: string | null;
    technicalCountry?: string | null;
    technicalEmail?: string | null;
    technicalFax?: string | null;
    technicalFaxExt?: string | null;
    technicalId?: string | null;
    technicalName?: string | null;
    technicalOrg?: string | null;
    technicalPhone?: string | null;
    technicalPhoneExt?: string | null;
    technicalPostalCode?: string | null;
    technicalProvince?: string | null;
    technicalReferralUrl?: string | null;
    technicalStreet?: string | null;
    updatedDate?: string | null;
    updatedDateRaw?: string | null;
    whoisServer?: string | null;
}
export declare const GetWhoiResponse: S.Schema<GetWhoiResponse>;
export type AttackSurfaceReportIssuesListRequestIssueClassList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestIssueClassList: S.Schema<AttackSurfaceReportIssuesListRequestIssueClassList>;
export type AttackSurfaceReportIssuesListRequestIssueClassNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestIssueClassNeqList: S.Schema<AttackSurfaceReportIssuesListRequestIssueClassNeqList>;
export type AttackSurfaceReportIssuesListRequestIssueTypeList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestIssueTypeList: S.Schema<AttackSurfaceReportIssuesListRequestIssueTypeList>;
export type AttackSurfaceReportIssuesListRequestIssueTypeNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestIssueTypeNeqList: S.Schema<AttackSurfaceReportIssuesListRequestIssueTypeNeqList>;
export type AttackSurfaceReportIssuesListRequestProductList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestProductList: S.Schema<AttackSurfaceReportIssuesListRequestProductList>;
export type AttackSurfaceReportIssuesListRequestProductNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestProductNeqList: S.Schema<AttackSurfaceReportIssuesListRequestProductNeqList>;
export type AttackSurfaceReportIssuesListRequestSeverityList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestSeverityList: S.Schema<AttackSurfaceReportIssuesListRequestSeverityList>;
export type AttackSurfaceReportIssuesListRequestSeverityNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestSeverityNeqList: S.Schema<AttackSurfaceReportIssuesListRequestSeverityNeqList>;
export type AttackSurfaceReportIssuesListRequestSubjectList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestSubjectList: S.Schema<AttackSurfaceReportIssuesListRequestSubjectList>;
export type AttackSurfaceReportIssuesListRequestSubjectNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesListRequestSubjectNeqList: S.Schema<AttackSurfaceReportIssuesListRequestSubjectNeqList>;
export interface ListAttackSurfaceReportIssuesRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesListRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesListRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesListRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesListRequestIssueTypeNeqList;
    /** Specifies the current page within paginated list of results. */
    page?: number;
    /** Sets the number of results per page of results. */
    perPage?: number;
    product?: AttackSurfaceReportIssuesListRequestProductList;
    productNeq?: AttackSurfaceReportIssuesListRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesListRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesListRequestSeverityNeqList;
    subject?: AttackSurfaceReportIssuesListRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesListRequestSubjectNeqList;
}
export declare const ListAttackSurfaceReportIssuesRequest: S.Schema<ListAttackSurfaceReportIssuesRequest>;
export type AttackSurfaceReportIssuesListResponseIssuesItemIssueType = "compliance_violation" | "email_security" | "exposed_infrastructure" | "insecure_configuration" | "weak_authentication" | "configuration_suggestion";
export declare const AttackSurfaceReportIssuesListResponseIssuesItemIssueType: any;
export interface AttackSurfaceReportIssuesListResponseIssuesItemPayload {
    /** Describes the method used to detect insight. */
    detectionMethod?: string | null;
    zoneTag?: string | null;
}
export declare const AttackSurfaceReportIssuesListResponseIssuesItemPayload: S.Schema<AttackSurfaceReportIssuesListResponseIssuesItemPayload>;
export type AttackSurfaceReportIssuesListResponseIssuesItemSeverity = "Low" | "Moderate" | "Critical";
export declare const AttackSurfaceReportIssuesListResponseIssuesItemSeverity: any;
export type AttackSurfaceReportIssuesListResponseIssuesItemStatus = "active" | "resolved";
export declare const AttackSurfaceReportIssuesListResponseIssuesItemStatus: any;
export type AttackSurfaceReportIssuesListResponseIssuesItemUserClassification = "false_positive" | "accept_risk" | "other";
export declare const AttackSurfaceReportIssuesListResponseIssuesItemUserClassification: any;
export interface AttackSurfaceReportIssuesListResponseIssuesItem {
    id?: string | null;
    dismissed?: boolean | null;
    /** Indicates whether the insight has a large payload that requires fetching via the context endpoint. */
    hasExtendedContext?: boolean | null;
    issueClass?: string | null;
    issueType?: AttackSurfaceReportIssuesListResponseIssuesItemIssueType | null;
    payload?: AttackSurfaceReportIssuesListResponseIssuesItemPayload | null;
    resolveLink?: string | null;
    resolveText?: string | null;
    severity?: AttackSurfaceReportIssuesListResponseIssuesItemSeverity | null;
    since?: string | null;
    /** The current status of the insight. */
    status?: AttackSurfaceReportIssuesListResponseIssuesItemStatus | null;
    subject?: string | null;
    timestamp?: string | null;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    userClassification?: AttackSurfaceReportIssuesListResponseIssuesItemUserClassification | null;
}
export declare const AttackSurfaceReportIssuesListResponseIssuesItem: S.Schema<AttackSurfaceReportIssuesListResponseIssuesItem>;
export type AttackSurfaceReportIssuesListResponseIssuesList = Array<AttackSurfaceReportIssuesListResponseIssuesItem>;
export declare const AttackSurfaceReportIssuesListResponseIssuesList: S.Schema<AttackSurfaceReportIssuesListResponseIssuesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListAttackSurfaceReportIssuesResponse {
    /** Indicates the total number of results. */
    count?: number | null;
    issues?: AttackSurfaceReportIssuesListResponseIssuesList | null;
    /** Specifies the current page within paginated list of results. */
    page?: number | null;
    /** Sets the number of results per page of results. */
    perPage?: number | null;
}
export declare const ListAttackSurfaceReportIssuesResponse: S.Schema<ListAttackSurfaceReportIssuesResponse>;
export interface DnsListRequestStartEndParams {
    /** Defaults to the current date. */
    end?: string;
    /** Defaults to 30 days before the end parameter value. */
    start?: string;
}
export declare const DnsListRequestStartEndParams: S.Schema<DnsListRequestStartEndParams>;
export interface ListDnsRequest {
    /** Identifier. */
    accountId: string;
    ipv4?: string;
    /** Requested page within paginated list of results. */
    page?: number;
    /** Maximum number of results requested. */
    perPage?: number;
    startEndParams?: DnsListRequestStartEndParams;
}
export declare const ListDnsRequest: S.Schema<ListDnsRequest>;
export interface DnsListResponseReverseRecordsItem {
    /** First seen date of the DNS record during the time period. */
    firstSeen?: string | null;
    /** Hostname that the IP was observed resolving to. */
    hostname?: string | null;
    /** Last seen date of the DNS record during the time period. */
    lastSeen?: string | null;
}
export declare const DnsListResponseReverseRecordsItem: S.Schema<DnsListResponseReverseRecordsItem>;
export type DnsListResponseReverseRecordsList = Array<DnsListResponseReverseRecordsItem>;
export declare const DnsListResponseReverseRecordsList: S.Schema<DnsListResponseReverseRecordsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListDnsResponse {
    /** Total results returned based on your search parameters. */
    count?: number | null;
    /** Current page within paginated list of results. */
    page?: number | null;
    /** Number of results per page of results. */
    perPage?: number | null;
    /** Reverse DNS look-ups observed during the time period. */
    reverseRecords?: DnsListResponseReverseRecordsList | null;
}
export declare const ListDnsResponse: S.Schema<ListDnsResponse>;
export interface ListIndicatorFeedPermissionsRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListIndicatorFeedPermissionsRequest: S.Schema<ListIndicatorFeedPermissionsRequest>;
export interface IndicatorFeedsPermissionsListResultItem {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export declare const IndicatorFeedsPermissionsListResultItem: S.Schema<IndicatorFeedsPermissionsListResultItem>;
export type IndicatorFeedsPermissionsListResultList = Array<IndicatorFeedsPermissionsListResultItem>;
export declare const IndicatorFeedsPermissionsListResultList: S.Schema<IndicatorFeedsPermissionsListResultList>;
export type ListIndicatorFeedPermissionsResponse = IndicatorFeedsPermissionsListResultList;
export declare const ListIndicatorFeedPermissionsResponse: S.Schema<ListIndicatorFeedPermissionsResponse>;
export interface ListIndicatorFeedsRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListIndicatorFeedsRequest: S.Schema<ListIndicatorFeedsRequest>;
export interface IndicatorFeedsListResultItem {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export declare const IndicatorFeedsListResultItem: S.Schema<IndicatorFeedsListResultItem>;
export type IndicatorFeedsListResultList = Array<IndicatorFeedsListResultItem>;
export declare const IndicatorFeedsListResultList: S.Schema<IndicatorFeedsListResultList>;
export interface ListIndicatorFeedsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: IndicatorFeedsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListIndicatorFeedsResponse: S.Schema<ListIndicatorFeedsResponse>;
export interface ListSinkholesRequest {
    /** Identifier. */
    accountId: string;
}
export declare const ListSinkholesRequest: S.Schema<ListSinkholesRequest>;
export interface SinkholesListResultItem {
    /** The unique identifier for the sinkhole. */
    id?: string | null;
    /** The account tag that owns this sinkhole. */
    accountTag?: string | null;
    /** The date and time when the sinkhole was created. */
    createdOn?: string | null;
    /** The date and time when the sinkhole was last modified. */
    modifiedOn?: string | null;
    /** The name of the sinkhole. */
    name?: string | null;
    /** The name of the R2 bucket to store results. */
    r2Bucket?: string | null;
    /** The id of the R2 instance. */
    r2Id?: string | null;
}
export declare const SinkholesListResultItem: S.Schema<SinkholesListResultItem>;
export type SinkholesListResultList = Array<SinkholesListResultItem>;
export declare const SinkholesListResultList: S.Schema<SinkholesListResultList>;
export interface ListSinkholesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SinkholesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSinkholesResponse: S.Schema<ListSinkholesResponse>;
export interface PutIndicatorFeedSnapshotRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
    /** The file to upload. Either a plain STIX2/CRDF body or a gzipped one (recognised by 0x1f 0x8b magic bytes or a .gz filename suffix). */
    source?: string;
}
export declare const PutIndicatorFeedSnapshotRequest: S.Schema<PutIndicatorFeedSnapshotRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutIndicatorFeedSnapshotResponse {
    /** Feed id */
    fileId?: number | null;
    /** Name of the file unified in our system */
    filename?: string | null;
    /** Current status of upload, should be unified */
    status?: string | null;
}
export declare const PutIndicatorFeedSnapshotResponse: S.Schema<PutIndicatorFeedSnapshotResponse>;
export type AttackSurfaceReportIssuesSeverityRequestIssueClassList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestIssueClassList: S.Schema<AttackSurfaceReportIssuesSeverityRequestIssueClassList>;
export type AttackSurfaceReportIssuesSeverityRequestIssueClassNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestIssueClassNeqList: S.Schema<AttackSurfaceReportIssuesSeverityRequestIssueClassNeqList>;
export type AttackSurfaceReportIssuesSeverityRequestIssueTypeList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestIssueTypeList: S.Schema<AttackSurfaceReportIssuesSeverityRequestIssueTypeList>;
export type AttackSurfaceReportIssuesSeverityRequestIssueTypeNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestIssueTypeNeqList: S.Schema<AttackSurfaceReportIssuesSeverityRequestIssueTypeNeqList>;
export type AttackSurfaceReportIssuesSeverityRequestProductList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestProductList: S.Schema<AttackSurfaceReportIssuesSeverityRequestProductList>;
export type AttackSurfaceReportIssuesSeverityRequestProductNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestProductNeqList: S.Schema<AttackSurfaceReportIssuesSeverityRequestProductNeqList>;
export type AttackSurfaceReportIssuesSeverityRequestSeverityList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestSeverityList: S.Schema<AttackSurfaceReportIssuesSeverityRequestSeverityList>;
export type AttackSurfaceReportIssuesSeverityRequestSeverityNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestSeverityNeqList: S.Schema<AttackSurfaceReportIssuesSeverityRequestSeverityNeqList>;
export type AttackSurfaceReportIssuesSeverityRequestSubjectList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestSubjectList: S.Schema<AttackSurfaceReportIssuesSeverityRequestSubjectList>;
export type AttackSurfaceReportIssuesSeverityRequestSubjectNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesSeverityRequestSubjectNeqList: S.Schema<AttackSurfaceReportIssuesSeverityRequestSubjectNeqList>;
export interface SeverityAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesSeverityRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesSeverityRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesSeverityRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesSeverityRequestIssueTypeNeqList;
    product?: AttackSurfaceReportIssuesSeverityRequestProductList;
    productNeq?: AttackSurfaceReportIssuesSeverityRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesSeverityRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesSeverityRequestSeverityNeqList;
    subject?: AttackSurfaceReportIssuesSeverityRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesSeverityRequestSubjectNeqList;
}
export declare const SeverityAttackSurfaceReportIssueRequest: S.Schema<SeverityAttackSurfaceReportIssueRequest>;
export type AttackSurfaceReportIssuesSeverityResultItem = AttackSurfaceReportIssuesClassResultItem;
export declare const AttackSurfaceReportIssuesSeverityResultItem: S.Schema<AttackSurfaceReportIssuesClassResultItem>;
export type AttackSurfaceReportIssuesSeverityResultList = Array<AttackSurfaceReportIssuesClassResultItem>;
export declare const AttackSurfaceReportIssuesSeverityResultList: S.Schema<AttackSurfaceReportIssuesSeverityResultList>;
export type SeverityAttackSurfaceReportIssueResponse = AttackSurfaceReportIssuesSeverityResultList;
export declare const SeverityAttackSurfaceReportIssueResponse: S.Schema<SeverityAttackSurfaceReportIssueResponse>;
export type AttackSurfaceReportIssuesTypeRequestIssueClassList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestIssueClassList: S.Schema<AttackSurfaceReportIssuesTypeRequestIssueClassList>;
export type AttackSurfaceReportIssuesTypeRequestIssueClassNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestIssueClassNeqList: S.Schema<AttackSurfaceReportIssuesTypeRequestIssueClassNeqList>;
export type AttackSurfaceReportIssuesTypeRequestIssueTypeList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestIssueTypeList: S.Schema<AttackSurfaceReportIssuesTypeRequestIssueTypeList>;
export type AttackSurfaceReportIssuesTypeRequestIssueTypeNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestIssueTypeNeqList: S.Schema<AttackSurfaceReportIssuesTypeRequestIssueTypeNeqList>;
export type AttackSurfaceReportIssuesTypeRequestProductList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestProductList: S.Schema<AttackSurfaceReportIssuesTypeRequestProductList>;
export type AttackSurfaceReportIssuesTypeRequestProductNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestProductNeqList: S.Schema<AttackSurfaceReportIssuesTypeRequestProductNeqList>;
export type AttackSurfaceReportIssuesTypeRequestSeverityList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestSeverityList: S.Schema<AttackSurfaceReportIssuesTypeRequestSeverityList>;
export type AttackSurfaceReportIssuesTypeRequestSeverityNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestSeverityNeqList: S.Schema<AttackSurfaceReportIssuesTypeRequestSeverityNeqList>;
export type AttackSurfaceReportIssuesTypeRequestSubjectList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestSubjectList: S.Schema<AttackSurfaceReportIssuesTypeRequestSubjectList>;
export type AttackSurfaceReportIssuesTypeRequestSubjectNeqList = Array<string>;
export declare const AttackSurfaceReportIssuesTypeRequestSubjectNeqList: S.Schema<AttackSurfaceReportIssuesTypeRequestSubjectNeqList>;
export interface TypeAttackSurfaceReportIssueRequest {
    /** Identifier. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: AttackSurfaceReportIssuesTypeRequestIssueClassList;
    issueClassNeq?: AttackSurfaceReportIssuesTypeRequestIssueClassNeqList;
    issueType?: AttackSurfaceReportIssuesTypeRequestIssueTypeList;
    issueTypeNeq?: AttackSurfaceReportIssuesTypeRequestIssueTypeNeqList;
    product?: AttackSurfaceReportIssuesTypeRequestProductList;
    productNeq?: AttackSurfaceReportIssuesTypeRequestProductNeqList;
    severity?: AttackSurfaceReportIssuesTypeRequestSeverityList;
    severityNeq?: AttackSurfaceReportIssuesTypeRequestSeverityNeqList;
    subject?: AttackSurfaceReportIssuesTypeRequestSubjectList;
    subjectNeq?: AttackSurfaceReportIssuesTypeRequestSubjectNeqList;
}
export declare const TypeAttackSurfaceReportIssueRequest: S.Schema<TypeAttackSurfaceReportIssueRequest>;
export type AttackSurfaceReportIssuesTypeResultItem = AttackSurfaceReportIssuesClassResultItem;
export declare const AttackSurfaceReportIssuesTypeResultItem: S.Schema<AttackSurfaceReportIssuesClassResultItem>;
export type AttackSurfaceReportIssuesTypeResultList = Array<AttackSurfaceReportIssuesClassResultItem>;
export declare const AttackSurfaceReportIssuesTypeResultList: S.Schema<AttackSurfaceReportIssuesTypeResultList>;
export type TypeAttackSurfaceReportIssueResponse = AttackSurfaceReportIssuesTypeResultList;
export declare const TypeAttackSurfaceReportIssueResponse: S.Schema<TypeAttackSurfaceReportIssueResponse>;
export interface UpdateIndicatorFeedRequest {
    /** Identifier */
    accountId: string;
    /** Indicator feed ID */
    feedId: number;
    /** The new description of the feed */
    description?: string;
    /** The new is_attributable value of the feed */
    isAttributable?: boolean;
    /** The new is_downloadable value of the feed */
    isDownloadable?: boolean;
    /** The new is_public value of the feed */
    isPublic?: boolean;
    /** The new name of the feed */
    name?: string;
}
export declare const UpdateIndicatorFeedRequest: S.Schema<UpdateIndicatorFeedRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateIndicatorFeedResponse {
    /** The unique identifier for the indicator feed */
    id?: number | null;
    /** The date and time when the data entry was created */
    createdOn?: string | null;
    /** The description of the example test */
    description?: string | null;
    /** Whether the indicator feed can be attributed to a provider */
    isAttributable?: boolean | null;
    /** Whether the indicator feed can be downloaded */
    isDownloadable?: boolean | null;
    /** Whether the indicator feed is exposed to customers */
    isPublic?: boolean | null;
    /** The date and time when the data entry was last modified */
    modifiedOn?: string | null;
    /** The name of the indicator feed */
    name?: string | null;
}
export declare const UpdateIndicatorFeedResponse: S.Schema<UpdateIndicatorFeedResponse>;
export type ClassAttackSurfaceReportIssueError = CloudflareOpError;
/** Retrieves Security Center issue counts aggregated by classification class. */
export declare const classAttackSurfaceReportIssue: API.OperationMethod<ClassAttackSurfaceReportIssueRequest, ClassAttackSurfaceReportIssueResponse, ClassAttackSurfaceReportIssueError, CloudflareOpContext>;
export type CreateIndicatorFeedError = IndicatorFeedsNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new custom threat indicator feed for sharing threat intelligence data. */
export declare const createIndicatorFeed: API.OperationMethod<CreateIndicatorFeedRequest, CreateIndicatorFeedResponse, CreateIndicatorFeedError, CloudflareOpContext>;
export type CreateIndicatorFeedPermissionError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Grants access permissions for a custom threat indicator feed to other accounts. */
export declare const createIndicatorFeedPermission: API.OperationMethod<CreateIndicatorFeedPermissionRequest, CreateIndicatorFeedPermissionResponse, CreateIndicatorFeedPermissionError, CloudflareOpContext>;
export type CreateMiscategorizationError = CloudflareOpError;
/** Allows you to submit requests to change a domain’s category. Requests that include category `169` (New Domains) or category `177` (Newly Seen) in any of `content_adds`, `content_removes`, `security_adds`, or `security_removes` will be rejected with a `400 Bad Request`. These categories are automatically managed and fall off 30 days after they are applied. */
export declare const createMiscategorization: API.OperationMethod<CreateMiscategorizationRequest, CreateMiscategorizationResponse, CreateMiscategorizationError, CloudflareOpContext>;
export type DataIndicatorFeedError = CloudflareOpError;
/** Retrieves the raw data entries in a custom threat indicator feed. */
export declare const dataIndicatorFeed: API.OperationMethod<DataIndicatorFeedRequest, DataIndicatorFeedResponse, DataIndicatorFeedError, CloudflareOpContext>;
export type DeleteIndicatorFeedPermissionError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Revokes access permissions for a custom threat indicator feed. */
export declare const deleteIndicatorFeedPermission: API.OperationMethod<DeleteIndicatorFeedPermissionRequest, DeleteIndicatorFeedPermissionResponse, DeleteIndicatorFeedPermissionError, CloudflareOpContext>;
export type DismissAttackSurfaceReportIssueError = CloudflareOpError;
/** Deprecated endpoint for archiving Security Center insights. Use the newer archive-security-center-insight endpoint instead. */
export declare const dismissAttackSurfaceReportIssue: API.OperationMethod<DismissAttackSurfaceReportIssueRequest, DismissAttackSurfaceReportIssueResponse, DismissAttackSurfaceReportIssueError, CloudflareOpContext>;
export type GetAsnError = CloudflareOpError;
/** Gets an overview of the Autonomous System Number (ASN) and a list of subnets for it. */
export declare const getAsn: API.OperationMethod<GetAsnRequest, GetAsnResponse, GetAsnError, CloudflareOpContext>;
export type GetAsnSubnetError = CloudflareOpError;
/** Get ASN Subnets. */
export declare const getAsnSubnet: API.OperationMethod<GetAsnSubnetRequest, GetAsnSubnetResponse, GetAsnSubnetError, CloudflareOpContext>;
export type GetAttackSurfaceReportIssueTypeError = CloudflareOpError;
/** Lists all available issue types in Security Center, describing categories of security issues. */
export declare const getAttackSurfaceReportIssueType: API.PaginatedOperationMethod<GetAttackSurfaceReportIssueTypeRequest, GetAttackSurfaceReportIssueTypeResponse, GetAttackSurfaceReportIssueTypeError, CloudflareOpContext, string>;
export type GetDomainError = CloudflareOpError;
/** Gets security details and statistics about a domain. */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, CloudflareOpContext>;
export type GetDomainBulkError = CloudflareOpError;
/** Returns security details and statistics about multiple domains in a single request. **Behavior change — domain ranking is becoming opt-in.** This endpoint previously included domain ranking data in every response and accepted a `skip_ranking=true` query parameter to opt out. That parameter is being deprecated and ranking will no longer be returned by default. Callers that want ranking data must pass `include_ranking=true`. The `skip_ranking` parameter will be silently ignored once the change ships. */
export declare const getDomainBulk: API.OperationMethod<GetDomainBulkRequest, GetDomainBulkResponse, GetDomainBulkError, CloudflareOpContext>;
export type GetDomainHistoryError = CloudflareOpError;
/** Gets historical security threat and content categories currently and previously assigned to a domain. */
export declare const getDomainHistory: API.OperationMethod<GetDomainHistoryRequest, GetDomainHistoryResponse, GetDomainHistoryError, CloudflareOpContext>;
export type GetIndicatorFeedError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a specific custom threat indicator feed. */
export declare const getIndicatorFeed: API.OperationMethod<GetIndicatorFeedRequest, GetIndicatorFeedResponse, GetIndicatorFeedError, CloudflareOpContext>;
export type GetIpError = CloudflareOpError;
/** Gets the geolocation, ASN, infrastructure type of the ASN, and any security threat categories of an IP address. **Must provide ip query parameters.** For example, `/intel/ip?ipv4=1.1.1.1` or `/intel/ip?ipv6=2001:db8::1`. */
export declare const getIp: API.OperationMethod<GetIpRequest, GetIpResponse, GetIpError, CloudflareOpContext>;
export type GetWhoiError = CloudflareOpError;
/** Retrieves WHOIS registration data for a domain, including registrant and nameserver information. */
export declare const getWhoi: API.OperationMethod<GetWhoiRequest, GetWhoiResponse, GetWhoiError, CloudflareOpContext>;
export type ListAttackSurfaceReportIssuesError = CloudflareOpError;
/** Lists all Security Center issues for the account, showing active security problems requiring attention. */
export declare const listAttackSurfaceReportIssues: API.OperationMethod<ListAttackSurfaceReportIssuesRequest, ListAttackSurfaceReportIssuesResponse, ListAttackSurfaceReportIssuesError, CloudflareOpContext>;
export type ListDnsError = CloudflareOpError;
/** Gets a list of all the domains that have resolved to a specific IP address. */
export declare const listDns: API.OperationMethod<ListDnsRequest, ListDnsResponse, ListDnsError, CloudflareOpContext>;
export type ListIndicatorFeedPermissionsError = Forbidden | CloudflareOpError;
/** Lists current access permissions for custom threat indicator feeds. */
export declare const listIndicatorFeedPermissions: API.OperationMethod<ListIndicatorFeedPermissionsRequest, ListIndicatorFeedPermissionsResponse, ListIndicatorFeedPermissionsError, CloudflareOpContext>;
export type ListIndicatorFeedsError = Forbidden | CloudflareOpError;
/** Retrieves details for all accessible custom threat indicator feeds. */
export declare const listIndicatorFeeds: API.PaginatedOperationMethod<ListIndicatorFeedsRequest, ListIndicatorFeedsResponse, ListIndicatorFeedsError, CloudflareOpContext, IndicatorFeedsListResultItem>;
export type ListSinkholesError = CloudflareOpError;
/** Lists sinkholes owned by the account for redirecting malicious traffic. */
export declare const listSinkholes: API.PaginatedOperationMethod<ListSinkholesRequest, ListSinkholesResponse, ListSinkholesError, CloudflareOpContext, SinkholesListResultItem>;
export type PutIndicatorFeedSnapshotError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Revises the raw data entries in a custom threat indicator feed. Accepts both plain and gzipped STIX2/CRDF bodies. Gzip is detected by RFC 1952 magic bytes (`0x1f 0x8b`) and/or a `.gz` filename suffix (case-insensitive) — either signal alone is sufficient to trigger the gzip path; if the body is not valid gzip, the upload fails fast. Customers are encouraged to gzip larger uploads — the api-gateway 500 MB body cap applies to the on-the-wire (compressed) size, so gzip lets a single upload carry several GiB of decompressed STIX. */
export declare const putIndicatorFeedSnapshot: API.OperationMethod<PutIndicatorFeedSnapshotRequest, PutIndicatorFeedSnapshotResponse, PutIndicatorFeedSnapshotError, CloudflareOpContext>;
export type SeverityAttackSurfaceReportIssueError = CloudflareOpError;
/** Retrieves Security Center issue counts aggregated by severity level. */
export declare const severityAttackSurfaceReportIssue: API.OperationMethod<SeverityAttackSurfaceReportIssueRequest, SeverityAttackSurfaceReportIssueResponse, SeverityAttackSurfaceReportIssueError, CloudflareOpContext>;
export type TypeAttackSurfaceReportIssueError = CloudflareOpError;
/** Retrieves Security Center issue counts aggregated by issue type. */
export declare const typeAttackSurfaceReportIssue: API.OperationMethod<TypeAttackSurfaceReportIssueRequest, TypeAttackSurfaceReportIssueResponse, TypeAttackSurfaceReportIssueError, CloudflareOpContext>;
export type UpdateIndicatorFeedError = IndicatorFeedNotFound | Forbidden | CloudflareOpError;
/** Revises details for a specific custom threat indicator feed. */
export declare const updateIndicatorFeed: API.OperationMethod<UpdateIndicatorFeedRequest, UpdateIndicatorFeedResponse, UpdateIndicatorFeedError, CloudflareOpContext>;
//# sourceMappingURL=intel.d.ts.map