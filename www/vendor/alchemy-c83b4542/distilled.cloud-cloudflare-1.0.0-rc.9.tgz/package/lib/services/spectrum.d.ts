import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SpectrumAppNotFound_base: S.Class<SpectrumAppNotFound, S.TaggedStruct<"SpectrumAppNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SpectrumAppNotFound extends /*@__PURE__*/ SpectrumAppNotFound_base {
}
declare const SpectrumProtocolNotAvailable_base: S.Class<SpectrumProtocolNotAvailable, S.TaggedStruct<"SpectrumProtocolNotAvailable", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SpectrumProtocolNotAvailable extends /*@__PURE__*/ SpectrumProtocolNotAvailable_base {
}
export type AppsCreateRequestDnsSpectrumConfigAppConfigType = "CNAME" | "ADDRESS";
export declare const AppsCreateRequestDnsSpectrumConfigAppConfigType: any;
export interface AppsCreateRequestDnsSpectrumConfigAppConfig {
    /** The name of the DNS record associated with the application. */
    name?: string;
    /** The type of DNS record associated with the application. */
    type?: AppsCreateRequestDnsSpectrumConfigAppConfigType | (string & {});
}
export declare const AppsCreateRequestDnsSpectrumConfigAppConfig: S.Schema<AppsCreateRequestDnsSpectrumConfigAppConfig>;
export type AppsCreateRequestTrafficType = "direct" | "http" | "https";
export declare const AppsCreateRequestTrafficType: any;
export type AppsCreateRequestEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export declare const AppsCreateRequestEdgeIpsDynamicConnectivity: any;
export type AppsCreateRequestEdgeIpsDynamicType = "dynamic";
export declare const AppsCreateRequestEdgeIpsDynamicType: any;
export interface AppsCreateRequestEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsCreateRequestEdgeIpsDynamicConnectivity | (string & {});
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsCreateRequestEdgeIpsDynamicType | (string & {});
}
export declare const AppsCreateRequestEdgeIpsDynamic: S.Schema<AppsCreateRequestEdgeIpsDynamic>;
export type AppsCreateRequestEdgeIpsStaticIpsList = Array<string>;
export declare const AppsCreateRequestEdgeIpsStaticIpsList: S.Schema<AppsCreateRequestEdgeIpsStaticIpsList>;
export type AppsCreateRequestEdgeIpsStaticType = "static";
export declare const AppsCreateRequestEdgeIpsStaticType: any;
export interface AppsCreateRequestEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsCreateRequestEdgeIpsStaticIpsList;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsCreateRequestEdgeIpsStaticType | (string & {});
}
export declare const AppsCreateRequestEdgeIpsStatic: S.Schema<AppsCreateRequestEdgeIpsStatic>;
export type AppsCreateRequestEdgeIps = AppsCreateRequestEdgeIpsDynamic | AppsCreateRequestEdgeIpsStatic;
export declare const AppsCreateRequestEdgeIps: any;
export type AppsCreateRequestOriginDirectList = Array<string>;
export declare const AppsCreateRequestOriginDirectList: S.Schema<AppsCreateRequestOriginDirectList>;
export type AppsCreateRequestOriginDnsType = "" | "A" | "AAAA" | "SRV";
export declare const AppsCreateRequestOriginDnsType: any;
export interface AppsCreateRequestOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsCreateRequestOriginDnsType | (string & {});
}
export declare const AppsCreateRequestOriginDns: S.Schema<AppsCreateRequestOriginDns>;
export type AppsCreateRequestOriginPort = string | number;
export declare const AppsCreateRequestOriginPort: any;
export type AppsCreateRequestProxyProtocol = "off" | "v1" | "v2" | "simple";
export declare const AppsCreateRequestProxyProtocol: any;
export type AppsCreateRequestTls = "off" | "flexible" | "full" | "strict";
export declare const AppsCreateRequestTls: any;
export interface CreateAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsCreateRequestDnsSpectrumConfigAppConfig;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. */
    trafficType?: AppsCreateRequestTrafficType | (string & {});
    /** Enables Argo Smart Routing for this application. */
    argoSmartRouting?: boolean;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsCreateRequestEdgeIps;
    /** Enables IP Access Rules for this application. */
    ipFirewall?: boolean;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsCreateRequestOriginDirectList;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsCreateRequestOriginDns;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. */
    originPort?: AppsCreateRequestOriginPort;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsCreateRequestProxyProtocol | (string & {});
    /** The type of TLS termination associated with the application. */
    tls?: AppsCreateRequestTls | (string & {});
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string;
}
export declare const CreateAppRequest: S.Schema<CreateAppRequest>;
export type AppsCreateResultSpectrumConfigAppConfigDnsType = "CNAME" | "ADDRESS";
export declare const AppsCreateResultSpectrumConfigAppConfigDnsType: any;
export interface AppsCreateResultSpectrumConfigAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsCreateResultSpectrumConfigAppConfigDnsType | null;
}
export declare const AppsCreateResultSpectrumConfigAppConfigDns: S.Schema<AppsCreateResultSpectrumConfigAppConfigDns>;
export type AppsCreateResultSpectrumConfigAppConfigTrafficType = "direct" | "http" | "https";
export declare const AppsCreateResultSpectrumConfigAppConfigTrafficType: any;
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity: any;
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicType = "dynamic";
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicType: any;
export interface AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamicType | null;
}
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamic: S.Schema<AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamic>;
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList = Array<string>;
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList: S.Schema<AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList>;
export type AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticType = "static";
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticType: any;
export interface AppsCreateResultSpectrumConfigAppConfigEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsCreateResultSpectrumConfigAppConfigEdgeIpsStaticType | null;
}
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIpsStatic: S.Schema<AppsCreateResultSpectrumConfigAppConfigEdgeIpsStatic>;
export type AppsCreateResultSpectrumConfigAppConfigEdgeIps = AppsCreateResultSpectrumConfigAppConfigEdgeIpsDynamic | AppsCreateResultSpectrumConfigAppConfigEdgeIpsStatic;
export declare const AppsCreateResultSpectrumConfigAppConfigEdgeIps: any;
export type AppsCreateResultSpectrumConfigAppConfigOriginDirectList = Array<string>;
export declare const AppsCreateResultSpectrumConfigAppConfigOriginDirectList: S.Schema<AppsCreateResultSpectrumConfigAppConfigOriginDirectList>;
export type AppsCreateResultSpectrumConfigAppConfigOriginDnsType = "" | "A" | "AAAA" | "SRV";
export declare const AppsCreateResultSpectrumConfigAppConfigOriginDnsType: any;
export interface AppsCreateResultSpectrumConfigAppConfigOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsCreateResultSpectrumConfigAppConfigOriginDnsType | null;
}
export declare const AppsCreateResultSpectrumConfigAppConfigOriginDns: S.Schema<AppsCreateResultSpectrumConfigAppConfigOriginDns>;
export type AppsCreateResultSpectrumConfigAppConfigOriginPort = string | number;
export declare const AppsCreateResultSpectrumConfigAppConfigOriginPort: any;
export type AppsCreateResultSpectrumConfigAppConfigProxyProtocol = "off" | "v1" | "v2" | "simple";
export declare const AppsCreateResultSpectrumConfigAppConfigProxyProtocol: any;
export type AppsCreateResultSpectrumConfigAppConfigTls = "off" | "flexible" | "full" | "strict";
export declare const AppsCreateResultSpectrumConfigAppConfigTls: any;
export interface AppsCreateResultSpectrumConfigAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsCreateResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. */
    trafficType: AppsCreateResultSpectrumConfigAppConfigTrafficType;
    /** Enables Argo Smart Routing for this application. */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsCreateResultSpectrumConfigAppConfigEdgeIps | null;
    /** Enables IP Access Rules for this application. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsCreateResultSpectrumConfigAppConfigOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsCreateResultSpectrumConfigAppConfigOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. */
    originPort?: AppsCreateResultSpectrumConfigAppConfigOriginPort | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsCreateResultSpectrumConfigAppConfigProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsCreateResultSpectrumConfigAppConfigTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export declare const AppsCreateResultSpectrumConfigAppConfig: S.Schema<AppsCreateResultSpectrumConfigAppConfig>;
export type AppsCreateResultSpectrumConfigPaygoAppConfigOriginDirectList = Array<string>;
export declare const AppsCreateResultSpectrumConfigPaygoAppConfigOriginDirectList: S.Schema<AppsCreateResultSpectrumConfigPaygoAppConfigOriginDirectList>;
export interface AppsCreateResultSpectrumConfigPaygoAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsCreateResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsCreateResultSpectrumConfigPaygoAppConfigOriginDirectList | null;
}
export declare const AppsCreateResultSpectrumConfigPaygoAppConfig: S.Schema<AppsCreateResultSpectrumConfigPaygoAppConfig>;
export type AppsCreateResult = AppsCreateResultSpectrumConfigAppConfig | AppsCreateResultSpectrumConfigPaygoAppConfig;
export declare const AppsCreateResult: any;
export type CreateAppResponse = AppsCreateResult;
export declare const CreateAppResponse: S.Schema<CreateAppResponse>;
export interface DeleteAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** App identifier. */
    appId: string;
}
export declare const DeleteAppRequest: S.Schema<DeleteAppRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppResponse {
    /** Identifier. */
    id: string;
}
export declare const DeleteAppResponse: S.Schema<DeleteAppResponse>;
export interface GetAnalyticAggregateCurrentRequest {
    /** Identifier. */
    zoneId: string;
    /** Comma-delimited list of Spectrum Application Id(s). If provided, the response will be limited to Spectrum Application Id(s) that match. */
    appID?: string;
    /** Co-location identifier. */
    coloName?: string;
}
export declare const GetAnalyticAggregateCurrentRequest: S.Schema<GetAnalyticAggregateCurrentRequest>;
export interface AnalyticsAggregatesCurrentsGetResultItem {
    /** Application identifier. */
    appID: string;
    /** Number of bytes sent. */
    bytesEgress: number;
    /** Number of bytes received. */
    bytesIngress: number;
    /** Number of connections. */
    connections: number;
    /** Average duration of connections. */
    durationAvg: number;
}
export declare const AnalyticsAggregatesCurrentsGetResultItem: S.Schema<AnalyticsAggregatesCurrentsGetResultItem>;
export type AnalyticsAggregatesCurrentsGetResultList = Array<AnalyticsAggregatesCurrentsGetResultItem>;
export declare const AnalyticsAggregatesCurrentsGetResultList: S.Schema<AnalyticsAggregatesCurrentsGetResultList>;
export type GetAnalyticAggregateCurrentResponse = AnalyticsAggregatesCurrentsGetResultList;
export declare const GetAnalyticAggregateCurrentResponse: S.Schema<GetAnalyticAggregateCurrentResponse>;
export type AnalyticsEventsBytimesGetRequestTimeDelta = "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export declare const AnalyticsEventsBytimesGetRequestTimeDelta: any;
export type AnalyticsEventsBytimesGetRequestDimensionsList = Array<string>;
export declare const AnalyticsEventsBytimesGetRequestDimensionsList: S.Schema<AnalyticsEventsBytimesGetRequestDimensionsList>;
export type AnalyticsEventsBytimesGetRequestMetrics = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export declare const AnalyticsEventsBytimesGetRequestMetrics: any;
export type AnalyticsEventsBytimesGetRequestMetricsList = Array<AnalyticsEventsBytimesGetRequestMetrics | (string & {})>;
export declare const AnalyticsEventsBytimesGetRequestMetricsList: S.Schema<AnalyticsEventsBytimesGetRequestMetricsList>;
export type AnalyticsEventsBytimesGetRequestSortList = Array<string>;
export declare const AnalyticsEventsBytimesGetRequestSortList: S.Schema<AnalyticsEventsBytimesGetRequestSortList>;
export interface GetAnalyticEventBytimeRequest {
    /** Identifier. */
    zoneId: string;
    /** Used to select time series resolution. */
    timeDelta: AnalyticsEventsBytimesGetRequestTimeDelta | (string & {});
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsBytimesGetRequestDimensionsList;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsBytimesGetRequestMetricsList;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsBytimesGetRequestSortList;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string;
}
export declare const GetAnalyticEventBytimeRequest: S.Schema<GetAnalyticEventBytimeRequest>;
export type AnalyticsEventsBytimesGetResponseDataItemDimensionsList = Array<string>;
export declare const AnalyticsEventsBytimesGetResponseDataItemDimensionsList: S.Schema<AnalyticsEventsBytimesGetResponseDataItemDimensionsList>;
export type AnalyticsEventsBytimesGetResponseDataItemMetricsCase0List = Array<number>;
export declare const AnalyticsEventsBytimesGetResponseDataItemMetricsCase0List: S.Schema<AnalyticsEventsBytimesGetResponseDataItemMetricsCase0List>;
export type AnalyticsEventsBytimesGetResponseDataItemMetricsCase1ItemList = Array<number>;
export declare const AnalyticsEventsBytimesGetResponseDataItemMetricsCase1ItemList: S.Schema<AnalyticsEventsBytimesGetResponseDataItemMetricsCase1ItemList>;
export type AnalyticsEventsBytimesGetResponseDataItemMetricsCase1List = Array<AnalyticsEventsBytimesGetResponseDataItemMetricsCase1ItemList>;
export declare const AnalyticsEventsBytimesGetResponseDataItemMetricsCase1List: S.Schema<AnalyticsEventsBytimesGetResponseDataItemMetricsCase1List>;
export type AnalyticsEventsBytimesGetResponseDataItemMetrics = AnalyticsEventsBytimesGetResponseDataItemMetricsCase0List | AnalyticsEventsBytimesGetResponseDataItemMetricsCase1List;
export declare const AnalyticsEventsBytimesGetResponseDataItemMetrics: any;
export interface AnalyticsEventsBytimesGetResponseDataItem {
    dimensions?: AnalyticsEventsBytimesGetResponseDataItemDimensionsList | null;
    metrics?: AnalyticsEventsBytimesGetResponseDataItemMetrics | null;
}
export declare const AnalyticsEventsBytimesGetResponseDataItem: S.Schema<AnalyticsEventsBytimesGetResponseDataItem>;
export type AnalyticsEventsBytimesGetResponseDataList = Array<AnalyticsEventsBytimesGetResponseDataItem>;
export declare const AnalyticsEventsBytimesGetResponseDataList: S.Schema<AnalyticsEventsBytimesGetResponseDataList>;
export type AnalyticsEventsBytimesGetResponseMaxMap = {
    [key: string]: number | undefined;
};
export declare const AnalyticsEventsBytimesGetResponseMaxMap: S.Schema<AnalyticsEventsBytimesGetResponseMaxMap>;
export type AnalyticsEventsBytimesGetResponseMinMap = {
    [key: string]: number | undefined;
};
export declare const AnalyticsEventsBytimesGetResponseMinMap: S.Schema<AnalyticsEventsBytimesGetResponseMinMap>;
export type AnalyticsEventsBytimesGetResponseQueryDimensionsItem = "event" | "appID" | "coloName" | "ipVersion";
export declare const AnalyticsEventsBytimesGetResponseQueryDimensionsItem: any;
export type AnalyticsEventsBytimesGetResponseQueryDimensionsList = Array<AnalyticsEventsBytimesGetResponseQueryDimensionsItem>;
export declare const AnalyticsEventsBytimesGetResponseQueryDimensionsList: S.Schema<AnalyticsEventsBytimesGetResponseQueryDimensionsList>;
export type AnalyticsEventsBytimesGetResponseQueryMetricsItem = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export declare const AnalyticsEventsBytimesGetResponseQueryMetricsItem: any;
export type AnalyticsEventsBytimesGetResponseQueryMetricsList = Array<AnalyticsEventsBytimesGetResponseQueryMetricsItem>;
export declare const AnalyticsEventsBytimesGetResponseQueryMetricsList: S.Schema<AnalyticsEventsBytimesGetResponseQueryMetricsList>;
export type AnalyticsEventsBytimesGetResponseQuerySortList = Array<string>;
export declare const AnalyticsEventsBytimesGetResponseQuerySortList: S.Schema<AnalyticsEventsBytimesGetResponseQuerySortList>;
export interface AnalyticsEventsBytimesGetResponseQuery {
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsBytimesGetResponseQueryDimensionsList | null;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string | null;
    /** Limit number of returned metrics. */
    limit?: number | null;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsBytimesGetResponseQueryMetricsList | null;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string | null;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsBytimesGetResponseQuerySortList | null;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string | null;
}
export declare const AnalyticsEventsBytimesGetResponseQuery: S.Schema<AnalyticsEventsBytimesGetResponseQuery>;
export type AnalyticsEventsBytimesGetResponseTotalsMap = {
    [key: string]: number | undefined;
};
export declare const AnalyticsEventsBytimesGetResponseTotalsMap: S.Schema<AnalyticsEventsBytimesGetResponseTotalsMap>;
export type AnalyticsEventsBytimesGetResponseTimeIntervalsItemList = Array<string>;
export declare const AnalyticsEventsBytimesGetResponseTimeIntervalsItemList: S.Schema<AnalyticsEventsBytimesGetResponseTimeIntervalsItemList>;
export type AnalyticsEventsBytimesGetResponseTimeIntervalsList = Array<AnalyticsEventsBytimesGetResponseTimeIntervalsItemList>;
export declare const AnalyticsEventsBytimesGetResponseTimeIntervalsList: S.Schema<AnalyticsEventsBytimesGetResponseTimeIntervalsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticEventBytimeResponse {
    /** List of columns returned by the analytics query. */
    data: AnalyticsEventsBytimesGetResponseDataList;
    /** Number of seconds between current time and last processed event, i.e. how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum result for each selected metrics across all data. */
    max: AnalyticsEventsBytimesGetResponseMaxMap;
    /** Minimum result for each selected metrics across all data. */
    min: AnalyticsEventsBytimesGetResponseMinMap;
    query: AnalyticsEventsBytimesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total result for each selected metrics across all data. */
    totals: AnalyticsEventsBytimesGetResponseTotalsMap;
    /** List of time interval buckets: [start, end]. */
    timeIntervals?: AnalyticsEventsBytimesGetResponseTimeIntervalsList | null;
}
export declare const GetAnalyticEventBytimeResponse: S.Schema<GetAnalyticEventBytimeResponse>;
export type AnalyticsEventsSummariesGetRequestDimensionsList = Array<string>;
export declare const AnalyticsEventsSummariesGetRequestDimensionsList: S.Schema<AnalyticsEventsSummariesGetRequestDimensionsList>;
export type AnalyticsEventsSummariesGetRequestMetrics = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export declare const AnalyticsEventsSummariesGetRequestMetrics: any;
export type AnalyticsEventsSummariesGetRequestMetricsList = Array<AnalyticsEventsSummariesGetRequestMetrics | (string & {})>;
export declare const AnalyticsEventsSummariesGetRequestMetricsList: S.Schema<AnalyticsEventsSummariesGetRequestMetricsList>;
export type AnalyticsEventsSummariesGetRequestSortList = Array<string>;
export declare const AnalyticsEventsSummariesGetRequestSortList: S.Schema<AnalyticsEventsSummariesGetRequestSortList>;
export interface GetAnalyticEventSummaryRequest {
    /** Identifier. */
    zoneId: string;
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsSummariesGetRequestDimensionsList;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsSummariesGetRequestMetricsList;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsSummariesGetRequestSortList;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string;
}
export declare const GetAnalyticEventSummaryRequest: S.Schema<GetAnalyticEventSummaryRequest>;
export type AnalyticsEventsSummariesGetResponseDataItemDimensionsList = Array<string>;
export declare const AnalyticsEventsSummariesGetResponseDataItemDimensionsList: S.Schema<AnalyticsEventsSummariesGetResponseDataItemDimensionsList>;
export type AnalyticsEventsSummariesGetResponseDataItemMetricsCase0List = Array<number>;
export declare const AnalyticsEventsSummariesGetResponseDataItemMetricsCase0List: S.Schema<AnalyticsEventsSummariesGetResponseDataItemMetricsCase0List>;
export type AnalyticsEventsSummariesGetResponseDataItemMetricsCase1ItemList = Array<number>;
export declare const AnalyticsEventsSummariesGetResponseDataItemMetricsCase1ItemList: S.Schema<AnalyticsEventsSummariesGetResponseDataItemMetricsCase1ItemList>;
export type AnalyticsEventsSummariesGetResponseDataItemMetricsCase1List = Array<AnalyticsEventsSummariesGetResponseDataItemMetricsCase1ItemList>;
export declare const AnalyticsEventsSummariesGetResponseDataItemMetricsCase1List: S.Schema<AnalyticsEventsSummariesGetResponseDataItemMetricsCase1List>;
export type AnalyticsEventsSummariesGetResponseDataItemMetrics = AnalyticsEventsSummariesGetResponseDataItemMetricsCase0List | AnalyticsEventsSummariesGetResponseDataItemMetricsCase1List;
export declare const AnalyticsEventsSummariesGetResponseDataItemMetrics: any;
export interface AnalyticsEventsSummariesGetResponseDataItem {
    dimensions?: AnalyticsEventsSummariesGetResponseDataItemDimensionsList | null;
    metrics?: AnalyticsEventsSummariesGetResponseDataItemMetrics | null;
}
export declare const AnalyticsEventsSummariesGetResponseDataItem: S.Schema<AnalyticsEventsSummariesGetResponseDataItem>;
export type AnalyticsEventsSummariesGetResponseDataList = Array<AnalyticsEventsSummariesGetResponseDataItem>;
export declare const AnalyticsEventsSummariesGetResponseDataList: S.Schema<AnalyticsEventsSummariesGetResponseDataList>;
export type AnalyticsEventsSummariesGetResponseMaxMap = {
    [key: string]: number | undefined;
};
export declare const AnalyticsEventsSummariesGetResponseMaxMap: S.Schema<AnalyticsEventsSummariesGetResponseMaxMap>;
export type AnalyticsEventsSummariesGetResponseMinMap = {
    [key: string]: number | undefined;
};
export declare const AnalyticsEventsSummariesGetResponseMinMap: S.Schema<AnalyticsEventsSummariesGetResponseMinMap>;
export type AnalyticsEventsSummariesGetResponseQueryDimensionsItem = "event" | "appID" | "coloName" | "ipVersion";
export declare const AnalyticsEventsSummariesGetResponseQueryDimensionsItem: any;
export type AnalyticsEventsSummariesGetResponseQueryDimensionsList = Array<AnalyticsEventsSummariesGetResponseQueryDimensionsItem>;
export declare const AnalyticsEventsSummariesGetResponseQueryDimensionsList: S.Schema<AnalyticsEventsSummariesGetResponseQueryDimensionsList>;
export type AnalyticsEventsSummariesGetResponseQueryMetricsItem = "count" | "bytesIngress" | "bytesEgress" | "durationAvg" | "durationMedian" | "duration90th" | "duration99th";
export declare const AnalyticsEventsSummariesGetResponseQueryMetricsItem: any;
export type AnalyticsEventsSummariesGetResponseQueryMetricsList = Array<AnalyticsEventsSummariesGetResponseQueryMetricsItem>;
export declare const AnalyticsEventsSummariesGetResponseQueryMetricsList: S.Schema<AnalyticsEventsSummariesGetResponseQueryMetricsList>;
export type AnalyticsEventsSummariesGetResponseQuerySortList = Array<string>;
export declare const AnalyticsEventsSummariesGetResponseQuerySortList: S.Schema<AnalyticsEventsSummariesGetResponseQuerySortList>;
export interface AnalyticsEventsSummariesGetResponseQuery {
    /** Can be used to break down the data by given attributes. Options are: */
    dimensions?: AnalyticsEventsSummariesGetResponseQueryDimensionsList | null;
    /** Used to filter rows by one or more dimensions. Filters can be combined using OR and AND boolean logic. AND takes precedence over OR in all the expressions. The OR operator is defined using a comma (,) or OR keyword surrounded by whitespace. The AND operator is defined using a semicolon (;) or AND keyword surrounded by whitespace. Note that the semicolon is a reserved character in URLs (rfc1738) and needs to be percent-encoded as %3B. Comparison options are: */
    filters?: string | null;
    /** Limit number of returned metrics. */
    limit?: number | null;
    /** One or more metrics to compute. Options are: */
    metrics?: AnalyticsEventsSummariesGetResponseQueryMetricsList | null;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string | null;
    /** The sort order for the result set; sort fields must be included in `metrics` or `dimensions`. */
    sort?: AnalyticsEventsSummariesGetResponseQuerySortList | null;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string | null;
}
export declare const AnalyticsEventsSummariesGetResponseQuery: S.Schema<AnalyticsEventsSummariesGetResponseQuery>;
export type AnalyticsEventsSummariesGetResponseTotalsMap = {
    [key: string]: number | undefined;
};
export declare const AnalyticsEventsSummariesGetResponseTotalsMap: S.Schema<AnalyticsEventsSummariesGetResponseTotalsMap>;
export type AnalyticsEventsSummariesGetResponseTimeIntervalsItemList = Array<string>;
export declare const AnalyticsEventsSummariesGetResponseTimeIntervalsItemList: S.Schema<AnalyticsEventsSummariesGetResponseTimeIntervalsItemList>;
export type AnalyticsEventsSummariesGetResponseTimeIntervalsList = Array<AnalyticsEventsSummariesGetResponseTimeIntervalsItemList>;
export declare const AnalyticsEventsSummariesGetResponseTimeIntervalsList: S.Schema<AnalyticsEventsSummariesGetResponseTimeIntervalsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticEventSummaryResponse {
    /** List of columns returned by the analytics query. */
    data: AnalyticsEventsSummariesGetResponseDataList;
    /** Number of seconds between current time and last processed event, i.e. how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum result for each selected metrics across all data. */
    max: AnalyticsEventsSummariesGetResponseMaxMap;
    /** Minimum result for each selected metrics across all data. */
    min: AnalyticsEventsSummariesGetResponseMinMap;
    query: AnalyticsEventsSummariesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total result for each selected metrics across all data. */
    totals: AnalyticsEventsSummariesGetResponseTotalsMap;
    /** List of time interval buckets: [start, end]. */
    timeIntervals?: AnalyticsEventsSummariesGetResponseTimeIntervalsList | null;
}
export declare const GetAnalyticEventSummaryResponse: S.Schema<GetAnalyticEventSummaryResponse>;
export interface GetAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** App identifier. */
    appId: string;
}
export declare const GetAppRequest: S.Schema<GetAppRequest>;
export type AppsGetResultSpectrumConfigAppConfigDnsType = "CNAME" | "ADDRESS";
export declare const AppsGetResultSpectrumConfigAppConfigDnsType: any;
export interface AppsGetResultSpectrumConfigAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsGetResultSpectrumConfigAppConfigDnsType | null;
}
export declare const AppsGetResultSpectrumConfigAppConfigDns: S.Schema<AppsGetResultSpectrumConfigAppConfigDns>;
export type AppsGetResultSpectrumConfigAppConfigTrafficType = "direct" | "http" | "https";
export declare const AppsGetResultSpectrumConfigAppConfigTrafficType: any;
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity: any;
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicType = "dynamic";
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicType: any;
export interface AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamicType | null;
}
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamic: S.Schema<AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamic>;
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticIpsList = Array<string>;
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticIpsList: S.Schema<AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticIpsList>;
export type AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticType = "static";
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticType: any;
export interface AppsGetResultSpectrumConfigAppConfigEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsGetResultSpectrumConfigAppConfigEdgeIpsStaticType | null;
}
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIpsStatic: S.Schema<AppsGetResultSpectrumConfigAppConfigEdgeIpsStatic>;
export type AppsGetResultSpectrumConfigAppConfigEdgeIps = AppsGetResultSpectrumConfigAppConfigEdgeIpsDynamic | AppsGetResultSpectrumConfigAppConfigEdgeIpsStatic;
export declare const AppsGetResultSpectrumConfigAppConfigEdgeIps: any;
export type AppsGetResultSpectrumConfigAppConfigOriginDirectList = Array<string>;
export declare const AppsGetResultSpectrumConfigAppConfigOriginDirectList: S.Schema<AppsGetResultSpectrumConfigAppConfigOriginDirectList>;
export type AppsGetResultSpectrumConfigAppConfigOriginDnsType = "" | "A" | "AAAA" | "SRV";
export declare const AppsGetResultSpectrumConfigAppConfigOriginDnsType: any;
export interface AppsGetResultSpectrumConfigAppConfigOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsGetResultSpectrumConfigAppConfigOriginDnsType | null;
}
export declare const AppsGetResultSpectrumConfigAppConfigOriginDns: S.Schema<AppsGetResultSpectrumConfigAppConfigOriginDns>;
export type AppsGetResultSpectrumConfigAppConfigOriginPort = string | number;
export declare const AppsGetResultSpectrumConfigAppConfigOriginPort: any;
export type AppsGetResultSpectrumConfigAppConfigProxyProtocol = "off" | "v1" | "v2" | "simple";
export declare const AppsGetResultSpectrumConfigAppConfigProxyProtocol: any;
export type AppsGetResultSpectrumConfigAppConfigTls = "off" | "flexible" | "full" | "strict";
export declare const AppsGetResultSpectrumConfigAppConfigTls: any;
export interface AppsGetResultSpectrumConfigAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsGetResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. */
    trafficType: AppsGetResultSpectrumConfigAppConfigTrafficType;
    /** Enables Argo Smart Routing for this application. */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsGetResultSpectrumConfigAppConfigEdgeIps | null;
    /** Enables IP Access Rules for this application. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsGetResultSpectrumConfigAppConfigOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsGetResultSpectrumConfigAppConfigOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. */
    originPort?: AppsGetResultSpectrumConfigAppConfigOriginPort | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsGetResultSpectrumConfigAppConfigProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsGetResultSpectrumConfigAppConfigTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export declare const AppsGetResultSpectrumConfigAppConfig: S.Schema<AppsGetResultSpectrumConfigAppConfig>;
export type AppsGetResultSpectrumConfigPaygoAppConfigOriginDirectList = Array<string>;
export declare const AppsGetResultSpectrumConfigPaygoAppConfigOriginDirectList: S.Schema<AppsGetResultSpectrumConfigPaygoAppConfigOriginDirectList>;
export interface AppsGetResultSpectrumConfigPaygoAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsGetResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsGetResultSpectrumConfigPaygoAppConfigOriginDirectList | null;
}
export declare const AppsGetResultSpectrumConfigPaygoAppConfig: S.Schema<AppsGetResultSpectrumConfigPaygoAppConfig>;
export type AppsGetResult = AppsGetResultSpectrumConfigAppConfig | AppsGetResultSpectrumConfigPaygoAppConfig;
export declare const AppsGetResult: any;
export type GetAppResponse = AppsGetResult;
export declare const GetAppResponse: S.Schema<GetAppResponse>;
export type AppsListRequestDirection = "asc" | "desc";
export declare const AppsListRequestDirection: any;
export type AppsListRequestOrder = "protocol" | "app_id" | "created_on" | "modified_on" | "dns";
export declare const AppsListRequestOrder: any;
export interface ListAppsRequest {
    /** Zone identifier. */
    zoneId: string;
    /** Sets the direction by which results are ordered. */
    direction?: AppsListRequestDirection | (string & {});
    /** Application field by which results are ordered. */
    order?: AppsListRequestOrder | (string & {});
    /** Page number of paginated results. This parameter is required in order to use other pagination parameters. If included in the query, `result_info` will be present in the response. */
    page?: number;
    /** Sets the maximum number of results per page. */
    perPage?: number;
}
export declare const ListAppsRequest: S.Schema<ListAppsRequest>;
export type AppsListResultCase0ItemDnsType = "CNAME" | "ADDRESS";
export declare const AppsListResultCase0ItemDnsType: any;
export interface AppsListResultCase0ItemDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsListResultCase0ItemDnsType | null;
}
export declare const AppsListResultCase0ItemDns: S.Schema<AppsListResultCase0ItemDns>;
export type AppsListResultCase0ItemTrafficType = "direct" | "http" | "https";
export declare const AppsListResultCase0ItemTrafficType: any;
export type AppsListResultCase0ItemEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export declare const AppsListResultCase0ItemEdgeIpsDynamicConnectivity: any;
export type AppsListResultCase0ItemEdgeIpsDynamicType = "dynamic";
export declare const AppsListResultCase0ItemEdgeIpsDynamicType: any;
export interface AppsListResultCase0ItemEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsListResultCase0ItemEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsListResultCase0ItemEdgeIpsDynamicType | null;
}
export declare const AppsListResultCase0ItemEdgeIpsDynamic: S.Schema<AppsListResultCase0ItemEdgeIpsDynamic>;
export type AppsListResultCase0ItemEdgeIpsStaticIpsList = Array<string>;
export declare const AppsListResultCase0ItemEdgeIpsStaticIpsList: S.Schema<AppsListResultCase0ItemEdgeIpsStaticIpsList>;
export type AppsListResultCase0ItemEdgeIpsStaticType = "static";
export declare const AppsListResultCase0ItemEdgeIpsStaticType: any;
export interface AppsListResultCase0ItemEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsListResultCase0ItemEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsListResultCase0ItemEdgeIpsStaticType | null;
}
export declare const AppsListResultCase0ItemEdgeIpsStatic: S.Schema<AppsListResultCase0ItemEdgeIpsStatic>;
export type AppsListResultCase0ItemEdgeIps = AppsListResultCase0ItemEdgeIpsDynamic | AppsListResultCase0ItemEdgeIpsStatic;
export declare const AppsListResultCase0ItemEdgeIps: any;
export type AppsListResultCase0ItemOriginDirectList = Array<string>;
export declare const AppsListResultCase0ItemOriginDirectList: S.Schema<AppsListResultCase0ItemOriginDirectList>;
export type AppsListResultCase0ItemOriginDnsType = "" | "A" | "AAAA" | "SRV";
export declare const AppsListResultCase0ItemOriginDnsType: any;
export interface AppsListResultCase0ItemOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsListResultCase0ItemOriginDnsType | null;
}
export declare const AppsListResultCase0ItemOriginDns: S.Schema<AppsListResultCase0ItemOriginDns>;
export type AppsListResultCase0ItemOriginPort = string | number;
export declare const AppsListResultCase0ItemOriginPort: any;
export type AppsListResultCase0ItemProxyProtocol = "off" | "v1" | "v2" | "simple";
export declare const AppsListResultCase0ItemProxyProtocol: any;
export type AppsListResultCase0ItemTls = "off" | "flexible" | "full" | "strict";
export declare const AppsListResultCase0ItemTls: any;
export interface AppsListResultCase0Item {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsListResultCase0ItemDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. */
    trafficType: AppsListResultCase0ItemTrafficType;
    /** Enables Argo Smart Routing for this application. */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsListResultCase0ItemEdgeIps | null;
    /** Enables IP Access Rules for this application. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsListResultCase0ItemOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsListResultCase0ItemOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. */
    originPort?: AppsListResultCase0ItemOriginPort | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsListResultCase0ItemProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsListResultCase0ItemTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export declare const AppsListResultCase0Item: S.Schema<AppsListResultCase0Item>;
export type AppsListResultCase0List = Array<AppsListResultCase0Item>;
export declare const AppsListResultCase0List: S.Schema<AppsListResultCase0List>;
export type AppsListResultCase1ItemOriginDirectList = Array<string>;
export declare const AppsListResultCase1ItemOriginDirectList: S.Schema<AppsListResultCase1ItemOriginDirectList>;
export interface AppsListResultCase1Item {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsListResultCase0ItemDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsListResultCase1ItemOriginDirectList | null;
}
export declare const AppsListResultCase1Item: S.Schema<AppsListResultCase1Item>;
export type AppsListResultCase1List = Array<AppsListResultCase1Item>;
export declare const AppsListResultCase1List: S.Schema<AppsListResultCase1List>;
export type AppsListResult = AppsListResultCase0List | AppsListResultCase1List;
export declare const AppsListResult: any;
export interface ListAppsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsListResult;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAppsResponse: S.Schema<ListAppsResponse>;
export type AppsUpdateRequestDnsSpectrumConfigAppConfigType = "CNAME" | "ADDRESS";
export declare const AppsUpdateRequestDnsSpectrumConfigAppConfigType: any;
export interface AppsUpdateRequestDnsSpectrumConfigAppConfig {
    /** The name of the DNS record associated with the application. */
    name?: string;
    /** The type of DNS record associated with the application. */
    type?: AppsUpdateRequestDnsSpectrumConfigAppConfigType | (string & {});
}
export declare const AppsUpdateRequestDnsSpectrumConfigAppConfig: S.Schema<AppsUpdateRequestDnsSpectrumConfigAppConfig>;
export type AppsUpdateRequestTrafficType = "direct" | "http" | "https";
export declare const AppsUpdateRequestTrafficType: any;
export type AppsUpdateRequestEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export declare const AppsUpdateRequestEdgeIpsDynamicConnectivity: any;
export type AppsUpdateRequestEdgeIpsDynamicType = "dynamic";
export declare const AppsUpdateRequestEdgeIpsDynamicType: any;
export interface AppsUpdateRequestEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsUpdateRequestEdgeIpsDynamicConnectivity | (string & {});
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsUpdateRequestEdgeIpsDynamicType | (string & {});
}
export declare const AppsUpdateRequestEdgeIpsDynamic: S.Schema<AppsUpdateRequestEdgeIpsDynamic>;
export type AppsUpdateRequestEdgeIpsStaticIpsList = Array<string>;
export declare const AppsUpdateRequestEdgeIpsStaticIpsList: S.Schema<AppsUpdateRequestEdgeIpsStaticIpsList>;
export type AppsUpdateRequestEdgeIpsStaticType = "static";
export declare const AppsUpdateRequestEdgeIpsStaticType: any;
export interface AppsUpdateRequestEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsUpdateRequestEdgeIpsStaticIpsList;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsUpdateRequestEdgeIpsStaticType | (string & {});
}
export declare const AppsUpdateRequestEdgeIpsStatic: S.Schema<AppsUpdateRequestEdgeIpsStatic>;
export type AppsUpdateRequestEdgeIps = AppsUpdateRequestEdgeIpsDynamic | AppsUpdateRequestEdgeIpsStatic;
export declare const AppsUpdateRequestEdgeIps: any;
export type AppsUpdateRequestOriginDirectList = Array<string>;
export declare const AppsUpdateRequestOriginDirectList: S.Schema<AppsUpdateRequestOriginDirectList>;
export type AppsUpdateRequestOriginDnsType = "" | "A" | "AAAA" | "SRV";
export declare const AppsUpdateRequestOriginDnsType: any;
export interface AppsUpdateRequestOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsUpdateRequestOriginDnsType | (string & {});
}
export declare const AppsUpdateRequestOriginDns: S.Schema<AppsUpdateRequestOriginDns>;
export type AppsUpdateRequestOriginPort = string | number;
export declare const AppsUpdateRequestOriginPort: any;
export type AppsUpdateRequestProxyProtocol = "off" | "v1" | "v2" | "simple";
export declare const AppsUpdateRequestProxyProtocol: any;
export type AppsUpdateRequestTls = "off" | "flexible" | "full" | "strict";
export declare const AppsUpdateRequestTls: any;
export interface UpdateAppRequest {
    /** Zone identifier. */
    zoneId: string;
    /** App identifier. */
    appId: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsUpdateRequestDnsSpectrumConfigAppConfig;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. */
    trafficType?: AppsUpdateRequestTrafficType | (string & {});
    /** Enables Argo Smart Routing for this application. */
    argoSmartRouting?: boolean;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsUpdateRequestEdgeIps;
    /** Enables IP Access Rules for this application. */
    ipFirewall?: boolean;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsUpdateRequestOriginDirectList;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsUpdateRequestOriginDns;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. */
    originPort?: AppsUpdateRequestOriginPort;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsUpdateRequestProxyProtocol | (string & {});
    /** The type of TLS termination associated with the application. */
    tls?: AppsUpdateRequestTls | (string & {});
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string;
}
export declare const UpdateAppRequest: S.Schema<UpdateAppRequest>;
export type AppsUpdateResultSpectrumConfigAppConfigDnsType = "CNAME" | "ADDRESS";
export declare const AppsUpdateResultSpectrumConfigAppConfigDnsType: any;
export interface AppsUpdateResultSpectrumConfigAppConfigDns {
    /** The name of the DNS record associated with the application. */
    name?: string | null;
    /** The type of DNS record associated with the application. */
    type?: AppsUpdateResultSpectrumConfigAppConfigDnsType | null;
}
export declare const AppsUpdateResultSpectrumConfigAppConfigDns: S.Schema<AppsUpdateResultSpectrumConfigAppConfigDns>;
export type AppsUpdateResultSpectrumConfigAppConfigTrafficType = "direct" | "http" | "https";
export declare const AppsUpdateResultSpectrumConfigAppConfigTrafficType: any;
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity = "all" | "ipv4" | "ipv6";
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity: any;
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicType = "dynamic";
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicType: any;
export interface AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamic {
    /** The IP versions supported for inbound connections on Spectrum anycast IPs. */
    connectivity?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicConnectivity | null;
    /** The type of edge IP configuration specified. Dynamically allocated edge IPs use Spectrum anycast IPs in accordance with the connectivity you specify. Only valid with CNAME DNS names. */
    type?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamicType | null;
}
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamic: S.Schema<AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamic>;
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList = Array<string>;
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList: S.Schema<AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList>;
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticType = "static";
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticType: any;
export interface AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStatic {
    /** The array of customer owned IPs we broadcast via anycast for this hostname and application. */
    ips?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticIpsList | null;
    /** The type of edge IP configuration specified. Statically allocated edge IPs use customer IPs in accordance with the ips array you specify. Only valid with ADDRESS DNS names. */
    type?: AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStaticType | null;
}
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStatic: S.Schema<AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStatic>;
export type AppsUpdateResultSpectrumConfigAppConfigEdgeIps = AppsUpdateResultSpectrumConfigAppConfigEdgeIpsDynamic | AppsUpdateResultSpectrumConfigAppConfigEdgeIpsStatic;
export declare const AppsUpdateResultSpectrumConfigAppConfigEdgeIps: any;
export type AppsUpdateResultSpectrumConfigAppConfigOriginDirectList = Array<string>;
export declare const AppsUpdateResultSpectrumConfigAppConfigOriginDirectList: S.Schema<AppsUpdateResultSpectrumConfigAppConfigOriginDirectList>;
export type AppsUpdateResultSpectrumConfigAppConfigOriginDnsType = "" | "A" | "AAAA" | "SRV";
export declare const AppsUpdateResultSpectrumConfigAppConfigOriginDnsType: any;
export interface AppsUpdateResultSpectrumConfigAppConfigOriginDns {
    /** The name of the DNS record associated with the origin. */
    name?: string | null;
    /** The TTL of our resolution of your DNS record in seconds. */
    ttl?: number | null;
    /** The type of DNS record associated with the origin. "" is used to specify a combination of A/AAAA records. */
    type?: AppsUpdateResultSpectrumConfigAppConfigOriginDnsType | null;
}
export declare const AppsUpdateResultSpectrumConfigAppConfigOriginDns: S.Schema<AppsUpdateResultSpectrumConfigAppConfigOriginDns>;
export type AppsUpdateResultSpectrumConfigAppConfigOriginPort = string | number;
export declare const AppsUpdateResultSpectrumConfigAppConfigOriginPort: any;
export type AppsUpdateResultSpectrumConfigAppConfigProxyProtocol = "off" | "v1" | "v2" | "simple";
export declare const AppsUpdateResultSpectrumConfigAppConfigProxyProtocol: any;
export type AppsUpdateResultSpectrumConfigAppConfigTls = "off" | "flexible" | "full" | "strict";
export declare const AppsUpdateResultSpectrumConfigAppConfigTls: any;
export interface AppsUpdateResultSpectrumConfigAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsUpdateResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** Determines how data travels from the edge to your origin. When set to "direct", Spectrum will send traffic directly to your origin, and the application's type is derived from the `protocol`. When set to "http" or "https", Spectrum will apply Cloudflare's HTTP/HTTPS features as it sends traffic to your origin, and the application type matches this property exactly. */
    trafficType: AppsUpdateResultSpectrumConfigAppConfigTrafficType;
    /** Enables Argo Smart Routing for this application. */
    argoSmartRouting?: boolean | null;
    /** The anycast edge IP configuration for the hostname of this application. */
    edgeIps?: AppsUpdateResultSpectrumConfigAppConfigEdgeIps | null;
    /** Enables IP Access Rules for this application. */
    ipFirewall?: boolean | null;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsUpdateResultSpectrumConfigAppConfigOriginDirectList | null;
    /** The name and type of DNS record for the Spectrum application. */
    originDns?: AppsUpdateResultSpectrumConfigAppConfigOriginDns | null;
    /** The destination port at the origin. Only specified in conjunction with origin_dns. May use an integer to specify a single origin port, for example `1000`, or a string to specify a range of origin ports, for example `"1000-2000"`. */
    originPort?: AppsUpdateResultSpectrumConfigAppConfigOriginPort | null;
    /** Enables Proxy Protocol to the origin. Refer to [Enable Proxy protocol](https://developers.cloudflare.com/spectrum/getting-started/proxy-protocol/) for implementation details on PROXY Protocol V1, PROXY Protocol V2, and Simple Proxy Protocol. */
    proxyProtocol?: AppsUpdateResultSpectrumConfigAppConfigProxyProtocol | null;
    /** The type of TLS termination associated with the application. */
    tls?: AppsUpdateResultSpectrumConfigAppConfigTls | null;
    /** Optional UUID of a virtual network for routing origin traffic through tunnel virtual networks. */
    virtualNetworkId?: string | null;
}
export declare const AppsUpdateResultSpectrumConfigAppConfig: S.Schema<AppsUpdateResultSpectrumConfigAppConfig>;
export type AppsUpdateResultSpectrumConfigPaygoAppConfigOriginDirectList = Array<string>;
export declare const AppsUpdateResultSpectrumConfigPaygoAppConfigOriginDirectList: S.Schema<AppsUpdateResultSpectrumConfigPaygoAppConfigOriginDirectList>;
export interface AppsUpdateResultSpectrumConfigPaygoAppConfig {
    /** App identifier. */
    id: string;
    /** When the Application was created. */
    createdOn: string;
    /** The name and type of DNS record for the Spectrum application. */
    dns: AppsUpdateResultSpectrumConfigAppConfigDns;
    /** When the Application was last modified. */
    modifiedOn: string;
    /** The port configuration at Cloudflare's edge. May specify a single port, for example `"tcp/1000"`, or a range of ports, for example `"tcp/1000-2000"`. */
    protocol: string;
    /** List of origin IP addresses. Array may contain multiple IP addresses for load balancing. */
    originDirect?: AppsUpdateResultSpectrumConfigPaygoAppConfigOriginDirectList | null;
}
export declare const AppsUpdateResultSpectrumConfigPaygoAppConfig: S.Schema<AppsUpdateResultSpectrumConfigPaygoAppConfig>;
export type AppsUpdateResult = AppsUpdateResultSpectrumConfigAppConfig | AppsUpdateResultSpectrumConfigPaygoAppConfig;
export declare const AppsUpdateResult: any;
export type UpdateAppResponse = AppsUpdateResult;
export declare const UpdateAppResponse: S.Schema<UpdateAppResponse>;
export type CreateAppError = SpectrumProtocolNotAvailable | Forbidden | CloudflareOpError;
/** Creates a new Spectrum application from a configuration using a name for the origin. */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, CloudflareOpContext>;
export type DeleteAppError = SpectrumAppNotFound | Forbidden | CloudflareOpError;
/** Deletes a previously existing application. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, CloudflareOpContext>;
export type GetAnalyticAggregateCurrentError = CloudflareOpError;
/** Retrieves analytics aggregated from the last minute of usage on Spectrum applications underneath a given zone. */
export declare const getAnalyticAggregateCurrent: API.OperationMethod<GetAnalyticAggregateCurrentRequest, GetAnalyticAggregateCurrentResponse, GetAnalyticAggregateCurrentError, CloudflareOpContext>;
export type GetAnalyticEventBytimeError = CloudflareOpError;
/** Retrieves a list of aggregate metrics grouped by time interval. */
export declare const getAnalyticEventBytime: API.OperationMethod<GetAnalyticEventBytimeRequest, GetAnalyticEventBytimeResponse, GetAnalyticEventBytimeError, CloudflareOpContext>;
export type GetAnalyticEventSummaryError = CloudflareOpError;
/** Retrieves a list of summarised aggregate metrics over a given time period. */
export declare const getAnalyticEventSummary: API.OperationMethod<GetAnalyticEventSummaryRequest, GetAnalyticEventSummaryResponse, GetAnalyticEventSummaryError, CloudflareOpContext>;
export type GetAppError = SpectrumAppNotFound | Forbidden | CloudflareOpError;
/** Gets the application configuration of a specific application inside a zone. */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResponse, GetAppError, CloudflareOpContext>;
export type ListAppsError = Forbidden | CloudflareOpError;
/** Retrieves a list of currently existing Spectrum applications inside a zone. */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, CloudflareOpContext>;
export type UpdateAppError = SpectrumAppNotFound | SpectrumProtocolNotAvailable | Forbidden | CloudflareOpError;
/** Updates a previously existing application's configuration that uses a name for the origin. */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResponse, UpdateAppError, CloudflareOpContext>;
//# sourceMappingURL=spectrum.d.ts.map