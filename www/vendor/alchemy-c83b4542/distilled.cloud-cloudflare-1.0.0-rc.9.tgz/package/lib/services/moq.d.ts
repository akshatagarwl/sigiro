import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    /** Human-readable name for the relay. */
    name: string;
}
export declare const CreateRelayRequest: S.Schema<CreateRelayRequest>;
export interface RelaysCreateResponseConfigLingeringSubscribe {
    enabled?: boolean | null;
    /** Relay-level ceiling on lingering subscribe timeout (ms). Default 30000. */
    maxTimeoutMs?: number | null;
}
export declare const RelaysCreateResponseConfigLingeringSubscribe: S.Schema<RelaysCreateResponseConfigLingeringSubscribe>;
export interface RelaysCreateResponseConfigUpstreamsUpstreamsItem {
    /** Upstream MOQT server publisher URL. */
    url?: string | null;
}
export declare const RelaysCreateResponseConfigUpstreamsUpstreamsItem: S.Schema<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export type RelaysCreateResponseConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export declare const RelaysCreateResponseConfigUpstreamsUpstreamsList: S.Schema<RelaysCreateResponseConfigUpstreamsUpstreamsList>;
export interface RelaysCreateResponseConfigUpstreams {
    enabled?: boolean | null;
    /** Ordered list of upstream MOQT server publishers. Each entry is an */
    upstreams?: RelaysCreateResponseConfigUpstreamsUpstreamsList | null;
}
export declare const RelaysCreateResponseConfigUpstreams: S.Schema<RelaysCreateResponseConfigUpstreams>;
export interface RelaysCreateResponseConfig {
    lingeringSubscribe?: RelaysCreateResponseConfigLingeringSubscribe | null;
    /** Upstreams are external MOQT server publishers that a relay falls back */
    upstreams?: RelaysCreateResponseConfigUpstreams | null;
}
export declare const RelaysCreateResponseConfig: S.Schema<RelaysCreateResponseConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRelayResponse {
    /** upstreams and lingering_subscribe are mutually exclusive. */
    config: RelaysCreateResponseConfig;
    created: string;
    modified: string;
    name: string;
    /** Full access token (publish + subscribe). Treat as sensitive. */
    tokenPublishSubscribe: string;
    /** Subscribe-only token. Treat as sensitive. */
    tokenSubscribe: string;
    /** Server-generated unique identifier (32 hex chars). */
    uid: string;
}
export declare const CreateRelayResponse: S.Schema<CreateRelayResponse>;
export interface DeleteRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
}
export declare const DeleteRelayRequest: S.Schema<DeleteRelayRequest>;
export type DeleteRelayResponse = unknown;
export declare const DeleteRelayResponse: S.Schema<DeleteRelayResponse>;
export interface GetRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
}
export declare const GetRelayRequest: S.Schema<GetRelayRequest>;
export type RelaysGetResponseConfigLingeringSubscribe = RelaysCreateResponseConfigLingeringSubscribe;
export declare const RelaysGetResponseConfigLingeringSubscribe: S.Schema<RelaysCreateResponseConfigLingeringSubscribe>;
export type RelaysGetResponseConfigUpstreamsUpstreamsItem = RelaysCreateResponseConfigUpstreamsUpstreamsItem;
export declare const RelaysGetResponseConfigUpstreamsUpstreamsItem: S.Schema<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export type RelaysGetResponseConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export declare const RelaysGetResponseConfigUpstreamsUpstreamsList: S.Schema<RelaysGetResponseConfigUpstreamsUpstreamsList>;
export interface RelaysGetResponseConfigUpstreams {
    enabled?: boolean | null;
    /** Ordered list of upstream MOQT server publishers. Each entry is an */
    upstreams?: RelaysGetResponseConfigUpstreamsUpstreamsList | null;
}
export declare const RelaysGetResponseConfigUpstreams: S.Schema<RelaysGetResponseConfigUpstreams>;
export interface RelaysGetResponseConfig {
    lingeringSubscribe?: RelaysCreateResponseConfigLingeringSubscribe | null;
    /** Upstreams are external MOQT server publishers that a relay falls back */
    upstreams?: RelaysGetResponseConfigUpstreams | null;
}
export declare const RelaysGetResponseConfig: S.Schema<RelaysGetResponseConfig>;
export type RelaysGetResponseStatus = "connected";
export declare const RelaysGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRelayResponse {
    /** upstreams and lingering_subscribe are mutually exclusive. */
    config: RelaysGetResponseConfig;
    created: string;
    modified: string;
    name: string;
    uid: string;
    /** "connected" when active, omitted otherwise. */
    status?: RelaysGetResponseStatus | null;
}
export declare const GetRelayResponse: S.Schema<GetRelayResponse>;
export interface ListRelaysRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    /** Sort order by `created`. When true, results are returned oldest-first */
    asc?: boolean;
    /** Cursor for pagination. Returns relays created strictly after this */
    createdAfter?: string;
    /** Cursor for pagination. Returns relays created strictly before this */
    createdBefore?: string;
    /** Maximum number of relays to return per page. */
    perPage?: number;
}
export declare const ListRelaysRequest: S.Schema<ListRelaysRequest>;
export interface RelaysListResultItem {
    created: string;
    modified: string;
    name: string;
    uid: string;
}
export declare const RelaysListResultItem: S.Schema<RelaysListResultItem>;
export type RelaysListResultList = Array<RelaysListResultItem>;
export declare const RelaysListResultList: S.Schema<RelaysListResultList>;
export interface ListRelaysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RelaysListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRelaysResponse: S.Schema<ListRelaysResponse>;
export type RelaysTokensRotateRequestType = "publish_subscribe" | "subscribe";
export declare const RelaysTokensRotateRequestType: any;
export interface RotateRelayTokenRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
    /** Which token type to rotate. */
    type: RelaysTokensRotateRequestType | (string & {});
}
export declare const RotateRelayTokenRequest: S.Schema<RotateRelayTokenRequest>;
export type RelaysTokensRotateResponseType = "publish_subscribe" | "subscribe";
export declare const RelaysTokensRotateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RotateRelayTokenResponse {
    /** New token value (shown once). Treat as sensitive. */
    token: string;
    type: RelaysTokensRotateResponseType;
}
export declare const RotateRelayTokenResponse: S.Schema<RotateRelayTokenResponse>;
export interface RelaysUpdateRequestConfigLingeringSubscribe {
    enabled?: boolean;
    /** Relay-level ceiling on lingering subscribe timeout (ms). Default 30000. */
    maxTimeoutMs?: number;
}
export declare const RelaysUpdateRequestConfigLingeringSubscribe: S.Schema<RelaysUpdateRequestConfigLingeringSubscribe>;
export interface RelaysUpdateRequestConfigUpstreamsUpstreamsItem {
    /** Upstream MOQT server publisher URL. */
    url?: string;
}
export declare const RelaysUpdateRequestConfigUpstreamsUpstreamsItem: S.Schema<RelaysUpdateRequestConfigUpstreamsUpstreamsItem>;
export type RelaysUpdateRequestConfigUpstreamsUpstreamsList = Array<RelaysUpdateRequestConfigUpstreamsUpstreamsItem>;
export declare const RelaysUpdateRequestConfigUpstreamsUpstreamsList: S.Schema<RelaysUpdateRequestConfigUpstreamsUpstreamsList>;
export interface RelaysUpdateRequestConfigUpstreams {
    enabled?: boolean;
    /** Ordered list of upstream MOQT server publishers. Each entry is an */
    upstreams?: RelaysUpdateRequestConfigUpstreamsUpstreamsList;
}
export declare const RelaysUpdateRequestConfigUpstreams: S.Schema<RelaysUpdateRequestConfigUpstreams>;
export interface RelaysUpdateRequestConfig {
    lingeringSubscribe?: RelaysUpdateRequestConfigLingeringSubscribe;
    /** Upstreams are external MOQT server publishers that a relay falls back */
    upstreams?: RelaysUpdateRequestConfigUpstreams;
}
export declare const RelaysUpdateRequestConfig: S.Schema<RelaysUpdateRequestConfig>;
export interface UpdateRelayRequest {
    /** Cloudflare account identifier. */
    accountId: string;
    relayId: string;
    /** upstreams and lingering_subscribe are mutually exclusive. */
    config?: RelaysUpdateRequestConfig;
    name?: string;
}
export declare const UpdateRelayRequest: S.Schema<UpdateRelayRequest>;
export type RelaysUpdateResponseConfigLingeringSubscribe = RelaysCreateResponseConfigLingeringSubscribe;
export declare const RelaysUpdateResponseConfigLingeringSubscribe: S.Schema<RelaysCreateResponseConfigLingeringSubscribe>;
export type RelaysUpdateResponseConfigUpstreamsUpstreamsItem = RelaysCreateResponseConfigUpstreamsUpstreamsItem;
export declare const RelaysUpdateResponseConfigUpstreamsUpstreamsItem: S.Schema<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export type RelaysUpdateResponseConfigUpstreamsUpstreamsList = Array<RelaysCreateResponseConfigUpstreamsUpstreamsItem>;
export declare const RelaysUpdateResponseConfigUpstreamsUpstreamsList: S.Schema<RelaysUpdateResponseConfigUpstreamsUpstreamsList>;
export interface RelaysUpdateResponseConfigUpstreams {
    enabled?: boolean | null;
    /** Ordered list of upstream MOQT server publishers. Each entry is an */
    upstreams?: RelaysUpdateResponseConfigUpstreamsUpstreamsList | null;
}
export declare const RelaysUpdateResponseConfigUpstreams: S.Schema<RelaysUpdateResponseConfigUpstreams>;
export interface RelaysUpdateResponseConfig {
    lingeringSubscribe?: RelaysCreateResponseConfigLingeringSubscribe | null;
    /** Upstreams are external MOQT server publishers that a relay falls back */
    upstreams?: RelaysUpdateResponseConfigUpstreams | null;
}
export declare const RelaysUpdateResponseConfig: S.Schema<RelaysUpdateResponseConfig>;
export type RelaysUpdateResponseStatus = "connected";
export declare const RelaysUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRelayResponse {
    /** upstreams and lingering_subscribe are mutually exclusive. */
    config: RelaysUpdateResponseConfig;
    created: string;
    modified: string;
    name: string;
    uid: string;
    /** "connected" when active, omitted otherwise. */
    status?: RelaysUpdateResponseStatus | null;
}
export declare const UpdateRelayResponse: S.Schema<UpdateRelayResponse>;
export type CreateRelayError = CloudflareOpError;
/** Provisions a new MoQ relay instance. Auto-creates a publish+subscribe token and a subscribe-only token. Token values are included in the response (shown once). Config is set to defaults (lingering subscribe enabled, 30s ceiling, upstreams off). Use PUT to modify. */
export declare const createRelay: API.OperationMethod<CreateRelayRequest, CreateRelayResponse, CreateRelayError, CloudflareOpContext>;
export type DeleteRelayError = CloudflareOpError;
/** Soft-deletes a MoQ relay. */
export declare const deleteRelay: API.OperationMethod<DeleteRelayRequest, DeleteRelayResponse, DeleteRelayError, CloudflareOpContext>;
export type GetRelayError = CloudflareOpError;
/** Retrieves a single MoQ relay including config and status. Tokens are NOT included. */
export declare const getRelay: API.OperationMethod<GetRelayRequest, GetRelayResponse, GetRelayError, CloudflareOpContext>;
export type ListRelaysError = CloudflareOpError;
/** Lists all MoQ relays for the account. Returns only metadata. Config, status, and tokens are omitted. Results are cursor-paginated (keyset on the `created` timestamp). Use `created_before` / `created_after` with the `created` value of the first/last item in a page to fetch the adjacent page. `result_info` reports the page `count` and the `total` matching the cursor filters. */
export declare const listRelays: API.PaginatedOperationMethod<ListRelaysRequest, ListRelaysResponse, ListRelaysError, CloudflareOpContext, RelaysListResultItem>;
export type RotateRelayTokenError = CloudflareOpError;
/** Generates a new token for the specified type. The old token is immediately invalidated. Token value is shown once in the response. */
export declare const rotateRelayToken: API.OperationMethod<RotateRelayTokenRequest, RotateRelayTokenResponse, RotateRelayTokenError, CloudflareOpContext>;
export type UpdateRelayError = CloudflareOpError;
/** Updates a relay's name and/or configuration. Partial updates: omitted fields are preserved. Config sub-objects replace as whole objects when present. upstreams and lingering_subscribe are mutually exclusive. */
export declare const updateRelay: API.OperationMethod<UpdateRelayRequest, UpdateRelayResponse, UpdateRelayError, CloudflareOpContext>;
//# sourceMappingURL=moq.d.ts.map