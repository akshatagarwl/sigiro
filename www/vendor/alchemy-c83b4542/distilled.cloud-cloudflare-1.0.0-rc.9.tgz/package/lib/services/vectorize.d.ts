import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Gone_base: S.Class<Gone, S.TaggedStruct<"Gone", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Gone extends /*@__PURE__*/ Gone_base {
}
declare const IndexAlreadyExists_base: S.Class<IndexAlreadyExists, S.TaggedStruct<"IndexAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IndexAlreadyExists extends /*@__PURE__*/ IndexAlreadyExists_base {
}
declare const IndexInvalidConfig_base: S.Class<IndexInvalidConfig, S.TaggedStruct<"IndexInvalidConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IndexInvalidConfig extends /*@__PURE__*/ IndexInvalidConfig_base {
}
declare const IndexInvalidName_base: S.Class<IndexInvalidName, S.TaggedStruct<"IndexInvalidName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IndexInvalidName extends /*@__PURE__*/ IndexInvalidName_base {
}
declare const MetadataIndexAlreadyExists_base: S.Class<MetadataIndexAlreadyExists, S.TaggedStruct<"MetadataIndexAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MetadataIndexAlreadyExists extends /*@__PURE__*/ MetadataIndexAlreadyExists_base {
}
declare const MetadataIndexInvalidType_base: S.Class<MetadataIndexInvalidType, S.TaggedStruct<"MetadataIndexInvalidType", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MetadataIndexInvalidType extends /*@__PURE__*/ MetadataIndexInvalidType_base {
}
declare const MetadataIndexNotFound_base: S.Class<MetadataIndexNotFound, S.TaggedStruct<"MetadataIndexNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MetadataIndexNotFound extends /*@__PURE__*/ MetadataIndexNotFound_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
export type IndexesCreateRequestConfigIndexDimensionConfigurationMetric = "cosine" | "euclidean" | "dot-product";
export declare const IndexesCreateRequestConfigIndexDimensionConfigurationMetric: any;
export interface IndexesCreateRequestConfigIndexDimensionConfiguration {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesCreateRequestConfigIndexDimensionConfigurationMetric | (string & {});
}
export declare const IndexesCreateRequestConfigIndexDimensionConfiguration: S.Schema<IndexesCreateRequestConfigIndexDimensionConfiguration>;
export type IndexesCreateRequestConfigVectorizeIndexPresetConfigurationPreset = "@cf/baai/bge-small-en-v1.5" | "@cf/baai/bge-base-en-v1.5" | "@cf/baai/bge-large-en-v1.5" | "openai/text-embedding-ada-002" | "cohere/embed-multilingual-v2.0";
export declare const IndexesCreateRequestConfigVectorizeIndexPresetConfigurationPreset: any;
export interface IndexesCreateRequestConfigVectorizeIndexPresetConfiguration {
    /** Specifies the preset to use for the index. */
    preset: IndexesCreateRequestConfigVectorizeIndexPresetConfigurationPreset | (string & {});
}
export declare const IndexesCreateRequestConfigVectorizeIndexPresetConfiguration: S.Schema<IndexesCreateRequestConfigVectorizeIndexPresetConfiguration>;
export type IndexesCreateRequestConfig = IndexesCreateRequestConfigIndexDimensionConfiguration | IndexesCreateRequestConfigVectorizeIndexPresetConfiguration;
export declare const IndexesCreateRequestConfig: any;
export interface CreateIndexRequest {
    /** Identifier */
    accountId: string;
    /** Specifies the type of configuration to use for the index. */
    config: IndexesCreateRequestConfig;
    name: string;
    /** Specifies the description of the index. */
    description?: string;
}
export declare const CreateIndexRequest: S.Schema<CreateIndexRequest>;
export type IndexesCreateResponseConfigMetric = "cosine" | "euclidean" | "dot-product";
export declare const IndexesCreateResponseConfigMetric: any;
export interface IndexesCreateResponseConfig {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesCreateResponseConfigMetric;
}
export declare const IndexesCreateResponseConfig: S.Schema<IndexesCreateResponseConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndexResponse {
    config?: IndexesCreateResponseConfig | null;
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdOn?: string | null;
    /** Specifies the description of the index. */
    description?: string | null;
    /** Specifies the timestamp the resource was modified as an ISO8601 string. */
    modifiedOn?: string | null;
    name?: string | null;
}
export declare const CreateIndexResponse: S.Schema<CreateIndexResponse>;
export type IndexesMetadataIndexCreateRequestIndexType = "string" | "number" | "boolean";
export declare const IndexesMetadataIndexCreateRequestIndexType: any;
export interface CreateIndexMetadataIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Specifies the type of metadata property to index. */
    indexType: IndexesMetadataIndexCreateRequestIndexType | (string & {});
    /** Specifies the metadata property to index. */
    propertyName: string;
}
export declare const CreateIndexMetadataIndexRequest: S.Schema<CreateIndexMetadataIndexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndexMetadataIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null;
}
export declare const CreateIndexMetadataIndexResponse: S.Schema<CreateIndexMetadataIndexResponse>;
export type IndexesDeleteByIdsRequestIdsList = Array<string>;
export declare const IndexesDeleteByIdsRequestIdsList: S.Schema<IndexesDeleteByIdsRequestIdsList>;
export interface DeleteByIdsIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** A list of vector identifiers to delete from the index indicated by the path. */
    ids?: IndexesDeleteByIdsRequestIdsList;
}
export declare const DeleteByIdsIndexRequest: S.Schema<DeleteByIdsIndexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteByIdsIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null;
}
export declare const DeleteByIdsIndexResponse: S.Schema<DeleteByIdsIndexResponse>;
export interface DeleteIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export declare const DeleteIndexRequest: S.Schema<DeleteIndexRequest>;
export type DeleteIndexResponse = unknown;
export declare const DeleteIndexResponse: S.Schema<DeleteIndexResponse>;
export interface DeleteIndexMetadataIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Specifies the metadata property for which the index must be deleted. */
    propertyName: string;
}
export declare const DeleteIndexMetadataIndexRequest: S.Schema<DeleteIndexMetadataIndexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteIndexMetadataIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null;
}
export declare const DeleteIndexMetadataIndexResponse: S.Schema<DeleteIndexMetadataIndexResponse>;
export type IndexesGetByIdsRequestIdsList = Array<string>;
export declare const IndexesGetByIdsRequestIdsList: S.Schema<IndexesGetByIdsRequestIdsList>;
export interface GetByIdsIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** A list of vector identifiers to retrieve from the index indicated by the path. */
    ids?: IndexesGetByIdsRequestIdsList;
}
export declare const GetByIdsIndexRequest: S.Schema<GetByIdsIndexRequest>;
export type GetByIdsIndexResponse = unknown;
export declare const GetByIdsIndexResponse: S.Schema<GetByIdsIndexResponse>;
export interface GetIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export declare const GetIndexRequest: S.Schema<GetIndexRequest>;
export type IndexesGetResponseConfigMetric = "cosine" | "euclidean" | "dot-product";
export declare const IndexesGetResponseConfigMetric: any;
export interface IndexesGetResponseConfig {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesGetResponseConfigMetric;
}
export declare const IndexesGetResponseConfig: S.Schema<IndexesGetResponseConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIndexResponse {
    config?: IndexesGetResponseConfig | null;
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdOn?: string | null;
    /** Specifies the description of the index. */
    description?: string | null;
    /** Specifies the timestamp the resource was modified as an ISO8601 string. */
    modifiedOn?: string | null;
    name?: string | null;
}
export declare const GetIndexResponse: S.Schema<GetIndexResponse>;
export interface GetIndexInfoRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export declare const GetIndexInfoRequest: S.Schema<GetIndexInfoRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIndexInfoResponse {
    /** Specifies the number of dimensions for the index */
    dimensions?: number | null;
    /** Specifies the timestamp the last mutation batch was processed as an ISO8601 string. */
    processedUpToDatetime?: string | null;
    /** The unique identifier for the async mutation operation containing the changeset. */
    processedUpToMutation?: string | null;
    /** Specifies the number of vectors present in the index */
    vectorCount?: number | null;
}
export declare const GetIndexInfoResponse: S.Schema<GetIndexInfoResponse>;
export type IndexesInsertRequestUnparsableBehavior = "error" | "discard";
export declare const IndexesInsertRequestUnparsableBehavior: any;
export interface InsertIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Behavior for ndjson parse failures. */
    unparsableBehavior?: IndexesInsertRequestUnparsableBehavior | (string & {});
    /** Vectors as newline-delimited JSON (application/x-ndjson), one vector object per line. */
    body: Blob | Uint8Array | ArrayBuffer | string;
}
export declare const InsertIndexRequest: S.Schema<InsertIndexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InsertIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null;
}
export declare const InsertIndexResponse: S.Schema<InsertIndexResponse>;
export interface ListIndexesRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListIndexesRequest: S.Schema<ListIndexesRequest>;
export type IndexesListResultItemConfigMetric = "cosine" | "euclidean" | "dot-product";
export declare const IndexesListResultItemConfigMetric: any;
export interface IndexesListResultItemConfig {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesListResultItemConfigMetric;
}
export declare const IndexesListResultItemConfig: S.Schema<IndexesListResultItemConfig>;
export interface IndexesListResultItem {
    config?: IndexesListResultItemConfig | null;
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdOn?: string | null;
    /** Specifies the description of the index. */
    description?: string | null;
    /** Specifies the timestamp the resource was modified as an ISO8601 string. */
    modifiedOn?: string | null;
    name?: string | null;
}
export declare const IndexesListResultItem: S.Schema<IndexesListResultItem>;
export type IndexesListResultList = Array<IndexesListResultItem>;
export declare const IndexesListResultList: S.Schema<IndexesListResultList>;
export interface ListIndexesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: IndexesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListIndexesResponse: S.Schema<ListIndexesResponse>;
export interface ListIndexMetadataIndexesRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export declare const ListIndexMetadataIndexesRequest: S.Schema<ListIndexMetadataIndexesRequest>;
export type IndexesMetadataIndexListResponseMetadataIndexesItemIndexType = "string" | "number" | "boolean";
export declare const IndexesMetadataIndexListResponseMetadataIndexesItemIndexType: any;
export interface IndexesMetadataIndexListResponseMetadataIndexesItem {
    /** Specifies the type of indexed metadata property. */
    indexType?: IndexesMetadataIndexListResponseMetadataIndexesItemIndexType | null;
    /** Specifies the indexed metadata property. */
    propertyName?: string | null;
}
export declare const IndexesMetadataIndexListResponseMetadataIndexesItem: S.Schema<IndexesMetadataIndexListResponseMetadataIndexesItem>;
export type IndexesMetadataIndexListResponseMetadataIndexesList = Array<IndexesMetadataIndexListResponseMetadataIndexesItem>;
export declare const IndexesMetadataIndexListResponseMetadataIndexesList: S.Schema<IndexesMetadataIndexListResponseMetadataIndexesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListIndexMetadataIndexesResponse {
    /** Array of indexed metadata properties. */
    metadataIndexes?: IndexesMetadataIndexListResponseMetadataIndexesList | null;
}
export declare const ListIndexMetadataIndexesResponse: S.Schema<ListIndexMetadataIndexesResponse>;
export interface ListVectorsIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Maximum number of vectors to return */
    count?: number;
    /** Cursor for pagination to get the next page of results */
    cursor?: string;
}
export declare const ListVectorsIndexRequest: S.Schema<ListVectorsIndexRequest>;
export interface IndexesListVectorsResponseVectorsItem {
    /** Identifier for a Vector */
    id: string;
}
export declare const IndexesListVectorsResponseVectorsItem: S.Schema<IndexesListVectorsResponseVectorsItem>;
export type IndexesListVectorsResponseVectorsList = Array<IndexesListVectorsResponseVectorsItem>;
export declare const IndexesListVectorsResponseVectorsList: S.Schema<IndexesListVectorsResponseVectorsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListVectorsIndexResponse {
    /** Number of vectors returned in this response */
    count: number;
    /** Whether there are more vectors available beyond this response */
    isTruncated: boolean;
    /** Total number of vectors in the index */
    totalCount: number;
    /** Array of vector items */
    vectors: IndexesListVectorsResponseVectorsList;
    /** When the cursor expires as an ISO8601 string */
    cursorExpirationTimestamp?: string | null;
    /** Cursor for the next page of results */
    nextCursor?: string | null;
}
export declare const ListVectorsIndexResponse: S.Schema<ListVectorsIndexResponse>;
export type IndexesQueryRequestVectorList = Array<number>;
export declare const IndexesQueryRequestVectorList: S.Schema<IndexesQueryRequestVectorList>;
export type IndexesQueryRequestReturnMetadata = "none" | "indexed" | "all";
export declare const IndexesQueryRequestReturnMetadata: any;
export interface QueryIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** The search vector that will be used to find the nearest neighbors. */
    vector: IndexesQueryRequestVectorList;
    /** A metadata filter expression used to limit nearest neighbor results. */
    filter?: unknown;
    /** Whether to return no metadata, indexed metadata or all metadata associated with the closest vectors. */
    returnMetadata?: IndexesQueryRequestReturnMetadata | (string & {});
    /** Whether to return the values associated with the closest vectors. */
    returnValues?: boolean;
    /** The number of nearest neighbors to find. */
    topK?: number;
}
export declare const QueryIndexRequest: S.Schema<QueryIndexRequest>;
export type IndexesQueryResponseMatchesItemValuesList = Array<number>;
export declare const IndexesQueryResponseMatchesItemValuesList: S.Schema<IndexesQueryResponseMatchesItemValuesList>;
export interface IndexesQueryResponseMatchesItem {
    /** Identifier for a Vector */
    id?: string | null;
    metadata?: unknown | null;
    namespace?: string | null;
    /** The score of the vector according to the index's distance metric */
    score?: number | null;
    values?: IndexesQueryResponseMatchesItemValuesList | null;
}
export declare const IndexesQueryResponseMatchesItem: S.Schema<IndexesQueryResponseMatchesItem>;
export type IndexesQueryResponseMatchesList = Array<IndexesQueryResponseMatchesItem>;
export declare const IndexesQueryResponseMatchesList: S.Schema<IndexesQueryResponseMatchesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface QueryIndexResponse {
    /** Specifies the count of vectors returned by the search */
    count?: number | null;
    /** Array of vectors matched by the search */
    matches?: IndexesQueryResponseMatchesList | null;
}
export declare const QueryIndexResponse: S.Schema<QueryIndexResponse>;
export type IndexesUpsertRequestUnparsableBehavior = "error" | "discard";
export declare const IndexesUpsertRequestUnparsableBehavior: any;
export interface UpsertIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Behavior for ndjson parse failures. */
    unparsableBehavior?: IndexesUpsertRequestUnparsableBehavior | (string & {});
    /** Vectors as newline-delimited JSON (application/x-ndjson), one vector object per line. */
    body: Blob | Uint8Array | ArrayBuffer | string;
}
export declare const UpsertIndexRequest: S.Schema<UpsertIndexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpsertIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null;
}
export declare const UpsertIndexResponse: S.Schema<UpsertIndexResponse>;
export type CreateIndexError = IndexAlreadyExists | IndexInvalidName | IndexInvalidConfig | CloudflareOpError;
/** Creates and returns a new Vectorize Index. */
export declare const createIndex: API.OperationMethod<CreateIndexRequest, CreateIndexResponse, CreateIndexError, CloudflareOpContext>;
export type CreateIndexMetadataIndexError = NotFound | MetadataIndexAlreadyExists | MetadataIndexInvalidType | CloudflareOpError;
/** Enable metadata filtering based on metadata property. Limited to 10 properties. */
export declare const createIndexMetadataIndex: API.OperationMethod<CreateIndexMetadataIndexRequest, CreateIndexMetadataIndexResponse, CreateIndexMetadataIndexError, CloudflareOpContext>;
export type DeleteByIdsIndexError = CloudflareOpError;
/** Delete a set of vectors from an index by their vector identifiers. */
export declare const deleteByIdsIndex: API.OperationMethod<DeleteByIdsIndexRequest, DeleteByIdsIndexResponse, DeleteByIdsIndexError, CloudflareOpContext>;
export type DeleteIndexError = NotFound | Gone | CloudflareOpError;
/** Deletes the specified Vectorize Index. */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest, DeleteIndexResponse, DeleteIndexError, CloudflareOpContext>;
export type DeleteIndexMetadataIndexError = NotFound | Gone | MetadataIndexNotFound | CloudflareOpError;
/** Allow Vectorize to delete the specified metadata index. */
export declare const deleteIndexMetadataIndex: API.OperationMethod<DeleteIndexMetadataIndexRequest, DeleteIndexMetadataIndexResponse, DeleteIndexMetadataIndexError, CloudflareOpContext>;
export type GetByIdsIndexError = CloudflareOpError;
/** Get a set of vectors from an index by their vector identifiers. */
export declare const getByIdsIndex: API.OperationMethod<GetByIdsIndexRequest, GetByIdsIndexResponse, GetByIdsIndexError, CloudflareOpContext>;
export type GetIndexError = NotFound | Gone | CloudflareOpError;
/** Returns the specified Vectorize Index. */
export declare const getIndex: API.OperationMethod<GetIndexRequest, GetIndexResponse, GetIndexError, CloudflareOpContext>;
export type GetIndexInfoError = CloudflareOpError;
/** Get information about a vectorize index. */
export declare const getIndexInfo: API.OperationMethod<GetIndexInfoRequest, GetIndexInfoResponse, GetIndexInfoError, CloudflareOpContext>;
export type InsertIndexError = CloudflareOpError;
/** Inserts vectors into the specified index and returns a mutation id corresponding to the vectors enqueued for insertion. */
export declare const insertIndex: API.OperationMethod<InsertIndexRequest, InsertIndexResponse, InsertIndexError, CloudflareOpContext>;
export type ListIndexesError = NotFound | Gone | CloudflareOpError;
/** Returns a list of Vectorize Indexes */
export declare const listIndexes: API.PaginatedOperationMethod<ListIndexesRequest, ListIndexesResponse, ListIndexesError, CloudflareOpContext, IndexesListResultItem>;
export type ListIndexMetadataIndexesError = NotFound | Gone | CloudflareOpError;
/** List Metadata Indexes for the specified Vectorize Index. */
export declare const listIndexMetadataIndexes: API.OperationMethod<ListIndexMetadataIndexesRequest, ListIndexMetadataIndexesResponse, ListIndexMetadataIndexesError, CloudflareOpContext>;
export type ListVectorsIndexError = CloudflareOpError;
/** Returns a paginated list of vector identifiers from the specified index. */
export declare const listVectorsIndex: API.OperationMethod<ListVectorsIndexRequest, ListVectorsIndexResponse, ListVectorsIndexError, CloudflareOpContext>;
export type QueryIndexError = CloudflareOpError;
/** Finds vectors closest to a given vector in an index. */
export declare const queryIndex: API.OperationMethod<QueryIndexRequest, QueryIndexResponse, QueryIndexError, CloudflareOpContext>;
export type UpsertIndexError = CloudflareOpError;
/** Upserts vectors into the specified index, creating them if they do not exist and returns a mutation id corresponding to the vectors enqueued for upsertion. */
export declare const upsertIndex: API.OperationMethod<UpsertIndexRequest, UpsertIndexResponse, UpsertIndexError, CloudflareOpContext>;
//# sourceMappingURL=vectorize.d.ts.map