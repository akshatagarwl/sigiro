import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CloudConnectorRulesNotFound_base: S.Class<CloudConnectorRulesNotFound, S.TaggedStruct<"CloudConnectorRulesNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CloudConnectorRulesNotFound extends /*@__PURE__*/ CloudConnectorRulesNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface ListRulesRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export interface RulesListResultItemParameters {
    /** Host to perform Cloud Connection to */
    host?: string | null;
}
export declare const RulesListResultItemParameters: S.Schema<RulesListResultItemParameters>;
export type RulesListResultItemProvider = "aws_s3" | "cloudflare_r2" | "gcp_storage" | "azure_storage";
export declare const RulesListResultItemProvider: any;
export interface RulesListResultItem {
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
    expression?: string | null;
    /** Parameters of Cloud Connector Rule */
    parameters?: RulesListResultItemParameters | null;
    /** Cloud Provider type */
    provider?: RulesListResultItemProvider | null;
}
export declare const RulesListResultItem: S.Schema<RulesListResultItem>;
export type RulesListResultList = Array<RulesListResultItem>;
export declare const RulesListResultList: S.Schema<RulesListResultList>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export interface RulesUpdateRequestRulesItemParameters {
    /** Host to perform Cloud Connection to */
    host?: string;
}
export declare const RulesUpdateRequestRulesItemParameters: S.Schema<RulesUpdateRequestRulesItemParameters>;
export type RulesUpdateRequestRulesItemProvider = "aws_s3" | "cloudflare_r2" | "gcp_storage" | "azure_storage";
export declare const RulesUpdateRequestRulesItemProvider: any;
export interface RulesUpdateRequestRulesItem {
    id?: string;
    description?: string;
    enabled?: boolean;
    expression?: string;
    /** Parameters of Cloud Connector Rule */
    parameters?: RulesUpdateRequestRulesItemParameters;
    /** Cloud Provider type */
    provider?: RulesUpdateRequestRulesItemProvider | (string & {});
}
export declare const RulesUpdateRequestRulesItem: S.Schema<RulesUpdateRequestRulesItem>;
export type RulesUpdateRequestRulesList = Array<RulesUpdateRequestRulesItem>;
export declare const RulesUpdateRequestRulesList: S.Schema<RulesUpdateRequestRulesList>;
export interface PutRuleRequest {
    /** Identifier. */
    zoneId: string;
    rules?: RulesUpdateRequestRulesList;
}
export declare const PutRuleRequest: S.Schema<PutRuleRequest>;
export type RulesUpdateResultItemParameters = RulesListResultItemParameters;
export declare const RulesUpdateResultItemParameters: S.Schema<RulesListResultItemParameters>;
export type RulesUpdateResultItemProvider = "aws_s3" | "cloudflare_r2" | "gcp_storage" | "azure_storage";
export declare const RulesUpdateResultItemProvider: any;
export interface RulesUpdateResultItem {
    id?: string | null;
    description?: string | null;
    enabled?: boolean | null;
    expression?: string | null;
    /** Parameters of Cloud Connector Rule */
    parameters?: RulesListResultItemParameters | null;
    /** Cloud Provider type */
    provider?: RulesUpdateResultItemProvider | null;
}
export declare const RulesUpdateResultItem: S.Schema<RulesUpdateResultItem>;
export type RulesUpdateResultList = Array<RulesUpdateResultItem>;
export declare const RulesUpdateResultList: S.Schema<RulesUpdateResultList>;
export interface PutRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const PutRuleResponse: S.Schema<PutRuleResponse>;
export type ListRulesError = Forbidden | CloudConnectorRulesNotFound | CloudflareOpError;
/** Retrieves the Cloud Connector rules configured for a zone. Rules define how traffic is routed to cloud services. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type PutRuleError = Forbidden | CloudflareOpError;
/** Updates Cloud Connector rules for a zone, replacing the existing rule configuration. */
export declare const putRule: API.PaginatedOperationMethod<PutRuleRequest, PutRuleResponse, PutRuleError, CloudflareOpContext, RulesUpdateResultItem>;
//# sourceMappingURL=cloud_connector.d.ts.map