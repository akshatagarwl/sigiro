import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CmbConfigNotFound_base: S.Class<CmbConfigNotFound, S.TaggedStruct<"CmbConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CmbConfigNotFound extends /*@__PURE__*/ CmbConfigNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LogsControlNotAuthorized_base: S.Class<LogsControlNotAuthorized, S.TaggedStruct<"LogsControlNotAuthorized", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LogsControlNotAuthorized extends /*@__PURE__*/ LogsControlNotAuthorized_base {
}
export interface CreateControlCmbConfigRequest {
    /** Identifier. */
    accountId: string;
    /** Allow out of region access */
    allowOutOfRegionAccess?: boolean;
    /** Name of the region. */
    regions?: string;
}
export declare const CreateControlCmbConfigRequest: S.Schema<CreateControlCmbConfigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateControlCmbConfigResponse {
    /** Allow out of region access */
    allowOutOfRegionAccess?: boolean | null;
    /** Name of the region. */
    regions?: string | null;
}
export declare const CreateControlCmbConfigResponse: S.Schema<CreateControlCmbConfigResponse>;
export interface CreateControlRetentionRequest {
    /** Identifier. */
    zoneId: string;
    /** The log retention flag for Logpull API. */
    flag?: boolean;
}
export declare const CreateControlRetentionRequest: S.Schema<CreateControlRetentionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateControlRetentionResponse {
    /** The log retention flag for Logpull API. */
    flag?: boolean | null;
}
export declare const CreateControlRetentionResponse: S.Schema<CreateControlRetentionResponse>;
export interface LogExplorerDatasetsCreateRequestFieldsItem {
    /** Whether the API includes this field in log ingest. */
    enabled: boolean;
    /** Field name in lowercase. */
    name: string;
}
export declare const LogExplorerDatasetsCreateRequestFieldsItem: S.Schema<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsCreateRequestFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export declare const LogExplorerDatasetsCreateRequestFieldsList: S.Schema<LogExplorerDatasetsCreateRequestFieldsList>;
export interface CreateLogExplorerDatasetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Dataset type name to create (e.g. `http_requests`). */
    dataset: string;
    /** Controls which fields the API ingests. Defaults to all available */
    fields?: LogExplorerDatasetsCreateRequestFieldsList;
}
export declare const CreateLogExplorerDatasetForAccountRequest: S.Schema<CreateLogExplorerDatasetForAccountRequest>;
export type LogExplorerDatasetsCreateResponseObjectType = "account" | "zone";
export declare const LogExplorerDatasetsCreateResponseObjectType: any;
export type LogExplorerDatasetsCreateResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export declare const LogExplorerDatasetsCreateResponseFieldsItem: S.Schema<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsCreateResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export declare const LogExplorerDatasetsCreateResponseFieldsList: S.Schema<LogExplorerDatasetsCreateResponseFieldsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLogExplorerDatasetResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsCreateResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The field configuration for this dataset. */
    fields?: LogExplorerDatasetsCreateResponseFieldsList | null;
}
export declare const CreateLogExplorerDatasetResponse: S.Schema<CreateLogExplorerDatasetResponse>;
export interface CreateLogExplorerDatasetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Dataset type name to create (e.g. `http_requests`). */
    dataset: string;
    /** Controls which fields the API ingests. Defaults to all available */
    fields?: LogExplorerDatasetsCreateRequestFieldsList;
}
export declare const CreateLogExplorerDatasetForZoneRequest: S.Schema<CreateLogExplorerDatasetForZoneRequest>;
export interface DeleteControlCmbConfigRequest {
    /** Identifier. */
    accountId: string;
}
export declare const DeleteControlCmbConfigRequest: S.Schema<DeleteControlCmbConfigRequest>;
export type DeleteControlCmbConfigResponse = unknown;
export declare const DeleteControlCmbConfigResponse: S.Schema<DeleteControlCmbConfigResponse>;
export interface GetControlCmbConfigRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetControlCmbConfigRequest: S.Schema<GetControlCmbConfigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetControlCmbConfigResponse {
    /** Allow out of region access */
    allowOutOfRegionAccess?: boolean | null;
    /** Name of the region. */
    regions?: string | null;
}
export declare const GetControlCmbConfigResponse: S.Schema<GetControlCmbConfigResponse>;
export interface GetControlRetentionRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetControlRetentionRequest: S.Schema<GetControlRetentionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetControlRetentionResponse {
    /** The log retention flag for Logpull API. */
    flag?: boolean | null;
}
export declare const GetControlRetentionResponse: S.Schema<GetControlRetentionResponse>;
export interface GetLogExplorerDatasetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    datasetId: string;
}
export declare const GetLogExplorerDatasetForAccountRequest: S.Schema<GetLogExplorerDatasetForAccountRequest>;
export type LogExplorerDatasetsGetResponseObjectType = "account" | "zone";
export declare const LogExplorerDatasetsGetResponseObjectType: any;
export type LogExplorerDatasetsGetResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export declare const LogExplorerDatasetsGetResponseFieldsItem: S.Schema<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsGetResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export declare const LogExplorerDatasetsGetResponseFieldsList: S.Schema<LogExplorerDatasetsGetResponseFieldsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLogExplorerDatasetResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsGetResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The field configuration for this dataset. */
    fields?: LogExplorerDatasetsGetResponseFieldsList | null;
}
export declare const GetLogExplorerDatasetResponse: S.Schema<GetLogExplorerDatasetResponse>;
export interface GetLogExplorerDatasetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    datasetId: string;
}
export declare const GetLogExplorerDatasetForZoneRequest: S.Schema<GetLogExplorerDatasetForZoneRequest>;
export type RayidGetRequestTimestamps = "unix" | "unixnano" | "rfc3339";
export declare const RayidGetRequestTimestamps: any;
export interface GetRayidRequest {
    /** Identifier. */
    zoneId: string;
    /** Ray identifier. */
    rayId: string;
    /** The `/received` route by default returns a limited set of fields, and allows customers to override the default field set by specifying individual fields. The reasons for this are: 1. Most customers require only a small subset of fields, but that subset varies from customer to customer; 2. Flat schema is much easier to work with downstream (importing into BigTable etc); 3. Performance (time to process, file size). If `?fields=` is not specified, default field set is returned. This default field set may change at any time. When `?fields=` is provided, each record is returned with the specified fields. `fields` must be specified as a comma separated list without any whitespaces, and all fields must exist. The order in which fields are specified does not matter, and the order of fields in the response is not specified. */
    fields?: string;
    /** By default, timestamps in responses are returned as Unix nanosecond integers. The `?timestamps=` argument can be set to change the format in which response timestamps are returned. Possible values are: `unix`, `unixnano`, `rfc3339`. Note that `unix` and `unixnano` return timestamps as integers; `rfc3339` returns timestamps as strings. */
    timestamps?: RayidGetRequestTimestamps | (string & {});
}
export declare const GetRayidRequest: S.Schema<GetRayidRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetRayidResponse {
}
export declare const GetRayidResponse: S.Schema<GetRayidResponse>;
export type ReceivedGetRequestTimestamps = "unix" | "unixnano" | "rfc3339";
export declare const ReceivedGetRequestTimestamps: any;
export interface GetReceivedRequest {
    /** Identifier. */
    zoneId: string;
    /** Sets the (exclusive) end of the requested time frame. This can be a unix timestamp (in seconds or nanoseconds), or an absolute timestamp that conforms to RFC 3339. `end` must be at least five minutes earlier than now and must be later than `start`. Difference between `start` and `end` must be not greater than one hour. */
    end: string;
    /** When `?count=` is provided, the response will contain up to `count` results. Since results are not sorted, you are likely to get different data for repeated requests. `count` must be an integer > 0. */
    count?: number;
    /** The `/received` route by default returns a limited set of fields, and allows customers to override the default field set by specifying individual fields. The reasons for this are: 1. Most customers require only a small subset of fields, but that subset varies from customer to customer; 2. Flat schema is much easier to work with downstream (importing into BigTable etc); 3. Performance (time to process, file size). If `?fields=` is not specified, default field set is returned. This default field set may change at any time. When `?fields=` is provided, each record is returned with the specified fields. `fields` must be specified as a comma separated list without any whitespaces, and all fields must exist. The order in which fields are specified does not matter, and the order of fields in the response is not specified. */
    fields?: string;
    /** When `?sample=` is provided, a sample of matching records is returned. If `sample=0.1` then 10% of records will be returned. Sampling is random: repeated calls will not only return different records, but likely will also vary slightly in number of returned records. When `?count=` is also specified, `count` is applied to the number of returned records, not the sampled records. So, with `sample=0.05` and `count=7`, when there is a total of 100 records available, approximately five will be returned. When there are 1000 records, seven will be returned. When there are 10,000 records, seven will be returned. */
    sample?: number;
    /** Sets the (inclusive) beginning of the requested time frame. This can be a unix timestamp (in seconds or nanoseconds), or an absolute timestamp that conforms to RFC 3339. At this point in time, it cannot exceed a time in the past greater than seven days. */
    start?: string;
    /** By default, timestamps in responses are returned as Unix nanosecond integers. The `?timestamps=` argument can be set to change the format in which response timestamps are returned. Possible values are: `unix`, `unixnano`, `rfc3339`. Note that `unix` and `unixnano` return timestamps as integers; `rfc3339` returns timestamps as strings. */
    timestamps?: ReceivedGetRequestTimestamps | (string & {});
}
export declare const GetReceivedRequest: S.Schema<GetReceivedRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetReceivedResponse {
}
export declare const GetReceivedResponse: S.Schema<GetReceivedResponse>;
export interface GetReceivedFieldRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetReceivedFieldRequest: S.Schema<GetReceivedFieldRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetReceivedFieldResponse {
    key?: string | null;
}
export declare const GetReceivedFieldResponse: S.Schema<GetReceivedFieldResponse>;
export interface ListLogExplorerDatasetAvailablesForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export declare const ListLogExplorerDatasetAvailablesForAccountRequest: S.Schema<ListLogExplorerDatasetAvailablesForAccountRequest>;
export type LogExplorerDatasetsAvailableListResultItemObjectType = "account" | "zone";
export declare const LogExplorerDatasetsAvailableListResultItemObjectType: any;
export type LogExplorerDatasetsAvailableListResultItemSchemaPropertiesMap = {
    [key: string]: unknown | undefined;
};
export declare const LogExplorerDatasetsAvailableListResultItemSchemaPropertiesMap: S.Schema<LogExplorerDatasetsAvailableListResultItemSchemaPropertiesMap>;
export type LogExplorerDatasetsAvailableListResultItemSchemaRequiredList = Array<string>;
export declare const LogExplorerDatasetsAvailableListResultItemSchemaRequiredList: S.Schema<LogExplorerDatasetsAvailableListResultItemSchemaRequiredList>;
export type LogExplorerDatasetsAvailableListResultItemSchemaType = "object";
export declare const LogExplorerDatasetsAvailableListResultItemSchemaType: any;
export interface LogExplorerDatasetsAvailableListResultItemSchema {
    properties?: LogExplorerDatasetsAvailableListResultItemSchemaPropertiesMap | null;
    required?: LogExplorerDatasetsAvailableListResultItemSchemaRequiredList | null;
    type?: LogExplorerDatasetsAvailableListResultItemSchemaType | null;
}
export declare const LogExplorerDatasetsAvailableListResultItemSchema: S.Schema<LogExplorerDatasetsAvailableListResultItemSchema>;
export interface LogExplorerDatasetsAvailableListResultItem {
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Whether this dataset type is account-scoped or zone-scoped. */
    objectType: LogExplorerDatasetsAvailableListResultItemObjectType;
    /** JSON Schema that describes the fields this dataset exposes. */
    schema: LogExplorerDatasetsAvailableListResultItemSchema;
    /** The primary timestamp field name for this dataset. */
    timestampField: string;
}
export declare const LogExplorerDatasetsAvailableListResultItem: S.Schema<LogExplorerDatasetsAvailableListResultItem>;
export type LogExplorerDatasetsAvailableListResultList = Array<LogExplorerDatasetsAvailableListResultItem>;
export declare const LogExplorerDatasetsAvailableListResultList: S.Schema<LogExplorerDatasetsAvailableListResultList>;
export interface ListLogExplorerDatasetAvailablesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogExplorerDatasetsAvailableListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLogExplorerDatasetAvailablesResponse: S.Schema<ListLogExplorerDatasetAvailablesResponse>;
export interface ListLogExplorerDatasetAvailablesForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export declare const ListLogExplorerDatasetAvailablesForZoneRequest: S.Schema<ListLogExplorerDatasetAvailablesForZoneRequest>;
export interface ListLogExplorerDatasetsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Set to true to include zone-scoped datasets belonging to this account. */
    includeZones?: boolean;
}
export declare const ListLogExplorerDatasetsForAccountRequest: S.Schema<ListLogExplorerDatasetsForAccountRequest>;
export type LogExplorerDatasetsListResultItemObjectType = "account" | "zone";
export declare const LogExplorerDatasetsListResultItemObjectType: any;
export interface LogExplorerDatasetsListResultItem {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsListResultItemObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
}
export declare const LogExplorerDatasetsListResultItem: S.Schema<LogExplorerDatasetsListResultItem>;
export type LogExplorerDatasetsListResultList = Array<LogExplorerDatasetsListResultItem>;
export declare const LogExplorerDatasetsListResultList: S.Schema<LogExplorerDatasetsListResultList>;
export interface ListLogExplorerDatasetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogExplorerDatasetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLogExplorerDatasetsResponse: S.Schema<ListLogExplorerDatasetsResponse>;
export interface ListLogExplorerDatasetsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Set to true to include zone-scoped datasets belonging to this account. */
    includeZones?: boolean;
}
export declare const ListLogExplorerDatasetsForZoneRequest: S.Schema<ListLogExplorerDatasetsForZoneRequest>;
export interface SqlLogExplorerQueryForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export declare const SqlLogExplorerQueryForAccountRequest: S.Schema<SqlLogExplorerQueryForAccountRequest>;
export type LogExplorerQuerySqlResultItemMap = {
    [key: string]: unknown | undefined;
};
export declare const LogExplorerQuerySqlResultItemMap: S.Schema<LogExplorerQuerySqlResultItemMap>;
export type LogExplorerQuerySqlResultList = Array<LogExplorerQuerySqlResultItemMap>;
export declare const LogExplorerQuerySqlResultList: S.Schema<LogExplorerQuerySqlResultList>;
export interface SqlLogExplorerQueryResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogExplorerQuerySqlResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const SqlLogExplorerQueryResponse: S.Schema<SqlLogExplorerQueryResponse>;
export interface SqlLogExplorerQueryForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export declare const SqlLogExplorerQueryForZoneRequest: S.Schema<SqlLogExplorerQueryForZoneRequest>;
export type LogExplorerDatasetsUpdateRequestFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export declare const LogExplorerDatasetsUpdateRequestFieldsItem: S.Schema<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsUpdateRequestFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export declare const LogExplorerDatasetsUpdateRequestFieldsList: S.Schema<LogExplorerDatasetsUpdateRequestFieldsList>;
export interface UpdateLogExplorerDatasetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    datasetId: string;
    /** Whether to enable or disable log ingest for this dataset. */
    enabled: boolean;
    /** Controls which fields the API ingests after the update. Defaults */
    fields?: LogExplorerDatasetsUpdateRequestFieldsList;
}
export declare const UpdateLogExplorerDatasetForAccountRequest: S.Schema<UpdateLogExplorerDatasetForAccountRequest>;
export type LogExplorerDatasetsUpdateResponseObjectType = "account" | "zone";
export declare const LogExplorerDatasetsUpdateResponseObjectType: any;
export type LogExplorerDatasetsUpdateResponseFieldsItem = LogExplorerDatasetsCreateRequestFieldsItem;
export declare const LogExplorerDatasetsUpdateResponseFieldsItem: S.Schema<LogExplorerDatasetsCreateRequestFieldsItem>;
export type LogExplorerDatasetsUpdateResponseFieldsList = Array<LogExplorerDatasetsCreateRequestFieldsItem>;
export declare const LogExplorerDatasetsUpdateResponseFieldsList: S.Schema<LogExplorerDatasetsUpdateResponseFieldsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLogExplorerDatasetResponse {
    /** RFC3339 timestamp recording when the API created this dataset. */
    createdAt: string;
    /** Dataset type name (e.g. `http_requests`). */
    dataset: string;
    /** Unique dataset ID. */
    datasetId: string;
    /** Whether log ingest is currently active for this dataset. */
    enabled: boolean;
    /** Public ID of the account or zone that owns this dataset. */
    objectId: string;
    /** Whether this dataset belongs to an account or a zone. */
    objectType: LogExplorerDatasetsUpdateResponseObjectType;
    /** RFC3339 timestamp recording when the API last updated this dataset. */
    updatedAt: string;
    /** The field configuration for this dataset. */
    fields?: LogExplorerDatasetsUpdateResponseFieldsList | null;
}
export declare const UpdateLogExplorerDatasetResponse: S.Schema<UpdateLogExplorerDatasetResponse>;
export interface UpdateLogExplorerDatasetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    datasetId: string;
    /** Whether to enable or disable log ingest for this dataset. */
    enabled: boolean;
    /** Controls which fields the API ingests after the update. Defaults */
    fields?: LogExplorerDatasetsUpdateRequestFieldsList;
}
export declare const UpdateLogExplorerDatasetForZoneRequest: S.Schema<UpdateLogExplorerDatasetForZoneRequest>;
export type CreateControlCmbConfigError = LogsControlNotAuthorized | Forbidden | CloudflareOpError;
/** Updates CMB config. */
export declare const createControlCmbConfig: API.OperationMethod<CreateControlCmbConfigRequest, CreateControlCmbConfigResponse, CreateControlCmbConfigError, CloudflareOpContext>;
export type CreateControlRetentionError = LogsControlNotAuthorized | Forbidden | CloudflareOpError;
/** Updates log retention flag for Logpull API. */
export declare const createControlRetention: API.OperationMethod<CreateControlRetentionRequest, CreateControlRetentionResponse, CreateControlRetentionError, CloudflareOpContext>;
export type CreateLogExplorerDatasetForAccountError = CloudflareOpError;
/** Create a new Log Explorer dataset for the account or zone. Use the `/account or zones/{account or zone_id}/logs/explorer/datasets/available` endpoint to list dataset types you can create along with their available fields. The `fields` property is optional. If not specified, all available fields will be enabled. For zone-level datasets use the zone-scoped endpoint: POST /zones/{zone_id}/logs/explorer/datasets For dataset field definitions, see: https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const createLogExplorerDatasetForAccount: API.OperationMethod<CreateLogExplorerDatasetForAccountRequest, CreateLogExplorerDatasetResponse, CreateLogExplorerDatasetForAccountError, CloudflareOpContext>;
export type CreateLogExplorerDatasetForZoneError = CloudflareOpError;
/** Create a new Log Explorer dataset for the account or zone. Use the `/account or zones/{account or zone_id}/logs/explorer/datasets/available` endpoint to list dataset types you can create along with their available fields. The `fields` property is optional. If not specified, all available fields will be enabled. For zone-level datasets use the zone-scoped endpoint: POST /zones/{zone_id}/logs/explorer/datasets For dataset field definitions, see: https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const createLogExplorerDatasetForZone: API.OperationMethod<CreateLogExplorerDatasetForZoneRequest, CreateLogExplorerDatasetResponse, CreateLogExplorerDatasetForZoneError, CloudflareOpContext>;
export type DeleteControlCmbConfigError = LogsControlNotAuthorized | CmbConfigNotFound | Forbidden | CloudflareOpError;
/** Deletes CMB config. */
export declare const deleteControlCmbConfig: API.OperationMethod<DeleteControlCmbConfigRequest, DeleteControlCmbConfigResponse, DeleteControlCmbConfigError, CloudflareOpContext>;
export type GetControlCmbConfigError = LogsControlNotAuthorized | CmbConfigNotFound | Forbidden | CloudflareOpError;
/** Gets CMB config. */
export declare const getControlCmbConfig: API.OperationMethod<GetControlCmbConfigRequest, GetControlCmbConfigResponse, GetControlCmbConfigError, CloudflareOpContext>;
export type GetControlRetentionError = LogsControlNotAuthorized | Forbidden | CloudflareOpError;
/** Gets log retention flag for Logpull API. */
export declare const getControlRetention: API.OperationMethod<GetControlRetentionRequest, GetControlRetentionResponse, GetControlRetentionError, CloudflareOpContext>;
export type GetLogExplorerDatasetForAccountError = CloudflareOpError;
/** Retrieve a single Log Explorer dataset by ID for the account or zone. */
export declare const getLogExplorerDatasetForAccount: API.OperationMethod<GetLogExplorerDatasetForAccountRequest, GetLogExplorerDatasetResponse, GetLogExplorerDatasetForAccountError, CloudflareOpContext>;
export type GetLogExplorerDatasetForZoneError = CloudflareOpError;
/** Retrieve a single Log Explorer dataset by ID for the account or zone. */
export declare const getLogExplorerDatasetForZone: API.OperationMethod<GetLogExplorerDatasetForZoneRequest, GetLogExplorerDatasetResponse, GetLogExplorerDatasetForZoneError, CloudflareOpContext>;
export type GetRayidError = CloudflareOpError;
/** The `/rayids` api route allows lookups by specific rayid. The rayids route will return zero, one, or more records (ray ids are not unique). */
export declare const getRayid: API.OperationMethod<GetRayidRequest, GetRayidResponse, GetRayidError, CloudflareOpContext>;
export type GetReceivedError = CloudflareOpError;
/** The `/received` api route allows customers to retrieve their edge HTTP logs. The basic access pattern is "give me all the logs for zone Z for minute M", where the minute M refers to the time records were received at Cloudflare's central data center. `start` is inclusive, and `end` is exclusive. Because of that, to get all data, at minutely cadence, starting at 10AM, the proper values are: `start=2018-05-20T10:00:00Z&end=2018-05-20T10:01:00Z`, then `start=2018-05-20T10:01:00Z&end=2018-05-20T10:02:00Z` and so on; the overlap will be handled properly. */
export declare const getReceived: API.OperationMethod<GetReceivedRequest, GetReceivedResponse, GetReceivedError, CloudflareOpContext>;
export type GetReceivedFieldError = CloudflareOpError;
/** Lists all fields available. The response is json object with key-value pairs, where keys are field names, and values are descriptions. */
export declare const getReceivedField: API.OperationMethod<GetReceivedFieldRequest, GetReceivedFieldResponse, GetReceivedFieldError, CloudflareOpContext>;
export type ListLogExplorerDatasetAvailablesForAccountError = CloudflareOpError;
/** Returns all dataset types that this account or zone can create. Each entry includes the dataset schema and timestamp field. The schema shows all possible fields for a dataset. However, not all fields may be available for your account or zone. When creating or updating a dataset, only fields available to your account or zone can be enabled. If you request a field that is not available, you will receive an error. */
export declare const listLogExplorerDatasetAvailablesForAccount: API.PaginatedOperationMethod<ListLogExplorerDatasetAvailablesForAccountRequest, ListLogExplorerDatasetAvailablesResponse, ListLogExplorerDatasetAvailablesForAccountError, CloudflareOpContext, LogExplorerDatasetsAvailableListResultItem>;
export type ListLogExplorerDatasetAvailablesForZoneError = CloudflareOpError;
/** Returns all dataset types that this account or zone can create. Each entry includes the dataset schema and timestamp field. The schema shows all possible fields for a dataset. However, not all fields may be available for your account or zone. When creating or updating a dataset, only fields available to your account or zone can be enabled. If you request a field that is not available, you will receive an error. */
export declare const listLogExplorerDatasetAvailablesForZone: API.PaginatedOperationMethod<ListLogExplorerDatasetAvailablesForZoneRequest, ListLogExplorerDatasetAvailablesResponse, ListLogExplorerDatasetAvailablesForZoneError, CloudflareOpContext, LogExplorerDatasetsAvailableListResultItem>;
export type ListLogExplorerDatasetsForAccountError = CloudflareOpError;
/** Returns all Log Explorer datasets configured for the account or zone. Pass `include_zones=true` to also include zone-level datasets that belong to this account or zone. List responses omit the `fields` property; use the single-dataset endpoint to retrieve field configuration. */
export declare const listLogExplorerDatasetsForAccount: API.PaginatedOperationMethod<ListLogExplorerDatasetsForAccountRequest, ListLogExplorerDatasetsResponse, ListLogExplorerDatasetsForAccountError, CloudflareOpContext, LogExplorerDatasetsListResultItem>;
export type ListLogExplorerDatasetsForZoneError = CloudflareOpError;
/** Returns all Log Explorer datasets configured for the account or zone. Pass `include_zones=true` to also include zone-level datasets that belong to this account or zone. List responses omit the `fields` property; use the single-dataset endpoint to retrieve field configuration. */
export declare const listLogExplorerDatasetsForZone: API.PaginatedOperationMethod<ListLogExplorerDatasetsForZoneRequest, ListLogExplorerDatasetsResponse, ListLogExplorerDatasetsForZoneError, CloudflareOpContext, LogExplorerDatasetsListResultItem>;
export type SqlLogExplorerQueryForAccountError = CloudflareOpError;
/** Run a SQL query against account or zone-level datasets. Timestamp fields are RFC3339 strings. Filter with: WHERE {timestamp_field} >= now() - INTERVAL '30' DAY WHERE {timestamp_field} >= '2026-04-01T00:00:00Z' WHERE {timestamp_field} BETWEEN '2026-04-01T00:00:00Z' AND '2026-04-30T23:59:59Z' Check /account or zones/{account or zone_id}/logs/explorer/datasets to see enabled account or zone level datasets. Zone-level datasets will not appear here. Check /account or zones/{account or zone_id}/logs/explorer/datasets/available for the schemas, and the name of the timestamp fields. For zone-level datasets use the zone-scoped endpoint: POST /zones/{zone_id}/logs/explorer/query/sql For more information about the datasets, and the meaning of each field, check out https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const sqlLogExplorerQueryForAccount: API.PaginatedOperationMethod<SqlLogExplorerQueryForAccountRequest, SqlLogExplorerQueryResponse, SqlLogExplorerQueryForAccountError, CloudflareOpContext, LogExplorerQuerySqlResultItemMap>;
export type SqlLogExplorerQueryForZoneError = CloudflareOpError;
/** Run a SQL query against account or zone-level datasets. Timestamp fields are RFC3339 strings. Filter with: WHERE {timestamp_field} >= now() - INTERVAL '30' DAY WHERE {timestamp_field} >= '2026-04-01T00:00:00Z' WHERE {timestamp_field} BETWEEN '2026-04-01T00:00:00Z' AND '2026-04-30T23:59:59Z' Check /account or zones/{account or zone_id}/logs/explorer/datasets to see enabled account or zone level datasets. Zone-level datasets will not appear here. Check /account or zones/{account or zone_id}/logs/explorer/datasets/available for the schemas, and the name of the timestamp fields. For zone-level datasets use the zone-scoped endpoint: POST /zones/{zone_id}/logs/explorer/query/sql For more information about the datasets, and the meaning of each field, check out https://developers.cloudflare.com/logs/logpush/logpush-job/datasets/ */
export declare const sqlLogExplorerQueryForZone: API.PaginatedOperationMethod<SqlLogExplorerQueryForZoneRequest, SqlLogExplorerQueryResponse, SqlLogExplorerQueryForZoneError, CloudflareOpContext, LogExplorerQuerySqlResultItemMap>;
export type UpdateLogExplorerDatasetForAccountError = CloudflareOpError;
/** Updates the enabled state and/or field configuration of an account or zone dataset. */
export declare const updateLogExplorerDatasetForAccount: API.OperationMethod<UpdateLogExplorerDatasetForAccountRequest, UpdateLogExplorerDatasetResponse, UpdateLogExplorerDatasetForAccountError, CloudflareOpContext>;
export type UpdateLogExplorerDatasetForZoneError = CloudflareOpError;
/** Updates the enabled state and/or field configuration of an account or zone dataset. */
export declare const updateLogExplorerDatasetForZone: API.OperationMethod<UpdateLogExplorerDatasetForZoneRequest, UpdateLogExplorerDatasetResponse, UpdateLogExplorerDatasetForZoneError, CloudflareOpContext>;
//# sourceMappingURL=logs.d.ts.map