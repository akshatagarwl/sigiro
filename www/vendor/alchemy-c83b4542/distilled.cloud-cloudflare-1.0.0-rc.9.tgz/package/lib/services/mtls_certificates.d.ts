import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CertificateAlreadyDeleted_base: S.Class<CertificateAlreadyDeleted, S.TaggedStruct<"CertificateAlreadyDeleted", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateAlreadyDeleted extends /*@__PURE__*/ CertificateAlreadyDeleted_base {
}
declare const CertificateAlreadyExists_base: S.Class<CertificateAlreadyExists, S.TaggedStruct<"CertificateAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateAlreadyExists extends /*@__PURE__*/ CertificateAlreadyExists_base {
}
declare const CertificateNotFound_base: S.Class<CertificateNotFound, S.TaggedStruct<"CertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateNotFound extends /*@__PURE__*/ CertificateNotFound_base {
}
export interface CreateMtlsCertificateRequest {
    /** Identifier. */
    accountId: string;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca: boolean;
    /** The uploaded root CA certificate. */
    certificates: string;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string;
    /** The private key for the certificate. This field is only needed for specific use cases such as using a custom certificate with Zero Trust's block page. */
    privateKey?: string;
}
export declare const CreateMtlsCertificateRequest: S.Schema<CreateMtlsCertificateRequest>;
export type CreateResponseType = "custom" | "gateway_managed" | "access_managed";
export declare const CreateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMtlsCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: CreateResponseType | null;
    /** This is the time the certificate was updated. */
    updatedAt?: string | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const CreateMtlsCertificateResponse: S.Schema<CreateMtlsCertificateResponse>;
export interface DeleteMtlsCertificateRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    mtlsCertificateId: string;
}
export declare const DeleteMtlsCertificateRequest: S.Schema<DeleteMtlsCertificateRequest>;
export type DeleteResponseType = "custom" | "gateway_managed" | "access_managed";
export declare const DeleteResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMtlsCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: DeleteResponseType | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const DeleteMtlsCertificateResponse: S.Schema<DeleteMtlsCertificateResponse>;
export interface GetAssociationRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    mtlsCertificateId: string;
}
export declare const GetAssociationRequest: S.Schema<GetAssociationRequest>;
export interface AssociationsGetResultItem {
    /** The service using the certificate. */
    service?: string | null;
    /** Certificate deployment status for the given service. */
    status?: string | null;
}
export declare const AssociationsGetResultItem: S.Schema<AssociationsGetResultItem>;
export type AssociationsGetResultList = Array<AssociationsGetResultItem>;
export declare const AssociationsGetResultList: S.Schema<AssociationsGetResultList>;
export interface GetAssociationResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AssociationsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetAssociationResponse: S.Schema<GetAssociationResponse>;
export interface GetMtlsCertificateRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    mtlsCertificateId: string;
}
export declare const GetMtlsCertificateRequest: S.Schema<GetMtlsCertificateRequest>;
export type GetResponseType = "custom" | "gateway_managed" | "access_managed";
export declare const GetResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMtlsCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: GetResponseType | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const GetMtlsCertificateResponse: S.Schema<GetMtlsCertificateResponse>;
export type ListRequestType = "custom" | "gateway_managed" | "access_managed";
export declare const ListRequestType: any;
export type ListRequestTypeList = Array<ListRequestType | (string & {})>;
export declare const ListRequestTypeList: S.Schema<ListRequestTypeList>;
export interface ListMtlsCertificatesRequest {
    /** Identifier. */
    accountId: string;
    /** Filters results by certificate type. Multiple types can be comma-separated. */
    type?: ListRequestTypeList;
}
export declare const ListMtlsCertificatesRequest: S.Schema<ListMtlsCertificatesRequest>;
export type ListResultItemType = "custom" | "gateway_managed" | "access_managed";
export declare const ListResultItemType: any;
export interface ListResultItem {
    /** Identifier. */
    id?: string | null;
    /** Indicates whether the certificate is a CA or leaf certificate. */
    ca?: boolean | null;
    /** The uploaded root CA certificate. */
    certificates?: string | null;
    /** When the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** Optional unique name for the certificate. Only used for human readability. */
    name?: string | null;
    /** The certificate serial number. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** The type of the certificate, indicating how it was created and who manages it. */
    type?: ListResultItemType | null;
    /** This is the time the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListMtlsCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListMtlsCertificatesResponse: S.Schema<ListMtlsCertificatesResponse>;
export type CreateMtlsCertificateError = CertificateAlreadyExists | CloudflareOpError;
/** Upload a certificate that you want to use with mTLS-enabled Cloudflare services, such as Bring Your Own CA (BYO-CA) for mTLS. To create certificates issued by the Cloudflare managed CA, use the [Create Client Certificate endpoint](/api/resources/client_certificates/methods/create/). */
export declare const createMtlsCertificate: API.OperationMethod<CreateMtlsCertificateRequest, CreateMtlsCertificateResponse, CreateMtlsCertificateError, CloudflareOpContext>;
export type DeleteMtlsCertificateError = CertificateNotFound | CertificateAlreadyDeleted | CloudflareOpError;
/** Deletes the mTLS certificate unless the certificate is in use by one or more Cloudflare services. */
export declare const deleteMtlsCertificate: API.OperationMethod<DeleteMtlsCertificateRequest, DeleteMtlsCertificateResponse, DeleteMtlsCertificateError, CloudflareOpContext>;
export type GetAssociationError = CloudflareOpError;
/** Lists all active associations between the certificate and Cloudflare services. */
export declare const getAssociation: API.PaginatedOperationMethod<GetAssociationRequest, GetAssociationResponse, GetAssociationError, CloudflareOpContext, AssociationsGetResultItem>;
export type GetMtlsCertificateError = CertificateNotFound | CloudflareOpError;
/** Fetches a single mTLS certificate uploaded to your account. To get a certificate issued by the Cloudflare managed CA, use the [Client Certificate Details endpoint](/api/resources/client_certificates/methods/get/). */
export declare const getMtlsCertificate: API.OperationMethod<GetMtlsCertificateRequest, GetMtlsCertificateResponse, GetMtlsCertificateError, CloudflareOpContext>;
export type ListMtlsCertificatesError = CloudflareOpError;
/** Lists all mTLS certificates uploaded to your account, such as Bring Your Own CA (BYO-CA) for mTLS. To list certificates issued by the Cloudflare managed CA, use the [List Client Certificates endpoint](/api/resources/client_certificates/methods/list/). */
export declare const listMtlsCertificates: API.PaginatedOperationMethod<ListMtlsCertificatesRequest, ListMtlsCertificatesResponse, ListMtlsCertificatesError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=mtls_certificates.d.ts.map