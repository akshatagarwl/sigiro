import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ScanConfigNotFound_base: S.Class<ScanConfigNotFound, S.TaggedStruct<"ScanConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ScanConfigNotFound extends /*@__PURE__*/ ScanConfigNotFound_base {
}
export type ThreatEventsBulkCreateRequestDataItemRawDataMap = {
    [key: string]: unknown | undefined;
};
export declare const ThreatEventsBulkCreateRequestDataItemRawDataMap: S.Schema<ThreatEventsBulkCreateRequestDataItemRawDataMap>;
export interface ThreatEventsBulkCreateRequestDataItemRaw {
    data: ThreatEventsBulkCreateRequestDataItemRawDataMap;
    source?: string;
    tlp?: string;
}
export declare const ThreatEventsBulkCreateRequestDataItemRaw: S.Schema<ThreatEventsBulkCreateRequestDataItemRaw>;
export interface ThreatEventsBulkCreateRequestDataItemIndicatorsItem {
    /** The type of indicator (e.g., DOMAIN, IP, JA3, HASH) */
    indicatorType: string;
    /** The indicator value (e.g., domain name, IP address, hash) */
    value: string;
}
export declare const ThreatEventsBulkCreateRequestDataItemIndicatorsItem: S.Schema<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export type ThreatEventsBulkCreateRequestDataItemIndicatorsList = Array<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export declare const ThreatEventsBulkCreateRequestDataItemIndicatorsList: S.Schema<ThreatEventsBulkCreateRequestDataItemIndicatorsList>;
export type ThreatEventsBulkCreateRequestDataItemTagsList = Array<string>;
export declare const ThreatEventsBulkCreateRequestDataItemTagsList: S.Schema<ThreatEventsBulkCreateRequestDataItemTagsList>;
export interface ThreatEventsBulkCreateRequestDataItem {
    category: string;
    date: string;
    event: string;
    raw: ThreatEventsBulkCreateRequestDataItemRaw;
    tlp: string;
    accountId?: number;
    attacker?: string;
    attackerCountry?: string;
    datasetId?: string;
    indicator?: string;
    /** Array of indicators for this event. Supports multiple indicators per event for complex scenarios. */
    indicators?: ThreatEventsBulkCreateRequestDataItemIndicatorsList;
    indicatorType?: string;
    insight?: string;
    tags?: ThreatEventsBulkCreateRequestDataItemTagsList;
    targetCountry?: string;
    targetIndustry?: string;
}
export declare const ThreatEventsBulkCreateRequestDataItem: S.Schema<ThreatEventsBulkCreateRequestDataItem>;
export type ThreatEventsBulkCreateRequestDataList = Array<ThreatEventsBulkCreateRequestDataItem>;
export declare const ThreatEventsBulkCreateRequestDataList: S.Schema<ThreatEventsBulkCreateRequestDataList>;
export interface BulkCreateThreatEventsRequest {
    /** Account ID. */
    accountId: string;
    data: ThreatEventsBulkCreateRequestDataList;
    datasetId: string;
    /** When true, response includes array of created event UUIDs and shard IDs. Useful for tracking which events were created and where. */
    includeCreatedEvents?: boolean;
}
export declare const BulkCreateThreatEventsRequest: S.Schema<BulkCreateThreatEventsRequest>;
export interface ThreatEventsBulkCreateResponseCreatedEventsItem {
    /** Original index in the input data array */
    eventIndex: number;
    /** Dataset ID of the shard where the event was created */
    shardId: string;
    /** UUID of the created event */
    uuid: string;
}
export declare const ThreatEventsBulkCreateResponseCreatedEventsItem: S.Schema<ThreatEventsBulkCreateResponseCreatedEventsItem>;
export type ThreatEventsBulkCreateResponseCreatedEventsList = Array<ThreatEventsBulkCreateResponseCreatedEventsItem>;
export declare const ThreatEventsBulkCreateResponseCreatedEventsList: S.Schema<ThreatEventsBulkCreateResponseCreatedEventsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface BulkCreateThreatEventsResponse {
    /** Number of events created */
    createdEventsCount: number;
    /** Number of new tags created in SoT */
    createdTagsCount: number;
    /** Number of errors encountered */
    errorCount: number;
    /** Number of indicators queued for async processing */
    queuedIndicatorsCount: number;
    /** Correlation ID for async indicator processing */
    createBulkEventsRequestId?: string | null;
    /** Array of created events with UUIDs and shard locations. Only present when includeCreatedEvents=true */
    createdEvents?: ThreatEventsBulkCreateResponseCreatedEventsList | null;
}
export declare const BulkCreateThreatEventsResponse: S.Schema<BulkCreateThreatEventsResponse>;
export interface CreateBinaryStorageRequest {
    /** Account ID. */
    accountId: string;
}
export declare const CreateBinaryStorageRequest: S.Schema<CreateBinaryStorageRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateBinaryStorageResponse {
    contentType: string;
    md5: string;
    sha1: string;
    sha256: string;
}
export declare const CreateBinaryStorageResponse: S.Schema<CreateBinaryStorageResponse>;
export type RequestsCreateRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsCreateRequestTlp: any;
export interface CreateRequestRequest {
    /** Identifier. */
    accountId: string;
    /** Request content. */
    content?: string;
    /** Priority for analyzing the request. */
    priority?: string;
    /** Requested information from request. */
    requestType?: string;
    /** Brief description of the request. */
    summary?: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp?: RequestsCreateRequestTlp | (string & {});
}
export declare const CreateRequestRequest: S.Schema<CreateRequestRequest>;
export type RequestsCreateResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsCreateResponseTlp: any;
export type RequestsCreateResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const RequestsCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRequestResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsCreateResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsCreateResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export declare const CreateRequestResponse: S.Schema<CreateRequestResponse>;
export interface CreateRequestAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Page number of results. */
    page: number;
    /** Number of results per page. */
    perPage: number;
}
export declare const CreateRequestAssetRequest: S.Schema<CreateRequestAssetRequest>;
export interface RequestsAssetsCreateResultItem {
    /** Asset ID. */
    id: number;
    /** Asset name. */
    name: string;
    /** Defines the asset creation time. */
    created?: string | null;
    /** Asset description. */
    description?: string | null;
    /** Asset file type. */
    fileType?: string | null;
}
export declare const RequestsAssetsCreateResultItem: S.Schema<RequestsAssetsCreateResultItem>;
export type RequestsAssetsCreateResultList = Array<RequestsAssetsCreateResultItem>;
export declare const RequestsAssetsCreateResultList: S.Schema<RequestsAssetsCreateResultList>;
export interface CreateRequestAssetResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RequestsAssetsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateRequestAssetResponse: S.Schema<CreateRequestAssetResponse>;
export interface CreateRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Content of message. */
    content?: string;
}
export declare const CreateRequestMessageRequest: S.Schema<CreateRequestMessageRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRequestMessageResponse {
    /** Message ID. */
    id: number;
    /** Author of message. */
    author: string;
    /** Content of message. */
    content: string;
    /** Whether the message is a follow-on request. */
    isFollowOnRequest: boolean;
    /** Defines the message last updated time. */
    updated: string;
    /** Defines the message creation time. */
    created?: string | null;
}
export declare const CreateRequestMessageResponse: S.Schema<CreateRequestMessageResponse>;
export type RequestsPriorityCreateRequestLabelsList = Array<unknown>;
export declare const RequestsPriorityCreateRequestLabelsList: S.Schema<RequestsPriorityCreateRequestLabelsList>;
export type RequestsPriorityCreateRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsPriorityCreateRequestTlp: any;
export interface CreateRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** List of labels. */
    labels: RequestsPriorityCreateRequestLabelsList;
    /** Priority. */
    priority: number;
    /** Requirement. */
    requirement: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityCreateRequestTlp | (string & {});
}
export declare const CreateRequestPriorityRequest: S.Schema<CreateRequestPriorityRequest>;
export type RequestsPriorityCreateResponseLabelsList = Array<unknown>;
export declare const RequestsPriorityCreateResponseLabelsList: S.Schema<RequestsPriorityCreateResponseLabelsList>;
export type RequestsPriorityCreateResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsPriorityCreateResponseTlp: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRequestPriorityResponse {
    /** UUID. */
    id: string;
    /** Priority creation time. */
    created: string;
    /** List of labels. */
    labels: RequestsPriorityCreateResponseLabelsList;
    /** Priority. */
    priority: number;
    /** Requirement. */
    requirement: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityCreateResponseTlp;
    /** Priority last updated time. */
    updated: string;
}
export declare const CreateRequestPriorityResponse: S.Schema<CreateRequestPriorityResponse>;
export type ScansConfigCreateRequestIpsList = Array<string>;
export declare const ScansConfigCreateRequestIpsList: S.Schema<ScansConfigCreateRequestIpsList>;
export type ScansConfigCreateRequestPortsList = Array<string>;
export declare const ScansConfigCreateRequestPortsList: S.Schema<ScansConfigCreateRequestPortsList>;
export interface CreateScanConfigRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigCreateRequestIpsList;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency?: number;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports?: ScansConfigCreateRequestPortsList;
}
export declare const CreateScanConfigRequest: S.Schema<CreateScanConfigRequest>;
export type ScansConfigCreateResponseIpsList = Array<string>;
export declare const ScansConfigCreateResponseIpsList: S.Schema<ScansConfigCreateResponseIpsList>;
export type ScansConfigCreateResponsePortsList = Array<string>;
export declare const ScansConfigCreateResponsePortsList: S.Schema<ScansConfigCreateResponsePortsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScanConfigResponse {
    /** Defines the Config ID. */
    id: string;
    accountId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigCreateResponseIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports: ScansConfigCreateResponsePortsList;
}
export declare const CreateScanConfigResponse: S.Schema<CreateScanConfigResponse>;
export type ThreatEventsCreateRequestRawDataMap = {
    [key: string]: unknown | undefined;
};
export declare const ThreatEventsCreateRequestRawDataMap: S.Schema<ThreatEventsCreateRequestRawDataMap>;
export interface ThreatEventsCreateRequestRaw {
    data: ThreatEventsCreateRequestRawDataMap;
    source?: string;
    tlp?: string;
}
export declare const ThreatEventsCreateRequestRaw: S.Schema<ThreatEventsCreateRequestRaw>;
export type ThreatEventsCreateRequestIndicatorsItem = ThreatEventsBulkCreateRequestDataItemIndicatorsItem;
export declare const ThreatEventsCreateRequestIndicatorsItem: S.Schema<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export type ThreatEventsCreateRequestIndicatorsList = Array<ThreatEventsBulkCreateRequestDataItemIndicatorsItem>;
export declare const ThreatEventsCreateRequestIndicatorsList: S.Schema<ThreatEventsCreateRequestIndicatorsList>;
export type ThreatEventsCreateRequestTagsList = Array<string>;
export declare const ThreatEventsCreateRequestTagsList: S.Schema<ThreatEventsCreateRequestTagsList>;
export interface CreateThreatEventRequest {
    /** Account ID. */
    accountId: string;
    category: string;
    date: string;
    event: string;
    raw: ThreatEventsCreateRequestRaw;
    tlp: string;
    attacker?: string;
    attackerCountry?: string;
    datasetId?: string;
    indicator?: string;
    /** Array of indicators for this event. Supports multiple indicators per event for complex scenarios. */
    indicators?: ThreatEventsCreateRequestIndicatorsList;
    indicatorType?: string;
    insight?: string;
    tags?: ThreatEventsCreateRequestTagsList;
    targetCountry?: string;
    targetIndustry?: string;
}
export declare const CreateThreatEventRequest: S.Schema<CreateThreatEventRequest>;
export type ThreatEventsCreateResponseMitreAttackList = Array<string>;
export declare const ThreatEventsCreateResponseMitreAttackList: S.Schema<ThreatEventsCreateResponseMitreAttackList>;
export type ThreatEventsCreateResponseMitreCapecList = Array<string>;
export declare const ThreatEventsCreateResponseMitreCapecList: S.Schema<ThreatEventsCreateResponseMitreCapecList>;
export type ThreatEventsCreateResponseReferencedList = Array<string>;
export declare const ThreatEventsCreateResponseReferencedList: S.Schema<ThreatEventsCreateResponseReferencedList>;
export type ThreatEventsCreateResponseReferencedIdsList = Array<number>;
export declare const ThreatEventsCreateResponseReferencedIdsList: S.Schema<ThreatEventsCreateResponseReferencedIdsList>;
export type ThreatEventsCreateResponseReferencesList = Array<string>;
export declare const ThreatEventsCreateResponseReferencesList: S.Schema<ThreatEventsCreateResponseReferencesList>;
export type ThreatEventsCreateResponseReferencesIdsList = Array<number>;
export declare const ThreatEventsCreateResponseReferencesIdsList: S.Schema<ThreatEventsCreateResponseReferencesIdsList>;
export type ThreatEventsCreateResponseTagsList = Array<string>;
export declare const ThreatEventsCreateResponseTagsList: S.Schema<ThreatEventsCreateResponseTagsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsCreateResponseMitreAttackList;
    mitreCapec: ThreatEventsCreateResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsCreateResponseReferencedList;
    referencedIds: ThreatEventsCreateResponseReferencedIdsList;
    references: ThreatEventsCreateResponseReferencesList;
    referencesIds: ThreatEventsCreateResponseReferencesIdsList;
    tags: ThreatEventsCreateResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export declare const CreateThreatEventResponse: S.Schema<CreateThreatEventResponse>;
export type ThreatEventsCategoriesCreateRequestMitreAttackList = Array<string>;
export declare const ThreatEventsCategoriesCreateRequestMitreAttackList: S.Schema<ThreatEventsCategoriesCreateRequestMitreAttackList>;
export type ThreatEventsCategoriesCreateRequestMitreCapecList = Array<string>;
export declare const ThreatEventsCategoriesCreateRequestMitreCapecList: S.Schema<ThreatEventsCategoriesCreateRequestMitreCapecList>;
export interface CreateThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    killChain: number;
    name: string;
    mitreAttack?: ThreatEventsCategoriesCreateRequestMitreAttackList;
    mitreCapec?: ThreatEventsCategoriesCreateRequestMitreCapecList;
    shortname?: string;
}
export declare const CreateThreatEventCategoryRequest: S.Schema<CreateThreatEventCategoryRequest>;
export type ThreatEventsCategoriesCreateResponseMitreAttackList = Array<string>;
export declare const ThreatEventsCategoriesCreateResponseMitreAttackList: S.Schema<ThreatEventsCategoriesCreateResponseMitreAttackList>;
export type ThreatEventsCategoriesCreateResponseMitreCapecList = Array<string>;
export declare const ThreatEventsCategoriesCreateResponseMitreCapecList: S.Schema<ThreatEventsCategoriesCreateResponseMitreCapecList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventCategoryResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesCreateResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesCreateResponseMitreCapecList | null;
    shortname?: string | null;
}
export declare const CreateThreatEventCategoryResponse: S.Schema<CreateThreatEventCategoryResponse>;
export interface CreateThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** If true, then anyone can search the dataset. If false, then its limited to the account. */
    isPublic: boolean;
    /** Used to describe the dataset within the account context. */
    name: string;
}
export declare const CreateThreatEventDatasetRequest: S.Schema<CreateThreatEventDatasetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventDatasetResponse {
    isPublic: boolean;
    name: string;
    uuid: string;
    deletedAt?: string | null;
}
export declare const CreateThreatEventDatasetResponse: S.Schema<CreateThreatEventDatasetResponse>;
export type ThreatEventsEventTagsCreateRequestTagsList = Array<string>;
export declare const ThreatEventsEventTagsCreateRequestTagsList: S.Schema<ThreatEventsEventTagsCreateRequestTagsList>;
export interface CreateThreatEventEventTagRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    tags: ThreatEventsEventTagsCreateRequestTagsList;
}
export declare const CreateThreatEventEventTagRequest: S.Schema<CreateThreatEventEventTagRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateThreatEventEventTagResponse {
    success: boolean;
}
export declare const CreateThreatEventEventTagResponse: S.Schema<CreateThreatEventEventTagResponse>;
export type ThreatEventsTagsCreateRequestAliasesItemTlp = "red" | "amber" | "green" | "white";
export declare const ThreatEventsTagsCreateRequestAliasesItemTlp: any;
export interface ThreatEventsTagsCreateRequestAliasesItem {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestAliasesItemTlp | (string & {});
}
export declare const ThreatEventsTagsCreateRequestAliasesItem: S.Schema<ThreatEventsTagsCreateRequestAliasesItem>;
export type ThreatEventsTagsCreateRequestAliasesList = Array<ThreatEventsTagsCreateRequestAliasesItem>;
export declare const ThreatEventsTagsCreateRequestAliasesList: S.Schema<ThreatEventsTagsCreateRequestAliasesList>;
export type ThreatEventsTagsCreateRequestAliasGroupNamesList = Array<string>;
export declare const ThreatEventsTagsCreateRequestAliasGroupNamesList: S.Schema<ThreatEventsTagsCreateRequestAliasGroupNamesList>;
export type ThreatEventsTagsCreateRequestAliasGroupNamesInternalList = Array<string>;
export declare const ThreatEventsTagsCreateRequestAliasGroupNamesInternalList: S.Schema<ThreatEventsTagsCreateRequestAliasGroupNamesInternalList>;
export type ThreatEventsTagsCreateRequestExternalReferenceLinksList = Array<string>;
export declare const ThreatEventsTagsCreateRequestExternalReferenceLinksList: S.Schema<ThreatEventsTagsCreateRequestExternalReferenceLinksList>;
export interface ThreatEventsTagsCreateRequestExternalReferencesItem {
    url: string;
    description?: string;
}
export declare const ThreatEventsTagsCreateRequestExternalReferencesItem: S.Schema<ThreatEventsTagsCreateRequestExternalReferencesItem>;
export type ThreatEventsTagsCreateRequestExternalReferencesList = Array<ThreatEventsTagsCreateRequestExternalReferencesItem>;
export declare const ThreatEventsTagsCreateRequestExternalReferencesList: S.Schema<ThreatEventsTagsCreateRequestExternalReferencesList>;
export type ThreatEventsTagsCreateRequestInternalAliasesItemTlp = "red" | "amber" | "green" | "white";
export declare const ThreatEventsTagsCreateRequestInternalAliasesItemTlp: any;
export interface ThreatEventsTagsCreateRequestInternalAliasesItem {
    value: string;
    confidence?: number;
    tlp?: ThreatEventsTagsCreateRequestInternalAliasesItemTlp | (string & {});
}
export declare const ThreatEventsTagsCreateRequestInternalAliasesItem: S.Schema<ThreatEventsTagsCreateRequestInternalAliasesItem>;
export type ThreatEventsTagsCreateRequestInternalAliasesList = Array<ThreatEventsTagsCreateRequestInternalAliasesItem>;
export declare const ThreatEventsTagsCreateRequestInternalAliasesList: S.Schema<ThreatEventsTagsCreateRequestInternalAliasesList>;
export type ThreatEventsTagsCreateRequestOriginCountryTlp = "red" | "amber" | "green" | "white";
export declare const ThreatEventsTagsCreateRequestOriginCountryTlp: any;
export interface CreateThreatEventTagRequest {
    /** Account ID. */
    accountId: string;
    value: string;
    activeDuration?: string;
    /** Actor variety. Allowed values: Activist, Competitor, Customer, Crime Syndicate, Former Employee, Nation State, Organized Crime, Nation State Affiliated, Terrorist, Unaffiliated. */
    actorCategory?: string;
    /** Confidence (1-10) in the actor variety (actorCategory). CFONE-only: stripped from responses to non-CFONE accounts. */
    actorCategoryConfidence?: number;
    /** Structured aliases ({ value, confidence 1-10, tlp }). CFONE-only: stripped from responses to non-CFONE accounts. */
    aliases?: ThreatEventsTagsCreateRequestAliasesList;
    aliasGroupNames?: ThreatEventsTagsCreateRequestAliasGroupNamesList;
    aliasGroupNamesInternal?: ThreatEventsTagsCreateRequestAliasGroupNamesInternalList;
    analyticPriority?: number;
    attributionConfidence?: string;
    attributionConfidenceScore?: number;
    attributionOrganization?: string;
    categoryUuid?: string;
    /** Date the actor was discovered (ISO YYYY-MM-DD). */
    dateOfDiscovery?: string;
    externalReferenceLinks?: ThreatEventsTagsCreateRequestExternalReferenceLinksList;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: ThreatEventsTagsCreateRequestExternalReferencesList;
    /** Internal structured aliases ({ value, confidence 1-10, tlp }). CFONE-only: never returned to non-CFONE accounts. */
    internalAliases?: ThreatEventsTagsCreateRequestInternalAliasesList;
    internalDescription?: string;
    /** Actor motive. Allowed values: Convenience, Fear, Fun, Financial, Grudge, Ideology, Espionage. */
    motive?: string;
    /** Confidence (1-10) in the actor motive. CFONE-only: stripped from responses to non-CFONE accounts. */
    motiveConfidence?: number;
    opsecLevel?: string;
    /** Confidence (1-10) in the origin-country attribution. CFONE-only: stripped from responses to non-CFONE accounts. */
    originCountryConfidence?: number;
    originCountryISO?: string;
    /** TLP marking for the origin-country attribution. CFONE-only: stripped from responses to non-CFONE accounts. */
    originCountryTlp?: ThreatEventsTagsCreateRequestOriginCountryTlp | (string & {});
    priority?: number;
    sophisticationLevel?: string;
}
export declare const CreateThreatEventTagRequest: S.Schema<CreateThreatEventTagRequest>;
export type ThreatEventsTagsCreateResponseAliasesItemTlp = "red" | "amber" | "green" | "white";
export declare const ThreatEventsTagsCreateResponseAliasesItemTlp: any;
export interface ThreatEventsTagsCreateResponseAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseAliasesItemTlp | null;
}
export declare const ThreatEventsTagsCreateResponseAliasesItem: S.Schema<ThreatEventsTagsCreateResponseAliasesItem>;
export type ThreatEventsTagsCreateResponseAliasesList = Array<ThreatEventsTagsCreateResponseAliasesItem>;
export declare const ThreatEventsTagsCreateResponseAliasesList: S.Schema<ThreatEventsTagsCreateResponseAliasesList>;
export type ThreatEventsTagsCreateResponseAliasGroupNamesList = Array<string>;
export declare const ThreatEventsTagsCreateResponseAliasGroupNamesList: S.Schema<ThreatEventsTagsCreateResponseAliasGroupNamesList>;
export type ThreatEventsTagsCreateResponseAliasGroupNamesInternalList = Array<string>;
export declare const ThreatEventsTagsCreateResponseAliasGroupNamesInternalList: S.Schema<ThreatEventsTagsCreateResponseAliasGroupNamesInternalList>;
export type ThreatEventsTagsCreateResponseExternalReferenceLinksList = Array<string>;
export declare const ThreatEventsTagsCreateResponseExternalReferenceLinksList: S.Schema<ThreatEventsTagsCreateResponseExternalReferenceLinksList>;
export interface ThreatEventsTagsCreateResponseExternalReferencesItem {
    url: string;
    description?: string | null;
}
export declare const ThreatEventsTagsCreateResponseExternalReferencesItem: S.Schema<ThreatEventsTagsCreateResponseExternalReferencesItem>;
export type ThreatEventsTagsCreateResponseExternalReferencesList = Array<ThreatEventsTagsCreateResponseExternalReferencesItem>;
export declare const ThreatEventsTagsCreateResponseExternalReferencesList: S.Schema<ThreatEventsTagsCreateResponseExternalReferencesList>;
export type ThreatEventsTagsCreateResponseInternalAliasesItemTlp = "red" | "amber" | "green" | "white";
export declare const ThreatEventsTagsCreateResponseInternalAliasesItemTlp: any;
export interface ThreatEventsTagsCreateResponseInternalAliasesItem {
    value: string;
    confidence?: number | null;
    tlp?: ThreatEventsTagsCreateResponseInternalAliasesItemTlp | null;
}
export declare const ThreatEventsTagsCreateResponseInternalAliasesItem: S.Schema<ThreatEventsTagsCreateResponseInternalAliasesItem>;
export type ThreatEventsTagsCreateResponseInternalAliasesList = Array<ThreatEventsTagsCreateResponseInternalAliasesItem>;
export declare const ThreatEventsTagsCreateResponseInternalAliasesList: S.Schema<ThreatEventsTagsCreateResponseInternalAliasesList>;
export type ThreatEventsTagsCreateResponseOriginCountryTlp = "red" | "amber" | "green" | "white";
export declare const ThreatEventsTagsCreateResponseOriginCountryTlp: any;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateThreatEventTagResponse {
    uuid: string;
    value: string;
    activeDuration?: string | null;
    actorCategory?: string | null;
    /** Confidence (1-10) in the actor variety (actorCategory). CFONE-only: stripped from responses to non-CFONE accounts. */
    actorCategoryConfidence?: number | null;
    /** Structured aliases ({ value, confidence 1-10, tlp }). CFONE-only: stripped from responses to non-CFONE accounts. */
    aliases?: ThreatEventsTagsCreateResponseAliasesList | null;
    aliasGroupNames?: ThreatEventsTagsCreateResponseAliasGroupNamesList | null;
    aliasGroupNamesInternal?: ThreatEventsTagsCreateResponseAliasGroupNamesInternalList | null;
    analyticPriority?: number | null;
    attributionConfidence?: string | null;
    attributionConfidenceScore?: number | null;
    attributionOrganization?: string | null;
    categoryName?: string | null;
    categoryUuid?: string | null;
    dateOfDiscovery?: string | null;
    externalReferenceLinks?: ThreatEventsTagsCreateResponseExternalReferenceLinksList | null;
    /** Structured external references ({ url, description }). Public: returned to all accounts. */
    externalReferences?: ThreatEventsTagsCreateResponseExternalReferencesList | null;
    /** Internal structured aliases ({ value, confidence 1-10, tlp }). CFONE-only: never returned to non-CFONE accounts. */
    internalAliases?: ThreatEventsTagsCreateResponseInternalAliasesList | null;
    internalDescription?: string | null;
    motive?: string | null;
    /** Confidence (1-10) in the actor motive. CFONE-only: stripped from responses to non-CFONE accounts. */
    motiveConfidence?: number | null;
    opsecLevel?: string | null;
    /** Confidence (1-10) in the origin-country attribution. CFONE-only: stripped from responses to non-CFONE accounts. */
    originCountryConfidence?: number | null;
    originCountryISO?: string | null;
    originCountryISOAlpha3?: string | null;
    /** TLP marking for the origin-country attribution. CFONE-only: stripped from responses to non-CFONE accounts. */
    originCountryTlp?: ThreatEventsTagsCreateResponseOriginCountryTlp | null;
    priority?: number | null;
    sophisticationLevel?: string | null;
}
export declare const CreateThreatEventTagResponse: S.Schema<CreateThreatEventTagResponse>;
export interface DeleteRequestRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
}
export declare const DeleteRequestRequest: S.Schema<DeleteRequestRequest>;
export interface DeleteRequestResponse {
}
export declare const DeleteRequestResponse: S.Schema<DeleteRequestResponse>;
export interface DeleteRequestAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** UUID. */
    assetId: string;
}
export declare const DeleteRequestAssetRequest: S.Schema<DeleteRequestAssetRequest>;
export interface DeleteRequestAssetResponse {
}
export declare const DeleteRequestAssetResponse: S.Schema<DeleteRequestAssetResponse>;
export interface DeleteRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    messageId: number;
}
export declare const DeleteRequestMessageRequest: S.Schema<DeleteRequestMessageRequest>;
export interface DeleteRequestMessageResponse {
}
export declare const DeleteRequestMessageResponse: S.Schema<DeleteRequestMessageResponse>;
export interface DeleteRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    priorityId: string;
}
export declare const DeleteRequestPriorityRequest: S.Schema<DeleteRequestPriorityRequest>;
export interface DeleteRequestPriorityResponse {
}
export declare const DeleteRequestPriorityResponse: S.Schema<DeleteRequestPriorityResponse>;
export interface DeleteScanConfigRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines the Config ID. */
    configId: string;
}
export declare const DeleteScanConfigRequest: S.Schema<DeleteScanConfigRequest>;
export type DeleteScanConfigResponse = unknown;
export declare const DeleteScanConfigResponse: S.Schema<DeleteScanConfigResponse>;
export interface DeleteThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Category UUID. */
    categoryId: string;
}
export declare const DeleteThreatEventCategoryRequest: S.Schema<DeleteThreatEventCategoryRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteThreatEventCategoryResponse {
    uuid: string;
}
export declare const DeleteThreatEventCategoryResponse: S.Schema<DeleteThreatEventCategoryResponse>;
export interface DeleteThreatEventEventTagRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
}
export declare const DeleteThreatEventEventTagRequest: S.Schema<DeleteThreatEventEventTagRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatEventEventTagResponse {
    success: boolean;
}
export declare const DeleteThreatEventEventTagResponse: S.Schema<DeleteThreatEventEventTagResponse>;
export interface DeleteThreatEventRelateRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
}
export declare const DeleteThreatEventRelateRequest: S.Schema<DeleteThreatEventRelateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteThreatEventRelateResponse {
    success: boolean;
}
export declare const DeleteThreatEventRelateResponse: S.Schema<DeleteThreatEventRelateResponse>;
export interface GetBinaryStorageRequest {
    /** Account ID. */
    accountId: string;
    /** hash of the binary */
    hash: string;
}
export declare const GetBinaryStorageRequest: S.Schema<GetBinaryStorageRequest>;
export interface GetBinaryStorageResponse {
}
export declare const GetBinaryStorageResponse: S.Schema<GetBinaryStorageResponse>;
export interface GetRequestRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
}
export declare const GetRequestRequest: S.Schema<GetRequestRequest>;
export type RequestsGetResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsGetResponseTlp: any;
export type RequestsGetResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const RequestsGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRequestResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsGetResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsGetResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export declare const GetRequestResponse: S.Schema<GetRequestResponse>;
export type RequestsMessageGetRequestSortOrder = "asc" | "desc";
export declare const RequestsMessageGetRequestSortOrder: any;
export interface GetRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Page number of results. */
    page: number;
    /** Number of results per page. */
    perPage: number;
    /** Retrieve mes ges created after this time. */
    after?: string;
    /** Retrieve messages created before this time. */
    before?: string;
    /** Field to sort results by. */
    sortBy?: string;
    /** Sort order (asc or desc). */
    sortOrder?: RequestsMessageGetRequestSortOrder | (string & {});
}
export declare const GetRequestMessageRequest: S.Schema<GetRequestMessageRequest>;
export interface RequestsMessageGetResultItem {
    /** Message ID. */
    id: number;
    /** Author of message. */
    author: string;
    /** Content of message. */
    content: string;
    /** Whether the message is a follow-on request. */
    isFollowOnRequest: boolean;
    /** Defines the message last updated time. */
    updated: string;
    /** Defines the message creation time. */
    created?: string | null;
}
export declare const RequestsMessageGetResultItem: S.Schema<RequestsMessageGetResultItem>;
export type RequestsMessageGetResultList = Array<RequestsMessageGetResultItem>;
export declare const RequestsMessageGetResultList: S.Schema<RequestsMessageGetResultList>;
export interface GetRequestMessageResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RequestsMessageGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetRequestMessageResponse: S.Schema<GetRequestMessageResponse>;
export interface GetRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    priorityId: string;
}
export declare const GetRequestPriorityRequest: S.Schema<GetRequestPriorityRequest>;
export type RequestsPriorityGetResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsPriorityGetResponseTlp: any;
export type RequestsPriorityGetResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const RequestsPriorityGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRequestPriorityResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityGetResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsPriorityGetResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export declare const GetRequestPriorityResponse: S.Schema<GetRequestPriorityResponse>;
export interface GetRequestsAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** UUID. */
    assetId: string;
}
export declare const GetRequestsAssetRequest: S.Schema<GetRequestsAssetRequest>;
export type GetRequestsAssetResultItem = RequestsAssetsCreateResultItem;
export declare const GetRequestsAssetResultItem: S.Schema<RequestsAssetsCreateResultItem>;
export type GetRequestsAssetResultList = Array<RequestsAssetsCreateResultItem>;
export declare const GetRequestsAssetResultList: S.Schema<GetRequestsAssetResultList>;
export type GetRequestsAssetResponse = GetRequestsAssetResultList;
export declare const GetRequestsAssetResponse: S.Schema<GetRequestsAssetResponse>;
export interface GetScanResultRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines the Config ID. */
    configId: string;
}
export declare const GetScanResultRequest: S.Schema<GetScanResultRequest>;
export interface ScansResultsGetResponse1111Item {
    number?: number | null;
    proto?: string | null;
    status?: string | null;
}
export declare const ScansResultsGetResponse1111Item: S.Schema<ScansResultsGetResponse1111Item>;
export type ScansResultsGetResponse1111List = Array<ScansResultsGetResponse1111Item>;
export declare const ScansResultsGetResponse1111List: S.Schema<ScansResultsGetResponse1111List>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScanResultResponse {
    "1_1_1_1": ScansResultsGetResponse1111List;
}
export declare const GetScanResultResponse: S.Schema<GetScanResultResponse>;
export interface GetThreatEventRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
}
export declare const GetThreatEventRequest: S.Schema<GetThreatEventRequest>;
export type ThreatEventsGetResponseMitreAttackList = Array<string>;
export declare const ThreatEventsGetResponseMitreAttackList: S.Schema<ThreatEventsGetResponseMitreAttackList>;
export type ThreatEventsGetResponseMitreCapecList = Array<string>;
export declare const ThreatEventsGetResponseMitreCapecList: S.Schema<ThreatEventsGetResponseMitreCapecList>;
export type ThreatEventsGetResponseReferencedList = Array<string>;
export declare const ThreatEventsGetResponseReferencedList: S.Schema<ThreatEventsGetResponseReferencedList>;
export type ThreatEventsGetResponseReferencedIdsList = Array<number>;
export declare const ThreatEventsGetResponseReferencedIdsList: S.Schema<ThreatEventsGetResponseReferencedIdsList>;
export type ThreatEventsGetResponseReferencesList = Array<string>;
export declare const ThreatEventsGetResponseReferencesList: S.Schema<ThreatEventsGetResponseReferencesList>;
export type ThreatEventsGetResponseReferencesIdsList = Array<number>;
export declare const ThreatEventsGetResponseReferencesIdsList: S.Schema<ThreatEventsGetResponseReferencesIdsList>;
export type ThreatEventsGetResponseTagsList = Array<string>;
export declare const ThreatEventsGetResponseTagsList: S.Schema<ThreatEventsGetResponseTagsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsGetResponseMitreAttackList;
    mitreCapec: ThreatEventsGetResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsGetResponseReferencedList;
    referencedIds: ThreatEventsGetResponseReferencedIdsList;
    references: ThreatEventsGetResponseReferencesList;
    referencesIds: ThreatEventsGetResponseReferencesIdsList;
    tags: ThreatEventsGetResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export declare const GetThreatEventResponse: S.Schema<GetThreatEventResponse>;
export interface GetThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Category UUID. */
    categoryId: string;
}
export declare const GetThreatEventCategoryRequest: S.Schema<GetThreatEventCategoryRequest>;
export type ThreatEventsCategoriesGetResponseMitreAttackList = Array<string>;
export declare const ThreatEventsCategoriesGetResponseMitreAttackList: S.Schema<ThreatEventsCategoriesGetResponseMitreAttackList>;
export type ThreatEventsCategoriesGetResponseMitreCapecList = Array<string>;
export declare const ThreatEventsCategoriesGetResponseMitreCapecList: S.Schema<ThreatEventsCategoriesGetResponseMitreCapecList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventCategoryResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesGetResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesGetResponseMitreCapecList | null;
    shortname?: string | null;
}
export declare const GetThreatEventCategoryResponse: S.Schema<GetThreatEventCategoryResponse>;
export interface GetThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
}
export declare const GetThreatEventDatasetRequest: S.Schema<GetThreatEventDatasetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventDatasetResponse {
    isPublic: boolean;
    name: string;
    uuid: string;
    deletedAt?: string | null;
}
export declare const GetThreatEventDatasetResponse: S.Schema<GetThreatEventDatasetResponse>;
export interface GetThreatEventRawRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** Raw Event UUID. */
    rawId: string;
}
export declare const GetThreatEventRawRequest: S.Schema<GetThreatEventRawRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetThreatEventRawResponse {
    id: string;
    accountId: number;
    created: string;
    data: unknown;
    source: string;
    tlp: string;
}
export declare const GetThreatEventRawResponse: S.Schema<GetThreatEventRawResponse>;
export type ListRequestsRequestSortOrder = "asc" | "desc";
export declare const ListRequestsRequestSortOrder: any;
export type ListRequestsRequestStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const ListRequestsRequestStatus: any;
export interface ListRequestsRequest {
    /** Identifier. */
    accountId: string;
    /** Page number of results. */
    page: number;
    /** Number of results per page. */
    perPage: number;
    /** Retrieve requests completed after this time. */
    completedAfter?: string;
    /** Retrieve requests completed before this time. */
    completedBefore?: string;
    /** Retrieve requests created after this time. */
    createdAfter?: string;
    /** Retrieve requests created before this time. */
    createdBefore?: string;
    /** Requested information from request. */
    requestType?: string;
    /** Field to sort results by. */
    sortBy?: string;
    /** Sort order (asc or desc). */
    sortOrder?: ListRequestsRequestSortOrder | (string & {});
    /** Request Status. */
    status?: ListRequestsRequestStatus | (string & {});
}
export declare const ListRequestsRequest: S.Schema<ListRequestsRequest>;
export type ListRequestsResultItemPriority = "routine" | "high" | "urgent";
export declare const ListRequestsResultItemPriority: any;
export type ListRequestsResultItemTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const ListRequestsResultItemTlp: any;
export type ListRequestsResultItemStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const ListRequestsResultItemStatus: any;
export interface ListRequestsResultItem {
    /** UUID. */
    id: string;
    /** Request creation time. */
    created: string;
    priority: ListRequestsResultItemPriority;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: ListRequestsResultItemTlp;
    /** Request last updated time. */
    updated: string;
    /** Request completion time. */
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: ListRequestsResultItemStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export declare const ListRequestsResultItem: S.Schema<ListRequestsResultItem>;
export type ListRequestsResultList = Array<ListRequestsResultItem>;
export declare const ListRequestsResultList: S.Schema<ListRequestsResultList>;
export type ListRequestsResponse = ListRequestsResultList;
export declare const ListRequestsResponse: S.Schema<ListRequestsResponse>;
export interface ListScanConfigsRequest {
    /** Defines the Account ID. */
    accountId: string;
}
export declare const ListScanConfigsRequest: S.Schema<ListScanConfigsRequest>;
export type ScansConfigListResultItemIpsList = Array<string>;
export declare const ScansConfigListResultItemIpsList: S.Schema<ScansConfigListResultItemIpsList>;
export type ScansConfigListResultItemPortsList = Array<string>;
export declare const ScansConfigListResultItemPortsList: S.Schema<ScansConfigListResultItemPortsList>;
export interface ScansConfigListResultItem {
    /** Defines the Config ID. */
    id: string;
    accountId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigListResultItemIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports: ScansConfigListResultItemPortsList;
}
export declare const ScansConfigListResultItem: S.Schema<ScansConfigListResultItem>;
export type ScansConfigListResultList = Array<ScansConfigListResultItem>;
export declare const ScansConfigListResultList: S.Schema<ScansConfigListResultList>;
export interface ListScanConfigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScansConfigListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListScanConfigsResponse: S.Schema<ListScanConfigsResponse>;
export type ThreatEventsAttackersListRequestDatasetIdsList = Array<string>;
export declare const ThreatEventsAttackersListRequestDatasetIdsList: S.Schema<ThreatEventsAttackersListRequestDatasetIdsList>;
export interface ListThreatEventAttackersRequest {
    /** Account ID. */
    accountId: string;
    /** Array of dataset IDs to query attackers from. If not provided, uses the default dataset. */
    datasetIds?: ThreatEventsAttackersListRequestDatasetIdsList;
}
export declare const ListThreatEventAttackersRequest: S.Schema<ListThreatEventAttackersRequest>;
export interface ThreatEventsAttackersListResponseItems {
    type: string;
}
export declare const ThreatEventsAttackersListResponseItems: S.Schema<ThreatEventsAttackersListResponseItems>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventAttackersResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export declare const ListThreatEventAttackersResponse: S.Schema<ListThreatEventAttackersResponse>;
export type ThreatEventsCategoriesListRequestDatasetIdsList = Array<string>;
export declare const ThreatEventsCategoriesListRequestDatasetIdsList: S.Schema<ThreatEventsCategoriesListRequestDatasetIdsList>;
export interface ListThreatEventCategoriesRequest {
    /** Account ID. */
    accountId: string;
    /** Array of dataset IDs to query categories from. If not provided, uses the default dataset. */
    datasetIds?: ThreatEventsCategoriesListRequestDatasetIdsList;
}
export declare const ListThreatEventCategoriesRequest: S.Schema<ListThreatEventCategoriesRequest>;
export type ThreatEventsCategoriesListResponseMitreAttackList = Array<string>;
export declare const ThreatEventsCategoriesListResponseMitreAttackList: S.Schema<ThreatEventsCategoriesListResponseMitreAttackList>;
export type ThreatEventsCategoriesListResponseMitreCapecList = Array<string>;
export declare const ThreatEventsCategoriesListResponseMitreCapecList: S.Schema<ThreatEventsCategoriesListResponseMitreCapecList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventCategoriesResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesListResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesListResponseMitreCapecList | null;
    shortname?: string | null;
}
export declare const ListThreatEventCategoriesResponse: S.Schema<ListThreatEventCategoriesResponse>;
export interface ListThreatEventCountriesRequest {
    /** Account ID. */
    accountId: string;
}
export declare const ListThreatEventCountriesRequest: S.Schema<ListThreatEventCountriesRequest>;
export interface ThreatEventsCountriesListResultItem {
    alpha2: string;
    alpha3: string;
    name: string;
}
export declare const ThreatEventsCountriesListResultItem: S.Schema<ThreatEventsCountriesListResultItem>;
export type ThreatEventsCountriesListResultList = Array<ThreatEventsCountriesListResultItem>;
export declare const ThreatEventsCountriesListResultList: S.Schema<ThreatEventsCountriesListResultList>;
export type ListThreatEventCountriesResponse = ThreatEventsCountriesListResultList;
export declare const ListThreatEventCountriesResponse: S.Schema<ListThreatEventCountriesResponse>;
export interface ListThreatEventDatasetsRequest {
    /** Account ID. */
    accountId: string;
    /** When true, include soft-deleted datasets in the response. Each item includes a `deletedAt` field (ISO 8601 or null). Default: false. */
    includeDeleted?: boolean;
}
export declare const ListThreatEventDatasetsRequest: S.Schema<ListThreatEventDatasetsRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventDatasetsResponse {
    isPublic: boolean;
    name: string;
    uuid: string;
    deletedAt?: string | null;
}
export declare const ListThreatEventDatasetsResponse: S.Schema<ListThreatEventDatasetsResponse>;
export interface ListThreatEventIndicatorTypesRequest {
    /** Account ID. */
    accountId: string;
}
export declare const ListThreatEventIndicatorTypesRequest: S.Schema<ListThreatEventIndicatorTypesRequest>;
export type ThreatEventsIndicatorTypesListResponseItems = ThreatEventsAttackersListResponseItems;
export declare const ThreatEventsIndicatorTypesListResponseItems: S.Schema<ThreatEventsAttackersListResponseItems>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventIndicatorTypesResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export declare const ListThreatEventIndicatorTypesResponse: S.Schema<ListThreatEventIndicatorTypesResponse>;
export type ThreatEventsListRequestDatasetIdList = Array<string>;
export declare const ThreatEventsListRequestDatasetIdList: S.Schema<ThreatEventsListRequestDatasetIdList>;
export type ThreatEventsListRequestFormat = "json" | "stix2" | "taxii";
export declare const ThreatEventsListRequestFormat: any;
export type ThreatEventsListRequestOrder = "asc" | "desc";
export declare const ThreatEventsListRequestOrder: any;
export type ThreatEventsListRequestSearchList = Array<string>;
export declare const ThreatEventsListRequestSearchList: S.Schema<ThreatEventsListRequestSearchList>;
export type ThreatEventsListRequestSource = "do" | "r2catalog";
export declare const ThreatEventsListRequestSource: any;
export interface ListThreatEventsRequest {
    /** Account ID. */
    accountId: string;
    /** Cursor for pagination. When provided, filters are embedded in the cursor so you only need to pass cursor and pageSize. Returned in the previous response's result_info.cursor field. Use cursor-based pagination for deep pagination (beyond 100,000 records) or for optimal performance. */
    cursor?: string;
    /** Dataset IDs to query events from (array of UUIDs), or special value 'all' or '*' to query all event datasets for the account. If not provided, uses the default dataset. */
    datasetId?: ThreatEventsListRequestDatasetIdList;
    forceRefresh?: boolean;
    format?: ThreatEventsListRequestFormat | (string & {});
    order?: ThreatEventsListRequestOrder | (string & {});
    orderBy?: string;
    /** Page number (1-indexed) for offset-based pagination. Limited to offset of 100,000 records. For deep pagination, use cursor-based pagination instead. */
    page?: number;
    /** Number of results per page. Maximum 25,000. */
    pageSize?: number;
    search?: ThreatEventsListRequestSearchList;
    /** Read backend. 'do' (default) reads Durable Object storage. 'r2catalog' reads R2 Data Catalog (admin-only, experimental; supports a subset of search fields — no 'tags'). */
    source?: ThreatEventsListRequestSource | (string & {});
}
export declare const ListThreatEventsRequest: S.Schema<ListThreatEventsRequest>;
export type ThreatEventsListResponseMitreAttackList = Array<string>;
export declare const ThreatEventsListResponseMitreAttackList: S.Schema<ThreatEventsListResponseMitreAttackList>;
export type ThreatEventsListResponseMitreCapecList = Array<string>;
export declare const ThreatEventsListResponseMitreCapecList: S.Schema<ThreatEventsListResponseMitreCapecList>;
export type ThreatEventsListResponseReferencedList = Array<string>;
export declare const ThreatEventsListResponseReferencedList: S.Schema<ThreatEventsListResponseReferencedList>;
export type ThreatEventsListResponseReferencedIdsList = Array<number>;
export declare const ThreatEventsListResponseReferencedIdsList: S.Schema<ThreatEventsListResponseReferencedIdsList>;
export type ThreatEventsListResponseReferencesList = Array<string>;
export declare const ThreatEventsListResponseReferencesList: S.Schema<ThreatEventsListResponseReferencesList>;
export type ThreatEventsListResponseReferencesIdsList = Array<number>;
export declare const ThreatEventsListResponseReferencesIdsList: S.Schema<ThreatEventsListResponseReferencesIdsList>;
export type ThreatEventsListResponseTagsList = Array<string>;
export declare const ThreatEventsListResponseTagsList: S.Schema<ThreatEventsListResponseTagsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventsResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsListResponseMitreAttackList;
    mitreCapec: ThreatEventsListResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsListResponseReferencedList;
    referencedIds: ThreatEventsListResponseReferencedIdsList;
    references: ThreatEventsListResponseReferencesList;
    referencesIds: ThreatEventsListResponseReferencesIdsList;
    tags: ThreatEventsListResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export declare const ListThreatEventsResponse: S.Schema<ListThreatEventsResponse>;
export type ThreatEventsTargetIndustriesListRequestDatasetIdsList = Array<string>;
export declare const ThreatEventsTargetIndustriesListRequestDatasetIdsList: S.Schema<ThreatEventsTargetIndustriesListRequestDatasetIdsList>;
export interface ListThreatEventTargetIndustriesRequest {
    /** Account ID. */
    accountId: string;
    /** Array of dataset IDs to query target industries from. If not provided, uses the default dataset. */
    datasetIds?: ThreatEventsTargetIndustriesListRequestDatasetIdsList;
}
export declare const ListThreatEventTargetIndustriesRequest: S.Schema<ListThreatEventTargetIndustriesRequest>;
export type ThreatEventsTargetIndustriesListResponseItems = ThreatEventsAttackersListResponseItems;
export declare const ThreatEventsTargetIndustriesListResponseItems: S.Schema<ThreatEventsAttackersListResponseItems>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListThreatEventTargetIndustriesResponse {
    items: ThreatEventsAttackersListResponseItems;
    type: string;
}
export declare const ListThreatEventTargetIndustriesResponse: S.Schema<ListThreatEventTargetIndustriesResponse>;
export type ScansConfigEditRequestIpsList = Array<string>;
export declare const ScansConfigEditRequestIpsList: S.Schema<ScansConfigEditRequestIpsList>;
export type ScansConfigEditRequestPortsList = Array<string>;
export declare const ScansConfigEditRequestPortsList: S.Schema<ScansConfigEditRequestPortsList>;
export interface PatchScanConfigRequest {
    /** Defines the Account ID. */
    accountId: string;
    /** Defines the Config ID. */
    configId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency?: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips?: ScansConfigEditRequestIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports?: ScansConfigEditRequestPortsList;
}
export declare const PatchScanConfigRequest: S.Schema<PatchScanConfigRequest>;
export type ScansConfigEditResponseIpsList = Array<string>;
export declare const ScansConfigEditResponseIpsList: S.Schema<ScansConfigEditResponseIpsList>;
export type ScansConfigEditResponsePortsList = Array<string>;
export declare const ScansConfigEditResponsePortsList: S.Schema<ScansConfigEditResponsePortsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchScanConfigResponse {
    /** Defines the Config ID. */
    id: string;
    accountId: string;
    /** Defines the number of days between each scan (0 = One-off scan). */
    frequency: number;
    /** Defines a list of IP addresses or CIDR blocks to scan. The maximum number of total IP addresses allowed is 5000. */
    ips: ScansConfigEditResponseIpsList;
    /** Defines a list of ports to scan. Valid values are:"default", "all", or a comma-separated list of ports or range of ports (e.g. ["1-80", "443"]). "default" scans the 100 most commonly open ports. */
    ports: ScansConfigEditResponsePortsList;
}
export declare const PatchScanConfigResponse: S.Schema<PatchScanConfigResponse>;
export type ThreatEventsEditRequestRawDataMap = {
    [key: string]: unknown | undefined;
};
export declare const ThreatEventsEditRequestRawDataMap: S.Schema<ThreatEventsEditRequestRawDataMap>;
export interface ThreatEventsEditRequestRaw {
    data?: ThreatEventsEditRequestRawDataMap;
    source?: string;
    tlp?: string;
}
export declare const ThreatEventsEditRequestRaw: S.Schema<ThreatEventsEditRequestRaw>;
export interface PatchThreatEventRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** Dataset ID containing the event to update. */
    datasetId: string;
    attacker?: string;
    attackerCountry?: string;
    category?: string;
    createdAt?: string;
    date?: string;
    event?: string;
    indicator?: string;
    indicatorType?: string;
    insight?: string;
    raw?: ThreatEventsEditRequestRaw;
    targetCountry?: string;
    targetIndustry?: string;
    tlp?: string;
}
export declare const PatchThreatEventRequest: S.Schema<PatchThreatEventRequest>;
export type ThreatEventsEditResponseMitreAttackList = Array<string>;
export declare const ThreatEventsEditResponseMitreAttackList: S.Schema<ThreatEventsEditResponseMitreAttackList>;
export type ThreatEventsEditResponseMitreCapecList = Array<string>;
export declare const ThreatEventsEditResponseMitreCapecList: S.Schema<ThreatEventsEditResponseMitreCapecList>;
export type ThreatEventsEditResponseReferencedList = Array<string>;
export declare const ThreatEventsEditResponseReferencedList: S.Schema<ThreatEventsEditResponseReferencedList>;
export type ThreatEventsEditResponseReferencedIdsList = Array<number>;
export declare const ThreatEventsEditResponseReferencedIdsList: S.Schema<ThreatEventsEditResponseReferencedIdsList>;
export type ThreatEventsEditResponseReferencesList = Array<string>;
export declare const ThreatEventsEditResponseReferencesList: S.Schema<ThreatEventsEditResponseReferencesList>;
export type ThreatEventsEditResponseReferencesIdsList = Array<number>;
export declare const ThreatEventsEditResponseReferencesIdsList: S.Schema<ThreatEventsEditResponseReferencesIdsList>;
export type ThreatEventsEditResponseTagsList = Array<string>;
export declare const ThreatEventsEditResponseTagsList: S.Schema<ThreatEventsEditResponseTagsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventResponse {
    attacker: string;
    attackerCountry: string;
    attackerCountryAlpha3: string;
    category: string;
    datasetId: string;
    date: string;
    event: string;
    hasChildren: boolean;
    indicator: string;
    indicatorType: string;
    indicatorTypeId: number;
    killChain: number;
    mitreAttack: ThreatEventsEditResponseMitreAttackList;
    mitreCapec: ThreatEventsEditResponseMitreCapecList;
    numReferenced: number;
    numReferences: number;
    rawId: string;
    referenced: ThreatEventsEditResponseReferencedList;
    referencedIds: ThreatEventsEditResponseReferencedIdsList;
    references: ThreatEventsEditResponseReferencesList;
    referencesIds: ThreatEventsEditResponseReferencesIdsList;
    tags: ThreatEventsEditResponseTagsList;
    targetCountry: string;
    targetCountryAlpha3: string;
    targetIndustry: string;
    tlp: string;
    uuid: string;
    insight?: string | null;
    releasabilityId?: string | null;
}
export declare const PatchThreatEventResponse: S.Schema<PatchThreatEventResponse>;
export type ThreatEventsCategoriesEditRequestMitreAttackList = Array<string>;
export declare const ThreatEventsCategoriesEditRequestMitreAttackList: S.Schema<ThreatEventsCategoriesEditRequestMitreAttackList>;
export type ThreatEventsCategoriesEditRequestMitreCapecList = Array<string>;
export declare const ThreatEventsCategoriesEditRequestMitreCapecList: S.Schema<ThreatEventsCategoriesEditRequestMitreCapecList>;
export interface PatchThreatEventCategoryRequest {
    /** Account ID. */
    accountId: string;
    /** Category UUID. */
    categoryId: string;
    killChain?: number;
    mitreAttack?: ThreatEventsCategoriesEditRequestMitreAttackList;
    mitreCapec?: ThreatEventsCategoriesEditRequestMitreCapecList;
    name?: string;
    shortname?: string;
}
export declare const PatchThreatEventCategoryRequest: S.Schema<PatchThreatEventCategoryRequest>;
export type ThreatEventsCategoriesEditResponseMitreAttackList = Array<string>;
export declare const ThreatEventsCategoriesEditResponseMitreAttackList: S.Schema<ThreatEventsCategoriesEditResponseMitreAttackList>;
export type ThreatEventsCategoriesEditResponseMitreCapecList = Array<string>;
export declare const ThreatEventsCategoriesEditResponseMitreCapecList: S.Schema<ThreatEventsCategoriesEditResponseMitreCapecList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventCategoryResponse {
    killChain: number;
    name: string;
    uuid: string;
    mitreAttack?: ThreatEventsCategoriesEditResponseMitreAttackList | null;
    mitreCapec?: ThreatEventsCategoriesEditResponseMitreCapecList | null;
    shortname?: string | null;
}
export declare const PatchThreatEventCategoryResponse: S.Schema<PatchThreatEventCategoryResponse>;
export interface PatchThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
    /** If true, then anyone can search the dataset. If false, then its limited to the account. */
    isPublic: boolean;
    /** Used to describe the dataset within the account context. */
    name: string;
}
export declare const PatchThreatEventDatasetRequest: S.Schema<PatchThreatEventDatasetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventDatasetResponse {
    isPublic: boolean;
    name: string;
    uuid: string;
    deletedAt?: string | null;
}
export declare const PatchThreatEventDatasetResponse: S.Schema<PatchThreatEventDatasetResponse>;
export interface PatchThreatEventRawRequest {
    /** Account ID. */
    accountId: string;
    /** Event UUID. */
    eventId: string;
    /** Raw Event UUID. */
    rawId: string;
    data?: unknown;
    source?: string;
    tlp?: string;
}
export declare const PatchThreatEventRawRequest: S.Schema<PatchThreatEventRawRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchThreatEventRawResponse {
    id: string;
    data: unknown;
}
export declare const PatchThreatEventRawResponse: S.Schema<PatchThreatEventRawResponse>;
export interface QuotaRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
}
export declare const QuotaRequestPriorityRequest: S.Schema<QuotaRequestPriorityRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface QuotaRequestPriorityResponse {
    /** Anniversary date is when annual quota limit is refreshed. */
    anniversaryDate?: string | null;
    /** Quarter anniversary date is when quota limit is refreshed each quarter. */
    quarterAnniversaryDate?: string | null;
    /** Tokens for the quarter. */
    quota?: number | null;
    /** Tokens remaining for the quarter. */
    remaining?: number | null;
}
export declare const QuotaRequestPriorityResponse: S.Schema<QuotaRequestPriorityResponse>;
export interface RawThreatEventDatasetRequest {
    /** Account ID. */
    accountId: string;
    /** Dataset ID. */
    datasetId: string;
    /** Event ID. */
    eventId: string;
}
export declare const RawThreatEventDatasetRequest: S.Schema<RawThreatEventDatasetRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface RawThreatEventDatasetResponse {
    id: number;
    accountId: number;
    created: string;
    data: string;
    source: string;
    tlp: string;
}
export declare const RawThreatEventDatasetResponse: S.Schema<RawThreatEventDatasetResponse>;
export interface RequestsConstantsRequest {
    /** Identifier. */
    accountId: string;
}
export declare const RequestsConstantsRequest: S.Schema<RequestsConstantsRequest>;
export type RequestsConstantsResponsePriorityItem = "routine" | "high" | "urgent";
export declare const RequestsConstantsResponsePriorityItem: any;
export type RequestsConstantsResponsePriorityList = Array<RequestsConstantsResponsePriorityItem>;
export declare const RequestsConstantsResponsePriorityList: S.Schema<RequestsConstantsResponsePriorityList>;
export type RequestsConstantsResponseStatusItem = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const RequestsConstantsResponseStatusItem: any;
export type RequestsConstantsResponseStatusList = Array<RequestsConstantsResponseStatusItem>;
export declare const RequestsConstantsResponseStatusList: S.Schema<RequestsConstantsResponseStatusList>;
export type RequestsConstantsResponseTlpItem = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsConstantsResponseTlpItem: any;
export type RequestsConstantsResponseTlpList = Array<RequestsConstantsResponseTlpItem>;
export declare const RequestsConstantsResponseTlpList: S.Schema<RequestsConstantsResponseTlpList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RequestsConstantsResponse {
    priority?: RequestsConstantsResponsePriorityList | null;
    status?: RequestsConstantsResponseStatusList | null;
    tlp?: RequestsConstantsResponseTlpList | null;
}
export declare const RequestsConstantsResponse: S.Schema<RequestsConstantsResponse>;
export interface RequestsQuotaRequest {
    /** Identifier. */
    accountId: string;
}
export declare const RequestsQuotaRequest: S.Schema<RequestsQuotaRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RequestsQuotaResponse {
    /** Anniversary date is when annual quota limit is refreshed. */
    anniversaryDate?: string | null;
    /** Quarter anniversary date is when quota limit is refreshed each quarter. */
    quarterAnniversaryDate?: string | null;
    /** Tokens for the quarter. */
    quota?: number | null;
    /** Tokens remaining for the quarter. */
    remaining?: number | null;
}
export declare const RequestsQuotaResponse: S.Schema<RequestsQuotaResponse>;
export interface RequestsTypesRequest {
    /** Identifier. */
    accountId: string;
}
export declare const RequestsTypesRequest: S.Schema<RequestsTypesRequest>;
export type RequestsTypesResponse = unknown;
export declare const RequestsTypesResponse: S.Schema<RequestsTypesResponse>;
export type UpdateRequestRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const UpdateRequestRequestTlp: any;
export interface UpdateRequestRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** Request content. */
    content?: string;
    /** Priority for analyzing the request. */
    priority?: string;
    /** Requested information from request. */
    requestType?: string;
    /** Brief description of the request. */
    summary?: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp?: UpdateRequestRequestTlp | (string & {});
}
export declare const UpdateRequestRequest: S.Schema<UpdateRequestRequest>;
export type UpdateRequestResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const UpdateRequestResponseTlp: any;
export type UpdateRequestResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const UpdateRequestResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: UpdateRequestResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: UpdateRequestResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export declare const UpdateRequestResponse: S.Schema<UpdateRequestResponse>;
export interface UpdateRequestAssetRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    /** UUID. */
    assetId: string;
    /** Asset file to upload. */
    source?: string;
}
export declare const UpdateRequestAssetRequest: S.Schema<UpdateRequestAssetRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestAssetResponse {
    /** Asset ID. */
    id: number;
    /** Asset name. */
    name: string;
    /** Defines the asset creation time. */
    created?: string | null;
    /** Asset description. */
    description?: string | null;
    /** Asset file type. */
    fileType?: string | null;
}
export declare const UpdateRequestAssetResponse: S.Schema<UpdateRequestAssetResponse>;
export interface UpdateRequestMessageRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    requestId: string;
    messageId: number;
    /** Content of message. */
    content?: string;
}
export declare const UpdateRequestMessageRequest: S.Schema<UpdateRequestMessageRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestMessageResponse {
    /** Message ID. */
    id: number;
    /** Author of message. */
    author: string;
    /** Content of message. */
    content: string;
    /** Whether the message is a follow-on request. */
    isFollowOnRequest: boolean;
    /** Defines the message last updated time. */
    updated: string;
    /** Defines the message creation time. */
    created?: string | null;
}
export declare const UpdateRequestMessageResponse: S.Schema<UpdateRequestMessageResponse>;
export type RequestsPriorityUpdateRequestLabelsList = Array<unknown>;
export declare const RequestsPriorityUpdateRequestLabelsList: S.Schema<RequestsPriorityUpdateRequestLabelsList>;
export type RequestsPriorityUpdateRequestTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsPriorityUpdateRequestTlp: any;
export interface UpdateRequestPriorityRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    priorityId: string;
    /** List of labels. */
    labels: RequestsPriorityUpdateRequestLabelsList;
    /** Priority. */
    priority: number;
    /** Requirement. */
    requirement: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityUpdateRequestTlp | (string & {});
}
export declare const UpdateRequestPriorityRequest: S.Schema<UpdateRequestPriorityRequest>;
export type RequestsPriorityUpdateResponseTlp = "clear" | "amber" | "amber-strict" | "green" | "red";
export declare const RequestsPriorityUpdateResponseTlp: any;
export type RequestsPriorityUpdateResponseStatus = "open" | "accepted" | "reported" | "approved" | "completed" | "declined";
export declare const RequestsPriorityUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRequestPriorityResponse {
    /** UUID. */
    id: string;
    /** Request content. */
    content: string;
    created: string;
    priority: string;
    /** Requested information from request. */
    request: string;
    /** Brief description of the request. */
    summary: string;
    /** The CISA defined Traffic Light Protocol (TLP). */
    tlp: RequestsPriorityUpdateResponseTlp;
    updated: string;
    completed?: string | null;
    /** Tokens for the request messages. */
    messageTokens?: number | null;
    /** Readable Request ID. */
    readableId?: string | null;
    /** Request Status. */
    status?: RequestsPriorityUpdateResponseStatus | null;
    /** Tokens for the request. */
    tokens?: number | null;
}
export declare const UpdateRequestPriorityResponse: S.Schema<UpdateRequestPriorityResponse>;
export type BulkCreateThreatEventsError = CloudflareOpError;
/** The `datasetId` parameter must be defined. To list existing datasets (and their IDs) in your account, use the [`List Datasets`](https://developers.cloudflare.com/api/resources/cloudforce_one/subresources/threat_events/subresources/datasets/methods/list/) endpoint. */
export declare const bulkCreateThreatEvents: API.OperationMethod<BulkCreateThreatEventsRequest, BulkCreateThreatEventsResponse, BulkCreateThreatEventsError, CloudflareOpContext>;
export type CreateBinaryStorageError = CloudflareOpError;
/** Uploads a binary file to Cloudforce One's binary database for malware analysis and threat intelligence correlation. */
export declare const createBinaryStorage: API.OperationMethod<CreateBinaryStorageRequest, CreateBinaryStorageResponse, CreateBinaryStorageError, CloudflareOpContext>;
export type CreateRequestError = CloudflareOpError;
/** Creating a request adds the request into the Cloudforce One queue for analysis. In addition to the content, a short title, type, priority, and releasability should be provided. If one is not provided, a default will be assigned. */
export declare const createRequest: API.OperationMethod<CreateRequestRequest, CreateRequestResponse, CreateRequestError, CloudflareOpContext>;
export type CreateRequestAssetError = CloudflareOpError;
/** Lists assets attached to a Cloudforce One intelligence request. */
export declare const createRequestAsset: API.PaginatedOperationMethod<CreateRequestAssetRequest, CreateRequestAssetResponse, CreateRequestAssetError, CloudflareOpContext, RequestsAssetsCreateResultItem>;
export type CreateRequestMessageError = CloudflareOpError;
/** Adds a message to a Cloudforce One intelligence request conversation. */
export declare const createRequestMessage: API.OperationMethod<CreateRequestMessageRequest, CreateRequestMessageResponse, CreateRequestMessageError, CloudflareOpContext>;
export type CreateRequestPriorityError = CloudflareOpError;
/** Creates a new priority intelligence request in Cloudforce One. */
export declare const createRequestPriority: API.OperationMethod<CreateRequestPriorityRequest, CreateRequestPriorityResponse, CreateRequestPriorityError, CloudflareOpContext>;
export type CreateScanConfigError = CloudflareOpError;
/** Create a new Scan Config */
export declare const createScanConfig: API.OperationMethod<CreateScanConfigRequest, CreateScanConfigResponse, CreateScanConfigError, CloudflareOpContext>;
export type CreateThreatEventError = CloudflareOpError;
/** To create a dataset, see the [`Create Dataset`](https://developers.cloudflare.com/api/resources/cloudforce_one/subresources/threat_events/subresources/datasets/methods/create/) endpoint. When `datasetId` parameter is unspecified, it will be created in a default dataset named `Cloudforce One Threat Events`. */
export declare const createThreatEvent: API.OperationMethod<CreateThreatEventRequest, CreateThreatEventResponse, CreateThreatEventError, CloudflareOpContext>;
export type CreateThreatEventCategoryError = CloudflareOpError;
/** Creates a new category */
export declare const createThreatEventCategory: API.OperationMethod<CreateThreatEventCategoryRequest, CreateThreatEventCategoryResponse, CreateThreatEventCategoryError, CloudflareOpContext>;
export type CreateThreatEventDatasetError = CloudflareOpError;
/** Creates a dataset */
export declare const createThreatEventDataset: API.OperationMethod<CreateThreatEventDatasetRequest, CreateThreatEventDatasetResponse, CreateThreatEventDatasetError, CloudflareOpContext>;
export type CreateThreatEventEventTagError = CloudflareOpError;
/** Adds a tag to an event */
export declare const createThreatEventEventTag: API.OperationMethod<CreateThreatEventEventTagRequest, CreateThreatEventEventTagResponse, CreateThreatEventEventTagError, CloudflareOpContext>;
export type CreateThreatEventTagError = CloudflareOpError;
/** Creates a new tag to be used accross threat events. */
export declare const createThreatEventTag: API.OperationMethod<CreateThreatEventTagRequest, CreateThreatEventTagResponse, CreateThreatEventTagError, CloudflareOpContext>;
export type DeleteRequestError = CloudflareOpError;
/** Deletes a Cloudforce One intelligence request and all associated data. */
export declare const deleteRequest: API.OperationMethod<DeleteRequestRequest, DeleteRequestResponse, DeleteRequestError, CloudflareOpContext>;
export type DeleteRequestAssetError = CloudflareOpError;
/** Removes an asset from a Cloudforce One intelligence request. */
export declare const deleteRequestAsset: API.OperationMethod<DeleteRequestAssetRequest, DeleteRequestAssetResponse, DeleteRequestAssetError, CloudflareOpContext>;
export type DeleteRequestMessageError = CloudflareOpError;
/** Removes a message from a Cloudforce One intelligence request thread. */
export declare const deleteRequestMessage: API.OperationMethod<DeleteRequestMessageRequest, DeleteRequestMessageResponse, DeleteRequestMessageError, CloudflareOpContext>;
export type DeleteRequestPriorityError = CloudflareOpError;
/** Deletes a priority intelligence request from Cloudforce One. */
export declare const deleteRequestPriority: API.OperationMethod<DeleteRequestPriorityRequest, DeleteRequestPriorityResponse, DeleteRequestPriorityError, CloudflareOpContext>;
export type DeleteScanConfigError = ScanConfigNotFound | CloudflareOpError;
/** Delete a Scan Config */
export declare const deleteScanConfig: API.OperationMethod<DeleteScanConfigRequest, DeleteScanConfigResponse, DeleteScanConfigError, CloudflareOpContext>;
export type DeleteThreatEventCategoryError = CloudflareOpError;
/** Deletes a category */
export declare const deleteThreatEventCategory: API.OperationMethod<DeleteThreatEventCategoryRequest, DeleteThreatEventCategoryResponse, DeleteThreatEventCategoryError, CloudflareOpContext>;
export type DeleteThreatEventEventTagError = CloudflareOpError;
/** Removes a tag from an event */
export declare const deleteThreatEventEventTag: API.OperationMethod<DeleteThreatEventEventTagRequest, DeleteThreatEventEventTagResponse, DeleteThreatEventEventTagError, CloudflareOpContext>;
export type DeleteThreatEventRelateError = CloudflareOpError;
/** Removes an event reference */
export declare const deleteThreatEventRelate: API.OperationMethod<DeleteThreatEventRelateRequest, DeleteThreatEventRelateResponse, DeleteThreatEventRelateError, CloudflareOpContext>;
export type GetBinaryStorageError = CloudflareOpError;
/** Retrieves a binary file from the Cloudforce One binary storage for analysis. */
export declare const getBinaryStorage: API.OperationMethod<GetBinaryStorageRequest, GetBinaryStorageResponse, GetBinaryStorageError, CloudflareOpContext>;
export type GetRequestError = CloudflareOpError;
/** Retrieves details for a specific Cloudforce One intelligence request. */
export declare const getRequest: API.OperationMethod<GetRequestRequest, GetRequestResponse, GetRequestError, CloudflareOpContext>;
export type GetRequestMessageError = CloudflareOpError;
/** Lists messages in a Cloudforce One intelligence request conversation. */
export declare const getRequestMessage: API.PaginatedOperationMethod<GetRequestMessageRequest, GetRequestMessageResponse, GetRequestMessageError, CloudflareOpContext, RequestsMessageGetResultItem>;
export type GetRequestPriorityError = CloudflareOpError;
/** Retrieves a specific priority intelligence request from Cloudforce One. */
export declare const getRequestPriority: API.OperationMethod<GetRequestPriorityRequest, GetRequestPriorityResponse, GetRequestPriorityError, CloudflareOpContext>;
export type GetRequestsAssetError = CloudflareOpError;
/** Retrieves an asset attached to a Cloudforce One intelligence request. */
export declare const getRequestsAsset: API.OperationMethod<GetRequestsAssetRequest, GetRequestsAssetResponse, GetRequestsAssetError, CloudflareOpContext>;
export type GetScanResultError = CloudflareOpError;
/** Get the Latest Scan Result */
export declare const getScanResult: API.OperationMethod<GetScanResultRequest, GetScanResultResponse, GetScanResultError, CloudflareOpContext>;
export type GetThreatEventError = CloudflareOpError;
/** This Method is deprecated. Please use /events/dataset/:dataset_id/events/:event_id instead. */
export declare const getThreatEvent: API.OperationMethod<GetThreatEventRequest, GetThreatEventResponse, GetThreatEventError, CloudflareOpContext>;
export type GetThreatEventCategoryError = CloudflareOpError;
/** Reads a category */
export declare const getThreatEventCategory: API.OperationMethod<GetThreatEventCategoryRequest, GetThreatEventCategoryResponse, GetThreatEventCategoryError, CloudflareOpContext>;
export type GetThreatEventDatasetError = CloudflareOpError;
/** Reads a dataset */
export declare const getThreatEventDataset: API.OperationMethod<GetThreatEventDatasetRequest, GetThreatEventDatasetResponse, GetThreatEventDatasetError, CloudflareOpContext>;
export type GetThreatEventRawError = CloudflareOpError;
/** Reads data for a raw event */
export declare const getThreatEventRaw: API.OperationMethod<GetThreatEventRawRequest, GetThreatEventRawResponse, GetThreatEventRawError, CloudflareOpContext>;
export type ListRequestsError = CloudflareOpError;
/** Lists Cloudforce One intelligence requests with filtering and pagination. */
export declare const listRequests: API.OperationMethod<ListRequestsRequest, ListRequestsResponse, ListRequestsError, CloudflareOpContext>;
export type ListScanConfigsError = CloudflareOpError;
/** List Scan Configs */
export declare const listScanConfigs: API.PaginatedOperationMethod<ListScanConfigsRequest, ListScanConfigsResponse, ListScanConfigsError, CloudflareOpContext, ScansConfigListResultItem>;
export type ListThreatEventAttackersError = CloudflareOpError;
/** Lists attackers across multiple datasets */
export declare const listThreatEventAttackers: API.OperationMethod<ListThreatEventAttackersRequest, ListThreatEventAttackersResponse, ListThreatEventAttackersError, CloudflareOpContext>;
export type ListThreatEventCategoriesError = CloudflareOpError;
/** Lists categories across multiple datasets */
export declare const listThreatEventCategories: API.OperationMethod<ListThreatEventCategoriesRequest, ListThreatEventCategoriesResponse, ListThreatEventCategoriesError, CloudflareOpContext>;
export type ListThreatEventCountriesError = CloudflareOpError;
/** Retrieves countries information for all countries */
export declare const listThreatEventCountries: API.OperationMethod<ListThreatEventCountriesRequest, ListThreatEventCountriesResponse, ListThreatEventCountriesError, CloudflareOpContext>;
export type ListThreatEventDatasetsError = CloudflareOpError;
/** Lists all datasets in an account */
export declare const listThreatEventDatasets: API.OperationMethod<ListThreatEventDatasetsRequest, ListThreatEventDatasetsResponse, ListThreatEventDatasetsError, CloudflareOpContext>;
export type ListThreatEventIndicatorTypesError = CloudflareOpError;
/** This Method is deprecated. Please use /events/dataset/:dataset_id/indicatorTypes instead. */
export declare const listThreatEventIndicatorTypes: API.OperationMethod<ListThreatEventIndicatorTypesRequest, ListThreatEventIndicatorTypesResponse, ListThreatEventIndicatorTypesError, CloudflareOpContext>;
export type ListThreatEventsError = CloudflareOpError;
/** Use `datasetId=all` or `datasetId=*` to query all event datasets for the account (limited to 10). When `datasetId` is unspecified, events are listed from the default Cloudforce One Threat Events dataset. To list existing datasets, use the [`List Datasets`](https://developers.cloudflare.com/api/resources/cloudforce_one/subresources/threat_events/subresources/datasets/methods/list/) endpoint. */
export declare const listThreatEvents: API.OperationMethod<ListThreatEventsRequest, ListThreatEventsResponse, ListThreatEventsError, CloudflareOpContext>;
export type ListThreatEventTargetIndustriesError = CloudflareOpError;
/** Lists target industries across multiple datasets */
export declare const listThreatEventTargetIndustries: API.OperationMethod<ListThreatEventTargetIndustriesRequest, ListThreatEventTargetIndustriesResponse, ListThreatEventTargetIndustriesError, CloudflareOpContext>;
export type PatchScanConfigError = ScanConfigNotFound | CloudflareOpError;
/** Update an existing Scan Config */
export declare const patchScanConfig: API.OperationMethod<PatchScanConfigRequest, PatchScanConfigResponse, PatchScanConfigError, CloudflareOpContext>;
export type PatchThreatEventError = CloudflareOpError;
/** Updates an event */
export declare const patchThreatEvent: API.OperationMethod<PatchThreatEventRequest, PatchThreatEventResponse, PatchThreatEventError, CloudflareOpContext>;
export type PatchThreatEventCategoryError = CloudflareOpError;
/** Updates a category */
export declare const patchThreatEventCategory: API.OperationMethod<PatchThreatEventCategoryRequest, PatchThreatEventCategoryResponse, PatchThreatEventCategoryError, CloudflareOpContext>;
export type PatchThreatEventDatasetError = CloudflareOpError;
/** Updates an existing dataset */
export declare const patchThreatEventDataset: API.OperationMethod<PatchThreatEventDatasetRequest, PatchThreatEventDatasetResponse, PatchThreatEventDatasetError, CloudflareOpContext>;
export type PatchThreatEventRawError = CloudflareOpError;
/** Updates a raw event */
export declare const patchThreatEventRaw: API.OperationMethod<PatchThreatEventRawRequest, PatchThreatEventRawResponse, PatchThreatEventRawError, CloudflareOpContext>;
export type QuotaRequestPriorityError = CloudflareOpError;
/** Retrieves quota usage for Cloudforce One priority requests. */
export declare const quotaRequestPriority: API.OperationMethod<QuotaRequestPriorityRequest, QuotaRequestPriorityResponse, QuotaRequestPriorityError, CloudflareOpContext>;
export type RawThreatEventDatasetError = CloudflareOpError;
/** Retrieves the raw data associated with an event. Searches across all shards in the dataset. */
export declare const rawThreatEventDataset: API.OperationMethod<RawThreatEventDatasetRequest, RawThreatEventDatasetResponse, RawThreatEventDatasetError, CloudflareOpContext>;
export type RequestsConstantsError = CloudflareOpError;
/** Retrieves constant values used in Cloudforce One requests, including valid statuses and types. */
export declare const requestsConstants: API.OperationMethod<RequestsConstantsRequest, RequestsConstantsResponse, RequestsConstantsError, CloudflareOpContext>;
export type RequestsQuotaError = CloudflareOpError;
/** Retrieves quota usage for Cloudforce One standard requests. */
export declare const requestsQuota: API.OperationMethod<RequestsQuotaRequest, RequestsQuotaResponse, RequestsQuotaError, CloudflareOpContext>;
export type RequestsTypesError = CloudflareOpError;
/** Lists available request types for Cloudforce One intelligence requests. */
export declare const requestsTypes: API.OperationMethod<RequestsTypesRequest, RequestsTypesResponse, RequestsTypesError, CloudflareOpContext>;
export type UpdateRequestError = CloudflareOpError;
/** Updating a request alters the request in the Cloudforce One queue. This API may be used to update any attributes of the request after the initial submission. Only fields that you choose to update need to be add to the request body. */
export declare const updateRequest: API.OperationMethod<UpdateRequestRequest, UpdateRequestResponse, UpdateRequestError, CloudflareOpContext>;
export type UpdateRequestAssetError = CloudflareOpError;
/** Updates an asset in a Cloudforce One intelligence request. */
export declare const updateRequestAsset: API.OperationMethod<UpdateRequestAssetRequest, UpdateRequestAssetResponse, UpdateRequestAssetError, CloudflareOpContext>;
export type UpdateRequestMessageError = CloudflareOpError;
/** Updates a message in a Cloudforce One intelligence request thread. */
export declare const updateRequestMessage: API.OperationMethod<UpdateRequestMessageRequest, UpdateRequestMessageResponse, UpdateRequestMessageError, CloudflareOpContext>;
export type UpdateRequestPriorityError = CloudflareOpError;
/** Updates a priority intelligence request in Cloudforce One. */
export declare const updateRequestPriority: API.OperationMethod<UpdateRequestPriorityRequest, UpdateRequestPriorityResponse, UpdateRequestPriorityError, CloudflareOpContext>;
//# sourceMappingURL=cloudforce_one.d.ts.map