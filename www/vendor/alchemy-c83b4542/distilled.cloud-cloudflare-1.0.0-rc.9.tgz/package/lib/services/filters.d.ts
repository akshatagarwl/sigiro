import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type BulkDeleteRequestIdList = Array<string>;
export declare const BulkDeleteRequestIdList: S.Schema<BulkDeleteRequestIdList>;
export interface BulkDeleteFiltersRequest {
    /** Defines an identifier. */
    zoneId: string;
    id: BulkDeleteRequestIdList;
}
export declare const BulkDeleteFiltersRequest: S.Schema<BulkDeleteFiltersRequest>;
export interface BulkDeleteResultItem {
    /** The unique identifier of the filter. */
    id?: string | null;
}
export declare const BulkDeleteResultItem: S.Schema<BulkDeleteResultItem>;
export type BulkDeleteResultList = Array<BulkDeleteResultItem>;
export declare const BulkDeleteResultList: S.Schema<BulkDeleteResultList>;
export type BulkDeleteFiltersResponse = BulkDeleteResultList;
export declare const BulkDeleteFiltersResponse: S.Schema<BulkDeleteFiltersResponse>;
export interface BulkUpdateRequestBodyItem {
    /** The unique identifier of the filter. */
    id?: string;
    /** An informative summary of the filter. */
    description?: string;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string;
}
export declare const BulkUpdateRequestBodyItem: S.Schema<BulkUpdateRequestBodyItem>;
export type BulkUpdateRequestBodyList = Array<BulkUpdateRequestBodyItem>;
export declare const BulkUpdateRequestBodyList: S.Schema<BulkUpdateRequestBodyList>;
export interface BulkPutFiltersRequest {
    /** Defines an identifier. */
    zoneId: string;
    body: BulkUpdateRequestBodyList;
}
export declare const BulkPutFiltersRequest: S.Schema<BulkPutFiltersRequest>;
export interface BulkUpdateResultItem {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export declare const BulkUpdateResultItem: S.Schema<BulkUpdateResultItem>;
export type BulkUpdateResultList = Array<BulkUpdateResultItem>;
export declare const BulkUpdateResultList: S.Schema<BulkUpdateResultList>;
export interface BulkPutFiltersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BulkUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkPutFiltersResponse: S.Schema<BulkPutFiltersResponse>;
export type CreateRequestBodyItem = BulkUpdateRequestBodyItem;
export declare const CreateRequestBodyItem: S.Schema<BulkUpdateRequestBodyItem>;
export type CreateRequestBodyList = Array<BulkUpdateRequestBodyItem>;
export declare const CreateRequestBodyList: S.Schema<CreateRequestBodyList>;
export interface CreateFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    body: CreateRequestBodyList;
}
export declare const CreateFilterRequest: S.Schema<CreateFilterRequest>;
export type CreateResultItem = BulkUpdateResultItem;
export declare const CreateResultItem: S.Schema<BulkUpdateResultItem>;
export type CreateResultList = Array<BulkUpdateResultItem>;
export declare const CreateResultList: S.Schema<CreateResultList>;
export interface CreateFilterResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateFilterResponse: S.Schema<CreateFilterResponse>;
export interface DeleteFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    filterId: string;
}
export declare const DeleteFilterRequest: S.Schema<DeleteFilterRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteFilterResponse {
    /** The unique identifier of the filter. */
    id: string;
}
export declare const DeleteFilterResponse: S.Schema<DeleteFilterResponse>;
export interface GetFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    filterId: string;
}
export declare const GetFilterRequest: S.Schema<GetFilterRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetFilterResponse {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export declare const GetFilterResponse: S.Schema<GetFilterResponse>;
export interface ListFiltersRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    id?: string;
    /** A case-insensitive string to find in the description. */
    description?: string;
    /** A case-insensitive string to find in the expression. */
    expression?: string;
    /** Page number of paginated results. */
    page?: number;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** Number of filters per page. */
    perPage?: number;
    /** The filter ref (a short reference tag) to search for. Must be an exact match. */
    ref?: string;
}
export declare const ListFiltersRequest: S.Schema<ListFiltersRequest>;
export type ListResultItem = BulkUpdateResultItem;
export declare const ListResultItem: S.Schema<BulkUpdateResultItem>;
export type ListResultList = Array<BulkUpdateResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListFiltersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListFiltersResponse: S.Schema<ListFiltersResponse>;
export interface UpdateFilterRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the filter. */
    filterId: string;
    /** An informative summary of the filter. */
    description?: string;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string;
}
export declare const UpdateFilterRequest: S.Schema<UpdateFilterRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateFilterResponse {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export declare const UpdateFilterResponse: S.Schema<UpdateFilterResponse>;
export type BulkDeleteFiltersError = CloudflareOpError;
/** Deletes one or more existing filters. */
export declare const bulkDeleteFilters: API.OperationMethod<BulkDeleteFiltersRequest, BulkDeleteFiltersResponse, BulkDeleteFiltersError, CloudflareOpContext>;
export type BulkPutFiltersError = CloudflareOpError;
/** Updates one or more existing filters. */
export declare const bulkPutFilters: API.PaginatedOperationMethod<BulkPutFiltersRequest, BulkPutFiltersResponse, BulkPutFiltersError, CloudflareOpContext, BulkUpdateResultItem>;
export type CreateFilterError = CloudflareOpError;
/** Creates one or more filters. */
export declare const createFilter: API.PaginatedOperationMethod<CreateFilterRequest, CreateFilterResponse, CreateFilterError, CloudflareOpContext, BulkUpdateResultItem>;
export type DeleteFilterError = CloudflareOpError;
/** Deletes an existing filter. */
export declare const deleteFilter: API.OperationMethod<DeleteFilterRequest, DeleteFilterResponse, DeleteFilterError, CloudflareOpContext>;
export type GetFilterError = CloudflareOpError;
/** Fetches the details of a filter. */
export declare const getFilter: API.OperationMethod<GetFilterRequest, GetFilterResponse, GetFilterError, CloudflareOpContext>;
export type ListFiltersError = CloudflareOpError;
/** Fetches filters in a zone. You can filter the results using several optional parameters. */
export declare const listFilters: API.PaginatedOperationMethod<ListFiltersRequest, ListFiltersResponse, ListFiltersError, CloudflareOpContext, BulkUpdateResultItem>;
export type UpdateFilterError = CloudflareOpError;
/** Updates an existing filter. */
export declare const updateFilter: API.OperationMethod<UpdateFilterRequest, UpdateFilterResponse, UpdateFilterError, CloudflareOpContext>;
//# sourceMappingURL=filters.d.ts.map