import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CustomNameserverSetNotFound_base: S.Class<CustomNameserverSetNotFound, S.TaggedStruct<"CustomNameserverSetNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CustomNameserverSetNotFound extends /*@__PURE__*/ CustomNameserverSetNotFound_base {
}
declare const DomainNotRegistered_base: S.Class<DomainNotRegistered, S.TaggedStruct<"DomainNotRegistered", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DomainNotRegistered extends /*@__PURE__*/ DomainNotRegistered_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidDomain_base: S.Class<InvalidDomain, S.TaggedStruct<"InvalidDomain", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDomain extends /*@__PURE__*/ InvalidDomain_base {
}
declare const InvalidZoneIdentifier_base: S.Class<InvalidZoneIdentifier, S.TaggedStruct<"InvalidZoneIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidZoneIdentifier extends /*@__PURE__*/ InvalidZoneIdentifier_base {
}
declare const SubdomainNotAllowed_base: S.Class<SubdomainNotAllowed, S.TaggedStruct<"SubdomainNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SubdomainNotAllowed extends /*@__PURE__*/ SubdomainNotAllowed_base {
}
declare const ZoneAlreadyExists_base: S.Class<ZoneAlreadyExists, S.TaggedStruct<"ZoneAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneAlreadyExists extends /*@__PURE__*/ ZoneAlreadyExists_base {
}
declare const ZoneCreationBlocked_base: S.Class<ZoneCreationBlocked, S.TaggedStruct<"ZoneCreationBlocked", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneCreationBlocked extends /*@__PURE__*/ ZoneCreationBlocked_base {
}
declare const ZoneHoldNotFound_base: S.Class<ZoneHoldNotFound, S.TaggedStruct<"ZoneHoldNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneHoldNotFound extends /*@__PURE__*/ ZoneHoldNotFound_base {
}
declare const ZoneHoldsRequireEnterprise_base: S.Class<ZoneHoldsRequireEnterprise, S.TaggedStruct<"ZoneHoldsRequireEnterprise", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneHoldsRequireEnterprise extends /*@__PURE__*/ ZoneHoldsRequireEnterprise_base {
}
export interface EnvironmentsCreateRequestEnvironmentsItemPosition {
    after?: string;
    before?: string;
}
export declare const EnvironmentsCreateRequestEnvironmentsItemPosition: S.Schema<EnvironmentsCreateRequestEnvironmentsItemPosition>;
export interface EnvironmentsCreateRequestEnvironmentsItem {
    expression: string;
    lockedOnDeployment: boolean;
    name: string;
    position: EnvironmentsCreateRequestEnvironmentsItemPosition;
    ref: string;
    version: number;
    httpApplicationId?: string;
}
export declare const EnvironmentsCreateRequestEnvironmentsItem: S.Schema<EnvironmentsCreateRequestEnvironmentsItem>;
export type EnvironmentsCreateRequestEnvironmentsList = Array<EnvironmentsCreateRequestEnvironmentsItem>;
export declare const EnvironmentsCreateRequestEnvironmentsList: S.Schema<EnvironmentsCreateRequestEnvironmentsList>;
export interface CreateEnvironmentRequest {
    zoneId: string;
    environments: EnvironmentsCreateRequestEnvironmentsList;
}
export declare const CreateEnvironmentRequest: S.Schema<CreateEnvironmentRequest>;
export interface EnvironmentsCreateResponseEnvironmentsItemPosition {
    after?: string | null;
    before?: string | null;
}
export declare const EnvironmentsCreateResponseEnvironmentsItemPosition: S.Schema<EnvironmentsCreateResponseEnvironmentsItemPosition>;
export interface EnvironmentsCreateResponseEnvironmentsItem {
    expression: string;
    lockedOnDeployment: boolean;
    name: string;
    position: EnvironmentsCreateResponseEnvironmentsItemPosition;
    ref: string;
    version: number;
    httpApplicationId?: string | null;
}
export declare const EnvironmentsCreateResponseEnvironmentsItem: S.Schema<EnvironmentsCreateResponseEnvironmentsItem>;
export type EnvironmentsCreateResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
export declare const EnvironmentsCreateResponseEnvironmentsList: S.Schema<EnvironmentsCreateResponseEnvironmentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEnvironmentResponse {
    environments: EnvironmentsCreateResponseEnvironmentsList;
}
export declare const CreateEnvironmentResponse: S.Schema<CreateEnvironmentResponse>;
export interface CreateHoldRequest {
    /** Identifier. */
    zoneId: string;
    /** If provided, the zone hold will extend to block any subdomain of the given zone, as well */
    includeSubdomains?: boolean;
}
export declare const CreateHoldRequest: S.Schema<CreateHoldRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export declare const CreateHoldResponse: S.Schema<CreateHoldResponse>;
export type SubscriptionsCreateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsCreateRequestFrequency: any;
export type SubscriptionsCreateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsCreateRequestRatePlanId: any;
export type SubscriptionsCreateRequestRatePlanSetsList = Array<string>;
export declare const SubscriptionsCreateRequestRatePlanSetsList: S.Schema<SubscriptionsCreateRequestRatePlanSetsList>;
export interface SubscriptionsCreateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateRequestRatePlanSetsList;
}
export declare const SubscriptionsCreateRequestRatePlan: S.Schema<SubscriptionsCreateRequestRatePlan>;
export interface CreateSubscriptionRequest {
    /** Identifier */
    zoneId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateRequestRatePlan;
}
export declare const CreateSubscriptionRequest: S.Schema<CreateSubscriptionRequest>;
export type SubscriptionsCreateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly" | "not-applicable";
export declare const SubscriptionsCreateResponseFrequency: any;
export type SubscriptionsCreateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsCreateResponseRatePlanId: any;
export type SubscriptionsCreateResponseRatePlanSetsList = Array<string>;
export declare const SubscriptionsCreateResponseRatePlanSetsList: S.Schema<SubscriptionsCreateResponseRatePlanSetsList>;
export interface SubscriptionsCreateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateResponseRatePlanSetsList | null;
}
export declare const SubscriptionsCreateResponseRatePlan: S.Schema<SubscriptionsCreateResponseRatePlan>;
export type SubscriptionsCreateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsCreateResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsCreateResponseState | null;
}
export declare const CreateSubscriptionResponse: S.Schema<CreateSubscriptionResponse>;
export interface CreateRequestAccount {
    /** Identifier */
    id?: string;
}
export declare const CreateRequestAccount: S.Schema<CreateRequestAccount>;
export type CreateRequestType = "full" | "partial" | "secondary" | "internal";
export declare const CreateRequestType: any;
export interface CreateZoneRequest {
    account: CreateRequestAccount;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is */
    type?: CreateRequestType | (string & {});
}
export declare const CreateZoneRequest: S.Schema<CreateZoneRequest>;
export interface CreateResponseAccount {
    /** Identifier */
    id?: string | null;
    /** The name of the account. */
    name?: string | null;
}
export declare const CreateResponseAccount: S.Schema<CreateResponseAccount>;
export interface CreateResponseMeta {
    /** The zone is only configured for CDN. */
    cdnOnly?: boolean | null;
    /** Number of Custom Certificates the zone can have. */
    customCertificateQuota?: number | null;
    /** The zone is only configured for DNS. */
    dnsOnly?: boolean | null;
    /** The zone is setup with Foundation DNS. */
    foundationDns?: boolean | null;
    /** Number of Page Rules a zone can have. */
    pageRuleQuota?: number | null;
    /** The zone has been flagged for phishing. */
    phishingDetected?: boolean | null;
    step?: number | null;
}
export declare const CreateResponseMeta: S.Schema<CreateResponseMeta>;
export type CreateResponseNameServersList = Array<string>;
export declare const CreateResponseNameServersList: S.Schema<CreateResponseNameServersList>;
export type CreateResponseOriginalNameServersList = Array<string>;
export declare const CreateResponseOriginalNameServersList: S.Schema<CreateResponseOriginalNameServersList>;
export interface CreateResponseOwner {
    /** Identifier */
    id?: string | null;
    /** Name of the owner. */
    name?: string | null;
    /** The type of owner. */
    type?: string | null;
}
export declare const CreateResponseOwner: S.Schema<CreateResponseOwner>;
export interface CreateResponsePlan {
    /** Identifier */
    id?: string | null;
    /** States if the subscription can be activated. */
    canSubscribe?: boolean | null;
    /** The denomination of the customer. */
    currency?: string | null;
    /** If this Zone is managed by another company. */
    externallyManaged?: boolean | null;
    /** How often the customer is billed. */
    frequency?: string | null;
    /** States if the subscription active. */
    isSubscribed?: boolean | null;
    /** If the legacy discount applies to this Zone. */
    legacyDiscount?: boolean | null;
    /** The legacy name of the plan. */
    legacyId?: string | null;
    /** Name of the owner. */
    name?: string | null;
    /** How much the customer is paying. */
    price?: number | null;
}
export declare const CreateResponsePlan: S.Schema<CreateResponsePlan>;
export type CreateResponsePermissionsList = Array<string>;
export declare const CreateResponsePermissionsList: S.Schema<CreateResponsePermissionsList>;
export type CreateResponseStatus = "initializing" | "pending" | "active" | "moved";
export declare const CreateResponseStatus: any;
export interface CreateResponseTenant {
    /** Identifier */
    id?: string | null;
    /** The name of the Tenant account. */
    name?: string | null;
}
export declare const CreateResponseTenant: S.Schema<CreateResponseTenant>;
export interface CreateResponseTenantUnit {
    /** Identifier */
    id?: string | null;
}
export declare const CreateResponseTenantUnit: S.Schema<CreateResponseTenantUnit>;
export type CreateResponseType = "full" | "partial" | "secondary" | "internal";
export declare const CreateResponseType: any;
export type CreateResponseVanityNameServersList = Array<string>;
export declare const CreateResponseVanityNameServersList: S.Schema<CreateResponseVanityNameServersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneResponse {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: CreateResponseNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: CreateResponseOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** A Zones subscription information. */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A */
    paused?: boolean | null;
    /** Legacy permissions based on legacy user membership information. */
    permissions?: CreateResponsePermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: CreateResponseStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is */
    type?: CreateResponseType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: CreateResponseVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export declare const CreateZoneResponse: S.Schema<CreateZoneResponse>;
export interface DeleteEnvironmentRequest {
    zoneId: string;
    environmentId: string;
}
export declare const DeleteEnvironmentRequest: S.Schema<DeleteEnvironmentRequest>;
export type EnvironmentsDeleteResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export declare const EnvironmentsDeleteResponseEnvironmentsItemPosition: S.Schema<EnvironmentsCreateResponseEnvironmentsItemPosition>;
export type EnvironmentsDeleteResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export declare const EnvironmentsDeleteResponseEnvironmentsItem: S.Schema<EnvironmentsCreateResponseEnvironmentsItem>;
export type EnvironmentsDeleteResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
export declare const EnvironmentsDeleteResponseEnvironmentsList: S.Schema<EnvironmentsDeleteResponseEnvironmentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteEnvironmentResponse {
    environments: EnvironmentsDeleteResponseEnvironmentsList;
}
export declare const DeleteEnvironmentResponse: S.Schema<DeleteEnvironmentResponse>;
export interface DeleteHoldRequest {
    /** Identifier. */
    zoneId: string;
    /** If `hold_after` is provided, the hold will be temporarily disabled, */
    holdAfter?: string;
}
export declare const DeleteHoldRequest: S.Schema<DeleteHoldRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export declare const DeleteHoldResponse: S.Schema<DeleteHoldResponse>;
export interface DeleteZoneRequest {
    /** Identifier */
    zoneId: string;
}
export declare const DeleteZoneRequest: S.Schema<DeleteZoneRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteZoneResponse: S.Schema<DeleteZoneResponse>;
export interface GetCtAlertingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetCtAlertingRequest: S.Schema<GetCtAlertingRequest>;
export type CtAlertingGetResponseEmailsList = Array<string>;
export declare const CtAlertingGetResponseEmailsList: S.Schema<CtAlertingGetResponseEmailsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCtAlertingResponse {
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** Email addresses that receive CT alert notifications. Only present and configurable for Business and Enterprise zones. Maximum of 10 addresses. For Free and Pro zones, notifications are sent to all users with SSL permissions on the zone. */
    emails?: CtAlertingGetResponseEmailsList | null;
}
export declare const GetCtAlertingResponse: S.Schema<GetCtAlertingResponse>;
export interface GetCustomNameserverRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetCustomNameserverRequest: S.Schema<GetCustomNameserverRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetCustomNameserverResponse {
    /** Whether zone uses account-level custom nameservers. */
    enabled?: boolean | null;
    /** The number of the name server set to assign to the zone. */
    nsSet?: number | null;
}
export declare const GetCustomNameserverResponse: S.Schema<GetCustomNameserverResponse>;
export interface GetHoldRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetHoldRequest: S.Schema<GetHoldRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export declare const GetHoldResponse: S.Schema<GetHoldResponse>;
export interface GetPlanRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    planIdentifier: string;
}
export declare const GetPlanRequest: S.Schema<GetPlanRequest>;
export type PlansGetResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const PlansGetResponseFrequency: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPlanResponse {
    /** Identifier */
    id?: string | null;
    /** Indicates whether you can subscribe to this plan. */
    canSubscribe?: boolean | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** Indicates whether this plan is managed externally. */
    externallyManaged?: boolean | null;
    /** The frequency at which you will be billed for this plan. */
    frequency?: PlansGetResponseFrequency | null;
    /** Indicates whether you are currently subscribed to this plan. */
    isSubscribed?: boolean | null;
    /** Indicates whether this plan has a legacy discount applied. */
    legacyDiscount?: boolean | null;
    /** The legacy identifier for this rate plan, if any. */
    legacyId?: string | null;
    /** The plan name. */
    name?: string | null;
    /** The amount you will be billed for this plan. */
    price?: number | null;
}
export declare const GetPlanResponse: S.Schema<GetPlanResponse>;
export interface GetRatePlanRequest {
    /** Identifier */
    zoneId: string;
}
export declare const GetRatePlanRequest: S.Schema<GetRatePlanRequest>;
export type RatePlansGetResultItemComponentsItemName = "zones" | "page_rules" | "dedicated_certificates" | "dedicated_certificates_custom";
export declare const RatePlansGetResultItemComponentsItemName: any;
export interface RatePlansGetResultItemComponentsItem {
    /** The default amount allocated. */
    default?: number | null;
    /** The unique component. */
    name?: RatePlansGetResultItemComponentsItemName | null;
    /** The unit price of the addon. */
    unitPrice?: number | null;
}
export declare const RatePlansGetResultItemComponentsItem: S.Schema<RatePlansGetResultItemComponentsItem>;
export type RatePlansGetResultItemComponentsList = Array<RatePlansGetResultItemComponentsItem>;
export declare const RatePlansGetResultItemComponentsList: S.Schema<RatePlansGetResultItemComponentsList>;
export type RatePlansGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const RatePlansGetResultItemFrequency: any;
export interface RatePlansGetResultItem {
    /** Plan identifier tag. */
    id?: string | null;
    /** Array of available components values for the plan. */
    components?: RatePlansGetResultItemComponentsList | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The duration of the plan subscription. */
    duration?: number | null;
    /** The frequency at which you will be billed for this plan. */
    frequency?: RatePlansGetResultItemFrequency | null;
    /** The plan name. */
    name?: string | null;
}
export declare const RatePlansGetResultItem: S.Schema<RatePlansGetResultItem>;
export type RatePlansGetResultList = Array<RatePlansGetResultItem>;
export declare const RatePlansGetResultList: S.Schema<RatePlansGetResultList>;
export interface GetRatePlanResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RatePlansGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetRatePlanResponse: S.Schema<GetRatePlanResponse>;
export interface GetSettingRequest {
    /** Identifier */
    zoneId: string;
    /** Setting name */
    settingId: string;
}
export declare const GetSettingRequest: S.Schema<GetSettingRequest>;
export type SettingsGetResultZeroRTTId = "0rtt";
export declare const SettingsGetResultZeroRTTId: any;
export type SettingsGetResultZeroRTTValue = "on" | "off";
export declare const SettingsGetResultZeroRTTValue: any;
export interface SettingsGetResultZeroRTT {
    /** ID of the zone setting. */
    id: SettingsGetResultZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZeroRTT: S.Schema<SettingsGetResultZeroRTT>;
export type SettingsGetResultAdvancedDDoSId = "advanced_ddos";
export declare const SettingsGetResultAdvancedDDoSId: any;
export type SettingsGetResultAdvancedDDoSValue = "on" | "off";
export declare const SettingsGetResultAdvancedDDoSValue: any;
export interface SettingsGetResultAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsGetResultAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsGetResultAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultAdvancedDDoS: S.Schema<SettingsGetResultAdvancedDDoS>;
export type SettingsGetResultZonesCacheRulesAegisId = "aegis";
export declare const SettingsGetResultZonesCacheRulesAegisId: any;
export interface SettingsGetResultZonesCacheRulesAegisValue {
    /** Whether the feature is enabled or not. */
    enabled?: boolean | null;
    /** Egress pool id which refers to a grouping of dedicated egress IPs through which Cloudflare will connect to origin. */
    poolId?: string | null;
}
export declare const SettingsGetResultZonesCacheRulesAegisValue: S.Schema<SettingsGetResultZonesCacheRulesAegisValue>;
export interface SettingsGetResultZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export declare const SettingsGetResultZonesCacheRulesAegis: S.Schema<SettingsGetResultZonesCacheRulesAegis>;
export type SettingsGetResultAlwaysOnlineId = "always_online";
export declare const SettingsGetResultAlwaysOnlineId: any;
export type SettingsGetResultAlwaysOnlineValue = "on" | "off";
export declare const SettingsGetResultAlwaysOnlineValue: any;
export interface SettingsGetResultAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsGetResultAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsGetResultAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultAlwaysOnline: S.Schema<SettingsGetResultAlwaysOnline>;
export type SettingsGetResultZonesSchemasAlwaysUseHTTPSId = "always_use_https";
export declare const SettingsGetResultZonesSchemasAlwaysUseHTTPSId: any;
export type SettingsGetResultZonesSchemasAlwaysUseHTTPSValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasAlwaysUseHTTPSValue: any;
export interface SettingsGetResultZonesSchemasAlwaysUseHTTPS {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasAlwaysUseHTTPSId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasAlwaysUseHTTPSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasAlwaysUseHTTPS: S.Schema<SettingsGetResultZonesSchemasAlwaysUseHTTPS>;
export type SettingsGetResultZonesSchemasAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const SettingsGetResultZonesSchemasAutomaticHTTPSRewritesId: any;
export type SettingsGetResultZonesSchemasAutomaticHTTPSRewritesValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasAutomaticHTTPSRewritesValue: any;
export interface SettingsGetResultZonesSchemasAutomaticHTTPSRewrites {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasAutomaticHTTPSRewritesId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasAutomaticHTTPSRewritesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasAutomaticHTTPSRewrites: S.Schema<SettingsGetResultZonesSchemasAutomaticHTTPSRewrites>;
export type SettingsGetResultBrotliId = "brotli";
export declare const SettingsGetResultBrotliId: any;
export type SettingsGetResultBrotliValue = "off" | "on";
export declare const SettingsGetResultBrotliValue: any;
export interface SettingsGetResultBrotli {
    /** ID of the zone setting. */
    id: SettingsGetResultBrotliId;
    /** Current value of the zone setting. */
    value: SettingsGetResultBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultBrotli: S.Schema<SettingsGetResultBrotli>;
export type SettingsGetResultZonesSchemasBrowserCacheTTLId = "browser_cache_ttl";
export declare const SettingsGetResultZonesSchemasBrowserCacheTTLId: any;
export interface SettingsGetResultZonesSchemasBrowserCacheTTL {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasBrowserCacheTTLId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasBrowserCacheTTL: S.Schema<SettingsGetResultZonesSchemasBrowserCacheTTL>;
export type SettingsGetResultZonesSchemasBrowserCheckId = "browser_check";
export declare const SettingsGetResultZonesSchemasBrowserCheckId: any;
export type SettingsGetResultZonesSchemasBrowserCheckValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasBrowserCheckValue: any;
export interface SettingsGetResultZonesSchemasBrowserCheck {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasBrowserCheckId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasBrowserCheckValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasBrowserCheck: S.Schema<SettingsGetResultZonesSchemasBrowserCheck>;
export type SettingsGetResultZonesSchemasCacheLevelId = "cache_level";
export declare const SettingsGetResultZonesSchemasCacheLevelId: any;
export type SettingsGetResultZonesSchemasCacheLevelValue = "aggressive" | "basic" | "simplified";
export declare const SettingsGetResultZonesSchemasCacheLevelValue: any;
export interface SettingsGetResultZonesSchemasCacheLevel {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasCacheLevelId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasCacheLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasCacheLevel: S.Schema<SettingsGetResultZonesSchemasCacheLevel>;
export type SettingsGetResultChallengeTTLId = "challenge_ttl";
export declare const SettingsGetResultChallengeTTLId: any;
export type SettingsGetResultChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export declare const SettingsGetResultChallengeTTLValue: any;
export interface SettingsGetResultChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsGetResultChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsGetResultChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultChallengeTTL: S.Schema<SettingsGetResultChallengeTTL>;
export type SettingsGetResultZonesChinaNetworkEnabledId = "china_network_enabled";
export declare const SettingsGetResultZonesChinaNetworkEnabledId: any;
export type SettingsGetResultZonesChinaNetworkEnabledValue = "on" | "off";
export declare const SettingsGetResultZonesChinaNetworkEnabledValue: any;
export interface SettingsGetResultZonesChinaNetworkEnabled {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesChinaNetworkEnabledId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesChinaNetworkEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesChinaNetworkEnabled: S.Schema<SettingsGetResultZonesChinaNetworkEnabled>;
export type SettingsGetResultZonesContentConverterId = "content_converter";
export declare const SettingsGetResultZonesContentConverterId: any;
export type SettingsGetResultZonesContentConverterValue = "off" | "on";
export declare const SettingsGetResultZonesContentConverterValue: any;
export interface SettingsGetResultZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesContentConverter: S.Schema<SettingsGetResultZonesContentConverter>;
export type SettingsGetResultCiphersId = "ciphers";
export declare const SettingsGetResultCiphersId: any;
export type SettingsGetResultCiphersValueList = Array<string>;
export declare const SettingsGetResultCiphersValueList: S.Schema<SettingsGetResultCiphersValueList>;
export interface SettingsGetResultCiphers {
    /** ID of the zone setting. */
    id: SettingsGetResultCiphersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultCiphers: S.Schema<SettingsGetResultCiphers>;
export type SettingsGetResultZonesCNAMEFlatteningId = "cname_flattening";
export declare const SettingsGetResultZonesCNAMEFlatteningId: any;
export type SettingsGetResultZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export declare const SettingsGetResultZonesCNAMEFlatteningValue: any;
export interface SettingsGetResultZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsGetResultZonesCNAMEFlatteningId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesCNAMEFlattening: S.Schema<SettingsGetResultZonesCNAMEFlattening>;
export type SettingsGetResultDevelopmentModeId = "development_mode";
export declare const SettingsGetResultDevelopmentModeId: any;
export type SettingsGetResultDevelopmentModeValue = "on" | "off";
export declare const SettingsGetResultDevelopmentModeValue: any;
export interface SettingsGetResultDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsGetResultDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsGetResultDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    timeRemaining?: number | null;
}
export declare const SettingsGetResultDevelopmentMode: S.Schema<SettingsGetResultDevelopmentMode>;
export type SettingsGetResultEarlyHintsId = "early_hints";
export declare const SettingsGetResultEarlyHintsId: any;
export type SettingsGetResultEarlyHintsValue = "on" | "off";
export declare const SettingsGetResultEarlyHintsValue: any;
export interface SettingsGetResultEarlyHints {
    /** ID of the zone setting. */
    id: SettingsGetResultEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsGetResultEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultEarlyHints: S.Schema<SettingsGetResultEarlyHints>;
export type SettingsGetResultZonesSchemasEdgeCacheTTLId = "edge_cache_ttl";
export declare const SettingsGetResultZonesSchemasEdgeCacheTTLId: any;
export type SettingsGetResultZonesSchemasEdgeCacheTTLValue = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export declare const SettingsGetResultZonesSchemasEdgeCacheTTLValue: any;
export interface SettingsGetResultZonesSchemasEdgeCacheTTL {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasEdgeCacheTTLId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasEdgeCacheTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasEdgeCacheTTL: S.Schema<SettingsGetResultZonesSchemasEdgeCacheTTL>;
export type SettingsGetResultZonesSchemasEmailObfuscationId = "email_obfuscation";
export declare const SettingsGetResultZonesSchemasEmailObfuscationId: any;
export type SettingsGetResultZonesSchemasEmailObfuscationValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasEmailObfuscationValue: any;
export interface SettingsGetResultZonesSchemasEmailObfuscation {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasEmailObfuscationId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasEmailObfuscationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasEmailObfuscation: S.Schema<SettingsGetResultZonesSchemasEmailObfuscation>;
export type SettingsGetResultH2PrioritizationId = "h2_prioritization";
export declare const SettingsGetResultH2PrioritizationId: any;
export type SettingsGetResultH2PrioritizationValue = "on" | "off" | "custom";
export declare const SettingsGetResultH2PrioritizationValue: any;
export interface SettingsGetResultH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsGetResultH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsGetResultH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultH2Prioritization: S.Schema<SettingsGetResultH2Prioritization>;
export type SettingsGetResultHotlinkProtectionId = "hotlink_protection";
export declare const SettingsGetResultHotlinkProtectionId: any;
export type SettingsGetResultHotlinkProtectionValue = "on" | "off";
export declare const SettingsGetResultHotlinkProtectionValue: any;
export interface SettingsGetResultHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsGetResultHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultHotlinkProtection: S.Schema<SettingsGetResultHotlinkProtection>;
export type SettingsGetResultHTTP2Id = "http2";
export declare const SettingsGetResultHTTP2Id: any;
export type SettingsGetResultHTTP2Value = "on" | "off";
export declare const SettingsGetResultHTTP2Value: any;
export interface SettingsGetResultHTTP2 {
    /** ID of the zone setting. */
    id: SettingsGetResultHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultHTTP2: S.Schema<SettingsGetResultHTTP2>;
export type SettingsGetResultHTTP3Id = "http3";
export declare const SettingsGetResultHTTP3Id: any;
export type SettingsGetResultHTTP3Value = "on" | "off";
export declare const SettingsGetResultHTTP3Value: any;
export interface SettingsGetResultHTTP3 {
    /** ID of the zone setting. */
    id: SettingsGetResultHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultHTTP3: S.Schema<SettingsGetResultHTTP3>;
export type SettingsGetResultImageResizingId = "image_resizing";
export declare const SettingsGetResultImageResizingId: any;
export type SettingsGetResultImageResizingValue = "on" | "off" | "open";
export declare const SettingsGetResultImageResizingValue: any;
export interface SettingsGetResultImageResizing {
    /** ID of the zone setting. */
    id: SettingsGetResultImageResizingId;
    /** Current value of the zone setting. */
    value: SettingsGetResultImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultImageResizing: S.Schema<SettingsGetResultImageResizing>;
export type SettingsGetResultZonesSchemasIPGeolocationId = "ip_geolocation";
export declare const SettingsGetResultZonesSchemasIPGeolocationId: any;
export type SettingsGetResultZonesSchemasIPGeolocationValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasIPGeolocationValue: any;
export interface SettingsGetResultZonesSchemasIPGeolocation {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasIPGeolocationId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasIPGeolocationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasIPGeolocation: S.Schema<SettingsGetResultZonesSchemasIPGeolocation>;
export type SettingsGetResultIPV6Id = "ipv6";
export declare const SettingsGetResultIPV6Id: any;
export type SettingsGetResultIPV6Value = "off" | "on";
export declare const SettingsGetResultIPV6Value: any;
export interface SettingsGetResultIPV6 {
    /** ID of the zone setting. */
    id: SettingsGetResultIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultIPV6: S.Schema<SettingsGetResultIPV6>;
export type SettingsGetResultZonesMaxUploadId = "max_upload";
export declare const SettingsGetResultZonesMaxUploadId: any;
export type SettingsGetResultZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000;
export declare const SettingsGetResultZonesMaxUploadValue: any;
export interface SettingsGetResultZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsGetResultZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesMaxUpload: S.Schema<SettingsGetResultZonesMaxUpload>;
export type SettingsGetResultMinTLSVersionId = "min_tls_version";
export declare const SettingsGetResultMinTLSVersionId: any;
export type SettingsGetResultMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export declare const SettingsGetResultMinTLSVersionValue: any;
export interface SettingsGetResultMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsGetResultMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultMinTLSVersion: S.Schema<SettingsGetResultMinTLSVersion>;
export type SettingsGetResultZonesSchemasMirageId = "mirage";
export declare const SettingsGetResultZonesSchemasMirageId: any;
export type SettingsGetResultZonesSchemasMirageValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasMirageValue: any;
export interface SettingsGetResultZonesSchemasMirage {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasMirageId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasMirageValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasMirage: S.Schema<SettingsGetResultZonesSchemasMirage>;
export type SettingsGetResultNELId = "nel";
export declare const SettingsGetResultNELId: any;
export interface SettingsGetResultNELValue {
    enabled?: boolean | null;
}
export declare const SettingsGetResultNELValue: S.Schema<SettingsGetResultNELValue>;
export interface SettingsGetResultNEL {
    /** Zone setting identifier. */
    id: SettingsGetResultNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultNEL: S.Schema<SettingsGetResultNEL>;
export type SettingsGetResultZonesSchemasOpportunisticEncryptionId = "opportunistic_encryption";
export declare const SettingsGetResultZonesSchemasOpportunisticEncryptionId: any;
export type SettingsGetResultZonesSchemasOpportunisticEncryptionValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasOpportunisticEncryptionValue: any;
export interface SettingsGetResultZonesSchemasOpportunisticEncryption {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasOpportunisticEncryptionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasOpportunisticEncryptionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasOpportunisticEncryption: S.Schema<SettingsGetResultZonesSchemasOpportunisticEncryption>;
export type SettingsGetResultOpportunisticOnionId = "opportunistic_onion";
export declare const SettingsGetResultOpportunisticOnionId: any;
export type SettingsGetResultOpportunisticOnionValue = "on" | "off";
export declare const SettingsGetResultOpportunisticOnionValue: any;
export interface SettingsGetResultOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsGetResultOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsGetResultOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultOpportunisticOnion: S.Schema<SettingsGetResultOpportunisticOnion>;
export type SettingsGetResultOrangeToOrangeId = "orange_to_orange";
export declare const SettingsGetResultOrangeToOrangeId: any;
export type SettingsGetResultOrangeToOrangeValue = "on" | "off";
export declare const SettingsGetResultOrangeToOrangeValue: any;
export interface SettingsGetResultOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsGetResultOrangeToOrangeId;
    /** Current value of the zone setting. */
    value: SettingsGetResultOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultOrangeToOrange: S.Schema<SettingsGetResultOrangeToOrange>;
export type SettingsGetResultZonesSchemasOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const SettingsGetResultZonesSchemasOriginErrorPagePassThruId: any;
export type SettingsGetResultZonesSchemasOriginErrorPagePassThruValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasOriginErrorPagePassThruValue: any;
export interface SettingsGetResultZonesSchemasOriginErrorPagePassThru {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasOriginErrorPagePassThruId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasOriginErrorPagePassThruValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasOriginErrorPagePassThru: S.Schema<SettingsGetResultZonesSchemasOriginErrorPagePassThru>;
export type SettingsGetResultZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export declare const SettingsGetResultZonesCacheRulesOriginH2MaxStreamsId: any;
export interface SettingsGetResultZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsGetResultZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export declare const SettingsGetResultZonesCacheRulesOriginH2MaxStreams: S.Schema<SettingsGetResultZonesCacheRulesOriginH2MaxStreams>;
export type SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export declare const SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionId: any;
export type SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export declare const SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionValue: any;
export interface SettingsGetResultZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsGetResultZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export declare const SettingsGetResultZonesCacheRulesOriginMaxHTTPVersion: S.Schema<SettingsGetResultZonesCacheRulesOriginMaxHTTPVersion>;
export type SettingsGetResultZonesSchemasPolishId = "polish";
export declare const SettingsGetResultZonesSchemasPolishId: any;
export type SettingsGetResultZonesSchemasPolishValue = "off" | "lossless" | "lossy";
export declare const SettingsGetResultZonesSchemasPolishValue: any;
export interface SettingsGetResultZonesSchemasPolish {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasPolishId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasPolishValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasPolish: S.Schema<SettingsGetResultZonesSchemasPolish>;
export type SettingsGetResultPrefetchPreloadId = "prefetch_preload";
export declare const SettingsGetResultPrefetchPreloadId: any;
export type SettingsGetResultPrefetchPreloadValue = "on" | "off";
export declare const SettingsGetResultPrefetchPreloadValue: any;
export interface SettingsGetResultPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsGetResultPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsGetResultPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultPrefetchPreload: S.Schema<SettingsGetResultPrefetchPreload>;
export type SettingsGetResultZonesPrivacyPassId = "privacy_pass";
export declare const SettingsGetResultZonesPrivacyPassId: any;
export type SettingsGetResultZonesPrivacyPassValue = "on" | "off";
export declare const SettingsGetResultZonesPrivacyPassValue: any;
export interface SettingsGetResultZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesPrivacyPassId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesPrivacyPass: S.Schema<SettingsGetResultZonesPrivacyPass>;
export type SettingsGetResultProxyReadTimeoutId = "proxy_read_timeout";
export declare const SettingsGetResultProxyReadTimeoutId: any;
export interface SettingsGetResultProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsGetResultProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultProxyReadTimeout: S.Schema<SettingsGetResultProxyReadTimeout>;
export type SettingsGetResultPseudoIPV4Id = "pseudo_ipv4";
export declare const SettingsGetResultPseudoIPV4Id: any;
export type SettingsGetResultPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export declare const SettingsGetResultPseudoIPV4Value: any;
export interface SettingsGetResultPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsGetResultPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultPseudoIPV4: S.Schema<SettingsGetResultPseudoIPV4>;
export type SettingsGetResultZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export declare const SettingsGetResultZonesRedirectsForAITrainingId: any;
export type SettingsGetResultZonesRedirectsForAITrainingValue = "off" | "on";
export declare const SettingsGetResultZonesRedirectsForAITrainingValue: any;
export interface SettingsGetResultZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesRedirectsForAITraining: S.Schema<SettingsGetResultZonesRedirectsForAITraining>;
export type SettingsGetResultZonesReplaceInsecureJSId = "replace_insecure_js";
export declare const SettingsGetResultZonesReplaceInsecureJSId: any;
export type SettingsGetResultZonesReplaceInsecureJSValue = "on" | "off";
export declare const SettingsGetResultZonesReplaceInsecureJSValue: any;
export interface SettingsGetResultZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesReplaceInsecureJS: S.Schema<SettingsGetResultZonesReplaceInsecureJS>;
export type SettingsGetResultZonesSchemasResponseBufferingId = "response_buffering";
export declare const SettingsGetResultZonesSchemasResponseBufferingId: any;
export type SettingsGetResultZonesSchemasResponseBufferingValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasResponseBufferingValue: any;
export interface SettingsGetResultZonesSchemasResponseBuffering {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasResponseBufferingId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasResponseBufferingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasResponseBuffering: S.Schema<SettingsGetResultZonesSchemasResponseBuffering>;
export type SettingsGetResultZonesSchemasRocketLoaderId = "rocket_loader";
export declare const SettingsGetResultZonesSchemasRocketLoaderId: any;
export type SettingsGetResultZonesSchemasRocketLoaderValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasRocketLoaderValue: any;
export interface SettingsGetResultZonesSchemasRocketLoader {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasRocketLoaderId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasRocketLoaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasRocketLoader: S.Schema<SettingsGetResultZonesSchemasRocketLoader>;
export type SettingsGetResultZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export declare const SettingsGetResultZonesSchemasAutomaticPlatformOptimizationId: any;
export type SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export declare const SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList: S.Schema<SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList>;
export interface SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export declare const SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValue: S.Schema<SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValue>;
export interface SettingsGetResultZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasAutomaticPlatformOptimization: S.Schema<SettingsGetResultZonesSchemasAutomaticPlatformOptimization>;
export type SettingsGetResultZonesSearchForAgentsId = "search_for_agents";
export declare const SettingsGetResultZonesSearchForAgentsId: any;
export type SettingsGetResultZonesSearchForAgentsValue = "off" | "on";
export declare const SettingsGetResultZonesSearchForAgentsValue: any;
export interface SettingsGetResultZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSearchForAgents: S.Schema<SettingsGetResultZonesSearchForAgents>;
export type SettingsGetResultSecurityHeadersId = "security_header";
export declare const SettingsGetResultSecurityHeadersId: any;
export interface SettingsGetResultSecurityHeadersValueStrictTransportSecurity {
    /** Whether or not strict transport security is enabled. */
    enabled?: boolean | null;
    /** Include all subdomains for strict transport security. */
    includeSubdomains?: boolean | null;
    /** Max age in seconds of the strict transport security. */
    maxAge?: number | null;
    /** Whether or not to include 'X-Content-Type-Options: nosniff' header. */
    nosniff?: boolean | null;
    /** Enable automatic preload of the HSTS configuration. */
    preload?: boolean | null;
}
export declare const SettingsGetResultSecurityHeadersValueStrictTransportSecurity: S.Schema<SettingsGetResultSecurityHeadersValueStrictTransportSecurity>;
export interface SettingsGetResultSecurityHeadersValue {
    /** Strict Transport Security. */
    strictTransportSecurity?: SettingsGetResultSecurityHeadersValueStrictTransportSecurity | null;
}
export declare const SettingsGetResultSecurityHeadersValue: S.Schema<SettingsGetResultSecurityHeadersValue>;
export interface SettingsGetResultSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsGetResultSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultSecurityHeaders: S.Schema<SettingsGetResultSecurityHeaders>;
export type SettingsGetResultZonesSchemasSecurityLevelId = "security_level";
export declare const SettingsGetResultZonesSchemasSecurityLevelId: any;
export type SettingsGetResultZonesSchemasSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const SettingsGetResultZonesSchemasSecurityLevelValue: any;
export interface SettingsGetResultZonesSchemasSecurityLevel {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasSecurityLevelId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasSecurityLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasSecurityLevel: S.Schema<SettingsGetResultZonesSchemasSecurityLevel>;
export type SettingsGetResultServerSideExcludesId = "server_side_exclude";
export declare const SettingsGetResultServerSideExcludesId: any;
export type SettingsGetResultServerSideExcludesValue = "on" | "off";
export declare const SettingsGetResultServerSideExcludesValue: any;
export interface SettingsGetResultServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsGetResultServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsGetResultServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultServerSideExcludes: S.Schema<SettingsGetResultServerSideExcludes>;
export type SettingsGetResultZonesSha1SupportId = "sha1_support";
export declare const SettingsGetResultZonesSha1SupportId: any;
export type SettingsGetResultZonesSha1SupportValue = "off" | "on";
export declare const SettingsGetResultZonesSha1SupportValue: any;
export interface SettingsGetResultZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsGetResultZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSha1Support: S.Schema<SettingsGetResultZonesSha1Support>;
export type SettingsGetResultZonesSchemasSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const SettingsGetResultZonesSchemasSortQueryStringForCacheId: any;
export type SettingsGetResultZonesSchemasSortQueryStringForCacheValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasSortQueryStringForCacheValue: any;
export interface SettingsGetResultZonesSchemasSortQueryStringForCache {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasSortQueryStringForCacheId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasSortQueryStringForCacheValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasSortQueryStringForCache: S.Schema<SettingsGetResultZonesSchemasSortQueryStringForCache>;
export type SettingsGetResultZonesSchemasSSLId = "ssl";
export declare const SettingsGetResultZonesSchemasSSLId: any;
export type SettingsGetResultZonesSchemasSSLValue = "off" | "flexible" | "full" | "strict";
export declare const SettingsGetResultZonesSchemasSSLValue: any;
export interface SettingsGetResultZonesSchemasSSL {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasSSLId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasSSLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasSSL: S.Schema<SettingsGetResultZonesSchemasSSL>;
export type SettingsGetResultSSLRecommenderId = "ssl_recommender";
export declare const SettingsGetResultSSLRecommenderId: any;
export interface SettingsGetResultSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsGetResultSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export declare const SettingsGetResultSSLRecommender: S.Schema<SettingsGetResultSSLRecommender>;
export type SettingsGetResultZonesTLS12OnlyId = "tls_1_2_only";
export declare const SettingsGetResultZonesTLS12OnlyId: any;
export type SettingsGetResultZonesTLS12OnlyValue = "off" | "on";
export declare const SettingsGetResultZonesTLS12OnlyValue: any;
export interface SettingsGetResultZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsGetResultZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesTLS12Only: S.Schema<SettingsGetResultZonesTLS12Only>;
export type SettingsGetResultTLS13Id = "tls_1_3";
export declare const SettingsGetResultTLS13Id: any;
export type SettingsGetResultTLS13Value = "on" | "off" | "zrt";
export declare const SettingsGetResultTLS13Value: any;
export interface SettingsGetResultTLS13 {
    /** ID of the zone setting. */
    id: SettingsGetResultTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsGetResultTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultTLS13: S.Schema<SettingsGetResultTLS13>;
export type SettingsGetResultTLSClientAuthId = "tls_client_auth";
export declare const SettingsGetResultTLSClientAuthId: any;
export type SettingsGetResultTLSClientAuthValue = "on" | "off";
export declare const SettingsGetResultTLSClientAuthValue: any;
export interface SettingsGetResultTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsGetResultTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsGetResultTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultTLSClientAuth: S.Schema<SettingsGetResultTLSClientAuth>;
export type SettingsGetResultZonesTransformationsId = "transformations";
export declare const SettingsGetResultZonesTransformationsId: any;
export type SettingsGetResultZonesTransformationsValue = "on" | "off" | "open";
export declare const SettingsGetResultZonesTransformationsValue: any;
export interface SettingsGetResultZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsGetResultZonesTransformationsId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesTransformations: S.Schema<SettingsGetResultZonesTransformations>;
export type SettingsGetResultZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export declare const SettingsGetResultZonesTransformationsAllowedOriginsId: any;
export interface SettingsGetResultZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsGetResultZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesTransformationsAllowedOrigins: S.Schema<SettingsGetResultZonesTransformationsAllowedOrigins>;
export type SettingsGetResultZonesSchemasTrueClientIPHeaderId = "true_client_ip_header";
export declare const SettingsGetResultZonesSchemasTrueClientIPHeaderId: any;
export type SettingsGetResultZonesSchemasTrueClientIPHeaderValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasTrueClientIPHeaderValue: any;
export interface SettingsGetResultZonesSchemasTrueClientIPHeader {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasTrueClientIPHeaderId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasTrueClientIPHeaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasTrueClientIPHeader: S.Schema<SettingsGetResultZonesSchemasTrueClientIPHeader>;
export type SettingsGetResultZonesSchemasWAFId = "waf";
export declare const SettingsGetResultZonesSchemasWAFId: any;
export type SettingsGetResultZonesSchemasWAFValue = "on" | "off";
export declare const SettingsGetResultZonesSchemasWAFValue: any;
export interface SettingsGetResultZonesSchemasWAF {
    /** ID of the zone setting. */
    id: SettingsGetResultZonesSchemasWAFId;
    /** Current value of the zone setting. */
    value: SettingsGetResultZonesSchemasWAFValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultZonesSchemasWAF: S.Schema<SettingsGetResultZonesSchemasWAF>;
export type SettingsGetResultWebPId = "webp";
export declare const SettingsGetResultWebPId: any;
export type SettingsGetResultWebPValue = "off" | "on";
export declare const SettingsGetResultWebPValue: any;
export interface SettingsGetResultWebP {
    /** ID of the zone setting. */
    id: SettingsGetResultWebPId;
    /** Current value of the zone setting. */
    value: SettingsGetResultWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultWebP: S.Schema<SettingsGetResultWebP>;
export type SettingsGetResultWebsocketId = "websockets";
export declare const SettingsGetResultWebsocketId: any;
export type SettingsGetResultWebsocketValue = "off" | "on";
export declare const SettingsGetResultWebsocketValue: any;
export interface SettingsGetResultWebsocket {
    /** ID of the zone setting. */
    id: SettingsGetResultWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsGetResultWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsGetResultWebsocket: S.Schema<SettingsGetResultWebsocket>;
export type SettingsGetResult = SettingsGetResultZeroRTT | SettingsGetResultAdvancedDDoS | SettingsGetResultZonesCacheRulesAegis | SettingsGetResultAlwaysOnline | SettingsGetResultZonesSchemasAlwaysUseHTTPS | SettingsGetResultZonesSchemasAutomaticHTTPSRewrites | SettingsGetResultBrotli | SettingsGetResultZonesSchemasBrowserCacheTTL | SettingsGetResultZonesSchemasBrowserCheck | SettingsGetResultZonesSchemasCacheLevel | SettingsGetResultChallengeTTL | SettingsGetResultZonesChinaNetworkEnabled | SettingsGetResultZonesContentConverter | SettingsGetResultCiphers | SettingsGetResultZonesCNAMEFlattening | SettingsGetResultDevelopmentMode | SettingsGetResultEarlyHints | SettingsGetResultZonesSchemasEdgeCacheTTL | SettingsGetResultZonesSchemasEmailObfuscation | SettingsGetResultH2Prioritization | SettingsGetResultHotlinkProtection | SettingsGetResultHTTP2 | SettingsGetResultHTTP3 | SettingsGetResultImageResizing | SettingsGetResultZonesSchemasIPGeolocation | SettingsGetResultIPV6 | SettingsGetResultZonesMaxUpload | SettingsGetResultMinTLSVersion | SettingsGetResultZonesSchemasMirage | SettingsGetResultNEL | SettingsGetResultZonesSchemasOpportunisticEncryption | SettingsGetResultOpportunisticOnion | SettingsGetResultOrangeToOrange | SettingsGetResultZonesSchemasOriginErrorPagePassThru | SettingsGetResultZonesCacheRulesOriginH2MaxStreams | SettingsGetResultZonesCacheRulesOriginMaxHTTPVersion | SettingsGetResultZonesSchemasPolish | SettingsGetResultPrefetchPreload | SettingsGetResultZonesPrivacyPass | SettingsGetResultProxyReadTimeout | SettingsGetResultPseudoIPV4 | SettingsGetResultZonesRedirectsForAITraining | SettingsGetResultZonesReplaceInsecureJS | SettingsGetResultZonesSchemasResponseBuffering | SettingsGetResultZonesSchemasRocketLoader | SettingsGetResultZonesSchemasAutomaticPlatformOptimization | SettingsGetResultZonesSearchForAgents | SettingsGetResultSecurityHeaders | SettingsGetResultZonesSchemasSecurityLevel | SettingsGetResultServerSideExcludes | SettingsGetResultZonesSha1Support | SettingsGetResultZonesSchemasSortQueryStringForCache | SettingsGetResultZonesSchemasSSL | SettingsGetResultSSLRecommender | SettingsGetResultZonesTLS12Only | SettingsGetResultTLS13 | SettingsGetResultTLSClientAuth | SettingsGetResultZonesTransformations | SettingsGetResultZonesTransformationsAllowedOrigins | SettingsGetResultZonesSchemasTrueClientIPHeader | SettingsGetResultZonesSchemasWAF | SettingsGetResultWebP | SettingsGetResultWebsocket;
export declare const SettingsGetResult: any;
export type GetSettingResponse = SettingsGetResult;
export declare const GetSettingResponse: S.Schema<GetSettingResponse>;
export interface GetSubscriptionRequest {
    /** Identifier */
    zoneId: string;
}
export declare const GetSubscriptionRequest: S.Schema<GetSubscriptionRequest>;
export type SubscriptionsGetResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly" | "not-applicable";
export declare const SubscriptionsGetResponseFrequency: any;
export type SubscriptionsGetResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsGetResponseRatePlanId: any;
export type SubscriptionsGetResponseRatePlanSetsList = Array<string>;
export declare const SubscriptionsGetResponseRatePlanSetsList: S.Schema<SubscriptionsGetResponseRatePlanSetsList>;
export interface SubscriptionsGetResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResponseRatePlanSetsList | null;
}
export declare const SubscriptionsGetResponseRatePlan: S.Schema<SubscriptionsGetResponseRatePlan>;
export type SubscriptionsGetResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsGetResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResponseState | null;
}
export declare const GetSubscriptionResponse: S.Schema<GetSubscriptionResponse>;
export interface GetZoneRequest {
    /** Identifier */
    zoneId: string;
}
export declare const GetZoneRequest: S.Schema<GetZoneRequest>;
export type GetResponseAccount = CreateResponseAccount;
export declare const GetResponseAccount: S.Schema<CreateResponseAccount>;
export type GetResponseMeta = CreateResponseMeta;
export declare const GetResponseMeta: S.Schema<CreateResponseMeta>;
export type GetResponseNameServersList = Array<string>;
export declare const GetResponseNameServersList: S.Schema<GetResponseNameServersList>;
export type GetResponseOriginalNameServersList = Array<string>;
export declare const GetResponseOriginalNameServersList: S.Schema<GetResponseOriginalNameServersList>;
export type GetResponseOwner = CreateResponseOwner;
export declare const GetResponseOwner: S.Schema<CreateResponseOwner>;
export type GetResponsePlan = CreateResponsePlan;
export declare const GetResponsePlan: S.Schema<CreateResponsePlan>;
export type GetResponsePermissionsList = Array<string>;
export declare const GetResponsePermissionsList: S.Schema<GetResponsePermissionsList>;
export type GetResponseStatus = "initializing" | "pending" | "active" | "moved";
export declare const GetResponseStatus: any;
export type GetResponseTenant = CreateResponseTenant;
export declare const GetResponseTenant: S.Schema<CreateResponseTenant>;
export type GetResponseTenantUnit = CreateResponseTenantUnit;
export declare const GetResponseTenantUnit: S.Schema<CreateResponseTenantUnit>;
export type GetResponseType = "full" | "partial" | "secondary" | "internal";
export declare const GetResponseType: any;
export type GetResponseVanityNameServersList = Array<string>;
export declare const GetResponseVanityNameServersList: S.Schema<GetResponseVanityNameServersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneResponse {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: GetResponseNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: GetResponseOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** A Zones subscription information. */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A */
    paused?: boolean | null;
    /** Legacy permissions based on legacy user membership information. */
    permissions?: GetResponsePermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: GetResponseStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is */
    type?: GetResponseType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: GetResponseVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export declare const GetZoneResponse: S.Schema<GetZoneResponse>;
export interface ListEnvironmentsRequest {
    zoneId: string;
}
export declare const ListEnvironmentsRequest: S.Schema<ListEnvironmentsRequest>;
export type EnvironmentsListResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export declare const EnvironmentsListResponseEnvironmentsItemPosition: S.Schema<EnvironmentsCreateResponseEnvironmentsItemPosition>;
export type EnvironmentsListResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export declare const EnvironmentsListResponseEnvironmentsItem: S.Schema<EnvironmentsCreateResponseEnvironmentsItem>;
export type EnvironmentsListResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
export declare const EnvironmentsListResponseEnvironmentsList: S.Schema<EnvironmentsListResponseEnvironmentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListEnvironmentsResponse {
    environments: EnvironmentsListResponseEnvironmentsList;
}
export declare const ListEnvironmentsResponse: S.Schema<ListEnvironmentsResponse>;
export interface ListPlansRequest {
    /** Identifier */
    zoneId: string;
}
export declare const ListPlansRequest: S.Schema<ListPlansRequest>;
export type PlansListResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const PlansListResultItemFrequency: any;
export interface PlansListResultItem {
    /** Identifier */
    id?: string | null;
    /** Indicates whether you can subscribe to this plan. */
    canSubscribe?: boolean | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** Indicates whether this plan is managed externally. */
    externallyManaged?: boolean | null;
    /** The frequency at which you will be billed for this plan. */
    frequency?: PlansListResultItemFrequency | null;
    /** Indicates whether you are currently subscribed to this plan. */
    isSubscribed?: boolean | null;
    /** Indicates whether this plan has a legacy discount applied. */
    legacyDiscount?: boolean | null;
    /** The legacy identifier for this rate plan, if any. */
    legacyId?: string | null;
    /** The plan name. */
    name?: string | null;
    /** The amount you will be billed for this plan. */
    price?: number | null;
}
export declare const PlansListResultItem: S.Schema<PlansListResultItem>;
export type PlansListResultList = Array<PlansListResultItem>;
export declare const PlansListResultList: S.Schema<PlansListResultList>;
export interface ListPlansResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PlansListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPlansResponse: S.Schema<ListPlansResponse>;
export interface ListSettingsRequest {
    /** Identifier */
    zoneId: string;
}
export declare const ListSettingsRequest: S.Schema<ListSettingsRequest>;
export type ListSettingsResultItemZeroRTTId = "0rtt";
export declare const ListSettingsResultItemZeroRTTId: any;
export type ListSettingsResultItemZeroRTTValue = "on" | "off";
export declare const ListSettingsResultItemZeroRTTValue: any;
export interface ListSettingsResultItemZeroRTT {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZeroRTTId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZeroRTT: S.Schema<ListSettingsResultItemZeroRTT>;
export type ListSettingsResultItemAdvancedDDoSId = "advanced_ddos";
export declare const ListSettingsResultItemAdvancedDDoSId: any;
export type ListSettingsResultItemAdvancedDDoSValue = "on" | "off";
export declare const ListSettingsResultItemAdvancedDDoSValue: any;
export interface ListSettingsResultItemAdvancedDDoS {
    /** ID of the zone setting. */
    id: ListSettingsResultItemAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemAdvancedDDoS: S.Schema<ListSettingsResultItemAdvancedDDoS>;
export type ListSettingsResultItemZonesCacheRulesAegisId = "aegis";
export declare const ListSettingsResultItemZonesCacheRulesAegisId: any;
export type ListSettingsResultItemZonesCacheRulesAegisValue = SettingsGetResultZonesCacheRulesAegisValue;
export declare const ListSettingsResultItemZonesCacheRulesAegisValue: S.Schema<SettingsGetResultZonesCacheRulesAegisValue>;
export interface ListSettingsResultItemZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export declare const ListSettingsResultItemZonesCacheRulesAegis: S.Schema<ListSettingsResultItemZonesCacheRulesAegis>;
export type ListSettingsResultItemAlwaysOnlineId = "always_online";
export declare const ListSettingsResultItemAlwaysOnlineId: any;
export type ListSettingsResultItemAlwaysOnlineValue = "on" | "off";
export declare const ListSettingsResultItemAlwaysOnlineValue: any;
export interface ListSettingsResultItemAlwaysOnline {
    /** ID of the zone setting. */
    id: ListSettingsResultItemAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemAlwaysOnline: S.Schema<ListSettingsResultItemAlwaysOnline>;
export type ListSettingsResultItemZonesSchemasAlwaysUseHTTPSId = "always_use_https";
export declare const ListSettingsResultItemZonesSchemasAlwaysUseHTTPSId: any;
export type ListSettingsResultItemZonesSchemasAlwaysUseHTTPSValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasAlwaysUseHTTPSValue: any;
export interface ListSettingsResultItemZonesSchemasAlwaysUseHTTPS {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasAlwaysUseHTTPSId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasAlwaysUseHTTPSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasAlwaysUseHTTPS: S.Schema<ListSettingsResultItemZonesSchemasAlwaysUseHTTPS>;
export type ListSettingsResultItemZonesSchemasAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const ListSettingsResultItemZonesSchemasAutomaticHTTPSRewritesId: any;
export type ListSettingsResultItemZonesSchemasAutomaticHTTPSRewritesValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasAutomaticHTTPSRewritesValue: any;
export interface ListSettingsResultItemZonesSchemasAutomaticHTTPSRewrites {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasAutomaticHTTPSRewritesId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasAutomaticHTTPSRewritesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasAutomaticHTTPSRewrites: S.Schema<ListSettingsResultItemZonesSchemasAutomaticHTTPSRewrites>;
export type ListSettingsResultItemBrotliId = "brotli";
export declare const ListSettingsResultItemBrotliId: any;
export type ListSettingsResultItemBrotliValue = "off" | "on";
export declare const ListSettingsResultItemBrotliValue: any;
export interface ListSettingsResultItemBrotli {
    /** ID of the zone setting. */
    id: ListSettingsResultItemBrotliId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemBrotli: S.Schema<ListSettingsResultItemBrotli>;
export type ListSettingsResultItemZonesSchemasBrowserCacheTTLId = "browser_cache_ttl";
export declare const ListSettingsResultItemZonesSchemasBrowserCacheTTLId: any;
export interface ListSettingsResultItemZonesSchemasBrowserCacheTTL {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasBrowserCacheTTLId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasBrowserCacheTTL: S.Schema<ListSettingsResultItemZonesSchemasBrowserCacheTTL>;
export type ListSettingsResultItemZonesSchemasBrowserCheckId = "browser_check";
export declare const ListSettingsResultItemZonesSchemasBrowserCheckId: any;
export type ListSettingsResultItemZonesSchemasBrowserCheckValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasBrowserCheckValue: any;
export interface ListSettingsResultItemZonesSchemasBrowserCheck {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasBrowserCheckId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasBrowserCheckValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasBrowserCheck: S.Schema<ListSettingsResultItemZonesSchemasBrowserCheck>;
export type ListSettingsResultItemZonesSchemasCacheLevelId = "cache_level";
export declare const ListSettingsResultItemZonesSchemasCacheLevelId: any;
export type ListSettingsResultItemZonesSchemasCacheLevelValue = "aggressive" | "basic" | "simplified";
export declare const ListSettingsResultItemZonesSchemasCacheLevelValue: any;
export interface ListSettingsResultItemZonesSchemasCacheLevel {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasCacheLevelId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasCacheLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasCacheLevel: S.Schema<ListSettingsResultItemZonesSchemasCacheLevel>;
export type ListSettingsResultItemChallengeTTLId = "challenge_ttl";
export declare const ListSettingsResultItemChallengeTTLId: any;
export type ListSettingsResultItemChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export declare const ListSettingsResultItemChallengeTTLValue: any;
export interface ListSettingsResultItemChallengeTTL {
    /** ID of the zone setting. */
    id: ListSettingsResultItemChallengeTTLId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemChallengeTTL: S.Schema<ListSettingsResultItemChallengeTTL>;
export type ListSettingsResultItemCiphersId = "ciphers";
export declare const ListSettingsResultItemCiphersId: any;
export type ListSettingsResultItemCiphersValueList = Array<string>;
export declare const ListSettingsResultItemCiphersValueList: S.Schema<ListSettingsResultItemCiphersValueList>;
export interface ListSettingsResultItemCiphers {
    /** ID of the zone setting. */
    id: ListSettingsResultItemCiphersId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemCiphers: S.Schema<ListSettingsResultItemCiphers>;
export type ListSettingsResultItemZonesContentConverterId = "content_converter";
export declare const ListSettingsResultItemZonesContentConverterId: any;
export type ListSettingsResultItemZonesContentConverterValue = "off" | "on";
export declare const ListSettingsResultItemZonesContentConverterValue: any;
export interface ListSettingsResultItemZonesContentConverter {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesContentConverterId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesContentConverter: S.Schema<ListSettingsResultItemZonesContentConverter>;
export type ListSettingsResultItemZonesCNAMEFlatteningId = "cname_flattening";
export declare const ListSettingsResultItemZonesCNAMEFlatteningId: any;
export type ListSettingsResultItemZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export declare const ListSettingsResultItemZonesCNAMEFlatteningValue: any;
export interface ListSettingsResultItemZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: ListSettingsResultItemZonesCNAMEFlatteningId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesCNAMEFlattening: S.Schema<ListSettingsResultItemZonesCNAMEFlattening>;
export type ListSettingsResultItemDevelopmentModeId = "development_mode";
export declare const ListSettingsResultItemDevelopmentModeId: any;
export type ListSettingsResultItemDevelopmentModeValue = "on" | "off";
export declare const ListSettingsResultItemDevelopmentModeValue: any;
export interface ListSettingsResultItemDevelopmentMode {
    /** ID of the zone setting. */
    id: ListSettingsResultItemDevelopmentModeId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    timeRemaining?: number | null;
}
export declare const ListSettingsResultItemDevelopmentMode: S.Schema<ListSettingsResultItemDevelopmentMode>;
export type ListSettingsResultItemEarlyHintsId = "early_hints";
export declare const ListSettingsResultItemEarlyHintsId: any;
export type ListSettingsResultItemEarlyHintsValue = "on" | "off";
export declare const ListSettingsResultItemEarlyHintsValue: any;
export interface ListSettingsResultItemEarlyHints {
    /** ID of the zone setting. */
    id: ListSettingsResultItemEarlyHintsId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemEarlyHints: S.Schema<ListSettingsResultItemEarlyHints>;
export type ListSettingsResultItemZonesSchemasEdgeCacheTTLId = "edge_cache_ttl";
export declare const ListSettingsResultItemZonesSchemasEdgeCacheTTLId: any;
export type ListSettingsResultItemZonesSchemasEdgeCacheTTLValue = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export declare const ListSettingsResultItemZonesSchemasEdgeCacheTTLValue: any;
export interface ListSettingsResultItemZonesSchemasEdgeCacheTTL {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasEdgeCacheTTLId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasEdgeCacheTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasEdgeCacheTTL: S.Schema<ListSettingsResultItemZonesSchemasEdgeCacheTTL>;
export type ListSettingsResultItemZonesSchemasEmailObfuscationId = "email_obfuscation";
export declare const ListSettingsResultItemZonesSchemasEmailObfuscationId: any;
export type ListSettingsResultItemZonesSchemasEmailObfuscationValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasEmailObfuscationValue: any;
export interface ListSettingsResultItemZonesSchemasEmailObfuscation {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasEmailObfuscationId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasEmailObfuscationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasEmailObfuscation: S.Schema<ListSettingsResultItemZonesSchemasEmailObfuscation>;
export type ListSettingsResultItemH2PrioritizationId = "h2_prioritization";
export declare const ListSettingsResultItemH2PrioritizationId: any;
export type ListSettingsResultItemH2PrioritizationValue = "on" | "off" | "custom";
export declare const ListSettingsResultItemH2PrioritizationValue: any;
export interface ListSettingsResultItemH2Prioritization {
    /** ID of the zone setting. */
    id: ListSettingsResultItemH2PrioritizationId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemH2Prioritization: S.Schema<ListSettingsResultItemH2Prioritization>;
export type ListSettingsResultItemHotlinkProtectionId = "hotlink_protection";
export declare const ListSettingsResultItemHotlinkProtectionId: any;
export type ListSettingsResultItemHotlinkProtectionValue = "on" | "off";
export declare const ListSettingsResultItemHotlinkProtectionValue: any;
export interface ListSettingsResultItemHotlinkProtection {
    /** ID of the zone setting. */
    id: ListSettingsResultItemHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemHotlinkProtection: S.Schema<ListSettingsResultItemHotlinkProtection>;
export type ListSettingsResultItemHTTP2Id = "http2";
export declare const ListSettingsResultItemHTTP2Id: any;
export type ListSettingsResultItemHTTP2Value = "on" | "off";
export declare const ListSettingsResultItemHTTP2Value: any;
export interface ListSettingsResultItemHTTP2 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemHTTP2Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemHTTP2: S.Schema<ListSettingsResultItemHTTP2>;
export type ListSettingsResultItemHTTP3Id = "http3";
export declare const ListSettingsResultItemHTTP3Id: any;
export type ListSettingsResultItemHTTP3Value = "on" | "off";
export declare const ListSettingsResultItemHTTP3Value: any;
export interface ListSettingsResultItemHTTP3 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemHTTP3Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemHTTP3: S.Schema<ListSettingsResultItemHTTP3>;
export type ListSettingsResultItemImageResizingId = "image_resizing";
export declare const ListSettingsResultItemImageResizingId: any;
export type ListSettingsResultItemImageResizingValue = "on" | "off" | "open";
export declare const ListSettingsResultItemImageResizingValue: any;
export interface ListSettingsResultItemImageResizing {
    /** ID of the zone setting. */
    id: ListSettingsResultItemImageResizingId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemImageResizing: S.Schema<ListSettingsResultItemImageResizing>;
export type ListSettingsResultItemZonesSchemasIPGeolocationId = "ip_geolocation";
export declare const ListSettingsResultItemZonesSchemasIPGeolocationId: any;
export type ListSettingsResultItemZonesSchemasIPGeolocationValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasIPGeolocationValue: any;
export interface ListSettingsResultItemZonesSchemasIPGeolocation {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasIPGeolocationId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasIPGeolocationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasIPGeolocation: S.Schema<ListSettingsResultItemZonesSchemasIPGeolocation>;
export type ListSettingsResultItemIPV6Id = "ipv6";
export declare const ListSettingsResultItemIPV6Id: any;
export type ListSettingsResultItemIPV6Value = "off" | "on";
export declare const ListSettingsResultItemIPV6Value: any;
export interface ListSettingsResultItemIPV6 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemIPV6Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemIPV6: S.Schema<ListSettingsResultItemIPV6>;
export type ListSettingsResultItemZonesMaxUploadId = "max_upload";
export declare const ListSettingsResultItemZonesMaxUploadId: any;
export type ListSettingsResultItemZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000;
export declare const ListSettingsResultItemZonesMaxUploadValue: any;
export interface ListSettingsResultItemZonesMaxUpload {
    /** identifier of the zone setting. */
    id: ListSettingsResultItemZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesMaxUpload: S.Schema<ListSettingsResultItemZonesMaxUpload>;
export type ListSettingsResultItemMinTLSVersionId = "min_tls_version";
export declare const ListSettingsResultItemMinTLSVersionId: any;
export type ListSettingsResultItemMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export declare const ListSettingsResultItemMinTLSVersionValue: any;
export interface ListSettingsResultItemMinTLSVersion {
    /** ID of the zone setting. */
    id: ListSettingsResultItemMinTLSVersionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemMinTLSVersion: S.Schema<ListSettingsResultItemMinTLSVersion>;
export type ListSettingsResultItemZonesSchemasMirageId = "mirage";
export declare const ListSettingsResultItemZonesSchemasMirageId: any;
export type ListSettingsResultItemZonesSchemasMirageValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasMirageValue: any;
export interface ListSettingsResultItemZonesSchemasMirage {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasMirageId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasMirageValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasMirage: S.Schema<ListSettingsResultItemZonesSchemasMirage>;
export type ListSettingsResultItemNELId = "nel";
export declare const ListSettingsResultItemNELId: any;
export type ListSettingsResultItemNELValue = SettingsGetResultNELValue;
export declare const ListSettingsResultItemNELValue: S.Schema<SettingsGetResultNELValue>;
export interface ListSettingsResultItemNEL {
    /** Zone setting identifier. */
    id: ListSettingsResultItemNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemNEL: S.Schema<ListSettingsResultItemNEL>;
export type ListSettingsResultItemZonesSchemasOpportunisticEncryptionId = "opportunistic_encryption";
export declare const ListSettingsResultItemZonesSchemasOpportunisticEncryptionId: any;
export type ListSettingsResultItemZonesSchemasOpportunisticEncryptionValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasOpportunisticEncryptionValue: any;
export interface ListSettingsResultItemZonesSchemasOpportunisticEncryption {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasOpportunisticEncryptionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasOpportunisticEncryptionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasOpportunisticEncryption: S.Schema<ListSettingsResultItemZonesSchemasOpportunisticEncryption>;
export type ListSettingsResultItemOpportunisticOnionId = "opportunistic_onion";
export declare const ListSettingsResultItemOpportunisticOnionId: any;
export type ListSettingsResultItemOpportunisticOnionValue = "on" | "off";
export declare const ListSettingsResultItemOpportunisticOnionValue: any;
export interface ListSettingsResultItemOpportunisticOnion {
    /** ID of the zone setting. */
    id: ListSettingsResultItemOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemOpportunisticOnion: S.Schema<ListSettingsResultItemOpportunisticOnion>;
export type ListSettingsResultItemOrangeToOrangeId = "orange_to_orange";
export declare const ListSettingsResultItemOrangeToOrangeId: any;
export type ListSettingsResultItemOrangeToOrangeValue = "on" | "off";
export declare const ListSettingsResultItemOrangeToOrangeValue: any;
export interface ListSettingsResultItemOrangeToOrange {
    /** ID of the zone setting. */
    id: ListSettingsResultItemOrangeToOrangeId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemOrangeToOrange: S.Schema<ListSettingsResultItemOrangeToOrange>;
export type ListSettingsResultItemZonesSchemasOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const ListSettingsResultItemZonesSchemasOriginErrorPagePassThruId: any;
export type ListSettingsResultItemZonesSchemasOriginErrorPagePassThruValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasOriginErrorPagePassThruValue: any;
export interface ListSettingsResultItemZonesSchemasOriginErrorPagePassThru {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasOriginErrorPagePassThruId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasOriginErrorPagePassThruValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasOriginErrorPagePassThru: S.Schema<ListSettingsResultItemZonesSchemasOriginErrorPagePassThru>;
export type ListSettingsResultItemZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export declare const ListSettingsResultItemZonesCacheRulesOriginH2MaxStreamsId: any;
export interface ListSettingsResultItemZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: ListSettingsResultItemZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export declare const ListSettingsResultItemZonesCacheRulesOriginH2MaxStreams: S.Schema<ListSettingsResultItemZonesCacheRulesOriginH2MaxStreams>;
export type ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export declare const ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionId: any;
export type ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export declare const ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionValue: any;
export interface ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export declare const ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersion: S.Schema<ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersion>;
export type ListSettingsResultItemZonesSchemasPolishId = "polish";
export declare const ListSettingsResultItemZonesSchemasPolishId: any;
export type ListSettingsResultItemZonesSchemasPolishValue = "off" | "lossless" | "lossy";
export declare const ListSettingsResultItemZonesSchemasPolishValue: any;
export interface ListSettingsResultItemZonesSchemasPolish {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasPolishId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasPolishValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasPolish: S.Schema<ListSettingsResultItemZonesSchemasPolish>;
export type ListSettingsResultItemPrefetchPreloadId = "prefetch_preload";
export declare const ListSettingsResultItemPrefetchPreloadId: any;
export type ListSettingsResultItemPrefetchPreloadValue = "on" | "off";
export declare const ListSettingsResultItemPrefetchPreloadValue: any;
export interface ListSettingsResultItemPrefetchPreload {
    /** ID of the zone setting. */
    id: ListSettingsResultItemPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemPrefetchPreload: S.Schema<ListSettingsResultItemPrefetchPreload>;
export type ListSettingsResultItemZonesPrivacyPassId = "privacy_pass";
export declare const ListSettingsResultItemZonesPrivacyPassId: any;
export type ListSettingsResultItemZonesPrivacyPassValue = "on" | "off";
export declare const ListSettingsResultItemZonesPrivacyPassValue: any;
export interface ListSettingsResultItemZonesPrivacyPass {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesPrivacyPassId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesPrivacyPass: S.Schema<ListSettingsResultItemZonesPrivacyPass>;
export type ListSettingsResultItemProxyReadTimeoutId = "proxy_read_timeout";
export declare const ListSettingsResultItemProxyReadTimeoutId: any;
export interface ListSettingsResultItemProxyReadTimeout {
    /** ID of the zone setting. */
    id: ListSettingsResultItemProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemProxyReadTimeout: S.Schema<ListSettingsResultItemProxyReadTimeout>;
export type ListSettingsResultItemPseudoIPV4Id = "pseudo_ipv4";
export declare const ListSettingsResultItemPseudoIPV4Id: any;
export type ListSettingsResultItemPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export declare const ListSettingsResultItemPseudoIPV4Value: any;
export interface ListSettingsResultItemPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: ListSettingsResultItemPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemPseudoIPV4: S.Schema<ListSettingsResultItemPseudoIPV4>;
export type ListSettingsResultItemZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export declare const ListSettingsResultItemZonesRedirectsForAITrainingId: any;
export type ListSettingsResultItemZonesRedirectsForAITrainingValue = "off" | "on";
export declare const ListSettingsResultItemZonesRedirectsForAITrainingValue: any;
export interface ListSettingsResultItemZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesRedirectsForAITraining: S.Schema<ListSettingsResultItemZonesRedirectsForAITraining>;
export type ListSettingsResultItemZonesReplaceInsecureJSId = "replace_insecure_js";
export declare const ListSettingsResultItemZonesReplaceInsecureJSId: any;
export type ListSettingsResultItemZonesReplaceInsecureJSValue = "on" | "off";
export declare const ListSettingsResultItemZonesReplaceInsecureJSValue: any;
export interface ListSettingsResultItemZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesReplaceInsecureJS: S.Schema<ListSettingsResultItemZonesReplaceInsecureJS>;
export type ListSettingsResultItemZonesSchemasResponseBufferingId = "response_buffering";
export declare const ListSettingsResultItemZonesSchemasResponseBufferingId: any;
export type ListSettingsResultItemZonesSchemasResponseBufferingValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasResponseBufferingValue: any;
export interface ListSettingsResultItemZonesSchemasResponseBuffering {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasResponseBufferingId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasResponseBufferingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasResponseBuffering: S.Schema<ListSettingsResultItemZonesSchemasResponseBuffering>;
export type ListSettingsResultItemZonesSchemasRocketLoaderId = "rocket_loader";
export declare const ListSettingsResultItemZonesSchemasRocketLoaderId: any;
export type ListSettingsResultItemZonesSchemasRocketLoaderValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasRocketLoaderValue: any;
export interface ListSettingsResultItemZonesSchemasRocketLoader {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasRocketLoaderId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasRocketLoaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasRocketLoader: S.Schema<ListSettingsResultItemZonesSchemasRocketLoader>;
export type ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export declare const ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationId: any;
export type ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export declare const ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList: S.Schema<ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList>;
export interface ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export declare const ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValue: S.Schema<ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValue>;
export interface ListSettingsResultItemZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasAutomaticPlatformOptimization: S.Schema<ListSettingsResultItemZonesSchemasAutomaticPlatformOptimization>;
export type ListSettingsResultItemZonesSearchForAgentsId = "search_for_agents";
export declare const ListSettingsResultItemZonesSearchForAgentsId: any;
export type ListSettingsResultItemZonesSearchForAgentsValue = "off" | "on";
export declare const ListSettingsResultItemZonesSearchForAgentsValue: any;
export interface ListSettingsResultItemZonesSearchForAgents {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSearchForAgents: S.Schema<ListSettingsResultItemZonesSearchForAgents>;
export type ListSettingsResultItemSecurityHeadersId = "security_header";
export declare const ListSettingsResultItemSecurityHeadersId: any;
export type ListSettingsResultItemSecurityHeadersValueStrictTransportSecurity = SettingsGetResultSecurityHeadersValueStrictTransportSecurity;
export declare const ListSettingsResultItemSecurityHeadersValueStrictTransportSecurity: S.Schema<SettingsGetResultSecurityHeadersValueStrictTransportSecurity>;
export type ListSettingsResultItemSecurityHeadersValue = SettingsGetResultSecurityHeadersValue;
export declare const ListSettingsResultItemSecurityHeadersValue: S.Schema<SettingsGetResultSecurityHeadersValue>;
export interface ListSettingsResultItemSecurityHeaders {
    /** ID of the zone's security header. */
    id: ListSettingsResultItemSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemSecurityHeaders: S.Schema<ListSettingsResultItemSecurityHeaders>;
export type ListSettingsResultItemZonesSchemasSecurityLevelId = "security_level";
export declare const ListSettingsResultItemZonesSchemasSecurityLevelId: any;
export type ListSettingsResultItemZonesSchemasSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const ListSettingsResultItemZonesSchemasSecurityLevelValue: any;
export interface ListSettingsResultItemZonesSchemasSecurityLevel {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasSecurityLevelId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasSecurityLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasSecurityLevel: S.Schema<ListSettingsResultItemZonesSchemasSecurityLevel>;
export type ListSettingsResultItemServerSideExcludesId = "server_side_exclude";
export declare const ListSettingsResultItemServerSideExcludesId: any;
export type ListSettingsResultItemServerSideExcludesValue = "on" | "off";
export declare const ListSettingsResultItemServerSideExcludesValue: any;
export interface ListSettingsResultItemServerSideExcludes {
    /** ID of the zone setting. */
    id: ListSettingsResultItemServerSideExcludesId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemServerSideExcludes: S.Schema<ListSettingsResultItemServerSideExcludes>;
export type ListSettingsResultItemZonesSha1SupportId = "sha1_support";
export declare const ListSettingsResultItemZonesSha1SupportId: any;
export type ListSettingsResultItemZonesSha1SupportValue = "off" | "on";
export declare const ListSettingsResultItemZonesSha1SupportValue: any;
export interface ListSettingsResultItemZonesSha1Support {
    /** Zone setting identifier. */
    id: ListSettingsResultItemZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSha1Support: S.Schema<ListSettingsResultItemZonesSha1Support>;
export type ListSettingsResultItemZonesSchemasSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const ListSettingsResultItemZonesSchemasSortQueryStringForCacheId: any;
export type ListSettingsResultItemZonesSchemasSortQueryStringForCacheValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasSortQueryStringForCacheValue: any;
export interface ListSettingsResultItemZonesSchemasSortQueryStringForCache {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasSortQueryStringForCacheId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasSortQueryStringForCacheValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasSortQueryStringForCache: S.Schema<ListSettingsResultItemZonesSchemasSortQueryStringForCache>;
export type ListSettingsResultItemZonesSchemasSSLId = "ssl";
export declare const ListSettingsResultItemZonesSchemasSSLId: any;
export type ListSettingsResultItemZonesSchemasSSLValue = "off" | "flexible" | "full" | "strict";
export declare const ListSettingsResultItemZonesSchemasSSLValue: any;
export interface ListSettingsResultItemZonesSchemasSSL {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasSSLId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasSSLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasSSL: S.Schema<ListSettingsResultItemZonesSchemasSSL>;
export type ListSettingsResultItemSSLRecommenderId = "ssl_recommender";
export declare const ListSettingsResultItemSSLRecommenderId: any;
export interface ListSettingsResultItemSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: ListSettingsResultItemSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export declare const ListSettingsResultItemSSLRecommender: S.Schema<ListSettingsResultItemSSLRecommender>;
export type ListSettingsResultItemZonesTLS12OnlyId = "tls_1_2_only";
export declare const ListSettingsResultItemZonesTLS12OnlyId: any;
export type ListSettingsResultItemZonesTLS12OnlyValue = "off" | "on";
export declare const ListSettingsResultItemZonesTLS12OnlyValue: any;
export interface ListSettingsResultItemZonesTLS12Only {
    /** Zone setting identifier. */
    id: ListSettingsResultItemZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesTLS12Only: S.Schema<ListSettingsResultItemZonesTLS12Only>;
export type ListSettingsResultItemTLS13Id = "tls_1_3";
export declare const ListSettingsResultItemTLS13Id: any;
export type ListSettingsResultItemTLS13Value = "on" | "off" | "zrt";
export declare const ListSettingsResultItemTLS13Value: any;
export interface ListSettingsResultItemTLS13 {
    /** ID of the zone setting. */
    id: ListSettingsResultItemTLS13Id;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemTLS13: S.Schema<ListSettingsResultItemTLS13>;
export type ListSettingsResultItemTLSClientAuthId = "tls_client_auth";
export declare const ListSettingsResultItemTLSClientAuthId: any;
export type ListSettingsResultItemTLSClientAuthValue = "on" | "off";
export declare const ListSettingsResultItemTLSClientAuthValue: any;
export interface ListSettingsResultItemTLSClientAuth {
    /** ID of the zone setting. */
    id: ListSettingsResultItemTLSClientAuthId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemTLSClientAuth: S.Schema<ListSettingsResultItemTLSClientAuth>;
export type ListSettingsResultItemZonesTransformationsId = "transformations";
export declare const ListSettingsResultItemZonesTransformationsId: any;
export type ListSettingsResultItemZonesTransformationsValue = "on" | "off" | "open";
export declare const ListSettingsResultItemZonesTransformationsValue: any;
export interface ListSettingsResultItemZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: ListSettingsResultItemZonesTransformationsId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesTransformations: S.Schema<ListSettingsResultItemZonesTransformations>;
export type ListSettingsResultItemZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export declare const ListSettingsResultItemZonesTransformationsAllowedOriginsId: any;
export interface ListSettingsResultItemZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: ListSettingsResultItemZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesTransformationsAllowedOrigins: S.Schema<ListSettingsResultItemZonesTransformationsAllowedOrigins>;
export type ListSettingsResultItemZonesSchemasTrueClientIPHeaderId = "true_client_ip_header";
export declare const ListSettingsResultItemZonesSchemasTrueClientIPHeaderId: any;
export type ListSettingsResultItemZonesSchemasTrueClientIPHeaderValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasTrueClientIPHeaderValue: any;
export interface ListSettingsResultItemZonesSchemasTrueClientIPHeader {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasTrueClientIPHeaderId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasTrueClientIPHeaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasTrueClientIPHeader: S.Schema<ListSettingsResultItemZonesSchemasTrueClientIPHeader>;
export type ListSettingsResultItemZonesSchemasWAFId = "waf";
export declare const ListSettingsResultItemZonesSchemasWAFId: any;
export type ListSettingsResultItemZonesSchemasWAFValue = "on" | "off";
export declare const ListSettingsResultItemZonesSchemasWAFValue: any;
export interface ListSettingsResultItemZonesSchemasWAF {
    /** ID of the zone setting. */
    id: ListSettingsResultItemZonesSchemasWAFId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemZonesSchemasWAFValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemZonesSchemasWAF: S.Schema<ListSettingsResultItemZonesSchemasWAF>;
export type ListSettingsResultItemWebPId = "webp";
export declare const ListSettingsResultItemWebPId: any;
export type ListSettingsResultItemWebPValue = "off" | "on";
export declare const ListSettingsResultItemWebPValue: any;
export interface ListSettingsResultItemWebP {
    /** ID of the zone setting. */
    id: ListSettingsResultItemWebPId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemWebP: S.Schema<ListSettingsResultItemWebP>;
export type ListSettingsResultItemWebsocketId = "websockets";
export declare const ListSettingsResultItemWebsocketId: any;
export type ListSettingsResultItemWebsocketValue = "off" | "on";
export declare const ListSettingsResultItemWebsocketValue: any;
export interface ListSettingsResultItemWebsocket {
    /** ID of the zone setting. */
    id: ListSettingsResultItemWebsocketId;
    /** Current value of the zone setting. */
    value: ListSettingsResultItemWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ListSettingsResultItemWebsocket: S.Schema<ListSettingsResultItemWebsocket>;
export type ListSettingsResultItem = ListSettingsResultItemZeroRTT | ListSettingsResultItemAdvancedDDoS | ListSettingsResultItemZonesCacheRulesAegis | ListSettingsResultItemAlwaysOnline | ListSettingsResultItemZonesSchemasAlwaysUseHTTPS | ListSettingsResultItemZonesSchemasAutomaticHTTPSRewrites | ListSettingsResultItemBrotli | ListSettingsResultItemZonesSchemasBrowserCacheTTL | ListSettingsResultItemZonesSchemasBrowserCheck | ListSettingsResultItemZonesSchemasCacheLevel | ListSettingsResultItemChallengeTTL | ListSettingsResultItemCiphers | ListSettingsResultItemZonesContentConverter | ListSettingsResultItemZonesCNAMEFlattening | ListSettingsResultItemDevelopmentMode | ListSettingsResultItemEarlyHints | ListSettingsResultItemZonesSchemasEdgeCacheTTL | ListSettingsResultItemZonesSchemasEmailObfuscation | ListSettingsResultItemH2Prioritization | ListSettingsResultItemHotlinkProtection | ListSettingsResultItemHTTP2 | ListSettingsResultItemHTTP3 | ListSettingsResultItemImageResizing | ListSettingsResultItemZonesSchemasIPGeolocation | ListSettingsResultItemIPV6 | ListSettingsResultItemZonesMaxUpload | ListSettingsResultItemMinTLSVersion | ListSettingsResultItemZonesSchemasMirage | ListSettingsResultItemNEL | ListSettingsResultItemZonesSchemasOpportunisticEncryption | ListSettingsResultItemOpportunisticOnion | ListSettingsResultItemOrangeToOrange | ListSettingsResultItemZonesSchemasOriginErrorPagePassThru | ListSettingsResultItemZonesCacheRulesOriginH2MaxStreams | ListSettingsResultItemZonesCacheRulesOriginMaxHTTPVersion | ListSettingsResultItemZonesSchemasPolish | ListSettingsResultItemPrefetchPreload | ListSettingsResultItemZonesPrivacyPass | ListSettingsResultItemProxyReadTimeout | ListSettingsResultItemPseudoIPV4 | ListSettingsResultItemZonesRedirectsForAITraining | ListSettingsResultItemZonesReplaceInsecureJS | ListSettingsResultItemZonesSchemasResponseBuffering | ListSettingsResultItemZonesSchemasRocketLoader | ListSettingsResultItemZonesSchemasAutomaticPlatformOptimization | ListSettingsResultItemZonesSearchForAgents | ListSettingsResultItemSecurityHeaders | ListSettingsResultItemZonesSchemasSecurityLevel | ListSettingsResultItemServerSideExcludes | ListSettingsResultItemZonesSha1Support | ListSettingsResultItemZonesSchemasSortQueryStringForCache | ListSettingsResultItemZonesSchemasSSL | ListSettingsResultItemSSLRecommender | ListSettingsResultItemZonesTLS12Only | ListSettingsResultItemTLS13 | ListSettingsResultItemTLSClientAuth | ListSettingsResultItemZonesTransformations | ListSettingsResultItemZonesTransformationsAllowedOrigins | ListSettingsResultItemZonesSchemasTrueClientIPHeader | ListSettingsResultItemZonesSchemasWAF | ListSettingsResultItemWebP | ListSettingsResultItemWebsocket;
export declare const ListSettingsResultItem: any;
export type ListSettingsResultList = Array<ListSettingsResultItem>;
export declare const ListSettingsResultList: S.Schema<ListSettingsResultList>;
export type ListSettingsResponse = ListSettingsResultList;
export declare const ListSettingsResponse: S.Schema<ListSettingsResponse>;
export interface ListRequestAccount {
    /** Filter by an account ID. */
    id?: string;
    /** An account Name. Optional filter operators can be provided to extend refine the search: */
    name?: string;
}
export declare const ListRequestAccount: S.Schema<ListRequestAccount>;
export type ListRequestDirection = "asc" | "desc";
export declare const ListRequestDirection: any;
export type ListRequestMatch = "any" | "all";
export declare const ListRequestMatch: any;
export type ListRequestOrder = "name" | "status" | "account.id" | "account.name" | "plan.id";
export declare const ListRequestOrder: any;
export type ListRequestStatus = "initializing" | "pending" | "active" | "moved";
export declare const ListRequestStatus: any;
export type ListRequestType = "full" | "partial" | "secondary" | "internal";
export declare const ListRequestType: any;
export type ListRequestTypeList = Array<ListRequestType | (string & {})>;
export declare const ListRequestTypeList: S.Schema<ListRequestTypeList>;
export interface ListZonesRequest {
    account?: ListRequestAccount;
    /** Direction to order zones. */
    direction?: ListRequestDirection | (string & {});
    /** Whether to match all search requirements or at least one (any). */
    match?: ListRequestMatch | (string & {});
    /** A domain name. Optional filter operators can be provided to extend refine the search: */
    name?: string;
    /** Field to order zones by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of zones per page. */
    perPage?: number;
    /** Specify a zone status to filter by. */
    status?: ListRequestStatus | (string & {});
    /** Zone types to filter by. Multiple types can be specified as a comma-separated list (e.g., ?type=full,partial,secondary). When this parameter is not provided, zones with type "internal" are excluded from the results. */
    type?: ListRequestTypeList;
}
export declare const ListZonesRequest: S.Schema<ListZonesRequest>;
export type ListResultItemAccount = CreateResponseAccount;
export declare const ListResultItemAccount: S.Schema<CreateResponseAccount>;
export type ListResultItemMeta = CreateResponseMeta;
export declare const ListResultItemMeta: S.Schema<CreateResponseMeta>;
export type ListResultItemNameServersList = Array<string>;
export declare const ListResultItemNameServersList: S.Schema<ListResultItemNameServersList>;
export type ListResultItemOriginalNameServersList = Array<string>;
export declare const ListResultItemOriginalNameServersList: S.Schema<ListResultItemOriginalNameServersList>;
export type ListResultItemOwner = CreateResponseOwner;
export declare const ListResultItemOwner: S.Schema<CreateResponseOwner>;
export type ListResultItemPlan = CreateResponsePlan;
export declare const ListResultItemPlan: S.Schema<CreateResponsePlan>;
export type ListResultItemPermissionsList = Array<string>;
export declare const ListResultItemPermissionsList: S.Schema<ListResultItemPermissionsList>;
export type ListResultItemStatus = "initializing" | "pending" | "active" | "moved";
export declare const ListResultItemStatus: any;
export type ListResultItemTenant = CreateResponseTenant;
export declare const ListResultItemTenant: S.Schema<CreateResponseTenant>;
export type ListResultItemTenantUnit = CreateResponseTenantUnit;
export declare const ListResultItemTenantUnit: S.Schema<CreateResponseTenantUnit>;
export type ListResultItemType = "full" | "partial" | "secondary" | "internal";
export declare const ListResultItemType: any;
export type ListResultItemVanityNameServersList = Array<string>;
export declare const ListResultItemVanityNameServersList: S.Schema<ListResultItemVanityNameServersList>;
export interface ListResultItem {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: ListResultItemNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: ListResultItemOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** A Zones subscription information. */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A */
    paused?: boolean | null;
    /** Legacy permissions based on legacy user membership information. */
    permissions?: ListResultItemPermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: ListResultItemStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is */
    type?: ListResultItemType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: ListResultItemVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListZonesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListZonesResponse: S.Schema<ListZonesResponse>;
export type CtAlertingEditRequestEmailsList = Array<string>;
export declare const CtAlertingEditRequestEmailsList: S.Schema<CtAlertingEditRequestEmailsList>;
export interface PatchCtAlertingRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** Email addresses that receive CT alert notifications. Only present and configurable for Business and Enterprise zones. Maximum of 10 addresses. For Free and Pro zones, notifications are sent to all users with SSL permissions on the zone. */
    emails?: CtAlertingEditRequestEmailsList;
}
export declare const PatchCtAlertingRequest: S.Schema<PatchCtAlertingRequest>;
export type CtAlertingEditResponseEmailsList = Array<string>;
export declare const CtAlertingEditResponseEmailsList: S.Schema<CtAlertingEditResponseEmailsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCtAlertingResponse {
    /** Whether CT alerting is enabled for the zone. */
    enabled: boolean;
    /** Email addresses that receive CT alert notifications. Only present and configurable for Business and Enterprise zones. Maximum of 10 addresses. For Free and Pro zones, notifications are sent to all users with SSL permissions on the zone. */
    emails?: CtAlertingEditResponseEmailsList | null;
}
export declare const PatchCtAlertingResponse: S.Schema<PatchCtAlertingResponse>;
export type EnvironmentsEditRequestEnvironmentsItemPosition = EnvironmentsCreateRequestEnvironmentsItemPosition;
export declare const EnvironmentsEditRequestEnvironmentsItemPosition: S.Schema<EnvironmentsCreateRequestEnvironmentsItemPosition>;
export type EnvironmentsEditRequestEnvironmentsItem = EnvironmentsCreateRequestEnvironmentsItem;
export declare const EnvironmentsEditRequestEnvironmentsItem: S.Schema<EnvironmentsCreateRequestEnvironmentsItem>;
export type EnvironmentsEditRequestEnvironmentsList = Array<EnvironmentsCreateRequestEnvironmentsItem>;
export declare const EnvironmentsEditRequestEnvironmentsList: S.Schema<EnvironmentsEditRequestEnvironmentsList>;
export interface PatchEnvironmentRequest {
    zoneId: string;
    environments: EnvironmentsEditRequestEnvironmentsList;
}
export declare const PatchEnvironmentRequest: S.Schema<PatchEnvironmentRequest>;
export type EnvironmentsEditResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export declare const EnvironmentsEditResponseEnvironmentsItemPosition: S.Schema<EnvironmentsCreateResponseEnvironmentsItemPosition>;
export type EnvironmentsEditResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export declare const EnvironmentsEditResponseEnvironmentsItem: S.Schema<EnvironmentsCreateResponseEnvironmentsItem>;
export type EnvironmentsEditResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
export declare const EnvironmentsEditResponseEnvironmentsList: S.Schema<EnvironmentsEditResponseEnvironmentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchEnvironmentResponse {
    environments: EnvironmentsEditResponseEnvironmentsList;
}
export declare const PatchEnvironmentResponse: S.Schema<PatchEnvironmentResponse>;
export interface PatchHoldRequest {
    /** Identifier. */
    zoneId: string;
    /** If `hold_after` is provided and future-dated, the hold will be temporarily disabled, */
    holdAfter?: string;
    /** If `true`, the zone hold will extend to block any subdomain of the given zone, as well */
    includeSubdomains?: boolean;
}
export declare const PatchHoldRequest: S.Schema<PatchHoldRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchHoldResponse {
    hold?: boolean | null;
    holdAfter?: string | null;
    includeSubdomains?: unknown | null;
}
export declare const PatchHoldResponse: S.Schema<PatchHoldResponse>;
export interface PatchSettingRequest {
    /** Identifier */
    zoneId: string;
    /** Setting name */
    settingId: string;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean;
    /** Value of the zone setting. */
    value?: unknown;
}
export declare const PatchSettingRequest: S.Schema<PatchSettingRequest>;
export type SettingsEditResultZeroRTTId = "0rtt";
export declare const SettingsEditResultZeroRTTId: any;
export type SettingsEditResultZeroRTTValue = "on" | "off";
export declare const SettingsEditResultZeroRTTValue: any;
export interface SettingsEditResultZeroRTT {
    /** ID of the zone setting. */
    id: SettingsEditResultZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZeroRTT: S.Schema<SettingsEditResultZeroRTT>;
export type SettingsEditResultAdvancedDDoSId = "advanced_ddos";
export declare const SettingsEditResultAdvancedDDoSId: any;
export type SettingsEditResultAdvancedDDoSValue = "on" | "off";
export declare const SettingsEditResultAdvancedDDoSValue: any;
export interface SettingsEditResultAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsEditResultAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsEditResultAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultAdvancedDDoS: S.Schema<SettingsEditResultAdvancedDDoS>;
export type SettingsEditResultZonesCacheRulesAegisId = "aegis";
export declare const SettingsEditResultZonesCacheRulesAegisId: any;
export type SettingsEditResultZonesCacheRulesAegisValue = SettingsGetResultZonesCacheRulesAegisValue;
export declare const SettingsEditResultZonesCacheRulesAegisValue: S.Schema<SettingsGetResultZonesCacheRulesAegisValue>;
export interface SettingsEditResultZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export declare const SettingsEditResultZonesCacheRulesAegis: S.Schema<SettingsEditResultZonesCacheRulesAegis>;
export type SettingsEditResultAlwaysOnlineId = "always_online";
export declare const SettingsEditResultAlwaysOnlineId: any;
export type SettingsEditResultAlwaysOnlineValue = "on" | "off";
export declare const SettingsEditResultAlwaysOnlineValue: any;
export interface SettingsEditResultAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsEditResultAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsEditResultAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultAlwaysOnline: S.Schema<SettingsEditResultAlwaysOnline>;
export type SettingsEditResultZonesSchemasAlwaysUseHTTPSId = "always_use_https";
export declare const SettingsEditResultZonesSchemasAlwaysUseHTTPSId: any;
export type SettingsEditResultZonesSchemasAlwaysUseHTTPSValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasAlwaysUseHTTPSValue: any;
export interface SettingsEditResultZonesSchemasAlwaysUseHTTPS {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasAlwaysUseHTTPSId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasAlwaysUseHTTPSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasAlwaysUseHTTPS: S.Schema<SettingsEditResultZonesSchemasAlwaysUseHTTPS>;
export type SettingsEditResultZonesSchemasAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const SettingsEditResultZonesSchemasAutomaticHTTPSRewritesId: any;
export type SettingsEditResultZonesSchemasAutomaticHTTPSRewritesValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasAutomaticHTTPSRewritesValue: any;
export interface SettingsEditResultZonesSchemasAutomaticHTTPSRewrites {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasAutomaticHTTPSRewritesId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasAutomaticHTTPSRewritesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasAutomaticHTTPSRewrites: S.Schema<SettingsEditResultZonesSchemasAutomaticHTTPSRewrites>;
export type SettingsEditResultBrotliId = "brotli";
export declare const SettingsEditResultBrotliId: any;
export type SettingsEditResultBrotliValue = "off" | "on";
export declare const SettingsEditResultBrotliValue: any;
export interface SettingsEditResultBrotli {
    /** ID of the zone setting. */
    id: SettingsEditResultBrotliId;
    /** Current value of the zone setting. */
    value: SettingsEditResultBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultBrotli: S.Schema<SettingsEditResultBrotli>;
export type SettingsEditResultZonesSchemasBrowserCacheTTLId = "browser_cache_ttl";
export declare const SettingsEditResultZonesSchemasBrowserCacheTTLId: any;
export interface SettingsEditResultZonesSchemasBrowserCacheTTL {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasBrowserCacheTTLId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasBrowserCacheTTL: S.Schema<SettingsEditResultZonesSchemasBrowserCacheTTL>;
export type SettingsEditResultZonesSchemasBrowserCheckId = "browser_check";
export declare const SettingsEditResultZonesSchemasBrowserCheckId: any;
export type SettingsEditResultZonesSchemasBrowserCheckValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasBrowserCheckValue: any;
export interface SettingsEditResultZonesSchemasBrowserCheck {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasBrowserCheckId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasBrowserCheckValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasBrowserCheck: S.Schema<SettingsEditResultZonesSchemasBrowserCheck>;
export type SettingsEditResultZonesSchemasCacheLevelId = "cache_level";
export declare const SettingsEditResultZonesSchemasCacheLevelId: any;
export type SettingsEditResultZonesSchemasCacheLevelValue = "aggressive" | "basic" | "simplified";
export declare const SettingsEditResultZonesSchemasCacheLevelValue: any;
export interface SettingsEditResultZonesSchemasCacheLevel {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasCacheLevelId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasCacheLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasCacheLevel: S.Schema<SettingsEditResultZonesSchemasCacheLevel>;
export type SettingsEditResultChallengeTTLId = "challenge_ttl";
export declare const SettingsEditResultChallengeTTLId: any;
export type SettingsEditResultChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export declare const SettingsEditResultChallengeTTLValue: any;
export interface SettingsEditResultChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsEditResultChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsEditResultChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultChallengeTTL: S.Schema<SettingsEditResultChallengeTTL>;
export type SettingsEditResultZonesChinaNetworkEnabledId = "china_network_enabled";
export declare const SettingsEditResultZonesChinaNetworkEnabledId: any;
export type SettingsEditResultZonesChinaNetworkEnabledValue = "on" | "off";
export declare const SettingsEditResultZonesChinaNetworkEnabledValue: any;
export interface SettingsEditResultZonesChinaNetworkEnabled {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesChinaNetworkEnabledId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesChinaNetworkEnabledValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesChinaNetworkEnabled: S.Schema<SettingsEditResultZonesChinaNetworkEnabled>;
export type SettingsEditResultZonesContentConverterId = "content_converter";
export declare const SettingsEditResultZonesContentConverterId: any;
export type SettingsEditResultZonesContentConverterValue = "off" | "on";
export declare const SettingsEditResultZonesContentConverterValue: any;
export interface SettingsEditResultZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesContentConverter: S.Schema<SettingsEditResultZonesContentConverter>;
export type SettingsEditResultCiphersId = "ciphers";
export declare const SettingsEditResultCiphersId: any;
export type SettingsEditResultCiphersValueList = Array<string>;
export declare const SettingsEditResultCiphersValueList: S.Schema<SettingsEditResultCiphersValueList>;
export interface SettingsEditResultCiphers {
    /** ID of the zone setting. */
    id: SettingsEditResultCiphersId;
    /** Current value of the zone setting. */
    value: SettingsEditResultCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultCiphers: S.Schema<SettingsEditResultCiphers>;
export type SettingsEditResultZonesCNAMEFlatteningId = "cname_flattening";
export declare const SettingsEditResultZonesCNAMEFlatteningId: any;
export type SettingsEditResultZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export declare const SettingsEditResultZonesCNAMEFlatteningValue: any;
export interface SettingsEditResultZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsEditResultZonesCNAMEFlatteningId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesCNAMEFlattening: S.Schema<SettingsEditResultZonesCNAMEFlattening>;
export type SettingsEditResultDevelopmentModeId = "development_mode";
export declare const SettingsEditResultDevelopmentModeId: any;
export type SettingsEditResultDevelopmentModeValue = "on" | "off";
export declare const SettingsEditResultDevelopmentModeValue: any;
export interface SettingsEditResultDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsEditResultDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsEditResultDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    timeRemaining?: number | null;
}
export declare const SettingsEditResultDevelopmentMode: S.Schema<SettingsEditResultDevelopmentMode>;
export type SettingsEditResultEarlyHintsId = "early_hints";
export declare const SettingsEditResultEarlyHintsId: any;
export type SettingsEditResultEarlyHintsValue = "on" | "off";
export declare const SettingsEditResultEarlyHintsValue: any;
export interface SettingsEditResultEarlyHints {
    /** ID of the zone setting. */
    id: SettingsEditResultEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsEditResultEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultEarlyHints: S.Schema<SettingsEditResultEarlyHints>;
export type SettingsEditResultZonesSchemasEdgeCacheTTLId = "edge_cache_ttl";
export declare const SettingsEditResultZonesSchemasEdgeCacheTTLId: any;
export type SettingsEditResultZonesSchemasEdgeCacheTTLValue = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export declare const SettingsEditResultZonesSchemasEdgeCacheTTLValue: any;
export interface SettingsEditResultZonesSchemasEdgeCacheTTL {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasEdgeCacheTTLId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasEdgeCacheTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasEdgeCacheTTL: S.Schema<SettingsEditResultZonesSchemasEdgeCacheTTL>;
export type SettingsEditResultZonesSchemasEmailObfuscationId = "email_obfuscation";
export declare const SettingsEditResultZonesSchemasEmailObfuscationId: any;
export type SettingsEditResultZonesSchemasEmailObfuscationValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasEmailObfuscationValue: any;
export interface SettingsEditResultZonesSchemasEmailObfuscation {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasEmailObfuscationId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasEmailObfuscationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasEmailObfuscation: S.Schema<SettingsEditResultZonesSchemasEmailObfuscation>;
export type SettingsEditResultH2PrioritizationId = "h2_prioritization";
export declare const SettingsEditResultH2PrioritizationId: any;
export type SettingsEditResultH2PrioritizationValue = "on" | "off" | "custom";
export declare const SettingsEditResultH2PrioritizationValue: any;
export interface SettingsEditResultH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsEditResultH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsEditResultH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultH2Prioritization: S.Schema<SettingsEditResultH2Prioritization>;
export type SettingsEditResultHotlinkProtectionId = "hotlink_protection";
export declare const SettingsEditResultHotlinkProtectionId: any;
export type SettingsEditResultHotlinkProtectionValue = "on" | "off";
export declare const SettingsEditResultHotlinkProtectionValue: any;
export interface SettingsEditResultHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsEditResultHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultHotlinkProtection: S.Schema<SettingsEditResultHotlinkProtection>;
export type SettingsEditResultHTTP2Id = "http2";
export declare const SettingsEditResultHTTP2Id: any;
export type SettingsEditResultHTTP2Value = "on" | "off";
export declare const SettingsEditResultHTTP2Value: any;
export interface SettingsEditResultHTTP2 {
    /** ID of the zone setting. */
    id: SettingsEditResultHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultHTTP2: S.Schema<SettingsEditResultHTTP2>;
export type SettingsEditResultHTTP3Id = "http3";
export declare const SettingsEditResultHTTP3Id: any;
export type SettingsEditResultHTTP3Value = "on" | "off";
export declare const SettingsEditResultHTTP3Value: any;
export interface SettingsEditResultHTTP3 {
    /** ID of the zone setting. */
    id: SettingsEditResultHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultHTTP3: S.Schema<SettingsEditResultHTTP3>;
export type SettingsEditResultImageResizingId = "image_resizing";
export declare const SettingsEditResultImageResizingId: any;
export type SettingsEditResultImageResizingValue = "on" | "off" | "open";
export declare const SettingsEditResultImageResizingValue: any;
export interface SettingsEditResultImageResizing {
    /** ID of the zone setting. */
    id: SettingsEditResultImageResizingId;
    /** Current value of the zone setting. */
    value: SettingsEditResultImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultImageResizing: S.Schema<SettingsEditResultImageResizing>;
export type SettingsEditResultZonesSchemasIPGeolocationId = "ip_geolocation";
export declare const SettingsEditResultZonesSchemasIPGeolocationId: any;
export type SettingsEditResultZonesSchemasIPGeolocationValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasIPGeolocationValue: any;
export interface SettingsEditResultZonesSchemasIPGeolocation {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasIPGeolocationId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasIPGeolocationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasIPGeolocation: S.Schema<SettingsEditResultZonesSchemasIPGeolocation>;
export type SettingsEditResultIPV6Id = "ipv6";
export declare const SettingsEditResultIPV6Id: any;
export type SettingsEditResultIPV6Value = "off" | "on";
export declare const SettingsEditResultIPV6Value: any;
export interface SettingsEditResultIPV6 {
    /** ID of the zone setting. */
    id: SettingsEditResultIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultIPV6: S.Schema<SettingsEditResultIPV6>;
export type SettingsEditResultZonesMaxUploadId = "max_upload";
export declare const SettingsEditResultZonesMaxUploadId: any;
export type SettingsEditResultZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000;
export declare const SettingsEditResultZonesMaxUploadValue: any;
export interface SettingsEditResultZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsEditResultZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesMaxUpload: S.Schema<SettingsEditResultZonesMaxUpload>;
export type SettingsEditResultMinTLSVersionId = "min_tls_version";
export declare const SettingsEditResultMinTLSVersionId: any;
export type SettingsEditResultMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export declare const SettingsEditResultMinTLSVersionValue: any;
export interface SettingsEditResultMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsEditResultMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultMinTLSVersion: S.Schema<SettingsEditResultMinTLSVersion>;
export type SettingsEditResultZonesSchemasMirageId = "mirage";
export declare const SettingsEditResultZonesSchemasMirageId: any;
export type SettingsEditResultZonesSchemasMirageValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasMirageValue: any;
export interface SettingsEditResultZonesSchemasMirage {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasMirageId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasMirageValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasMirage: S.Schema<SettingsEditResultZonesSchemasMirage>;
export type SettingsEditResultNELId = "nel";
export declare const SettingsEditResultNELId: any;
export type SettingsEditResultNELValue = SettingsGetResultNELValue;
export declare const SettingsEditResultNELValue: S.Schema<SettingsGetResultNELValue>;
export interface SettingsEditResultNEL {
    /** Zone setting identifier. */
    id: SettingsEditResultNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultNEL: S.Schema<SettingsEditResultNEL>;
export type SettingsEditResultZonesSchemasOpportunisticEncryptionId = "opportunistic_encryption";
export declare const SettingsEditResultZonesSchemasOpportunisticEncryptionId: any;
export type SettingsEditResultZonesSchemasOpportunisticEncryptionValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasOpportunisticEncryptionValue: any;
export interface SettingsEditResultZonesSchemasOpportunisticEncryption {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasOpportunisticEncryptionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasOpportunisticEncryptionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasOpportunisticEncryption: S.Schema<SettingsEditResultZonesSchemasOpportunisticEncryption>;
export type SettingsEditResultOpportunisticOnionId = "opportunistic_onion";
export declare const SettingsEditResultOpportunisticOnionId: any;
export type SettingsEditResultOpportunisticOnionValue = "on" | "off";
export declare const SettingsEditResultOpportunisticOnionValue: any;
export interface SettingsEditResultOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsEditResultOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsEditResultOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultOpportunisticOnion: S.Schema<SettingsEditResultOpportunisticOnion>;
export type SettingsEditResultOrangeToOrangeId = "orange_to_orange";
export declare const SettingsEditResultOrangeToOrangeId: any;
export type SettingsEditResultOrangeToOrangeValue = "on" | "off";
export declare const SettingsEditResultOrangeToOrangeValue: any;
export interface SettingsEditResultOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsEditResultOrangeToOrangeId;
    /** Current value of the zone setting. */
    value: SettingsEditResultOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultOrangeToOrange: S.Schema<SettingsEditResultOrangeToOrange>;
export type SettingsEditResultZonesSchemasOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const SettingsEditResultZonesSchemasOriginErrorPagePassThruId: any;
export type SettingsEditResultZonesSchemasOriginErrorPagePassThruValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasOriginErrorPagePassThruValue: any;
export interface SettingsEditResultZonesSchemasOriginErrorPagePassThru {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasOriginErrorPagePassThruId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasOriginErrorPagePassThruValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasOriginErrorPagePassThru: S.Schema<SettingsEditResultZonesSchemasOriginErrorPagePassThru>;
export type SettingsEditResultZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export declare const SettingsEditResultZonesCacheRulesOriginH2MaxStreamsId: any;
export interface SettingsEditResultZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsEditResultZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export declare const SettingsEditResultZonesCacheRulesOriginH2MaxStreams: S.Schema<SettingsEditResultZonesCacheRulesOriginH2MaxStreams>;
export type SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export declare const SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionId: any;
export type SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export declare const SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionValue: any;
export interface SettingsEditResultZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsEditResultZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export declare const SettingsEditResultZonesCacheRulesOriginMaxHTTPVersion: S.Schema<SettingsEditResultZonesCacheRulesOriginMaxHTTPVersion>;
export type SettingsEditResultZonesSchemasPolishId = "polish";
export declare const SettingsEditResultZonesSchemasPolishId: any;
export type SettingsEditResultZonesSchemasPolishValue = "off" | "lossless" | "lossy";
export declare const SettingsEditResultZonesSchemasPolishValue: any;
export interface SettingsEditResultZonesSchemasPolish {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasPolishId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasPolishValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasPolish: S.Schema<SettingsEditResultZonesSchemasPolish>;
export type SettingsEditResultPrefetchPreloadId = "prefetch_preload";
export declare const SettingsEditResultPrefetchPreloadId: any;
export type SettingsEditResultPrefetchPreloadValue = "on" | "off";
export declare const SettingsEditResultPrefetchPreloadValue: any;
export interface SettingsEditResultPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsEditResultPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsEditResultPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultPrefetchPreload: S.Schema<SettingsEditResultPrefetchPreload>;
export type SettingsEditResultZonesPrivacyPassId = "privacy_pass";
export declare const SettingsEditResultZonesPrivacyPassId: any;
export type SettingsEditResultZonesPrivacyPassValue = "on" | "off";
export declare const SettingsEditResultZonesPrivacyPassValue: any;
export interface SettingsEditResultZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesPrivacyPassId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesPrivacyPass: S.Schema<SettingsEditResultZonesPrivacyPass>;
export type SettingsEditResultProxyReadTimeoutId = "proxy_read_timeout";
export declare const SettingsEditResultProxyReadTimeoutId: any;
export interface SettingsEditResultProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsEditResultProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultProxyReadTimeout: S.Schema<SettingsEditResultProxyReadTimeout>;
export type SettingsEditResultPseudoIPV4Id = "pseudo_ipv4";
export declare const SettingsEditResultPseudoIPV4Id: any;
export type SettingsEditResultPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export declare const SettingsEditResultPseudoIPV4Value: any;
export interface SettingsEditResultPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsEditResultPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultPseudoIPV4: S.Schema<SettingsEditResultPseudoIPV4>;
export type SettingsEditResultZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export declare const SettingsEditResultZonesRedirectsForAITrainingId: any;
export type SettingsEditResultZonesRedirectsForAITrainingValue = "off" | "on";
export declare const SettingsEditResultZonesRedirectsForAITrainingValue: any;
export interface SettingsEditResultZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesRedirectsForAITraining: S.Schema<SettingsEditResultZonesRedirectsForAITraining>;
export type SettingsEditResultZonesReplaceInsecureJSId = "replace_insecure_js";
export declare const SettingsEditResultZonesReplaceInsecureJSId: any;
export type SettingsEditResultZonesReplaceInsecureJSValue = "on" | "off";
export declare const SettingsEditResultZonesReplaceInsecureJSValue: any;
export interface SettingsEditResultZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesReplaceInsecureJS: S.Schema<SettingsEditResultZonesReplaceInsecureJS>;
export type SettingsEditResultZonesSchemasResponseBufferingId = "response_buffering";
export declare const SettingsEditResultZonesSchemasResponseBufferingId: any;
export type SettingsEditResultZonesSchemasResponseBufferingValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasResponseBufferingValue: any;
export interface SettingsEditResultZonesSchemasResponseBuffering {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasResponseBufferingId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasResponseBufferingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasResponseBuffering: S.Schema<SettingsEditResultZonesSchemasResponseBuffering>;
export type SettingsEditResultZonesSchemasRocketLoaderId = "rocket_loader";
export declare const SettingsEditResultZonesSchemasRocketLoaderId: any;
export type SettingsEditResultZonesSchemasRocketLoaderValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasRocketLoaderValue: any;
export interface SettingsEditResultZonesSchemasRocketLoader {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasRocketLoaderId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasRocketLoaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasRocketLoader: S.Schema<SettingsEditResultZonesSchemasRocketLoader>;
export type SettingsEditResultZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export declare const SettingsEditResultZonesSchemasAutomaticPlatformOptimizationId: any;
export type SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export declare const SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList: S.Schema<SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList>;
export interface SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export declare const SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValue: S.Schema<SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValue>;
export interface SettingsEditResultZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasAutomaticPlatformOptimization: S.Schema<SettingsEditResultZonesSchemasAutomaticPlatformOptimization>;
export type SettingsEditResultZonesSearchForAgentsId = "search_for_agents";
export declare const SettingsEditResultZonesSearchForAgentsId: any;
export type SettingsEditResultZonesSearchForAgentsValue = "off" | "on";
export declare const SettingsEditResultZonesSearchForAgentsValue: any;
export interface SettingsEditResultZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSearchForAgents: S.Schema<SettingsEditResultZonesSearchForAgents>;
export type SettingsEditResultSecurityHeadersId = "security_header";
export declare const SettingsEditResultSecurityHeadersId: any;
export type SettingsEditResultSecurityHeadersValueStrictTransportSecurity = SettingsGetResultSecurityHeadersValueStrictTransportSecurity;
export declare const SettingsEditResultSecurityHeadersValueStrictTransportSecurity: S.Schema<SettingsGetResultSecurityHeadersValueStrictTransportSecurity>;
export type SettingsEditResultSecurityHeadersValue = SettingsGetResultSecurityHeadersValue;
export declare const SettingsEditResultSecurityHeadersValue: S.Schema<SettingsGetResultSecurityHeadersValue>;
export interface SettingsEditResultSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsEditResultSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultSecurityHeaders: S.Schema<SettingsEditResultSecurityHeaders>;
export type SettingsEditResultZonesSchemasSecurityLevelId = "security_level";
export declare const SettingsEditResultZonesSchemasSecurityLevelId: any;
export type SettingsEditResultZonesSchemasSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const SettingsEditResultZonesSchemasSecurityLevelValue: any;
export interface SettingsEditResultZonesSchemasSecurityLevel {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasSecurityLevelId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasSecurityLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasSecurityLevel: S.Schema<SettingsEditResultZonesSchemasSecurityLevel>;
export type SettingsEditResultServerSideExcludesId = "server_side_exclude";
export declare const SettingsEditResultServerSideExcludesId: any;
export type SettingsEditResultServerSideExcludesValue = "on" | "off";
export declare const SettingsEditResultServerSideExcludesValue: any;
export interface SettingsEditResultServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsEditResultServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsEditResultServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultServerSideExcludes: S.Schema<SettingsEditResultServerSideExcludes>;
export type SettingsEditResultZonesSha1SupportId = "sha1_support";
export declare const SettingsEditResultZonesSha1SupportId: any;
export type SettingsEditResultZonesSha1SupportValue = "off" | "on";
export declare const SettingsEditResultZonesSha1SupportValue: any;
export interface SettingsEditResultZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsEditResultZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSha1Support: S.Schema<SettingsEditResultZonesSha1Support>;
export type SettingsEditResultZonesSchemasSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const SettingsEditResultZonesSchemasSortQueryStringForCacheId: any;
export type SettingsEditResultZonesSchemasSortQueryStringForCacheValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasSortQueryStringForCacheValue: any;
export interface SettingsEditResultZonesSchemasSortQueryStringForCache {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasSortQueryStringForCacheId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasSortQueryStringForCacheValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasSortQueryStringForCache: S.Schema<SettingsEditResultZonesSchemasSortQueryStringForCache>;
export type SettingsEditResultZonesSchemasSSLId = "ssl";
export declare const SettingsEditResultZonesSchemasSSLId: any;
export type SettingsEditResultZonesSchemasSSLValue = "off" | "flexible" | "full" | "strict";
export declare const SettingsEditResultZonesSchemasSSLValue: any;
export interface SettingsEditResultZonesSchemasSSL {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasSSLId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasSSLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasSSL: S.Schema<SettingsEditResultZonesSchemasSSL>;
export type SettingsEditResultSSLRecommenderId = "ssl_recommender";
export declare const SettingsEditResultSSLRecommenderId: any;
export interface SettingsEditResultSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsEditResultSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export declare const SettingsEditResultSSLRecommender: S.Schema<SettingsEditResultSSLRecommender>;
export type SettingsEditResultZonesTLS12OnlyId = "tls_1_2_only";
export declare const SettingsEditResultZonesTLS12OnlyId: any;
export type SettingsEditResultZonesTLS12OnlyValue = "off" | "on";
export declare const SettingsEditResultZonesTLS12OnlyValue: any;
export interface SettingsEditResultZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsEditResultZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesTLS12Only: S.Schema<SettingsEditResultZonesTLS12Only>;
export type SettingsEditResultTLS13Id = "tls_1_3";
export declare const SettingsEditResultTLS13Id: any;
export type SettingsEditResultTLS13Value = "on" | "off" | "zrt";
export declare const SettingsEditResultTLS13Value: any;
export interface SettingsEditResultTLS13 {
    /** ID of the zone setting. */
    id: SettingsEditResultTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsEditResultTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultTLS13: S.Schema<SettingsEditResultTLS13>;
export type SettingsEditResultTLSClientAuthId = "tls_client_auth";
export declare const SettingsEditResultTLSClientAuthId: any;
export type SettingsEditResultTLSClientAuthValue = "on" | "off";
export declare const SettingsEditResultTLSClientAuthValue: any;
export interface SettingsEditResultTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsEditResultTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsEditResultTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultTLSClientAuth: S.Schema<SettingsEditResultTLSClientAuth>;
export type SettingsEditResultZonesTransformationsId = "transformations";
export declare const SettingsEditResultZonesTransformationsId: any;
export type SettingsEditResultZonesTransformationsValue = "on" | "off" | "open";
export declare const SettingsEditResultZonesTransformationsValue: any;
export interface SettingsEditResultZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsEditResultZonesTransformationsId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesTransformations: S.Schema<SettingsEditResultZonesTransformations>;
export type SettingsEditResultZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export declare const SettingsEditResultZonesTransformationsAllowedOriginsId: any;
export interface SettingsEditResultZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsEditResultZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesTransformationsAllowedOrigins: S.Schema<SettingsEditResultZonesTransformationsAllowedOrigins>;
export type SettingsEditResultZonesSchemasTrueClientIPHeaderId = "true_client_ip_header";
export declare const SettingsEditResultZonesSchemasTrueClientIPHeaderId: any;
export type SettingsEditResultZonesSchemasTrueClientIPHeaderValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasTrueClientIPHeaderValue: any;
export interface SettingsEditResultZonesSchemasTrueClientIPHeader {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasTrueClientIPHeaderId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasTrueClientIPHeaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasTrueClientIPHeader: S.Schema<SettingsEditResultZonesSchemasTrueClientIPHeader>;
export type SettingsEditResultZonesSchemasWAFId = "waf";
export declare const SettingsEditResultZonesSchemasWAFId: any;
export type SettingsEditResultZonesSchemasWAFValue = "on" | "off";
export declare const SettingsEditResultZonesSchemasWAFValue: any;
export interface SettingsEditResultZonesSchemasWAF {
    /** ID of the zone setting. */
    id: SettingsEditResultZonesSchemasWAFId;
    /** Current value of the zone setting. */
    value: SettingsEditResultZonesSchemasWAFValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultZonesSchemasWAF: S.Schema<SettingsEditResultZonesSchemasWAF>;
export type SettingsEditResultWebPId = "webp";
export declare const SettingsEditResultWebPId: any;
export type SettingsEditResultWebPValue = "off" | "on";
export declare const SettingsEditResultWebPValue: any;
export interface SettingsEditResultWebP {
    /** ID of the zone setting. */
    id: SettingsEditResultWebPId;
    /** Current value of the zone setting. */
    value: SettingsEditResultWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultWebP: S.Schema<SettingsEditResultWebP>;
export type SettingsEditResultWebsocketId = "websockets";
export declare const SettingsEditResultWebsocketId: any;
export type SettingsEditResultWebsocketValue = "off" | "on";
export declare const SettingsEditResultWebsocketValue: any;
export interface SettingsEditResultWebsocket {
    /** ID of the zone setting. */
    id: SettingsEditResultWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsEditResultWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsEditResultWebsocket: S.Schema<SettingsEditResultWebsocket>;
export type SettingsEditResult = SettingsEditResultZeroRTT | SettingsEditResultAdvancedDDoS | SettingsEditResultZonesCacheRulesAegis | SettingsEditResultAlwaysOnline | SettingsEditResultZonesSchemasAlwaysUseHTTPS | SettingsEditResultZonesSchemasAutomaticHTTPSRewrites | SettingsEditResultBrotli | SettingsEditResultZonesSchemasBrowserCacheTTL | SettingsEditResultZonesSchemasBrowserCheck | SettingsEditResultZonesSchemasCacheLevel | SettingsEditResultChallengeTTL | SettingsEditResultZonesChinaNetworkEnabled | SettingsEditResultZonesContentConverter | SettingsEditResultCiphers | SettingsEditResultZonesCNAMEFlattening | SettingsEditResultDevelopmentMode | SettingsEditResultEarlyHints | SettingsEditResultZonesSchemasEdgeCacheTTL | SettingsEditResultZonesSchemasEmailObfuscation | SettingsEditResultH2Prioritization | SettingsEditResultHotlinkProtection | SettingsEditResultHTTP2 | SettingsEditResultHTTP3 | SettingsEditResultImageResizing | SettingsEditResultZonesSchemasIPGeolocation | SettingsEditResultIPV6 | SettingsEditResultZonesMaxUpload | SettingsEditResultMinTLSVersion | SettingsEditResultZonesSchemasMirage | SettingsEditResultNEL | SettingsEditResultZonesSchemasOpportunisticEncryption | SettingsEditResultOpportunisticOnion | SettingsEditResultOrangeToOrange | SettingsEditResultZonesSchemasOriginErrorPagePassThru | SettingsEditResultZonesCacheRulesOriginH2MaxStreams | SettingsEditResultZonesCacheRulesOriginMaxHTTPVersion | SettingsEditResultZonesSchemasPolish | SettingsEditResultPrefetchPreload | SettingsEditResultZonesPrivacyPass | SettingsEditResultProxyReadTimeout | SettingsEditResultPseudoIPV4 | SettingsEditResultZonesRedirectsForAITraining | SettingsEditResultZonesReplaceInsecureJS | SettingsEditResultZonesSchemasResponseBuffering | SettingsEditResultZonesSchemasRocketLoader | SettingsEditResultZonesSchemasAutomaticPlatformOptimization | SettingsEditResultZonesSearchForAgents | SettingsEditResultSecurityHeaders | SettingsEditResultZonesSchemasSecurityLevel | SettingsEditResultServerSideExcludes | SettingsEditResultZonesSha1Support | SettingsEditResultZonesSchemasSortQueryStringForCache | SettingsEditResultZonesSchemasSSL | SettingsEditResultSSLRecommender | SettingsEditResultZonesTLS12Only | SettingsEditResultTLS13 | SettingsEditResultTLSClientAuth | SettingsEditResultZonesTransformations | SettingsEditResultZonesTransformationsAllowedOrigins | SettingsEditResultZonesSchemasTrueClientIPHeader | SettingsEditResultZonesSchemasWAF | SettingsEditResultWebP | SettingsEditResultWebsocket;
export declare const SettingsEditResult: any;
export type PatchSettingResponse = SettingsEditResult;
export declare const PatchSettingResponse: S.Schema<PatchSettingResponse>;
export type EditRequestType = "full" | "partial" | "secondary" | "internal";
export declare const EditRequestType: any;
export type EditRequestVanityNameServersList = Array<string>;
export declare const EditRequestVanityNameServersList: S.Schema<EditRequestVanityNameServersList>;
export interface PatchZoneRequest {
    /** Identifier */
    zoneId: string;
    /** Indicates whether the zone is only using Cloudflare DNS services. A */
    paused?: boolean;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial */
    type?: EditRequestType | (string & {});
    /** An array of domains used for custom name servers. This is only */
    vanityNameServers?: EditRequestVanityNameServersList;
}
export declare const PatchZoneRequest: S.Schema<PatchZoneRequest>;
export type EditResponseAccount = CreateResponseAccount;
export declare const EditResponseAccount: S.Schema<CreateResponseAccount>;
export type EditResponseMeta = CreateResponseMeta;
export declare const EditResponseMeta: S.Schema<CreateResponseMeta>;
export type EditResponseNameServersList = Array<string>;
export declare const EditResponseNameServersList: S.Schema<EditResponseNameServersList>;
export type EditResponseOriginalNameServersList = Array<string>;
export declare const EditResponseOriginalNameServersList: S.Schema<EditResponseOriginalNameServersList>;
export type EditResponseOwner = CreateResponseOwner;
export declare const EditResponseOwner: S.Schema<CreateResponseOwner>;
export type EditResponsePlan = CreateResponsePlan;
export declare const EditResponsePlan: S.Schema<CreateResponsePlan>;
export type EditResponsePermissionsList = Array<string>;
export declare const EditResponsePermissionsList: S.Schema<EditResponsePermissionsList>;
export type EditResponseStatus = "initializing" | "pending" | "active" | "moved";
export declare const EditResponseStatus: any;
export type EditResponseTenant = CreateResponseTenant;
export declare const EditResponseTenant: S.Schema<CreateResponseTenant>;
export type EditResponseTenantUnit = CreateResponseTenantUnit;
export declare const EditResponseTenantUnit: S.Schema<CreateResponseTenantUnit>;
export type EditResponseType = "full" | "partial" | "secondary" | "internal";
export declare const EditResponseType: any;
export type EditResponseVanityNameServersList = Array<string>;
export declare const EditResponseVanityNameServersList: S.Schema<EditResponseVanityNameServersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchZoneResponse {
    /** Identifier */
    id: string;
    /** The account the zone belongs to. */
    account: CreateResponseAccount;
    /** The last time proof of ownership was detected and the zone was made */
    activatedOn: string;
    /** When the zone was created. */
    createdOn: string;
    /** The interval (in seconds) from when development mode expires */
    developmentMode: number;
    /** Metadata about the zone. */
    meta: CreateResponseMeta;
    /** When the zone was last modified. */
    modifiedOn: string;
    /** The domain name. Per [RFC 1035](https://datatracker.ietf.org/doc/html/rfc1035#section-2.3.4) the overall zone name can be up to 253 characters, with each segment ("label") not exceeding 63 characters. */
    name: string;
    /** The name servers Cloudflare assigns to a zone. */
    nameServers: EditResponseNameServersList;
    /** DNS host at the time of switching to Cloudflare. */
    originalDnshost: string;
    /** Original name servers before moving to Cloudflare. */
    originalNameServers: EditResponseOriginalNameServersList;
    /** Registrar for the domain at the time of switching to Cloudflare. */
    originalRegistrar: string;
    /** The owner of the zone. */
    owner: CreateResponseOwner;
    /** A Zones subscription information. */
    plan: CreateResponsePlan;
    /** Allows the customer to use a custom apex. */
    cnameSuffix?: string | null;
    /** Indicates whether the zone is only using Cloudflare DNS services. A */
    paused?: boolean | null;
    /** Legacy permissions based on legacy user membership information. */
    permissions?: EditResponsePermissionsList | null;
    /** The zone status on Cloudflare. */
    status?: EditResponseStatus | null;
    /** The root organizational unit that this zone belongs to (such as a tenant or organization). */
    tenant?: CreateResponseTenant | null;
    /** The immediate parent organizational unit that this zone belongs to (such as under a tenant or sub-organization). */
    tenantUnit?: CreateResponseTenantUnit | null;
    /** A full zone implies that DNS is hosted with Cloudflare. A partial zone is */
    type?: EditResponseType | null;
    /** An array of domains used for custom name servers. This is only available for Business and Enterprise plans. */
    vanityNameServers?: EditResponseVanityNameServersList | null;
    /** Verification key for partial zone setup. */
    verificationKey?: string | null;
}
export declare const PatchZoneResponse: S.Schema<PatchZoneResponse>;
export interface PutCustomNameserverRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether zone uses account-level custom nameservers. */
    enabled?: boolean;
    /** The number of the name server set to assign to the zone. */
    nsSet?: number;
}
export declare const PutCustomNameserverRequest: S.Schema<PutCustomNameserverRequest>;
export type CustomNameserversUpdateResultList = Array<string>;
export declare const CustomNameserversUpdateResultList: S.Schema<CustomNameserversUpdateResultList>;
export interface PutCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CustomNameserversUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const PutCustomNameserverResponse: S.Schema<PutCustomNameserverResponse>;
export interface RollbackEnvironmentRequest {
    zoneId: string;
    environmentId: string;
}
export declare const RollbackEnvironmentRequest: S.Schema<RollbackEnvironmentRequest>;
export type EnvironmentsRollbackResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export declare const EnvironmentsRollbackResponseEnvironmentsItemPosition: S.Schema<EnvironmentsCreateResponseEnvironmentsItemPosition>;
export type EnvironmentsRollbackResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export declare const EnvironmentsRollbackResponseEnvironmentsItem: S.Schema<EnvironmentsCreateResponseEnvironmentsItem>;
export type EnvironmentsRollbackResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
export declare const EnvironmentsRollbackResponseEnvironmentsList: S.Schema<EnvironmentsRollbackResponseEnvironmentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RollbackEnvironmentResponse {
    environments: EnvironmentsRollbackResponseEnvironmentsList;
}
export declare const RollbackEnvironmentResponse: S.Schema<RollbackEnvironmentResponse>;
export type SettingsBulkEditRequestBodyItemZeroRTTId = "0rtt";
export declare const SettingsBulkEditRequestBodyItemZeroRTTId: any;
export type SettingsBulkEditRequestBodyItemZeroRTTValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZeroRTTValue: any;
export interface SettingsBulkEditRequestBodyItemZeroRTT {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZeroRTTValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZeroRTT: S.Schema<SettingsBulkEditRequestBodyItemZeroRTT>;
export type SettingsBulkEditRequestBodyItemAdvancedDDoSId = "advanced_ddos";
export declare const SettingsBulkEditRequestBodyItemAdvancedDDoSId: any;
export type SettingsBulkEditRequestBodyItemAdvancedDDoSValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemAdvancedDDoSValue: any;
export interface SettingsBulkEditRequestBodyItemAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemAdvancedDDoSValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemAdvancedDDoS: S.Schema<SettingsBulkEditRequestBodyItemAdvancedDDoS>;
export type SettingsBulkEditRequestBodyItemZonesCacheRulesAegisId = "aegis";
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesAegisId: any;
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesAegisValue {
    /** Whether the feature is enabled or not. */
    enabled?: boolean;
    /** Egress pool id which refers to a grouping of dedicated egress IPs through which Cloudflare will connect to origin. */
    poolId?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesAegisValue: S.Schema<SettingsBulkEditRequestBodyItemZonesCacheRulesAegisValue>;
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the zone setting. */
    value?: SettingsBulkEditRequestBodyItemZonesCacheRulesAegisValue;
}
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesAegis: S.Schema<SettingsBulkEditRequestBodyItemZonesCacheRulesAegis>;
export type SettingsBulkEditRequestBodyItemAlwaysOnlineId = "always_online";
export declare const SettingsBulkEditRequestBodyItemAlwaysOnlineId: any;
export type SettingsBulkEditRequestBodyItemAlwaysOnlineValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemAlwaysOnlineValue: any;
export interface SettingsBulkEditRequestBodyItemAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemAlwaysOnlineValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemAlwaysOnline: S.Schema<SettingsBulkEditRequestBodyItemAlwaysOnline>;
export type SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPSId = "always_use_https";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPSId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPSValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPSValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPS {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPSValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPS: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPS>;
export type SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewritesId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewritesValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewritesValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewrites {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewritesId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewritesValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewrites: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewrites>;
export type SettingsBulkEditRequestBodyItemBrotliId = "brotli";
export declare const SettingsBulkEditRequestBodyItemBrotliId: any;
export type SettingsBulkEditRequestBodyItemBrotliValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemBrotliValue: any;
export interface SettingsBulkEditRequestBodyItemBrotli {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemBrotliId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemBrotliValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemBrotli: S.Schema<SettingsBulkEditRequestBodyItemBrotli>;
export type SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTLId = "browser_cache_ttl";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTLId: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTLId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTL: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTL>;
export type SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheckId = "browser_check";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheckId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheckValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheckValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheck {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheckId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheckValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheck: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheck>;
export type SettingsBulkEditRequestBodyItemZonesSchemasCacheLevelId = "cache_level";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasCacheLevelId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasCacheLevelValue = "aggressive" | "basic" | "simplified";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasCacheLevelValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasCacheLevel {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasCacheLevelId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasCacheLevelValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasCacheLevel: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasCacheLevel>;
export type SettingsBulkEditRequestBodyItemChallengeTTLId = "challenge_ttl";
export declare const SettingsBulkEditRequestBodyItemChallengeTTLId: any;
export type SettingsBulkEditRequestBodyItemChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export declare const SettingsBulkEditRequestBodyItemChallengeTTLValue: any;
export interface SettingsBulkEditRequestBodyItemChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemChallengeTTLValue | (number & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemChallengeTTL: S.Schema<SettingsBulkEditRequestBodyItemChallengeTTL>;
export type SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledId = "china_network_enabled";
export declare const SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledId: any;
export type SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledValue: any;
export interface SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabled {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabledValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabled: S.Schema<SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabled>;
export type SettingsBulkEditRequestBodyItemZonesContentConverterId = "content_converter";
export declare const SettingsBulkEditRequestBodyItemZonesContentConverterId: any;
export type SettingsBulkEditRequestBodyItemZonesContentConverterValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemZonesContentConverterValue: any;
export interface SettingsBulkEditRequestBodyItemZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesContentConverterValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesContentConverter: S.Schema<SettingsBulkEditRequestBodyItemZonesContentConverter>;
export type SettingsBulkEditRequestBodyItemCiphersId = "ciphers";
export declare const SettingsBulkEditRequestBodyItemCiphersId: any;
export type SettingsBulkEditRequestBodyItemCiphersValueList = Array<string>;
export declare const SettingsBulkEditRequestBodyItemCiphersValueList: S.Schema<SettingsBulkEditRequestBodyItemCiphersValueList>;
export interface SettingsBulkEditRequestBodyItemCiphers {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemCiphersId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemCiphers: S.Schema<SettingsBulkEditRequestBodyItemCiphers>;
export type SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningId = "cname_flattening";
export declare const SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningId: any;
export type SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export declare const SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningValue: any;
export interface SettingsBulkEditRequestBodyItemZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesCNAMEFlatteningValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesCNAMEFlattening: S.Schema<SettingsBulkEditRequestBodyItemZonesCNAMEFlattening>;
export type SettingsBulkEditRequestBodyItemDevelopmentModeId = "development_mode";
export declare const SettingsBulkEditRequestBodyItemDevelopmentModeId: any;
export type SettingsBulkEditRequestBodyItemDevelopmentModeValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemDevelopmentModeValue: any;
export interface SettingsBulkEditRequestBodyItemDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemDevelopmentModeValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the zone setting. */
    timeRemaining?: number;
}
export declare const SettingsBulkEditRequestBodyItemDevelopmentMode: S.Schema<SettingsBulkEditRequestBodyItemDevelopmentMode>;
export type SettingsBulkEditRequestBodyItemEarlyHintsId = "early_hints";
export declare const SettingsBulkEditRequestBodyItemEarlyHintsId: any;
export type SettingsBulkEditRequestBodyItemEarlyHintsValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemEarlyHintsValue: any;
export interface SettingsBulkEditRequestBodyItemEarlyHints {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemEarlyHintsValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemEarlyHints: S.Schema<SettingsBulkEditRequestBodyItemEarlyHints>;
export type SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTLId = "edge_cache_ttl";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTLId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTLValue = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export declare const SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTLValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTLValue | (number & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTL: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTL>;
export type SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscationId = "email_obfuscation";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscationId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscationValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscationValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscation {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscationValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscation: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscation>;
export type SettingsBulkEditRequestBodyItemH2PrioritizationId = "h2_prioritization";
export declare const SettingsBulkEditRequestBodyItemH2PrioritizationId: any;
export type SettingsBulkEditRequestBodyItemH2PrioritizationValue = "on" | "off" | "custom";
export declare const SettingsBulkEditRequestBodyItemH2PrioritizationValue: any;
export interface SettingsBulkEditRequestBodyItemH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemH2PrioritizationValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemH2Prioritization: S.Schema<SettingsBulkEditRequestBodyItemH2Prioritization>;
export type SettingsBulkEditRequestBodyItemHotlinkProtectionId = "hotlink_protection";
export declare const SettingsBulkEditRequestBodyItemHotlinkProtectionId: any;
export type SettingsBulkEditRequestBodyItemHotlinkProtectionValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemHotlinkProtectionValue: any;
export interface SettingsBulkEditRequestBodyItemHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemHotlinkProtectionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemHotlinkProtection: S.Schema<SettingsBulkEditRequestBodyItemHotlinkProtection>;
export type SettingsBulkEditRequestBodyItemHTTP2Id = "http2";
export declare const SettingsBulkEditRequestBodyItemHTTP2Id: any;
export type SettingsBulkEditRequestBodyItemHTTP2Value = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemHTTP2Value: any;
export interface SettingsBulkEditRequestBodyItemHTTP2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemHTTP2Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemHTTP2: S.Schema<SettingsBulkEditRequestBodyItemHTTP2>;
export type SettingsBulkEditRequestBodyItemHTTP3Id = "http3";
export declare const SettingsBulkEditRequestBodyItemHTTP3Id: any;
export type SettingsBulkEditRequestBodyItemHTTP3Value = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemHTTP3Value: any;
export interface SettingsBulkEditRequestBodyItemHTTP3 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemHTTP3Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemHTTP3: S.Schema<SettingsBulkEditRequestBodyItemHTTP3>;
export type SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocationId = "ip_geolocation";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocationId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocationValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocationValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocation {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocationValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocation: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocation>;
export type SettingsBulkEditRequestBodyItemIPV6Id = "ipv6";
export declare const SettingsBulkEditRequestBodyItemIPV6Id: any;
export type SettingsBulkEditRequestBodyItemIPV6Value = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemIPV6Value: any;
export interface SettingsBulkEditRequestBodyItemIPV6 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemIPV6Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemIPV6: S.Schema<SettingsBulkEditRequestBodyItemIPV6>;
export type SettingsBulkEditRequestBodyItemZonesMaxUploadId = "max_upload";
export declare const SettingsBulkEditRequestBodyItemZonesMaxUploadId: any;
export type SettingsBulkEditRequestBodyItemZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000;
export declare const SettingsBulkEditRequestBodyItemZonesMaxUploadValue: any;
export interface SettingsBulkEditRequestBodyItemZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesMaxUploadValue | (number & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesMaxUpload: S.Schema<SettingsBulkEditRequestBodyItemZonesMaxUpload>;
export type SettingsBulkEditRequestBodyItemMinTLSVersionId = "min_tls_version";
export declare const SettingsBulkEditRequestBodyItemMinTLSVersionId: any;
export type SettingsBulkEditRequestBodyItemMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export declare const SettingsBulkEditRequestBodyItemMinTLSVersionValue: any;
export interface SettingsBulkEditRequestBodyItemMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemMinTLSVersionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemMinTLSVersion: S.Schema<SettingsBulkEditRequestBodyItemMinTLSVersion>;
export type SettingsBulkEditRequestBodyItemZonesSchemasMirageId = "mirage";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasMirageId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasMirageValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasMirageValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasMirage {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasMirageId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasMirageValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasMirage: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasMirage>;
export type SettingsBulkEditRequestBodyItemNELId = "nel";
export declare const SettingsBulkEditRequestBodyItemNELId: any;
export interface SettingsBulkEditRequestBodyItemNELValue {
    enabled?: boolean;
}
export declare const SettingsBulkEditRequestBodyItemNELValue: S.Schema<SettingsBulkEditRequestBodyItemNELValue>;
export interface SettingsBulkEditRequestBodyItemNEL {
    /** Zone setting identifier. */
    id: SettingsBulkEditRequestBodyItemNELId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemNEL: S.Schema<SettingsBulkEditRequestBodyItemNEL>;
export type SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryptionId = "opportunistic_encryption";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryptionId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryptionValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryptionValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryption {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryptionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryptionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryption: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryption>;
export type SettingsBulkEditRequestBodyItemOpportunisticOnionId = "opportunistic_onion";
export declare const SettingsBulkEditRequestBodyItemOpportunisticOnionId: any;
export type SettingsBulkEditRequestBodyItemOpportunisticOnionValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemOpportunisticOnionValue: any;
export interface SettingsBulkEditRequestBodyItemOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemOpportunisticOnionValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemOpportunisticOnion: S.Schema<SettingsBulkEditRequestBodyItemOpportunisticOnion>;
export type SettingsBulkEditRequestBodyItemOrangeToOrangeId = "orange_to_orange";
export declare const SettingsBulkEditRequestBodyItemOrangeToOrangeId: any;
export type SettingsBulkEditRequestBodyItemOrangeToOrangeValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemOrangeToOrangeValue: any;
export interface SettingsBulkEditRequestBodyItemOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemOrangeToOrangeId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemOrangeToOrangeValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemOrangeToOrange: S.Schema<SettingsBulkEditRequestBodyItemOrangeToOrange>;
export type SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThruId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThruValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThruValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThru {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThruId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThruValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThru: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThru>;
export type SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreamsId: any;
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number;
}
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreams: S.Schema<SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreams>;
export type SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionId: any;
export type SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionValue: any;
export interface SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersionValue | (string & {});
}
export declare const SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersion: S.Schema<SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersion>;
export type SettingsBulkEditRequestBodyItemZonesSchemasPolishId = "polish";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasPolishId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasPolishValue = "off" | "lossless" | "lossy";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasPolishValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasPolish {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasPolishId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasPolishValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasPolish: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasPolish>;
export type SettingsBulkEditRequestBodyItemPrefetchPreloadId = "prefetch_preload";
export declare const SettingsBulkEditRequestBodyItemPrefetchPreloadId: any;
export type SettingsBulkEditRequestBodyItemPrefetchPreloadValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemPrefetchPreloadValue: any;
export interface SettingsBulkEditRequestBodyItemPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemPrefetchPreloadValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemPrefetchPreload: S.Schema<SettingsBulkEditRequestBodyItemPrefetchPreload>;
export type SettingsBulkEditRequestBodyItemZonesPrivacyPassId = "privacy_pass";
export declare const SettingsBulkEditRequestBodyItemZonesPrivacyPassId: any;
export type SettingsBulkEditRequestBodyItemZonesPrivacyPassValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesPrivacyPassValue: any;
export interface SettingsBulkEditRequestBodyItemZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesPrivacyPassId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesPrivacyPassValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesPrivacyPass: S.Schema<SettingsBulkEditRequestBodyItemZonesPrivacyPass>;
export type SettingsBulkEditRequestBodyItemProxyReadTimeoutId = "proxy_read_timeout";
export declare const SettingsBulkEditRequestBodyItemProxyReadTimeoutId: any;
export interface SettingsBulkEditRequestBodyItemProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemProxyReadTimeout: S.Schema<SettingsBulkEditRequestBodyItemProxyReadTimeout>;
export type SettingsBulkEditRequestBodyItemPseudoIPV4Id = "pseudo_ipv4";
export declare const SettingsBulkEditRequestBodyItemPseudoIPV4Id: any;
export type SettingsBulkEditRequestBodyItemPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export declare const SettingsBulkEditRequestBodyItemPseudoIPV4Value: any;
export interface SettingsBulkEditRequestBodyItemPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsBulkEditRequestBodyItemPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemPseudoIPV4Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemPseudoIPV4: S.Schema<SettingsBulkEditRequestBodyItemPseudoIPV4>;
export type SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export declare const SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingId: any;
export type SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingValue: any;
export interface SettingsBulkEditRequestBodyItemZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesRedirectsForAITrainingValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesRedirectsForAITraining: S.Schema<SettingsBulkEditRequestBodyItemZonesRedirectsForAITraining>;
export type SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSId = "replace_insecure_js";
export declare const SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSId: any;
export type SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSValue: any;
export interface SettingsBulkEditRequestBodyItemZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesReplaceInsecureJSValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesReplaceInsecureJS: S.Schema<SettingsBulkEditRequestBodyItemZonesReplaceInsecureJS>;
export type SettingsBulkEditRequestBodyItemZonesSchemasResponseBufferingId = "response_buffering";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasResponseBufferingId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasResponseBufferingValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasResponseBufferingValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasResponseBuffering {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasResponseBufferingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasResponseBufferingValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasResponseBuffering: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasResponseBuffering>;
export type SettingsBulkEditRequestBodyItemZonesSchemasRocketLoaderId = "rocket_loader";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasRocketLoaderId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasRocketLoaderValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasRocketLoaderValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasRocketLoader {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasRocketLoaderId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasRocketLoaderValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasRocketLoader: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasRocketLoader>;
export type SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList>;
export interface SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValue: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValue>;
export interface SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimization: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimization>;
export type SettingsBulkEditRequestBodyItemZonesSearchForAgentsId = "search_for_agents";
export declare const SettingsBulkEditRequestBodyItemZonesSearchForAgentsId: any;
export type SettingsBulkEditRequestBodyItemZonesSearchForAgentsValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemZonesSearchForAgentsValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSearchForAgentsValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSearchForAgents: S.Schema<SettingsBulkEditRequestBodyItemZonesSearchForAgents>;
export type SettingsBulkEditRequestBodyItemSecurityHeadersId = "security_header";
export declare const SettingsBulkEditRequestBodyItemSecurityHeadersId: any;
export interface SettingsBulkEditRequestBodyItemSecurityHeadersValueStrictTransportSecurity {
    /** Whether or not strict transport security is enabled. */
    enabled?: boolean;
    /** Include all subdomains for strict transport security. */
    includeSubdomains?: boolean;
    /** Max age in seconds of the strict transport security. */
    maxAge?: number;
    /** Whether or not to include 'X-Content-Type-Options: nosniff' header. */
    nosniff?: boolean;
    /** Enable automatic preload of the HSTS configuration. */
    preload?: boolean;
}
export declare const SettingsBulkEditRequestBodyItemSecurityHeadersValueStrictTransportSecurity: S.Schema<SettingsBulkEditRequestBodyItemSecurityHeadersValueStrictTransportSecurity>;
export interface SettingsBulkEditRequestBodyItemSecurityHeadersValue {
    /** Strict Transport Security. */
    strictTransportSecurity?: SettingsBulkEditRequestBodyItemSecurityHeadersValueStrictTransportSecurity;
}
export declare const SettingsBulkEditRequestBodyItemSecurityHeadersValue: S.Schema<SettingsBulkEditRequestBodyItemSecurityHeadersValue>;
export interface SettingsBulkEditRequestBodyItemSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsBulkEditRequestBodyItemSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemSecurityHeaders: S.Schema<SettingsBulkEditRequestBodyItemSecurityHeaders>;
export type SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevelId = "security_level";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevelId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevelValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevel {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevelId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevelValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevel: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevel>;
export type SettingsBulkEditRequestBodyItemServerSideExcludesId = "server_side_exclude";
export declare const SettingsBulkEditRequestBodyItemServerSideExcludesId: any;
export type SettingsBulkEditRequestBodyItemServerSideExcludesValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemServerSideExcludesValue: any;
export interface SettingsBulkEditRequestBodyItemServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemServerSideExcludesValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemServerSideExcludes: S.Schema<SettingsBulkEditRequestBodyItemServerSideExcludes>;
export type SettingsBulkEditRequestBodyItemZonesSha1SupportId = "sha1_support";
export declare const SettingsBulkEditRequestBodyItemZonesSha1SupportId: any;
export type SettingsBulkEditRequestBodyItemZonesSha1SupportValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemZonesSha1SupportValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsBulkEditRequestBodyItemZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSha1SupportValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSha1Support: S.Schema<SettingsBulkEditRequestBodyItemZonesSha1Support>;
export type SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCacheId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCacheValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCacheValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCache {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCacheId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCacheValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCache: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCache>;
export type SettingsBulkEditRequestBodyItemZonesSchemasSSLId = "ssl";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSSLId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasSSLValue = "off" | "flexible" | "full" | "strict";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSSLValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasSSL {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasSSLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasSSLValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasSSL: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasSSL>;
export type SettingsBulkEditRequestBodyItemSSLRecommenderId = "ssl_recommender";
export declare const SettingsBulkEditRequestBodyItemSSLRecommenderId: any;
export interface SettingsBulkEditRequestBodyItemSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsBulkEditRequestBodyItemSSLRecommenderId | (string & {});
    /** ssl-recommender enrollment setting. */
    enabled?: boolean;
}
export declare const SettingsBulkEditRequestBodyItemSSLRecommender: S.Schema<SettingsBulkEditRequestBodyItemSSLRecommender>;
export type SettingsBulkEditRequestBodyItemZonesTLS12OnlyId = "tls_1_2_only";
export declare const SettingsBulkEditRequestBodyItemZonesTLS12OnlyId: any;
export type SettingsBulkEditRequestBodyItemZonesTLS12OnlyValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemZonesTLS12OnlyValue: any;
export interface SettingsBulkEditRequestBodyItemZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsBulkEditRequestBodyItemZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesTLS12OnlyValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesTLS12Only: S.Schema<SettingsBulkEditRequestBodyItemZonesTLS12Only>;
export type SettingsBulkEditRequestBodyItemTLS13Id = "tls_1_3";
export declare const SettingsBulkEditRequestBodyItemTLS13Id: any;
export type SettingsBulkEditRequestBodyItemTLS13Value = "on" | "off" | "zrt";
export declare const SettingsBulkEditRequestBodyItemTLS13Value: any;
export interface SettingsBulkEditRequestBodyItemTLS13 {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemTLS13Value | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemTLS13: S.Schema<SettingsBulkEditRequestBodyItemTLS13>;
export type SettingsBulkEditRequestBodyItemTLSClientAuthId = "tls_client_auth";
export declare const SettingsBulkEditRequestBodyItemTLSClientAuthId: any;
export type SettingsBulkEditRequestBodyItemTLSClientAuthValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemTLSClientAuthValue: any;
export interface SettingsBulkEditRequestBodyItemTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemTLSClientAuthValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemTLSClientAuth: S.Schema<SettingsBulkEditRequestBodyItemTLSClientAuth>;
export type SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeaderId = "true_client_ip_header";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeaderId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeaderValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeaderValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeader {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeaderId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeaderValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeader: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeader>;
export type SettingsBulkEditRequestBodyItemZonesSchemasWAFId = "waf";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasWAFId: any;
export type SettingsBulkEditRequestBodyItemZonesSchemasWAFValue = "on" | "off";
export declare const SettingsBulkEditRequestBodyItemZonesSchemasWAFValue: any;
export interface SettingsBulkEditRequestBodyItemZonesSchemasWAF {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemZonesSchemasWAFId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemZonesSchemasWAFValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemZonesSchemasWAF: S.Schema<SettingsBulkEditRequestBodyItemZonesSchemasWAF>;
export type SettingsBulkEditRequestBodyItemWebPId = "webp";
export declare const SettingsBulkEditRequestBodyItemWebPId: any;
export type SettingsBulkEditRequestBodyItemWebPValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemWebPValue: any;
export interface SettingsBulkEditRequestBodyItemWebP {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemWebPId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemWebPValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemWebP: S.Schema<SettingsBulkEditRequestBodyItemWebP>;
export type SettingsBulkEditRequestBodyItemWebsocketId = "websockets";
export declare const SettingsBulkEditRequestBodyItemWebsocketId: any;
export type SettingsBulkEditRequestBodyItemWebsocketValue = "off" | "on";
export declare const SettingsBulkEditRequestBodyItemWebsocketValue: any;
export interface SettingsBulkEditRequestBodyItemWebsocket {
    /** ID of the zone setting. */
    id: SettingsBulkEditRequestBodyItemWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditRequestBodyItemWebsocketValue | (string & {});
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean;
    /** last time this setting was modified. */
    modifiedOn?: string;
}
export declare const SettingsBulkEditRequestBodyItemWebsocket: S.Schema<SettingsBulkEditRequestBodyItemWebsocket>;
export type SettingsBulkEditRequestBodyItem = SettingsBulkEditRequestBodyItemZeroRTT | SettingsBulkEditRequestBodyItemAdvancedDDoS | SettingsBulkEditRequestBodyItemZonesCacheRulesAegis | SettingsBulkEditRequestBodyItemAlwaysOnline | SettingsBulkEditRequestBodyItemZonesSchemasAlwaysUseHTTPS | SettingsBulkEditRequestBodyItemZonesSchemasAutomaticHTTPSRewrites | SettingsBulkEditRequestBodyItemBrotli | SettingsBulkEditRequestBodyItemZonesSchemasBrowserCacheTTL | SettingsBulkEditRequestBodyItemZonesSchemasBrowserCheck | SettingsBulkEditRequestBodyItemZonesSchemasCacheLevel | SettingsBulkEditRequestBodyItemChallengeTTL | SettingsBulkEditRequestBodyItemZonesChinaNetworkEnabled | SettingsBulkEditRequestBodyItemZonesContentConverter | SettingsBulkEditRequestBodyItemCiphers | SettingsBulkEditRequestBodyItemZonesCNAMEFlattening | SettingsBulkEditRequestBodyItemDevelopmentMode | SettingsBulkEditRequestBodyItemEarlyHints | SettingsBulkEditRequestBodyItemZonesSchemasEdgeCacheTTL | SettingsBulkEditRequestBodyItemZonesSchemasEmailObfuscation | SettingsBulkEditRequestBodyItemH2Prioritization | SettingsBulkEditRequestBodyItemHotlinkProtection | SettingsBulkEditRequestBodyItemHTTP2 | SettingsBulkEditRequestBodyItemHTTP3 | SettingsBulkEditRequestBodyItemZonesSchemasIPGeolocation | SettingsBulkEditRequestBodyItemIPV6 | SettingsBulkEditRequestBodyItemZonesMaxUpload | SettingsBulkEditRequestBodyItemMinTLSVersion | SettingsBulkEditRequestBodyItemZonesSchemasMirage | SettingsBulkEditRequestBodyItemNEL | SettingsBulkEditRequestBodyItemZonesSchemasOpportunisticEncryption | SettingsBulkEditRequestBodyItemOpportunisticOnion | SettingsBulkEditRequestBodyItemOrangeToOrange | SettingsBulkEditRequestBodyItemZonesSchemasOriginErrorPagePassThru | SettingsBulkEditRequestBodyItemZonesCacheRulesOriginH2MaxStreams | SettingsBulkEditRequestBodyItemZonesCacheRulesOriginMaxHTTPVersion | SettingsBulkEditRequestBodyItemZonesSchemasPolish | SettingsBulkEditRequestBodyItemPrefetchPreload | SettingsBulkEditRequestBodyItemZonesPrivacyPass | SettingsBulkEditRequestBodyItemProxyReadTimeout | SettingsBulkEditRequestBodyItemPseudoIPV4 | SettingsBulkEditRequestBodyItemZonesRedirectsForAITraining | SettingsBulkEditRequestBodyItemZonesReplaceInsecureJS | SettingsBulkEditRequestBodyItemZonesSchemasResponseBuffering | SettingsBulkEditRequestBodyItemZonesSchemasRocketLoader | SettingsBulkEditRequestBodyItemZonesSchemasAutomaticPlatformOptimization | SettingsBulkEditRequestBodyItemZonesSearchForAgents | SettingsBulkEditRequestBodyItemSecurityHeaders | SettingsBulkEditRequestBodyItemZonesSchemasSecurityLevel | SettingsBulkEditRequestBodyItemServerSideExcludes | SettingsBulkEditRequestBodyItemZonesSha1Support | SettingsBulkEditRequestBodyItemZonesSchemasSortQueryStringForCache | SettingsBulkEditRequestBodyItemZonesSchemasSSL | SettingsBulkEditRequestBodyItemSSLRecommender | SettingsBulkEditRequestBodyItemZonesTLS12Only | SettingsBulkEditRequestBodyItemTLS13 | SettingsBulkEditRequestBodyItemTLSClientAuth | SettingsBulkEditRequestBodyItemZonesSchemasTrueClientIPHeader | SettingsBulkEditRequestBodyItemZonesSchemasWAF | SettingsBulkEditRequestBodyItemWebP | SettingsBulkEditRequestBodyItemWebsocket;
export declare const SettingsBulkEditRequestBodyItem: any;
export type SettingsBulkEditRequestBodyList = Array<SettingsBulkEditRequestBodyItem>;
export declare const SettingsBulkEditRequestBodyList: S.Schema<SettingsBulkEditRequestBodyList>;
export interface SettingsBulkEditRequest {
    /** Identifier */
    zoneId: string;
    body: SettingsBulkEditRequestBodyList;
}
export declare const SettingsBulkEditRequest: S.Schema<SettingsBulkEditRequest>;
export type SettingsBulkEditResultItemZeroRTTId = "0rtt";
export declare const SettingsBulkEditResultItemZeroRTTId: any;
export type SettingsBulkEditResultItemZeroRTTValue = "on" | "off";
export declare const SettingsBulkEditResultItemZeroRTTValue: any;
export interface SettingsBulkEditResultItemZeroRTT {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZeroRTTId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZeroRTTValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZeroRTT: S.Schema<SettingsBulkEditResultItemZeroRTT>;
export type SettingsBulkEditResultItemAdvancedDDoSId = "advanced_ddos";
export declare const SettingsBulkEditResultItemAdvancedDDoSId: any;
export type SettingsBulkEditResultItemAdvancedDDoSValue = "on" | "off";
export declare const SettingsBulkEditResultItemAdvancedDDoSValue: any;
export interface SettingsBulkEditResultItemAdvancedDDoS {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemAdvancedDDoSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemAdvancedDDoSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemAdvancedDDoS: S.Schema<SettingsBulkEditResultItemAdvancedDDoS>;
export type SettingsBulkEditResultItemZonesCacheRulesAegisId = "aegis";
export declare const SettingsBulkEditResultItemZonesCacheRulesAegisId: any;
export type SettingsBulkEditResultItemZonesCacheRulesAegisValue = SettingsGetResultZonesCacheRulesAegisValue;
export declare const SettingsBulkEditResultItemZonesCacheRulesAegisValue: S.Schema<SettingsGetResultZonesCacheRulesAegisValue>;
export interface SettingsBulkEditResultItemZonesCacheRulesAegis {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheRulesAegisId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    value?: SettingsGetResultZonesCacheRulesAegisValue | null;
}
export declare const SettingsBulkEditResultItemZonesCacheRulesAegis: S.Schema<SettingsBulkEditResultItemZonesCacheRulesAegis>;
export type SettingsBulkEditResultItemAlwaysOnlineId = "always_online";
export declare const SettingsBulkEditResultItemAlwaysOnlineId: any;
export type SettingsBulkEditResultItemAlwaysOnlineValue = "on" | "off";
export declare const SettingsBulkEditResultItemAlwaysOnlineValue: any;
export interface SettingsBulkEditResultItemAlwaysOnline {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemAlwaysOnlineId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemAlwaysOnlineValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemAlwaysOnline: S.Schema<SettingsBulkEditResultItemAlwaysOnline>;
export type SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPSId = "always_use_https";
export declare const SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPSId: any;
export type SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPSValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPSValue: any;
export interface SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPS {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPS: S.Schema<SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPS>;
export type SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewritesId: any;
export type SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewritesValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewritesValue: any;
export interface SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewrites {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewritesId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewritesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewrites: S.Schema<SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewrites>;
export type SettingsBulkEditResultItemBrotliId = "brotli";
export declare const SettingsBulkEditResultItemBrotliId: any;
export type SettingsBulkEditResultItemBrotliValue = "off" | "on";
export declare const SettingsBulkEditResultItemBrotliValue: any;
export interface SettingsBulkEditResultItemBrotli {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemBrotliId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemBrotliValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemBrotli: S.Schema<SettingsBulkEditResultItemBrotli>;
export type SettingsBulkEditResultItemZonesSchemasBrowserCacheTTLId = "browser_cache_ttl";
export declare const SettingsBulkEditResultItemZonesSchemasBrowserCacheTTLId: any;
export interface SettingsBulkEditResultItemZonesSchemasBrowserCacheTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasBrowserCacheTTLId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasBrowserCacheTTL: S.Schema<SettingsBulkEditResultItemZonesSchemasBrowserCacheTTL>;
export type SettingsBulkEditResultItemZonesSchemasBrowserCheckId = "browser_check";
export declare const SettingsBulkEditResultItemZonesSchemasBrowserCheckId: any;
export type SettingsBulkEditResultItemZonesSchemasBrowserCheckValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasBrowserCheckValue: any;
export interface SettingsBulkEditResultItemZonesSchemasBrowserCheck {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasBrowserCheckId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasBrowserCheckValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasBrowserCheck: S.Schema<SettingsBulkEditResultItemZonesSchemasBrowserCheck>;
export type SettingsBulkEditResultItemZonesSchemasCacheLevelId = "cache_level";
export declare const SettingsBulkEditResultItemZonesSchemasCacheLevelId: any;
export type SettingsBulkEditResultItemZonesSchemasCacheLevelValue = "aggressive" | "basic" | "simplified";
export declare const SettingsBulkEditResultItemZonesSchemasCacheLevelValue: any;
export interface SettingsBulkEditResultItemZonesSchemasCacheLevel {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasCacheLevelId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasCacheLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasCacheLevel: S.Schema<SettingsBulkEditResultItemZonesSchemasCacheLevel>;
export type SettingsBulkEditResultItemChallengeTTLId = "challenge_ttl";
export declare const SettingsBulkEditResultItemChallengeTTLId: any;
export type SettingsBulkEditResultItemChallengeTTLValue = 300 | 900 | 1800 | 2700 | 3600 | 7200 | 10800 | 14400 | 28800 | 57600 | 86400 | 604800 | 2592000 | 31536000;
export declare const SettingsBulkEditResultItemChallengeTTLValue: any;
export interface SettingsBulkEditResultItemChallengeTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemChallengeTTLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemChallengeTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemChallengeTTL: S.Schema<SettingsBulkEditResultItemChallengeTTL>;
export type SettingsBulkEditResultItemCiphersId = "ciphers";
export declare const SettingsBulkEditResultItemCiphersId: any;
export type SettingsBulkEditResultItemCiphersValueList = Array<string>;
export declare const SettingsBulkEditResultItemCiphersValueList: S.Schema<SettingsBulkEditResultItemCiphersValueList>;
export interface SettingsBulkEditResultItemCiphers {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemCiphersId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemCiphersValueList;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemCiphers: S.Schema<SettingsBulkEditResultItemCiphers>;
export type SettingsBulkEditResultItemZonesContentConverterId = "content_converter";
export declare const SettingsBulkEditResultItemZonesContentConverterId: any;
export type SettingsBulkEditResultItemZonesContentConverterValue = "off" | "on";
export declare const SettingsBulkEditResultItemZonesContentConverterValue: any;
export interface SettingsBulkEditResultItemZonesContentConverter {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesContentConverterId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesContentConverterValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesContentConverter: S.Schema<SettingsBulkEditResultItemZonesContentConverter>;
export type SettingsBulkEditResultItemZonesCNAMEFlatteningId = "cname_flattening";
export declare const SettingsBulkEditResultItemZonesCNAMEFlatteningId: any;
export type SettingsBulkEditResultItemZonesCNAMEFlatteningValue = "flatten_at_root" | "flatten_all";
export declare const SettingsBulkEditResultItemZonesCNAMEFlatteningValue: any;
export interface SettingsBulkEditResultItemZonesCNAMEFlattening {
    /** How to flatten the cname destination. */
    id: SettingsBulkEditResultItemZonesCNAMEFlatteningId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesCNAMEFlatteningValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesCNAMEFlattening: S.Schema<SettingsBulkEditResultItemZonesCNAMEFlattening>;
export type SettingsBulkEditResultItemDevelopmentModeId = "development_mode";
export declare const SettingsBulkEditResultItemDevelopmentModeId: any;
export type SettingsBulkEditResultItemDevelopmentModeValue = "on" | "off";
export declare const SettingsBulkEditResultItemDevelopmentModeValue: any;
export interface SettingsBulkEditResultItemDevelopmentMode {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemDevelopmentModeId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemDevelopmentModeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the zone setting. */
    timeRemaining?: number | null;
}
export declare const SettingsBulkEditResultItemDevelopmentMode: S.Schema<SettingsBulkEditResultItemDevelopmentMode>;
export type SettingsBulkEditResultItemEarlyHintsId = "early_hints";
export declare const SettingsBulkEditResultItemEarlyHintsId: any;
export type SettingsBulkEditResultItemEarlyHintsValue = "on" | "off";
export declare const SettingsBulkEditResultItemEarlyHintsValue: any;
export interface SettingsBulkEditResultItemEarlyHints {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemEarlyHintsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemEarlyHintsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemEarlyHints: S.Schema<SettingsBulkEditResultItemEarlyHints>;
export type SettingsBulkEditResultItemZonesSchemasEdgeCacheTTLId = "edge_cache_ttl";
export declare const SettingsBulkEditResultItemZonesSchemasEdgeCacheTTLId: any;
export type SettingsBulkEditResultItemZonesSchemasEdgeCacheTTLValue = 30 | 60 | 300 | 1200 | 1800 | 3600 | 7200 | 10800 | 14400 | 18000 | 28800 | 43200 | 57600 | 72000 | 86400 | 172800 | 259200 | 345600 | 432000 | 518400 | 604800;
export declare const SettingsBulkEditResultItemZonesSchemasEdgeCacheTTLValue: any;
export interface SettingsBulkEditResultItemZonesSchemasEdgeCacheTTL {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasEdgeCacheTTLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasEdgeCacheTTLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasEdgeCacheTTL: S.Schema<SettingsBulkEditResultItemZonesSchemasEdgeCacheTTL>;
export type SettingsBulkEditResultItemZonesSchemasEmailObfuscationId = "email_obfuscation";
export declare const SettingsBulkEditResultItemZonesSchemasEmailObfuscationId: any;
export type SettingsBulkEditResultItemZonesSchemasEmailObfuscationValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasEmailObfuscationValue: any;
export interface SettingsBulkEditResultItemZonesSchemasEmailObfuscation {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasEmailObfuscationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasEmailObfuscationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasEmailObfuscation: S.Schema<SettingsBulkEditResultItemZonesSchemasEmailObfuscation>;
export type SettingsBulkEditResultItemH2PrioritizationId = "h2_prioritization";
export declare const SettingsBulkEditResultItemH2PrioritizationId: any;
export type SettingsBulkEditResultItemH2PrioritizationValue = "on" | "off" | "custom";
export declare const SettingsBulkEditResultItemH2PrioritizationValue: any;
export interface SettingsBulkEditResultItemH2Prioritization {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemH2PrioritizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemH2PrioritizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemH2Prioritization: S.Schema<SettingsBulkEditResultItemH2Prioritization>;
export type SettingsBulkEditResultItemHotlinkProtectionId = "hotlink_protection";
export declare const SettingsBulkEditResultItemHotlinkProtectionId: any;
export type SettingsBulkEditResultItemHotlinkProtectionValue = "on" | "off";
export declare const SettingsBulkEditResultItemHotlinkProtectionValue: any;
export interface SettingsBulkEditResultItemHotlinkProtection {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemHotlinkProtectionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemHotlinkProtectionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemHotlinkProtection: S.Schema<SettingsBulkEditResultItemHotlinkProtection>;
export type SettingsBulkEditResultItemHTTP2Id = "http2";
export declare const SettingsBulkEditResultItemHTTP2Id: any;
export type SettingsBulkEditResultItemHTTP2Value = "on" | "off";
export declare const SettingsBulkEditResultItemHTTP2Value: any;
export interface SettingsBulkEditResultItemHTTP2 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemHTTP2Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemHTTP2Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemHTTP2: S.Schema<SettingsBulkEditResultItemHTTP2>;
export type SettingsBulkEditResultItemHTTP3Id = "http3";
export declare const SettingsBulkEditResultItemHTTP3Id: any;
export type SettingsBulkEditResultItemHTTP3Value = "on" | "off";
export declare const SettingsBulkEditResultItemHTTP3Value: any;
export interface SettingsBulkEditResultItemHTTP3 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemHTTP3Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemHTTP3Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemHTTP3: S.Schema<SettingsBulkEditResultItemHTTP3>;
export type SettingsBulkEditResultItemImageResizingId = "image_resizing";
export declare const SettingsBulkEditResultItemImageResizingId: any;
export type SettingsBulkEditResultItemImageResizingValue = "on" | "off" | "open";
export declare const SettingsBulkEditResultItemImageResizingValue: any;
export interface SettingsBulkEditResultItemImageResizing {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemImageResizingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemImageResizingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemImageResizing: S.Schema<SettingsBulkEditResultItemImageResizing>;
export type SettingsBulkEditResultItemZonesSchemasIPGeolocationId = "ip_geolocation";
export declare const SettingsBulkEditResultItemZonesSchemasIPGeolocationId: any;
export type SettingsBulkEditResultItemZonesSchemasIPGeolocationValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasIPGeolocationValue: any;
export interface SettingsBulkEditResultItemZonesSchemasIPGeolocation {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasIPGeolocationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasIPGeolocationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasIPGeolocation: S.Schema<SettingsBulkEditResultItemZonesSchemasIPGeolocation>;
export type SettingsBulkEditResultItemIPV6Id = "ipv6";
export declare const SettingsBulkEditResultItemIPV6Id: any;
export type SettingsBulkEditResultItemIPV6Value = "off" | "on";
export declare const SettingsBulkEditResultItemIPV6Value: any;
export interface SettingsBulkEditResultItemIPV6 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemIPV6Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemIPV6Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemIPV6: S.Schema<SettingsBulkEditResultItemIPV6>;
export type SettingsBulkEditResultItemZonesMaxUploadId = "max_upload";
export declare const SettingsBulkEditResultItemZonesMaxUploadId: any;
export type SettingsBulkEditResultItemZonesMaxUploadValue = 100 | 125 | 150 | 175 | 200 | 225 | 250 | 275 | 300 | 325 | 350 | 375 | 400 | 425 | 450 | 475 | 500 | 1000;
export declare const SettingsBulkEditResultItemZonesMaxUploadValue: any;
export interface SettingsBulkEditResultItemZonesMaxUpload {
    /** identifier of the zone setting. */
    id: SettingsBulkEditResultItemZonesMaxUploadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesMaxUploadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesMaxUpload: S.Schema<SettingsBulkEditResultItemZonesMaxUpload>;
export type SettingsBulkEditResultItemMinTLSVersionId = "min_tls_version";
export declare const SettingsBulkEditResultItemMinTLSVersionId: any;
export type SettingsBulkEditResultItemMinTLSVersionValue = "1.0" | "1.1" | "1.2" | "1.3";
export declare const SettingsBulkEditResultItemMinTLSVersionValue: any;
export interface SettingsBulkEditResultItemMinTLSVersion {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemMinTLSVersionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemMinTLSVersionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemMinTLSVersion: S.Schema<SettingsBulkEditResultItemMinTLSVersion>;
export type SettingsBulkEditResultItemZonesSchemasMirageId = "mirage";
export declare const SettingsBulkEditResultItemZonesSchemasMirageId: any;
export type SettingsBulkEditResultItemZonesSchemasMirageValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasMirageValue: any;
export interface SettingsBulkEditResultItemZonesSchemasMirage {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasMirageId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasMirageValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasMirage: S.Schema<SettingsBulkEditResultItemZonesSchemasMirage>;
export type SettingsBulkEditResultItemNELId = "nel";
export declare const SettingsBulkEditResultItemNELId: any;
export type SettingsBulkEditResultItemNELValue = SettingsGetResultNELValue;
export declare const SettingsBulkEditResultItemNELValue: S.Schema<SettingsGetResultNELValue>;
export interface SettingsBulkEditResultItemNEL {
    /** Zone setting identifier. */
    id: SettingsBulkEditResultItemNELId;
    /** Current value of the zone setting. */
    value: SettingsGetResultNELValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemNEL: S.Schema<SettingsBulkEditResultItemNEL>;
export type SettingsBulkEditResultItemZonesSchemasOpportunisticEncryptionId = "opportunistic_encryption";
export declare const SettingsBulkEditResultItemZonesSchemasOpportunisticEncryptionId: any;
export type SettingsBulkEditResultItemZonesSchemasOpportunisticEncryptionValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasOpportunisticEncryptionValue: any;
export interface SettingsBulkEditResultItemZonesSchemasOpportunisticEncryption {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasOpportunisticEncryptionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasOpportunisticEncryptionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasOpportunisticEncryption: S.Schema<SettingsBulkEditResultItemZonesSchemasOpportunisticEncryption>;
export type SettingsBulkEditResultItemOpportunisticOnionId = "opportunistic_onion";
export declare const SettingsBulkEditResultItemOpportunisticOnionId: any;
export type SettingsBulkEditResultItemOpportunisticOnionValue = "on" | "off";
export declare const SettingsBulkEditResultItemOpportunisticOnionValue: any;
export interface SettingsBulkEditResultItemOpportunisticOnion {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemOpportunisticOnionId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemOpportunisticOnionValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemOpportunisticOnion: S.Schema<SettingsBulkEditResultItemOpportunisticOnion>;
export type SettingsBulkEditResultItemOrangeToOrangeId = "orange_to_orange";
export declare const SettingsBulkEditResultItemOrangeToOrangeId: any;
export type SettingsBulkEditResultItemOrangeToOrangeValue = "on" | "off";
export declare const SettingsBulkEditResultItemOrangeToOrangeValue: any;
export interface SettingsBulkEditResultItemOrangeToOrange {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemOrangeToOrangeId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemOrangeToOrangeValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemOrangeToOrange: S.Schema<SettingsBulkEditResultItemOrangeToOrange>;
export type SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThruId: any;
export type SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThruValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThruValue: any;
export interface SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThru {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThruId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThruValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThru: S.Schema<SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThru>;
export type SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreamsId = "origin_h2_max_streams";
export declare const SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreamsId: any;
export interface SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreams {
    /** Value of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreamsId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin H2 Max Streams Setting. */
    value?: number | null;
}
export declare const SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreams: S.Schema<SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreams>;
export type SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionId = "origin_max_http_version";
export declare const SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionId: any;
export type SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionValue = "2" | "1";
export declare const SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionValue: any;
export interface SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersion {
    /** Value of the zone setting. */
    id: SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionId;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
    /** Value of the Origin Max HTTP Version Setting. */
    value?: SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersionValue | null;
}
export declare const SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersion: S.Schema<SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersion>;
export type SettingsBulkEditResultItemZonesSchemasPolishId = "polish";
export declare const SettingsBulkEditResultItemZonesSchemasPolishId: any;
export type SettingsBulkEditResultItemZonesSchemasPolishValue = "off" | "lossless" | "lossy";
export declare const SettingsBulkEditResultItemZonesSchemasPolishValue: any;
export interface SettingsBulkEditResultItemZonesSchemasPolish {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasPolishId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasPolishValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasPolish: S.Schema<SettingsBulkEditResultItemZonesSchemasPolish>;
export type SettingsBulkEditResultItemPrefetchPreloadId = "prefetch_preload";
export declare const SettingsBulkEditResultItemPrefetchPreloadId: any;
export type SettingsBulkEditResultItemPrefetchPreloadValue = "on" | "off";
export declare const SettingsBulkEditResultItemPrefetchPreloadValue: any;
export interface SettingsBulkEditResultItemPrefetchPreload {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemPrefetchPreloadId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemPrefetchPreloadValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemPrefetchPreload: S.Schema<SettingsBulkEditResultItemPrefetchPreload>;
export type SettingsBulkEditResultItemZonesPrivacyPassId = "privacy_pass";
export declare const SettingsBulkEditResultItemZonesPrivacyPassId: any;
export type SettingsBulkEditResultItemZonesPrivacyPassValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesPrivacyPassValue: any;
export interface SettingsBulkEditResultItemZonesPrivacyPass {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesPrivacyPassId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesPrivacyPassValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesPrivacyPass: S.Schema<SettingsBulkEditResultItemZonesPrivacyPass>;
export type SettingsBulkEditResultItemProxyReadTimeoutId = "proxy_read_timeout";
export declare const SettingsBulkEditResultItemProxyReadTimeoutId: any;
export interface SettingsBulkEditResultItemProxyReadTimeout {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemProxyReadTimeoutId;
    /** Current value of the zone setting. */
    value: number;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemProxyReadTimeout: S.Schema<SettingsBulkEditResultItemProxyReadTimeout>;
export type SettingsBulkEditResultItemPseudoIPV4Id = "pseudo_ipv4";
export declare const SettingsBulkEditResultItemPseudoIPV4Id: any;
export type SettingsBulkEditResultItemPseudoIPV4Value = "off" | "add_header" | "overwrite_header";
export declare const SettingsBulkEditResultItemPseudoIPV4Value: any;
export interface SettingsBulkEditResultItemPseudoIPV4 {
    /** Value of the Pseudo IPv4 setting. */
    id: SettingsBulkEditResultItemPseudoIPV4Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemPseudoIPV4Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemPseudoIPV4: S.Schema<SettingsBulkEditResultItemPseudoIPV4>;
export type SettingsBulkEditResultItemZonesRedirectsForAITrainingId = "redirects_for_ai_training";
export declare const SettingsBulkEditResultItemZonesRedirectsForAITrainingId: any;
export type SettingsBulkEditResultItemZonesRedirectsForAITrainingValue = "off" | "on";
export declare const SettingsBulkEditResultItemZonesRedirectsForAITrainingValue: any;
export interface SettingsBulkEditResultItemZonesRedirectsForAITraining {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesRedirectsForAITrainingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesRedirectsForAITrainingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesRedirectsForAITraining: S.Schema<SettingsBulkEditResultItemZonesRedirectsForAITraining>;
export type SettingsBulkEditResultItemZonesReplaceInsecureJSId = "replace_insecure_js";
export declare const SettingsBulkEditResultItemZonesReplaceInsecureJSId: any;
export type SettingsBulkEditResultItemZonesReplaceInsecureJSValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesReplaceInsecureJSValue: any;
export interface SettingsBulkEditResultItemZonesReplaceInsecureJS {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesReplaceInsecureJSId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesReplaceInsecureJSValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesReplaceInsecureJS: S.Schema<SettingsBulkEditResultItemZonesReplaceInsecureJS>;
export type SettingsBulkEditResultItemZonesSchemasResponseBufferingId = "response_buffering";
export declare const SettingsBulkEditResultItemZonesSchemasResponseBufferingId: any;
export type SettingsBulkEditResultItemZonesSchemasResponseBufferingValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasResponseBufferingValue: any;
export interface SettingsBulkEditResultItemZonesSchemasResponseBuffering {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasResponseBufferingId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasResponseBufferingValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasResponseBuffering: S.Schema<SettingsBulkEditResultItemZonesSchemasResponseBuffering>;
export type SettingsBulkEditResultItemZonesSchemasRocketLoaderId = "rocket_loader";
export declare const SettingsBulkEditResultItemZonesSchemasRocketLoaderId: any;
export type SettingsBulkEditResultItemZonesSchemasRocketLoaderValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasRocketLoaderValue: any;
export interface SettingsBulkEditResultItemZonesSchemasRocketLoader {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasRocketLoaderId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasRocketLoaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasRocketLoader: S.Schema<SettingsBulkEditResultItemZonesSchemasRocketLoader>;
export type SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationId = "automatic_platform_optimization";
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationId: any;
export type SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList = Array<string>;
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList: S.Schema<SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList>;
export interface SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValue {
    /** Indicates whether or not [cache by device type](https://developers.cloudflare.com/automatic-platform-optimization/reference/cache-device-type/) is enabled. */
    cacheByDeviceType: boolean;
    /** Indicates whether or not Cloudflare proxy is enabled. */
    cf: boolean;
    /** Indicates whether or not Automatic Platform Optimization is enabled. */
    enabled: boolean;
    /** An array of hostnames where Automatic Platform Optimization for WordPress is activated. */
    hostnames: SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValueHostnamesList;
    /** Indicates whether or not site is powered by WordPress. */
    wordpress: boolean;
    /** Indicates whether or not [Cloudflare for WordPress plugin](https://wordpress.org/plugins/cloudflare/) is installed. */
    wpPlugin: boolean;
}
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValue: S.Schema<SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValue>;
export interface SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimization {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimizationValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimization: S.Schema<SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimization>;
export type SettingsBulkEditResultItemZonesSearchForAgentsId = "search_for_agents";
export declare const SettingsBulkEditResultItemZonesSearchForAgentsId: any;
export type SettingsBulkEditResultItemZonesSearchForAgentsValue = "off" | "on";
export declare const SettingsBulkEditResultItemZonesSearchForAgentsValue: any;
export interface SettingsBulkEditResultItemZonesSearchForAgents {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSearchForAgentsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSearchForAgentsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSearchForAgents: S.Schema<SettingsBulkEditResultItemZonesSearchForAgents>;
export type SettingsBulkEditResultItemSecurityHeadersId = "security_header";
export declare const SettingsBulkEditResultItemSecurityHeadersId: any;
export type SettingsBulkEditResultItemSecurityHeadersValueStrictTransportSecurity = SettingsGetResultSecurityHeadersValueStrictTransportSecurity;
export declare const SettingsBulkEditResultItemSecurityHeadersValueStrictTransportSecurity: S.Schema<SettingsGetResultSecurityHeadersValueStrictTransportSecurity>;
export type SettingsBulkEditResultItemSecurityHeadersValue = SettingsGetResultSecurityHeadersValue;
export declare const SettingsBulkEditResultItemSecurityHeadersValue: S.Schema<SettingsGetResultSecurityHeadersValue>;
export interface SettingsBulkEditResultItemSecurityHeaders {
    /** ID of the zone's security header. */
    id: SettingsBulkEditResultItemSecurityHeadersId;
    /** Current value of the zone setting. */
    value: SettingsGetResultSecurityHeadersValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemSecurityHeaders: S.Schema<SettingsBulkEditResultItemSecurityHeaders>;
export type SettingsBulkEditResultItemZonesSchemasSecurityLevelId = "security_level";
export declare const SettingsBulkEditResultItemZonesSchemasSecurityLevelId: any;
export type SettingsBulkEditResultItemZonesSchemasSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const SettingsBulkEditResultItemZonesSchemasSecurityLevelValue: any;
export interface SettingsBulkEditResultItemZonesSchemasSecurityLevel {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasSecurityLevelId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasSecurityLevelValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasSecurityLevel: S.Schema<SettingsBulkEditResultItemZonesSchemasSecurityLevel>;
export type SettingsBulkEditResultItemServerSideExcludesId = "server_side_exclude";
export declare const SettingsBulkEditResultItemServerSideExcludesId: any;
export type SettingsBulkEditResultItemServerSideExcludesValue = "on" | "off";
export declare const SettingsBulkEditResultItemServerSideExcludesValue: any;
export interface SettingsBulkEditResultItemServerSideExcludes {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemServerSideExcludesId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemServerSideExcludesValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemServerSideExcludes: S.Schema<SettingsBulkEditResultItemServerSideExcludes>;
export type SettingsBulkEditResultItemZonesSha1SupportId = "sha1_support";
export declare const SettingsBulkEditResultItemZonesSha1SupportId: any;
export type SettingsBulkEditResultItemZonesSha1SupportValue = "off" | "on";
export declare const SettingsBulkEditResultItemZonesSha1SupportValue: any;
export interface SettingsBulkEditResultItemZonesSha1Support {
    /** Zone setting identifier. */
    id: SettingsBulkEditResultItemZonesSha1SupportId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSha1SupportValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSha1Support: S.Schema<SettingsBulkEditResultItemZonesSha1Support>;
export type SettingsBulkEditResultItemZonesSchemasSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const SettingsBulkEditResultItemZonesSchemasSortQueryStringForCacheId: any;
export type SettingsBulkEditResultItemZonesSchemasSortQueryStringForCacheValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasSortQueryStringForCacheValue: any;
export interface SettingsBulkEditResultItemZonesSchemasSortQueryStringForCache {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasSortQueryStringForCacheId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasSortQueryStringForCacheValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasSortQueryStringForCache: S.Schema<SettingsBulkEditResultItemZonesSchemasSortQueryStringForCache>;
export type SettingsBulkEditResultItemZonesSchemasSSLId = "ssl";
export declare const SettingsBulkEditResultItemZonesSchemasSSLId: any;
export type SettingsBulkEditResultItemZonesSchemasSSLValue = "off" | "flexible" | "full" | "strict";
export declare const SettingsBulkEditResultItemZonesSchemasSSLValue: any;
export interface SettingsBulkEditResultItemZonesSchemasSSL {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasSSLId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasSSLValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasSSL: S.Schema<SettingsBulkEditResultItemZonesSchemasSSL>;
export type SettingsBulkEditResultItemSSLRecommenderId = "ssl_recommender";
export declare const SettingsBulkEditResultItemSSLRecommenderId: any;
export interface SettingsBulkEditResultItemSSLRecommender {
    /** Enrollment value for SSL/TLS Recommender. */
    id?: SettingsBulkEditResultItemSSLRecommenderId | null;
    /** ssl-recommender enrollment setting. */
    enabled?: boolean | null;
}
export declare const SettingsBulkEditResultItemSSLRecommender: S.Schema<SettingsBulkEditResultItemSSLRecommender>;
export type SettingsBulkEditResultItemZonesTLS12OnlyId = "tls_1_2_only";
export declare const SettingsBulkEditResultItemZonesTLS12OnlyId: any;
export type SettingsBulkEditResultItemZonesTLS12OnlyValue = "off" | "on";
export declare const SettingsBulkEditResultItemZonesTLS12OnlyValue: any;
export interface SettingsBulkEditResultItemZonesTLS12Only {
    /** Zone setting identifier. */
    id: SettingsBulkEditResultItemZonesTLS12OnlyId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesTLS12OnlyValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesTLS12Only: S.Schema<SettingsBulkEditResultItemZonesTLS12Only>;
export type SettingsBulkEditResultItemTLS13Id = "tls_1_3";
export declare const SettingsBulkEditResultItemTLS13Id: any;
export type SettingsBulkEditResultItemTLS13Value = "on" | "off" | "zrt";
export declare const SettingsBulkEditResultItemTLS13Value: any;
export interface SettingsBulkEditResultItemTLS13 {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemTLS13Id;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemTLS13Value;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemTLS13: S.Schema<SettingsBulkEditResultItemTLS13>;
export type SettingsBulkEditResultItemTLSClientAuthId = "tls_client_auth";
export declare const SettingsBulkEditResultItemTLSClientAuthId: any;
export type SettingsBulkEditResultItemTLSClientAuthValue = "on" | "off";
export declare const SettingsBulkEditResultItemTLSClientAuthValue: any;
export interface SettingsBulkEditResultItemTLSClientAuth {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemTLSClientAuthId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemTLSClientAuthValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemTLSClientAuth: S.Schema<SettingsBulkEditResultItemTLSClientAuth>;
export type SettingsBulkEditResultItemZonesTransformationsId = "transformations";
export declare const SettingsBulkEditResultItemZonesTransformationsId: any;
export type SettingsBulkEditResultItemZonesTransformationsValue = "on" | "off" | "open";
export declare const SettingsBulkEditResultItemZonesTransformationsValue: any;
export interface SettingsBulkEditResultItemZonesTransformations {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsBulkEditResultItemZonesTransformationsId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesTransformationsValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesTransformations: S.Schema<SettingsBulkEditResultItemZonesTransformations>;
export type SettingsBulkEditResultItemZonesTransformationsAllowedOriginsId = "transformations_allowed_origins";
export declare const SettingsBulkEditResultItemZonesTransformationsAllowedOriginsId: any;
export interface SettingsBulkEditResultItemZonesTransformationsAllowedOrigins {
    /** ID of the zone setting. Shared between Image Transformations and Video Transformations. */
    id: SettingsBulkEditResultItemZonesTransformationsAllowedOriginsId;
    /** Current value of the zone setting. */
    value: string;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesTransformationsAllowedOrigins: S.Schema<SettingsBulkEditResultItemZonesTransformationsAllowedOrigins>;
export type SettingsBulkEditResultItemZonesSchemasTrueClientIPHeaderId = "true_client_ip_header";
export declare const SettingsBulkEditResultItemZonesSchemasTrueClientIPHeaderId: any;
export type SettingsBulkEditResultItemZonesSchemasTrueClientIPHeaderValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasTrueClientIPHeaderValue: any;
export interface SettingsBulkEditResultItemZonesSchemasTrueClientIPHeader {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasTrueClientIPHeaderId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasTrueClientIPHeaderValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasTrueClientIPHeader: S.Schema<SettingsBulkEditResultItemZonesSchemasTrueClientIPHeader>;
export type SettingsBulkEditResultItemZonesSchemasWAFId = "waf";
export declare const SettingsBulkEditResultItemZonesSchemasWAFId: any;
export type SettingsBulkEditResultItemZonesSchemasWAFValue = "on" | "off";
export declare const SettingsBulkEditResultItemZonesSchemasWAFValue: any;
export interface SettingsBulkEditResultItemZonesSchemasWAF {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemZonesSchemasWAFId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemZonesSchemasWAFValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemZonesSchemasWAF: S.Schema<SettingsBulkEditResultItemZonesSchemasWAF>;
export type SettingsBulkEditResultItemWebPId = "webp";
export declare const SettingsBulkEditResultItemWebPId: any;
export type SettingsBulkEditResultItemWebPValue = "off" | "on";
export declare const SettingsBulkEditResultItemWebPValue: any;
export interface SettingsBulkEditResultItemWebP {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemWebPId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemWebPValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemWebP: S.Schema<SettingsBulkEditResultItemWebP>;
export type SettingsBulkEditResultItemWebsocketId = "websockets";
export declare const SettingsBulkEditResultItemWebsocketId: any;
export type SettingsBulkEditResultItemWebsocketValue = "off" | "on";
export declare const SettingsBulkEditResultItemWebsocketValue: any;
export interface SettingsBulkEditResultItemWebsocket {
    /** ID of the zone setting. */
    id: SettingsBulkEditResultItemWebsocketId;
    /** Current value of the zone setting. */
    value: SettingsBulkEditResultItemWebsocketValue;
    /** Whether or not this setting can be modified for this zone (based on your Cloudflare plan level). */
    editable?: boolean | null;
    /** last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const SettingsBulkEditResultItemWebsocket: S.Schema<SettingsBulkEditResultItemWebsocket>;
export type SettingsBulkEditResultItem = SettingsBulkEditResultItemZeroRTT | SettingsBulkEditResultItemAdvancedDDoS | SettingsBulkEditResultItemZonesCacheRulesAegis | SettingsBulkEditResultItemAlwaysOnline | SettingsBulkEditResultItemZonesSchemasAlwaysUseHTTPS | SettingsBulkEditResultItemZonesSchemasAutomaticHTTPSRewrites | SettingsBulkEditResultItemBrotli | SettingsBulkEditResultItemZonesSchemasBrowserCacheTTL | SettingsBulkEditResultItemZonesSchemasBrowserCheck | SettingsBulkEditResultItemZonesSchemasCacheLevel | SettingsBulkEditResultItemChallengeTTL | SettingsBulkEditResultItemCiphers | SettingsBulkEditResultItemZonesContentConverter | SettingsBulkEditResultItemZonesCNAMEFlattening | SettingsBulkEditResultItemDevelopmentMode | SettingsBulkEditResultItemEarlyHints | SettingsBulkEditResultItemZonesSchemasEdgeCacheTTL | SettingsBulkEditResultItemZonesSchemasEmailObfuscation | SettingsBulkEditResultItemH2Prioritization | SettingsBulkEditResultItemHotlinkProtection | SettingsBulkEditResultItemHTTP2 | SettingsBulkEditResultItemHTTP3 | SettingsBulkEditResultItemImageResizing | SettingsBulkEditResultItemZonesSchemasIPGeolocation | SettingsBulkEditResultItemIPV6 | SettingsBulkEditResultItemZonesMaxUpload | SettingsBulkEditResultItemMinTLSVersion | SettingsBulkEditResultItemZonesSchemasMirage | SettingsBulkEditResultItemNEL | SettingsBulkEditResultItemZonesSchemasOpportunisticEncryption | SettingsBulkEditResultItemOpportunisticOnion | SettingsBulkEditResultItemOrangeToOrange | SettingsBulkEditResultItemZonesSchemasOriginErrorPagePassThru | SettingsBulkEditResultItemZonesCacheRulesOriginH2MaxStreams | SettingsBulkEditResultItemZonesCacheRulesOriginMaxHTTPVersion | SettingsBulkEditResultItemZonesSchemasPolish | SettingsBulkEditResultItemPrefetchPreload | SettingsBulkEditResultItemZonesPrivacyPass | SettingsBulkEditResultItemProxyReadTimeout | SettingsBulkEditResultItemPseudoIPV4 | SettingsBulkEditResultItemZonesRedirectsForAITraining | SettingsBulkEditResultItemZonesReplaceInsecureJS | SettingsBulkEditResultItemZonesSchemasResponseBuffering | SettingsBulkEditResultItemZonesSchemasRocketLoader | SettingsBulkEditResultItemZonesSchemasAutomaticPlatformOptimization | SettingsBulkEditResultItemZonesSearchForAgents | SettingsBulkEditResultItemSecurityHeaders | SettingsBulkEditResultItemZonesSchemasSecurityLevel | SettingsBulkEditResultItemServerSideExcludes | SettingsBulkEditResultItemZonesSha1Support | SettingsBulkEditResultItemZonesSchemasSortQueryStringForCache | SettingsBulkEditResultItemZonesSchemasSSL | SettingsBulkEditResultItemSSLRecommender | SettingsBulkEditResultItemZonesTLS12Only | SettingsBulkEditResultItemTLS13 | SettingsBulkEditResultItemTLSClientAuth | SettingsBulkEditResultItemZonesTransformations | SettingsBulkEditResultItemZonesTransformationsAllowedOrigins | SettingsBulkEditResultItemZonesSchemasTrueClientIPHeader | SettingsBulkEditResultItemZonesSchemasWAF | SettingsBulkEditResultItemWebP | SettingsBulkEditResultItemWebsocket;
export declare const SettingsBulkEditResultItem: any;
export type SettingsBulkEditResultList = Array<SettingsBulkEditResultItem>;
export declare const SettingsBulkEditResultList: S.Schema<SettingsBulkEditResultList>;
export type SettingsBulkEditResponse = SettingsBulkEditResultList;
export declare const SettingsBulkEditResponse: S.Schema<SettingsBulkEditResponse>;
export interface TriggerActivationCheckRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const TriggerActivationCheckRequest: S.Schema<TriggerActivationCheckRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TriggerActivationCheckResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const TriggerActivationCheckResponse: S.Schema<TriggerActivationCheckResponse>;
export type EnvironmentsUpdateRequestEnvironmentsItemPosition = EnvironmentsCreateRequestEnvironmentsItemPosition;
export declare const EnvironmentsUpdateRequestEnvironmentsItemPosition: S.Schema<EnvironmentsCreateRequestEnvironmentsItemPosition>;
export type EnvironmentsUpdateRequestEnvironmentsItem = EnvironmentsCreateRequestEnvironmentsItem;
export declare const EnvironmentsUpdateRequestEnvironmentsItem: S.Schema<EnvironmentsCreateRequestEnvironmentsItem>;
export type EnvironmentsUpdateRequestEnvironmentsList = Array<EnvironmentsCreateRequestEnvironmentsItem>;
export declare const EnvironmentsUpdateRequestEnvironmentsList: S.Schema<EnvironmentsUpdateRequestEnvironmentsList>;
export interface UpdateEnvironmentRequest {
    zoneId: string;
    environments: EnvironmentsUpdateRequestEnvironmentsList;
}
export declare const UpdateEnvironmentRequest: S.Schema<UpdateEnvironmentRequest>;
export type EnvironmentsUpdateResponseEnvironmentsItemPosition = EnvironmentsCreateResponseEnvironmentsItemPosition;
export declare const EnvironmentsUpdateResponseEnvironmentsItemPosition: S.Schema<EnvironmentsCreateResponseEnvironmentsItemPosition>;
export type EnvironmentsUpdateResponseEnvironmentsItem = EnvironmentsCreateResponseEnvironmentsItem;
export declare const EnvironmentsUpdateResponseEnvironmentsItem: S.Schema<EnvironmentsCreateResponseEnvironmentsItem>;
export type EnvironmentsUpdateResponseEnvironmentsList = Array<EnvironmentsCreateResponseEnvironmentsItem>;
export declare const EnvironmentsUpdateResponseEnvironmentsList: S.Schema<EnvironmentsUpdateResponseEnvironmentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateEnvironmentResponse {
    environments: EnvironmentsUpdateResponseEnvironmentsList;
}
export declare const UpdateEnvironmentResponse: S.Schema<UpdateEnvironmentResponse>;
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsUpdateRequestFrequency: any;
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsUpdateRequestRatePlanId: any;
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export declare const SubscriptionsUpdateRequestRatePlanSetsList: S.Schema<SubscriptionsUpdateRequestRatePlanSetsList>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList;
}
export declare const SubscriptionsUpdateRequestRatePlan: S.Schema<SubscriptionsUpdateRequestRatePlan>;
export interface UpdateSubscriptionRequest {
    /** Identifier */
    zoneId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan;
}
export declare const UpdateSubscriptionRequest: S.Schema<UpdateSubscriptionRequest>;
export type SubscriptionsUpdateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly" | "not-applicable";
export declare const SubscriptionsUpdateResponseFrequency: any;
export type SubscriptionsUpdateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsUpdateResponseRatePlanId: any;
export type SubscriptionsUpdateResponseRatePlanSetsList = Array<string>;
export declare const SubscriptionsUpdateResponseRatePlanSetsList: S.Schema<SubscriptionsUpdateResponseRatePlanSetsList>;
export interface SubscriptionsUpdateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateResponseRatePlanSetsList | null;
}
export declare const SubscriptionsUpdateResponseRatePlan: S.Schema<SubscriptionsUpdateResponseRatePlan>;
export type SubscriptionsUpdateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsUpdateResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsUpdateResponseState | null;
}
export declare const UpdateSubscriptionResponse: S.Schema<UpdateSubscriptionResponse>;
export type CreateEnvironmentError = CloudflareOpError;
/** Create zone environments */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, CloudflareOpContext>;
export type CreateHoldError = ZoneHoldsRequireEnterprise | InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Enforce a zone hold on the zone, blocking the creation and activation of zones with this zone's hostname. Zone holds cannot be enabled on CDN-only zones. */
export declare const createHold: API.OperationMethod<CreateHoldRequest, CreateHoldResponse, CreateHoldError, CloudflareOpContext>;
export type CreateSubscriptionError = CloudflareOpError;
/** Create a zone subscription, either plan or add-ons. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type CreateZoneError = ZoneAlreadyExists | ZoneCreationBlocked | InvalidDomain | DomainNotRegistered | SubdomainNotAllowed | CloudflareOpError;
/** Create Zone */
export declare const createZone: API.OperationMethod<CreateZoneRequest, CreateZoneResponse, CreateZoneError, CloudflareOpContext>;
export type DeleteEnvironmentError = CloudflareOpError;
/** Delete zone environment */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, CloudflareOpContext>;
export type DeleteHoldError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Stop enforcement of a zone hold on the zone, permanently or temporarily, allowing the creation and activation of zones with this zone's hostname. Existing zone holds can be removed from CDN-only zones when `hold_after` is not provided. Active holds are automatically disabled when a zone transitions to CDN-only mode. */
export declare const deleteHold: API.OperationMethod<DeleteHoldRequest, DeleteHoldResponse, DeleteHoldError, CloudflareOpContext>;
export type DeleteZoneError = InvalidZoneIdentifier | CloudflareOpError;
/** Deletes an existing zone. */
export declare const deleteZone: API.OperationMethod<DeleteZoneRequest, DeleteZoneResponse, DeleteZoneError, CloudflareOpContext>;
export type GetCtAlertingError = CloudflareOpError;
/** Retrieve the Certificate Transparency alerting subscription settings for a zone. Returns whether CT monitoring is enabled and, for Business and Enterprise zones, the list of email addresses that receive alerts. */
export declare const getCtAlerting: API.OperationMethod<GetCtAlertingRequest, GetCtAlertingResponse, GetCtAlertingError, CloudflareOpContext>;
export type GetCustomNameserverError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Get metadata for account-level custom nameservers on a zone. Deprecated in favor of [Show DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-a-zone-list-dns-settings). */
export declare const getCustomNameserver: API.OperationMethod<GetCustomNameserverRequest, GetCustomNameserverResponse, GetCustomNameserverError, CloudflareOpContext>;
export type GetHoldError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Retrieve whether the zone is subject to a zone hold, and metadata about the hold. */
export declare const getHold: API.OperationMethod<GetHoldRequest, GetHoldResponse, GetHoldError, CloudflareOpContext>;
export type GetPlanError = CloudflareOpError;
/** Details of the available plan that the zone can subscribe to. */
export declare const getPlan: API.OperationMethod<GetPlanRequest, GetPlanResponse, GetPlanError, CloudflareOpContext>;
export type GetRatePlanError = CloudflareOpError;
/** Lists all rate plans the zone can subscribe to. */
export declare const getRatePlan: API.PaginatedOperationMethod<GetRatePlanRequest, GetRatePlanResponse, GetRatePlanError, CloudflareOpContext, RatePlansGetResultItem>;
export type GetSettingError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Fetch a single zone setting by name */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists zone subscription details. */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext>;
export type GetZoneError = InvalidZoneIdentifier | CloudflareOpError;
/** Zone Details */
export declare const getZone: API.OperationMethod<GetZoneRequest, GetZoneResponse, GetZoneError, CloudflareOpContext>;
export type ListEnvironmentsError = CloudflareOpError;
/** List zone environments */
export declare const listEnvironments: API.OperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, CloudflareOpContext>;
export type ListPlansError = CloudflareOpError;
/** Lists available plans the zone can subscribe to. */
export declare const listPlans: API.PaginatedOperationMethod<ListPlansRequest, ListPlansResponse, ListPlansError, CloudflareOpContext, PlansListResultItem>;
export type ListSettingsError = CloudflareOpError;
/** Available settings for your user in relation to a zone. */
export declare const listSettings: API.OperationMethod<ListSettingsRequest, ListSettingsResponse, ListSettingsError, CloudflareOpContext>;
export type ListZonesError = CloudflareOpError;
/** Lists, searches, sorts, and filters your zones. Listing zones across more than 500 accounts is currently not allowed. */
export declare const listZones: API.PaginatedOperationMethod<ListZonesRequest, ListZonesResponse, ListZonesError, CloudflareOpContext, ListResultItem>;
export type PatchCtAlertingError = CloudflareOpError;
/** Create or update the Certificate Transparency alerting subscription for a zone. Enables or disables email notifications when certificates are issued for the zone's domains. For Free and Pro zones, the subscription is toggled on or off using the enabled field. Notification emails are sent to all users with SSL permissions on the zone. For Business and Enterprise zones, the emails field is required and controls which addresses receive alerts. Setting emails to an empty list disables the subscription regardless of the enabled field. A maximum of 10 email addresses may be configured. */
export declare const patchCtAlerting: API.OperationMethod<PatchCtAlertingRequest, PatchCtAlertingResponse, PatchCtAlertingError, CloudflareOpContext>;
export type PatchEnvironmentError = CloudflareOpError;
/** Partially update zone environments */
export declare const patchEnvironment: API.OperationMethod<PatchEnvironmentRequest, PatchEnvironmentResponse, PatchEnvironmentError, CloudflareOpContext>;
export type PatchHoldError = ZoneHoldNotFound | ZoneHoldsRequireEnterprise | InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Update the `hold_after` and/or `include_subdomains` values on an existing zone hold. The hold is enabled if the `hold_after` date-time value is in the past. Existing zone holds can be removed from CDN-only zones by setting `hold_after` to `null`. Other zone hold updates cannot be made on CDN-only zones. Active holds are automatically disabled when a zone transitions to CDN-only mode. */
export declare const patchHold: API.OperationMethod<PatchHoldRequest, PatchHoldResponse, PatchHoldError, CloudflareOpContext>;
export type PatchSettingError = InvalidZoneIdentifier | Forbidden | CloudflareOpError;
/** Updates a single zone setting by the identifier */
export declare const patchSetting: API.OperationMethod<PatchSettingRequest, PatchSettingResponse, PatchSettingError, CloudflareOpContext>;
export type PatchZoneError = InvalidZoneIdentifier | CloudflareOpError;
/** Edits a zone. Only one zone property can be changed at a time. */
export declare const patchZone: API.OperationMethod<PatchZoneRequest, PatchZoneResponse, PatchZoneError, CloudflareOpContext>;
export type PutCustomNameserverError = InvalidZoneIdentifier | CustomNameserverSetNotFound | Forbidden | CloudflareOpError;
/** Set metadata for account-level custom nameservers on a zone. If you would like new zones in the account to use account custom nameservers by default, use PUT /accounts/:identifier to set the account setting use_account_custom_ns_by_default to true. Deprecated in favor of [Update DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-a-zone-update-dns-settings). */
export declare const putCustomNameserver: API.PaginatedOperationMethod<PutCustomNameserverRequest, PutCustomNameserverResponse, PutCustomNameserverError, CloudflareOpContext, string>;
export type RollbackEnvironmentError = CloudflareOpError;
/** Roll back zone environment */
export declare const rollbackEnvironment: API.OperationMethod<RollbackEnvironmentRequest, RollbackEnvironmentResponse, RollbackEnvironmentError, CloudflareOpContext>;
export type SettingsBulkEditError = CloudflareOpError;
/** Edit settings for a zone. */
export declare const settingsBulkEdit: API.OperationMethod<SettingsBulkEditRequest, SettingsBulkEditResponse, SettingsBulkEditError, CloudflareOpContext>;
export type TriggerActivationCheckError = CloudflareOpError;
/** Triggeres a new activation check for a PENDING Zone. This can be triggered every 5 min for paygo/ent customers, every hour for FREE Zones. */
export declare const triggerActivationCheck: API.OperationMethod<TriggerActivationCheckRequest, TriggerActivationCheckResponse, TriggerActivationCheckError, CloudflareOpContext>;
export type UpdateEnvironmentError = CloudflareOpError;
/** Upsert zone environments */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest, UpdateEnvironmentResponse, UpdateEnvironmentError, CloudflareOpContext>;
export type UpdateSubscriptionError = CloudflareOpError;
/** Updates zone subscriptions, either plan or add-ons. */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionRequest, UpdateSubscriptionResponse, UpdateSubscriptionError, CloudflareOpContext>;
//# sourceMappingURL=zones.d.ts.map