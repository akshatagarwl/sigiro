import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** A short description of the custom asset. */
    description: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
export declare const CreateAssetForAccountRequest: S.Schema<CreateAssetForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAssetResponse {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export declare const CreateAssetResponse: S.Schema<CreateAssetResponse>;
export interface CreateAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** A short description of the custom asset. */
    description: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
export declare const CreateAssetForZoneRequest: S.Schema<CreateAssetForZoneRequest>;
export interface DeleteAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export declare const DeleteAssetForAccountRequest: S.Schema<DeleteAssetForAccountRequest>;
export interface DeleteAssetForAccountResponse {
}
export declare const DeleteAssetForAccountResponse: S.Schema<DeleteAssetForAccountResponse>;
export interface DeleteAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export declare const DeleteAssetForZoneRequest: S.Schema<DeleteAssetForZoneRequest>;
export interface DeleteAssetForZoneResponse {
}
export declare const DeleteAssetForZoneResponse: S.Schema<DeleteAssetForZoneResponse>;
export interface GetAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export declare const GetAssetForAccountRequest: S.Schema<GetAssetForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAssetResponse {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export declare const GetAssetResponse: S.Schema<GetAssetResponse>;
export interface GetAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
}
export declare const GetAssetForZoneRequest: S.Schema<GetAssetForZoneRequest>;
export type GetRequestIdentifier = "1000_errors" | "500_errors" | "basic_challenge" | "country_challenge" | "ip_block" | "managed_challenge" | "ratelimit_block" | "under_attack" | "waf_block" | "waf_challenge";
export declare const GetRequestIdentifier: any;
export interface GetCustomPageForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Error Page Types */
    identifier: GetRequestIdentifier | (string & {});
}
export declare const GetCustomPageForAccountRequest: S.Schema<GetCustomPageForAccountRequest>;
export type GetResponseRequiredTokensList = Array<string>;
export declare const GetResponseRequiredTokensList: S.Schema<GetResponseRequiredTokensList>;
export type GetResponseState = "default" | "customized";
export declare const GetResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomPageResponse {
    id?: string | null;
    createdOn?: string | null;
    description?: string | null;
    modifiedOn?: string | null;
    previewTarget?: string | null;
    requiredTokens?: GetResponseRequiredTokensList | null;
    /** The custom page state. */
    state?: GetResponseState | null;
    /** The URL associated with the custom page. */
    url?: string | null;
}
export declare const GetCustomPageResponse: S.Schema<GetCustomPageResponse>;
export interface GetCustomPageForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Error Page Types */
    identifier: GetRequestIdentifier | (string & {});
}
export declare const GetCustomPageForZoneRequest: S.Schema<GetCustomPageForZoneRequest>;
export interface ListAssetsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    page?: number;
    perPage?: number;
}
export declare const ListAssetsForAccountRequest: S.Schema<ListAssetsForAccountRequest>;
export interface AssetsListResultItem {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export declare const AssetsListResultItem: S.Schema<AssetsListResultItem>;
export type AssetsListResultList = Array<AssetsListResultItem>;
export declare const AssetsListResultList: S.Schema<AssetsListResultList>;
export interface ListAssetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AssetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAssetsResponse: S.Schema<ListAssetsResponse>;
export interface ListAssetsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    page?: number;
    perPage?: number;
}
export declare const ListAssetsForZoneRequest: S.Schema<ListAssetsForZoneRequest>;
export interface ListCustomPagesForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export declare const ListCustomPagesForAccountRequest: S.Schema<ListCustomPagesForAccountRequest>;
export type ListResultItemRequiredTokensList = Array<string>;
export declare const ListResultItemRequiredTokensList: S.Schema<ListResultItemRequiredTokensList>;
export type ListResultItemState = "default" | "customized";
export declare const ListResultItemState: any;
export interface ListResultItem {
    id?: string | null;
    createdOn?: string | null;
    description?: string | null;
    modifiedOn?: string | null;
    previewTarget?: string | null;
    requiredTokens?: ListResultItemRequiredTokensList | null;
    /** The custom page state. */
    state?: ListResultItemState | null;
    /** The URL associated with the custom page. */
    url?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListCustomPagesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCustomPagesResponse: S.Schema<ListCustomPagesResponse>;
export interface ListCustomPagesForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export declare const ListCustomPagesForZoneRequest: S.Schema<ListCustomPagesForZoneRequest>;
export type UpdateRequestIdentifier = "1000_errors" | "500_errors" | "basic_challenge" | "country_challenge" | "ip_block" | "managed_challenge" | "ratelimit_block" | "under_attack" | "waf_block" | "waf_challenge";
export declare const UpdateRequestIdentifier: any;
export type UpdateRequestState = "default" | "customized";
export declare const UpdateRequestState: any;
export interface PutCustomPageForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Error Page Types */
    identifier: UpdateRequestIdentifier | (string & {});
    /** The custom page state. */
    state: UpdateRequestState | (string & {});
    /** The URL associated with the custom page. */
    url: string;
}
export declare const PutCustomPageForAccountRequest: S.Schema<PutCustomPageForAccountRequest>;
export type UpdateResponseRequiredTokensList = Array<string>;
export declare const UpdateResponseRequiredTokensList: S.Schema<UpdateResponseRequiredTokensList>;
export type UpdateResponseState = "default" | "customized";
export declare const UpdateResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCustomPageResponse {
    id?: string | null;
    createdOn?: string | null;
    description?: string | null;
    modifiedOn?: string | null;
    previewTarget?: string | null;
    requiredTokens?: UpdateResponseRequiredTokensList | null;
    /** The custom page state. */
    state?: UpdateResponseState | null;
    /** The URL associated with the custom page. */
    url?: string | null;
}
export declare const PutCustomPageResponse: S.Schema<PutCustomPageResponse>;
export interface PutCustomPageForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Error Page Types */
    identifier: UpdateRequestIdentifier | (string & {});
    /** The custom page state. */
    state: UpdateRequestState | (string & {});
    /** The URL associated with the custom page. */
    url: string;
}
export declare const PutCustomPageForZoneRequest: S.Schema<PutCustomPageForZoneRequest>;
export interface UpdateAssetForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
    /** A short description of the custom asset. */
    description: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
export declare const UpdateAssetForAccountRequest: S.Schema<UpdateAssetForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAssetResponse {
    /** A short description of the custom asset. */
    description?: string | null;
    lastUpdated?: string | null;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    name?: string | null;
    /** The size of the asset content in bytes. */
    sizeBytes?: number | null;
    /** The URL where the asset content is fetched from. */
    url?: string | null;
}
export declare const UpdateAssetResponse: S.Schema<UpdateAssetResponse>;
export interface UpdateAssetForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The unique name of the custom asset. Can only contain letters (A-Z, a-z), numbers (0-9), and underscores (_). */
    assetName: string;
    /** A short description of the custom asset. */
    description: string;
    /** The URL where the asset content is fetched from. */
    url: string;
}
export declare const UpdateAssetForZoneRequest: S.Schema<UpdateAssetForZoneRequest>;
export type CreateAssetForAccountError = CloudflareOpError;
/** Creates a new custom asset. */
export declare const createAssetForAccount: API.OperationMethod<CreateAssetForAccountRequest, CreateAssetResponse, CreateAssetForAccountError, CloudflareOpContext>;
export type CreateAssetForZoneError = CloudflareOpError;
/** Creates a new custom asset. */
export declare const createAssetForZone: API.OperationMethod<CreateAssetForZoneRequest, CreateAssetResponse, CreateAssetForZoneError, CloudflareOpContext>;
export type DeleteAssetForAccountError = CloudflareOpError;
/** Deletes an existing custom asset. */
export declare const deleteAssetForAccount: API.OperationMethod<DeleteAssetForAccountRequest, DeleteAssetForAccountResponse, DeleteAssetForAccountError, CloudflareOpContext>;
export type DeleteAssetForZoneError = CloudflareOpError;
/** Deletes an existing custom asset. */
export declare const deleteAssetForZone: API.OperationMethod<DeleteAssetForZoneRequest, DeleteAssetForZoneResponse, DeleteAssetForZoneError, CloudflareOpContext>;
export type GetAssetForAccountError = CloudflareOpError;
/** Fetches the details of a custom asset. */
export declare const getAssetForAccount: API.OperationMethod<GetAssetForAccountRequest, GetAssetResponse, GetAssetForAccountError, CloudflareOpContext>;
export type GetAssetForZoneError = CloudflareOpError;
/** Fetches the details of a custom asset. */
export declare const getAssetForZone: API.OperationMethod<GetAssetForZoneRequest, GetAssetResponse, GetAssetForZoneError, CloudflareOpContext>;
export type GetCustomPageForAccountError = CloudflareOpError;
/** Fetches the details of a custom page. */
export declare const getCustomPageForAccount: API.OperationMethod<GetCustomPageForAccountRequest, GetCustomPageResponse, GetCustomPageForAccountError, CloudflareOpContext>;
export type GetCustomPageForZoneError = CloudflareOpError;
/** Fetches the details of a custom page. */
export declare const getCustomPageForZone: API.OperationMethod<GetCustomPageForZoneRequest, GetCustomPageResponse, GetCustomPageForZoneError, CloudflareOpContext>;
export type ListAssetsForAccountError = CloudflareOpError;
/** Fetches all the custom assets. */
export declare const listAssetsForAccount: API.PaginatedOperationMethod<ListAssetsForAccountRequest, ListAssetsResponse, ListAssetsForAccountError, CloudflareOpContext, AssetsListResultItem>;
export type ListAssetsForZoneError = CloudflareOpError;
/** Fetches all the custom assets. */
export declare const listAssetsForZone: API.PaginatedOperationMethod<ListAssetsForZoneRequest, ListAssetsResponse, ListAssetsForZoneError, CloudflareOpContext, AssetsListResultItem>;
export type ListCustomPagesForAccountError = CloudflareOpError;
/** Fetches all the custom pages. */
export declare const listCustomPagesForAccount: API.PaginatedOperationMethod<ListCustomPagesForAccountRequest, ListCustomPagesResponse, ListCustomPagesForAccountError, CloudflareOpContext, ListResultItem>;
export type ListCustomPagesForZoneError = CloudflareOpError;
/** Fetches all the custom pages. */
export declare const listCustomPagesForZone: API.PaginatedOperationMethod<ListCustomPagesForZoneRequest, ListCustomPagesResponse, ListCustomPagesForZoneError, CloudflareOpContext, ListResultItem>;
export type PutCustomPageForAccountError = CloudflareOpError;
/** Updates the configuration of an existing custom page. */
export declare const putCustomPageForAccount: API.OperationMethod<PutCustomPageForAccountRequest, PutCustomPageResponse, PutCustomPageForAccountError, CloudflareOpContext>;
export type PutCustomPageForZoneError = CloudflareOpError;
/** Updates the configuration of an existing custom page. */
export declare const putCustomPageForZone: API.OperationMethod<PutCustomPageForZoneRequest, PutCustomPageResponse, PutCustomPageForZoneError, CloudflareOpContext>;
export type UpdateAssetForAccountError = CloudflareOpError;
/** Updates the configuration of an existing custom asset. */
export declare const updateAssetForAccount: API.OperationMethod<UpdateAssetForAccountRequest, UpdateAssetResponse, UpdateAssetForAccountError, CloudflareOpContext>;
export type UpdateAssetForZoneError = CloudflareOpError;
/** Updates the configuration of an existing custom asset. */
export declare const updateAssetForZone: API.OperationMethod<UpdateAssetForZoneRequest, UpdateAssetResponse, UpdateAssetForZoneError, CloudflareOpContext>;
//# sourceMappingURL=custom_pages.d.ts.map