import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiGatewaySpendingLimitDeprecated_base: S.Class<AiGatewaySpendingLimitDeprecated, S.TaggedStruct<"AiGatewaySpendingLimitDeprecated", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AiGatewaySpendingLimitDeprecated extends /*@__PURE__*/ AiGatewaySpendingLimitDeprecated_base {
}
declare const DatasetNameAlreadyExists_base: S.Class<DatasetNameAlreadyExists, S.TaggedStruct<"DatasetNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DatasetNameAlreadyExists extends /*@__PURE__*/ DatasetNameAlreadyExists_base {
}
declare const DatasetNotFound_base: S.Class<DatasetNotFound, S.TaggedStruct<"DatasetNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DatasetNotFound extends /*@__PURE__*/ DatasetNotFound_base {
}
declare const EvaluationNameAlreadyExists_base: S.Class<EvaluationNameAlreadyExists, S.TaggedStruct<"EvaluationNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EvaluationNameAlreadyExists extends /*@__PURE__*/ EvaluationNameAlreadyExists_base {
}
declare const EvaluationNotFound_base: S.Class<EvaluationNotFound, S.TaggedStruct<"EvaluationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EvaluationNotFound extends /*@__PURE__*/ EvaluationNotFound_base {
}
declare const GatewayAlreadyExists_base: S.Class<GatewayAlreadyExists, S.TaggedStruct<"GatewayAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class GatewayAlreadyExists extends /*@__PURE__*/ GatewayAlreadyExists_base {
}
declare const GatewayNotFound_base: S.Class<GatewayNotFound, S.TaggedStruct<"GatewayNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class GatewayNotFound extends /*@__PURE__*/ GatewayNotFound_base {
}
declare const NoManualTopup_base: S.Class<NoManualTopup, S.TaggedStruct<"NoManualTopup", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoManualTopup extends /*@__PURE__*/ NoManualTopup_base {
}
declare const ProviderConfigAlreadyExists_base: S.Class<ProviderConfigAlreadyExists, S.TaggedStruct<"ProviderConfigAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ProviderConfigAlreadyExists extends /*@__PURE__*/ ProviderConfigAlreadyExists_base {
}
declare const ProviderConfigNotFound_base: S.Class<ProviderConfigNotFound, S.TaggedStruct<"ProviderConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ProviderConfigNotFound extends /*@__PURE__*/ ProviderConfigNotFound_base {
}
declare const ProviderConfigSecretNotFound_base: S.Class<ProviderConfigSecretNotFound, S.TaggedStruct<"ProviderConfigSecretNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ProviderConfigSecretNotFound extends /*@__PURE__*/ ProviderConfigSecretNotFound_base {
}
declare const RouteAlreadyExists_base: S.Class<RouteAlreadyExists, S.TaggedStruct<"RouteAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RouteAlreadyExists extends /*@__PURE__*/ RouteAlreadyExists_base {
}
declare const RouteNotFound_base: S.Class<RouteNotFound, S.TaggedStruct<"RouteNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RouteNotFound extends /*@__PURE__*/ RouteNotFound_base {
}
export type CreateRequestLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const CreateRequestLogManagementStrategy: any;
export type CreateRequestRateLimitingTechnique = "fixed" | "sliding";
export declare const CreateRequestRateLimitingTechnique: any;
export type CreateRequestRetryBackoff = "constant" | "linear" | "exponential";
export declare const CreateRequestRetryBackoff: any;
export type CreateRequestWorkersAiBillingMode = "postpaid";
export declare const CreateRequestWorkersAiBillingMode: any;
export interface CreateAiGatewayRequest {
    accountId: string;
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number | null;
    collectLogs: boolean;
    rateLimitingInterval: number | null;
    rateLimitingLimit: number | null;
    authentication?: boolean;
    logManagement?: number;
    logManagementStrategy?: CreateRequestLogManagementStrategy | (string & {});
    logpush?: boolean;
    logpushPublicKey?: string;
    rateLimitingTechnique?: CreateRequestRateLimitingTechnique | (string & {});
    /** Backoff strategy for retry delays */
    retryBackoff?: CreateRequestRetryBackoff | (string & {});
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: CreateRequestWorkersAiBillingMode | (string & {});
    zdr?: boolean;
}
export declare const CreateAiGatewayRequest: S.Schema<CreateAiGatewayRequest>;
export type CreateResponseDlpCase0Action = "BLOCK" | "FLAG";
export declare const CreateResponseDlpCase0Action: any;
export type CreateResponseDlpCase0ProfilesList = Array<string>;
export declare const CreateResponseDlpCase0ProfilesList: S.Schema<CreateResponseDlpCase0ProfilesList>;
export interface CreateResponseDlpCase0 {
    action: CreateResponseDlpCase0Action;
    enabled: boolean;
    profiles: CreateResponseDlpCase0ProfilesList;
}
export declare const CreateResponseDlpCase0: S.Schema<CreateResponseDlpCase0>;
export type CreateResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export declare const CreateResponseDlpCase1PoliciesItemAction: any;
export type CreateResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export declare const CreateResponseDlpCase1PoliciesItemCheckItem: any;
export type CreateResponseDlpCase1PoliciesItemCheckList = Array<CreateResponseDlpCase1PoliciesItemCheckItem>;
export declare const CreateResponseDlpCase1PoliciesItemCheckList: S.Schema<CreateResponseDlpCase1PoliciesItemCheckList>;
export type CreateResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export declare const CreateResponseDlpCase1PoliciesItemProfilesList: S.Schema<CreateResponseDlpCase1PoliciesItemProfilesList>;
export interface CreateResponseDlpCase1PoliciesItem {
    id: string;
    action: CreateResponseDlpCase1PoliciesItemAction;
    check: CreateResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: CreateResponseDlpCase1PoliciesItemProfilesList;
}
export declare const CreateResponseDlpCase1PoliciesItem: S.Schema<CreateResponseDlpCase1PoliciesItem>;
export type CreateResponseDlpCase1PoliciesList = Array<CreateResponseDlpCase1PoliciesItem>;
export declare const CreateResponseDlpCase1PoliciesList: S.Schema<CreateResponseDlpCase1PoliciesList>;
export interface CreateResponseDlpCase1 {
    enabled: boolean;
    policies: CreateResponseDlpCase1PoliciesList;
}
export declare const CreateResponseDlpCase1: S.Schema<CreateResponseDlpCase1>;
export type CreateResponseDlp = CreateResponseDlpCase0 | CreateResponseDlpCase1;
export declare const CreateResponseDlp: any;
export type CreateResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptP1: any;
export type CreateResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS1: any;
export type CreateResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS10: any;
export type CreateResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS11: any;
export type CreateResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS12: any;
export type CreateResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS13: any;
export type CreateResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS2: any;
export type CreateResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS3: any;
export type CreateResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS4: any;
export type CreateResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS5: any;
export type CreateResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS6: any;
export type CreateResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS7: any;
export type CreateResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS8: any;
export type CreateResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsPromptS9: any;
export interface CreateResponseGuardrailsPrompt {
    p1?: CreateResponseGuardrailsPromptP1 | null;
    s1?: CreateResponseGuardrailsPromptS1 | null;
    s10?: CreateResponseGuardrailsPromptS10 | null;
    s11?: CreateResponseGuardrailsPromptS11 | null;
    s12?: CreateResponseGuardrailsPromptS12 | null;
    s13?: CreateResponseGuardrailsPromptS13 | null;
    s2?: CreateResponseGuardrailsPromptS2 | null;
    s3?: CreateResponseGuardrailsPromptS3 | null;
    s4?: CreateResponseGuardrailsPromptS4 | null;
    s5?: CreateResponseGuardrailsPromptS5 | null;
    s6?: CreateResponseGuardrailsPromptS6 | null;
    s7?: CreateResponseGuardrailsPromptS7 | null;
    s8?: CreateResponseGuardrailsPromptS8 | null;
    s9?: CreateResponseGuardrailsPromptS9 | null;
}
export declare const CreateResponseGuardrailsPrompt: S.Schema<CreateResponseGuardrailsPrompt>;
export type CreateResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseP1: any;
export type CreateResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS1: any;
export type CreateResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS10: any;
export type CreateResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS11: any;
export type CreateResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS12: any;
export type CreateResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS13: any;
export type CreateResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS2: any;
export type CreateResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS3: any;
export type CreateResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS4: any;
export type CreateResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS5: any;
export type CreateResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS6: any;
export type CreateResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS7: any;
export type CreateResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS8: any;
export type CreateResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export declare const CreateResponseGuardrailsResponseS9: any;
export interface CreateResponseGuardrailsResponse {
    p1?: CreateResponseGuardrailsResponseP1 | null;
    s1?: CreateResponseGuardrailsResponseS1 | null;
    s10?: CreateResponseGuardrailsResponseS10 | null;
    s11?: CreateResponseGuardrailsResponseS11 | null;
    s12?: CreateResponseGuardrailsResponseS12 | null;
    s13?: CreateResponseGuardrailsResponseS13 | null;
    s2?: CreateResponseGuardrailsResponseS2 | null;
    s3?: CreateResponseGuardrailsResponseS3 | null;
    s4?: CreateResponseGuardrailsResponseS4 | null;
    s5?: CreateResponseGuardrailsResponseS5 | null;
    s6?: CreateResponseGuardrailsResponseS6 | null;
    s7?: CreateResponseGuardrailsResponseS7 | null;
    s8?: CreateResponseGuardrailsResponseS8 | null;
    s9?: CreateResponseGuardrailsResponseS9 | null;
}
export declare const CreateResponseGuardrailsResponse: S.Schema<CreateResponseGuardrailsResponse>;
export interface CreateResponseGuardrails {
    prompt: CreateResponseGuardrailsPrompt;
    response: CreateResponseGuardrailsResponse;
}
export declare const CreateResponseGuardrails: S.Schema<CreateResponseGuardrails>;
export type CreateResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const CreateResponseLogManagementStrategy: any;
export type CreateResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateResponseOtelItemHeadersMap: S.Schema<CreateResponseOtelItemHeadersMap>;
export type CreateResponseOtelItemContentType = "json" | "protobuf";
export declare const CreateResponseOtelItemContentType: any;
export interface CreateResponseOtelItem {
    headers: CreateResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null;
    contentType?: CreateResponseOtelItemContentType | null;
}
export declare const CreateResponseOtelItem: S.Schema<CreateResponseOtelItem>;
export type CreateResponseOtelList = Array<CreateResponseOtelItem>;
export declare const CreateResponseOtelList: S.Schema<CreateResponseOtelList>;
export type CreateResponseRateLimitingTechnique = "fixed" | "sliding";
export declare const CreateResponseRateLimitingTechnique: any;
export type CreateResponseRetryBackoff = "constant" | "linear" | "exponential";
export declare const CreateResponseRetryBackoff: any;
export type CreateResponseSpendLimitsRulesItemLimitType = "cost";
export declare const CreateResponseSpendLimitsRulesItemLimitType: any;
export type UntypedMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const UntypedMetadataMap: S.Schema<UntypedMetadataMap>;
export type CreateResponseSpendLimitsRulesItemModelMode = "filter";
export declare const CreateResponseSpendLimitsRulesItemModelMode: any;
export type CreateResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export declare const CreateResponseSpendLimitsRulesItemModelValuesList: S.Schema<CreateResponseSpendLimitsRulesItemModelValuesList>;
export interface CreateResponseSpendLimitsRulesItemModel {
    mode: CreateResponseSpendLimitsRulesItemModelMode;
    values: CreateResponseSpendLimitsRulesItemModelValuesList;
}
export declare const CreateResponseSpendLimitsRulesItemModel: S.Schema<CreateResponseSpendLimitsRulesItemModel>;
export type CreateResponseSpendLimitsRulesItemProviderMode = "filter";
export declare const CreateResponseSpendLimitsRulesItemProviderMode: any;
export type CreateResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export declare const CreateResponseSpendLimitsRulesItemProviderValuesList: S.Schema<CreateResponseSpendLimitsRulesItemProviderValuesList>;
export interface CreateResponseSpendLimitsRulesItemProvider {
    mode: CreateResponseSpendLimitsRulesItemProviderMode;
    values: CreateResponseSpendLimitsRulesItemProviderValuesList;
}
export declare const CreateResponseSpendLimitsRulesItemProvider: S.Schema<CreateResponseSpendLimitsRulesItemProvider>;
export type CreateResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export declare const CreateResponseSpendLimitsRulesItemTechnique: any;
export interface CreateResponseSpendLimitsRulesItem {
    limit: number;
    limitType: CreateResponseSpendLimitsRulesItemLimitType;
    window: number;
    id?: string | null;
    enabled?: boolean | null;
    metadata?: UntypedMetadataMap | null;
    model?: CreateResponseSpendLimitsRulesItemModel | null;
    provider?: CreateResponseSpendLimitsRulesItemProvider | null;
    technique?: CreateResponseSpendLimitsRulesItemTechnique | null;
}
export declare const CreateResponseSpendLimitsRulesItem: S.Schema<CreateResponseSpendLimitsRulesItem>;
export type CreateResponseSpendLimitsRulesList = Array<CreateResponseSpendLimitsRulesItem>;
export declare const CreateResponseSpendLimitsRulesList: S.Schema<CreateResponseSpendLimitsRulesList>;
export interface CreateResponseSpendLimits {
    enabled?: boolean | null;
    rules?: CreateResponseSpendLimitsRulesList | null;
}
export declare const CreateResponseSpendLimits: S.Schema<CreateResponseSpendLimits>;
export interface CreateResponseStripeUsageEventsItem {
    payload: string;
}
export declare const CreateResponseStripeUsageEventsItem: S.Schema<CreateResponseStripeUsageEventsItem>;
export type CreateResponseStripeUsageEventsList = Array<CreateResponseStripeUsageEventsItem>;
export declare const CreateResponseStripeUsageEventsList: S.Schema<CreateResponseStripeUsageEventsList>;
export interface CreateResponseStripe {
    authorization: string;
    usageEvents: CreateResponseStripeUsageEventsList;
}
export declare const CreateResponseStripe: S.Schema<CreateResponseStripe>;
export type CreateResponseWorkersAiBillingMode = "postpaid";
export declare const CreateResponseWorkersAiBillingMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAiGatewayResponse {
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    authentication?: boolean | null;
    dlp?: CreateResponseDlp | null;
    guardrails?: CreateResponseGuardrails | null;
    isDefault?: boolean | null;
    logManagement?: number | null;
    logManagementStrategy?: CreateResponseLogManagementStrategy | null;
    logpush?: boolean | null;
    logpushPublicKey?: string | null;
    otel?: CreateResponseOtelList | null;
    rateLimitingTechnique?: CreateResponseRateLimitingTechnique | null;
    /** Backoff strategy for retry delays */
    retryBackoff?: CreateResponseRetryBackoff | null;
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number | null;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null;
    spendLimits?: CreateResponseSpendLimits | null;
    storeId?: string | null;
    stripe?: CreateResponseStripe | null;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: CreateResponseWorkersAiBillingMode | null;
    zdr?: boolean | null;
}
export declare const CreateAiGatewayResponse: S.Schema<CreateAiGatewayResponse>;
export type BillingSpendingLimitCreateRequestDuration = "daily" | "weekly" | "monthly";
export declare const BillingSpendingLimitCreateRequestDuration: any;
export type BillingSpendingLimitCreateRequestStrategy = "fixed" | "sliding";
export declare const BillingSpendingLimitCreateRequestStrategy: any;
export interface CreateBillingSpendingLimitRequest {
    accountId: string;
    /** Spending limit amount in cents (min 100). */
    amount: number;
    /** Spending limit duration. */
    duration: BillingSpendingLimitCreateRequestDuration | (string & {});
    /** Spending limit strategy. */
    strategy: BillingSpendingLimitCreateRequestStrategy | (string & {});
}
export declare const CreateBillingSpendingLimitRequest: S.Schema<CreateBillingSpendingLimitRequest>;
export type CreateBillingSpendingLimitResponse = unknown;
export declare const CreateBillingSpendingLimitResponse: S.Schema<CreateBillingSpendingLimitResponse>;
export interface CreateBillingTopupRequest {
    accountId: string;
    /** Top-up amount in cents (min 1000). */
    amount: number;
}
export declare const CreateBillingTopupRequest: S.Schema<CreateBillingTopupRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBillingTopupResponse {
    /** Stripe PaymentIntent client secret. */
    clientSecret: string;
    /** Whether the user was already onboarded. */
    onboarding: boolean;
    /** Stripe invoice ID. */
    paymentIntentId: string;
    /** Card brand (visa, mastercard, etc.). */
    brand?: string | null;
    /** Last 4 digits of card. */
    last4?: string | null;
}
export declare const CreateBillingTopupResponse: S.Schema<CreateBillingTopupResponse>;
export interface CreateBillingTopupConfigRequest {
    accountId: string;
    /** Auto top-up amount in cents (min 1000). */
    amount: number;
    /** Balance threshold in cents that triggers auto top-up (min 500). */
    threshold: number;
}
export declare const CreateBillingTopupConfigRequest: S.Schema<CreateBillingTopupConfigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBillingTopupConfigResponse {
    amount: number;
    threshold: number;
}
export declare const CreateBillingTopupConfigResponse: S.Schema<CreateBillingTopupConfigResponse>;
export interface CreateCustomProviderRequest {
    accountId: string;
    baseUrl: string;
    name: string;
    slug: string;
    beta?: boolean;
    curlExample?: string;
    description?: string;
    enable?: boolean;
    headers?: string;
    jsExample?: string;
    link?: string;
    position?: number;
}
export declare const CreateCustomProviderRequest: S.Schema<CreateCustomProviderRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomProviderResponse {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null;
    curlExample?: string | null;
    description?: string | null;
    enable?: boolean | null;
    headers?: string | null;
    jsExample?: string | null;
    link?: string | null;
    logo?: string | null;
    position?: number | null;
}
export declare const CreateCustomProviderResponse: S.Schema<CreateCustomProviderResponse>;
export type DatasetsCreateRequestFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsCreateRequestFiltersItemKey: any;
export type DatasetsCreateRequestFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsCreateRequestFiltersItemOperator: any;
export type DatasetsCreateRequestFiltersItemValueItem = string | number | boolean;
export declare const DatasetsCreateRequestFiltersItemValueItem: any;
export type DatasetsCreateRequestFiltersItemValueList = Array<DatasetsCreateRequestFiltersItemValueItem>;
export declare const DatasetsCreateRequestFiltersItemValueList: S.Schema<DatasetsCreateRequestFiltersItemValueList>;
export interface DatasetsCreateRequestFiltersItem {
    key: DatasetsCreateRequestFiltersItemKey | (string & {});
    operator: DatasetsCreateRequestFiltersItemOperator | (string & {});
    value: DatasetsCreateRequestFiltersItemValueList;
}
export declare const DatasetsCreateRequestFiltersItem: S.Schema<DatasetsCreateRequestFiltersItem>;
export type DatasetsCreateRequestFiltersList = Array<DatasetsCreateRequestFiltersItem>;
export declare const DatasetsCreateRequestFiltersList: S.Schema<DatasetsCreateRequestFiltersList>;
export interface CreateDatasetRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    enable: boolean;
    filters: DatasetsCreateRequestFiltersList;
    name: string;
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export type DatasetsCreateResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsCreateResponseFiltersItemKey: any;
export type DatasetsCreateResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsCreateResponseFiltersItemOperator: any;
export type DatasetsCreateResponseFiltersItemValueItem = string | number | boolean;
export declare const DatasetsCreateResponseFiltersItemValueItem: any;
export type DatasetsCreateResponseFiltersItemValueList = Array<DatasetsCreateResponseFiltersItemValueItem>;
export declare const DatasetsCreateResponseFiltersItemValueList: S.Schema<DatasetsCreateResponseFiltersItemValueList>;
export interface DatasetsCreateResponseFiltersItem {
    key: DatasetsCreateResponseFiltersItemKey;
    operator: DatasetsCreateResponseFiltersItemOperator;
    value: DatasetsCreateResponseFiltersItemValueList;
}
export declare const DatasetsCreateResponseFiltersItem: S.Schema<DatasetsCreateResponseFiltersItem>;
export type DatasetsCreateResponseFiltersList = Array<DatasetsCreateResponseFiltersItem>;
export declare const DatasetsCreateResponseFiltersList: S.Schema<DatasetsCreateResponseFiltersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsCreateResponseFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export interface CreateDeploymentDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    versionId: string;
}
export declare const CreateDeploymentDynamicRoutingRequest: S.Schema<CreateDeploymentDynamicRoutingRequest>;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext {
    elementId: string;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs {
    next: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase0Type = "start";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase0Type: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase0Type;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase0: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs {
    false: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
    true: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties {
    conditions?: unknown | null;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase1Type = "conditional";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase1Type: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase1Type;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase1: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase2OutputsMap: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase2OutputsMap>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase2Type = "percentage";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase2Type: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase2Type;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase2: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase2>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs {
    fallback: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
    success: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateDeploymentResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Properties>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3Type = "rate";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3Type: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase3Properties;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase3Type;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase3: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties {
    model: string;
    provider: string;
    retries: number;
    timeout: number;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4Type = "model";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase4Type: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase4Type;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase4: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase5OutputsMap: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase5OutputsMap>;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase5Type = "end";
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase5Type: any;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase5Type;
}
export declare const DynamicRoutingCreateDeploymentResponseElementsItemCase5: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase5>;
export type DynamicRoutingCreateDeploymentResponseElementsItem = DynamicRoutingCreateDeploymentResponseElementsItemCase0 | DynamicRoutingCreateDeploymentResponseElementsItemCase1 | DynamicRoutingCreateDeploymentResponseElementsItemCase2 | DynamicRoutingCreateDeploymentResponseElementsItemCase3 | DynamicRoutingCreateDeploymentResponseElementsItemCase4 | DynamicRoutingCreateDeploymentResponseElementsItemCase5;
export declare const DynamicRoutingCreateDeploymentResponseElementsItem: any;
export type DynamicRoutingCreateDeploymentResponseElementsList = Array<DynamicRoutingCreateDeploymentResponseElementsItem>;
export declare const DynamicRoutingCreateDeploymentResponseElementsList: S.Schema<DynamicRoutingCreateDeploymentResponseElementsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDeploymentDynamicRoutingResponse {
    id: string;
    createdAt: string;
    elements: DynamicRoutingCreateDeploymentResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const CreateDeploymentDynamicRoutingResponse: S.Schema<CreateDeploymentDynamicRoutingResponse>;
export type DynamicRoutingCreateRequestElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingCreateRequestElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingCreateRequestElementsItemCase0Type = "start";
export declare const DynamicRoutingCreateRequestElementsItemCase0Type: any;
export interface DynamicRoutingCreateRequestElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateRequestElementsItemCase0Type;
}
export declare const DynamicRoutingCreateRequestElementsItemCase0: S.Schema<DynamicRoutingCreateRequestElementsItemCase0>;
export type DynamicRoutingCreateRequestElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingCreateRequestElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingCreateRequestElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingCreateRequestElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingCreateRequestElementsItemCase1Type = "conditional";
export declare const DynamicRoutingCreateRequestElementsItemCase1Type: any;
export interface DynamicRoutingCreateRequestElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateRequestElementsItemCase1Type;
}
export declare const DynamicRoutingCreateRequestElementsItemCase1: S.Schema<DynamicRoutingCreateRequestElementsItemCase1>;
export type DynamicRoutingCreateRequestElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateRequestElementsItemCase2OutputsMap: S.Schema<DynamicRoutingCreateRequestElementsItemCase2OutputsMap>;
export type DynamicRoutingCreateRequestElementsItemCase2Type = "percentage";
export declare const DynamicRoutingCreateRequestElementsItemCase2Type: any;
export interface DynamicRoutingCreateRequestElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateRequestElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateRequestElementsItemCase2Type;
}
export declare const DynamicRoutingCreateRequestElementsItemCase2: S.Schema<DynamicRoutingCreateRequestElementsItemCase2>;
export type DynamicRoutingCreateRequestElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateRequestElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateRequestElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingCreateRequestElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingCreateRequestElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateRequestElementsItemCase3PropertiesLimitType | (string & {});
    window: number;
}
export declare const DynamicRoutingCreateRequestElementsItemCase3Properties: S.Schema<DynamicRoutingCreateRequestElementsItemCase3Properties>;
export type DynamicRoutingCreateRequestElementsItemCase3Type = "rate";
export declare const DynamicRoutingCreateRequestElementsItemCase3Type: any;
export interface DynamicRoutingCreateRequestElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateRequestElementsItemCase3Properties;
    type: DynamicRoutingCreateRequestElementsItemCase3Type;
}
export declare const DynamicRoutingCreateRequestElementsItemCase3: S.Schema<DynamicRoutingCreateRequestElementsItemCase3>;
export type DynamicRoutingCreateRequestElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateRequestElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateRequestElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateRequestElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateRequestElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingCreateRequestElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingCreateRequestElementsItemCase4Type = "model";
export declare const DynamicRoutingCreateRequestElementsItemCase4Type: any;
export interface DynamicRoutingCreateRequestElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateRequestElementsItemCase4Type;
}
export declare const DynamicRoutingCreateRequestElementsItemCase4: S.Schema<DynamicRoutingCreateRequestElementsItemCase4>;
export type DynamicRoutingCreateRequestElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateRequestElementsItemCase5OutputsMap: S.Schema<DynamicRoutingCreateRequestElementsItemCase5OutputsMap>;
export type DynamicRoutingCreateRequestElementsItemCase5Type = "end";
export declare const DynamicRoutingCreateRequestElementsItemCase5Type: any;
export interface DynamicRoutingCreateRequestElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateRequestElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateRequestElementsItemCase5Type;
}
export declare const DynamicRoutingCreateRequestElementsItemCase5: S.Schema<DynamicRoutingCreateRequestElementsItemCase5>;
export type DynamicRoutingCreateRequestElementsItem = DynamicRoutingCreateRequestElementsItemCase0 | DynamicRoutingCreateRequestElementsItemCase1 | DynamicRoutingCreateRequestElementsItemCase2 | DynamicRoutingCreateRequestElementsItemCase3 | DynamicRoutingCreateRequestElementsItemCase4 | DynamicRoutingCreateRequestElementsItemCase5;
export declare const DynamicRoutingCreateRequestElementsItem: any;
export type DynamicRoutingCreateRequestElementsList = Array<DynamicRoutingCreateRequestElementsItem>;
export declare const DynamicRoutingCreateRequestElementsList: S.Schema<DynamicRoutingCreateRequestElementsList>;
export interface CreateDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    elements: DynamicRoutingCreateRequestElementsList;
    name: string;
}
export declare const CreateDynamicRoutingRequest: S.Schema<CreateDynamicRoutingRequest>;
export interface DynamicRoutingCreateResponseDeployment {
    createdAt: string;
    deploymentId: string;
    versionId: string;
}
export declare const DynamicRoutingCreateResponseDeployment: S.Schema<DynamicRoutingCreateResponseDeployment>;
export type DynamicRoutingCreateResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingCreateResponseElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingCreateResponseElementsItemCase0Type = "start";
export declare const DynamicRoutingCreateResponseElementsItemCase0Type: any;
export interface DynamicRoutingCreateResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateResponseElementsItemCase0Type;
}
export declare const DynamicRoutingCreateResponseElementsItemCase0: S.Schema<DynamicRoutingCreateResponseElementsItemCase0>;
export type DynamicRoutingCreateResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingCreateResponseElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingCreateResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingCreateResponseElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingCreateResponseElementsItemCase1Type = "conditional";
export declare const DynamicRoutingCreateResponseElementsItemCase1Type: any;
export interface DynamicRoutingCreateResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateResponseElementsItemCase1Type;
}
export declare const DynamicRoutingCreateResponseElementsItemCase1: S.Schema<DynamicRoutingCreateResponseElementsItemCase1>;
export type DynamicRoutingCreateResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateResponseElementsItemCase2OutputsMap: S.Schema<DynamicRoutingCreateResponseElementsItemCase2OutputsMap>;
export type DynamicRoutingCreateResponseElementsItemCase2Type = "percentage";
export declare const DynamicRoutingCreateResponseElementsItemCase2Type: any;
export interface DynamicRoutingCreateResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateResponseElementsItemCase2Type;
}
export declare const DynamicRoutingCreateResponseElementsItemCase2: S.Schema<DynamicRoutingCreateResponseElementsItemCase2>;
export type DynamicRoutingCreateResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateResponseElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingCreateResponseElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingCreateResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingCreateResponseElementsItemCase3Properties: S.Schema<DynamicRoutingCreateResponseElementsItemCase3Properties>;
export type DynamicRoutingCreateResponseElementsItemCase3Type = "rate";
export declare const DynamicRoutingCreateResponseElementsItemCase3Type: any;
export interface DynamicRoutingCreateResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateResponseElementsItemCase3Properties;
    type: DynamicRoutingCreateResponseElementsItemCase3Type;
}
export declare const DynamicRoutingCreateResponseElementsItemCase3: S.Schema<DynamicRoutingCreateResponseElementsItemCase3>;
export type DynamicRoutingCreateResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateResponseElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateResponseElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingCreateResponseElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingCreateResponseElementsItemCase4Type = "model";
export declare const DynamicRoutingCreateResponseElementsItemCase4Type: any;
export interface DynamicRoutingCreateResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateResponseElementsItemCase4Type;
}
export declare const DynamicRoutingCreateResponseElementsItemCase4: S.Schema<DynamicRoutingCreateResponseElementsItemCase4>;
export type DynamicRoutingCreateResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateResponseElementsItemCase5OutputsMap: S.Schema<DynamicRoutingCreateResponseElementsItemCase5OutputsMap>;
export type DynamicRoutingCreateResponseElementsItemCase5Type = "end";
export declare const DynamicRoutingCreateResponseElementsItemCase5Type: any;
export interface DynamicRoutingCreateResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateResponseElementsItemCase5Type;
}
export declare const DynamicRoutingCreateResponseElementsItemCase5: S.Schema<DynamicRoutingCreateResponseElementsItemCase5>;
export type DynamicRoutingCreateResponseElementsItem = DynamicRoutingCreateResponseElementsItemCase0 | DynamicRoutingCreateResponseElementsItemCase1 | DynamicRoutingCreateResponseElementsItemCase2 | DynamicRoutingCreateResponseElementsItemCase3 | DynamicRoutingCreateResponseElementsItemCase4 | DynamicRoutingCreateResponseElementsItemCase5;
export declare const DynamicRoutingCreateResponseElementsItem: any;
export type DynamicRoutingCreateResponseElementsList = Array<DynamicRoutingCreateResponseElementsItem>;
export declare const DynamicRoutingCreateResponseElementsList: S.Schema<DynamicRoutingCreateResponseElementsList>;
export type DynamicRoutingCreateResponseVersionActive = "true" | "false";
export declare const DynamicRoutingCreateResponseVersionActive: any;
export interface DynamicRoutingCreateResponseVersion {
    active: DynamicRoutingCreateResponseVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null;
}
export declare const DynamicRoutingCreateResponseVersion: S.Schema<DynamicRoutingCreateResponseVersion>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDynamicRoutingResponse {
    id: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingCreateResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingCreateResponseVersion;
}
export declare const CreateDynamicRoutingResponse: S.Schema<CreateDynamicRoutingResponse>;
export type EvaluationsCreateRequestDatasetIdsList = Array<string>;
export declare const EvaluationsCreateRequestDatasetIdsList: S.Schema<EvaluationsCreateRequestDatasetIdsList>;
export type EvaluationsCreateRequestEvaluationTypeIdsList = Array<string>;
export declare const EvaluationsCreateRequestEvaluationTypeIdsList: S.Schema<EvaluationsCreateRequestEvaluationTypeIdsList>;
export interface CreateEvaluationRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    datasetIds: EvaluationsCreateRequestDatasetIdsList;
    evaluationTypeIds: EvaluationsCreateRequestEvaluationTypeIdsList;
    name: string;
}
export declare const CreateEvaluationRequest: S.Schema<CreateEvaluationRequest>;
export type EvaluationsCreateResponseDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const EvaluationsCreateResponseDatasetsItemFiltersItemKey: any;
export type EvaluationsCreateResponseDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const EvaluationsCreateResponseDatasetsItemFiltersItemOperator: any;
export type EvaluationsCreateResponseDatasetsItemFiltersItemValueItem = string | number | boolean;
export declare const EvaluationsCreateResponseDatasetsItemFiltersItemValueItem: any;
export type EvaluationsCreateResponseDatasetsItemFiltersItemValueList = Array<EvaluationsCreateResponseDatasetsItemFiltersItemValueItem>;
export declare const EvaluationsCreateResponseDatasetsItemFiltersItemValueList: S.Schema<EvaluationsCreateResponseDatasetsItemFiltersItemValueList>;
export interface EvaluationsCreateResponseDatasetsItemFiltersItem {
    key: EvaluationsCreateResponseDatasetsItemFiltersItemKey;
    operator: EvaluationsCreateResponseDatasetsItemFiltersItemOperator;
    value: EvaluationsCreateResponseDatasetsItemFiltersItemValueList;
}
export declare const EvaluationsCreateResponseDatasetsItemFiltersItem: S.Schema<EvaluationsCreateResponseDatasetsItemFiltersItem>;
export type EvaluationsCreateResponseDatasetsItemFiltersList = Array<EvaluationsCreateResponseDatasetsItemFiltersItem>;
export declare const EvaluationsCreateResponseDatasetsItemFiltersList: S.Schema<EvaluationsCreateResponseDatasetsItemFiltersList>;
export interface EvaluationsCreateResponseDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsCreateResponseDatasetsItemFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const EvaluationsCreateResponseDatasetsItem: S.Schema<EvaluationsCreateResponseDatasetsItem>;
export type EvaluationsCreateResponseDatasetsList = Array<EvaluationsCreateResponseDatasetsItem>;
export declare const EvaluationsCreateResponseDatasetsList: S.Schema<EvaluationsCreateResponseDatasetsList>;
export interface EvaluationsCreateResponseResultsItem {
    id: string;
    createdAt: string;
    evaluationId: string;
    evaluationTypeId: string;
    modifiedAt: string;
    result: string;
    status: number;
    statusDescription: string;
    totalLogs: number;
}
export declare const EvaluationsCreateResponseResultsItem: S.Schema<EvaluationsCreateResponseResultsItem>;
export type EvaluationsCreateResponseResultsList = Array<EvaluationsCreateResponseResultsItem>;
export declare const EvaluationsCreateResponseResultsList: S.Schema<EvaluationsCreateResponseResultsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEvaluationResponse {
    id: string;
    createdAt: string;
    datasets: EvaluationsCreateResponseDatasetsList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsCreateResponseResultsList;
    totalLogs: number;
}
export declare const CreateEvaluationResponse: S.Schema<CreateEvaluationResponse>;
export interface CreateProviderConfigRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    alias: string;
    defaultConfig: boolean;
    providerSlug: string;
    rateLimit?: number;
    rateLimitPeriod?: number;
    secret?: string;
    secretId?: string;
}
export declare const CreateProviderConfigRequest: S.Schema<CreateProviderConfigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProviderConfigResponse {
    id: string;
    alias: string;
    defaultConfig: boolean;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    providerSlug: string;
    secretId: string;
    secretPreview: string;
    rateLimit?: number | null;
    rateLimitPeriod?: number | null;
}
export declare const CreateProviderConfigResponse: S.Schema<CreateProviderConfigResponse>;
export type DynamicRoutingCreateVersionRequestElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingCreateVersionRequestElementsItemCase0Type = "start";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase0Type: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateVersionRequestElementsItemCase0Type;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase0: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase0>;
export type DynamicRoutingCreateVersionRequestElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export interface DynamicRoutingCreateVersionRequestElementsItemCase1Properties {
    conditions?: unknown;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase1Properties: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase1Properties>;
export type DynamicRoutingCreateVersionRequestElementsItemCase1Type = "conditional";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase1Type: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateVersionRequestElementsItemCase1Properties;
    type: DynamicRoutingCreateVersionRequestElementsItemCase1Type;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase1: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase1>;
export type DynamicRoutingCreateVersionRequestElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateVersionRequestElementsItemCase2OutputsMap: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase2OutputsMap>;
export type DynamicRoutingCreateVersionRequestElementsItemCase2Type = "percentage";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase2Type: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateVersionRequestElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateVersionRequestElementsItemCase2Type;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase2: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase2>;
export type DynamicRoutingCreateVersionRequestElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateVersionRequestElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateVersionRequestElementsItemCase3PropertiesLimitType | (string & {});
    window: number;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3Properties: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase3Properties>;
export type DynamicRoutingCreateVersionRequestElementsItemCase3Type = "rate";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3Type: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateVersionRequestElementsItemCase3Properties;
    type: DynamicRoutingCreateVersionRequestElementsItemCase3Type;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase3: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase3>;
export type DynamicRoutingCreateVersionRequestElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionRequestElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateVersionRequestElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingCreateVersionRequestElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingCreateVersionRequestElementsItemCase4Type = "model";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase4Type: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateVersionRequestElementsItemCase4Type;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase4: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase4>;
export type DynamicRoutingCreateVersionRequestElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateVersionRequestElementsItemCase5OutputsMap: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase5OutputsMap>;
export type DynamicRoutingCreateVersionRequestElementsItemCase5Type = "end";
export declare const DynamicRoutingCreateVersionRequestElementsItemCase5Type: any;
export interface DynamicRoutingCreateVersionRequestElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateVersionRequestElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateVersionRequestElementsItemCase5Type;
}
export declare const DynamicRoutingCreateVersionRequestElementsItemCase5: S.Schema<DynamicRoutingCreateVersionRequestElementsItemCase5>;
export type DynamicRoutingCreateVersionRequestElementsItem = DynamicRoutingCreateVersionRequestElementsItemCase0 | DynamicRoutingCreateVersionRequestElementsItemCase1 | DynamicRoutingCreateVersionRequestElementsItemCase2 | DynamicRoutingCreateVersionRequestElementsItemCase3 | DynamicRoutingCreateVersionRequestElementsItemCase4 | DynamicRoutingCreateVersionRequestElementsItemCase5;
export declare const DynamicRoutingCreateVersionRequestElementsItem: any;
export type DynamicRoutingCreateVersionRequestElementsList = Array<DynamicRoutingCreateVersionRequestElementsItem>;
export declare const DynamicRoutingCreateVersionRequestElementsList: S.Schema<DynamicRoutingCreateVersionRequestElementsList>;
export interface CreateVersionDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    elements: DynamicRoutingCreateVersionRequestElementsList;
}
export declare const CreateVersionDynamicRoutingRequest: S.Schema<CreateVersionDynamicRoutingRequest>;
export type DynamicRoutingCreateVersionResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingCreateVersionResponseElementsItemCase0Type = "start";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase0Type: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateVersionResponseElementsItemCase0Type;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase0: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase0>;
export type DynamicRoutingCreateVersionResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingCreateVersionResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingCreateVersionResponseElementsItemCase1Type = "conditional";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase1Type: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateVersionResponseElementsItemCase1Type;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase1: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase1>;
export type DynamicRoutingCreateVersionResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateVersionResponseElementsItemCase2OutputsMap: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase2OutputsMap>;
export type DynamicRoutingCreateVersionResponseElementsItemCase2Type = "percentage";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase2Type: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateVersionResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateVersionResponseElementsItemCase2Type;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase2: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase2>;
export type DynamicRoutingCreateVersionResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateVersionResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateVersionResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3Properties: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase3Properties>;
export type DynamicRoutingCreateVersionResponseElementsItemCase3Type = "rate";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3Type: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateVersionResponseElementsItemCase3Properties;
    type: DynamicRoutingCreateVersionResponseElementsItemCase3Type;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase3: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase3>;
export type DynamicRoutingCreateVersionResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingCreateVersionResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingCreateVersionResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingCreateVersionResponseElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingCreateVersionResponseElementsItemCase4Type = "model";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase4Type: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateVersionResponseElementsItemCase4Type;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase4: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase4>;
export type DynamicRoutingCreateVersionResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingCreateVersionResponseElementsItemCase5OutputsMap: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase5OutputsMap>;
export type DynamicRoutingCreateVersionResponseElementsItemCase5Type = "end";
export declare const DynamicRoutingCreateVersionResponseElementsItemCase5Type: any;
export interface DynamicRoutingCreateVersionResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateVersionResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateVersionResponseElementsItemCase5Type;
}
export declare const DynamicRoutingCreateVersionResponseElementsItemCase5: S.Schema<DynamicRoutingCreateVersionResponseElementsItemCase5>;
export type DynamicRoutingCreateVersionResponseElementsItem = DynamicRoutingCreateVersionResponseElementsItemCase0 | DynamicRoutingCreateVersionResponseElementsItemCase1 | DynamicRoutingCreateVersionResponseElementsItemCase2 | DynamicRoutingCreateVersionResponseElementsItemCase3 | DynamicRoutingCreateVersionResponseElementsItemCase4 | DynamicRoutingCreateVersionResponseElementsItemCase5;
export declare const DynamicRoutingCreateVersionResponseElementsItem: any;
export type DynamicRoutingCreateVersionResponseElementsList = Array<DynamicRoutingCreateVersionResponseElementsItem>;
export declare const DynamicRoutingCreateVersionResponseElementsList: S.Schema<DynamicRoutingCreateVersionResponseElementsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateVersionDynamicRoutingResponse {
    id: string;
    createdAt: string;
    elements: DynamicRoutingCreateVersionResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    /** Identifier of the newly created version (top-level on the live wire; the docs' nested shape is stale). */
    versionId: string;
}
export declare const CreateVersionDynamicRoutingResponse: S.Schema<CreateVersionDynamicRoutingResponse>;
export interface CreditBalanceBillingRequest {
    accountId: string;
}
export declare const CreditBalanceBillingRequest: S.Schema<CreditBalanceBillingRequest>;
export interface BillingCreditBalanceResponsePaymentMethod {
    brand?: string | null;
    last4?: string | null;
}
export declare const BillingCreditBalanceResponsePaymentMethod: S.Schema<BillingCreditBalanceResponsePaymentMethod>;
export interface BillingCreditBalanceResponseTopupConfig {
    amount: number;
    disabledReason: string;
    error: string;
    lastFailedAt: number;
    threshold: number;
}
export declare const BillingCreditBalanceResponseTopupConfig: S.Schema<BillingCreditBalanceResponseTopupConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreditBalanceBillingResponse {
    balance: number;
    hasDefaultPaymentMethod: boolean;
    paymentMethod: BillingCreditBalanceResponsePaymentMethod;
    topupConfig: BillingCreditBalanceResponseTopupConfig;
    firstTopupSuccess?: boolean | null;
}
export declare const CreditBalanceBillingResponse: S.Schema<CreditBalanceBillingResponse>;
export interface DeleteAiGatewayRequest {
    accountId: string;
    /** gateway id */
    id: string;
}
export declare const DeleteAiGatewayRequest: S.Schema<DeleteAiGatewayRequest>;
export type DeleteResponseDlpCase0Action = "BLOCK" | "FLAG";
export declare const DeleteResponseDlpCase0Action: any;
export type DeleteResponseDlpCase0ProfilesList = Array<string>;
export declare const DeleteResponseDlpCase0ProfilesList: S.Schema<DeleteResponseDlpCase0ProfilesList>;
export interface DeleteResponseDlpCase0 {
    action: DeleteResponseDlpCase0Action;
    enabled: boolean;
    profiles: DeleteResponseDlpCase0ProfilesList;
}
export declare const DeleteResponseDlpCase0: S.Schema<DeleteResponseDlpCase0>;
export type DeleteResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export declare const DeleteResponseDlpCase1PoliciesItemAction: any;
export type DeleteResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export declare const DeleteResponseDlpCase1PoliciesItemCheckItem: any;
export type DeleteResponseDlpCase1PoliciesItemCheckList = Array<DeleteResponseDlpCase1PoliciesItemCheckItem>;
export declare const DeleteResponseDlpCase1PoliciesItemCheckList: S.Schema<DeleteResponseDlpCase1PoliciesItemCheckList>;
export type DeleteResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export declare const DeleteResponseDlpCase1PoliciesItemProfilesList: S.Schema<DeleteResponseDlpCase1PoliciesItemProfilesList>;
export interface DeleteResponseDlpCase1PoliciesItem {
    id: string;
    action: DeleteResponseDlpCase1PoliciesItemAction;
    check: DeleteResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: DeleteResponseDlpCase1PoliciesItemProfilesList;
}
export declare const DeleteResponseDlpCase1PoliciesItem: S.Schema<DeleteResponseDlpCase1PoliciesItem>;
export type DeleteResponseDlpCase1PoliciesList = Array<DeleteResponseDlpCase1PoliciesItem>;
export declare const DeleteResponseDlpCase1PoliciesList: S.Schema<DeleteResponseDlpCase1PoliciesList>;
export interface DeleteResponseDlpCase1 {
    enabled: boolean;
    policies: DeleteResponseDlpCase1PoliciesList;
}
export declare const DeleteResponseDlpCase1: S.Schema<DeleteResponseDlpCase1>;
export type DeleteResponseDlp = DeleteResponseDlpCase0 | DeleteResponseDlpCase1;
export declare const DeleteResponseDlp: any;
export type DeleteResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptP1: any;
export type DeleteResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS1: any;
export type DeleteResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS10: any;
export type DeleteResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS11: any;
export type DeleteResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS12: any;
export type DeleteResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS13: any;
export type DeleteResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS2: any;
export type DeleteResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS3: any;
export type DeleteResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS4: any;
export type DeleteResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS5: any;
export type DeleteResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS6: any;
export type DeleteResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS7: any;
export type DeleteResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS8: any;
export type DeleteResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsPromptS9: any;
export interface DeleteResponseGuardrailsPrompt {
    p1?: DeleteResponseGuardrailsPromptP1 | null;
    s1?: DeleteResponseGuardrailsPromptS1 | null;
    s10?: DeleteResponseGuardrailsPromptS10 | null;
    s11?: DeleteResponseGuardrailsPromptS11 | null;
    s12?: DeleteResponseGuardrailsPromptS12 | null;
    s13?: DeleteResponseGuardrailsPromptS13 | null;
    s2?: DeleteResponseGuardrailsPromptS2 | null;
    s3?: DeleteResponseGuardrailsPromptS3 | null;
    s4?: DeleteResponseGuardrailsPromptS4 | null;
    s5?: DeleteResponseGuardrailsPromptS5 | null;
    s6?: DeleteResponseGuardrailsPromptS6 | null;
    s7?: DeleteResponseGuardrailsPromptS7 | null;
    s8?: DeleteResponseGuardrailsPromptS8 | null;
    s9?: DeleteResponseGuardrailsPromptS9 | null;
}
export declare const DeleteResponseGuardrailsPrompt: S.Schema<DeleteResponseGuardrailsPrompt>;
export type DeleteResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseP1: any;
export type DeleteResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS1: any;
export type DeleteResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS10: any;
export type DeleteResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS11: any;
export type DeleteResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS12: any;
export type DeleteResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS13: any;
export type DeleteResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS2: any;
export type DeleteResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS3: any;
export type DeleteResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS4: any;
export type DeleteResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS5: any;
export type DeleteResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS6: any;
export type DeleteResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS7: any;
export type DeleteResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS8: any;
export type DeleteResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export declare const DeleteResponseGuardrailsResponseS9: any;
export interface DeleteResponseGuardrailsResponse {
    p1?: DeleteResponseGuardrailsResponseP1 | null;
    s1?: DeleteResponseGuardrailsResponseS1 | null;
    s10?: DeleteResponseGuardrailsResponseS10 | null;
    s11?: DeleteResponseGuardrailsResponseS11 | null;
    s12?: DeleteResponseGuardrailsResponseS12 | null;
    s13?: DeleteResponseGuardrailsResponseS13 | null;
    s2?: DeleteResponseGuardrailsResponseS2 | null;
    s3?: DeleteResponseGuardrailsResponseS3 | null;
    s4?: DeleteResponseGuardrailsResponseS4 | null;
    s5?: DeleteResponseGuardrailsResponseS5 | null;
    s6?: DeleteResponseGuardrailsResponseS6 | null;
    s7?: DeleteResponseGuardrailsResponseS7 | null;
    s8?: DeleteResponseGuardrailsResponseS8 | null;
    s9?: DeleteResponseGuardrailsResponseS9 | null;
}
export declare const DeleteResponseGuardrailsResponse: S.Schema<DeleteResponseGuardrailsResponse>;
export interface DeleteResponseGuardrails {
    prompt: DeleteResponseGuardrailsPrompt;
    response: DeleteResponseGuardrailsResponse;
}
export declare const DeleteResponseGuardrails: S.Schema<DeleteResponseGuardrails>;
export type DeleteResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const DeleteResponseLogManagementStrategy: any;
export type DeleteResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const DeleteResponseOtelItemHeadersMap: S.Schema<DeleteResponseOtelItemHeadersMap>;
export type DeleteResponseOtelItemContentType = "json" | "protobuf";
export declare const DeleteResponseOtelItemContentType: any;
export interface DeleteResponseOtelItem {
    headers: DeleteResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null;
    contentType?: DeleteResponseOtelItemContentType | null;
}
export declare const DeleteResponseOtelItem: S.Schema<DeleteResponseOtelItem>;
export type DeleteResponseOtelList = Array<DeleteResponseOtelItem>;
export declare const DeleteResponseOtelList: S.Schema<DeleteResponseOtelList>;
export type DeleteResponseRateLimitingTechnique = "fixed" | "sliding";
export declare const DeleteResponseRateLimitingTechnique: any;
export type DeleteResponseRetryBackoff = "constant" | "linear" | "exponential";
export declare const DeleteResponseRetryBackoff: any;
export type DeleteResponseSpendLimitsRulesItemLimitType = "cost";
export declare const DeleteResponseSpendLimitsRulesItemLimitType: any;
export type DeleteResponseSpendLimitsRulesItemModelMode = "filter";
export declare const DeleteResponseSpendLimitsRulesItemModelMode: any;
export type DeleteResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export declare const DeleteResponseSpendLimitsRulesItemModelValuesList: S.Schema<DeleteResponseSpendLimitsRulesItemModelValuesList>;
export interface DeleteResponseSpendLimitsRulesItemModel {
    mode: DeleteResponseSpendLimitsRulesItemModelMode;
    values: DeleteResponseSpendLimitsRulesItemModelValuesList;
}
export declare const DeleteResponseSpendLimitsRulesItemModel: S.Schema<DeleteResponseSpendLimitsRulesItemModel>;
export type DeleteResponseSpendLimitsRulesItemProviderMode = "filter";
export declare const DeleteResponseSpendLimitsRulesItemProviderMode: any;
export type DeleteResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export declare const DeleteResponseSpendLimitsRulesItemProviderValuesList: S.Schema<DeleteResponseSpendLimitsRulesItemProviderValuesList>;
export interface DeleteResponseSpendLimitsRulesItemProvider {
    mode: DeleteResponseSpendLimitsRulesItemProviderMode;
    values: DeleteResponseSpendLimitsRulesItemProviderValuesList;
}
export declare const DeleteResponseSpendLimitsRulesItemProvider: S.Schema<DeleteResponseSpendLimitsRulesItemProvider>;
export type DeleteResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export declare const DeleteResponseSpendLimitsRulesItemTechnique: any;
export interface DeleteResponseSpendLimitsRulesItem {
    limit: number;
    limitType: DeleteResponseSpendLimitsRulesItemLimitType;
    window: number;
    id?: string | null;
    enabled?: boolean | null;
    metadata?: UntypedMetadataMap | null;
    model?: DeleteResponseSpendLimitsRulesItemModel | null;
    provider?: DeleteResponseSpendLimitsRulesItemProvider | null;
    technique?: DeleteResponseSpendLimitsRulesItemTechnique | null;
}
export declare const DeleteResponseSpendLimitsRulesItem: S.Schema<DeleteResponseSpendLimitsRulesItem>;
export type DeleteResponseSpendLimitsRulesList = Array<DeleteResponseSpendLimitsRulesItem>;
export declare const DeleteResponseSpendLimitsRulesList: S.Schema<DeleteResponseSpendLimitsRulesList>;
export interface DeleteResponseSpendLimits {
    enabled?: boolean | null;
    rules?: DeleteResponseSpendLimitsRulesList | null;
}
export declare const DeleteResponseSpendLimits: S.Schema<DeleteResponseSpendLimits>;
export type DeleteResponseStripeUsageEventsItem = CreateResponseStripeUsageEventsItem;
export declare const DeleteResponseStripeUsageEventsItem: S.Schema<CreateResponseStripeUsageEventsItem>;
export type DeleteResponseStripeUsageEventsList = Array<CreateResponseStripeUsageEventsItem>;
export declare const DeleteResponseStripeUsageEventsList: S.Schema<DeleteResponseStripeUsageEventsList>;
export interface DeleteResponseStripe {
    authorization: string;
    usageEvents: DeleteResponseStripeUsageEventsList;
}
export declare const DeleteResponseStripe: S.Schema<DeleteResponseStripe>;
export type DeleteResponseWorkersAiBillingMode = "postpaid";
export declare const DeleteResponseWorkersAiBillingMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAiGatewayResponse {
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    authentication?: boolean | null;
    dlp?: DeleteResponseDlp | null;
    guardrails?: DeleteResponseGuardrails | null;
    isDefault?: boolean | null;
    logManagement?: number | null;
    logManagementStrategy?: DeleteResponseLogManagementStrategy | null;
    logpush?: boolean | null;
    logpushPublicKey?: string | null;
    otel?: DeleteResponseOtelList | null;
    rateLimitingTechnique?: DeleteResponseRateLimitingTechnique | null;
    /** Backoff strategy for retry delays */
    retryBackoff?: DeleteResponseRetryBackoff | null;
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number | null;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null;
    spendLimits?: DeleteResponseSpendLimits | null;
    storeId?: string | null;
    stripe?: DeleteResponseStripe | null;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: DeleteResponseWorkersAiBillingMode | null;
    zdr?: boolean | null;
}
export declare const DeleteAiGatewayResponse: S.Schema<DeleteAiGatewayResponse>;
export interface DeleteBillingSpendingLimitRequest {
    accountId: string;
}
export declare const DeleteBillingSpendingLimitRequest: S.Schema<DeleteBillingSpendingLimitRequest>;
export type DeleteBillingSpendingLimitResponse = unknown;
export declare const DeleteBillingSpendingLimitResponse: S.Schema<DeleteBillingSpendingLimitResponse>;
export interface DeleteBillingTopupConfigRequest {
    accountId: string;
}
export declare const DeleteBillingTopupConfigRequest: S.Schema<DeleteBillingTopupConfigRequest>;
export type DeleteBillingTopupConfigResponse = unknown;
export declare const DeleteBillingTopupConfigResponse: S.Schema<DeleteBillingTopupConfigResponse>;
export interface DeleteCustomProviderRequest {
    accountId: string;
    id: string;
}
export declare const DeleteCustomProviderRequest: S.Schema<DeleteCustomProviderRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCustomProviderResponse {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null;
    curlExample?: string | null;
    description?: string | null;
    enable?: boolean | null;
    headers?: string | null;
    jsExample?: string | null;
    link?: string | null;
    logo?: string | null;
    position?: number | null;
}
export declare const DeleteCustomProviderResponse: S.Schema<DeleteCustomProviderResponse>;
export interface DeleteDatasetRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export type DatasetsDeleteResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsDeleteResponseFiltersItemKey: any;
export type DatasetsDeleteResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsDeleteResponseFiltersItemOperator: any;
export type DatasetsDeleteResponseFiltersItemValueItem = string | number | boolean;
export declare const DatasetsDeleteResponseFiltersItemValueItem: any;
export type DatasetsDeleteResponseFiltersItemValueList = Array<DatasetsDeleteResponseFiltersItemValueItem>;
export declare const DatasetsDeleteResponseFiltersItemValueList: S.Schema<DatasetsDeleteResponseFiltersItemValueList>;
export interface DatasetsDeleteResponseFiltersItem {
    key: DatasetsDeleteResponseFiltersItemKey;
    operator: DatasetsDeleteResponseFiltersItemOperator;
    value: DatasetsDeleteResponseFiltersItemValueList;
}
export declare const DatasetsDeleteResponseFiltersItem: S.Schema<DatasetsDeleteResponseFiltersItem>;
export type DatasetsDeleteResponseFiltersList = Array<DatasetsDeleteResponseFiltersItem>;
export declare const DatasetsDeleteResponseFiltersList: S.Schema<DatasetsDeleteResponseFiltersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsDeleteResponseFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeleteDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export declare const DeleteDynamicRoutingRequest: S.Schema<DeleteDynamicRoutingRequest>;
export type DynamicRoutingDeleteResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingDeleteResponseElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingDeleteResponseElementsItemCase0Type = "start";
export declare const DynamicRoutingDeleteResponseElementsItemCase0Type: any;
export interface DynamicRoutingDeleteResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingDeleteResponseElementsItemCase0Type;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase0: S.Schema<DynamicRoutingDeleteResponseElementsItemCase0>;
export type DynamicRoutingDeleteResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingDeleteResponseElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingDeleteResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingDeleteResponseElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingDeleteResponseElementsItemCase1Type = "conditional";
export declare const DynamicRoutingDeleteResponseElementsItemCase1Type: any;
export interface DynamicRoutingDeleteResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingDeleteResponseElementsItemCase1Type;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase1: S.Schema<DynamicRoutingDeleteResponseElementsItemCase1>;
export type DynamicRoutingDeleteResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingDeleteResponseElementsItemCase2OutputsMap: S.Schema<DynamicRoutingDeleteResponseElementsItemCase2OutputsMap>;
export type DynamicRoutingDeleteResponseElementsItemCase2Type = "percentage";
export declare const DynamicRoutingDeleteResponseElementsItemCase2Type: any;
export interface DynamicRoutingDeleteResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingDeleteResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingDeleteResponseElementsItemCase2Type;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase2: S.Schema<DynamicRoutingDeleteResponseElementsItemCase2>;
export type DynamicRoutingDeleteResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingDeleteResponseElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingDeleteResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingDeleteResponseElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingDeleteResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingDeleteResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase3Properties: S.Schema<DynamicRoutingDeleteResponseElementsItemCase3Properties>;
export type DynamicRoutingDeleteResponseElementsItemCase3Type = "rate";
export declare const DynamicRoutingDeleteResponseElementsItemCase3Type: any;
export interface DynamicRoutingDeleteResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingDeleteResponseElementsItemCase3Properties;
    type: DynamicRoutingDeleteResponseElementsItemCase3Type;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase3: S.Schema<DynamicRoutingDeleteResponseElementsItemCase3>;
export type DynamicRoutingDeleteResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingDeleteResponseElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingDeleteResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingDeleteResponseElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingDeleteResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingDeleteResponseElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingDeleteResponseElementsItemCase4Type = "model";
export declare const DynamicRoutingDeleteResponseElementsItemCase4Type: any;
export interface DynamicRoutingDeleteResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingDeleteResponseElementsItemCase4Type;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase4: S.Schema<DynamicRoutingDeleteResponseElementsItemCase4>;
export type DynamicRoutingDeleteResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingDeleteResponseElementsItemCase5OutputsMap: S.Schema<DynamicRoutingDeleteResponseElementsItemCase5OutputsMap>;
export type DynamicRoutingDeleteResponseElementsItemCase5Type = "end";
export declare const DynamicRoutingDeleteResponseElementsItemCase5Type: any;
export interface DynamicRoutingDeleteResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingDeleteResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingDeleteResponseElementsItemCase5Type;
}
export declare const DynamicRoutingDeleteResponseElementsItemCase5: S.Schema<DynamicRoutingDeleteResponseElementsItemCase5>;
export type DynamicRoutingDeleteResponseElementsItem = DynamicRoutingDeleteResponseElementsItemCase0 | DynamicRoutingDeleteResponseElementsItemCase1 | DynamicRoutingDeleteResponseElementsItemCase2 | DynamicRoutingDeleteResponseElementsItemCase3 | DynamicRoutingDeleteResponseElementsItemCase4 | DynamicRoutingDeleteResponseElementsItemCase5;
export declare const DynamicRoutingDeleteResponseElementsItem: any;
export type DynamicRoutingDeleteResponseElementsList = Array<DynamicRoutingDeleteResponseElementsItem>;
export declare const DynamicRoutingDeleteResponseElementsList: S.Schema<DynamicRoutingDeleteResponseElementsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteDynamicRoutingResponse {
    id: string;
    createdAt: string;
    elements: DynamicRoutingDeleteResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const DeleteDynamicRoutingResponse: S.Schema<DeleteDynamicRoutingResponse>;
export interface DeleteEvaluationRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const DeleteEvaluationRequest: S.Schema<DeleteEvaluationRequest>;
export type EvaluationsDeleteResponseDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const EvaluationsDeleteResponseDatasetsItemFiltersItemKey: any;
export type EvaluationsDeleteResponseDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const EvaluationsDeleteResponseDatasetsItemFiltersItemOperator: any;
export type EvaluationsDeleteResponseDatasetsItemFiltersItemValueItem = string | number | boolean;
export declare const EvaluationsDeleteResponseDatasetsItemFiltersItemValueItem: any;
export type EvaluationsDeleteResponseDatasetsItemFiltersItemValueList = Array<EvaluationsDeleteResponseDatasetsItemFiltersItemValueItem>;
export declare const EvaluationsDeleteResponseDatasetsItemFiltersItemValueList: S.Schema<EvaluationsDeleteResponseDatasetsItemFiltersItemValueList>;
export interface EvaluationsDeleteResponseDatasetsItemFiltersItem {
    key: EvaluationsDeleteResponseDatasetsItemFiltersItemKey;
    operator: EvaluationsDeleteResponseDatasetsItemFiltersItemOperator;
    value: EvaluationsDeleteResponseDatasetsItemFiltersItemValueList;
}
export declare const EvaluationsDeleteResponseDatasetsItemFiltersItem: S.Schema<EvaluationsDeleteResponseDatasetsItemFiltersItem>;
export type EvaluationsDeleteResponseDatasetsItemFiltersList = Array<EvaluationsDeleteResponseDatasetsItemFiltersItem>;
export declare const EvaluationsDeleteResponseDatasetsItemFiltersList: S.Schema<EvaluationsDeleteResponseDatasetsItemFiltersList>;
export interface EvaluationsDeleteResponseDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsDeleteResponseDatasetsItemFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const EvaluationsDeleteResponseDatasetsItem: S.Schema<EvaluationsDeleteResponseDatasetsItem>;
export type EvaluationsDeleteResponseDatasetsList = Array<EvaluationsDeleteResponseDatasetsItem>;
export declare const EvaluationsDeleteResponseDatasetsList: S.Schema<EvaluationsDeleteResponseDatasetsList>;
export type EvaluationsDeleteResponseResultsItem = EvaluationsCreateResponseResultsItem;
export declare const EvaluationsDeleteResponseResultsItem: S.Schema<EvaluationsCreateResponseResultsItem>;
export type EvaluationsDeleteResponseResultsList = Array<EvaluationsCreateResponseResultsItem>;
export declare const EvaluationsDeleteResponseResultsList: S.Schema<EvaluationsDeleteResponseResultsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteEvaluationResponse {
    id: string;
    createdAt: string;
    datasets: EvaluationsDeleteResponseDatasetsList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsDeleteResponseResultsList;
    totalLogs: number;
}
export declare const DeleteEvaluationResponse: S.Schema<DeleteEvaluationResponse>;
export type LogsDeleteRequestFiltersList = Array<string>;
export declare const LogsDeleteRequestFiltersList: S.Schema<LogsDeleteRequestFiltersList>;
export type LogsDeleteRequestOrderBy = "created_at" | "provider" | "model" | "model_type" | "success" | "cached" | "cost" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const LogsDeleteRequestOrderBy: any;
export type LogsDeleteRequestOrderByDirection = "asc" | "desc";
export declare const LogsDeleteRequestOrderByDirection: any;
export interface DeleteLogRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    filters?: LogsDeleteRequestFiltersList;
    limit?: number;
    orderBy?: LogsDeleteRequestOrderBy | (string & {});
    orderByDirection?: LogsDeleteRequestOrderByDirection | (string & {});
}
export declare const DeleteLogRequest: S.Schema<DeleteLogRequest>;
export interface DeleteLogResponse {
}
export declare const DeleteLogResponse: S.Schema<DeleteLogResponse>;
export interface DeleteProviderConfigRequest {
    /** Identifier. */
    accountId: string;
    gatewayId: string;
    id: string;
}
export declare const DeleteProviderConfigRequest: S.Schema<DeleteProviderConfigRequest>;
export type DeleteProviderConfigResponse = unknown;
export declare const DeleteProviderConfigResponse: S.Schema<DeleteProviderConfigResponse>;
export interface GetAiGatewayRequest {
    accountId: string;
    /** gateway id */
    id: string;
}
export declare const GetAiGatewayRequest: S.Schema<GetAiGatewayRequest>;
export type GetResponseDlpCase0Action = "BLOCK" | "FLAG";
export declare const GetResponseDlpCase0Action: any;
export type GetResponseDlpCase0ProfilesList = Array<string>;
export declare const GetResponseDlpCase0ProfilesList: S.Schema<GetResponseDlpCase0ProfilesList>;
export interface GetResponseDlpCase0 {
    action: GetResponseDlpCase0Action;
    enabled: boolean;
    profiles: GetResponseDlpCase0ProfilesList;
}
export declare const GetResponseDlpCase0: S.Schema<GetResponseDlpCase0>;
export type GetResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export declare const GetResponseDlpCase1PoliciesItemAction: any;
export type GetResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export declare const GetResponseDlpCase1PoliciesItemCheckItem: any;
export type GetResponseDlpCase1PoliciesItemCheckList = Array<GetResponseDlpCase1PoliciesItemCheckItem>;
export declare const GetResponseDlpCase1PoliciesItemCheckList: S.Schema<GetResponseDlpCase1PoliciesItemCheckList>;
export type GetResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export declare const GetResponseDlpCase1PoliciesItemProfilesList: S.Schema<GetResponseDlpCase1PoliciesItemProfilesList>;
export interface GetResponseDlpCase1PoliciesItem {
    id: string;
    action: GetResponseDlpCase1PoliciesItemAction;
    check: GetResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: GetResponseDlpCase1PoliciesItemProfilesList;
}
export declare const GetResponseDlpCase1PoliciesItem: S.Schema<GetResponseDlpCase1PoliciesItem>;
export type GetResponseDlpCase1PoliciesList = Array<GetResponseDlpCase1PoliciesItem>;
export declare const GetResponseDlpCase1PoliciesList: S.Schema<GetResponseDlpCase1PoliciesList>;
export interface GetResponseDlpCase1 {
    enabled: boolean;
    policies: GetResponseDlpCase1PoliciesList;
}
export declare const GetResponseDlpCase1: S.Schema<GetResponseDlpCase1>;
export type GetResponseDlp = GetResponseDlpCase0 | GetResponseDlpCase1;
export declare const GetResponseDlp: any;
export type GetResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptP1: any;
export type GetResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS1: any;
export type GetResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS10: any;
export type GetResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS11: any;
export type GetResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS12: any;
export type GetResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS13: any;
export type GetResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS2: any;
export type GetResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS3: any;
export type GetResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS4: any;
export type GetResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS5: any;
export type GetResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS6: any;
export type GetResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS7: any;
export type GetResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS8: any;
export type GetResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsPromptS9: any;
export interface GetResponseGuardrailsPrompt {
    p1?: GetResponseGuardrailsPromptP1 | null;
    s1?: GetResponseGuardrailsPromptS1 | null;
    s10?: GetResponseGuardrailsPromptS10 | null;
    s11?: GetResponseGuardrailsPromptS11 | null;
    s12?: GetResponseGuardrailsPromptS12 | null;
    s13?: GetResponseGuardrailsPromptS13 | null;
    s2?: GetResponseGuardrailsPromptS2 | null;
    s3?: GetResponseGuardrailsPromptS3 | null;
    s4?: GetResponseGuardrailsPromptS4 | null;
    s5?: GetResponseGuardrailsPromptS5 | null;
    s6?: GetResponseGuardrailsPromptS6 | null;
    s7?: GetResponseGuardrailsPromptS7 | null;
    s8?: GetResponseGuardrailsPromptS8 | null;
    s9?: GetResponseGuardrailsPromptS9 | null;
}
export declare const GetResponseGuardrailsPrompt: S.Schema<GetResponseGuardrailsPrompt>;
export type GetResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseP1: any;
export type GetResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS1: any;
export type GetResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS10: any;
export type GetResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS11: any;
export type GetResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS12: any;
export type GetResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS13: any;
export type GetResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS2: any;
export type GetResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS3: any;
export type GetResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS4: any;
export type GetResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS5: any;
export type GetResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS6: any;
export type GetResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS7: any;
export type GetResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS8: any;
export type GetResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export declare const GetResponseGuardrailsResponseS9: any;
export interface GetResponseGuardrailsResponse {
    p1?: GetResponseGuardrailsResponseP1 | null;
    s1?: GetResponseGuardrailsResponseS1 | null;
    s10?: GetResponseGuardrailsResponseS10 | null;
    s11?: GetResponseGuardrailsResponseS11 | null;
    s12?: GetResponseGuardrailsResponseS12 | null;
    s13?: GetResponseGuardrailsResponseS13 | null;
    s2?: GetResponseGuardrailsResponseS2 | null;
    s3?: GetResponseGuardrailsResponseS3 | null;
    s4?: GetResponseGuardrailsResponseS4 | null;
    s5?: GetResponseGuardrailsResponseS5 | null;
    s6?: GetResponseGuardrailsResponseS6 | null;
    s7?: GetResponseGuardrailsResponseS7 | null;
    s8?: GetResponseGuardrailsResponseS8 | null;
    s9?: GetResponseGuardrailsResponseS9 | null;
}
export declare const GetResponseGuardrailsResponse: S.Schema<GetResponseGuardrailsResponse>;
export interface GetResponseGuardrails {
    prompt: GetResponseGuardrailsPrompt;
    response: GetResponseGuardrailsResponse;
}
export declare const GetResponseGuardrails: S.Schema<GetResponseGuardrails>;
export type GetResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const GetResponseLogManagementStrategy: any;
export type GetResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const GetResponseOtelItemHeadersMap: S.Schema<GetResponseOtelItemHeadersMap>;
export type GetResponseOtelItemContentType = "json" | "protobuf";
export declare const GetResponseOtelItemContentType: any;
export interface GetResponseOtelItem {
    headers: GetResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null;
    contentType?: GetResponseOtelItemContentType | null;
}
export declare const GetResponseOtelItem: S.Schema<GetResponseOtelItem>;
export type GetResponseOtelList = Array<GetResponseOtelItem>;
export declare const GetResponseOtelList: S.Schema<GetResponseOtelList>;
export type GetResponseRateLimitingTechnique = "fixed" | "sliding";
export declare const GetResponseRateLimitingTechnique: any;
export type GetResponseRetryBackoff = "constant" | "linear" | "exponential";
export declare const GetResponseRetryBackoff: any;
export type GetResponseSpendLimitsRulesItemLimitType = "cost";
export declare const GetResponseSpendLimitsRulesItemLimitType: any;
export type GetResponseSpendLimitsRulesItemModelMode = "filter";
export declare const GetResponseSpendLimitsRulesItemModelMode: any;
export type GetResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export declare const GetResponseSpendLimitsRulesItemModelValuesList: S.Schema<GetResponseSpendLimitsRulesItemModelValuesList>;
export interface GetResponseSpendLimitsRulesItemModel {
    mode: GetResponseSpendLimitsRulesItemModelMode;
    values: GetResponseSpendLimitsRulesItemModelValuesList;
}
export declare const GetResponseSpendLimitsRulesItemModel: S.Schema<GetResponseSpendLimitsRulesItemModel>;
export type GetResponseSpendLimitsRulesItemProviderMode = "filter";
export declare const GetResponseSpendLimitsRulesItemProviderMode: any;
export type GetResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export declare const GetResponseSpendLimitsRulesItemProviderValuesList: S.Schema<GetResponseSpendLimitsRulesItemProviderValuesList>;
export interface GetResponseSpendLimitsRulesItemProvider {
    mode: GetResponseSpendLimitsRulesItemProviderMode;
    values: GetResponseSpendLimitsRulesItemProviderValuesList;
}
export declare const GetResponseSpendLimitsRulesItemProvider: S.Schema<GetResponseSpendLimitsRulesItemProvider>;
export type GetResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export declare const GetResponseSpendLimitsRulesItemTechnique: any;
export interface GetResponseSpendLimitsRulesItem {
    limit: number;
    limitType: GetResponseSpendLimitsRulesItemLimitType;
    window: number;
    id?: string | null;
    enabled?: boolean | null;
    metadata?: UntypedMetadataMap | null;
    model?: GetResponseSpendLimitsRulesItemModel | null;
    provider?: GetResponseSpendLimitsRulesItemProvider | null;
    technique?: GetResponseSpendLimitsRulesItemTechnique | null;
}
export declare const GetResponseSpendLimitsRulesItem: S.Schema<GetResponseSpendLimitsRulesItem>;
export type GetResponseSpendLimitsRulesList = Array<GetResponseSpendLimitsRulesItem>;
export declare const GetResponseSpendLimitsRulesList: S.Schema<GetResponseSpendLimitsRulesList>;
export interface GetResponseSpendLimits {
    enabled?: boolean | null;
    rules?: GetResponseSpendLimitsRulesList | null;
}
export declare const GetResponseSpendLimits: S.Schema<GetResponseSpendLimits>;
export type GetResponseStripeUsageEventsItem = CreateResponseStripeUsageEventsItem;
export declare const GetResponseStripeUsageEventsItem: S.Schema<CreateResponseStripeUsageEventsItem>;
export type GetResponseStripeUsageEventsList = Array<CreateResponseStripeUsageEventsItem>;
export declare const GetResponseStripeUsageEventsList: S.Schema<GetResponseStripeUsageEventsList>;
export interface GetResponseStripe {
    authorization: string;
    usageEvents: GetResponseStripeUsageEventsList;
}
export declare const GetResponseStripe: S.Schema<GetResponseStripe>;
export type GetResponseWorkersAiBillingMode = "postpaid";
export declare const GetResponseWorkersAiBillingMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAiGatewayResponse {
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    authentication?: boolean | null;
    dlp?: GetResponseDlp | null;
    guardrails?: GetResponseGuardrails | null;
    isDefault?: boolean | null;
    logManagement?: number | null;
    logManagementStrategy?: GetResponseLogManagementStrategy | null;
    logpush?: boolean | null;
    logpushPublicKey?: string | null;
    otel?: GetResponseOtelList | null;
    rateLimitingTechnique?: GetResponseRateLimitingTechnique | null;
    /** Backoff strategy for retry delays */
    retryBackoff?: GetResponseRetryBackoff | null;
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number | null;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null;
    spendLimits?: GetResponseSpendLimits | null;
    storeId?: string | null;
    stripe?: GetResponseStripe | null;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: GetResponseWorkersAiBillingMode | null;
    zdr?: boolean | null;
}
export declare const GetAiGatewayResponse: S.Schema<GetAiGatewayResponse>;
export interface GetBillingSpendingLimitRequest {
    accountId: string;
}
export declare const GetBillingSpendingLimitRequest: S.Schema<GetBillingSpendingLimitRequest>;
export interface BillingSpendingLimitGetResponseConfig {
    amount: number;
    duration: string;
    strategy: string;
}
export declare const BillingSpendingLimitGetResponseConfig: S.Schema<BillingSpendingLimitGetResponseConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingSpendingLimitResponse {
    config: BillingSpendingLimitGetResponseConfig;
    enabled: boolean;
}
export declare const GetBillingSpendingLimitResponse: S.Schema<GetBillingSpendingLimitResponse>;
export interface GetBillingTopupConfigRequest {
    accountId: string;
}
export declare const GetBillingTopupConfigRequest: S.Schema<GetBillingTopupConfigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingTopupConfigResponse {
    amount: number;
    disabledReason: string;
    error: string;
    lastFailedAt: number;
    threshold: number;
}
export declare const GetBillingTopupConfigResponse: S.Schema<GetBillingTopupConfigResponse>;
export interface GetCustomProviderRequest {
    accountId: string;
    id: string;
}
export declare const GetCustomProviderRequest: S.Schema<GetCustomProviderRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomProviderResponse {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null;
    curlExample?: string | null;
    description?: string | null;
    enable?: boolean | null;
    headers?: string | null;
    jsExample?: string | null;
    link?: string | null;
    logo?: string | null;
    position?: number | null;
}
export declare const GetCustomProviderResponse: S.Schema<GetCustomProviderResponse>;
export interface GetDatasetRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const GetDatasetRequest: S.Schema<GetDatasetRequest>;
export type DatasetsGetResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsGetResponseFiltersItemKey: any;
export type DatasetsGetResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsGetResponseFiltersItemOperator: any;
export type DatasetsGetResponseFiltersItemValueItem = string | number | boolean;
export declare const DatasetsGetResponseFiltersItemValueItem: any;
export type DatasetsGetResponseFiltersItemValueList = Array<DatasetsGetResponseFiltersItemValueItem>;
export declare const DatasetsGetResponseFiltersItemValueList: S.Schema<DatasetsGetResponseFiltersItemValueList>;
export interface DatasetsGetResponseFiltersItem {
    key: DatasetsGetResponseFiltersItemKey;
    operator: DatasetsGetResponseFiltersItemOperator;
    value: DatasetsGetResponseFiltersItemValueList;
}
export declare const DatasetsGetResponseFiltersItem: S.Schema<DatasetsGetResponseFiltersItem>;
export type DatasetsGetResponseFiltersList = Array<DatasetsGetResponseFiltersItem>;
export declare const DatasetsGetResponseFiltersList: S.Schema<DatasetsGetResponseFiltersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsGetResponseFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const GetDatasetResponse: S.Schema<GetDatasetResponse>;
export interface GetDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export declare const GetDynamicRoutingRequest: S.Schema<GetDynamicRoutingRequest>;
export type DynamicRoutingGetResponseDeployment = DynamicRoutingCreateResponseDeployment;
export declare const DynamicRoutingGetResponseDeployment: S.Schema<DynamicRoutingCreateResponseDeployment>;
export type DynamicRoutingGetResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingGetResponseElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingGetResponseElementsItemCase0Type = "start";
export declare const DynamicRoutingGetResponseElementsItemCase0Type: any;
export interface DynamicRoutingGetResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingGetResponseElementsItemCase0Type;
}
export declare const DynamicRoutingGetResponseElementsItemCase0: S.Schema<DynamicRoutingGetResponseElementsItemCase0>;
export type DynamicRoutingGetResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingGetResponseElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingGetResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingGetResponseElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingGetResponseElementsItemCase1Type = "conditional";
export declare const DynamicRoutingGetResponseElementsItemCase1Type: any;
export interface DynamicRoutingGetResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingGetResponseElementsItemCase1Type;
}
export declare const DynamicRoutingGetResponseElementsItemCase1: S.Schema<DynamicRoutingGetResponseElementsItemCase1>;
export type DynamicRoutingGetResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingGetResponseElementsItemCase2OutputsMap: S.Schema<DynamicRoutingGetResponseElementsItemCase2OutputsMap>;
export type DynamicRoutingGetResponseElementsItemCase2Type = "percentage";
export declare const DynamicRoutingGetResponseElementsItemCase2Type: any;
export interface DynamicRoutingGetResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingGetResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingGetResponseElementsItemCase2Type;
}
export declare const DynamicRoutingGetResponseElementsItemCase2: S.Schema<DynamicRoutingGetResponseElementsItemCase2>;
export type DynamicRoutingGetResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingGetResponseElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingGetResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingGetResponseElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingGetResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingGetResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingGetResponseElementsItemCase3Properties: S.Schema<DynamicRoutingGetResponseElementsItemCase3Properties>;
export type DynamicRoutingGetResponseElementsItemCase3Type = "rate";
export declare const DynamicRoutingGetResponseElementsItemCase3Type: any;
export interface DynamicRoutingGetResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingGetResponseElementsItemCase3Properties;
    type: DynamicRoutingGetResponseElementsItemCase3Type;
}
export declare const DynamicRoutingGetResponseElementsItemCase3: S.Schema<DynamicRoutingGetResponseElementsItemCase3>;
export type DynamicRoutingGetResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetResponseElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingGetResponseElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingGetResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingGetResponseElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingGetResponseElementsItemCase4Type = "model";
export declare const DynamicRoutingGetResponseElementsItemCase4Type: any;
export interface DynamicRoutingGetResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingGetResponseElementsItemCase4Type;
}
export declare const DynamicRoutingGetResponseElementsItemCase4: S.Schema<DynamicRoutingGetResponseElementsItemCase4>;
export type DynamicRoutingGetResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingGetResponseElementsItemCase5OutputsMap: S.Schema<DynamicRoutingGetResponseElementsItemCase5OutputsMap>;
export type DynamicRoutingGetResponseElementsItemCase5Type = "end";
export declare const DynamicRoutingGetResponseElementsItemCase5Type: any;
export interface DynamicRoutingGetResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingGetResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingGetResponseElementsItemCase5Type;
}
export declare const DynamicRoutingGetResponseElementsItemCase5: S.Schema<DynamicRoutingGetResponseElementsItemCase5>;
export type DynamicRoutingGetResponseElementsItem = DynamicRoutingGetResponseElementsItemCase0 | DynamicRoutingGetResponseElementsItemCase1 | DynamicRoutingGetResponseElementsItemCase2 | DynamicRoutingGetResponseElementsItemCase3 | DynamicRoutingGetResponseElementsItemCase4 | DynamicRoutingGetResponseElementsItemCase5;
export declare const DynamicRoutingGetResponseElementsItem: any;
export type DynamicRoutingGetResponseElementsList = Array<DynamicRoutingGetResponseElementsItem>;
export declare const DynamicRoutingGetResponseElementsList: S.Schema<DynamicRoutingGetResponseElementsList>;
export type DynamicRoutingGetResponseVersionActive = "true" | "false";
export declare const DynamicRoutingGetResponseVersionActive: any;
export interface DynamicRoutingGetResponseVersion {
    active: DynamicRoutingGetResponseVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null;
}
export declare const DynamicRoutingGetResponseVersion: S.Schema<DynamicRoutingGetResponseVersion>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDynamicRoutingResponse {
    id: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingGetResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingGetResponseVersion;
}
export declare const GetDynamicRoutingResponse: S.Schema<GetDynamicRoutingResponse>;
export interface GetEvaluationRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const GetEvaluationRequest: S.Schema<GetEvaluationRequest>;
export type EvaluationsGetResponseDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const EvaluationsGetResponseDatasetsItemFiltersItemKey: any;
export type EvaluationsGetResponseDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const EvaluationsGetResponseDatasetsItemFiltersItemOperator: any;
export type EvaluationsGetResponseDatasetsItemFiltersItemValueItem = string | number | boolean;
export declare const EvaluationsGetResponseDatasetsItemFiltersItemValueItem: any;
export type EvaluationsGetResponseDatasetsItemFiltersItemValueList = Array<EvaluationsGetResponseDatasetsItemFiltersItemValueItem>;
export declare const EvaluationsGetResponseDatasetsItemFiltersItemValueList: S.Schema<EvaluationsGetResponseDatasetsItemFiltersItemValueList>;
export interface EvaluationsGetResponseDatasetsItemFiltersItem {
    key: EvaluationsGetResponseDatasetsItemFiltersItemKey;
    operator: EvaluationsGetResponseDatasetsItemFiltersItemOperator;
    value: EvaluationsGetResponseDatasetsItemFiltersItemValueList;
}
export declare const EvaluationsGetResponseDatasetsItemFiltersItem: S.Schema<EvaluationsGetResponseDatasetsItemFiltersItem>;
export type EvaluationsGetResponseDatasetsItemFiltersList = Array<EvaluationsGetResponseDatasetsItemFiltersItem>;
export declare const EvaluationsGetResponseDatasetsItemFiltersList: S.Schema<EvaluationsGetResponseDatasetsItemFiltersList>;
export interface EvaluationsGetResponseDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsGetResponseDatasetsItemFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const EvaluationsGetResponseDatasetsItem: S.Schema<EvaluationsGetResponseDatasetsItem>;
export type EvaluationsGetResponseDatasetsList = Array<EvaluationsGetResponseDatasetsItem>;
export declare const EvaluationsGetResponseDatasetsList: S.Schema<EvaluationsGetResponseDatasetsList>;
export type EvaluationsGetResponseResultsItem = EvaluationsCreateResponseResultsItem;
export declare const EvaluationsGetResponseResultsItem: S.Schema<EvaluationsCreateResponseResultsItem>;
export type EvaluationsGetResponseResultsList = Array<EvaluationsCreateResponseResultsItem>;
export declare const EvaluationsGetResponseResultsList: S.Schema<EvaluationsGetResponseResultsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEvaluationResponse {
    id: string;
    createdAt: string;
    datasets: EvaluationsGetResponseDatasetsList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsGetResponseResultsList;
    totalLogs: number;
}
export declare const GetEvaluationResponse: S.Schema<GetEvaluationResponse>;
export interface GetLogRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const GetLogRequest: S.Schema<GetLogRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLogResponse {
    id: string;
    cached: boolean;
    createdAt: string;
    duration: number;
    model: string;
    path: string;
    provider: string;
    success: boolean;
    tokensIn: number;
    tokensOut: number;
    cost?: number | null;
    customCost?: boolean | null;
    metadata?: string | null;
    modelType?: string | null;
    requestContentType?: string | null;
    requestHead?: string | null;
    requestHeadComplete?: boolean | null;
    requestSize?: number | null;
    requestType?: string | null;
    responseContentType?: string | null;
    responseHead?: string | null;
    responseHeadComplete?: boolean | null;
    responseSize?: number | null;
    statusCode?: number | null;
    step?: number | null;
}
export declare const GetLogResponse: S.Schema<GetLogResponse>;
export interface GetUrlRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    provider: string;
}
export declare const GetUrlRequest: S.Schema<GetUrlRequest>;
export type GetUrlResponse = string;
export declare const GetUrlResponse: S.Schema<GetUrlResponse>;
export interface GetVersionDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    versionId: string;
}
export declare const GetVersionDynamicRoutingRequest: S.Schema<GetVersionDynamicRoutingRequest>;
export type DynamicRoutingGetVersionResponseActive = "true" | "false";
export declare const DynamicRoutingGetVersionResponseActive: any;
export type DynamicRoutingGetVersionResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingGetVersionResponseElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingGetVersionResponseElementsItemCase0Type = "start";
export declare const DynamicRoutingGetVersionResponseElementsItemCase0Type: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingGetVersionResponseElementsItemCase0Type;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase0: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase0>;
export type DynamicRoutingGetVersionResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingGetVersionResponseElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingGetVersionResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingGetVersionResponseElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingGetVersionResponseElementsItemCase1Type = "conditional";
export declare const DynamicRoutingGetVersionResponseElementsItemCase1Type: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingGetVersionResponseElementsItemCase1Type;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase1: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase1>;
export type DynamicRoutingGetVersionResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingGetVersionResponseElementsItemCase2OutputsMap: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase2OutputsMap>;
export type DynamicRoutingGetVersionResponseElementsItemCase2Type = "percentage";
export declare const DynamicRoutingGetVersionResponseElementsItemCase2Type: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingGetVersionResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingGetVersionResponseElementsItemCase2Type;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase2: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase2>;
export type DynamicRoutingGetVersionResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingGetVersionResponseElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingGetVersionResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingGetVersionResponseElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingGetVersionResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase3Properties: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase3Properties>;
export type DynamicRoutingGetVersionResponseElementsItemCase3Type = "rate";
export declare const DynamicRoutingGetVersionResponseElementsItemCase3Type: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingGetVersionResponseElementsItemCase3Properties;
    type: DynamicRoutingGetVersionResponseElementsItemCase3Type;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase3: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase3>;
export type DynamicRoutingGetVersionResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingGetVersionResponseElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingGetVersionResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingGetVersionResponseElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingGetVersionResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingGetVersionResponseElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingGetVersionResponseElementsItemCase4Type = "model";
export declare const DynamicRoutingGetVersionResponseElementsItemCase4Type: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingGetVersionResponseElementsItemCase4Type;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase4: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase4>;
export type DynamicRoutingGetVersionResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingGetVersionResponseElementsItemCase5OutputsMap: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase5OutputsMap>;
export type DynamicRoutingGetVersionResponseElementsItemCase5Type = "end";
export declare const DynamicRoutingGetVersionResponseElementsItemCase5Type: any;
export interface DynamicRoutingGetVersionResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingGetVersionResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingGetVersionResponseElementsItemCase5Type;
}
export declare const DynamicRoutingGetVersionResponseElementsItemCase5: S.Schema<DynamicRoutingGetVersionResponseElementsItemCase5>;
export type DynamicRoutingGetVersionResponseElementsItem = DynamicRoutingGetVersionResponseElementsItemCase0 | DynamicRoutingGetVersionResponseElementsItemCase1 | DynamicRoutingGetVersionResponseElementsItemCase2 | DynamicRoutingGetVersionResponseElementsItemCase3 | DynamicRoutingGetVersionResponseElementsItemCase4 | DynamicRoutingGetVersionResponseElementsItemCase5;
export declare const DynamicRoutingGetVersionResponseElementsItem: any;
export type DynamicRoutingGetVersionResponseElementsList = Array<DynamicRoutingGetVersionResponseElementsItem>;
export declare const DynamicRoutingGetVersionResponseElementsList: S.Schema<DynamicRoutingGetVersionResponseElementsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVersionDynamicRoutingResponse {
    id: string;
    active: DynamicRoutingGetVersionResponseActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    elements: DynamicRoutingGetVersionResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    versionId: string;
    isValid?: boolean | null;
}
export declare const GetVersionDynamicRoutingResponse: S.Schema<GetVersionDynamicRoutingResponse>;
export type BillingInvoiceHistoryRequestType = "auto" | "all" | "manual";
export declare const BillingInvoiceHistoryRequestType: any;
export interface InvoiceHistoryBillingRequest {
    accountId: string;
    /** Filter invoice type: auto, manual, or all. */
    type?: BillingInvoiceHistoryRequestType | (string & {});
}
export declare const InvoiceHistoryBillingRequest: S.Schema<InvoiceHistoryBillingRequest>;
export interface BillingInvoiceHistoryResponseInvoicesItem {
    amountDue: number;
    amountPaid: number;
    amountRemaining: number;
    currency: string;
    id?: string | null;
    attemptCount?: number | null;
    attempted?: boolean | null;
    autoAdvance?: boolean | null;
    created?: number | null;
    createdBy?: string | null;
    description?: string | null;
    invoiceOrigin?: string | null;
    invoicePdf?: string | null;
    status?: string | null;
}
export declare const BillingInvoiceHistoryResponseInvoicesItem: S.Schema<BillingInvoiceHistoryResponseInvoicesItem>;
export type BillingInvoiceHistoryResponseInvoicesList = Array<BillingInvoiceHistoryResponseInvoicesItem>;
export declare const BillingInvoiceHistoryResponseInvoicesList: S.Schema<BillingInvoiceHistoryResponseInvoicesList>;
export interface BillingInvoiceHistoryResponsePagination {
    hasMore: boolean;
    page: number;
    perPage: number;
    totalCount: number;
}
export declare const BillingInvoiceHistoryResponsePagination: S.Schema<BillingInvoiceHistoryResponsePagination>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InvoiceHistoryBillingResponse {
    invoices: BillingInvoiceHistoryResponseInvoicesList;
    pagination: BillingInvoiceHistoryResponsePagination;
}
export declare const InvoiceHistoryBillingResponse: S.Schema<InvoiceHistoryBillingResponse>;
export interface InvoicePreviewBillingRequest {
    accountId: string;
}
export declare const InvoicePreviewBillingRequest: S.Schema<InvoicePreviewBillingRequest>;
export interface BillingInvoicePreviewResponseInvoiceLinesItemPeriod {
    end: number;
    start: number;
}
export declare const BillingInvoicePreviewResponseInvoiceLinesItemPeriod: S.Schema<BillingInvoicePreviewResponseInvoiceLinesItemPeriod>;
export interface BillingInvoicePreviewResponseInvoiceLinesItemPricing {
    unitAmountDecimal: string;
}
export declare const BillingInvoicePreviewResponseInvoiceLinesItemPricing: S.Schema<BillingInvoicePreviewResponseInvoiceLinesItemPricing>;
export interface BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsItem {
    amount: number;
    type: string;
    creditBalanceTransaction?: string | null;
    discount?: string | null;
}
export declare const BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsItem: S.Schema<BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsItem>;
export type BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsList = Array<BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsItem>;
export declare const BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsList: S.Schema<BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsList>;
export interface BillingInvoicePreviewResponseInvoiceLinesItem {
    amount: number;
    currency: string;
    description: string;
    period: BillingInvoicePreviewResponseInvoiceLinesItemPeriod;
    pricing: BillingInvoicePreviewResponseInvoiceLinesItemPricing;
    quantity: number;
    pretaxCreditAmounts?: BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsList | null;
}
export declare const BillingInvoicePreviewResponseInvoiceLinesItem: S.Schema<BillingInvoicePreviewResponseInvoiceLinesItem>;
export type BillingInvoicePreviewResponseInvoiceLinesList = Array<BillingInvoicePreviewResponseInvoiceLinesItem>;
export declare const BillingInvoicePreviewResponseInvoiceLinesList: S.Schema<BillingInvoicePreviewResponseInvoiceLinesList>;
export type BillingInvoicePreviewResponseStatus = "draft" | "open" | "paid" | "uncollectible" | "void";
export declare const BillingInvoicePreviewResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InvoicePreviewBillingResponse {
    id: string;
    amountDue: number;
    amountPaid: number;
    amountRemaining: number;
    currency: string;
    invoiceLines: BillingInvoicePreviewResponseInvoiceLinesList;
    periodEnd: number;
    periodStart: number;
    status: BillingInvoicePreviewResponseStatus;
}
export declare const InvoicePreviewBillingResponse: S.Schema<InvoicePreviewBillingResponse>;
export interface ListAiGatewaysRequest {
    accountId: string;
    page?: number;
    perPage?: number;
    /** Search by id */
    search?: string;
}
export declare const ListAiGatewaysRequest: S.Schema<ListAiGatewaysRequest>;
export type ListResultItemDlpCase0Action = "BLOCK" | "FLAG";
export declare const ListResultItemDlpCase0Action: any;
export type ListResultItemDlpCase0ProfilesList = Array<string>;
export declare const ListResultItemDlpCase0ProfilesList: S.Schema<ListResultItemDlpCase0ProfilesList>;
export interface ListResultItemDlpCase0 {
    action: ListResultItemDlpCase0Action;
    enabled: boolean;
    profiles: ListResultItemDlpCase0ProfilesList;
}
export declare const ListResultItemDlpCase0: S.Schema<ListResultItemDlpCase0>;
export type ListResultItemDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export declare const ListResultItemDlpCase1PoliciesItemAction: any;
export type ListResultItemDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export declare const ListResultItemDlpCase1PoliciesItemCheckItem: any;
export type ListResultItemDlpCase1PoliciesItemCheckList = Array<ListResultItemDlpCase1PoliciesItemCheckItem>;
export declare const ListResultItemDlpCase1PoliciesItemCheckList: S.Schema<ListResultItemDlpCase1PoliciesItemCheckList>;
export type ListResultItemDlpCase1PoliciesItemProfilesList = Array<string>;
export declare const ListResultItemDlpCase1PoliciesItemProfilesList: S.Schema<ListResultItemDlpCase1PoliciesItemProfilesList>;
export interface ListResultItemDlpCase1PoliciesItem {
    id: string;
    action: ListResultItemDlpCase1PoliciesItemAction;
    check: ListResultItemDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: ListResultItemDlpCase1PoliciesItemProfilesList;
}
export declare const ListResultItemDlpCase1PoliciesItem: S.Schema<ListResultItemDlpCase1PoliciesItem>;
export type ListResultItemDlpCase1PoliciesList = Array<ListResultItemDlpCase1PoliciesItem>;
export declare const ListResultItemDlpCase1PoliciesList: S.Schema<ListResultItemDlpCase1PoliciesList>;
export interface ListResultItemDlpCase1 {
    enabled: boolean;
    policies: ListResultItemDlpCase1PoliciesList;
}
export declare const ListResultItemDlpCase1: S.Schema<ListResultItemDlpCase1>;
export type ListResultItemDlp = ListResultItemDlpCase0 | ListResultItemDlpCase1;
export declare const ListResultItemDlp: any;
export type ListResultItemGuardrailsPromptP1 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptP1: any;
export type ListResultItemGuardrailsPromptS1 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS1: any;
export type ListResultItemGuardrailsPromptS10 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS10: any;
export type ListResultItemGuardrailsPromptS11 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS11: any;
export type ListResultItemGuardrailsPromptS12 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS12: any;
export type ListResultItemGuardrailsPromptS13 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS13: any;
export type ListResultItemGuardrailsPromptS2 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS2: any;
export type ListResultItemGuardrailsPromptS3 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS3: any;
export type ListResultItemGuardrailsPromptS4 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS4: any;
export type ListResultItemGuardrailsPromptS5 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS5: any;
export type ListResultItemGuardrailsPromptS6 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS6: any;
export type ListResultItemGuardrailsPromptS7 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS7: any;
export type ListResultItemGuardrailsPromptS8 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS8: any;
export type ListResultItemGuardrailsPromptS9 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsPromptS9: any;
export interface ListResultItemGuardrailsPrompt {
    p1?: ListResultItemGuardrailsPromptP1 | null;
    s1?: ListResultItemGuardrailsPromptS1 | null;
    s10?: ListResultItemGuardrailsPromptS10 | null;
    s11?: ListResultItemGuardrailsPromptS11 | null;
    s12?: ListResultItemGuardrailsPromptS12 | null;
    s13?: ListResultItemGuardrailsPromptS13 | null;
    s2?: ListResultItemGuardrailsPromptS2 | null;
    s3?: ListResultItemGuardrailsPromptS3 | null;
    s4?: ListResultItemGuardrailsPromptS4 | null;
    s5?: ListResultItemGuardrailsPromptS5 | null;
    s6?: ListResultItemGuardrailsPromptS6 | null;
    s7?: ListResultItemGuardrailsPromptS7 | null;
    s8?: ListResultItemGuardrailsPromptS8 | null;
    s9?: ListResultItemGuardrailsPromptS9 | null;
}
export declare const ListResultItemGuardrailsPrompt: S.Schema<ListResultItemGuardrailsPrompt>;
export type ListResultItemGuardrailsResponseP1 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseP1: any;
export type ListResultItemGuardrailsResponseS1 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS1: any;
export type ListResultItemGuardrailsResponseS10 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS10: any;
export type ListResultItemGuardrailsResponseS11 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS11: any;
export type ListResultItemGuardrailsResponseS12 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS12: any;
export type ListResultItemGuardrailsResponseS13 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS13: any;
export type ListResultItemGuardrailsResponseS2 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS2: any;
export type ListResultItemGuardrailsResponseS3 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS3: any;
export type ListResultItemGuardrailsResponseS4 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS4: any;
export type ListResultItemGuardrailsResponseS5 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS5: any;
export type ListResultItemGuardrailsResponseS6 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS6: any;
export type ListResultItemGuardrailsResponseS7 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS7: any;
export type ListResultItemGuardrailsResponseS8 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS8: any;
export type ListResultItemGuardrailsResponseS9 = "FLAG" | "BLOCK";
export declare const ListResultItemGuardrailsResponseS9: any;
export interface ListResultItemGuardrailsResponse {
    p1?: ListResultItemGuardrailsResponseP1 | null;
    s1?: ListResultItemGuardrailsResponseS1 | null;
    s10?: ListResultItemGuardrailsResponseS10 | null;
    s11?: ListResultItemGuardrailsResponseS11 | null;
    s12?: ListResultItemGuardrailsResponseS12 | null;
    s13?: ListResultItemGuardrailsResponseS13 | null;
    s2?: ListResultItemGuardrailsResponseS2 | null;
    s3?: ListResultItemGuardrailsResponseS3 | null;
    s4?: ListResultItemGuardrailsResponseS4 | null;
    s5?: ListResultItemGuardrailsResponseS5 | null;
    s6?: ListResultItemGuardrailsResponseS6 | null;
    s7?: ListResultItemGuardrailsResponseS7 | null;
    s8?: ListResultItemGuardrailsResponseS8 | null;
    s9?: ListResultItemGuardrailsResponseS9 | null;
}
export declare const ListResultItemGuardrailsResponse: S.Schema<ListResultItemGuardrailsResponse>;
export interface ListResultItemGuardrails {
    prompt: ListResultItemGuardrailsPrompt;
    response: ListResultItemGuardrailsResponse;
}
export declare const ListResultItemGuardrails: S.Schema<ListResultItemGuardrails>;
export type ListResultItemLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const ListResultItemLogManagementStrategy: any;
export type ListResultItemOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const ListResultItemOtelItemHeadersMap: S.Schema<ListResultItemOtelItemHeadersMap>;
export type ListResultItemOtelItemContentType = "json" | "protobuf";
export declare const ListResultItemOtelItemContentType: any;
export interface ListResultItemOtelItem {
    headers: ListResultItemOtelItemHeadersMap;
    url: string;
    authorization?: string | null;
    contentType?: ListResultItemOtelItemContentType | null;
}
export declare const ListResultItemOtelItem: S.Schema<ListResultItemOtelItem>;
export type ListResultItemOtelList = Array<ListResultItemOtelItem>;
export declare const ListResultItemOtelList: S.Schema<ListResultItemOtelList>;
export type ListResultItemRateLimitingTechnique = "fixed" | "sliding";
export declare const ListResultItemRateLimitingTechnique: any;
export type ListResultItemRetryBackoff = "constant" | "linear" | "exponential";
export declare const ListResultItemRetryBackoff: any;
export type ListResultItemSpendLimitsRulesItemLimitType = "cost";
export declare const ListResultItemSpendLimitsRulesItemLimitType: any;
export type ListResultItemSpendLimitsRulesItemModelMode = "filter";
export declare const ListResultItemSpendLimitsRulesItemModelMode: any;
export type ListResultItemSpendLimitsRulesItemModelValuesList = Array<string>;
export declare const ListResultItemSpendLimitsRulesItemModelValuesList: S.Schema<ListResultItemSpendLimitsRulesItemModelValuesList>;
export interface ListResultItemSpendLimitsRulesItemModel {
    mode: ListResultItemSpendLimitsRulesItemModelMode;
    values: ListResultItemSpendLimitsRulesItemModelValuesList;
}
export declare const ListResultItemSpendLimitsRulesItemModel: S.Schema<ListResultItemSpendLimitsRulesItemModel>;
export type ListResultItemSpendLimitsRulesItemProviderMode = "filter";
export declare const ListResultItemSpendLimitsRulesItemProviderMode: any;
export type ListResultItemSpendLimitsRulesItemProviderValuesList = Array<string>;
export declare const ListResultItemSpendLimitsRulesItemProviderValuesList: S.Schema<ListResultItemSpendLimitsRulesItemProviderValuesList>;
export interface ListResultItemSpendLimitsRulesItemProvider {
    mode: ListResultItemSpendLimitsRulesItemProviderMode;
    values: ListResultItemSpendLimitsRulesItemProviderValuesList;
}
export declare const ListResultItemSpendLimitsRulesItemProvider: S.Schema<ListResultItemSpendLimitsRulesItemProvider>;
export type ListResultItemSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export declare const ListResultItemSpendLimitsRulesItemTechnique: any;
export interface ListResultItemSpendLimitsRulesItem {
    limit: number;
    limitType: ListResultItemSpendLimitsRulesItemLimitType;
    window: number;
    id?: string | null;
    enabled?: boolean | null;
    metadata?: UntypedMetadataMap | null;
    model?: ListResultItemSpendLimitsRulesItemModel | null;
    provider?: ListResultItemSpendLimitsRulesItemProvider | null;
    technique?: ListResultItemSpendLimitsRulesItemTechnique | null;
}
export declare const ListResultItemSpendLimitsRulesItem: S.Schema<ListResultItemSpendLimitsRulesItem>;
export type ListResultItemSpendLimitsRulesList = Array<ListResultItemSpendLimitsRulesItem>;
export declare const ListResultItemSpendLimitsRulesList: S.Schema<ListResultItemSpendLimitsRulesList>;
export interface ListResultItemSpendLimits {
    enabled?: boolean | null;
    rules?: ListResultItemSpendLimitsRulesList | null;
}
export declare const ListResultItemSpendLimits: S.Schema<ListResultItemSpendLimits>;
export type ListResultItemStripeUsageEventsItem = CreateResponseStripeUsageEventsItem;
export declare const ListResultItemStripeUsageEventsItem: S.Schema<CreateResponseStripeUsageEventsItem>;
export type ListResultItemStripeUsageEventsList = Array<CreateResponseStripeUsageEventsItem>;
export declare const ListResultItemStripeUsageEventsList: S.Schema<ListResultItemStripeUsageEventsList>;
export interface ListResultItemStripe {
    authorization: string;
    usageEvents: ListResultItemStripeUsageEventsList;
}
export declare const ListResultItemStripe: S.Schema<ListResultItemStripe>;
export type ListResultItemWorkersAiBillingMode = "postpaid";
export declare const ListResultItemWorkersAiBillingMode: any;
export interface ListResultItem {
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    authentication?: boolean | null;
    dlp?: ListResultItemDlp | null;
    guardrails?: ListResultItemGuardrails | null;
    isDefault?: boolean | null;
    logManagement?: number | null;
    logManagementStrategy?: ListResultItemLogManagementStrategy | null;
    logpush?: boolean | null;
    logpushPublicKey?: string | null;
    otel?: ListResultItemOtelList | null;
    rateLimitingTechnique?: ListResultItemRateLimitingTechnique | null;
    /** Backoff strategy for retry delays */
    retryBackoff?: ListResultItemRetryBackoff | null;
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number | null;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null;
    spendLimits?: ListResultItemSpendLimits | null;
    storeId?: string | null;
    stripe?: ListResultItemStripe | null;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: ListResultItemWorkersAiBillingMode | null;
    zdr?: boolean | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListAiGatewaysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAiGatewaysResponse: S.Schema<ListAiGatewaysResponse>;
export interface ListCustomProvidersRequest {
    accountId: string;
    beta?: boolean;
    enable?: boolean;
    page?: number;
    perPage?: number;
    /** Search by id, name, slug */
    search?: string;
}
export declare const ListCustomProvidersRequest: S.Schema<ListCustomProvidersRequest>;
export interface CustomProvidersListResultItem {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null;
    curlExample?: string | null;
    description?: string | null;
    enable?: boolean | null;
    headers?: string | null;
    jsExample?: string | null;
    link?: string | null;
    logo?: string | null;
    position?: number | null;
}
export declare const CustomProvidersListResultItem: S.Schema<CustomProvidersListResultItem>;
export type CustomProvidersListResultList = Array<CustomProvidersListResultItem>;
export declare const CustomProvidersListResultList: S.Schema<CustomProvidersListResultList>;
export interface ListCustomProvidersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CustomProvidersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCustomProvidersResponse: S.Schema<ListCustomProvidersResponse>;
export interface ListDatasetsRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    enable?: boolean;
    name?: string;
    page?: number;
    perPage?: number;
    /** Search by id, name, filters */
    search?: string;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export type DatasetsListResultItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsListResultItemFiltersItemKey: any;
export type DatasetsListResultItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsListResultItemFiltersItemOperator: any;
export type DatasetsListResultItemFiltersItemValueItem = string | number | boolean;
export declare const DatasetsListResultItemFiltersItemValueItem: any;
export type DatasetsListResultItemFiltersItemValueList = Array<DatasetsListResultItemFiltersItemValueItem>;
export declare const DatasetsListResultItemFiltersItemValueList: S.Schema<DatasetsListResultItemFiltersItemValueList>;
export interface DatasetsListResultItemFiltersItem {
    key: DatasetsListResultItemFiltersItemKey;
    operator: DatasetsListResultItemFiltersItemOperator;
    value: DatasetsListResultItemFiltersItemValueList;
}
export declare const DatasetsListResultItemFiltersItem: S.Schema<DatasetsListResultItemFiltersItem>;
export type DatasetsListResultItemFiltersList = Array<DatasetsListResultItemFiltersItem>;
export declare const DatasetsListResultItemFiltersList: S.Schema<DatasetsListResultItemFiltersList>;
export interface DatasetsListResultItem {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsListResultItemFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const DatasetsListResultItem: S.Schema<DatasetsListResultItem>;
export type DatasetsListResultList = Array<DatasetsListResultItem>;
export declare const DatasetsListResultList: S.Schema<DatasetsListResultList>;
export interface ListDatasetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatasetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface ListDeploymentsDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export declare const ListDeploymentsDynamicRoutingRequest: S.Schema<ListDeploymentsDynamicRoutingRequest>;
export type DynamicRoutingListDeploymentsResponseDataDeploymentsItem = DynamicRoutingCreateResponseDeployment;
export declare const DynamicRoutingListDeploymentsResponseDataDeploymentsItem: S.Schema<DynamicRoutingCreateResponseDeployment>;
export type DynamicRoutingListDeploymentsResponseDataDeploymentsList = Array<DynamicRoutingCreateResponseDeployment>;
export declare const DynamicRoutingListDeploymentsResponseDataDeploymentsList: S.Schema<DynamicRoutingListDeploymentsResponseDataDeploymentsList>;
export interface DynamicRoutingListDeploymentsResponseData {
    deployments: DynamicRoutingListDeploymentsResponseDataDeploymentsList;
    orderBy: string;
    orderByDirection: string;
    page: number;
    perPage: number;
}
export declare const DynamicRoutingListDeploymentsResponseData: S.Schema<DynamicRoutingListDeploymentsResponseData>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDeploymentsDynamicRoutingResponse {
    data: DynamicRoutingListDeploymentsResponseData;
}
export declare const ListDeploymentsDynamicRoutingResponse: S.Schema<ListDeploymentsDynamicRoutingResponse>;
export interface ListDynamicRoutingsRequest {
    accountId: string;
    gatewayId: string;
    /** Page number */
    page?: number;
    /** Number of routes per page */
    perPage?: number;
}
export declare const ListDynamicRoutingsRequest: S.Schema<ListDynamicRoutingsRequest>;
export type DynamicRoutingListResponseDataRoutesItemDeployment = DynamicRoutingCreateResponseDeployment;
export declare const DynamicRoutingListResponseDataRoutesItemDeployment: S.Schema<DynamicRoutingCreateResponseDeployment>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase0Type = "start";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase0Type: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase0Type;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase0: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase0>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1Type = "conditional";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase1Type: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase1Type;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase1: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase1>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase2OutputsMap: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase2OutputsMap>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase2Type = "percentage";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase2Type: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingListResponseDataRoutesItemElementsItemCase2OutputsMap;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase2Type;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase2: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase2>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingListResponseDataRoutesItemElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3Properties: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase3Properties>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3Type = "rate";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3Type: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingListResponseDataRoutesItemElementsItemCase3Properties;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase3Type;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase3: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase3>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4Type = "model";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase4Type: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase4Type;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase4: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase4>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase5OutputsMap: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase5OutputsMap>;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase5Type = "end";
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase5Type: any;
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingListResponseDataRoutesItemElementsItemCase5OutputsMap;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase5Type;
}
export declare const DynamicRoutingListResponseDataRoutesItemElementsItemCase5: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsItemCase5>;
export type DynamicRoutingListResponseDataRoutesItemElementsItem = DynamicRoutingListResponseDataRoutesItemElementsItemCase0 | DynamicRoutingListResponseDataRoutesItemElementsItemCase1 | DynamicRoutingListResponseDataRoutesItemElementsItemCase2 | DynamicRoutingListResponseDataRoutesItemElementsItemCase3 | DynamicRoutingListResponseDataRoutesItemElementsItemCase4 | DynamicRoutingListResponseDataRoutesItemElementsItemCase5;
export declare const DynamicRoutingListResponseDataRoutesItemElementsItem: any;
export type DynamicRoutingListResponseDataRoutesItemElementsList = Array<DynamicRoutingListResponseDataRoutesItemElementsItem>;
export declare const DynamicRoutingListResponseDataRoutesItemElementsList: S.Schema<DynamicRoutingListResponseDataRoutesItemElementsList>;
export type DynamicRoutingListResponseDataRoutesItemVersionActive = "true" | "false";
export declare const DynamicRoutingListResponseDataRoutesItemVersionActive: any;
export interface DynamicRoutingListResponseDataRoutesItemVersion {
    active: DynamicRoutingListResponseDataRoutesItemVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null;
}
export declare const DynamicRoutingListResponseDataRoutesItemVersion: S.Schema<DynamicRoutingListResponseDataRoutesItemVersion>;
export interface DynamicRoutingListResponseDataRoutesItem {
    id: string;
    accountTag: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingListResponseDataRoutesItemElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingListResponseDataRoutesItemVersion;
}
export declare const DynamicRoutingListResponseDataRoutesItem: S.Schema<DynamicRoutingListResponseDataRoutesItem>;
export type DynamicRoutingListResponseDataRoutesList = Array<DynamicRoutingListResponseDataRoutesItem>;
export declare const DynamicRoutingListResponseDataRoutesList: S.Schema<DynamicRoutingListResponseDataRoutesList>;
export interface DynamicRoutingListResponseData {
    orderBy: string;
    orderByDirection: string;
    page: number;
    perPage: number;
    routes: DynamicRoutingListResponseDataRoutesList;
}
export declare const DynamicRoutingListResponseData: S.Schema<DynamicRoutingListResponseData>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDynamicRoutingsResponse {
    data: DynamicRoutingListResponseData;
}
export declare const ListDynamicRoutingsResponse: S.Schema<ListDynamicRoutingsResponse>;
export interface ListEvaluationsRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    name?: string;
    page?: number;
    perPage?: number;
    processed?: boolean;
    /** Search by id, name */
    search?: string;
}
export declare const ListEvaluationsRequest: S.Schema<ListEvaluationsRequest>;
export type EvaluationsListResultItemDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const EvaluationsListResultItemDatasetsItemFiltersItemKey: any;
export type EvaluationsListResultItemDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const EvaluationsListResultItemDatasetsItemFiltersItemOperator: any;
export type EvaluationsListResultItemDatasetsItemFiltersItemValueItem = string | number | boolean;
export declare const EvaluationsListResultItemDatasetsItemFiltersItemValueItem: any;
export type EvaluationsListResultItemDatasetsItemFiltersItemValueList = Array<EvaluationsListResultItemDatasetsItemFiltersItemValueItem>;
export declare const EvaluationsListResultItemDatasetsItemFiltersItemValueList: S.Schema<EvaluationsListResultItemDatasetsItemFiltersItemValueList>;
export interface EvaluationsListResultItemDatasetsItemFiltersItem {
    key: EvaluationsListResultItemDatasetsItemFiltersItemKey;
    operator: EvaluationsListResultItemDatasetsItemFiltersItemOperator;
    value: EvaluationsListResultItemDatasetsItemFiltersItemValueList;
}
export declare const EvaluationsListResultItemDatasetsItemFiltersItem: S.Schema<EvaluationsListResultItemDatasetsItemFiltersItem>;
export type EvaluationsListResultItemDatasetsItemFiltersList = Array<EvaluationsListResultItemDatasetsItemFiltersItem>;
export declare const EvaluationsListResultItemDatasetsItemFiltersList: S.Schema<EvaluationsListResultItemDatasetsItemFiltersList>;
export interface EvaluationsListResultItemDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsListResultItemDatasetsItemFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const EvaluationsListResultItemDatasetsItem: S.Schema<EvaluationsListResultItemDatasetsItem>;
export type EvaluationsListResultItemDatasetsList = Array<EvaluationsListResultItemDatasetsItem>;
export declare const EvaluationsListResultItemDatasetsList: S.Schema<EvaluationsListResultItemDatasetsList>;
export type EvaluationsListResultItemResultsItem = EvaluationsCreateResponseResultsItem;
export declare const EvaluationsListResultItemResultsItem: S.Schema<EvaluationsCreateResponseResultsItem>;
export type EvaluationsListResultItemResultsList = Array<EvaluationsCreateResponseResultsItem>;
export declare const EvaluationsListResultItemResultsList: S.Schema<EvaluationsListResultItemResultsList>;
export interface EvaluationsListResultItem {
    id: string;
    createdAt: string;
    datasets: EvaluationsListResultItemDatasetsList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsListResultItemResultsList;
    totalLogs: number;
}
export declare const EvaluationsListResultItem: S.Schema<EvaluationsListResultItem>;
export type EvaluationsListResultList = Array<EvaluationsListResultItem>;
export declare const EvaluationsListResultList: S.Schema<EvaluationsListResultList>;
export interface ListEvaluationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EvaluationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListEvaluationsResponse: S.Schema<ListEvaluationsResponse>;
export type EvaluationTypesListRequestOrderByDirection = "asc" | "desc";
export declare const EvaluationTypesListRequestOrderByDirection: any;
export interface ListEvaluationTypesRequest {
    accountId: string;
    orderBy?: string;
    orderByDirection?: EvaluationTypesListRequestOrderByDirection | (string & {});
    page?: number;
    perPage?: number;
}
export declare const ListEvaluationTypesRequest: S.Schema<ListEvaluationTypesRequest>;
export interface EvaluationTypesListResultItem {
    id: string;
    createdAt: string;
    description: string;
    enable: boolean;
    mandatory: boolean;
    modifiedAt: string;
    name: string;
    type: string;
}
export declare const EvaluationTypesListResultItem: S.Schema<EvaluationTypesListResultItem>;
export type EvaluationTypesListResultList = Array<EvaluationTypesListResultItem>;
export declare const EvaluationTypesListResultList: S.Schema<EvaluationTypesListResultList>;
export interface ListEvaluationTypesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EvaluationTypesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListEvaluationTypesResponse: S.Schema<ListEvaluationTypesResponse>;
export type LogsListRequestDirection = "asc" | "desc";
export declare const LogsListRequestDirection: any;
export type LogsListRequestFiltersList = Array<string>;
export declare const LogsListRequestFiltersList: S.Schema<LogsListRequestFiltersList>;
export type LogsListRequestOrderBy = "created_at" | "provider" | "model" | "model_type" | "success" | "cached";
export declare const LogsListRequestOrderBy: any;
export type LogsListRequestOrderByDirection = "asc" | "desc";
export declare const LogsListRequestOrderByDirection: any;
export interface ListLogsRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    cached?: boolean;
    direction?: LogsListRequestDirection | (string & {});
    endDate?: string;
    feedback?: string;
    filters?: LogsListRequestFiltersList;
    maxCost?: number;
    maxDuration?: number;
    maxTokensIn?: number;
    maxTokensOut?: number;
    maxTotalTokens?: number;
    metaInfo?: boolean;
    minCost?: number;
    minDuration?: number;
    minTokensIn?: number;
    minTokensOut?: number;
    minTotalTokens?: number;
    model?: string;
    modelType?: string;
    orderBy?: LogsListRequestOrderBy | (string & {});
    orderByDirection?: LogsListRequestOrderByDirection | (string & {});
    page?: number;
    perPage?: number;
    provider?: string;
    requestContentType?: string;
    responseContentType?: string;
    search?: string;
    startDate?: string;
    success?: boolean;
}
export declare const ListLogsRequest: S.Schema<ListLogsRequest>;
export interface LogsListResultItem {
    id: string;
    cached: boolean;
    createdAt: string;
    duration: number;
    model: string;
    path: string;
    provider: string;
    success: boolean;
    tokensIn: number;
    tokensOut: number;
    cost?: number | null;
    customCost?: boolean | null;
    metadata?: string | null;
    modelType?: string | null;
    requestContentType?: string | null;
    requestType?: string | null;
    responseContentType?: string | null;
    statusCode?: number | null;
    step?: number | null;
}
export declare const LogsListResultItem: S.Schema<LogsListResultItem>;
export type LogsListResultList = Array<LogsListResultItem>;
export declare const LogsListResultList: S.Schema<LogsListResultList>;
export interface ListLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLogsResponse: S.Schema<ListLogsResponse>;
export interface ListProviderConfigsRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    page?: number;
    perPage?: number;
}
export declare const ListProviderConfigsRequest: S.Schema<ListProviderConfigsRequest>;
export interface ProviderConfigsListResultItem {
    id: string;
    alias: string;
    defaultConfig: boolean;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    providerSlug: string;
    secretId: string;
    secretPreview: string;
    rateLimit?: number | null;
    rateLimitPeriod?: number | null;
}
export declare const ProviderConfigsListResultItem: S.Schema<ProviderConfigsListResultItem>;
export type ProviderConfigsListResultList = Array<ProviderConfigsListResultItem>;
export declare const ProviderConfigsListResultList: S.Schema<ProviderConfigsListResultList>;
export interface ListProviderConfigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProviderConfigsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListProviderConfigsResponse: S.Schema<ListProviderConfigsResponse>;
export interface ListVersionsDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export declare const ListVersionsDynamicRoutingRequest: S.Schema<ListVersionsDynamicRoutingRequest>;
export type DynamicRoutingListVersionsResponseDataVersionsItemActive = "true" | "false";
export declare const DynamicRoutingListVersionsResponseDataVersionsItemActive: any;
export interface DynamicRoutingListVersionsResponseDataVersionsItem {
    active: DynamicRoutingListVersionsResponseDataVersionsItemActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null;
}
export declare const DynamicRoutingListVersionsResponseDataVersionsItem: S.Schema<DynamicRoutingListVersionsResponseDataVersionsItem>;
export type DynamicRoutingListVersionsResponseDataVersionsList = Array<DynamicRoutingListVersionsResponseDataVersionsItem>;
export declare const DynamicRoutingListVersionsResponseDataVersionsList: S.Schema<DynamicRoutingListVersionsResponseDataVersionsList>;
export interface DynamicRoutingListVersionsResponseData {
    orderBy: string;
    orderByDirection: string;
    page: number;
    perPage: number;
    versions: DynamicRoutingListVersionsResponseDataVersionsList;
}
export declare const DynamicRoutingListVersionsResponseData: S.Schema<DynamicRoutingListVersionsResponseData>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListVersionsDynamicRoutingResponse {
    data: DynamicRoutingListVersionsResponseData;
}
export declare const ListVersionsDynamicRoutingResponse: S.Schema<ListVersionsDynamicRoutingResponse>;
export interface PatchDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    name: string;
}
export declare const PatchDynamicRoutingRequest: S.Schema<PatchDynamicRoutingRequest>;
export type DynamicRoutingUpdateResponseRouteDeployment = DynamicRoutingCreateResponseDeployment;
export declare const DynamicRoutingUpdateResponseRouteDeployment: S.Schema<DynamicRoutingCreateResponseDeployment>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase0OutputsNext: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase0Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase0Type = "start";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase0Type: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase0Type;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase0: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase0>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase1OutputsFalse: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase1OutputsTrue: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase1Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase1Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1Type = "conditional";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase1Type: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase1Type;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase1: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase1>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase2OutputsMap: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase2OutputsMap>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase2Type = "percentage";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase2Type: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingUpdateResponseRouteElementsItemCase2OutputsMap;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase2Type;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase2: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase2>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3PropertiesLimitType = "count" | "cost";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3PropertiesLimitType: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingUpdateResponseRouteElementsItemCase3PropertiesLimitType;
    window: number;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3Properties: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase3Properties>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3Type = "rate";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3Type: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingUpdateResponseRouteElementsItemCase3Properties;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase3Type;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase3: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase3>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase4OutputsFallback: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase4OutputsSuccess: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase4Outputs: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase4Properties: S.Schema<DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4Type = "model";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase4Type: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase4Type;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase4: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase4>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase5OutputsMap: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase5OutputsMap>;
export type DynamicRoutingUpdateResponseRouteElementsItemCase5Type = "end";
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase5Type: any;
export interface DynamicRoutingUpdateResponseRouteElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingUpdateResponseRouteElementsItemCase5OutputsMap;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase5Type;
}
export declare const DynamicRoutingUpdateResponseRouteElementsItemCase5: S.Schema<DynamicRoutingUpdateResponseRouteElementsItemCase5>;
export type DynamicRoutingUpdateResponseRouteElementsItem = DynamicRoutingUpdateResponseRouteElementsItemCase0 | DynamicRoutingUpdateResponseRouteElementsItemCase1 | DynamicRoutingUpdateResponseRouteElementsItemCase2 | DynamicRoutingUpdateResponseRouteElementsItemCase3 | DynamicRoutingUpdateResponseRouteElementsItemCase4 | DynamicRoutingUpdateResponseRouteElementsItemCase5;
export declare const DynamicRoutingUpdateResponseRouteElementsItem: any;
export type DynamicRoutingUpdateResponseRouteElementsList = Array<DynamicRoutingUpdateResponseRouteElementsItem>;
export declare const DynamicRoutingUpdateResponseRouteElementsList: S.Schema<DynamicRoutingUpdateResponseRouteElementsList>;
export type DynamicRoutingUpdateResponseRouteVersionActive = "true" | "false";
export declare const DynamicRoutingUpdateResponseRouteVersionActive: any;
export interface DynamicRoutingUpdateResponseRouteVersion {
    active: DynamicRoutingUpdateResponseRouteVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null;
}
export declare const DynamicRoutingUpdateResponseRouteVersion: S.Schema<DynamicRoutingUpdateResponseRouteVersion>;
export interface DynamicRoutingUpdateResponseRoute {
    id: string;
    accountTag: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingUpdateResponseRouteElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingUpdateResponseRouteVersion;
}
export declare const DynamicRoutingUpdateResponseRoute: S.Schema<DynamicRoutingUpdateResponseRoute>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchDynamicRoutingResponse {
    route: DynamicRoutingUpdateResponseRoute;
}
export declare const PatchDynamicRoutingResponse: S.Schema<PatchDynamicRoutingResponse>;
export type LogsEditRequestMetadata = string | number | boolean;
export declare const LogsEditRequestMetadata: any;
export interface PatchLogRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
    feedback?: number;
    metadata?: LogsEditRequestMetadata;
    score?: number;
}
export declare const PatchLogRequest: S.Schema<PatchLogRequest>;
export type PatchLogResponse = unknown;
export declare const PatchLogResponse: S.Schema<PatchLogResponse>;
export interface RequestLogRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const RequestLogRequest: S.Schema<RequestLogRequest>;
export interface RequestLogResponse {
}
export declare const RequestLogResponse: S.Schema<RequestLogResponse>;
export interface ResponseLogRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
}
export declare const ResponseLogRequest: S.Schema<ResponseLogRequest>;
export interface ResponseLogResponse {
}
export declare const ResponseLogResponse: S.Schema<ResponseLogResponse>;
export interface StatusBillingTopupRequest {
    accountId: string;
    /** Stripe invoice ID to check status for. */
    paymentIntentId: string;
}
export declare const StatusBillingTopupRequest: S.Schema<StatusBillingTopupRequest>;
export type BillingTopupStatusResponseStatus = "completed" | "pending";
export declare const BillingTopupStatusResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatusBillingTopupResponse {
    paymentIntentId: string;
    status: BillingTopupStatusResponseStatus;
}
export declare const StatusBillingTopupResponse: S.Schema<StatusBillingTopupResponse>;
export type UpdateRequestDlpCase0Action = "BLOCK" | "FLAG";
export declare const UpdateRequestDlpCase0Action: any;
export type UpdateRequestDlpCase0ProfilesList = Array<string>;
export declare const UpdateRequestDlpCase0ProfilesList: S.Schema<UpdateRequestDlpCase0ProfilesList>;
export interface UpdateRequestDlpCase0 {
    action: UpdateRequestDlpCase0Action | (string & {});
    enabled: boolean;
    profiles: UpdateRequestDlpCase0ProfilesList;
}
export declare const UpdateRequestDlpCase0: S.Schema<UpdateRequestDlpCase0>;
export type UpdateRequestDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export declare const UpdateRequestDlpCase1PoliciesItemAction: any;
export type UpdateRequestDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export declare const UpdateRequestDlpCase1PoliciesItemCheckItem: any;
export type UpdateRequestDlpCase1PoliciesItemCheckList = Array<UpdateRequestDlpCase1PoliciesItemCheckItem | (string & {})>;
export declare const UpdateRequestDlpCase1PoliciesItemCheckList: S.Schema<UpdateRequestDlpCase1PoliciesItemCheckList>;
export type UpdateRequestDlpCase1PoliciesItemProfilesList = Array<string>;
export declare const UpdateRequestDlpCase1PoliciesItemProfilesList: S.Schema<UpdateRequestDlpCase1PoliciesItemProfilesList>;
export interface UpdateRequestDlpCase1PoliciesItem {
    id: string;
    action: UpdateRequestDlpCase1PoliciesItemAction | (string & {});
    check: UpdateRequestDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: UpdateRequestDlpCase1PoliciesItemProfilesList;
}
export declare const UpdateRequestDlpCase1PoliciesItem: S.Schema<UpdateRequestDlpCase1PoliciesItem>;
export type UpdateRequestDlpCase1PoliciesList = Array<UpdateRequestDlpCase1PoliciesItem>;
export declare const UpdateRequestDlpCase1PoliciesList: S.Schema<UpdateRequestDlpCase1PoliciesList>;
export interface UpdateRequestDlpCase1 {
    enabled: boolean;
    policies: UpdateRequestDlpCase1PoliciesList;
}
export declare const UpdateRequestDlpCase1: S.Schema<UpdateRequestDlpCase1>;
export type UpdateRequestDlp = UpdateRequestDlpCase0 | UpdateRequestDlpCase1;
export declare const UpdateRequestDlp: any;
export type UpdateRequestGuardrailsPromptP1 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptP1: any;
export type UpdateRequestGuardrailsPromptS1 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS1: any;
export type UpdateRequestGuardrailsPromptS10 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS10: any;
export type UpdateRequestGuardrailsPromptS11 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS11: any;
export type UpdateRequestGuardrailsPromptS12 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS12: any;
export type UpdateRequestGuardrailsPromptS13 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS13: any;
export type UpdateRequestGuardrailsPromptS2 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS2: any;
export type UpdateRequestGuardrailsPromptS3 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS3: any;
export type UpdateRequestGuardrailsPromptS4 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS4: any;
export type UpdateRequestGuardrailsPromptS5 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS5: any;
export type UpdateRequestGuardrailsPromptS6 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS6: any;
export type UpdateRequestGuardrailsPromptS7 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS7: any;
export type UpdateRequestGuardrailsPromptS8 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS8: any;
export type UpdateRequestGuardrailsPromptS9 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsPromptS9: any;
export interface UpdateRequestGuardrailsPrompt {
    p1?: UpdateRequestGuardrailsPromptP1 | (string & {});
    s1?: UpdateRequestGuardrailsPromptS1 | (string & {});
    s10?: UpdateRequestGuardrailsPromptS10 | (string & {});
    s11?: UpdateRequestGuardrailsPromptS11 | (string & {});
    s12?: UpdateRequestGuardrailsPromptS12 | (string & {});
    s13?: UpdateRequestGuardrailsPromptS13 | (string & {});
    s2?: UpdateRequestGuardrailsPromptS2 | (string & {});
    s3?: UpdateRequestGuardrailsPromptS3 | (string & {});
    s4?: UpdateRequestGuardrailsPromptS4 | (string & {});
    s5?: UpdateRequestGuardrailsPromptS5 | (string & {});
    s6?: UpdateRequestGuardrailsPromptS6 | (string & {});
    s7?: UpdateRequestGuardrailsPromptS7 | (string & {});
    s8?: UpdateRequestGuardrailsPromptS8 | (string & {});
    s9?: UpdateRequestGuardrailsPromptS9 | (string & {});
}
export declare const UpdateRequestGuardrailsPrompt: S.Schema<UpdateRequestGuardrailsPrompt>;
export type UpdateRequestGuardrailsResponseP1 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseP1: any;
export type UpdateRequestGuardrailsResponseS1 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS1: any;
export type UpdateRequestGuardrailsResponseS10 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS10: any;
export type UpdateRequestGuardrailsResponseS11 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS11: any;
export type UpdateRequestGuardrailsResponseS12 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS12: any;
export type UpdateRequestGuardrailsResponseS13 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS13: any;
export type UpdateRequestGuardrailsResponseS2 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS2: any;
export type UpdateRequestGuardrailsResponseS3 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS3: any;
export type UpdateRequestGuardrailsResponseS4 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS4: any;
export type UpdateRequestGuardrailsResponseS5 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS5: any;
export type UpdateRequestGuardrailsResponseS6 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS6: any;
export type UpdateRequestGuardrailsResponseS7 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS7: any;
export type UpdateRequestGuardrailsResponseS8 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS8: any;
export type UpdateRequestGuardrailsResponseS9 = "FLAG" | "BLOCK";
export declare const UpdateRequestGuardrailsResponseS9: any;
export interface UpdateRequestGuardrailsResponse {
    p1?: UpdateRequestGuardrailsResponseP1 | (string & {});
    s1?: UpdateRequestGuardrailsResponseS1 | (string & {});
    s10?: UpdateRequestGuardrailsResponseS10 | (string & {});
    s11?: UpdateRequestGuardrailsResponseS11 | (string & {});
    s12?: UpdateRequestGuardrailsResponseS12 | (string & {});
    s13?: UpdateRequestGuardrailsResponseS13 | (string & {});
    s2?: UpdateRequestGuardrailsResponseS2 | (string & {});
    s3?: UpdateRequestGuardrailsResponseS3 | (string & {});
    s4?: UpdateRequestGuardrailsResponseS4 | (string & {});
    s5?: UpdateRequestGuardrailsResponseS5 | (string & {});
    s6?: UpdateRequestGuardrailsResponseS6 | (string & {});
    s7?: UpdateRequestGuardrailsResponseS7 | (string & {});
    s8?: UpdateRequestGuardrailsResponseS8 | (string & {});
    s9?: UpdateRequestGuardrailsResponseS9 | (string & {});
}
export declare const UpdateRequestGuardrailsResponse: S.Schema<UpdateRequestGuardrailsResponse>;
export interface UpdateRequestGuardrails {
    prompt: UpdateRequestGuardrailsPrompt;
    response: UpdateRequestGuardrailsResponse;
}
export declare const UpdateRequestGuardrails: S.Schema<UpdateRequestGuardrails>;
export type UpdateRequestLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const UpdateRequestLogManagementStrategy: any;
export type UpdateRequestOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateRequestOtelItemHeadersMap: S.Schema<UpdateRequestOtelItemHeadersMap>;
export type UpdateRequestOtelItemContentType = "json" | "protobuf";
export declare const UpdateRequestOtelItemContentType: any;
export interface UpdateRequestOtelItem {
    headers: UpdateRequestOtelItemHeadersMap;
    url: string;
    authorization?: string;
    contentType?: UpdateRequestOtelItemContentType | (string & {});
}
export declare const UpdateRequestOtelItem: S.Schema<UpdateRequestOtelItem>;
export type UpdateRequestOtelList = Array<UpdateRequestOtelItem>;
export declare const UpdateRequestOtelList: S.Schema<UpdateRequestOtelList>;
export type UpdateRequestRateLimitingTechnique = "fixed" | "sliding";
export declare const UpdateRequestRateLimitingTechnique: any;
export type UpdateRequestRetryBackoff = "constant" | "linear" | "exponential";
export declare const UpdateRequestRetryBackoff: any;
export type UpdateRequestSpendLimitsRulesItemLimitType = "cost";
export declare const UpdateRequestSpendLimitsRulesItemLimitType: any;
export type UpdateRequestSpendLimitsRulesItemModelMode = "filter";
export declare const UpdateRequestSpendLimitsRulesItemModelMode: any;
export type UpdateRequestSpendLimitsRulesItemModelValuesList = Array<string>;
export declare const UpdateRequestSpendLimitsRulesItemModelValuesList: S.Schema<UpdateRequestSpendLimitsRulesItemModelValuesList>;
export interface UpdateRequestSpendLimitsRulesItemModel {
    mode: UpdateRequestSpendLimitsRulesItemModelMode | (string & {});
    values: UpdateRequestSpendLimitsRulesItemModelValuesList;
}
export declare const UpdateRequestSpendLimitsRulesItemModel: S.Schema<UpdateRequestSpendLimitsRulesItemModel>;
export type UpdateRequestSpendLimitsRulesItemProviderMode = "filter";
export declare const UpdateRequestSpendLimitsRulesItemProviderMode: any;
export type UpdateRequestSpendLimitsRulesItemProviderValuesList = Array<string>;
export declare const UpdateRequestSpendLimitsRulesItemProviderValuesList: S.Schema<UpdateRequestSpendLimitsRulesItemProviderValuesList>;
export interface UpdateRequestSpendLimitsRulesItemProvider {
    mode: UpdateRequestSpendLimitsRulesItemProviderMode | (string & {});
    values: UpdateRequestSpendLimitsRulesItemProviderValuesList;
}
export declare const UpdateRequestSpendLimitsRulesItemProvider: S.Schema<UpdateRequestSpendLimitsRulesItemProvider>;
export type UpdateRequestSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export declare const UpdateRequestSpendLimitsRulesItemTechnique: any;
export interface UpdateRequestSpendLimitsRulesItem {
    limit: number;
    limitType: UpdateRequestSpendLimitsRulesItemLimitType | (string & {});
    window: number;
    id?: string;
    enabled?: boolean;
    metadata?: UntypedMetadataMap;
    model?: UpdateRequestSpendLimitsRulesItemModel;
    provider?: UpdateRequestSpendLimitsRulesItemProvider;
    technique?: UpdateRequestSpendLimitsRulesItemTechnique | (string & {});
}
export declare const UpdateRequestSpendLimitsRulesItem: S.Schema<UpdateRequestSpendLimitsRulesItem>;
export type UpdateRequestSpendLimitsRulesList = Array<UpdateRequestSpendLimitsRulesItem>;
export declare const UpdateRequestSpendLimitsRulesList: S.Schema<UpdateRequestSpendLimitsRulesList>;
export interface UpdateRequestSpendLimits {
    enabled?: boolean;
    rules?: UpdateRequestSpendLimitsRulesList;
}
export declare const UpdateRequestSpendLimits: S.Schema<UpdateRequestSpendLimits>;
export type UpdateRequestStripeUsageEventsItem = CreateResponseStripeUsageEventsItem;
export declare const UpdateRequestStripeUsageEventsItem: S.Schema<CreateResponseStripeUsageEventsItem>;
export type UpdateRequestStripeUsageEventsList = Array<CreateResponseStripeUsageEventsItem>;
export declare const UpdateRequestStripeUsageEventsList: S.Schema<UpdateRequestStripeUsageEventsList>;
export interface UpdateRequestStripe {
    authorization: string;
    usageEvents: UpdateRequestStripeUsageEventsList;
}
export declare const UpdateRequestStripe: S.Schema<UpdateRequestStripe>;
export type UpdateRequestWorkersAiBillingMode = "postpaid";
export declare const UpdateRequestWorkersAiBillingMode: any;
export interface UpdateAiGatewayRequest {
    accountId: string;
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number | null;
    collectLogs: boolean;
    rateLimitingInterval: number | null;
    rateLimitingLimit: number | null;
    authentication?: boolean;
    dlp?: UpdateRequestDlp;
    guardrails?: UpdateRequestGuardrails;
    logManagement?: number;
    logManagementStrategy?: UpdateRequestLogManagementStrategy | (string & {});
    logpush?: boolean;
    logpushPublicKey?: string;
    otel?: UpdateRequestOtelList;
    rateLimitingTechnique?: UpdateRequestRateLimitingTechnique | (string & {});
    /** Backoff strategy for retry delays */
    retryBackoff?: UpdateRequestRetryBackoff | (string & {});
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number;
    spendLimits?: UpdateRequestSpendLimits;
    storeId?: string;
    stripe?: UpdateRequestStripe;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: UpdateRequestWorkersAiBillingMode | (string & {});
    zdr?: boolean;
}
export declare const UpdateAiGatewayRequest: S.Schema<UpdateAiGatewayRequest>;
export type UpdateResponseDlpCase0Action = "BLOCK" | "FLAG";
export declare const UpdateResponseDlpCase0Action: any;
export type UpdateResponseDlpCase0ProfilesList = Array<string>;
export declare const UpdateResponseDlpCase0ProfilesList: S.Schema<UpdateResponseDlpCase0ProfilesList>;
export interface UpdateResponseDlpCase0 {
    action: UpdateResponseDlpCase0Action;
    enabled: boolean;
    profiles: UpdateResponseDlpCase0ProfilesList;
}
export declare const UpdateResponseDlpCase0: S.Schema<UpdateResponseDlpCase0>;
export type UpdateResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export declare const UpdateResponseDlpCase1PoliciesItemAction: any;
export type UpdateResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export declare const UpdateResponseDlpCase1PoliciesItemCheckItem: any;
export type UpdateResponseDlpCase1PoliciesItemCheckList = Array<UpdateResponseDlpCase1PoliciesItemCheckItem>;
export declare const UpdateResponseDlpCase1PoliciesItemCheckList: S.Schema<UpdateResponseDlpCase1PoliciesItemCheckList>;
export type UpdateResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export declare const UpdateResponseDlpCase1PoliciesItemProfilesList: S.Schema<UpdateResponseDlpCase1PoliciesItemProfilesList>;
export interface UpdateResponseDlpCase1PoliciesItem {
    id: string;
    action: UpdateResponseDlpCase1PoliciesItemAction;
    check: UpdateResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: UpdateResponseDlpCase1PoliciesItemProfilesList;
}
export declare const UpdateResponseDlpCase1PoliciesItem: S.Schema<UpdateResponseDlpCase1PoliciesItem>;
export type UpdateResponseDlpCase1PoliciesList = Array<UpdateResponseDlpCase1PoliciesItem>;
export declare const UpdateResponseDlpCase1PoliciesList: S.Schema<UpdateResponseDlpCase1PoliciesList>;
export interface UpdateResponseDlpCase1 {
    enabled: boolean;
    policies: UpdateResponseDlpCase1PoliciesList;
}
export declare const UpdateResponseDlpCase1: S.Schema<UpdateResponseDlpCase1>;
export type UpdateResponseDlp = UpdateResponseDlpCase0 | UpdateResponseDlpCase1;
export declare const UpdateResponseDlp: any;
export type UpdateResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptP1: any;
export type UpdateResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS1: any;
export type UpdateResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS10: any;
export type UpdateResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS11: any;
export type UpdateResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS12: any;
export type UpdateResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS13: any;
export type UpdateResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS2: any;
export type UpdateResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS3: any;
export type UpdateResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS4: any;
export type UpdateResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS5: any;
export type UpdateResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS6: any;
export type UpdateResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS7: any;
export type UpdateResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS8: any;
export type UpdateResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsPromptS9: any;
export interface UpdateResponseGuardrailsPrompt {
    p1?: UpdateResponseGuardrailsPromptP1 | null;
    s1?: UpdateResponseGuardrailsPromptS1 | null;
    s10?: UpdateResponseGuardrailsPromptS10 | null;
    s11?: UpdateResponseGuardrailsPromptS11 | null;
    s12?: UpdateResponseGuardrailsPromptS12 | null;
    s13?: UpdateResponseGuardrailsPromptS13 | null;
    s2?: UpdateResponseGuardrailsPromptS2 | null;
    s3?: UpdateResponseGuardrailsPromptS3 | null;
    s4?: UpdateResponseGuardrailsPromptS4 | null;
    s5?: UpdateResponseGuardrailsPromptS5 | null;
    s6?: UpdateResponseGuardrailsPromptS6 | null;
    s7?: UpdateResponseGuardrailsPromptS7 | null;
    s8?: UpdateResponseGuardrailsPromptS8 | null;
    s9?: UpdateResponseGuardrailsPromptS9 | null;
}
export declare const UpdateResponseGuardrailsPrompt: S.Schema<UpdateResponseGuardrailsPrompt>;
export type UpdateResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseP1: any;
export type UpdateResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS1: any;
export type UpdateResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS10: any;
export type UpdateResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS11: any;
export type UpdateResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS12: any;
export type UpdateResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS13: any;
export type UpdateResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS2: any;
export type UpdateResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS3: any;
export type UpdateResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS4: any;
export type UpdateResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS5: any;
export type UpdateResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS6: any;
export type UpdateResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS7: any;
export type UpdateResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS8: any;
export type UpdateResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export declare const UpdateResponseGuardrailsResponseS9: any;
export interface UpdateResponseGuardrailsResponse {
    p1?: UpdateResponseGuardrailsResponseP1 | null;
    s1?: UpdateResponseGuardrailsResponseS1 | null;
    s10?: UpdateResponseGuardrailsResponseS10 | null;
    s11?: UpdateResponseGuardrailsResponseS11 | null;
    s12?: UpdateResponseGuardrailsResponseS12 | null;
    s13?: UpdateResponseGuardrailsResponseS13 | null;
    s2?: UpdateResponseGuardrailsResponseS2 | null;
    s3?: UpdateResponseGuardrailsResponseS3 | null;
    s4?: UpdateResponseGuardrailsResponseS4 | null;
    s5?: UpdateResponseGuardrailsResponseS5 | null;
    s6?: UpdateResponseGuardrailsResponseS6 | null;
    s7?: UpdateResponseGuardrailsResponseS7 | null;
    s8?: UpdateResponseGuardrailsResponseS8 | null;
    s9?: UpdateResponseGuardrailsResponseS9 | null;
}
export declare const UpdateResponseGuardrailsResponse: S.Schema<UpdateResponseGuardrailsResponse>;
export interface UpdateResponseGuardrails {
    prompt: UpdateResponseGuardrailsPrompt;
    response: UpdateResponseGuardrailsResponse;
}
export declare const UpdateResponseGuardrails: S.Schema<UpdateResponseGuardrails>;
export type UpdateResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export declare const UpdateResponseLogManagementStrategy: any;
export type UpdateResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateResponseOtelItemHeadersMap: S.Schema<UpdateResponseOtelItemHeadersMap>;
export type UpdateResponseOtelItemContentType = "json" | "protobuf";
export declare const UpdateResponseOtelItemContentType: any;
export interface UpdateResponseOtelItem {
    headers: UpdateResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null;
    contentType?: UpdateResponseOtelItemContentType | null;
}
export declare const UpdateResponseOtelItem: S.Schema<UpdateResponseOtelItem>;
export type UpdateResponseOtelList = Array<UpdateResponseOtelItem>;
export declare const UpdateResponseOtelList: S.Schema<UpdateResponseOtelList>;
export type UpdateResponseRateLimitingTechnique = "fixed" | "sliding";
export declare const UpdateResponseRateLimitingTechnique: any;
export type UpdateResponseRetryBackoff = "constant" | "linear" | "exponential";
export declare const UpdateResponseRetryBackoff: any;
export type UpdateResponseSpendLimitsRulesItemLimitType = "cost";
export declare const UpdateResponseSpendLimitsRulesItemLimitType: any;
export type UpdateResponseSpendLimitsRulesItemModelMode = "filter";
export declare const UpdateResponseSpendLimitsRulesItemModelMode: any;
export type UpdateResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export declare const UpdateResponseSpendLimitsRulesItemModelValuesList: S.Schema<UpdateResponseSpendLimitsRulesItemModelValuesList>;
export interface UpdateResponseSpendLimitsRulesItemModel {
    mode: UpdateResponseSpendLimitsRulesItemModelMode;
    values: UpdateResponseSpendLimitsRulesItemModelValuesList;
}
export declare const UpdateResponseSpendLimitsRulesItemModel: S.Schema<UpdateResponseSpendLimitsRulesItemModel>;
export type UpdateResponseSpendLimitsRulesItemProviderMode = "filter";
export declare const UpdateResponseSpendLimitsRulesItemProviderMode: any;
export type UpdateResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export declare const UpdateResponseSpendLimitsRulesItemProviderValuesList: S.Schema<UpdateResponseSpendLimitsRulesItemProviderValuesList>;
export interface UpdateResponseSpendLimitsRulesItemProvider {
    mode: UpdateResponseSpendLimitsRulesItemProviderMode;
    values: UpdateResponseSpendLimitsRulesItemProviderValuesList;
}
export declare const UpdateResponseSpendLimitsRulesItemProvider: S.Schema<UpdateResponseSpendLimitsRulesItemProvider>;
export type UpdateResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export declare const UpdateResponseSpendLimitsRulesItemTechnique: any;
export interface UpdateResponseSpendLimitsRulesItem {
    limit: number;
    limitType: UpdateResponseSpendLimitsRulesItemLimitType;
    window: number;
    id?: string | null;
    enabled?: boolean | null;
    metadata?: UntypedMetadataMap | null;
    model?: UpdateResponseSpendLimitsRulesItemModel | null;
    provider?: UpdateResponseSpendLimitsRulesItemProvider | null;
    technique?: UpdateResponseSpendLimitsRulesItemTechnique | null;
}
export declare const UpdateResponseSpendLimitsRulesItem: S.Schema<UpdateResponseSpendLimitsRulesItem>;
export type UpdateResponseSpendLimitsRulesList = Array<UpdateResponseSpendLimitsRulesItem>;
export declare const UpdateResponseSpendLimitsRulesList: S.Schema<UpdateResponseSpendLimitsRulesList>;
export interface UpdateResponseSpendLimits {
    enabled?: boolean | null;
    rules?: UpdateResponseSpendLimitsRulesList | null;
}
export declare const UpdateResponseSpendLimits: S.Schema<UpdateResponseSpendLimits>;
export type UpdateResponseStripeUsageEventsItem = CreateResponseStripeUsageEventsItem;
export declare const UpdateResponseStripeUsageEventsItem: S.Schema<CreateResponseStripeUsageEventsItem>;
export type UpdateResponseStripeUsageEventsList = Array<CreateResponseStripeUsageEventsItem>;
export declare const UpdateResponseStripeUsageEventsList: S.Schema<UpdateResponseStripeUsageEventsList>;
export interface UpdateResponseStripe {
    authorization: string;
    usageEvents: UpdateResponseStripeUsageEventsList;
}
export declare const UpdateResponseStripe: S.Schema<UpdateResponseStripe>;
export type UpdateResponseWorkersAiBillingMode = "postpaid";
export declare const UpdateResponseWorkersAiBillingMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAiGatewayResponse {
    /** gateway id */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    authentication?: boolean | null;
    dlp?: UpdateResponseDlp | null;
    guardrails?: UpdateResponseGuardrails | null;
    isDefault?: boolean | null;
    logManagement?: number | null;
    logManagementStrategy?: UpdateResponseLogManagementStrategy | null;
    logpush?: boolean | null;
    logpushPublicKey?: string | null;
    otel?: UpdateResponseOtelList | null;
    rateLimitingTechnique?: UpdateResponseRateLimitingTechnique | null;
    /** Backoff strategy for retry delays */
    retryBackoff?: UpdateResponseRetryBackoff | null;
    /** Delay between retry attempts in milliseconds (0-5000) */
    retryDelay?: number | null;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null;
    spendLimits?: UpdateResponseSpendLimits | null;
    storeId?: string | null;
    stripe?: UpdateResponseStripe | null;
    /** Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported. */
    workersAiBillingMode?: UpdateResponseWorkersAiBillingMode | null;
    zdr?: boolean | null;
}
export declare const UpdateAiGatewayResponse: S.Schema<UpdateAiGatewayResponse>;
export type DatasetsUpdateRequestFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsUpdateRequestFiltersItemKey: any;
export type DatasetsUpdateRequestFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsUpdateRequestFiltersItemOperator: any;
export type DatasetsUpdateRequestFiltersItemValueItem = string | number | boolean;
export declare const DatasetsUpdateRequestFiltersItemValueItem: any;
export type DatasetsUpdateRequestFiltersItemValueList = Array<DatasetsUpdateRequestFiltersItemValueItem>;
export declare const DatasetsUpdateRequestFiltersItemValueList: S.Schema<DatasetsUpdateRequestFiltersItemValueList>;
export interface DatasetsUpdateRequestFiltersItem {
    key: DatasetsUpdateRequestFiltersItemKey | (string & {});
    operator: DatasetsUpdateRequestFiltersItemOperator | (string & {});
    value: DatasetsUpdateRequestFiltersItemValueList;
}
export declare const DatasetsUpdateRequestFiltersItem: S.Schema<DatasetsUpdateRequestFiltersItem>;
export type DatasetsUpdateRequestFiltersList = Array<DatasetsUpdateRequestFiltersItem>;
export declare const DatasetsUpdateRequestFiltersList: S.Schema<DatasetsUpdateRequestFiltersList>;
export interface UpdateDatasetRequest {
    accountId: string;
    /** gateway id */
    gatewayId: string;
    id: string;
    enable: boolean;
    filters: DatasetsUpdateRequestFiltersList;
    name: string;
}
export declare const UpdateDatasetRequest: S.Schema<UpdateDatasetRequest>;
export type DatasetsUpdateResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export declare const DatasetsUpdateResponseFiltersItemKey: any;
export type DatasetsUpdateResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export declare const DatasetsUpdateResponseFiltersItemOperator: any;
export type DatasetsUpdateResponseFiltersItemValueItem = string | number | boolean;
export declare const DatasetsUpdateResponseFiltersItemValueItem: any;
export type DatasetsUpdateResponseFiltersItemValueList = Array<DatasetsUpdateResponseFiltersItemValueItem>;
export declare const DatasetsUpdateResponseFiltersItemValueList: S.Schema<DatasetsUpdateResponseFiltersItemValueList>;
export interface DatasetsUpdateResponseFiltersItem {
    key: DatasetsUpdateResponseFiltersItemKey;
    operator: DatasetsUpdateResponseFiltersItemOperator;
    value: DatasetsUpdateResponseFiltersItemValueList;
}
export declare const DatasetsUpdateResponseFiltersItem: S.Schema<DatasetsUpdateResponseFiltersItem>;
export type DatasetsUpdateResponseFiltersList = Array<DatasetsUpdateResponseFiltersItem>;
export declare const DatasetsUpdateResponseFiltersList: S.Schema<DatasetsUpdateResponseFiltersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsUpdateResponseFiltersList;
    /** gateway id */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export declare const UpdateDatasetResponse: S.Schema<UpdateDatasetResponse>;
export type BillingUsageHistoryRequestValueGroupingWindow = "day" | "hour";
export declare const BillingUsageHistoryRequestValueGroupingWindow: any;
export interface UsageHistoryBillingRequest {
    accountId: string;
    /** Grouping window for usage data. */
    valueGroupingWindow: BillingUsageHistoryRequestValueGroupingWindow | (string & {});
    /** End time as Unix timestamp in milliseconds. */
    endTime?: number;
    /** Start time as Unix timestamp in milliseconds. */
    startTime?: number;
}
export declare const UsageHistoryBillingRequest: S.Schema<UsageHistoryBillingRequest>;
export interface BillingUsageHistoryResponseHistoryItem {
    id: string;
    aggregatedValue: number;
    endTime: number;
    startTime: number;
}
export declare const BillingUsageHistoryResponseHistoryItem: S.Schema<BillingUsageHistoryResponseHistoryItem>;
export type BillingUsageHistoryResponseHistoryList = Array<BillingUsageHistoryResponseHistoryItem>;
export declare const BillingUsageHistoryResponseHistoryList: S.Schema<BillingUsageHistoryResponseHistoryList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UsageHistoryBillingResponse {
    history: BillingUsageHistoryResponseHistoryList;
}
export declare const UsageHistoryBillingResponse: S.Schema<UsageHistoryBillingResponse>;
export type CreateAiGatewayError = GatewayAlreadyExists | CloudflareOpError;
/** Creates a new AI Gateway. */
export declare const createAiGateway: API.OperationMethod<CreateAiGatewayRequest, CreateAiGatewayResponse, CreateAiGatewayError, CloudflareOpContext>;
export type CreateBillingSpendingLimitError = NoManualTopup | AiGatewaySpendingLimitDeprecated | CloudflareOpError;
/** Deprecated: spending limits can no longer be created, enabled, or modified and this endpoint always responds 403. Use the new AI Gateway spend limits instead: https://developers.cloudflare.com/ai-gateway/features/spend-limits/. Existing limits can be removed via DELETE /spending-limit. */
export declare const createBillingSpendingLimit: API.OperationMethod<CreateBillingSpendingLimitRequest, CreateBillingSpendingLimitResponse, CreateBillingSpendingLimitError, CloudflareOpContext>;
export type CreateBillingTopupError = CloudflareOpError;
/** Create a credit top-up via Stripe PaymentIntent for the given account. */
export declare const createBillingTopup: API.OperationMethod<CreateBillingTopupRequest, CreateBillingTopupResponse, CreateBillingTopupError, CloudflareOpContext>;
export type CreateBillingTopupConfigError = CloudflareOpError;
/** Configure auto top-up with a balance threshold and top-up amount. */
export declare const createBillingTopupConfig: API.OperationMethod<CreateBillingTopupConfigRequest, CreateBillingTopupConfigResponse, CreateBillingTopupConfigError, CloudflareOpContext>;
export type CreateCustomProviderError = CloudflareOpError;
/** Creates a new AI Gateway. */
export declare const createCustomProvider: API.OperationMethod<CreateCustomProviderRequest, CreateCustomProviderResponse, CreateCustomProviderError, CloudflareOpContext>;
export type CreateDatasetError = GatewayNotFound | DatasetNameAlreadyExists | CloudflareOpError;
/** Creates a new AI Gateway. */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, CloudflareOpContext>;
export type CreateDeploymentDynamicRoutingError = RouteNotFound | CloudflareOpError;
/** Create a new AI Gateway Dynamic Route Deployment. */
export declare const createDeploymentDynamicRouting: API.OperationMethod<CreateDeploymentDynamicRoutingRequest, CreateDeploymentDynamicRoutingResponse, CreateDeploymentDynamicRoutingError, CloudflareOpContext>;
export type CreateDynamicRoutingError = RouteAlreadyExists | GatewayNotFound | CloudflareOpError;
/** Create a new AI Gateway Dynamic Route. */
export declare const createDynamicRouting: API.OperationMethod<CreateDynamicRoutingRequest, CreateDynamicRoutingResponse, CreateDynamicRoutingError, CloudflareOpContext>;
export type CreateEvaluationError = GatewayNotFound | EvaluationNameAlreadyExists | CloudflareOpError;
/** Creates a new AI Gateway. */
export declare const createEvaluation: API.OperationMethod<CreateEvaluationRequest, CreateEvaluationResponse, CreateEvaluationError, CloudflareOpContext>;
export type CreateProviderConfigError = ProviderConfigSecretNotFound | ProviderConfigAlreadyExists | GatewayNotFound | CloudflareOpError;
/** Creates a new AI Gateway. */
export declare const createProviderConfig: API.OperationMethod<CreateProviderConfigRequest, CreateProviderConfigResponse, CreateProviderConfigError, CloudflareOpContext>;
export type CreateVersionDynamicRoutingError = RouteNotFound | CloudflareOpError;
/** Create a new AI Gateway Dynamic Route Version. */
export declare const createVersionDynamicRouting: API.OperationMethod<CreateVersionDynamicRoutingRequest, CreateVersionDynamicRoutingResponse, CreateVersionDynamicRoutingError, CloudflareOpContext>;
export type CreditBalanceBillingError = CloudflareOpError;
/** Retrieve the current credit balance, payment method info, and top-up configuration. */
export declare const creditBalanceBilling: API.OperationMethod<CreditBalanceBillingRequest, CreditBalanceBillingResponse, CreditBalanceBillingError, CloudflareOpContext>;
export type DeleteAiGatewayError = GatewayNotFound | CloudflareOpError;
/** Deletes an AI Gateway dataset. */
export declare const deleteAiGateway: API.OperationMethod<DeleteAiGatewayRequest, DeleteAiGatewayResponse, DeleteAiGatewayError, CloudflareOpContext>;
export type DeleteBillingSpendingLimitError = CloudflareOpError;
/** Remove the spending limit for the account. */
export declare const deleteBillingSpendingLimit: API.OperationMethod<DeleteBillingSpendingLimitRequest, DeleteBillingSpendingLimitResponse, DeleteBillingSpendingLimitError, CloudflareOpContext>;
export type DeleteBillingTopupConfigError = CloudflareOpError;
/** Remove the auto top-up configuration for the account. */
export declare const deleteBillingTopupConfig: API.OperationMethod<DeleteBillingTopupConfigRequest, DeleteBillingTopupConfigResponse, DeleteBillingTopupConfigError, CloudflareOpContext>;
export type DeleteCustomProviderError = CloudflareOpError;
/** Deletes an AI Gateway dataset. */
export declare const deleteCustomProvider: API.OperationMethod<DeleteCustomProviderRequest, DeleteCustomProviderResponse, DeleteCustomProviderError, CloudflareOpContext>;
export type DeleteDatasetError = DatasetNotFound | CloudflareOpError;
/** Deletes an AI Gateway dataset. */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, CloudflareOpContext>;
export type DeleteDynamicRoutingError = RouteNotFound | GatewayNotFound | CloudflareOpError;
/** Delete an AI Gateway Dynamic Route. */
export declare const deleteDynamicRouting: API.OperationMethod<DeleteDynamicRoutingRequest, DeleteDynamicRoutingResponse, DeleteDynamicRoutingError, CloudflareOpContext>;
export type DeleteEvaluationError = EvaluationNotFound | CloudflareOpError;
/** Deletes an AI Gateway dataset. */
export declare const deleteEvaluation: API.OperationMethod<DeleteEvaluationRequest, DeleteEvaluationResponse, DeleteEvaluationError, CloudflareOpContext>;
export type DeleteLogError = CloudflareOpError;
/** Delete Gateway Logs */
export declare const deleteLog: API.OperationMethod<DeleteLogRequest, DeleteLogResponse, DeleteLogError, CloudflareOpContext>;
export type DeleteProviderConfigError = ProviderConfigNotFound | CloudflareOpError;
export declare const deleteProviderConfig: API.OperationMethod<DeleteProviderConfigRequest, DeleteProviderConfigResponse, DeleteProviderConfigError, CloudflareOpContext>;
export type GetAiGatewayError = GatewayNotFound | CloudflareOpError;
/** Retrieves details for a specific AI Gateway dataset. */
export declare const getAiGateway: API.OperationMethod<GetAiGatewayRequest, GetAiGatewayResponse, GetAiGatewayError, CloudflareOpContext>;
export type GetBillingSpendingLimitError = CloudflareOpError;
/** Retrieve the current spending limit configuration for the account. */
export declare const getBillingSpendingLimit: API.OperationMethod<GetBillingSpendingLimitRequest, GetBillingSpendingLimitResponse, GetBillingSpendingLimitError, CloudflareOpContext>;
export type GetBillingTopupConfigError = CloudflareOpError;
/** Retrieve the current auto top-up threshold, amount, and any error state. */
export declare const getBillingTopupConfig: API.OperationMethod<GetBillingTopupConfigRequest, GetBillingTopupConfigResponse, GetBillingTopupConfigError, CloudflareOpContext>;
export type GetCustomProviderError = CloudflareOpError;
/** Retrieves details for a specific AI Gateway dataset. */
export declare const getCustomProvider: API.OperationMethod<GetCustomProviderRequest, GetCustomProviderResponse, GetCustomProviderError, CloudflareOpContext>;
export type GetDatasetError = DatasetNotFound | CloudflareOpError;
/** Retrieves details for a specific AI Gateway dataset. */
export declare const getDataset: API.OperationMethod<GetDatasetRequest, GetDatasetResponse, GetDatasetError, CloudflareOpContext>;
export type GetDynamicRoutingError = RouteNotFound | GatewayNotFound | CloudflareOpError;
/** Get an AI Gateway Dynamic Route. */
export declare const getDynamicRouting: API.OperationMethod<GetDynamicRoutingRequest, GetDynamicRoutingResponse, GetDynamicRoutingError, CloudflareOpContext>;
export type GetEvaluationError = EvaluationNotFound | CloudflareOpError;
/** Retrieves details for a specific AI Gateway dataset. */
export declare const getEvaluation: API.OperationMethod<GetEvaluationRequest, GetEvaluationResponse, GetEvaluationError, CloudflareOpContext>;
export type GetLogError = CloudflareOpError;
/** Retrieves detailed information for a specific AI Gateway log entry. */
export declare const getLog: API.OperationMethod<GetLogRequest, GetLogResponse, GetLogError, CloudflareOpContext>;
export type GetUrlError = CloudflareOpError;
/** Retrieves the endpoint URL for an AI Gateway. */
export declare const getUrl: API.OperationMethod<GetUrlRequest, GetUrlResponse, GetUrlError, CloudflareOpContext>;
export type GetVersionDynamicRoutingError = CloudflareOpError;
/** Get an AI Gateway Dynamic Route Version. */
export declare const getVersionDynamicRouting: API.OperationMethod<GetVersionDynamicRoutingRequest, GetVersionDynamicRoutingResponse, GetVersionDynamicRoutingError, CloudflareOpContext>;
export type InvoiceHistoryBillingError = CloudflareOpError;
/** Retrieve a list of past invoices with pagination, optionally filtered by type. */
export declare const invoiceHistoryBilling: API.OperationMethod<InvoiceHistoryBillingRequest, InvoiceHistoryBillingResponse, InvoiceHistoryBillingError, CloudflareOpContext>;
export type InvoicePreviewBillingError = CloudflareOpError;
/** Retrieve a preview of the upcoming invoice including line items and tax. */
export declare const invoicePreviewBilling: API.OperationMethod<InvoicePreviewBillingRequest, InvoicePreviewBillingResponse, InvoicePreviewBillingError, CloudflareOpContext>;
export type ListAiGatewaysError = CloudflareOpError;
/** Lists all AI Gateway evaluator types configured for the account. */
export declare const listAiGateways: API.PaginatedOperationMethod<ListAiGatewaysRequest, ListAiGatewaysResponse, ListAiGatewaysError, CloudflareOpContext, ListResultItem>;
export type ListCustomProvidersError = CloudflareOpError;
/** Lists all AI Gateway evaluator types configured for the account. */
export declare const listCustomProviders: API.PaginatedOperationMethod<ListCustomProvidersRequest, ListCustomProvidersResponse, ListCustomProvidersError, CloudflareOpContext, CustomProvidersListResultItem>;
export type ListDatasetsError = GatewayNotFound | CloudflareOpError;
/** Lists all AI Gateway evaluator types configured for the account. */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, CloudflareOpContext, DatasetsListResultItem>;
export type ListDeploymentsDynamicRoutingError = CloudflareOpError;
/** List all AI Gateway Dynamic Route Deployments. */
export declare const listDeploymentsDynamicRouting: API.OperationMethod<ListDeploymentsDynamicRoutingRequest, ListDeploymentsDynamicRoutingResponse, ListDeploymentsDynamicRoutingError, CloudflareOpContext>;
export type ListDynamicRoutingsError = GatewayNotFound | CloudflareOpError;
/** List all AI Gateway Dynamic Routes. */
export declare const listDynamicRoutings: API.OperationMethod<ListDynamicRoutingsRequest, ListDynamicRoutingsResponse, ListDynamicRoutingsError, CloudflareOpContext>;
export type ListEvaluationsError = CloudflareOpError;
/** Lists all AI Gateway evaluator types configured for the account. */
export declare const listEvaluations: API.PaginatedOperationMethod<ListEvaluationsRequest, ListEvaluationsResponse, ListEvaluationsError, CloudflareOpContext, EvaluationsListResultItem>;
export type ListEvaluationTypesError = CloudflareOpError;
/** List Evaluators */
export declare const listEvaluationTypes: API.PaginatedOperationMethod<ListEvaluationTypesRequest, ListEvaluationTypesResponse, ListEvaluationTypesError, CloudflareOpContext, EvaluationTypesListResultItem>;
export type ListLogsError = CloudflareOpError;
/** List Gateway Logs */
export declare const listLogs: API.PaginatedOperationMethod<ListLogsRequest, ListLogsResponse, ListLogsError, CloudflareOpContext, LogsListResultItem>;
export type ListProviderConfigsError = CloudflareOpError;
/** Lists all AI Gateway evaluator types configured for the account. */
export declare const listProviderConfigs: API.PaginatedOperationMethod<ListProviderConfigsRequest, ListProviderConfigsResponse, ListProviderConfigsError, CloudflareOpContext, ProviderConfigsListResultItem>;
export type ListVersionsDynamicRoutingError = CloudflareOpError;
/** List all AI Gateway Dynamic Route Versions. */
export declare const listVersionsDynamicRouting: API.OperationMethod<ListVersionsDynamicRoutingRequest, ListVersionsDynamicRoutingResponse, ListVersionsDynamicRoutingError, CloudflareOpContext>;
export type PatchDynamicRoutingError = RouteNotFound | RouteAlreadyExists | CloudflareOpError;
/** Update an AI Gateway Dynamic Route. */
export declare const patchDynamicRouting: API.OperationMethod<PatchDynamicRoutingRequest, PatchDynamicRoutingResponse, PatchDynamicRoutingError, CloudflareOpContext>;
export type PatchLogError = CloudflareOpError;
/** Updates metadata for an AI Gateway log entry. */
export declare const patchLog: API.OperationMethod<PatchLogRequest, PatchLogResponse, PatchLogError, CloudflareOpContext>;
export type RequestLogError = CloudflareOpError;
/** Retrieves the original request payload for an AI Gateway log entry. */
export declare const requestLog: API.OperationMethod<RequestLogRequest, RequestLogResponse, RequestLogError, CloudflareOpContext>;
export type ResponseLogError = CloudflareOpError;
/** Retrieves the response payload for an AI Gateway log entry. */
export declare const responseLog: API.OperationMethod<ResponseLogRequest, ResponseLogResponse, ResponseLogError, CloudflareOpContext>;
export type StatusBillingTopupError = CloudflareOpError;
/** Get the payment processing status of a top-up by its invoice ID. */
export declare const statusBillingTopup: API.OperationMethod<StatusBillingTopupRequest, StatusBillingTopupResponse, StatusBillingTopupError, CloudflareOpContext>;
export type UpdateAiGatewayError = GatewayNotFound | CloudflareOpError;
/** Updates an existing AI Gateway dataset. */
export declare const updateAiGateway: API.OperationMethod<UpdateAiGatewayRequest, UpdateAiGatewayResponse, UpdateAiGatewayError, CloudflareOpContext>;
export type UpdateDatasetError = DatasetNotFound | CloudflareOpError;
/** Updates an existing AI Gateway dataset. */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, CloudflareOpContext>;
export type UsageHistoryBillingError = CloudflareOpError;
/** Retrieve aggregated usage meter event summaries for the given time range. */
export declare const usageHistoryBilling: API.OperationMethod<UsageHistoryBillingRequest, UsageHistoryBillingResponse, UsageHistoryBillingError, CloudflareOpContext>;
//# sourceMappingURL=ai_gateway.d.ts.map