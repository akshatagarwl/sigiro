import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TagPreconditionFailed_base: S.Class<TagPreconditionFailed, S.TaggedStruct<"TagPreconditionFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagPreconditionFailed extends /*@__PURE__*/ TagPreconditionFailed_base {
}
declare const ZoneTagResourceNotFound_base: S.Class<ZoneTagResourceNotFound, S.TaggedStruct<"ZoneTagResourceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneTagResourceNotFound extends /*@__PURE__*/ ZoneTagResourceNotFound_base {
}
export interface DeleteAccountTagRequest {
    /** Identifier. */
    accountId: string;
    ifMatch?: string;
    /** Identifier of the resource to remove tags from. */
    resourceId?: string;
    /** Type of the resource to remove tags from. */
    resourceType?: string;
    /** Identifier of the Worker to remove tags from. */
    workerId?: string;
}
export declare const DeleteAccountTagRequest: S.Schema<DeleteAccountTagRequest>;
export interface DeleteAccountTagResponse {
}
export declare const DeleteAccountTagResponse: S.Schema<DeleteAccountTagResponse>;
export interface DeleteZoneTagRequest {
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    ifMatch?: string;
    /** Identifier of the resource to remove tags from. */
    resourceId?: string;
    /** Type of the resource to remove tags from. */
    resourceType?: string;
    /** Identifier of the Access application to remove tags from. */
    accessApplicationId?: string;
}
export declare const DeleteZoneTagRequest: S.Schema<DeleteZoneTagRequest>;
export interface DeleteZoneTagResponse {
}
export declare const DeleteZoneTagResponse: S.Schema<DeleteZoneTagResponse>;
export type AccountTagsGetRequestResourceType = "access_application" | "access_group" | "account" | "ai_gateway" | "alerting_policy" | "alerting_webhook" | "cloudflared_tunnel" | "d1_database" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "kv_namespace" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "worker" | "worker_version";
export declare const AccountTagsGetRequestResourceType: any;
export interface GetAccountTagRequest {
    /** Identifier. */
    accountId: string;
    /** The ID of the resource to retrieve tags for. */
    resourceId: string;
    /** The type of the resource. */
    resourceType: AccountTagsGetRequestResourceType | (string & {});
    /** Worker identifier. Required for worker_version resources. */
    workerId?: string;
}
export declare const GetAccountTagRequest: S.Schema<GetAccountTagRequest>;
export type AccountTagsGetResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAccessApplicationTagsMap: S.Schema<AccountTagsGetResultAccessApplicationTagsMap>;
export type AccountTagsGetResultAccessApplicationType = "access_application";
export declare const AccountTagsGetResultAccessApplicationType: any;
export interface AccountTagsGetResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAccessApplicationTagsMap;
    type: AccountTagsGetResultAccessApplicationType;
}
export declare const AccountTagsGetResultAccessApplication: S.Schema<AccountTagsGetResultAccessApplication>;
export type AccountTagsGetResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAccessApplicationPolicyTagsMap: S.Schema<AccountTagsGetResultAccessApplicationPolicyTagsMap>;
export type AccountTagsGetResultAccessApplicationPolicyType = "access_application_policy";
export declare const AccountTagsGetResultAccessApplicationPolicyType: any;
export interface AccountTagsGetResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAccessApplicationPolicyTagsMap;
    type: AccountTagsGetResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultAccessApplicationPolicy: S.Schema<AccountTagsGetResultAccessApplicationPolicy>;
export type AccountTagsGetResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAccessGroupTagsMap: S.Schema<AccountTagsGetResultAccessGroupTagsMap>;
export type AccountTagsGetResultAccessGroupType = "access_group";
export declare const AccountTagsGetResultAccessGroupType: any;
export interface AccountTagsGetResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAccessGroupTagsMap;
    type: AccountTagsGetResultAccessGroupType;
}
export declare const AccountTagsGetResultAccessGroup: S.Schema<AccountTagsGetResultAccessGroup>;
export type AccountTagsGetResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAccountTagsMap: S.Schema<AccountTagsGetResultAccountTagsMap>;
export type AccountTagsGetResultAccountType = "account";
export declare const AccountTagsGetResultAccountType: any;
export interface AccountTagsGetResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAccountTagsMap;
    type: AccountTagsGetResultAccountType;
}
export declare const AccountTagsGetResultAccount: S.Schema<AccountTagsGetResultAccount>;
export type AccountTagsGetResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAIGatewayTagsMap: S.Schema<AccountTagsGetResultAIGatewayTagsMap>;
export type AccountTagsGetResultAIGatewayType = "ai_gateway";
export declare const AccountTagsGetResultAIGatewayType: any;
export interface AccountTagsGetResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAIGatewayTagsMap;
    type: AccountTagsGetResultAIGatewayType;
}
export declare const AccountTagsGetResultAIGateway: S.Schema<AccountTagsGetResultAIGateway>;
export type AccountTagsGetResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAlertingPolicyTagsMap: S.Schema<AccountTagsGetResultAlertingPolicyTagsMap>;
export type AccountTagsGetResultAlertingPolicyType = "alerting_policy";
export declare const AccountTagsGetResultAlertingPolicyType: any;
export interface AccountTagsGetResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAlertingPolicyTagsMap;
    type: AccountTagsGetResultAlertingPolicyType;
}
export declare const AccountTagsGetResultAlertingPolicy: S.Schema<AccountTagsGetResultAlertingPolicy>;
export type AccountTagsGetResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAlertingWebhookTagsMap: S.Schema<AccountTagsGetResultAlertingWebhookTagsMap>;
export type AccountTagsGetResultAlertingWebhookType = "alerting_webhook";
export declare const AccountTagsGetResultAlertingWebhookType: any;
export interface AccountTagsGetResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAlertingWebhookTagsMap;
    type: AccountTagsGetResultAlertingWebhookType;
}
export declare const AccountTagsGetResultAlertingWebhook: S.Schema<AccountTagsGetResultAlertingWebhook>;
export type AccountTagsGetResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultAPIGatewayOperationTagsMap: S.Schema<AccountTagsGetResultAPIGatewayOperationTagsMap>;
export type AccountTagsGetResultAPIGatewayOperationType = "api_gateway_operation";
export declare const AccountTagsGetResultAPIGatewayOperationType: any;
export interface AccountTagsGetResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultAPIGatewayOperationTagsMap;
    type: AccountTagsGetResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultAPIGatewayOperation: S.Schema<AccountTagsGetResultAPIGatewayOperation>;
export type AccountTagsGetResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultCloudflaredTunnelTagsMap: S.Schema<AccountTagsGetResultCloudflaredTunnelTagsMap>;
export type AccountTagsGetResultCloudflaredTunnelType = "cloudflared_tunnel";
export declare const AccountTagsGetResultCloudflaredTunnelType: any;
export interface AccountTagsGetResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultCloudflaredTunnelTagsMap;
    type: AccountTagsGetResultCloudflaredTunnelType;
}
export declare const AccountTagsGetResultCloudflaredTunnel: S.Schema<AccountTagsGetResultCloudflaredTunnel>;
export type AccountTagsGetResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultCustomCertificateTagsMap: S.Schema<AccountTagsGetResultCustomCertificateTagsMap>;
export type AccountTagsGetResultCustomCertificateType = "custom_certificate";
export declare const AccountTagsGetResultCustomCertificateType: any;
export interface AccountTagsGetResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultCustomCertificateTagsMap;
    type: AccountTagsGetResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultCustomCertificate: S.Schema<AccountTagsGetResultCustomCertificate>;
export type AccountTagsGetResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultCustomHostnameTagsMap: S.Schema<AccountTagsGetResultCustomHostnameTagsMap>;
export type AccountTagsGetResultCustomHostnameType = "custom_hostname";
export declare const AccountTagsGetResultCustomHostnameType: any;
export interface AccountTagsGetResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultCustomHostnameTagsMap;
    type: AccountTagsGetResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultCustomHostname: S.Schema<AccountTagsGetResultCustomHostname>;
export type AccountTagsGetResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultD1DatabaseTagsMap: S.Schema<AccountTagsGetResultD1DatabaseTagsMap>;
export type AccountTagsGetResultD1DatabaseType = "d1_database";
export declare const AccountTagsGetResultD1DatabaseType: any;
export interface AccountTagsGetResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultD1DatabaseTagsMap;
    type: AccountTagsGetResultD1DatabaseType;
}
export declare const AccountTagsGetResultD1Database: S.Schema<AccountTagsGetResultD1Database>;
export type AccountTagsGetResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultDNSRecordTagsMap: S.Schema<AccountTagsGetResultDNSRecordTagsMap>;
export type AccountTagsGetResultDNSRecordType = "dns_record";
export declare const AccountTagsGetResultDNSRecordType: any;
export interface AccountTagsGetResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultDNSRecordTagsMap;
    type: AccountTagsGetResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultDNSRecord: S.Schema<AccountTagsGetResultDNSRecord>;
export type AccountTagsGetResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultDurableObjectNamespaceTagsMap: S.Schema<AccountTagsGetResultDurableObjectNamespaceTagsMap>;
export type AccountTagsGetResultDurableObjectNamespaceType = "durable_object_namespace";
export declare const AccountTagsGetResultDurableObjectNamespaceType: any;
export interface AccountTagsGetResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultDurableObjectNamespaceTagsMap;
    type: AccountTagsGetResultDurableObjectNamespaceType;
}
export declare const AccountTagsGetResultDurableObjectNamespace: S.Schema<AccountTagsGetResultDurableObjectNamespace>;
export type AccountTagsGetResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultGatewayListTagsMap: S.Schema<AccountTagsGetResultGatewayListTagsMap>;
export type AccountTagsGetResultGatewayListType = "gateway_list";
export declare const AccountTagsGetResultGatewayListType: any;
export interface AccountTagsGetResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultGatewayListTagsMap;
    type: AccountTagsGetResultGatewayListType;
}
export declare const AccountTagsGetResultGatewayList: S.Schema<AccountTagsGetResultGatewayList>;
export type AccountTagsGetResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultGatewayRuleTagsMap: S.Schema<AccountTagsGetResultGatewayRuleTagsMap>;
export type AccountTagsGetResultGatewayRuleType = "gateway_rule";
export declare const AccountTagsGetResultGatewayRuleType: any;
export interface AccountTagsGetResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultGatewayRuleTagsMap;
    type: AccountTagsGetResultGatewayRuleType;
}
export declare const AccountTagsGetResultGatewayRule: S.Schema<AccountTagsGetResultGatewayRule>;
export type AccountTagsGetResultImageTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultImageTagsMap: S.Schema<AccountTagsGetResultImageTagsMap>;
export type AccountTagsGetResultImageType = "image";
export declare const AccountTagsGetResultImageType: any;
export interface AccountTagsGetResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultImageTagsMap;
    type: AccountTagsGetResultImageType;
}
export declare const AccountTagsGetResultImage: S.Schema<AccountTagsGetResultImage>;
export type AccountTagsGetResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultKVNamespaceTagsMap: S.Schema<AccountTagsGetResultKVNamespaceTagsMap>;
export type AccountTagsGetResultKVNamespaceType = "kv_namespace";
export declare const AccountTagsGetResultKVNamespaceType: any;
export interface AccountTagsGetResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultKVNamespaceTagsMap;
    type: AccountTagsGetResultKVNamespaceType;
}
export declare const AccountTagsGetResultKVNamespace: S.Schema<AccountTagsGetResultKVNamespace>;
export type AccountTagsGetResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultManagedClientCertificateTagsMap: S.Schema<AccountTagsGetResultManagedClientCertificateTagsMap>;
export type AccountTagsGetResultManagedClientCertificateType = "managed_client_certificate";
export declare const AccountTagsGetResultManagedClientCertificateType: any;
export interface AccountTagsGetResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultManagedClientCertificateTagsMap;
    type: AccountTagsGetResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultManagedClientCertificate: S.Schema<AccountTagsGetResultManagedClientCertificate>;
export type AccountTagsGetResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultQueueTagsMap: S.Schema<AccountTagsGetResultQueueTagsMap>;
export type AccountTagsGetResultQueueType = "queue";
export declare const AccountTagsGetResultQueueType: any;
export interface AccountTagsGetResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultQueueTagsMap;
    type: AccountTagsGetResultQueueType;
}
export declare const AccountTagsGetResultQueue: S.Schema<AccountTagsGetResultQueue>;
export type AccountTagsGetResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultR2BucketTagsMap: S.Schema<AccountTagsGetResultR2BucketTagsMap>;
export type AccountTagsGetResultR2BucketType = "r2_bucket";
export declare const AccountTagsGetResultR2BucketType: any;
export interface AccountTagsGetResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultR2BucketTagsMap;
    type: AccountTagsGetResultR2BucketType;
}
export declare const AccountTagsGetResultR2Bucket: S.Schema<AccountTagsGetResultR2Bucket>;
export type AccountTagsGetResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultResourceShareTagsMap: S.Schema<AccountTagsGetResultResourceShareTagsMap>;
export type AccountTagsGetResultResourceShareType = "resource_share";
export declare const AccountTagsGetResultResourceShareType: any;
export interface AccountTagsGetResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultResourceShareTagsMap;
    type: AccountTagsGetResultResourceShareType;
}
export declare const AccountTagsGetResultResourceShare: S.Schema<AccountTagsGetResultResourceShare>;
export type AccountTagsGetResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultStreamLiveInputTagsMap: S.Schema<AccountTagsGetResultStreamLiveInputTagsMap>;
export type AccountTagsGetResultStreamLiveInputType = "stream_live_input";
export declare const AccountTagsGetResultStreamLiveInputType: any;
export interface AccountTagsGetResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultStreamLiveInputTagsMap;
    type: AccountTagsGetResultStreamLiveInputType;
}
export declare const AccountTagsGetResultStreamLiveInput: S.Schema<AccountTagsGetResultStreamLiveInput>;
export type AccountTagsGetResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultStreamVideoTagsMap: S.Schema<AccountTagsGetResultStreamVideoTagsMap>;
export type AccountTagsGetResultStreamVideoType = "stream_video";
export declare const AccountTagsGetResultStreamVideoType: any;
export interface AccountTagsGetResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultStreamVideoTagsMap;
    type: AccountTagsGetResultStreamVideoType;
}
export declare const AccountTagsGetResultStreamVideo: S.Schema<AccountTagsGetResultStreamVideo>;
export type AccountTagsGetResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultWorkerTagsMap: S.Schema<AccountTagsGetResultWorkerTagsMap>;
export type AccountTagsGetResultWorkerType = "worker";
export declare const AccountTagsGetResultWorkerType: any;
export interface AccountTagsGetResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultWorkerTagsMap;
    type: AccountTagsGetResultWorkerType;
}
export declare const AccountTagsGetResultWorker: S.Schema<AccountTagsGetResultWorker>;
export type AccountTagsGetResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultWorkerVersionTagsMap: S.Schema<AccountTagsGetResultWorkerVersionTagsMap>;
export type AccountTagsGetResultWorkerVersionType = "worker_version";
export declare const AccountTagsGetResultWorkerVersionType: any;
export interface AccountTagsGetResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultWorkerVersionTagsMap;
    type: AccountTagsGetResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
}
export declare const AccountTagsGetResultWorkerVersion: S.Schema<AccountTagsGetResultWorkerVersion>;
export type AccountTagsGetResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsGetResultZoneTagsMap: S.Schema<AccountTagsGetResultZoneTagsMap>;
export type AccountTagsGetResultZoneType = "zone";
export declare const AccountTagsGetResultZoneType: any;
export interface AccountTagsGetResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsGetResultZoneTagsMap;
    type: AccountTagsGetResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsGetResultZone: S.Schema<AccountTagsGetResultZone>;
export type AccountTagsGetResult = AccountTagsGetResultAccessApplication | AccountTagsGetResultAccessApplicationPolicy | AccountTagsGetResultAccessGroup | AccountTagsGetResultAccount | AccountTagsGetResultAIGateway | AccountTagsGetResultAlertingPolicy | AccountTagsGetResultAlertingWebhook | AccountTagsGetResultAPIGatewayOperation | AccountTagsGetResultCloudflaredTunnel | AccountTagsGetResultCustomCertificate | AccountTagsGetResultCustomHostname | AccountTagsGetResultD1Database | AccountTagsGetResultDNSRecord | AccountTagsGetResultDurableObjectNamespace | AccountTagsGetResultGatewayList | AccountTagsGetResultGatewayRule | AccountTagsGetResultImage | AccountTagsGetResultKVNamespace | AccountTagsGetResultManagedClientCertificate | AccountTagsGetResultQueue | AccountTagsGetResultR2Bucket | AccountTagsGetResultResourceShare | AccountTagsGetResultStreamLiveInput | AccountTagsGetResultStreamVideo | AccountTagsGetResultWorker | AccountTagsGetResultWorkerVersion | AccountTagsGetResultZone;
export declare const AccountTagsGetResult: any;
export type GetAccountTagResponse = AccountTagsGetResult;
export declare const GetAccountTagResponse: S.Schema<GetAccountTagResponse>;
export type ZoneTagsGetRequestResourceType = "access_application_policy" | "api_gateway_operation" | "custom_certificate" | "custom_hostname" | "dns_record" | "managed_client_certificate" | "zone";
export declare const ZoneTagsGetRequestResourceType: any;
export interface GetZoneTagRequest {
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** The ID of the resource to retrieve tags for. */
    resourceId: string;
    /** The type of the resource. */
    resourceType: ZoneTagsGetRequestResourceType | (string & {});
    /** Access application ID identifier. Required for access_application_policy resources. */
    accessApplicationId?: string;
}
export declare const GetZoneTagRequest: S.Schema<GetZoneTagRequest>;
export type ZoneTagsGetResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAccessApplicationTagsMap: S.Schema<ZoneTagsGetResultAccessApplicationTagsMap>;
export type ZoneTagsGetResultAccessApplicationType = "access_application";
export declare const ZoneTagsGetResultAccessApplicationType: any;
export interface ZoneTagsGetResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAccessApplicationTagsMap;
    type: ZoneTagsGetResultAccessApplicationType;
}
export declare const ZoneTagsGetResultAccessApplication: S.Schema<ZoneTagsGetResultAccessApplication>;
export type ZoneTagsGetResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAccessApplicationPolicyTagsMap: S.Schema<ZoneTagsGetResultAccessApplicationPolicyTagsMap>;
export type ZoneTagsGetResultAccessApplicationPolicyType = "access_application_policy";
export declare const ZoneTagsGetResultAccessApplicationPolicyType: any;
export interface ZoneTagsGetResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAccessApplicationPolicyTagsMap;
    type: ZoneTagsGetResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultAccessApplicationPolicy: S.Schema<ZoneTagsGetResultAccessApplicationPolicy>;
export type ZoneTagsGetResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAccessGroupTagsMap: S.Schema<ZoneTagsGetResultAccessGroupTagsMap>;
export type ZoneTagsGetResultAccessGroupType = "access_group";
export declare const ZoneTagsGetResultAccessGroupType: any;
export interface ZoneTagsGetResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAccessGroupTagsMap;
    type: ZoneTagsGetResultAccessGroupType;
}
export declare const ZoneTagsGetResultAccessGroup: S.Schema<ZoneTagsGetResultAccessGroup>;
export type ZoneTagsGetResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAccountTagsMap: S.Schema<ZoneTagsGetResultAccountTagsMap>;
export type ZoneTagsGetResultAccountType = "account";
export declare const ZoneTagsGetResultAccountType: any;
export interface ZoneTagsGetResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAccountTagsMap;
    type: ZoneTagsGetResultAccountType;
}
export declare const ZoneTagsGetResultAccount: S.Schema<ZoneTagsGetResultAccount>;
export type ZoneTagsGetResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAIGatewayTagsMap: S.Schema<ZoneTagsGetResultAIGatewayTagsMap>;
export type ZoneTagsGetResultAIGatewayType = "ai_gateway";
export declare const ZoneTagsGetResultAIGatewayType: any;
export interface ZoneTagsGetResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAIGatewayTagsMap;
    type: ZoneTagsGetResultAIGatewayType;
}
export declare const ZoneTagsGetResultAIGateway: S.Schema<ZoneTagsGetResultAIGateway>;
export type ZoneTagsGetResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAlertingPolicyTagsMap: S.Schema<ZoneTagsGetResultAlertingPolicyTagsMap>;
export type ZoneTagsGetResultAlertingPolicyType = "alerting_policy";
export declare const ZoneTagsGetResultAlertingPolicyType: any;
export interface ZoneTagsGetResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAlertingPolicyTagsMap;
    type: ZoneTagsGetResultAlertingPolicyType;
}
export declare const ZoneTagsGetResultAlertingPolicy: S.Schema<ZoneTagsGetResultAlertingPolicy>;
export type ZoneTagsGetResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAlertingWebhookTagsMap: S.Schema<ZoneTagsGetResultAlertingWebhookTagsMap>;
export type ZoneTagsGetResultAlertingWebhookType = "alerting_webhook";
export declare const ZoneTagsGetResultAlertingWebhookType: any;
export interface ZoneTagsGetResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAlertingWebhookTagsMap;
    type: ZoneTagsGetResultAlertingWebhookType;
}
export declare const ZoneTagsGetResultAlertingWebhook: S.Schema<ZoneTagsGetResultAlertingWebhook>;
export type ZoneTagsGetResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultAPIGatewayOperationTagsMap: S.Schema<ZoneTagsGetResultAPIGatewayOperationTagsMap>;
export type ZoneTagsGetResultAPIGatewayOperationType = "api_gateway_operation";
export declare const ZoneTagsGetResultAPIGatewayOperationType: any;
export interface ZoneTagsGetResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultAPIGatewayOperationTagsMap;
    type: ZoneTagsGetResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultAPIGatewayOperation: S.Schema<ZoneTagsGetResultAPIGatewayOperation>;
export type ZoneTagsGetResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultCloudflaredTunnelTagsMap: S.Schema<ZoneTagsGetResultCloudflaredTunnelTagsMap>;
export type ZoneTagsGetResultCloudflaredTunnelType = "cloudflared_tunnel";
export declare const ZoneTagsGetResultCloudflaredTunnelType: any;
export interface ZoneTagsGetResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultCloudflaredTunnelTagsMap;
    type: ZoneTagsGetResultCloudflaredTunnelType;
}
export declare const ZoneTagsGetResultCloudflaredTunnel: S.Schema<ZoneTagsGetResultCloudflaredTunnel>;
export type ZoneTagsGetResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultCustomCertificateTagsMap: S.Schema<ZoneTagsGetResultCustomCertificateTagsMap>;
export type ZoneTagsGetResultCustomCertificateType = "custom_certificate";
export declare const ZoneTagsGetResultCustomCertificateType: any;
export interface ZoneTagsGetResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultCustomCertificateTagsMap;
    type: ZoneTagsGetResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultCustomCertificate: S.Schema<ZoneTagsGetResultCustomCertificate>;
export type ZoneTagsGetResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultCustomHostnameTagsMap: S.Schema<ZoneTagsGetResultCustomHostnameTagsMap>;
export type ZoneTagsGetResultCustomHostnameType = "custom_hostname";
export declare const ZoneTagsGetResultCustomHostnameType: any;
export interface ZoneTagsGetResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultCustomHostnameTagsMap;
    type: ZoneTagsGetResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultCustomHostname: S.Schema<ZoneTagsGetResultCustomHostname>;
export type ZoneTagsGetResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultD1DatabaseTagsMap: S.Schema<ZoneTagsGetResultD1DatabaseTagsMap>;
export type ZoneTagsGetResultD1DatabaseType = "d1_database";
export declare const ZoneTagsGetResultD1DatabaseType: any;
export interface ZoneTagsGetResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultD1DatabaseTagsMap;
    type: ZoneTagsGetResultD1DatabaseType;
}
export declare const ZoneTagsGetResultD1Database: S.Schema<ZoneTagsGetResultD1Database>;
export type ZoneTagsGetResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultDNSRecordTagsMap: S.Schema<ZoneTagsGetResultDNSRecordTagsMap>;
export type ZoneTagsGetResultDNSRecordType = "dns_record";
export declare const ZoneTagsGetResultDNSRecordType: any;
export interface ZoneTagsGetResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultDNSRecordTagsMap;
    type: ZoneTagsGetResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultDNSRecord: S.Schema<ZoneTagsGetResultDNSRecord>;
export type ZoneTagsGetResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultDurableObjectNamespaceTagsMap: S.Schema<ZoneTagsGetResultDurableObjectNamespaceTagsMap>;
export type ZoneTagsGetResultDurableObjectNamespaceType = "durable_object_namespace";
export declare const ZoneTagsGetResultDurableObjectNamespaceType: any;
export interface ZoneTagsGetResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultDurableObjectNamespaceTagsMap;
    type: ZoneTagsGetResultDurableObjectNamespaceType;
}
export declare const ZoneTagsGetResultDurableObjectNamespace: S.Schema<ZoneTagsGetResultDurableObjectNamespace>;
export type ZoneTagsGetResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultGatewayListTagsMap: S.Schema<ZoneTagsGetResultGatewayListTagsMap>;
export type ZoneTagsGetResultGatewayListType = "gateway_list";
export declare const ZoneTagsGetResultGatewayListType: any;
export interface ZoneTagsGetResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultGatewayListTagsMap;
    type: ZoneTagsGetResultGatewayListType;
}
export declare const ZoneTagsGetResultGatewayList: S.Schema<ZoneTagsGetResultGatewayList>;
export type ZoneTagsGetResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultGatewayRuleTagsMap: S.Schema<ZoneTagsGetResultGatewayRuleTagsMap>;
export type ZoneTagsGetResultGatewayRuleType = "gateway_rule";
export declare const ZoneTagsGetResultGatewayRuleType: any;
export interface ZoneTagsGetResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultGatewayRuleTagsMap;
    type: ZoneTagsGetResultGatewayRuleType;
}
export declare const ZoneTagsGetResultGatewayRule: S.Schema<ZoneTagsGetResultGatewayRule>;
export type ZoneTagsGetResultImageTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultImageTagsMap: S.Schema<ZoneTagsGetResultImageTagsMap>;
export type ZoneTagsGetResultImageType = "image";
export declare const ZoneTagsGetResultImageType: any;
export interface ZoneTagsGetResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultImageTagsMap;
    type: ZoneTagsGetResultImageType;
}
export declare const ZoneTagsGetResultImage: S.Schema<ZoneTagsGetResultImage>;
export type ZoneTagsGetResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultKVNamespaceTagsMap: S.Schema<ZoneTagsGetResultKVNamespaceTagsMap>;
export type ZoneTagsGetResultKVNamespaceType = "kv_namespace";
export declare const ZoneTagsGetResultKVNamespaceType: any;
export interface ZoneTagsGetResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultKVNamespaceTagsMap;
    type: ZoneTagsGetResultKVNamespaceType;
}
export declare const ZoneTagsGetResultKVNamespace: S.Schema<ZoneTagsGetResultKVNamespace>;
export type ZoneTagsGetResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultManagedClientCertificateTagsMap: S.Schema<ZoneTagsGetResultManagedClientCertificateTagsMap>;
export type ZoneTagsGetResultManagedClientCertificateType = "managed_client_certificate";
export declare const ZoneTagsGetResultManagedClientCertificateType: any;
export interface ZoneTagsGetResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultManagedClientCertificateTagsMap;
    type: ZoneTagsGetResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultManagedClientCertificate: S.Schema<ZoneTagsGetResultManagedClientCertificate>;
export type ZoneTagsGetResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultQueueTagsMap: S.Schema<ZoneTagsGetResultQueueTagsMap>;
export type ZoneTagsGetResultQueueType = "queue";
export declare const ZoneTagsGetResultQueueType: any;
export interface ZoneTagsGetResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultQueueTagsMap;
    type: ZoneTagsGetResultQueueType;
}
export declare const ZoneTagsGetResultQueue: S.Schema<ZoneTagsGetResultQueue>;
export type ZoneTagsGetResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultR2BucketTagsMap: S.Schema<ZoneTagsGetResultR2BucketTagsMap>;
export type ZoneTagsGetResultR2BucketType = "r2_bucket";
export declare const ZoneTagsGetResultR2BucketType: any;
export interface ZoneTagsGetResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultR2BucketTagsMap;
    type: ZoneTagsGetResultR2BucketType;
}
export declare const ZoneTagsGetResultR2Bucket: S.Schema<ZoneTagsGetResultR2Bucket>;
export type ZoneTagsGetResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultResourceShareTagsMap: S.Schema<ZoneTagsGetResultResourceShareTagsMap>;
export type ZoneTagsGetResultResourceShareType = "resource_share";
export declare const ZoneTagsGetResultResourceShareType: any;
export interface ZoneTagsGetResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultResourceShareTagsMap;
    type: ZoneTagsGetResultResourceShareType;
}
export declare const ZoneTagsGetResultResourceShare: S.Schema<ZoneTagsGetResultResourceShare>;
export type ZoneTagsGetResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultStreamLiveInputTagsMap: S.Schema<ZoneTagsGetResultStreamLiveInputTagsMap>;
export type ZoneTagsGetResultStreamLiveInputType = "stream_live_input";
export declare const ZoneTagsGetResultStreamLiveInputType: any;
export interface ZoneTagsGetResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultStreamLiveInputTagsMap;
    type: ZoneTagsGetResultStreamLiveInputType;
}
export declare const ZoneTagsGetResultStreamLiveInput: S.Schema<ZoneTagsGetResultStreamLiveInput>;
export type ZoneTagsGetResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultStreamVideoTagsMap: S.Schema<ZoneTagsGetResultStreamVideoTagsMap>;
export type ZoneTagsGetResultStreamVideoType = "stream_video";
export declare const ZoneTagsGetResultStreamVideoType: any;
export interface ZoneTagsGetResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultStreamVideoTagsMap;
    type: ZoneTagsGetResultStreamVideoType;
}
export declare const ZoneTagsGetResultStreamVideo: S.Schema<ZoneTagsGetResultStreamVideo>;
export type ZoneTagsGetResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultWorkerTagsMap: S.Schema<ZoneTagsGetResultWorkerTagsMap>;
export type ZoneTagsGetResultWorkerType = "worker";
export declare const ZoneTagsGetResultWorkerType: any;
export interface ZoneTagsGetResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultWorkerTagsMap;
    type: ZoneTagsGetResultWorkerType;
}
export declare const ZoneTagsGetResultWorker: S.Schema<ZoneTagsGetResultWorker>;
export type ZoneTagsGetResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultWorkerVersionTagsMap: S.Schema<ZoneTagsGetResultWorkerVersionTagsMap>;
export type ZoneTagsGetResultWorkerVersionType = "worker_version";
export declare const ZoneTagsGetResultWorkerVersionType: any;
export interface ZoneTagsGetResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultWorkerVersionTagsMap;
    type: ZoneTagsGetResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
}
export declare const ZoneTagsGetResultWorkerVersion: S.Schema<ZoneTagsGetResultWorkerVersion>;
export type ZoneTagsGetResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsGetResultZoneTagsMap: S.Schema<ZoneTagsGetResultZoneTagsMap>;
export type ZoneTagsGetResultZoneType = "zone";
export declare const ZoneTagsGetResultZoneType: any;
export interface ZoneTagsGetResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsGetResultZoneTagsMap;
    type: ZoneTagsGetResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsGetResultZone: S.Schema<ZoneTagsGetResultZone>;
export type ZoneTagsGetResult = ZoneTagsGetResultAccessApplication | ZoneTagsGetResultAccessApplicationPolicy | ZoneTagsGetResultAccessGroup | ZoneTagsGetResultAccount | ZoneTagsGetResultAIGateway | ZoneTagsGetResultAlertingPolicy | ZoneTagsGetResultAlertingWebhook | ZoneTagsGetResultAPIGatewayOperation | ZoneTagsGetResultCloudflaredTunnel | ZoneTagsGetResultCustomCertificate | ZoneTagsGetResultCustomHostname | ZoneTagsGetResultD1Database | ZoneTagsGetResultDNSRecord | ZoneTagsGetResultDurableObjectNamespace | ZoneTagsGetResultGatewayList | ZoneTagsGetResultGatewayRule | ZoneTagsGetResultImage | ZoneTagsGetResultKVNamespace | ZoneTagsGetResultManagedClientCertificate | ZoneTagsGetResultQueue | ZoneTagsGetResultR2Bucket | ZoneTagsGetResultResourceShare | ZoneTagsGetResultStreamLiveInput | ZoneTagsGetResultStreamVideo | ZoneTagsGetResultWorker | ZoneTagsGetResultWorkerVersion | ZoneTagsGetResultZone;
export declare const ZoneTagsGetResult: any;
export type GetZoneTagResponse = ZoneTagsGetResult;
export declare const GetZoneTagResponse: S.Schema<GetZoneTagResponse>;
export interface ListKeysRequest {
    /** Identifier. */
    accountId: string;
    /** Cursor for pagination. */
    cursor?: string;
}
export declare const ListKeysRequest: S.Schema<ListKeysRequest>;
export type KeysListResultList = Array<string>;
export declare const KeysListResultList: S.Schema<KeysListResultList>;
export interface ListKeysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: KeysListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListKeysResponse: S.Schema<ListKeysResponse>;
export type ListRequestTagList = Array<string>;
export declare const ListRequestTagList: S.Schema<ListRequestTagList>;
export type ListRequestType = "access_application" | "access_application_policy" | "access_group" | "account" | "ai_gateway" | "alerting_policy" | "alerting_webhook" | "api_gateway_operation" | "cloudflared_tunnel" | "custom_certificate" | "custom_hostname" | "d1_database" | "dns_record" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "kv_namespace" | "managed_client_certificate" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "worker" | "worker_version" | "zone";
export declare const ListRequestType: any;
export type ListRequestTypeList = Array<ListRequestType | (string & {})>;
export declare const ListRequestTypeList: S.Schema<ListRequestTypeList>;
export interface ListResourceTaggingsRequest {
    /** Identifier. */
    accountId: string;
    /** Cursor for pagination. */
    cursor?: string;
    /** Filter resources by tag criteria. This parameter can be repeated multiple times, with AND logic between parameters. */
    tag?: ListRequestTagList;
    /** Filter by resource type. Can be repeated to filter by multiple types (OR logic). Example: ?type=zone&type=worker */
    type?: ListRequestTypeList;
}
export declare const ListResourceTaggingsRequest: S.Schema<ListResourceTaggingsRequest>;
export type ListResultItemAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAccessApplicationTagsMap: S.Schema<ListResultItemAccessApplicationTagsMap>;
export type ListResultItemAccessApplicationType = "access_application";
export declare const ListResultItemAccessApplicationType: any;
export interface ListResultItemAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAccessApplicationTagsMap;
    type: ListResultItemAccessApplicationType;
}
export declare const ListResultItemAccessApplication: S.Schema<ListResultItemAccessApplication>;
export type ListResultItemAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAccessApplicationPolicyTagsMap: S.Schema<ListResultItemAccessApplicationPolicyTagsMap>;
export type ListResultItemAccessApplicationPolicyType = "access_application_policy";
export declare const ListResultItemAccessApplicationPolicyType: any;
export interface ListResultItemAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAccessApplicationPolicyTagsMap;
    type: ListResultItemAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemAccessApplicationPolicy: S.Schema<ListResultItemAccessApplicationPolicy>;
export type ListResultItemAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAccessGroupTagsMap: S.Schema<ListResultItemAccessGroupTagsMap>;
export type ListResultItemAccessGroupType = "access_group";
export declare const ListResultItemAccessGroupType: any;
export interface ListResultItemAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAccessGroupTagsMap;
    type: ListResultItemAccessGroupType;
}
export declare const ListResultItemAccessGroup: S.Schema<ListResultItemAccessGroup>;
export type ListResultItemAccountTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAccountTagsMap: S.Schema<ListResultItemAccountTagsMap>;
export type ListResultItemAccountType = "account";
export declare const ListResultItemAccountType: any;
export interface ListResultItemAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAccountTagsMap;
    type: ListResultItemAccountType;
}
export declare const ListResultItemAccount: S.Schema<ListResultItemAccount>;
export type ListResultItemAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAIGatewayTagsMap: S.Schema<ListResultItemAIGatewayTagsMap>;
export type ListResultItemAIGatewayType = "ai_gateway";
export declare const ListResultItemAIGatewayType: any;
export interface ListResultItemAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAIGatewayTagsMap;
    type: ListResultItemAIGatewayType;
}
export declare const ListResultItemAIGateway: S.Schema<ListResultItemAIGateway>;
export type ListResultItemAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAlertingPolicyTagsMap: S.Schema<ListResultItemAlertingPolicyTagsMap>;
export type ListResultItemAlertingPolicyType = "alerting_policy";
export declare const ListResultItemAlertingPolicyType: any;
export interface ListResultItemAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAlertingPolicyTagsMap;
    type: ListResultItemAlertingPolicyType;
}
export declare const ListResultItemAlertingPolicy: S.Schema<ListResultItemAlertingPolicy>;
export type ListResultItemAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAlertingWebhookTagsMap: S.Schema<ListResultItemAlertingWebhookTagsMap>;
export type ListResultItemAlertingWebhookType = "alerting_webhook";
export declare const ListResultItemAlertingWebhookType: any;
export interface ListResultItemAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAlertingWebhookTagsMap;
    type: ListResultItemAlertingWebhookType;
}
export declare const ListResultItemAlertingWebhook: S.Schema<ListResultItemAlertingWebhook>;
export type ListResultItemAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemAPIGatewayOperationTagsMap: S.Schema<ListResultItemAPIGatewayOperationTagsMap>;
export type ListResultItemAPIGatewayOperationType = "api_gateway_operation";
export declare const ListResultItemAPIGatewayOperationType: any;
export interface ListResultItemAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemAPIGatewayOperationTagsMap;
    type: ListResultItemAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemAPIGatewayOperation: S.Schema<ListResultItemAPIGatewayOperation>;
export type ListResultItemCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemCloudflaredTunnelTagsMap: S.Schema<ListResultItemCloudflaredTunnelTagsMap>;
export type ListResultItemCloudflaredTunnelType = "cloudflared_tunnel";
export declare const ListResultItemCloudflaredTunnelType: any;
export interface ListResultItemCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemCloudflaredTunnelTagsMap;
    type: ListResultItemCloudflaredTunnelType;
}
export declare const ListResultItemCloudflaredTunnel: S.Schema<ListResultItemCloudflaredTunnel>;
export type ListResultItemCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemCustomCertificateTagsMap: S.Schema<ListResultItemCustomCertificateTagsMap>;
export type ListResultItemCustomCertificateType = "custom_certificate";
export declare const ListResultItemCustomCertificateType: any;
export interface ListResultItemCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemCustomCertificateTagsMap;
    type: ListResultItemCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemCustomCertificate: S.Schema<ListResultItemCustomCertificate>;
export type ListResultItemCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemCustomHostnameTagsMap: S.Schema<ListResultItemCustomHostnameTagsMap>;
export type ListResultItemCustomHostnameType = "custom_hostname";
export declare const ListResultItemCustomHostnameType: any;
export interface ListResultItemCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemCustomHostnameTagsMap;
    type: ListResultItemCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemCustomHostname: S.Schema<ListResultItemCustomHostname>;
export type ListResultItemD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemD1DatabaseTagsMap: S.Schema<ListResultItemD1DatabaseTagsMap>;
export type ListResultItemD1DatabaseType = "d1_database";
export declare const ListResultItemD1DatabaseType: any;
export interface ListResultItemD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemD1DatabaseTagsMap;
    type: ListResultItemD1DatabaseType;
}
export declare const ListResultItemD1Database: S.Schema<ListResultItemD1Database>;
export type ListResultItemDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemDNSRecordTagsMap: S.Schema<ListResultItemDNSRecordTagsMap>;
export type ListResultItemDNSRecordType = "dns_record";
export declare const ListResultItemDNSRecordType: any;
export interface ListResultItemDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemDNSRecordTagsMap;
    type: ListResultItemDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemDNSRecord: S.Schema<ListResultItemDNSRecord>;
export type ListResultItemDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemDurableObjectNamespaceTagsMap: S.Schema<ListResultItemDurableObjectNamespaceTagsMap>;
export type ListResultItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const ListResultItemDurableObjectNamespaceType: any;
export interface ListResultItemDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemDurableObjectNamespaceTagsMap;
    type: ListResultItemDurableObjectNamespaceType;
}
export declare const ListResultItemDurableObjectNamespace: S.Schema<ListResultItemDurableObjectNamespace>;
export type ListResultItemGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemGatewayListTagsMap: S.Schema<ListResultItemGatewayListTagsMap>;
export type ListResultItemGatewayListType = "gateway_list";
export declare const ListResultItemGatewayListType: any;
export interface ListResultItemGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemGatewayListTagsMap;
    type: ListResultItemGatewayListType;
}
export declare const ListResultItemGatewayList: S.Schema<ListResultItemGatewayList>;
export type ListResultItemGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemGatewayRuleTagsMap: S.Schema<ListResultItemGatewayRuleTagsMap>;
export type ListResultItemGatewayRuleType = "gateway_rule";
export declare const ListResultItemGatewayRuleType: any;
export interface ListResultItemGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemGatewayRuleTagsMap;
    type: ListResultItemGatewayRuleType;
}
export declare const ListResultItemGatewayRule: S.Schema<ListResultItemGatewayRule>;
export type ListResultItemImageTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemImageTagsMap: S.Schema<ListResultItemImageTagsMap>;
export type ListResultItemImageType = "image";
export declare const ListResultItemImageType: any;
export interface ListResultItemImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemImageTagsMap;
    type: ListResultItemImageType;
}
export declare const ListResultItemImage: S.Schema<ListResultItemImage>;
export type ListResultItemKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemKVNamespaceTagsMap: S.Schema<ListResultItemKVNamespaceTagsMap>;
export type ListResultItemKVNamespaceType = "kv_namespace";
export declare const ListResultItemKVNamespaceType: any;
export interface ListResultItemKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemKVNamespaceTagsMap;
    type: ListResultItemKVNamespaceType;
}
export declare const ListResultItemKVNamespace: S.Schema<ListResultItemKVNamespace>;
export type ListResultItemManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemManagedClientCertificateTagsMap: S.Schema<ListResultItemManagedClientCertificateTagsMap>;
export type ListResultItemManagedClientCertificateType = "managed_client_certificate";
export declare const ListResultItemManagedClientCertificateType: any;
export interface ListResultItemManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemManagedClientCertificateTagsMap;
    type: ListResultItemManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemManagedClientCertificate: S.Schema<ListResultItemManagedClientCertificate>;
export type ListResultItemQueueTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemQueueTagsMap: S.Schema<ListResultItemQueueTagsMap>;
export type ListResultItemQueueType = "queue";
export declare const ListResultItemQueueType: any;
export interface ListResultItemQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemQueueTagsMap;
    type: ListResultItemQueueType;
}
export declare const ListResultItemQueue: S.Schema<ListResultItemQueue>;
export type ListResultItemR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemR2BucketTagsMap: S.Schema<ListResultItemR2BucketTagsMap>;
export type ListResultItemR2BucketType = "r2_bucket";
export declare const ListResultItemR2BucketType: any;
export interface ListResultItemR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemR2BucketTagsMap;
    type: ListResultItemR2BucketType;
}
export declare const ListResultItemR2Bucket: S.Schema<ListResultItemR2Bucket>;
export type ListResultItemResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemResourceShareTagsMap: S.Schema<ListResultItemResourceShareTagsMap>;
export type ListResultItemResourceShareType = "resource_share";
export declare const ListResultItemResourceShareType: any;
export interface ListResultItemResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemResourceShareTagsMap;
    type: ListResultItemResourceShareType;
}
export declare const ListResultItemResourceShare: S.Schema<ListResultItemResourceShare>;
export type ListResultItemStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemStreamLiveInputTagsMap: S.Schema<ListResultItemStreamLiveInputTagsMap>;
export type ListResultItemStreamLiveInputType = "stream_live_input";
export declare const ListResultItemStreamLiveInputType: any;
export interface ListResultItemStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemStreamLiveInputTagsMap;
    type: ListResultItemStreamLiveInputType;
}
export declare const ListResultItemStreamLiveInput: S.Schema<ListResultItemStreamLiveInput>;
export type ListResultItemStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemStreamVideoTagsMap: S.Schema<ListResultItemStreamVideoTagsMap>;
export type ListResultItemStreamVideoType = "stream_video";
export declare const ListResultItemStreamVideoType: any;
export interface ListResultItemStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemStreamVideoTagsMap;
    type: ListResultItemStreamVideoType;
}
export declare const ListResultItemStreamVideo: S.Schema<ListResultItemStreamVideo>;
export type ListResultItemWorkerTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemWorkerTagsMap: S.Schema<ListResultItemWorkerTagsMap>;
export type ListResultItemWorkerType = "worker";
export declare const ListResultItemWorkerType: any;
export interface ListResultItemWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemWorkerTagsMap;
    type: ListResultItemWorkerType;
}
export declare const ListResultItemWorker: S.Schema<ListResultItemWorker>;
export type ListResultItemWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemWorkerVersionTagsMap: S.Schema<ListResultItemWorkerVersionTagsMap>;
export type ListResultItemWorkerVersionType = "worker_version";
export declare const ListResultItemWorkerVersionType: any;
export interface ListResultItemWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemWorkerVersionTagsMap;
    type: ListResultItemWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
}
export declare const ListResultItemWorkerVersion: S.Schema<ListResultItemWorkerVersion>;
export type ListResultItemZoneTagsMap = {
    [key: string]: string | undefined;
};
export declare const ListResultItemZoneTagsMap: S.Schema<ListResultItemZoneTagsMap>;
export type ListResultItemZoneType = "zone";
export declare const ListResultItemZoneType: any;
export interface ListResultItemZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ListResultItemZoneTagsMap;
    type: ListResultItemZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ListResultItemZone: S.Schema<ListResultItemZone>;
export type ListResultItem = ListResultItemAccessApplication | ListResultItemAccessApplicationPolicy | ListResultItemAccessGroup | ListResultItemAccount | ListResultItemAIGateway | ListResultItemAlertingPolicy | ListResultItemAlertingWebhook | ListResultItemAPIGatewayOperation | ListResultItemCloudflaredTunnel | ListResultItemCustomCertificate | ListResultItemCustomHostname | ListResultItemD1Database | ListResultItemDNSRecord | ListResultItemDurableObjectNamespace | ListResultItemGatewayList | ListResultItemGatewayRule | ListResultItemImage | ListResultItemKVNamespace | ListResultItemManagedClientCertificate | ListResultItemQueue | ListResultItemR2Bucket | ListResultItemResourceShare | ListResultItemStreamLiveInput | ListResultItemStreamVideo | ListResultItemWorker | ListResultItemWorkerVersion | ListResultItemZone;
export declare const ListResultItem: any;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListResourceTaggingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListResourceTaggingsResponse: S.Schema<ListResourceTaggingsResponse>;
export type ValuesListRequestType = "access_application" | "access_application_policy" | "access_group" | "account" | "ai_gateway" | "alerting_policy" | "alerting_webhook" | "api_gateway_operation" | "cloudflared_tunnel" | "custom_certificate" | "custom_hostname" | "d1_database" | "dns_record" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "kv_namespace" | "managed_client_certificate" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "worker" | "worker_version" | "zone";
export declare const ValuesListRequestType: any;
export interface ListValuesRequest {
    /** Identifier. */
    accountId: string;
    tagKey: string;
    /** Cursor for pagination. */
    cursor?: string;
    /** Filter by resource type. */
    type?: ValuesListRequestType | (string & {});
}
export declare const ListValuesRequest: S.Schema<ListValuesRequest>;
export type ValuesListResultList = Array<string>;
export declare const ValuesListResultList: S.Schema<ValuesListResultList>;
export interface ListValuesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ValuesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListValuesResponse: S.Schema<ListValuesResponse>;
export type AccountTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestAccountLevelWorkerVersion = "access_application" | "access_group" | "account" | "ai_gateway" | "alerting_policy" | "alerting_webhook" | "cloudflared_tunnel" | "d1_database" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "kv_namespace" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "worker" | "worker_version";
export declare const AccountTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestAccountLevelWorkerVersion: any;
export type AccountTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestAccountLevelBase = "access_application" | "access_group" | "account" | "ai_gateway" | "alerting_policy" | "alerting_webhook" | "cloudflared_tunnel" | "d1_database" | "durable_object_namespace" | "gateway_list" | "gateway_rule" | "image" | "kv_namespace" | "queue" | "r2_bucket" | "resource_share" | "stream_live_input" | "stream_video" | "worker";
export declare const AccountTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestAccountLevelBase: any;
export type AccountTagsUpdateRequestResourceType = AccountTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestAccountLevelWorkerVersion | (string & {}) | AccountTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestAccountLevelBase | (string & {});
export declare const AccountTagsUpdateRequestResourceType: any;
export type AccountTagsUpdateRequestTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateRequestTagsMap: S.Schema<AccountTagsUpdateRequestTagsMap>;
export interface PutAccountTagRequest {
    /** Identifier. */
    accountId: string;
    /** Identifies the unique resource. */
    resourceId: string;
    /** Enum for base account-level resource types (those with no extra required fields). */
    resourceType: AccountTagsUpdateRequestResourceType;
    /** Worker ID is required only for worker_version resources */
    workerId?: string;
    /** Contains key-value pairs of tags. */
    tags?: AccountTagsUpdateRequestTagsMap;
    ifMatch?: string;
}
export declare const PutAccountTagRequest: S.Schema<PutAccountTagRequest>;
export type AccountTagsUpdateResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAccessApplicationTagsMap: S.Schema<AccountTagsUpdateResultAccessApplicationTagsMap>;
export type AccountTagsUpdateResultAccessApplicationType = "access_application";
export declare const AccountTagsUpdateResultAccessApplicationType: any;
export interface AccountTagsUpdateResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAccessApplicationTagsMap;
    type: AccountTagsUpdateResultAccessApplicationType;
}
export declare const AccountTagsUpdateResultAccessApplication: S.Schema<AccountTagsUpdateResultAccessApplication>;
export type AccountTagsUpdateResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAccessApplicationPolicyTagsMap: S.Schema<AccountTagsUpdateResultAccessApplicationPolicyTagsMap>;
export type AccountTagsUpdateResultAccessApplicationPolicyType = "access_application_policy";
export declare const AccountTagsUpdateResultAccessApplicationPolicyType: any;
export interface AccountTagsUpdateResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAccessApplicationPolicyTagsMap;
    type: AccountTagsUpdateResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultAccessApplicationPolicy: S.Schema<AccountTagsUpdateResultAccessApplicationPolicy>;
export type AccountTagsUpdateResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAccessGroupTagsMap: S.Schema<AccountTagsUpdateResultAccessGroupTagsMap>;
export type AccountTagsUpdateResultAccessGroupType = "access_group";
export declare const AccountTagsUpdateResultAccessGroupType: any;
export interface AccountTagsUpdateResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAccessGroupTagsMap;
    type: AccountTagsUpdateResultAccessGroupType;
}
export declare const AccountTagsUpdateResultAccessGroup: S.Schema<AccountTagsUpdateResultAccessGroup>;
export type AccountTagsUpdateResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAccountTagsMap: S.Schema<AccountTagsUpdateResultAccountTagsMap>;
export type AccountTagsUpdateResultAccountType = "account";
export declare const AccountTagsUpdateResultAccountType: any;
export interface AccountTagsUpdateResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAccountTagsMap;
    type: AccountTagsUpdateResultAccountType;
}
export declare const AccountTagsUpdateResultAccount: S.Schema<AccountTagsUpdateResultAccount>;
export type AccountTagsUpdateResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAIGatewayTagsMap: S.Schema<AccountTagsUpdateResultAIGatewayTagsMap>;
export type AccountTagsUpdateResultAIGatewayType = "ai_gateway";
export declare const AccountTagsUpdateResultAIGatewayType: any;
export interface AccountTagsUpdateResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAIGatewayTagsMap;
    type: AccountTagsUpdateResultAIGatewayType;
}
export declare const AccountTagsUpdateResultAIGateway: S.Schema<AccountTagsUpdateResultAIGateway>;
export type AccountTagsUpdateResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAlertingPolicyTagsMap: S.Schema<AccountTagsUpdateResultAlertingPolicyTagsMap>;
export type AccountTagsUpdateResultAlertingPolicyType = "alerting_policy";
export declare const AccountTagsUpdateResultAlertingPolicyType: any;
export interface AccountTagsUpdateResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAlertingPolicyTagsMap;
    type: AccountTagsUpdateResultAlertingPolicyType;
}
export declare const AccountTagsUpdateResultAlertingPolicy: S.Schema<AccountTagsUpdateResultAlertingPolicy>;
export type AccountTagsUpdateResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAlertingWebhookTagsMap: S.Schema<AccountTagsUpdateResultAlertingWebhookTagsMap>;
export type AccountTagsUpdateResultAlertingWebhookType = "alerting_webhook";
export declare const AccountTagsUpdateResultAlertingWebhookType: any;
export interface AccountTagsUpdateResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAlertingWebhookTagsMap;
    type: AccountTagsUpdateResultAlertingWebhookType;
}
export declare const AccountTagsUpdateResultAlertingWebhook: S.Schema<AccountTagsUpdateResultAlertingWebhook>;
export type AccountTagsUpdateResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultAPIGatewayOperationTagsMap: S.Schema<AccountTagsUpdateResultAPIGatewayOperationTagsMap>;
export type AccountTagsUpdateResultAPIGatewayOperationType = "api_gateway_operation";
export declare const AccountTagsUpdateResultAPIGatewayOperationType: any;
export interface AccountTagsUpdateResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultAPIGatewayOperationTagsMap;
    type: AccountTagsUpdateResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultAPIGatewayOperation: S.Schema<AccountTagsUpdateResultAPIGatewayOperation>;
export type AccountTagsUpdateResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultCloudflaredTunnelTagsMap: S.Schema<AccountTagsUpdateResultCloudflaredTunnelTagsMap>;
export type AccountTagsUpdateResultCloudflaredTunnelType = "cloudflared_tunnel";
export declare const AccountTagsUpdateResultCloudflaredTunnelType: any;
export interface AccountTagsUpdateResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultCloudflaredTunnelTagsMap;
    type: AccountTagsUpdateResultCloudflaredTunnelType;
}
export declare const AccountTagsUpdateResultCloudflaredTunnel: S.Schema<AccountTagsUpdateResultCloudflaredTunnel>;
export type AccountTagsUpdateResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultCustomCertificateTagsMap: S.Schema<AccountTagsUpdateResultCustomCertificateTagsMap>;
export type AccountTagsUpdateResultCustomCertificateType = "custom_certificate";
export declare const AccountTagsUpdateResultCustomCertificateType: any;
export interface AccountTagsUpdateResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultCustomCertificateTagsMap;
    type: AccountTagsUpdateResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultCustomCertificate: S.Schema<AccountTagsUpdateResultCustomCertificate>;
export type AccountTagsUpdateResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultCustomHostnameTagsMap: S.Schema<AccountTagsUpdateResultCustomHostnameTagsMap>;
export type AccountTagsUpdateResultCustomHostnameType = "custom_hostname";
export declare const AccountTagsUpdateResultCustomHostnameType: any;
export interface AccountTagsUpdateResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultCustomHostnameTagsMap;
    type: AccountTagsUpdateResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultCustomHostname: S.Schema<AccountTagsUpdateResultCustomHostname>;
export type AccountTagsUpdateResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultD1DatabaseTagsMap: S.Schema<AccountTagsUpdateResultD1DatabaseTagsMap>;
export type AccountTagsUpdateResultD1DatabaseType = "d1_database";
export declare const AccountTagsUpdateResultD1DatabaseType: any;
export interface AccountTagsUpdateResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultD1DatabaseTagsMap;
    type: AccountTagsUpdateResultD1DatabaseType;
}
export declare const AccountTagsUpdateResultD1Database: S.Schema<AccountTagsUpdateResultD1Database>;
export type AccountTagsUpdateResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultDNSRecordTagsMap: S.Schema<AccountTagsUpdateResultDNSRecordTagsMap>;
export type AccountTagsUpdateResultDNSRecordType = "dns_record";
export declare const AccountTagsUpdateResultDNSRecordType: any;
export interface AccountTagsUpdateResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultDNSRecordTagsMap;
    type: AccountTagsUpdateResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultDNSRecord: S.Schema<AccountTagsUpdateResultDNSRecord>;
export type AccountTagsUpdateResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultDurableObjectNamespaceTagsMap: S.Schema<AccountTagsUpdateResultDurableObjectNamespaceTagsMap>;
export type AccountTagsUpdateResultDurableObjectNamespaceType = "durable_object_namespace";
export declare const AccountTagsUpdateResultDurableObjectNamespaceType: any;
export interface AccountTagsUpdateResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultDurableObjectNamespaceTagsMap;
    type: AccountTagsUpdateResultDurableObjectNamespaceType;
}
export declare const AccountTagsUpdateResultDurableObjectNamespace: S.Schema<AccountTagsUpdateResultDurableObjectNamespace>;
export type AccountTagsUpdateResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultGatewayListTagsMap: S.Schema<AccountTagsUpdateResultGatewayListTagsMap>;
export type AccountTagsUpdateResultGatewayListType = "gateway_list";
export declare const AccountTagsUpdateResultGatewayListType: any;
export interface AccountTagsUpdateResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultGatewayListTagsMap;
    type: AccountTagsUpdateResultGatewayListType;
}
export declare const AccountTagsUpdateResultGatewayList: S.Schema<AccountTagsUpdateResultGatewayList>;
export type AccountTagsUpdateResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultGatewayRuleTagsMap: S.Schema<AccountTagsUpdateResultGatewayRuleTagsMap>;
export type AccountTagsUpdateResultGatewayRuleType = "gateway_rule";
export declare const AccountTagsUpdateResultGatewayRuleType: any;
export interface AccountTagsUpdateResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultGatewayRuleTagsMap;
    type: AccountTagsUpdateResultGatewayRuleType;
}
export declare const AccountTagsUpdateResultGatewayRule: S.Schema<AccountTagsUpdateResultGatewayRule>;
export type AccountTagsUpdateResultImageTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultImageTagsMap: S.Schema<AccountTagsUpdateResultImageTagsMap>;
export type AccountTagsUpdateResultImageType = "image";
export declare const AccountTagsUpdateResultImageType: any;
export interface AccountTagsUpdateResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultImageTagsMap;
    type: AccountTagsUpdateResultImageType;
}
export declare const AccountTagsUpdateResultImage: S.Schema<AccountTagsUpdateResultImage>;
export type AccountTagsUpdateResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultKVNamespaceTagsMap: S.Schema<AccountTagsUpdateResultKVNamespaceTagsMap>;
export type AccountTagsUpdateResultKVNamespaceType = "kv_namespace";
export declare const AccountTagsUpdateResultKVNamespaceType: any;
export interface AccountTagsUpdateResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultKVNamespaceTagsMap;
    type: AccountTagsUpdateResultKVNamespaceType;
}
export declare const AccountTagsUpdateResultKVNamespace: S.Schema<AccountTagsUpdateResultKVNamespace>;
export type AccountTagsUpdateResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultManagedClientCertificateTagsMap: S.Schema<AccountTagsUpdateResultManagedClientCertificateTagsMap>;
export type AccountTagsUpdateResultManagedClientCertificateType = "managed_client_certificate";
export declare const AccountTagsUpdateResultManagedClientCertificateType: any;
export interface AccountTagsUpdateResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultManagedClientCertificateTagsMap;
    type: AccountTagsUpdateResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultManagedClientCertificate: S.Schema<AccountTagsUpdateResultManagedClientCertificate>;
export type AccountTagsUpdateResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultQueueTagsMap: S.Schema<AccountTagsUpdateResultQueueTagsMap>;
export type AccountTagsUpdateResultQueueType = "queue";
export declare const AccountTagsUpdateResultQueueType: any;
export interface AccountTagsUpdateResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultQueueTagsMap;
    type: AccountTagsUpdateResultQueueType;
}
export declare const AccountTagsUpdateResultQueue: S.Schema<AccountTagsUpdateResultQueue>;
export type AccountTagsUpdateResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultR2BucketTagsMap: S.Schema<AccountTagsUpdateResultR2BucketTagsMap>;
export type AccountTagsUpdateResultR2BucketType = "r2_bucket";
export declare const AccountTagsUpdateResultR2BucketType: any;
export interface AccountTagsUpdateResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultR2BucketTagsMap;
    type: AccountTagsUpdateResultR2BucketType;
}
export declare const AccountTagsUpdateResultR2Bucket: S.Schema<AccountTagsUpdateResultR2Bucket>;
export type AccountTagsUpdateResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultResourceShareTagsMap: S.Schema<AccountTagsUpdateResultResourceShareTagsMap>;
export type AccountTagsUpdateResultResourceShareType = "resource_share";
export declare const AccountTagsUpdateResultResourceShareType: any;
export interface AccountTagsUpdateResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultResourceShareTagsMap;
    type: AccountTagsUpdateResultResourceShareType;
}
export declare const AccountTagsUpdateResultResourceShare: S.Schema<AccountTagsUpdateResultResourceShare>;
export type AccountTagsUpdateResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultStreamLiveInputTagsMap: S.Schema<AccountTagsUpdateResultStreamLiveInputTagsMap>;
export type AccountTagsUpdateResultStreamLiveInputType = "stream_live_input";
export declare const AccountTagsUpdateResultStreamLiveInputType: any;
export interface AccountTagsUpdateResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultStreamLiveInputTagsMap;
    type: AccountTagsUpdateResultStreamLiveInputType;
}
export declare const AccountTagsUpdateResultStreamLiveInput: S.Schema<AccountTagsUpdateResultStreamLiveInput>;
export type AccountTagsUpdateResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultStreamVideoTagsMap: S.Schema<AccountTagsUpdateResultStreamVideoTagsMap>;
export type AccountTagsUpdateResultStreamVideoType = "stream_video";
export declare const AccountTagsUpdateResultStreamVideoType: any;
export interface AccountTagsUpdateResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultStreamVideoTagsMap;
    type: AccountTagsUpdateResultStreamVideoType;
}
export declare const AccountTagsUpdateResultStreamVideo: S.Schema<AccountTagsUpdateResultStreamVideo>;
export type AccountTagsUpdateResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultWorkerTagsMap: S.Schema<AccountTagsUpdateResultWorkerTagsMap>;
export type AccountTagsUpdateResultWorkerType = "worker";
export declare const AccountTagsUpdateResultWorkerType: any;
export interface AccountTagsUpdateResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultWorkerTagsMap;
    type: AccountTagsUpdateResultWorkerType;
}
export declare const AccountTagsUpdateResultWorker: S.Schema<AccountTagsUpdateResultWorker>;
export type AccountTagsUpdateResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultWorkerVersionTagsMap: S.Schema<AccountTagsUpdateResultWorkerVersionTagsMap>;
export type AccountTagsUpdateResultWorkerVersionType = "worker_version";
export declare const AccountTagsUpdateResultWorkerVersionType: any;
export interface AccountTagsUpdateResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultWorkerVersionTagsMap;
    type: AccountTagsUpdateResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
}
export declare const AccountTagsUpdateResultWorkerVersion: S.Schema<AccountTagsUpdateResultWorkerVersion>;
export type AccountTagsUpdateResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export declare const AccountTagsUpdateResultZoneTagsMap: S.Schema<AccountTagsUpdateResultZoneTagsMap>;
export type AccountTagsUpdateResultZoneType = "zone";
export declare const AccountTagsUpdateResultZoneType: any;
export interface AccountTagsUpdateResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: AccountTagsUpdateResultZoneTagsMap;
    type: AccountTagsUpdateResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const AccountTagsUpdateResultZone: S.Schema<AccountTagsUpdateResultZone>;
export type AccountTagsUpdateResult = AccountTagsUpdateResultAccessApplication | AccountTagsUpdateResultAccessApplicationPolicy | AccountTagsUpdateResultAccessGroup | AccountTagsUpdateResultAccount | AccountTagsUpdateResultAIGateway | AccountTagsUpdateResultAlertingPolicy | AccountTagsUpdateResultAlertingWebhook | AccountTagsUpdateResultAPIGatewayOperation | AccountTagsUpdateResultCloudflaredTunnel | AccountTagsUpdateResultCustomCertificate | AccountTagsUpdateResultCustomHostname | AccountTagsUpdateResultD1Database | AccountTagsUpdateResultDNSRecord | AccountTagsUpdateResultDurableObjectNamespace | AccountTagsUpdateResultGatewayList | AccountTagsUpdateResultGatewayRule | AccountTagsUpdateResultImage | AccountTagsUpdateResultKVNamespace | AccountTagsUpdateResultManagedClientCertificate | AccountTagsUpdateResultQueue | AccountTagsUpdateResultR2Bucket | AccountTagsUpdateResultResourceShare | AccountTagsUpdateResultStreamLiveInput | AccountTagsUpdateResultStreamVideo | AccountTagsUpdateResultWorker | AccountTagsUpdateResultWorkerVersion | AccountTagsUpdateResultZone;
export declare const AccountTagsUpdateResult: any;
export type PutAccountTagResponse = AccountTagsUpdateResult;
export declare const PutAccountTagResponse: S.Schema<PutAccountTagResponse>;
export type ZoneTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestZoneLevelBase = "api_gateway_operation" | "custom_certificate" | "custom_hostname" | "dns_record" | "managed_client_certificate" | "zone";
export declare const ZoneTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestZoneLevelBase: any;
export type ZoneTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestZoneLevelAccessApplicationPolicy = "api_gateway_operation" | "custom_certificate" | "custom_hostname" | "dns_record" | "managed_client_certificate" | "zone" | "access_application_policy";
export declare const ZoneTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestZoneLevelAccessApplicationPolicy: any;
export type ZoneTagsUpdateRequestResourceType = ZoneTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestZoneLevelBase | (string & {}) | ZoneTagsUpdateRequestResourceTypeResourceTaggingSetTagsRequestZoneLevelAccessApplicationPolicy | (string & {});
export declare const ZoneTagsUpdateRequestResourceType: any;
export type ZoneTagsUpdateRequestTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateRequestTagsMap: S.Schema<ZoneTagsUpdateRequestTagsMap>;
export interface PutZoneTagRequest {
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
    /** Identifies the unique resource. */
    resourceId: string;
    /** Enum for base zone-level resource types (those with no extra required fields). */
    resourceType: ZoneTagsUpdateRequestResourceType;
    /** Contains key-value pairs of tags. */
    tags?: ZoneTagsUpdateRequestTagsMap;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId?: string;
    ifMatch?: string;
}
export declare const PutZoneTagRequest: S.Schema<PutZoneTagRequest>;
export type ZoneTagsUpdateResultAccessApplicationTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAccessApplicationTagsMap: S.Schema<ZoneTagsUpdateResultAccessApplicationTagsMap>;
export type ZoneTagsUpdateResultAccessApplicationType = "access_application";
export declare const ZoneTagsUpdateResultAccessApplicationType: any;
export interface ZoneTagsUpdateResultAccessApplication {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAccessApplicationTagsMap;
    type: ZoneTagsUpdateResultAccessApplicationType;
}
export declare const ZoneTagsUpdateResultAccessApplication: S.Schema<ZoneTagsUpdateResultAccessApplication>;
export type ZoneTagsUpdateResultAccessApplicationPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAccessApplicationPolicyTagsMap: S.Schema<ZoneTagsUpdateResultAccessApplicationPolicyTagsMap>;
export type ZoneTagsUpdateResultAccessApplicationPolicyType = "access_application_policy";
export declare const ZoneTagsUpdateResultAccessApplicationPolicyType: any;
export interface ZoneTagsUpdateResultAccessApplicationPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** Access application ID is required only for access_application_policy resources */
    accessApplicationId: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAccessApplicationPolicyTagsMap;
    type: ZoneTagsUpdateResultAccessApplicationPolicyType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultAccessApplicationPolicy: S.Schema<ZoneTagsUpdateResultAccessApplicationPolicy>;
export type ZoneTagsUpdateResultAccessGroupTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAccessGroupTagsMap: S.Schema<ZoneTagsUpdateResultAccessGroupTagsMap>;
export type ZoneTagsUpdateResultAccessGroupType = "access_group";
export declare const ZoneTagsUpdateResultAccessGroupType: any;
export interface ZoneTagsUpdateResultAccessGroup {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAccessGroupTagsMap;
    type: ZoneTagsUpdateResultAccessGroupType;
}
export declare const ZoneTagsUpdateResultAccessGroup: S.Schema<ZoneTagsUpdateResultAccessGroup>;
export type ZoneTagsUpdateResultAccountTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAccountTagsMap: S.Schema<ZoneTagsUpdateResultAccountTagsMap>;
export type ZoneTagsUpdateResultAccountType = "account";
export declare const ZoneTagsUpdateResultAccountType: any;
export interface ZoneTagsUpdateResultAccount {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAccountTagsMap;
    type: ZoneTagsUpdateResultAccountType;
}
export declare const ZoneTagsUpdateResultAccount: S.Schema<ZoneTagsUpdateResultAccount>;
export type ZoneTagsUpdateResultAIGatewayTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAIGatewayTagsMap: S.Schema<ZoneTagsUpdateResultAIGatewayTagsMap>;
export type ZoneTagsUpdateResultAIGatewayType = "ai_gateway";
export declare const ZoneTagsUpdateResultAIGatewayType: any;
export interface ZoneTagsUpdateResultAIGateway {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAIGatewayTagsMap;
    type: ZoneTagsUpdateResultAIGatewayType;
}
export declare const ZoneTagsUpdateResultAIGateway: S.Schema<ZoneTagsUpdateResultAIGateway>;
export type ZoneTagsUpdateResultAlertingPolicyTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAlertingPolicyTagsMap: S.Schema<ZoneTagsUpdateResultAlertingPolicyTagsMap>;
export type ZoneTagsUpdateResultAlertingPolicyType = "alerting_policy";
export declare const ZoneTagsUpdateResultAlertingPolicyType: any;
export interface ZoneTagsUpdateResultAlertingPolicy {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAlertingPolicyTagsMap;
    type: ZoneTagsUpdateResultAlertingPolicyType;
}
export declare const ZoneTagsUpdateResultAlertingPolicy: S.Schema<ZoneTagsUpdateResultAlertingPolicy>;
export type ZoneTagsUpdateResultAlertingWebhookTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAlertingWebhookTagsMap: S.Schema<ZoneTagsUpdateResultAlertingWebhookTagsMap>;
export type ZoneTagsUpdateResultAlertingWebhookType = "alerting_webhook";
export declare const ZoneTagsUpdateResultAlertingWebhookType: any;
export interface ZoneTagsUpdateResultAlertingWebhook {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAlertingWebhookTagsMap;
    type: ZoneTagsUpdateResultAlertingWebhookType;
}
export declare const ZoneTagsUpdateResultAlertingWebhook: S.Schema<ZoneTagsUpdateResultAlertingWebhook>;
export type ZoneTagsUpdateResultAPIGatewayOperationTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultAPIGatewayOperationTagsMap: S.Schema<ZoneTagsUpdateResultAPIGatewayOperationTagsMap>;
export type ZoneTagsUpdateResultAPIGatewayOperationType = "api_gateway_operation";
export declare const ZoneTagsUpdateResultAPIGatewayOperationType: any;
export interface ZoneTagsUpdateResultAPIGatewayOperation {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultAPIGatewayOperationTagsMap;
    type: ZoneTagsUpdateResultAPIGatewayOperationType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultAPIGatewayOperation: S.Schema<ZoneTagsUpdateResultAPIGatewayOperation>;
export type ZoneTagsUpdateResultCloudflaredTunnelTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultCloudflaredTunnelTagsMap: S.Schema<ZoneTagsUpdateResultCloudflaredTunnelTagsMap>;
export type ZoneTagsUpdateResultCloudflaredTunnelType = "cloudflared_tunnel";
export declare const ZoneTagsUpdateResultCloudflaredTunnelType: any;
export interface ZoneTagsUpdateResultCloudflaredTunnel {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultCloudflaredTunnelTagsMap;
    type: ZoneTagsUpdateResultCloudflaredTunnelType;
}
export declare const ZoneTagsUpdateResultCloudflaredTunnel: S.Schema<ZoneTagsUpdateResultCloudflaredTunnel>;
export type ZoneTagsUpdateResultCustomCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultCustomCertificateTagsMap: S.Schema<ZoneTagsUpdateResultCustomCertificateTagsMap>;
export type ZoneTagsUpdateResultCustomCertificateType = "custom_certificate";
export declare const ZoneTagsUpdateResultCustomCertificateType: any;
export interface ZoneTagsUpdateResultCustomCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultCustomCertificateTagsMap;
    type: ZoneTagsUpdateResultCustomCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultCustomCertificate: S.Schema<ZoneTagsUpdateResultCustomCertificate>;
export type ZoneTagsUpdateResultCustomHostnameTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultCustomHostnameTagsMap: S.Schema<ZoneTagsUpdateResultCustomHostnameTagsMap>;
export type ZoneTagsUpdateResultCustomHostnameType = "custom_hostname";
export declare const ZoneTagsUpdateResultCustomHostnameType: any;
export interface ZoneTagsUpdateResultCustomHostname {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultCustomHostnameTagsMap;
    type: ZoneTagsUpdateResultCustomHostnameType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultCustomHostname: S.Schema<ZoneTagsUpdateResultCustomHostname>;
export type ZoneTagsUpdateResultD1DatabaseTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultD1DatabaseTagsMap: S.Schema<ZoneTagsUpdateResultD1DatabaseTagsMap>;
export type ZoneTagsUpdateResultD1DatabaseType = "d1_database";
export declare const ZoneTagsUpdateResultD1DatabaseType: any;
export interface ZoneTagsUpdateResultD1Database {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultD1DatabaseTagsMap;
    type: ZoneTagsUpdateResultD1DatabaseType;
}
export declare const ZoneTagsUpdateResultD1Database: S.Schema<ZoneTagsUpdateResultD1Database>;
export type ZoneTagsUpdateResultDNSRecordTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultDNSRecordTagsMap: S.Schema<ZoneTagsUpdateResultDNSRecordTagsMap>;
export type ZoneTagsUpdateResultDNSRecordType = "dns_record";
export declare const ZoneTagsUpdateResultDNSRecordType: any;
export interface ZoneTagsUpdateResultDNSRecord {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultDNSRecordTagsMap;
    type: ZoneTagsUpdateResultDNSRecordType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultDNSRecord: S.Schema<ZoneTagsUpdateResultDNSRecord>;
export type ZoneTagsUpdateResultDurableObjectNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultDurableObjectNamespaceTagsMap: S.Schema<ZoneTagsUpdateResultDurableObjectNamespaceTagsMap>;
export type ZoneTagsUpdateResultDurableObjectNamespaceType = "durable_object_namespace";
export declare const ZoneTagsUpdateResultDurableObjectNamespaceType: any;
export interface ZoneTagsUpdateResultDurableObjectNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultDurableObjectNamespaceTagsMap;
    type: ZoneTagsUpdateResultDurableObjectNamespaceType;
}
export declare const ZoneTagsUpdateResultDurableObjectNamespace: S.Schema<ZoneTagsUpdateResultDurableObjectNamespace>;
export type ZoneTagsUpdateResultGatewayListTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultGatewayListTagsMap: S.Schema<ZoneTagsUpdateResultGatewayListTagsMap>;
export type ZoneTagsUpdateResultGatewayListType = "gateway_list";
export declare const ZoneTagsUpdateResultGatewayListType: any;
export interface ZoneTagsUpdateResultGatewayList {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultGatewayListTagsMap;
    type: ZoneTagsUpdateResultGatewayListType;
}
export declare const ZoneTagsUpdateResultGatewayList: S.Schema<ZoneTagsUpdateResultGatewayList>;
export type ZoneTagsUpdateResultGatewayRuleTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultGatewayRuleTagsMap: S.Schema<ZoneTagsUpdateResultGatewayRuleTagsMap>;
export type ZoneTagsUpdateResultGatewayRuleType = "gateway_rule";
export declare const ZoneTagsUpdateResultGatewayRuleType: any;
export interface ZoneTagsUpdateResultGatewayRule {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultGatewayRuleTagsMap;
    type: ZoneTagsUpdateResultGatewayRuleType;
}
export declare const ZoneTagsUpdateResultGatewayRule: S.Schema<ZoneTagsUpdateResultGatewayRule>;
export type ZoneTagsUpdateResultImageTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultImageTagsMap: S.Schema<ZoneTagsUpdateResultImageTagsMap>;
export type ZoneTagsUpdateResultImageType = "image";
export declare const ZoneTagsUpdateResultImageType: any;
export interface ZoneTagsUpdateResultImage {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultImageTagsMap;
    type: ZoneTagsUpdateResultImageType;
}
export declare const ZoneTagsUpdateResultImage: S.Schema<ZoneTagsUpdateResultImage>;
export type ZoneTagsUpdateResultKVNamespaceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultKVNamespaceTagsMap: S.Schema<ZoneTagsUpdateResultKVNamespaceTagsMap>;
export type ZoneTagsUpdateResultKVNamespaceType = "kv_namespace";
export declare const ZoneTagsUpdateResultKVNamespaceType: any;
export interface ZoneTagsUpdateResultKVNamespace {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultKVNamespaceTagsMap;
    type: ZoneTagsUpdateResultKVNamespaceType;
}
export declare const ZoneTagsUpdateResultKVNamespace: S.Schema<ZoneTagsUpdateResultKVNamespace>;
export type ZoneTagsUpdateResultManagedClientCertificateTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultManagedClientCertificateTagsMap: S.Schema<ZoneTagsUpdateResultManagedClientCertificateTagsMap>;
export type ZoneTagsUpdateResultManagedClientCertificateType = "managed_client_certificate";
export declare const ZoneTagsUpdateResultManagedClientCertificateType: any;
export interface ZoneTagsUpdateResultManagedClientCertificate {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultManagedClientCertificateTagsMap;
    type: ZoneTagsUpdateResultManagedClientCertificateType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultManagedClientCertificate: S.Schema<ZoneTagsUpdateResultManagedClientCertificate>;
export type ZoneTagsUpdateResultQueueTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultQueueTagsMap: S.Schema<ZoneTagsUpdateResultQueueTagsMap>;
export type ZoneTagsUpdateResultQueueType = "queue";
export declare const ZoneTagsUpdateResultQueueType: any;
export interface ZoneTagsUpdateResultQueue {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultQueueTagsMap;
    type: ZoneTagsUpdateResultQueueType;
}
export declare const ZoneTagsUpdateResultQueue: S.Schema<ZoneTagsUpdateResultQueue>;
export type ZoneTagsUpdateResultR2BucketTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultR2BucketTagsMap: S.Schema<ZoneTagsUpdateResultR2BucketTagsMap>;
export type ZoneTagsUpdateResultR2BucketType = "r2_bucket";
export declare const ZoneTagsUpdateResultR2BucketType: any;
export interface ZoneTagsUpdateResultR2Bucket {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultR2BucketTagsMap;
    type: ZoneTagsUpdateResultR2BucketType;
}
export declare const ZoneTagsUpdateResultR2Bucket: S.Schema<ZoneTagsUpdateResultR2Bucket>;
export type ZoneTagsUpdateResultResourceShareTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultResourceShareTagsMap: S.Schema<ZoneTagsUpdateResultResourceShareTagsMap>;
export type ZoneTagsUpdateResultResourceShareType = "resource_share";
export declare const ZoneTagsUpdateResultResourceShareType: any;
export interface ZoneTagsUpdateResultResourceShare {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultResourceShareTagsMap;
    type: ZoneTagsUpdateResultResourceShareType;
}
export declare const ZoneTagsUpdateResultResourceShare: S.Schema<ZoneTagsUpdateResultResourceShare>;
export type ZoneTagsUpdateResultStreamLiveInputTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultStreamLiveInputTagsMap: S.Schema<ZoneTagsUpdateResultStreamLiveInputTagsMap>;
export type ZoneTagsUpdateResultStreamLiveInputType = "stream_live_input";
export declare const ZoneTagsUpdateResultStreamLiveInputType: any;
export interface ZoneTagsUpdateResultStreamLiveInput {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultStreamLiveInputTagsMap;
    type: ZoneTagsUpdateResultStreamLiveInputType;
}
export declare const ZoneTagsUpdateResultStreamLiveInput: S.Schema<ZoneTagsUpdateResultStreamLiveInput>;
export type ZoneTagsUpdateResultStreamVideoTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultStreamVideoTagsMap: S.Schema<ZoneTagsUpdateResultStreamVideoTagsMap>;
export type ZoneTagsUpdateResultStreamVideoType = "stream_video";
export declare const ZoneTagsUpdateResultStreamVideoType: any;
export interface ZoneTagsUpdateResultStreamVideo {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultStreamVideoTagsMap;
    type: ZoneTagsUpdateResultStreamVideoType;
}
export declare const ZoneTagsUpdateResultStreamVideo: S.Schema<ZoneTagsUpdateResultStreamVideo>;
export type ZoneTagsUpdateResultWorkerTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultWorkerTagsMap: S.Schema<ZoneTagsUpdateResultWorkerTagsMap>;
export type ZoneTagsUpdateResultWorkerType = "worker";
export declare const ZoneTagsUpdateResultWorkerType: any;
export interface ZoneTagsUpdateResultWorker {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultWorkerTagsMap;
    type: ZoneTagsUpdateResultWorkerType;
}
export declare const ZoneTagsUpdateResultWorker: S.Schema<ZoneTagsUpdateResultWorker>;
export type ZoneTagsUpdateResultWorkerVersionTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultWorkerVersionTagsMap: S.Schema<ZoneTagsUpdateResultWorkerVersionTagsMap>;
export type ZoneTagsUpdateResultWorkerVersionType = "worker_version";
export declare const ZoneTagsUpdateResultWorkerVersionType: any;
export interface ZoneTagsUpdateResultWorkerVersion {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultWorkerVersionTagsMap;
    type: ZoneTagsUpdateResultWorkerVersionType;
    /** Worker ID is required only for worker_version resources */
    workerId: string;
}
export declare const ZoneTagsUpdateResultWorkerVersion: S.Schema<ZoneTagsUpdateResultWorkerVersion>;
export type ZoneTagsUpdateResultZoneTagsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneTagsUpdateResultZoneTagsMap: S.Schema<ZoneTagsUpdateResultZoneTagsMap>;
export type ZoneTagsUpdateResultZoneType = "zone";
export declare const ZoneTagsUpdateResultZoneType: any;
export interface ZoneTagsUpdateResultZone {
    /** Identifies the unique resource. */
    id: string;
    /** ETag identifier for optimistic concurrency control. Formatted as "v1:<hash>" where */
    etag: string;
    /** Human-readable name of the resource. */
    name: string;
    /** Contains key-value pairs of tags. */
    tags: ZoneTagsUpdateResultZoneTagsMap;
    type: ZoneTagsUpdateResultZoneType;
    /** Zone ID is required only for zone-level resources */
    zoneId: string;
}
export declare const ZoneTagsUpdateResultZone: S.Schema<ZoneTagsUpdateResultZone>;
export type ZoneTagsUpdateResult = ZoneTagsUpdateResultAccessApplication | ZoneTagsUpdateResultAccessApplicationPolicy | ZoneTagsUpdateResultAccessGroup | ZoneTagsUpdateResultAccount | ZoneTagsUpdateResultAIGateway | ZoneTagsUpdateResultAlertingPolicy | ZoneTagsUpdateResultAlertingWebhook | ZoneTagsUpdateResultAPIGatewayOperation | ZoneTagsUpdateResultCloudflaredTunnel | ZoneTagsUpdateResultCustomCertificate | ZoneTagsUpdateResultCustomHostname | ZoneTagsUpdateResultD1Database | ZoneTagsUpdateResultDNSRecord | ZoneTagsUpdateResultDurableObjectNamespace | ZoneTagsUpdateResultGatewayList | ZoneTagsUpdateResultGatewayRule | ZoneTagsUpdateResultImage | ZoneTagsUpdateResultKVNamespace | ZoneTagsUpdateResultManagedClientCertificate | ZoneTagsUpdateResultQueue | ZoneTagsUpdateResultR2Bucket | ZoneTagsUpdateResultResourceShare | ZoneTagsUpdateResultStreamLiveInput | ZoneTagsUpdateResultStreamVideo | ZoneTagsUpdateResultWorker | ZoneTagsUpdateResultWorkerVersion | ZoneTagsUpdateResultZone;
export declare const ZoneTagsUpdateResult: any;
export type PutZoneTagResponse = ZoneTagsUpdateResult;
export declare const PutZoneTagResponse: S.Schema<PutZoneTagResponse>;
export type DeleteAccountTagError = Forbidden | CloudflareOpError;
/** Removes all tags from a specific account-level resource. */
export declare const deleteAccountTag: API.OperationMethod<DeleteAccountTagRequest, DeleteAccountTagResponse, DeleteAccountTagError, CloudflareOpContext>;
export type DeleteZoneTagError = Forbidden | CloudflareOpError;
/** Removes all tags from a specific zone-level resource. */
export declare const deleteZoneTag: API.OperationMethod<DeleteZoneTagRequest, DeleteZoneTagResponse, DeleteZoneTagError, CloudflareOpContext>;
export type GetAccountTagError = Forbidden | CloudflareOpError;
/** Retrieves tags for a specific account-level resource. */
export declare const getAccountTag: API.OperationMethod<GetAccountTagRequest, GetAccountTagResponse, GetAccountTagError, CloudflareOpContext>;
export type GetZoneTagError = ZoneTagResourceNotFound | Forbidden | CloudflareOpError;
/** Retrieves tags for a specific zone-level resource. */
export declare const getZoneTag: API.OperationMethod<GetZoneTagRequest, GetZoneTagResponse, GetZoneTagError, CloudflareOpContext>;
export type ListKeysError = CloudflareOpError;
/** Lists all distinct tag keys used across resources in an account. */
export declare const listKeys: API.PaginatedOperationMethod<ListKeysRequest, ListKeysResponse, ListKeysError, CloudflareOpContext, string>;
export type ListResourceTaggingsError = CloudflareOpError;
/** Lists all tagged resources for an account. */
export declare const listResourceTaggings: API.PaginatedOperationMethod<ListResourceTaggingsRequest, ListResourceTaggingsResponse, ListResourceTaggingsError, CloudflareOpContext, ListResultItem>;
export type ListValuesError = CloudflareOpError;
/** Lists all distinct values for a given tag key, optionally filtered by resource type. */
export declare const listValues: API.PaginatedOperationMethod<ListValuesRequest, ListValuesResponse, ListValuesError, CloudflareOpContext, string>;
export type PutAccountTagError = Forbidden | TagPreconditionFailed | CloudflareOpError;
/** Creates or updates tags for a specific account-level resource. */
export declare const putAccountTag: API.OperationMethod<PutAccountTagRequest, PutAccountTagResponse, PutAccountTagError, CloudflareOpContext>;
export type PutZoneTagError = ZoneTagResourceNotFound | Forbidden | TagPreconditionFailed | CloudflareOpError;
/** Creates or updates tags for a specific zone-level resource. Replaces all existing tags for the resource. */
export declare const putZoneTag: API.OperationMethod<PutZoneTagRequest, PutZoneTagResponse, PutZoneTagError, CloudflareOpContext>;
//# sourceMappingURL=resource_tagging.d.ts.map