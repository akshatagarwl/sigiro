import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CacheReserveClearStatusRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const CacheReserveClearStatusRequest: S.Schema<CacheReserveClearStatusRequest>;
export type CacheReserveClearStatusResponseId = "cache_reserve_clear";
export declare const CacheReserveClearStatusResponseId: any;
export type CacheReserveClearStatusResponseState = "In-progress" | "Completed";
export declare const CacheReserveClearStatusResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CacheReserveClearStatusResponse {
    /** ID of the zone setting. */
    id: CacheReserveClearStatusResponseId;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: CacheReserveClearStatusResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const CacheReserveClearStatusResponse: S.Schema<CacheReserveClearStatusResponse>;
export interface ClearCacheReserveClearRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ClearCacheReserveClearRequest: S.Schema<ClearCacheReserveClearRequest>;
export type ClearCacheReserveClearResponseId = "cache_reserve_clear";
export declare const ClearCacheReserveClearResponseId: any;
export type ClearCacheReserveClearResponseState = "In-progress" | "Completed";
export declare const ClearCacheReserveClearResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ClearCacheReserveClearResponse {
    /** ID of the zone setting. */
    id: ClearCacheReserveClearResponseId;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: ClearCacheReserveClearResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ClearCacheReserveClearResponse: S.Schema<ClearCacheReserveClearResponse>;
export type CreateHealthCheckRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const CreateHealthCheckRequestCheckRegionsItem: any;
export type CreateHealthCheckRequestCheckRegionsList = Array<CreateHealthCheckRequestCheckRegionsItem | (string & {})>;
export declare const CreateHealthCheckRequestCheckRegionsList: S.Schema<CreateHealthCheckRequestCheckRegionsList>;
export type CreateHealthCheckRequestHttpConfigExpectedCodesList = Array<string>;
export declare const CreateHealthCheckRequestHttpConfigExpectedCodesList: S.Schema<CreateHealthCheckRequestHttpConfigExpectedCodesList>;
export type CreateHealthCheckRequestHttpConfigHeaderValueList = Array<string>;
export declare const CreateHealthCheckRequestHttpConfigHeaderValueList: S.Schema<CreateHealthCheckRequestHttpConfigHeaderValueList>;
export type CreateHealthCheckRequestHttpConfigHeaderMap = {
    [key: string]: CreateHealthCheckRequestHttpConfigHeaderValueList | undefined;
};
export declare const CreateHealthCheckRequestHttpConfigHeaderMap: S.Schema<CreateHealthCheckRequestHttpConfigHeaderMap>;
export type CreateHealthCheckRequestHttpConfigMethod = "GET" | "HEAD";
export declare const CreateHealthCheckRequestHttpConfigMethod: any;
export interface CreateHealthCheckRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateHealthCheckRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateHealthCheckRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: CreateHealthCheckRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const CreateHealthCheckRequestHttpConfig: S.Schema<CreateHealthCheckRequestHttpConfig>;
export type CreateHealthCheckRequestTcpConfigMethod = "connection_established";
export declare const CreateHealthCheckRequestTcpConfigMethod: any;
export interface CreateHealthCheckRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateHealthCheckRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const CreateHealthCheckRequestTcpConfig: S.Schema<CreateHealthCheckRequestTcpConfig>;
export interface CreateHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateHealthCheckRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateHealthCheckRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateHealthCheckRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const CreateHealthCheckRequest: S.Schema<CreateHealthCheckRequest>;
export type CreateHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const CreateHealthCheckResponseCheckRegionsItem: any;
export type CreateHealthCheckResponseCheckRegionsList = Array<CreateHealthCheckResponseCheckRegionsItem>;
export declare const CreateHealthCheckResponseCheckRegionsList: S.Schema<CreateHealthCheckResponseCheckRegionsList>;
export type CreateHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export declare const CreateHealthCheckResponseHttpConfigExpectedCodesList: S.Schema<CreateHealthCheckResponseHttpConfigExpectedCodesList>;
export type CreateHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export declare const CreateHealthCheckResponseHttpConfigHeaderValueList: S.Schema<CreateHealthCheckResponseHttpConfigHeaderValueList>;
export type CreateHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: CreateHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export declare const CreateHealthCheckResponseHttpConfigHeaderMap: S.Schema<CreateHealthCheckResponseHttpConfigHeaderMap>;
export type CreateHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export declare const CreateHealthCheckResponseHttpConfigMethod: any;
export interface CreateHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: CreateHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const CreateHealthCheckResponseHttpConfig: S.Schema<CreateHealthCheckResponseHttpConfig>;
export type CreateHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const CreateHealthCheckResponseStatus: any;
export type CreateHealthCheckResponseTcpConfigMethod = "connection_established";
export declare const CreateHealthCheckResponseTcpConfigMethod: any;
export interface CreateHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const CreateHealthCheckResponseTcpConfig: S.Schema<CreateHealthCheckResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: CreateHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const CreateHealthCheckResponse: S.Schema<CreateHealthCheckResponse>;
export interface DeleteHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
}
export declare const DeleteHealthCheckRequest: S.Schema<DeleteHealthCheckRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteHealthCheckResponse: S.Schema<DeleteHealthCheckResponse>;
export type EditHealthCheckRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const EditHealthCheckRequestCheckRegionsItem: any;
export type EditHealthCheckRequestCheckRegionsList = Array<EditHealthCheckRequestCheckRegionsItem | (string & {})>;
export declare const EditHealthCheckRequestCheckRegionsList: S.Schema<EditHealthCheckRequestCheckRegionsList>;
export type EditHealthCheckRequestHttpConfigExpectedCodesList = Array<string>;
export declare const EditHealthCheckRequestHttpConfigExpectedCodesList: S.Schema<EditHealthCheckRequestHttpConfigExpectedCodesList>;
export type EditHealthCheckRequestHttpConfigHeaderValueList = Array<string>;
export declare const EditHealthCheckRequestHttpConfigHeaderValueList: S.Schema<EditHealthCheckRequestHttpConfigHeaderValueList>;
export type EditHealthCheckRequestHttpConfigHeaderMap = {
    [key: string]: EditHealthCheckRequestHttpConfigHeaderValueList | undefined;
};
export declare const EditHealthCheckRequestHttpConfigHeaderMap: S.Schema<EditHealthCheckRequestHttpConfigHeaderMap>;
export type EditHealthCheckRequestHttpConfigMethod = "GET" | "HEAD";
export declare const EditHealthCheckRequestHttpConfigMethod: any;
export interface EditHealthCheckRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditHealthCheckRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditHealthCheckRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: EditHealthCheckRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const EditHealthCheckRequestHttpConfig: S.Schema<EditHealthCheckRequestHttpConfig>;
export type EditHealthCheckRequestTcpConfigMethod = "connection_established";
export declare const EditHealthCheckRequestTcpConfigMethod: any;
export interface EditHealthCheckRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditHealthCheckRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const EditHealthCheckRequestTcpConfig: S.Schema<EditHealthCheckRequestTcpConfig>;
export interface EditHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditHealthCheckRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditHealthCheckRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditHealthCheckRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const EditHealthCheckRequest: S.Schema<EditHealthCheckRequest>;
export type EditHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const EditHealthCheckResponseCheckRegionsItem: any;
export type EditHealthCheckResponseCheckRegionsList = Array<EditHealthCheckResponseCheckRegionsItem>;
export declare const EditHealthCheckResponseCheckRegionsList: S.Schema<EditHealthCheckResponseCheckRegionsList>;
export type EditHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export declare const EditHealthCheckResponseHttpConfigExpectedCodesList: S.Schema<EditHealthCheckResponseHttpConfigExpectedCodesList>;
export type EditHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export declare const EditHealthCheckResponseHttpConfigHeaderValueList: S.Schema<EditHealthCheckResponseHttpConfigHeaderValueList>;
export type EditHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: EditHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export declare const EditHealthCheckResponseHttpConfigHeaderMap: S.Schema<EditHealthCheckResponseHttpConfigHeaderMap>;
export type EditHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export declare const EditHealthCheckResponseHttpConfigMethod: any;
export interface EditHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: EditHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const EditHealthCheckResponseHttpConfig: S.Schema<EditHealthCheckResponseHttpConfig>;
export type EditHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const EditHealthCheckResponseStatus: any;
export type EditHealthCheckResponseTcpConfigMethod = "connection_established";
export declare const EditHealthCheckResponseTcpConfigMethod: any;
export interface EditHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const EditHealthCheckResponseTcpConfig: S.Schema<EditHealthCheckResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: EditHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const EditHealthCheckResponse: S.Schema<EditHealthCheckResponse>;
export interface GetRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetRequest: S.Schema<GetRequest>;
export type GetResponseCacheReserveValue = "on" | "off";
export declare const GetResponseCacheReserveValue: any;
export interface GetResponseCacheReserve {
    /** The id of the Cache Reserve setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** Specifies the enablement value of Cache Reserve. */
    value?: GetResponseCacheReserveValue | null;
}
export declare const GetResponseCacheReserve: S.Schema<GetResponseCacheReserve>;
export type GetResponseRegionalTieredCacheValue = "on" | "off";
export declare const GetResponseRegionalTieredCacheValue: any;
export interface GetResponseRegionalTieredCache {
    /** The id of the Regional Tiered Cache setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** Specifies the enablement value of Cache Reserve. */
    value?: GetResponseRegionalTieredCacheValue | null;
}
export declare const GetResponseRegionalTieredCache: S.Schema<GetResponseRegionalTieredCache>;
export type GetResponseSmartRoutingValue = "on" | "off";
export declare const GetResponseSmartRoutingValue: any;
export interface GetResponseSmartRouting {
    /** The id of the Smart Routing setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** Specifies the enablement value of Argo Smart Routing. */
    value?: GetResponseSmartRoutingValue | null;
}
export declare const GetResponseSmartRouting: S.Schema<GetResponseSmartRouting>;
export type GetResponseSmartTieredCacheValue = "on" | "off";
export declare const GetResponseSmartTieredCacheValue: any;
export interface GetResponseSmartTieredCache {
    /** The id of the Smart Tiered Cache setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** The last time the setting was modified. */
    modifiedOn?: string | null;
    /** Specifies the enablement value of Tiered Cache. */
    value?: GetResponseSmartTieredCacheValue | null;
}
export declare const GetResponseSmartTieredCache: S.Schema<GetResponseSmartTieredCache>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    cacheReserve: GetResponseCacheReserve;
    /** The total number of health checks associated with the zone. */
    healthchecksCount: number;
    regionalTieredCache: GetResponseRegionalTieredCache;
    smartRouting: GetResponseSmartRouting;
    smartTieredCache: GetResponseSmartTieredCache;
}
export declare const GetResponse: S.Schema<GetResponse>;
export interface GetHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
}
export declare const GetHealthCheckRequest: S.Schema<GetHealthCheckRequest>;
export type GetHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const GetHealthCheckResponseCheckRegionsItem: any;
export type GetHealthCheckResponseCheckRegionsList = Array<GetHealthCheckResponseCheckRegionsItem>;
export declare const GetHealthCheckResponseCheckRegionsList: S.Schema<GetHealthCheckResponseCheckRegionsList>;
export type GetHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export declare const GetHealthCheckResponseHttpConfigExpectedCodesList: S.Schema<GetHealthCheckResponseHttpConfigExpectedCodesList>;
export type GetHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export declare const GetHealthCheckResponseHttpConfigHeaderValueList: S.Schema<GetHealthCheckResponseHttpConfigHeaderValueList>;
export type GetHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: GetHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export declare const GetHealthCheckResponseHttpConfigHeaderMap: S.Schema<GetHealthCheckResponseHttpConfigHeaderMap>;
export type GetHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export declare const GetHealthCheckResponseHttpConfigMethod: any;
export interface GetHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: GetHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: GetHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: GetHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const GetHealthCheckResponseHttpConfig: S.Schema<GetHealthCheckResponseHttpConfig>;
export type GetHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const GetHealthCheckResponseStatus: any;
export type GetHealthCheckResponseTcpConfigMethod = "connection_established";
export declare const GetHealthCheckResponseTcpConfigMethod: any;
export interface GetHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: GetHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const GetHealthCheckResponseTcpConfig: S.Schema<GetHealthCheckResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: GetHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: GetHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: GetHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: GetHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const GetHealthCheckResponse: S.Schema<GetHealthCheckResponse>;
export interface ListHealthChecksRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export declare const ListHealthChecksRequest: S.Schema<ListHealthChecksRequest>;
export type ListHealthChecksResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const ListHealthChecksResultItemCheckRegionsItem: any;
export type ListHealthChecksResultItemCheckRegionsList = Array<ListHealthChecksResultItemCheckRegionsItem>;
export declare const ListHealthChecksResultItemCheckRegionsList: S.Schema<ListHealthChecksResultItemCheckRegionsList>;
export type ListHealthChecksResultItemHttpConfigExpectedCodesList = Array<string>;
export declare const ListHealthChecksResultItemHttpConfigExpectedCodesList: S.Schema<ListHealthChecksResultItemHttpConfigExpectedCodesList>;
export type ListHealthChecksResultItemHttpConfigHeaderValueList = Array<string>;
export declare const ListHealthChecksResultItemHttpConfigHeaderValueList: S.Schema<ListHealthChecksResultItemHttpConfigHeaderValueList>;
export type ListHealthChecksResultItemHttpConfigHeaderMap = {
    [key: string]: ListHealthChecksResultItemHttpConfigHeaderValueList | undefined;
};
export declare const ListHealthChecksResultItemHttpConfigHeaderMap: S.Schema<ListHealthChecksResultItemHttpConfigHeaderMap>;
export type ListHealthChecksResultItemHttpConfigMethod = "GET" | "HEAD";
export declare const ListHealthChecksResultItemHttpConfigMethod: any;
export interface ListHealthChecksResultItemHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: ListHealthChecksResultItemHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: ListHealthChecksResultItemHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: ListHealthChecksResultItemHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const ListHealthChecksResultItemHttpConfig: S.Schema<ListHealthChecksResultItemHttpConfig>;
export type ListHealthChecksResultItemStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const ListHealthChecksResultItemStatus: any;
export type ListHealthChecksResultItemTcpConfigMethod = "connection_established";
export declare const ListHealthChecksResultItemTcpConfigMethod: any;
export interface ListHealthChecksResultItemTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: ListHealthChecksResultItemTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const ListHealthChecksResultItemTcpConfig: S.Schema<ListHealthChecksResultItemTcpConfig>;
export interface ListHealthChecksResultItem {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: ListHealthChecksResultItemCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: ListHealthChecksResultItemHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: ListHealthChecksResultItemStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: ListHealthChecksResultItemTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const ListHealthChecksResultItem: S.Schema<ListHealthChecksResultItem>;
export type ListHealthChecksResultList = Array<ListHealthChecksResultItem>;
export declare const ListHealthChecksResultList: S.Schema<ListHealthChecksResultList>;
export type ListHealthChecksResponse = ListHealthChecksResultList;
export declare const ListHealthChecksResponse: S.Schema<ListHealthChecksResponse>;
export type UpdateRequestCacheReserveValue = "on" | "off";
export declare const UpdateRequestCacheReserveValue: any;
export interface UpdateRequestCacheReserve {
    /** Specifies the enablement value of Cache Reserve. */
    value?: UpdateRequestCacheReserveValue | (string & {});
}
export declare const UpdateRequestCacheReserve: S.Schema<UpdateRequestCacheReserve>;
export type UpdateRequestRegionalTieredCacheValue = "on" | "off";
export declare const UpdateRequestRegionalTieredCacheValue: any;
export interface UpdateRequestRegionalTieredCache {
    /** Specifies the enablement value of Regional Tiered Cache. */
    value?: UpdateRequestRegionalTieredCacheValue | (string & {});
}
export declare const UpdateRequestRegionalTieredCache: S.Schema<UpdateRequestRegionalTieredCache>;
export type UpdateRequestSmartRoutingValue = "on" | "off";
export declare const UpdateRequestSmartRoutingValue: any;
export interface UpdateRequestSmartRouting {
    /** Specifies the enablement value of Smart Routing. */
    value?: UpdateRequestSmartRoutingValue | (string & {});
}
export declare const UpdateRequestSmartRouting: S.Schema<UpdateRequestSmartRouting>;
export type UpdateRequestSmartTieredCacheValue = "on" | "off";
export declare const UpdateRequestSmartTieredCacheValue: any;
export interface UpdateRequestSmartTieredCache {
    /** Specifies the enablement value of Smart Tiered Cache. */
    value?: UpdateRequestSmartTieredCacheValue | (string & {});
}
export declare const UpdateRequestSmartTieredCache: S.Schema<UpdateRequestSmartTieredCache>;
export interface UpdateRequest {
    /** Identifier. */
    zoneId: string;
    cacheReserve?: UpdateRequestCacheReserve;
    regionalTieredCache?: UpdateRequestRegionalTieredCache;
    smartRouting?: UpdateRequestSmartRouting;
    smartTieredCache?: UpdateRequestSmartTieredCache;
}
export declare const UpdateRequest: S.Schema<UpdateRequest>;
export type UpdateResponseSmartTieredCacheValue = "on" | "off";
export declare const UpdateResponseSmartTieredCacheValue: any;
export interface UpdateResponseSmartTieredCache {
    /** The id of the Smart Tiered Cache setting. */
    id?: string | null;
    /** Whether the setting is editable. */
    editable?: boolean | null;
    /** The last time the setting was modified. */
    modifiedOn?: string | null;
    /** Specifies the enablement value of Tiered Cache. */
    value?: UpdateResponseSmartTieredCacheValue | null;
}
export declare const UpdateResponseSmartTieredCache: S.Schema<UpdateResponseSmartTieredCache>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    smartTieredCache: UpdateResponseSmartTieredCache;
}
export declare const UpdateResponse: S.Schema<UpdateResponse>;
export interface UpdateHealthCheckRequestErrorsItemSource {
    pointer?: string;
}
export declare const UpdateHealthCheckRequestErrorsItemSource: S.Schema<UpdateHealthCheckRequestErrorsItemSource>;
export interface UpdateHealthCheckRequestErrorsItem {
    code: number;
    message: string;
    documentationUrl?: string;
    source?: UpdateHealthCheckRequestErrorsItemSource;
}
export declare const UpdateHealthCheckRequestErrorsItem: S.Schema<UpdateHealthCheckRequestErrorsItem>;
export type UpdateHealthCheckRequestErrorsList = Array<UpdateHealthCheckRequestErrorsItem>;
export declare const UpdateHealthCheckRequestErrorsList: S.Schema<UpdateHealthCheckRequestErrorsList>;
export interface UpdateHealthCheckRequestMessagesItem {
    code: number;
    message: string;
    documentationUrl?: string;
    source?: unknown;
}
export declare const UpdateHealthCheckRequestMessagesItem: S.Schema<UpdateHealthCheckRequestMessagesItem>;
export type UpdateHealthCheckRequestMessagesList = Array<UpdateHealthCheckRequestMessagesItem>;
export declare const UpdateHealthCheckRequestMessagesList: S.Schema<UpdateHealthCheckRequestMessagesList>;
export type UpdateHealthCheckRequestResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const UpdateHealthCheckRequestResultCheckRegionsItem: any;
export type UpdateHealthCheckRequestResultCheckRegionsList = Array<UpdateHealthCheckRequestResultCheckRegionsItem | (string & {})>;
export declare const UpdateHealthCheckRequestResultCheckRegionsList: S.Schema<UpdateHealthCheckRequestResultCheckRegionsList>;
export type UpdateHealthCheckRequestResultHttpConfigExpectedCodesList = Array<string>;
export declare const UpdateHealthCheckRequestResultHttpConfigExpectedCodesList: S.Schema<UpdateHealthCheckRequestResultHttpConfigExpectedCodesList>;
export type UpdateHealthCheckRequestResultHttpConfigHeaderValueList = Array<string>;
export declare const UpdateHealthCheckRequestResultHttpConfigHeaderValueList: S.Schema<UpdateHealthCheckRequestResultHttpConfigHeaderValueList>;
export type UpdateHealthCheckRequestResultHttpConfigHeaderMap = {
    [key: string]: UpdateHealthCheckRequestResultHttpConfigHeaderValueList | undefined;
};
export declare const UpdateHealthCheckRequestResultHttpConfigHeaderMap: S.Schema<UpdateHealthCheckRequestResultHttpConfigHeaderMap>;
export type UpdateHealthCheckRequestResultHttpConfigMethod = "GET" | "HEAD";
export declare const UpdateHealthCheckRequestResultHttpConfigMethod: any;
export interface UpdateHealthCheckRequestResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateHealthCheckRequestResultHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateHealthCheckRequestResultHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: UpdateHealthCheckRequestResultHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const UpdateHealthCheckRequestResultHttpConfig: S.Schema<UpdateHealthCheckRequestResultHttpConfig>;
export type UpdateHealthCheckRequestResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const UpdateHealthCheckRequestResultStatus: any;
export type UpdateHealthCheckRequestResultTcpConfigMethod = "connection_established";
export declare const UpdateHealthCheckRequestResultTcpConfigMethod: any;
export interface UpdateHealthCheckRequestResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateHealthCheckRequestResultTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const UpdateHealthCheckRequestResultTcpConfig: S.Schema<UpdateHealthCheckRequestResultTcpConfig>;
export interface UpdateHealthCheckRequestResult {
    /** Identifier. */
    id?: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateHealthCheckRequestResultCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    createdOn?: string;
    /** A human-readable description of the health check. */
    description?: string;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateHealthCheckRequestResultHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    modifiedOn?: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** The current status of the origin server according to the health check. */
    status?: UpdateHealthCheckRequestResultStatus | (string & {});
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateHealthCheckRequestResultTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const UpdateHealthCheckRequestResult: S.Schema<UpdateHealthCheckRequestResult>;
export interface UpdateHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
    errors: UpdateHealthCheckRequestErrorsList;
    messages: UpdateHealthCheckRequestMessagesList;
    result: UpdateHealthCheckRequestResult;
    /** Whether the API call was successful. */
    success: boolean;
}
export declare const UpdateHealthCheckRequest: S.Schema<UpdateHealthCheckRequest>;
export type UpdateHealthCheckResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const UpdateHealthCheckResponseCheckRegionsItem: any;
export type UpdateHealthCheckResponseCheckRegionsList = Array<UpdateHealthCheckResponseCheckRegionsItem>;
export declare const UpdateHealthCheckResponseCheckRegionsList: S.Schema<UpdateHealthCheckResponseCheckRegionsList>;
export type UpdateHealthCheckResponseHttpConfigExpectedCodesList = Array<string>;
export declare const UpdateHealthCheckResponseHttpConfigExpectedCodesList: S.Schema<UpdateHealthCheckResponseHttpConfigExpectedCodesList>;
export type UpdateHealthCheckResponseHttpConfigHeaderValueList = Array<string>;
export declare const UpdateHealthCheckResponseHttpConfigHeaderValueList: S.Schema<UpdateHealthCheckResponseHttpConfigHeaderValueList>;
export type UpdateHealthCheckResponseHttpConfigHeaderMap = {
    [key: string]: UpdateHealthCheckResponseHttpConfigHeaderValueList | undefined;
};
export declare const UpdateHealthCheckResponseHttpConfigHeaderMap: S.Schema<UpdateHealthCheckResponseHttpConfigHeaderMap>;
export type UpdateHealthCheckResponseHttpConfigMethod = "GET" | "HEAD";
export declare const UpdateHealthCheckResponseHttpConfigMethod: any;
export interface UpdateHealthCheckResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateHealthCheckResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateHealthCheckResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: UpdateHealthCheckResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const UpdateHealthCheckResponseHttpConfig: S.Schema<UpdateHealthCheckResponseHttpConfig>;
export type UpdateHealthCheckResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const UpdateHealthCheckResponseStatus: any;
export type UpdateHealthCheckResponseTcpConfigMethod = "connection_established";
export declare const UpdateHealthCheckResponseTcpConfigMethod: any;
export interface UpdateHealthCheckResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateHealthCheckResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const UpdateHealthCheckResponseTcpConfig: S.Schema<UpdateHealthCheckResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateHealthCheckResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateHealthCheckResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateHealthCheckResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: UpdateHealthCheckResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateHealthCheckResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const UpdateHealthCheckResponse: S.Schema<UpdateHealthCheckResponse>;
export type CacheReserveClearStatusError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const cacheReserveClearStatus: API.OperationMethod<CacheReserveClearStatusRequest, CacheReserveClearStatusResponse, CacheReserveClearStatusError, CloudflareOpContext>;
export type ClearCacheReserveClearError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const clearCacheReserveClear: API.OperationMethod<ClearCacheReserveClearRequest, ClearCacheReserveClearResponse, ClearCacheReserveClearError, CloudflareOpContext>;
export type CreateHealthCheckError = CloudflareOpError;
/** Create a new health check. */
export declare const createHealthCheck: API.OperationMethod<CreateHealthCheckRequest, CreateHealthCheckResponse, CreateHealthCheckError, CloudflareOpContext>;
export type DeleteHealthCheckError = CloudflareOpError;
/** Delete a health check. */
export declare const deleteHealthCheck: API.OperationMethod<DeleteHealthCheckRequest, DeleteHealthCheckResponse, DeleteHealthCheckError, CloudflareOpContext>;
export type EditHealthCheckError = CloudflareOpError;
/** Patch a configured health check. */
export declare const editHealthCheck: API.OperationMethod<EditHealthCheckRequest, EditHealthCheckResponse, EditHealthCheckError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieve Smart Shield Settings. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type GetHealthCheckError = CloudflareOpError;
/** Fetch a single configured health check. */
export declare const getHealthCheck: API.OperationMethod<GetHealthCheckRequest, GetHealthCheckResponse, GetHealthCheckError, CloudflareOpContext>;
export type ListHealthChecksError = CloudflareOpError;
/** List configured health checks. */
export declare const listHealthChecks: API.OperationMethod<ListHealthChecksRequest, ListHealthChecksResponse, ListHealthChecksError, CloudflareOpContext>;
export type UpdateError = CloudflareOpError;
/** Set Smart Shield Settings. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
export type UpdateHealthCheckError = CloudflareOpError;
/** Update a configured health check. */
export declare const updateHealthCheck: API.OperationMethod<UpdateHealthCheckRequest, UpdateHealthCheckResponse, UpdateHealthCheckError, CloudflareOpContext>;
//# sourceMappingURL=smart_shield.d.ts.map