import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetProfileRequest {
    /** Identifier */
    accountId: string;
}
export declare const GetProfileRequest: S.Schema<GetProfileRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    useLegacy?: boolean | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export declare const GetProfileResponse: S.Schema<GetProfileResponse>;
export interface GetUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string;
    /** Filter results by billable metric id (e.g., workers_standard_requests). */
    metric?: string;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string;
}
export declare const GetUsageRequest: S.Schema<GetUsageRequest>;
export type UsageGetResultItemChargeCategory = "Usage";
export declare const UsageGetResultItemChargeCategory: any;
export type UsageGetResultItemChargeFrequency = "Usage-Based";
export declare const UsageGetResultItemChargeFrequency: any;
export type UsageGetResultItemChargeClass = "Correction";
export declare const UsageGetResultItemChargeClass: any;
export interface UsageGetResultItem {
    /** Public identifier of the Cloudflare account (account tag). */
    billingAccountId: string;
    /** Display name of the Cloudflare account. */
    billingAccountName: string;
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: UsageGetResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: UsageGetResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity: number;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: UsageGetResultItemChargeClass | null;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId?: string | null;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). Cloudflare extension. */
    xZoneId?: string | null;
    /** The display name of the Cloudflare zone. Cloudflare extension. */
    xZoneName?: string | null;
}
export declare const UsageGetResultItem: S.Schema<UsageGetResultItem>;
export type UsageGetResultList = Array<UsageGetResultItem>;
export declare const UsageGetResultList: S.Schema<UsageGetResultList>;
export type GetUsageResponse = UsageGetResultList;
export declare const GetUsageResponse: S.Schema<GetUsageResponse>;
export interface PaygoUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). */
    from?: string;
    /** End date for the usage query (ISO 8601). */
    to?: string;
}
export declare const PaygoUsageRequest: S.Schema<PaygoUsageRequest>;
export interface UsagePaygoResultItem {
    /** Specifies the billing currency code (ISO 4217). */
    billingCurrency: string;
    /** Indicates the start of the billing period. */
    billingPeriodStart: string;
    /** Indicates the end of the charge period. */
    chargePeriodEnd: string;
    /** Indicates the start of the charge period. */
    chargePeriodStart: string;
    /** Specifies the quantity consumed during this charge period. */
    consumedQuantity: number;
    /** A display name for the unit of measurement used for the product (for example, "GB-months", "GB-seconds"). May be empty when the unit is implicit in the service name. */
    consumedUnit: string;
    /** Specifies the cost for this charge period in the billing currency. */
    contractedCost: number;
    /** Specifies the cumulated cost for the billing period in the billing currency. */
    cumulatedContractedCost: number;
    /** Specifies the cumulated pricing quantity for the billing period. */
    cumulatedPricingQuantity: number;
    /** Specifies the pricing quantity for this charge period. */
    pricingQuantity: number;
    /** Identifies the Cloudflare service. */
    serviceName: string;
    /** Identifies the product family for the Cloudflare service. */
    serviceFamilyName?: string | null;
    /** The identifier for the Cloudflare subscription. */
    subscriptionId?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). */
    zoneId?: string | null;
    /** The display name of the Cloudflare zone. */
    zoneName?: string | null;
}
export declare const UsagePaygoResultItem: S.Schema<UsagePaygoResultItem>;
export type UsagePaygoResultList = Array<UsagePaygoResultItem>;
export declare const UsagePaygoResultList: S.Schema<UsagePaygoResultList>;
export type PaygoUsageResponse = UsagePaygoResultList;
export declare const PaygoUsageResponse: S.Schema<PaygoUsageResponse>;
export type GetProfileError = CloudflareOpError;
/** Gets the current billing profile for the account. */
export declare const getProfile: API.OperationMethod<GetProfileRequest, GetProfileResponse, GetProfileError, CloudflareOpContext>;
export type GetUsageError = CloudflareOpError;
/** Returns cost and usage data for a single Cloudflare account, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. **Note:** Cost and pricing fields are not yet populated and will be absent from responses until billing integration is complete. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. */
export declare const getUsage: API.OperationMethod<GetUsageRequest, GetUsageResponse, GetUsageError, CloudflareOpContext>;
export type PaygoUsageError = CloudflareOpError;
/** Returns billable usage data for PayGo (self-serve) accounts. When no query parameters are provided, returns usage for the current billing period. This endpoint is currently in alpha and access is restricted to select accounts. While in alpha, the endpoint may get breaking changes. */
export declare const paygoUsage: API.OperationMethod<PaygoUsageRequest, PaygoUsageResponse, PaygoUsageError, CloudflareOpContext>;
//# sourceMappingURL=billing.d.ts.map