import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AdvancedTcpProtectionNotEntitled_base: S.Class<AdvancedTcpProtectionNotEntitled, S.TaggedStruct<"AdvancedTcpProtectionNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AdvancedTcpProtectionNotEntitled extends /*@__PURE__*/ AdvancedTcpProtectionNotEntitled_base {
}
declare const AllowlistEntryNotFound_base: S.Class<AllowlistEntryNotFound, S.TaggedStruct<"AllowlistEntryNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AllowlistEntryNotFound extends /*@__PURE__*/ AllowlistEntryNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SynProtectionFilterNotFound_base: S.Class<SynProtectionFilterNotFound, S.TaggedStruct<"SynProtectionFilterNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SynProtectionFilterNotFound extends /*@__PURE__*/ SynProtectionFilterNotFound_base {
}
declare const SynProtectionRuleNotFound_base: S.Class<SynProtectionRuleNotFound, S.TaggedStruct<"SynProtectionRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SynProtectionRuleNotFound extends /*@__PURE__*/ SynProtectionRuleNotFound_base {
}
declare const TcpFlowProtectionFilterNotFound_base: S.Class<TcpFlowProtectionFilterNotFound, S.TaggedStruct<"TcpFlowProtectionFilterNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TcpFlowProtectionFilterNotFound extends /*@__PURE__*/ TcpFlowProtectionFilterNotFound_base {
}
declare const TcpFlowProtectionRuleNotFound_base: S.Class<TcpFlowProtectionRuleNotFound, S.TaggedStruct<"TcpFlowProtectionRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TcpFlowProtectionRuleNotFound extends /*@__PURE__*/ TcpFlowProtectionRuleNotFound_base {
}
export interface AdvancedTcpProtectionPrefixesBulkCreateRequestBodyItem {
    /** A comment describing the prefix. */
    comment: string;
    /** Whether to exclude the prefix from protection. */
    excluded: boolean;
    /** The prefix to add in CIDR format. */
    prefix: string;
}
export declare const AdvancedTcpProtectionPrefixesBulkCreateRequestBodyItem: S.Schema<AdvancedTcpProtectionPrefixesBulkCreateRequestBodyItem>;
export type AdvancedTcpProtectionPrefixesBulkCreateRequestBodyList = Array<AdvancedTcpProtectionPrefixesBulkCreateRequestBodyItem>;
export declare const AdvancedTcpProtectionPrefixesBulkCreateRequestBodyList: S.Schema<AdvancedTcpProtectionPrefixesBulkCreateRequestBodyList>;
export interface BulkCreateAdvancedTcpProtectionPrefixesRequest {
    /** Identifier. */
    accountId: string;
    body: AdvancedTcpProtectionPrefixesBulkCreateRequestBodyList;
}
export declare const BulkCreateAdvancedTcpProtectionPrefixesRequest: S.Schema<BulkCreateAdvancedTcpProtectionPrefixesRequest>;
export interface AdvancedTcpProtectionPrefixesBulkCreateResultItem {
    /** The unique ID of the prefix. */
    id: string;
    /** A comment describing the prefix. */
    comment: string;
    /** The creation timestamp of the prefix. */
    createdOn: string;
    /** Whether to exclude the prefix from protection. */
    excluded: boolean;
    /** The last modification timestamp of the prefix. */
    modifiedOn: string;
    /** The prefix in CIDR format. */
    prefix: string;
}
export declare const AdvancedTcpProtectionPrefixesBulkCreateResultItem: S.Schema<AdvancedTcpProtectionPrefixesBulkCreateResultItem>;
export type AdvancedTcpProtectionPrefixesBulkCreateResultList = Array<AdvancedTcpProtectionPrefixesBulkCreateResultItem>;
export declare const AdvancedTcpProtectionPrefixesBulkCreateResultList: S.Schema<AdvancedTcpProtectionPrefixesBulkCreateResultList>;
export interface BulkCreateAdvancedTcpProtectionPrefixesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionPrefixesBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkCreateAdvancedTcpProtectionPrefixesResponse: S.Schema<BulkCreateAdvancedTcpProtectionPrefixesResponse>;
export interface BulkDeleteAdvancedTcpProtectionAllowlistsRequest {
    /** Identifier. */
    accountId: string;
}
export declare const BulkDeleteAdvancedTcpProtectionAllowlistsRequest: S.Schema<BulkDeleteAdvancedTcpProtectionAllowlistsRequest>;
export interface BulkDeleteAdvancedTcpProtectionAllowlistsResponse {
}
export declare const BulkDeleteAdvancedTcpProtectionAllowlistsResponse: S.Schema<BulkDeleteAdvancedTcpProtectionAllowlistsResponse>;
export interface BulkDeleteAdvancedTcpProtectionPrefixesRequest {
    /** Identifier. */
    accountId: string;
}
export declare const BulkDeleteAdvancedTcpProtectionPrefixesRequest: S.Schema<BulkDeleteAdvancedTcpProtectionPrefixesRequest>;
export interface BulkDeleteAdvancedTcpProtectionPrefixesResponse {
}
export declare const BulkDeleteAdvancedTcpProtectionPrefixesResponse: S.Schema<BulkDeleteAdvancedTcpProtectionPrefixesResponse>;
export interface BulkDeleteAdvancedTcpProtectionSynProtectionFiltersRequest {
    /** Identifier. */
    accountId: string;
}
export declare const BulkDeleteAdvancedTcpProtectionSynProtectionFiltersRequest: S.Schema<BulkDeleteAdvancedTcpProtectionSynProtectionFiltersRequest>;
export interface BulkDeleteAdvancedTcpProtectionSynProtectionFiltersResponse {
}
export declare const BulkDeleteAdvancedTcpProtectionSynProtectionFiltersResponse: S.Schema<BulkDeleteAdvancedTcpProtectionSynProtectionFiltersResponse>;
export interface BulkDeleteAdvancedTcpProtectionSynProtectionRulesRequest {
    /** Identifier. */
    accountId: string;
}
export declare const BulkDeleteAdvancedTcpProtectionSynProtectionRulesRequest: S.Schema<BulkDeleteAdvancedTcpProtectionSynProtectionRulesRequest>;
export interface BulkDeleteAdvancedTcpProtectionSynProtectionRulesResponse {
}
export declare const BulkDeleteAdvancedTcpProtectionSynProtectionRulesResponse: S.Schema<BulkDeleteAdvancedTcpProtectionSynProtectionRulesResponse>;
export interface BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersRequest {
    /** Identifier. */
    accountId: string;
}
export declare const BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersRequest: S.Schema<BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersRequest>;
export interface BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersResponse {
}
export declare const BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersResponse: S.Schema<BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersResponse>;
export interface BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesRequest {
    /** Identifier. */
    accountId: string;
}
export declare const BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesRequest: S.Schema<BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesRequest>;
export interface BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesResponse {
}
export declare const BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesResponse: S.Schema<BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesResponse>;
export interface CreateAdvancedTcpProtectionAllowlistRequest {
    /** Identifier. */
    accountId: string;
    /** An comment describing the allowlist prefix. */
    comment: string;
    /** Whether to enable the allowlist prefix into effect. */
    enabled: boolean;
    /** The allowlist prefix to add in CIDR format. */
    prefix: string;
}
export declare const CreateAdvancedTcpProtectionAllowlistRequest: S.Schema<CreateAdvancedTcpProtectionAllowlistRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAdvancedTcpProtectionAllowlistResponse {
    /** The unique ID of the allowlist prefix. */
    id: string;
    /** An optional comment describing the allowlist prefix. */
    comment: string;
    /** The creation timestamp of the allowlist prefix. */
    createdOn: string;
    /** Whether to enable the allowlist prefix into effect. Defaults to false. */
    enabled: boolean;
    /** The last modification timestamp of the allowlist prefix. */
    modifiedOn: string;
    /** The allowlist prefix in CIDR format. */
    prefix: string;
}
export declare const CreateAdvancedTcpProtectionAllowlistResponse: S.Schema<CreateAdvancedTcpProtectionAllowlistResponse>;
export interface CreateAdvancedTcpProtectionPrefixRequest {
    /** Identifier. */
    accountId: string;
    /** A comment describing the prefix. */
    comment: string;
    /** Whether to exclude the prefix from protection. */
    excluded: boolean;
    /** The prefix to add in CIDR format. */
    prefix: string;
}
export declare const CreateAdvancedTcpProtectionPrefixRequest: S.Schema<CreateAdvancedTcpProtectionPrefixRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAdvancedTcpProtectionPrefixResponse {
    /** The unique ID of the prefix. */
    id: string;
    /** A comment describing the prefix. */
    comment: string;
    /** The creation timestamp of the prefix. */
    createdOn: string;
    /** Whether to exclude the prefix from protection. */
    excluded: boolean;
    /** The last modification timestamp of the prefix. */
    modifiedOn: string;
    /** The prefix in CIDR format. */
    prefix: string;
}
export declare const CreateAdvancedTcpProtectionPrefixResponse: S.Schema<CreateAdvancedTcpProtectionPrefixResponse>;
export interface CreateAdvancedTcpProtectionSynProtectionFilterRequest {
    /** Identifier. */
    accountId: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
}
export declare const CreateAdvancedTcpProtectionSynProtectionFilterRequest: S.Schema<CreateAdvancedTcpProtectionSynProtectionFilterRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAdvancedTcpProtectionSynProtectionFilterResponse {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const CreateAdvancedTcpProtectionSynProtectionFilterResponse: S.Schema<CreateAdvancedTcpProtectionSynProtectionFilterResponse>;
export interface CreateAdvancedTcpProtectionSynProtectionRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The mode for SYN Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The name of the SYN Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the SYN Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
    /** The type of mitigation. Must be one of 'challenge' or 'retransmit'. Optional. Defaults to 'challenge'. */
    mitigationType?: string;
}
export declare const CreateAdvancedTcpProtectionSynProtectionRuleRequest: S.Schema<CreateAdvancedTcpProtectionSynProtectionRuleRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAdvancedTcpProtectionSynProtectionRuleResponse {
    /** The unique ID of the SYN Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the SYN Protection rule. */
    createdOn: string;
    /** The type of mitigation for SYN Protection. Must be one of 'challenge' or 'retransmit'. */
    mitigationType: string;
    /** The mode for SYN Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the SYN Protection rule. */
    modifiedOn: string;
    /** The name of the SYN Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the SYN Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const CreateAdvancedTcpProtectionSynProtectionRuleResponse: S.Schema<CreateAdvancedTcpProtectionSynProtectionRuleResponse>;
export interface CreateAdvancedTcpProtectionTcpFlowProtectionFilterRequest {
    /** Identifier. */
    accountId: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
}
export declare const CreateAdvancedTcpProtectionTcpFlowProtectionFilterRequest: S.Schema<CreateAdvancedTcpProtectionTcpFlowProtectionFilterRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAdvancedTcpProtectionTcpFlowProtectionFilterResponse {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const CreateAdvancedTcpProtectionTcpFlowProtectionFilterResponse: S.Schema<CreateAdvancedTcpProtectionTcpFlowProtectionFilterResponse>;
export interface CreateAdvancedTcpProtectionTcpFlowProtectionRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The mode for the TCP Flow Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The name of the TCP Flow Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the TCP Flow Protection rule. */
    scope: string;
}
export declare const CreateAdvancedTcpProtectionTcpFlowProtectionRuleRequest: S.Schema<CreateAdvancedTcpProtectionTcpFlowProtectionRuleRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAdvancedTcpProtectionTcpFlowProtectionRuleResponse {
    /** The unique ID of the TCP Flow Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the TCP Flow Protection rule. */
    createdOn: string;
    /** The mode for TCP Flow Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the TCP Flow Protection rule. */
    modifiedOn: string;
    /** The name of the TCP Flow Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the TCP Flow Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const CreateAdvancedTcpProtectionTcpFlowProtectionRuleResponse: S.Schema<CreateAdvancedTcpProtectionTcpFlowProtectionRuleResponse>;
export interface DeleteAdvancedTcpProtectionAllowlistItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    prefixId: string;
}
export declare const DeleteAdvancedTcpProtectionAllowlistItemRequest: S.Schema<DeleteAdvancedTcpProtectionAllowlistItemRequest>;
export interface DeleteAdvancedTcpProtectionAllowlistItemResponse {
}
export declare const DeleteAdvancedTcpProtectionAllowlistItemResponse: S.Schema<DeleteAdvancedTcpProtectionAllowlistItemResponse>;
export interface DeleteAdvancedTcpProtectionPrefixItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    prefixId: string;
}
export declare const DeleteAdvancedTcpProtectionPrefixItemRequest: S.Schema<DeleteAdvancedTcpProtectionPrefixItemRequest>;
export interface DeleteAdvancedTcpProtectionPrefixItemResponse {
}
export declare const DeleteAdvancedTcpProtectionPrefixItemResponse: S.Schema<DeleteAdvancedTcpProtectionPrefixItemResponse>;
export interface DeleteAdvancedTcpProtectionSynProtectionFilterItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    filterId: string;
}
export declare const DeleteAdvancedTcpProtectionSynProtectionFilterItemRequest: S.Schema<DeleteAdvancedTcpProtectionSynProtectionFilterItemRequest>;
export interface DeleteAdvancedTcpProtectionSynProtectionFilterItemResponse {
}
export declare const DeleteAdvancedTcpProtectionSynProtectionFilterItemResponse: S.Schema<DeleteAdvancedTcpProtectionSynProtectionFilterItemResponse>;
export interface DeleteAdvancedTcpProtectionSynProtectionRuleItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    ruleId: string;
}
export declare const DeleteAdvancedTcpProtectionSynProtectionRuleItemRequest: S.Schema<DeleteAdvancedTcpProtectionSynProtectionRuleItemRequest>;
export interface DeleteAdvancedTcpProtectionSynProtectionRuleItemResponse {
}
export declare const DeleteAdvancedTcpProtectionSynProtectionRuleItemResponse: S.Schema<DeleteAdvancedTcpProtectionSynProtectionRuleItemResponse>;
export interface DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    filterId: string;
}
export declare const DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest: S.Schema<DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest>;
export interface DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse {
}
export declare const DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse: S.Schema<DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse>;
export interface DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    ruleId: string;
}
export declare const DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest: S.Schema<DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest>;
export interface DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse {
}
export declare const DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse: S.Schema<DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse>;
export interface GetAdvancedTcpProtectionAllowlistItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    prefixId: string;
}
export declare const GetAdvancedTcpProtectionAllowlistItemRequest: S.Schema<GetAdvancedTcpProtectionAllowlistItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionAllowlistItemResponse {
    /** The unique ID of the allowlist prefix. */
    id: string;
    /** An optional comment describing the allowlist prefix. */
    comment: string;
    /** The creation timestamp of the allowlist prefix. */
    createdOn: string;
    /** Whether to enable the allowlist prefix into effect. Defaults to false. */
    enabled: boolean;
    /** The last modification timestamp of the allowlist prefix. */
    modifiedOn: string;
    /** The allowlist prefix in CIDR format. */
    prefix: string;
}
export declare const GetAdvancedTcpProtectionAllowlistItemResponse: S.Schema<GetAdvancedTcpProtectionAllowlistItemResponse>;
export interface GetAdvancedTcpProtectionPrefixItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    prefixId: string;
}
export declare const GetAdvancedTcpProtectionPrefixItemRequest: S.Schema<GetAdvancedTcpProtectionPrefixItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionPrefixItemResponse {
    /** The unique ID of the prefix. */
    id: string;
    /** A comment describing the prefix. */
    comment: string;
    /** The creation timestamp of the prefix. */
    createdOn: string;
    /** Whether to exclude the prefix from protection. */
    excluded: boolean;
    /** The last modification timestamp of the prefix. */
    modifiedOn: string;
    /** The prefix in CIDR format. */
    prefix: string;
}
export declare const GetAdvancedTcpProtectionPrefixItemResponse: S.Schema<GetAdvancedTcpProtectionPrefixItemResponse>;
export interface GetAdvancedTcpProtectionStatusRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetAdvancedTcpProtectionStatusRequest: S.Schema<GetAdvancedTcpProtectionStatusRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionStatusResponse {
    enabled: boolean;
}
export declare const GetAdvancedTcpProtectionStatusResponse: S.Schema<GetAdvancedTcpProtectionStatusResponse>;
export interface GetAdvancedTcpProtectionSynProtectionFilterItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    filterId: string;
}
export declare const GetAdvancedTcpProtectionSynProtectionFilterItemRequest: S.Schema<GetAdvancedTcpProtectionSynProtectionFilterItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionSynProtectionFilterItemResponse {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const GetAdvancedTcpProtectionSynProtectionFilterItemResponse: S.Schema<GetAdvancedTcpProtectionSynProtectionFilterItemResponse>;
export interface GetAdvancedTcpProtectionSynProtectionRuleItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    ruleId: string;
}
export declare const GetAdvancedTcpProtectionSynProtectionRuleItemRequest: S.Schema<GetAdvancedTcpProtectionSynProtectionRuleItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionSynProtectionRuleItemResponse {
    /** The unique ID of the SYN Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the SYN Protection rule. */
    createdOn: string;
    /** The type of mitigation for SYN Protection. Must be one of 'challenge' or 'retransmit'. */
    mitigationType: string;
    /** The mode for SYN Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the SYN Protection rule. */
    modifiedOn: string;
    /** The name of the SYN Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the SYN Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const GetAdvancedTcpProtectionSynProtectionRuleItemResponse: S.Schema<GetAdvancedTcpProtectionSynProtectionRuleItemResponse>;
export interface GetAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    filterId: string;
}
export declare const GetAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest: S.Schema<GetAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const GetAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse: S.Schema<GetAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse>;
export interface GetAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    ruleId: string;
}
export declare const GetAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest: S.Schema<GetAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse {
    /** The unique ID of the TCP Flow Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the TCP Flow Protection rule. */
    createdOn: string;
    /** The mode for TCP Flow Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the TCP Flow Protection rule. */
    modifiedOn: string;
    /** The name of the TCP Flow Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the TCP Flow Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const GetAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse: S.Schema<GetAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse>;
export interface ListAdvancedTcpProtectionAllowlistsRequest {
    /** Identifier. */
    accountId: string;
    /** The direction of ordering (ASC or DESC). Defaults to 'ASC'. */
    direction?: string;
    /** The field to order by. Defaults to 'prefix'. */
    order?: string;
    /** The page number for pagination. Defaults to 1. */
    page?: number;
    /** The number of items per page. Must be between 10 and 1000. Defaults to 25. */
    perPage?: number;
}
export declare const ListAdvancedTcpProtectionAllowlistsRequest: S.Schema<ListAdvancedTcpProtectionAllowlistsRequest>;
export interface AdvancedTcpProtectionAllowlistListResultItem {
    /** The unique ID of the allowlist prefix. */
    id: string;
    /** An optional comment describing the allowlist prefix. */
    comment: string;
    /** The creation timestamp of the allowlist prefix. */
    createdOn: string;
    /** Whether to enable the allowlist prefix into effect. Defaults to false. */
    enabled: boolean;
    /** The last modification timestamp of the allowlist prefix. */
    modifiedOn: string;
    /** The allowlist prefix in CIDR format. */
    prefix: string;
}
export declare const AdvancedTcpProtectionAllowlistListResultItem: S.Schema<AdvancedTcpProtectionAllowlistListResultItem>;
export type AdvancedTcpProtectionAllowlistListResultList = Array<AdvancedTcpProtectionAllowlistListResultItem>;
export declare const AdvancedTcpProtectionAllowlistListResultList: S.Schema<AdvancedTcpProtectionAllowlistListResultList>;
export interface ListAdvancedTcpProtectionAllowlistsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionAllowlistListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAdvancedTcpProtectionAllowlistsResponse: S.Schema<ListAdvancedTcpProtectionAllowlistsResponse>;
export interface ListAdvancedTcpProtectionPrefixesRequest {
    /** Identifier. */
    accountId: string;
    /** The direction of ordering (ASC or DESC). Defaults to 'ASC'. */
    direction?: string;
    /** The field to order by. Defaults to 'prefix'. */
    order?: string;
    /** The page number for pagination. Defaults to 1. */
    page?: number;
    /** The number of items per page. Must be between 10 and 1000. Defaults to 25. */
    perPage?: number;
}
export declare const ListAdvancedTcpProtectionPrefixesRequest: S.Schema<ListAdvancedTcpProtectionPrefixesRequest>;
export type AdvancedTcpProtectionPrefixesListResultItem = AdvancedTcpProtectionPrefixesBulkCreateResultItem;
export declare const AdvancedTcpProtectionPrefixesListResultItem: S.Schema<AdvancedTcpProtectionPrefixesBulkCreateResultItem>;
export type AdvancedTcpProtectionPrefixesListResultList = Array<AdvancedTcpProtectionPrefixesBulkCreateResultItem>;
export declare const AdvancedTcpProtectionPrefixesListResultList: S.Schema<AdvancedTcpProtectionPrefixesListResultList>;
export interface ListAdvancedTcpProtectionPrefixesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionPrefixesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAdvancedTcpProtectionPrefixesResponse: S.Schema<ListAdvancedTcpProtectionPrefixesResponse>;
export interface ListAdvancedTcpProtectionSynProtectionFiltersRequest {
    /** Identifier. */
    accountId: string;
    /** The direction of ordering (ASC or DESC). Defaults to 'ASC'. */
    direction?: string;
    /** The mode of the filters to get. Optional. Valid values: 'enabled', 'disabled', 'monitoring'. */
    mode?: string;
    /** The field to order by. Defaults to 'prefix'. */
    order?: string;
    /** The page number for pagination. Defaults to 1. */
    page?: number;
    /** The number of items per page. Must be between 10 and 1000. Defaults to 25. */
    perPage?: number;
}
export declare const ListAdvancedTcpProtectionSynProtectionFiltersRequest: S.Schema<ListAdvancedTcpProtectionSynProtectionFiltersRequest>;
export interface AdvancedTcpProtectionSynProtectionFiltersListResultItem {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const AdvancedTcpProtectionSynProtectionFiltersListResultItem: S.Schema<AdvancedTcpProtectionSynProtectionFiltersListResultItem>;
export type AdvancedTcpProtectionSynProtectionFiltersListResultList = Array<AdvancedTcpProtectionSynProtectionFiltersListResultItem>;
export declare const AdvancedTcpProtectionSynProtectionFiltersListResultList: S.Schema<AdvancedTcpProtectionSynProtectionFiltersListResultList>;
export interface ListAdvancedTcpProtectionSynProtectionFiltersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionSynProtectionFiltersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAdvancedTcpProtectionSynProtectionFiltersResponse: S.Schema<ListAdvancedTcpProtectionSynProtectionFiltersResponse>;
export interface ListAdvancedTcpProtectionSynProtectionRulesRequest {
    /** Identifier. */
    accountId: string;
    /** The direction of ordering (ASC or DESC). Defaults to 'ASC'. */
    direction?: string;
    /** The field to order by. Defaults to 'prefix'. */
    order?: string;
    /** The page number for pagination. Defaults to 1. */
    page?: number;
    /** The number of items per page. Must be between 10 and 1000. Defaults to 25. */
    perPage?: number;
}
export declare const ListAdvancedTcpProtectionSynProtectionRulesRequest: S.Schema<ListAdvancedTcpProtectionSynProtectionRulesRequest>;
export interface AdvancedTcpProtectionSynProtectionRulesListResultItem {
    /** The unique ID of the SYN Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the SYN Protection rule. */
    createdOn: string;
    /** The type of mitigation for SYN Protection. Must be one of 'challenge' or 'retransmit'. */
    mitigationType: string;
    /** The mode for SYN Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the SYN Protection rule. */
    modifiedOn: string;
    /** The name of the SYN Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the SYN Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const AdvancedTcpProtectionSynProtectionRulesListResultItem: S.Schema<AdvancedTcpProtectionSynProtectionRulesListResultItem>;
export type AdvancedTcpProtectionSynProtectionRulesListResultList = Array<AdvancedTcpProtectionSynProtectionRulesListResultItem>;
export declare const AdvancedTcpProtectionSynProtectionRulesListResultList: S.Schema<AdvancedTcpProtectionSynProtectionRulesListResultList>;
export interface ListAdvancedTcpProtectionSynProtectionRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionSynProtectionRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAdvancedTcpProtectionSynProtectionRulesResponse: S.Schema<ListAdvancedTcpProtectionSynProtectionRulesResponse>;
export interface ListAdvancedTcpProtectionTcpFlowProtectionFiltersRequest {
    /** Identifier. */
    accountId: string;
    /** The direction of ordering (ASC or DESC). Defaults to 'ASC'. */
    direction?: string;
    /** The mode of the filters to get. Optional. Valid values: 'enabled', 'disabled', 'monitoring'. */
    mode?: string;
    /** The field to order by. Defaults to 'prefix'. */
    order?: string;
    /** The page number for pagination. Defaults to 1. */
    page?: number;
    /** The number of items per page. Must be between 10 and 1000. Defaults to 25. */
    perPage?: number;
}
export declare const ListAdvancedTcpProtectionTcpFlowProtectionFiltersRequest: S.Schema<ListAdvancedTcpProtectionTcpFlowProtectionFiltersRequest>;
export type AdvancedTcpProtectionTcpFlowProtectionFiltersListResultItem = AdvancedTcpProtectionSynProtectionFiltersListResultItem;
export declare const AdvancedTcpProtectionTcpFlowProtectionFiltersListResultItem: S.Schema<AdvancedTcpProtectionSynProtectionFiltersListResultItem>;
export type AdvancedTcpProtectionTcpFlowProtectionFiltersListResultList = Array<AdvancedTcpProtectionSynProtectionFiltersListResultItem>;
export declare const AdvancedTcpProtectionTcpFlowProtectionFiltersListResultList: S.Schema<AdvancedTcpProtectionTcpFlowProtectionFiltersListResultList>;
export interface ListAdvancedTcpProtectionTcpFlowProtectionFiltersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionTcpFlowProtectionFiltersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAdvancedTcpProtectionTcpFlowProtectionFiltersResponse: S.Schema<ListAdvancedTcpProtectionTcpFlowProtectionFiltersResponse>;
export interface ListAdvancedTcpProtectionTcpFlowProtectionRulesRequest {
    /** Identifier. */
    accountId: string;
    /** The direction of ordering (ASC or DESC). Defaults to 'ASC'. */
    direction?: string;
    /** The field to order by. Defaults to 'prefix'. */
    order?: string;
    /** The page number for pagination. Defaults to 1. */
    page?: number;
    /** The number of items per page. Must be between 10 and 1000. Defaults to 25. */
    perPage?: number;
}
export declare const ListAdvancedTcpProtectionTcpFlowProtectionRulesRequest: S.Schema<ListAdvancedTcpProtectionTcpFlowProtectionRulesRequest>;
export interface AdvancedTcpProtectionTcpFlowProtectionRulesListResultItem {
    /** The unique ID of the TCP Flow Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the TCP Flow Protection rule. */
    createdOn: string;
    /** The mode for TCP Flow Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the TCP Flow Protection rule. */
    modifiedOn: string;
    /** The name of the TCP Flow Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the TCP Flow Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const AdvancedTcpProtectionTcpFlowProtectionRulesListResultItem: S.Schema<AdvancedTcpProtectionTcpFlowProtectionRulesListResultItem>;
export type AdvancedTcpProtectionTcpFlowProtectionRulesListResultList = Array<AdvancedTcpProtectionTcpFlowProtectionRulesListResultItem>;
export declare const AdvancedTcpProtectionTcpFlowProtectionRulesListResultList: S.Schema<AdvancedTcpProtectionTcpFlowProtectionRulesListResultList>;
export interface ListAdvancedTcpProtectionTcpFlowProtectionRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AdvancedTcpProtectionTcpFlowProtectionRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAdvancedTcpProtectionTcpFlowProtectionRulesResponse: S.Schema<ListAdvancedTcpProtectionTcpFlowProtectionRulesResponse>;
export interface PatchAdvancedTcpProtectionAllowlistItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    prefixId: string;
    /** A comment describing the allowlist prefix. Optional. */
    comment?: string;
    /** Whether to enable the allowlist prefix into effect. Optional. */
    enabled?: boolean;
}
export declare const PatchAdvancedTcpProtectionAllowlistItemRequest: S.Schema<PatchAdvancedTcpProtectionAllowlistItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionAllowlistItemResponse {
    /** The unique ID of the allowlist prefix. */
    id: string;
    /** An optional comment describing the allowlist prefix. */
    comment: string;
    /** The creation timestamp of the allowlist prefix. */
    createdOn: string;
    /** Whether to enable the allowlist prefix into effect. Defaults to false. */
    enabled: boolean;
    /** The last modification timestamp of the allowlist prefix. */
    modifiedOn: string;
    /** The allowlist prefix in CIDR format. */
    prefix: string;
}
export declare const PatchAdvancedTcpProtectionAllowlistItemResponse: S.Schema<PatchAdvancedTcpProtectionAllowlistItemResponse>;
export interface PatchAdvancedTcpProtectionPrefixItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    prefixId: string;
    /** A new comment for the prefix. Optional. */
    comment?: string;
    /** Whether to exclude the prefix from protection. Optional. */
    excluded?: boolean;
}
export declare const PatchAdvancedTcpProtectionPrefixItemRequest: S.Schema<PatchAdvancedTcpProtectionPrefixItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionPrefixItemResponse {
    /** The unique ID of the prefix. */
    id: string;
    /** A comment describing the prefix. */
    comment: string;
    /** The creation timestamp of the prefix. */
    createdOn: string;
    /** Whether to exclude the prefix from protection. */
    excluded: boolean;
    /** The last modification timestamp of the prefix. */
    modifiedOn: string;
    /** The prefix in CIDR format. */
    prefix: string;
}
export declare const PatchAdvancedTcpProtectionPrefixItemResponse: S.Schema<PatchAdvancedTcpProtectionPrefixItemResponse>;
export interface PatchAdvancedTcpProtectionStatusRequest {
    /** Identifier. */
    accountId: string;
    /** Enables or disables protection. */
    enabled: boolean;
}
export declare const PatchAdvancedTcpProtectionStatusRequest: S.Schema<PatchAdvancedTcpProtectionStatusRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionStatusResponse {
    enabled: boolean;
}
export declare const PatchAdvancedTcpProtectionStatusResponse: S.Schema<PatchAdvancedTcpProtectionStatusResponse>;
export interface PatchAdvancedTcpProtectionSynProtectionFilterItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    filterId: string;
    /** The new filter expression. Optional. */
    expression?: string;
    /** The new mode for the filter. Optional. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode?: string;
}
export declare const PatchAdvancedTcpProtectionSynProtectionFilterItemRequest: S.Schema<PatchAdvancedTcpProtectionSynProtectionFilterItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionSynProtectionFilterItemResponse {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const PatchAdvancedTcpProtectionSynProtectionFilterItemResponse: S.Schema<PatchAdvancedTcpProtectionSynProtectionFilterItemResponse>;
export interface PatchAdvancedTcpProtectionSynProtectionRuleItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    ruleId: string;
    /** The new burst sensitivity. Optional. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity?: string;
    /** The new mitigation type. Optional. Must be one of 'challenge' or 'retransmit'. */
    mitigationType?: string;
    /** The new mode for SYN Protection. Optional. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode?: string;
    /** The new rate sensitivity. Optional. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity?: string;
}
export declare const PatchAdvancedTcpProtectionSynProtectionRuleItemRequest: S.Schema<PatchAdvancedTcpProtectionSynProtectionRuleItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionSynProtectionRuleItemResponse {
    /** The unique ID of the SYN Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the SYN Protection rule. */
    createdOn: string;
    /** The type of mitigation for SYN Protection. Must be one of 'challenge' or 'retransmit'. */
    mitigationType: string;
    /** The mode for SYN Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the SYN Protection rule. */
    modifiedOn: string;
    /** The name of the SYN Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the SYN Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const PatchAdvancedTcpProtectionSynProtectionRuleItemResponse: S.Schema<PatchAdvancedTcpProtectionSynProtectionRuleItemResponse>;
export interface PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    filterId: string;
    /** The new filter expression. Optional. */
    expression?: string;
    /** The new mode for the filter. Optional. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode?: string;
}
export declare const PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest: S.Schema<PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse {
    /** The unique ID of the expression filter. */
    id: string;
    /** The creation timestamp of the expression filter. */
    createdOn: string;
    /** The filter expression. */
    expression: string;
    /** The filter's mode. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the expression filter. */
    modifiedOn: string;
}
export declare const PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse: S.Schema<PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse>;
export interface PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest {
    /** Identifier. */
    accountId: string;
    /** UUID. */
    ruleId: string;
    /** The new burst sensitivity. Optional. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity?: string;
    /** The new mode for TCP Flow Protection. Optional. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode?: string;
    /** The new rate sensitivity. Optional. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity?: string;
}
export declare const PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest: S.Schema<PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse {
    /** The unique ID of the TCP Flow Protection rule. */
    id: string;
    /** The burst sensitivity. Must be one of 'low', 'medium', 'high'. */
    burstSensitivity: string;
    /** The creation timestamp of the TCP Flow Protection rule. */
    createdOn: string;
    /** The mode for TCP Flow Protection. Must be one of 'enabled', 'disabled', 'monitoring'. */
    mode: string;
    /** The last modification timestamp of the TCP Flow Protection rule. */
    modifiedOn: string;
    /** The name of the TCP Flow Protection rule. Value is relative to the 'scope' setting. For 'global' scope, name should be 'global'. For either the 'region' or 'datacenter' scope, name should be the actual name of the region or datacenter, e.g., 'wnam' or 'lax'. */
    name: string;
    /** The rate sensitivity. Must be one of 'low', 'medium', 'high'. */
    rateSensitivity: string;
    /** The scope for the TCP Flow Protection rule. Must be one of 'global', 'region', or 'datacenter'. */
    scope: string;
}
export declare const PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse: S.Schema<PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse>;
export type BulkCreateAdvancedTcpProtectionPrefixesError = CloudflareOpError;
/** Create multiple prefixes for an account. */
export declare const bulkCreateAdvancedTcpProtectionPrefixes: API.PaginatedOperationMethod<BulkCreateAdvancedTcpProtectionPrefixesRequest, BulkCreateAdvancedTcpProtectionPrefixesResponse, BulkCreateAdvancedTcpProtectionPrefixesError, CloudflareOpContext, AdvancedTcpProtectionPrefixesBulkCreateResultItem>;
export type BulkDeleteAdvancedTcpProtectionAllowlistsError = CloudflareOpError;
/** Delete all allowlist prefixes for an account. */
export declare const bulkDeleteAdvancedTcpProtectionAllowlists: API.OperationMethod<BulkDeleteAdvancedTcpProtectionAllowlistsRequest, BulkDeleteAdvancedTcpProtectionAllowlistsResponse, BulkDeleteAdvancedTcpProtectionAllowlistsError, CloudflareOpContext>;
export type BulkDeleteAdvancedTcpProtectionPrefixesError = CloudflareOpError;
/** Delete all prefixes for an account. */
export declare const bulkDeleteAdvancedTcpProtectionPrefixes: API.OperationMethod<BulkDeleteAdvancedTcpProtectionPrefixesRequest, BulkDeleteAdvancedTcpProtectionPrefixesResponse, BulkDeleteAdvancedTcpProtectionPrefixesError, CloudflareOpContext>;
export type BulkDeleteAdvancedTcpProtectionSynProtectionFiltersError = CloudflareOpError;
/** Delete all SYN Protection filters for an account. */
export declare const bulkDeleteAdvancedTcpProtectionSynProtectionFilters: API.OperationMethod<BulkDeleteAdvancedTcpProtectionSynProtectionFiltersRequest, BulkDeleteAdvancedTcpProtectionSynProtectionFiltersResponse, BulkDeleteAdvancedTcpProtectionSynProtectionFiltersError, CloudflareOpContext>;
export type BulkDeleteAdvancedTcpProtectionSynProtectionRulesError = CloudflareOpError;
/** Delete all SYN Protection rules for an account. */
export declare const bulkDeleteAdvancedTcpProtectionSynProtectionRules: API.OperationMethod<BulkDeleteAdvancedTcpProtectionSynProtectionRulesRequest, BulkDeleteAdvancedTcpProtectionSynProtectionRulesResponse, BulkDeleteAdvancedTcpProtectionSynProtectionRulesError, CloudflareOpContext>;
export type BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersError = CloudflareOpError;
/** Delete all TCP Flow Protection filters for an account. */
export declare const bulkDeleteAdvancedTcpProtectionTcpFlowProtectionFilters: API.OperationMethod<BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersRequest, BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersResponse, BulkDeleteAdvancedTcpProtectionTcpFlowProtectionFiltersError, CloudflareOpContext>;
export type BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesError = CloudflareOpError;
/** Delete all TCP Flow Protection rules for an account. */
export declare const bulkDeleteAdvancedTcpProtectionTcpFlowProtectionRules: API.OperationMethod<BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesRequest, BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesResponse, BulkDeleteAdvancedTcpProtectionTcpFlowProtectionRulesError, CloudflareOpContext>;
export type CreateAdvancedTcpProtectionAllowlistError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Create an allowlist prefix for an account. */
export declare const createAdvancedTcpProtectionAllowlist: API.OperationMethod<CreateAdvancedTcpProtectionAllowlistRequest, CreateAdvancedTcpProtectionAllowlistResponse, CreateAdvancedTcpProtectionAllowlistError, CloudflareOpContext>;
export type CreateAdvancedTcpProtectionPrefixError = CloudflareOpError;
/** Create a prefix for an account. */
export declare const createAdvancedTcpProtectionPrefix: API.OperationMethod<CreateAdvancedTcpProtectionPrefixRequest, CreateAdvancedTcpProtectionPrefixResponse, CreateAdvancedTcpProtectionPrefixError, CloudflareOpContext>;
export type CreateAdvancedTcpProtectionSynProtectionFilterError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Create a SYN Protection filter for an account. */
export declare const createAdvancedTcpProtectionSynProtectionFilter: API.OperationMethod<CreateAdvancedTcpProtectionSynProtectionFilterRequest, CreateAdvancedTcpProtectionSynProtectionFilterResponse, CreateAdvancedTcpProtectionSynProtectionFilterError, CloudflareOpContext>;
export type CreateAdvancedTcpProtectionSynProtectionRuleError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Create a SYN Protection rule for an account. */
export declare const createAdvancedTcpProtectionSynProtectionRule: API.OperationMethod<CreateAdvancedTcpProtectionSynProtectionRuleRequest, CreateAdvancedTcpProtectionSynProtectionRuleResponse, CreateAdvancedTcpProtectionSynProtectionRuleError, CloudflareOpContext>;
export type CreateAdvancedTcpProtectionTcpFlowProtectionFilterError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Create a TCP Flow Protection filter for an account. */
export declare const createAdvancedTcpProtectionTcpFlowProtectionFilter: API.OperationMethod<CreateAdvancedTcpProtectionTcpFlowProtectionFilterRequest, CreateAdvancedTcpProtectionTcpFlowProtectionFilterResponse, CreateAdvancedTcpProtectionTcpFlowProtectionFilterError, CloudflareOpContext>;
export type CreateAdvancedTcpProtectionTcpFlowProtectionRuleError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Create a TCP Flow Protection rule for an account. */
export declare const createAdvancedTcpProtectionTcpFlowProtectionRule: API.OperationMethod<CreateAdvancedTcpProtectionTcpFlowProtectionRuleRequest, CreateAdvancedTcpProtectionTcpFlowProtectionRuleResponse, CreateAdvancedTcpProtectionTcpFlowProtectionRuleError, CloudflareOpContext>;
export type DeleteAdvancedTcpProtectionAllowlistItemError = AllowlistEntryNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Delete the allowlist prefix for an account given a UUID. */
export declare const deleteAdvancedTcpProtectionAllowlistItem: API.OperationMethod<DeleteAdvancedTcpProtectionAllowlistItemRequest, DeleteAdvancedTcpProtectionAllowlistItemResponse, DeleteAdvancedTcpProtectionAllowlistItemError, CloudflareOpContext>;
export type DeleteAdvancedTcpProtectionPrefixItemError = CloudflareOpError;
/** Delete the prefix for an account given a UUID. */
export declare const deleteAdvancedTcpProtectionPrefixItem: API.OperationMethod<DeleteAdvancedTcpProtectionPrefixItemRequest, DeleteAdvancedTcpProtectionPrefixItemResponse, DeleteAdvancedTcpProtectionPrefixItemError, CloudflareOpContext>;
export type DeleteAdvancedTcpProtectionSynProtectionFilterItemError = SynProtectionFilterNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Delete a SYN Protection filter specified by the given UUID. */
export declare const deleteAdvancedTcpProtectionSynProtectionFilterItem: API.OperationMethod<DeleteAdvancedTcpProtectionSynProtectionFilterItemRequest, DeleteAdvancedTcpProtectionSynProtectionFilterItemResponse, DeleteAdvancedTcpProtectionSynProtectionFilterItemError, CloudflareOpContext>;
export type DeleteAdvancedTcpProtectionSynProtectionRuleItemError = SynProtectionRuleNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Delete a SYN Protection rule specified by the given UUID. */
export declare const deleteAdvancedTcpProtectionSynProtectionRuleItem: API.OperationMethod<DeleteAdvancedTcpProtectionSynProtectionRuleItemRequest, DeleteAdvancedTcpProtectionSynProtectionRuleItemResponse, DeleteAdvancedTcpProtectionSynProtectionRuleItemError, CloudflareOpContext>;
export type DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemError = TcpFlowProtectionFilterNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Delete a TCP Flow Protection filter specified by the given UUID. */
export declare const deleteAdvancedTcpProtectionTcpFlowProtectionFilterItem: API.OperationMethod<DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest, DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse, DeleteAdvancedTcpProtectionTcpFlowProtectionFilterItemError, CloudflareOpContext>;
export type DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemError = TcpFlowProtectionRuleNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Delete a TCP Flow Protection rule specified by the given UUID. */
export declare const deleteAdvancedTcpProtectionTcpFlowProtectionRuleItem: API.OperationMethod<DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest, DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse, DeleteAdvancedTcpProtectionTcpFlowProtectionRuleItemError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionAllowlistItemError = AllowlistEntryNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Get an allowlist prefix specified by the given UUID. */
export declare const getAdvancedTcpProtectionAllowlistItem: API.OperationMethod<GetAdvancedTcpProtectionAllowlistItemRequest, GetAdvancedTcpProtectionAllowlistItemResponse, GetAdvancedTcpProtectionAllowlistItemError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionPrefixItemError = CloudflareOpError;
/** Get a prefix specified by the given UUID. */
export declare const getAdvancedTcpProtectionPrefixItem: API.OperationMethod<GetAdvancedTcpProtectionPrefixItemRequest, GetAdvancedTcpProtectionPrefixItemResponse, GetAdvancedTcpProtectionPrefixItemError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionStatusError = CloudflareOpError;
/** Get the protection status of the account. */
export declare const getAdvancedTcpProtectionStatus: API.OperationMethod<GetAdvancedTcpProtectionStatusRequest, GetAdvancedTcpProtectionStatusResponse, GetAdvancedTcpProtectionStatusError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionSynProtectionFilterItemError = SynProtectionFilterNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Get a SYN Protection filter specified by the given UUID. */
export declare const getAdvancedTcpProtectionSynProtectionFilterItem: API.OperationMethod<GetAdvancedTcpProtectionSynProtectionFilterItemRequest, GetAdvancedTcpProtectionSynProtectionFilterItemResponse, GetAdvancedTcpProtectionSynProtectionFilterItemError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionSynProtectionRuleItemError = SynProtectionRuleNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Get a SYN Protection rule specified by the given UUID. */
export declare const getAdvancedTcpProtectionSynProtectionRuleItem: API.OperationMethod<GetAdvancedTcpProtectionSynProtectionRuleItemRequest, GetAdvancedTcpProtectionSynProtectionRuleItemResponse, GetAdvancedTcpProtectionSynProtectionRuleItemError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionTcpFlowProtectionFilterItemError = TcpFlowProtectionFilterNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Get a TCP Flow Protection filter specified by the given UUID. */
export declare const getAdvancedTcpProtectionTcpFlowProtectionFilterItem: API.OperationMethod<GetAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest, GetAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse, GetAdvancedTcpProtectionTcpFlowProtectionFilterItemError, CloudflareOpContext>;
export type GetAdvancedTcpProtectionTcpFlowProtectionRuleItemError = TcpFlowProtectionRuleNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Get a TCP Flow Protection rule specified by the given UUID. */
export declare const getAdvancedTcpProtectionTcpFlowProtectionRuleItem: API.OperationMethod<GetAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest, GetAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse, GetAdvancedTcpProtectionTcpFlowProtectionRuleItemError, CloudflareOpContext>;
export type ListAdvancedTcpProtectionAllowlistsError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** List all allowlist prefixes for an account. */
export declare const listAdvancedTcpProtectionAllowlists: API.PaginatedOperationMethod<ListAdvancedTcpProtectionAllowlistsRequest, ListAdvancedTcpProtectionAllowlistsResponse, ListAdvancedTcpProtectionAllowlistsError, CloudflareOpContext, AdvancedTcpProtectionAllowlistListResultItem>;
export type ListAdvancedTcpProtectionPrefixesError = CloudflareOpError;
/** List all prefixes for an account. */
export declare const listAdvancedTcpProtectionPrefixes: API.PaginatedOperationMethod<ListAdvancedTcpProtectionPrefixesRequest, ListAdvancedTcpProtectionPrefixesResponse, ListAdvancedTcpProtectionPrefixesError, CloudflareOpContext, AdvancedTcpProtectionPrefixesBulkCreateResultItem>;
export type ListAdvancedTcpProtectionSynProtectionFiltersError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** List all SYN Protection filters for an account. */
export declare const listAdvancedTcpProtectionSynProtectionFilters: API.PaginatedOperationMethod<ListAdvancedTcpProtectionSynProtectionFiltersRequest, ListAdvancedTcpProtectionSynProtectionFiltersResponse, ListAdvancedTcpProtectionSynProtectionFiltersError, CloudflareOpContext, AdvancedTcpProtectionSynProtectionFiltersListResultItem>;
export type ListAdvancedTcpProtectionSynProtectionRulesError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** List all SYN Protection rules for an account. */
export declare const listAdvancedTcpProtectionSynProtectionRules: API.PaginatedOperationMethod<ListAdvancedTcpProtectionSynProtectionRulesRequest, ListAdvancedTcpProtectionSynProtectionRulesResponse, ListAdvancedTcpProtectionSynProtectionRulesError, CloudflareOpContext, AdvancedTcpProtectionSynProtectionRulesListResultItem>;
export type ListAdvancedTcpProtectionTcpFlowProtectionFiltersError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** List all TCP Flow Protection filters for an account. */
export declare const listAdvancedTcpProtectionTcpFlowProtectionFilters: API.PaginatedOperationMethod<ListAdvancedTcpProtectionTcpFlowProtectionFiltersRequest, ListAdvancedTcpProtectionTcpFlowProtectionFiltersResponse, ListAdvancedTcpProtectionTcpFlowProtectionFiltersError, CloudflareOpContext, AdvancedTcpProtectionSynProtectionFiltersListResultItem>;
export type ListAdvancedTcpProtectionTcpFlowProtectionRulesError = AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** List all TCP Flow Protection rules for an account. */
export declare const listAdvancedTcpProtectionTcpFlowProtectionRules: API.PaginatedOperationMethod<ListAdvancedTcpProtectionTcpFlowProtectionRulesRequest, ListAdvancedTcpProtectionTcpFlowProtectionRulesResponse, ListAdvancedTcpProtectionTcpFlowProtectionRulesError, CloudflareOpContext, AdvancedTcpProtectionTcpFlowProtectionRulesListResultItem>;
export type PatchAdvancedTcpProtectionAllowlistItemError = AllowlistEntryNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Update an allowlist prefix specified by the given UUID. */
export declare const patchAdvancedTcpProtectionAllowlistItem: API.OperationMethod<PatchAdvancedTcpProtectionAllowlistItemRequest, PatchAdvancedTcpProtectionAllowlistItemResponse, PatchAdvancedTcpProtectionAllowlistItemError, CloudflareOpContext>;
export type PatchAdvancedTcpProtectionPrefixItemError = CloudflareOpError;
/** Update a prefix specified by the given UUID. */
export declare const patchAdvancedTcpProtectionPrefixItem: API.OperationMethod<PatchAdvancedTcpProtectionPrefixItemRequest, PatchAdvancedTcpProtectionPrefixItemResponse, PatchAdvancedTcpProtectionPrefixItemError, CloudflareOpContext>;
export type PatchAdvancedTcpProtectionStatusError = CloudflareOpError;
/** Update the protection status of the account. */
export declare const patchAdvancedTcpProtectionStatus: API.OperationMethod<PatchAdvancedTcpProtectionStatusRequest, PatchAdvancedTcpProtectionStatusResponse, PatchAdvancedTcpProtectionStatusError, CloudflareOpContext>;
export type PatchAdvancedTcpProtectionSynProtectionFilterItemError = SynProtectionFilterNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Update a SYN Protection filter specified by the given UUID. */
export declare const patchAdvancedTcpProtectionSynProtectionFilterItem: API.OperationMethod<PatchAdvancedTcpProtectionSynProtectionFilterItemRequest, PatchAdvancedTcpProtectionSynProtectionFilterItemResponse, PatchAdvancedTcpProtectionSynProtectionFilterItemError, CloudflareOpContext>;
export type PatchAdvancedTcpProtectionSynProtectionRuleItemError = SynProtectionRuleNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Update a SYN Protection rule specified by the given UUID. */
export declare const patchAdvancedTcpProtectionSynProtectionRuleItem: API.OperationMethod<PatchAdvancedTcpProtectionSynProtectionRuleItemRequest, PatchAdvancedTcpProtectionSynProtectionRuleItemResponse, PatchAdvancedTcpProtectionSynProtectionRuleItemError, CloudflareOpContext>;
export type PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemError = TcpFlowProtectionFilterNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Update a TCP Flow Protection filter specified by the given UUID. */
export declare const patchAdvancedTcpProtectionTcpFlowProtectionFilterItem: API.OperationMethod<PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemRequest, PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemResponse, PatchAdvancedTcpProtectionTcpFlowProtectionFilterItemError, CloudflareOpContext>;
export type PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemError = TcpFlowProtectionRuleNotFound | AdvancedTcpProtectionNotEntitled | Forbidden | CloudflareOpError;
/** Update a TCP Flow Protection rule specified by the given UUID. */
export declare const patchAdvancedTcpProtectionTcpFlowProtectionRuleItem: API.OperationMethod<PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemRequest, PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemResponse, PatchAdvancedTcpProtectionTcpFlowProtectionRuleItemError, CloudflareOpContext>;
//# sourceMappingURL=ddos_protection.d.ts.map