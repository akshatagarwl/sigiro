import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const FraudDetectionNotEntitled_base: S.Class<FraudDetectionNotEntitled, S.TaggedStruct<"FraudDetectionNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FraudDetectionNotEntitled extends /*@__PURE__*/ FraudDetectionNotEntitled_base {
}
export interface GetFraudRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetFraudRequest: S.Schema<GetFraudRequest>;
export type GetResponseAuthenticationSettingsFailureCriteriaKind = "status_code";
export declare const GetResponseAuthenticationSettingsFailureCriteriaKind: any;
export type GetResponseAuthenticationSettingsFailureCriteriaStatusCodesList = Array<number>;
export declare const GetResponseAuthenticationSettingsFailureCriteriaStatusCodesList: S.Schema<GetResponseAuthenticationSettingsFailureCriteriaStatusCodesList>;
export interface GetResponseAuthenticationSettingsFailureCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: GetResponseAuthenticationSettingsFailureCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: GetResponseAuthenticationSettingsFailureCriteriaStatusCodesList | null;
}
export declare const GetResponseAuthenticationSettingsFailureCriteria: S.Schema<GetResponseAuthenticationSettingsFailureCriteria>;
export type GetResponseAuthenticationSettingsSuccessCriteriaKind = "status_code";
export declare const GetResponseAuthenticationSettingsSuccessCriteriaKind: any;
export type GetResponseAuthenticationSettingsSuccessCriteriaStatusCodesList = Array<number>;
export declare const GetResponseAuthenticationSettingsSuccessCriteriaStatusCodesList: S.Schema<GetResponseAuthenticationSettingsSuccessCriteriaStatusCodesList>;
export interface GetResponseAuthenticationSettingsSuccessCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: GetResponseAuthenticationSettingsSuccessCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: GetResponseAuthenticationSettingsSuccessCriteriaStatusCodesList | null;
}
export declare const GetResponseAuthenticationSettingsSuccessCriteria: S.Schema<GetResponseAuthenticationSettingsSuccessCriteria>;
export interface GetResponseAuthenticationSettings {
    /** Criterion for identifying failed login responses. */
    failureCriteria?: GetResponseAuthenticationSettingsFailureCriteria | null;
    /** Criterion for identifying successful login responses. */
    successCriteria?: GetResponseAuthenticationSettingsSuccessCriteria | null;
}
export declare const GetResponseAuthenticationSettings: S.Schema<GetResponseAuthenticationSettings>;
export type GetResponseUserProfiles = "enabled" | "disabled";
export declare const GetResponseUserProfiles: any;
export type GetResponseUsernameExpressionsList = Array<string>;
export declare const GetResponseUsernameExpressionsList: S.Schema<GetResponseUsernameExpressionsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetFraudResponse {
    /** Configuration for classifying login authentication outcomes based on the origin response. */
    authenticationSettings?: GetResponseAuthenticationSettings | null;
    /** Whether Fraud User Profiles is enabled for the zone. */
    userProfiles?: GetResponseUserProfiles | null;
    /** List of expressions to detect usernames in write HTTP requests. */
    usernameExpressions?: GetResponseUsernameExpressionsList | null;
}
export declare const GetFraudResponse: S.Schema<GetFraudResponse>;
export type UpdateRequestAuthenticationSettingsFailureCriteriaKind = "status_code";
export declare const UpdateRequestAuthenticationSettingsFailureCriteriaKind: any;
export type UpdateRequestAuthenticationSettingsFailureCriteriaStatusCodesList = Array<number>;
export declare const UpdateRequestAuthenticationSettingsFailureCriteriaStatusCodesList: S.Schema<UpdateRequestAuthenticationSettingsFailureCriteriaStatusCodesList>;
export interface UpdateRequestAuthenticationSettingsFailureCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateRequestAuthenticationSettingsFailureCriteriaKind | (string & {});
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateRequestAuthenticationSettingsFailureCriteriaStatusCodesList;
}
export declare const UpdateRequestAuthenticationSettingsFailureCriteria: S.Schema<UpdateRequestAuthenticationSettingsFailureCriteria>;
export type UpdateRequestAuthenticationSettingsSuccessCriteriaKind = "status_code";
export declare const UpdateRequestAuthenticationSettingsSuccessCriteriaKind: any;
export type UpdateRequestAuthenticationSettingsSuccessCriteriaStatusCodesList = Array<number>;
export declare const UpdateRequestAuthenticationSettingsSuccessCriteriaStatusCodesList: S.Schema<UpdateRequestAuthenticationSettingsSuccessCriteriaStatusCodesList>;
export interface UpdateRequestAuthenticationSettingsSuccessCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateRequestAuthenticationSettingsSuccessCriteriaKind | (string & {});
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateRequestAuthenticationSettingsSuccessCriteriaStatusCodesList;
}
export declare const UpdateRequestAuthenticationSettingsSuccessCriteria: S.Schema<UpdateRequestAuthenticationSettingsSuccessCriteria>;
export interface UpdateRequestAuthenticationSettings {
    /** Criterion for identifying failed login responses. */
    failureCriteria?: UpdateRequestAuthenticationSettingsFailureCriteria;
    /** Criterion for identifying successful login responses. */
    successCriteria?: UpdateRequestAuthenticationSettingsSuccessCriteria;
}
export declare const UpdateRequestAuthenticationSettings: S.Schema<UpdateRequestAuthenticationSettings>;
export type UpdateRequestUserProfiles = "enabled" | "disabled";
export declare const UpdateRequestUserProfiles: any;
export type UpdateRequestUsernameExpressionsList = Array<string>;
export declare const UpdateRequestUsernameExpressionsList: S.Schema<UpdateRequestUsernameExpressionsList>;
export interface PutFraudRequest {
    /** Identifier. */
    zoneId: string;
    /** Configuration for classifying login authentication outcomes based on the origin response. */
    authenticationSettings?: UpdateRequestAuthenticationSettings;
    /** Whether Fraud User Profiles is enabled for the zone. */
    userProfiles?: UpdateRequestUserProfiles | (string & {});
    /** List of expressions to detect usernames in write HTTP requests. */
    usernameExpressions?: UpdateRequestUsernameExpressionsList;
}
export declare const PutFraudRequest: S.Schema<PutFraudRequest>;
export type UpdateResponseAuthenticationSettingsFailureCriteriaKind = "status_code";
export declare const UpdateResponseAuthenticationSettingsFailureCriteriaKind: any;
export type UpdateResponseAuthenticationSettingsFailureCriteriaStatusCodesList = Array<number>;
export declare const UpdateResponseAuthenticationSettingsFailureCriteriaStatusCodesList: S.Schema<UpdateResponseAuthenticationSettingsFailureCriteriaStatusCodesList>;
export interface UpdateResponseAuthenticationSettingsFailureCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateResponseAuthenticationSettingsFailureCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateResponseAuthenticationSettingsFailureCriteriaStatusCodesList | null;
}
export declare const UpdateResponseAuthenticationSettingsFailureCriteria: S.Schema<UpdateResponseAuthenticationSettingsFailureCriteria>;
export type UpdateResponseAuthenticationSettingsSuccessCriteriaKind = "status_code";
export declare const UpdateResponseAuthenticationSettingsSuccessCriteriaKind: any;
export type UpdateResponseAuthenticationSettingsSuccessCriteriaStatusCodesList = Array<number>;
export declare const UpdateResponseAuthenticationSettingsSuccessCriteriaStatusCodesList: S.Schema<UpdateResponseAuthenticationSettingsSuccessCriteriaStatusCodesList>;
export interface UpdateResponseAuthenticationSettingsSuccessCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateResponseAuthenticationSettingsSuccessCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateResponseAuthenticationSettingsSuccessCriteriaStatusCodesList | null;
}
export declare const UpdateResponseAuthenticationSettingsSuccessCriteria: S.Schema<UpdateResponseAuthenticationSettingsSuccessCriteria>;
export interface UpdateResponseAuthenticationSettings {
    /** Criterion for identifying failed login responses. */
    failureCriteria?: UpdateResponseAuthenticationSettingsFailureCriteria | null;
    /** Criterion for identifying successful login responses. */
    successCriteria?: UpdateResponseAuthenticationSettingsSuccessCriteria | null;
}
export declare const UpdateResponseAuthenticationSettings: S.Schema<UpdateResponseAuthenticationSettings>;
export type UpdateResponseUserProfiles = "enabled" | "disabled";
export declare const UpdateResponseUserProfiles: any;
export type UpdateResponseUsernameExpressionsList = Array<string>;
export declare const UpdateResponseUsernameExpressionsList: S.Schema<UpdateResponseUsernameExpressionsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutFraudResponse {
    /** Configuration for classifying login authentication outcomes based on the origin response. */
    authenticationSettings?: UpdateResponseAuthenticationSettings | null;
    /** Whether Fraud User Profiles is enabled for the zone. */
    userProfiles?: UpdateResponseUserProfiles | null;
    /** List of expressions to detect usernames in write HTTP requests. */
    usernameExpressions?: UpdateResponseUsernameExpressionsList | null;
}
export declare const PutFraudResponse: S.Schema<PutFraudResponse>;
export type GetFraudError = Forbidden | CloudflareOpError;
/** Retrieve Fraud Detection settings for a zone. */
export declare const getFraud: API.OperationMethod<GetFraudRequest, GetFraudResponse, GetFraudError, CloudflareOpContext>;
export type PutFraudError = Forbidden | FraudDetectionNotEntitled | CloudflareOpError;
/** Update Fraud Detection settings for a zone. Notes on `username_expressions` behavior: - If omitted or set to null, expressions are not modified. - If provided as an empty array `[]`, all expressions will be cleared. */
export declare const putFraud: API.OperationMethod<PutFraudRequest, PutFraudResponse, PutFraudError, CloudflareOpContext>;
//# sourceMappingURL=fraud.d.ts.map