import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccountCreationForbidden_base: S.Class<AccountCreationForbidden, S.TaggedStruct<"AccountCreationForbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AccountCreationForbidden extends /*@__PURE__*/ AccountCreationForbidden_base {
}
declare const AccountMemberAlreadyExists_base: S.Class<AccountMemberAlreadyExists, S.TaggedStruct<"AccountMemberAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AccountMemberAlreadyExists extends /*@__PURE__*/ AccountMemberAlreadyExists_base {
}
declare const AccountNameTooLong_base: S.Class<AccountNameTooLong, S.TaggedStruct<"AccountNameTooLong", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AccountNameTooLong extends /*@__PURE__*/ AccountNameTooLong_base {
}
declare const BadRequest_base: S.Class<BadRequest, S.TaggedStruct<"BadRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const EndpointNotFound_base: S.Class<EndpointNotFound, S.TaggedStruct<"EndpointNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EndpointNotFound extends /*@__PURE__*/ EndpointNotFound_base {
}
declare const InvalidAccountName_base: S.Class<InvalidAccountName, S.TaggedStruct<"InvalidAccountName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAccountName extends /*@__PURE__*/ InvalidAccountName_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenName_base: S.Class<InvalidTokenName, S.TaggedStruct<"InvalidTokenName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTokenName extends /*@__PURE__*/ InvalidTokenName_base {
}
declare const JsonDecodeFailure_base: S.Class<JsonDecodeFailure, S.TaggedStruct<"JsonDecodeFailure", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class JsonDecodeFailure extends /*@__PURE__*/ JsonDecodeFailure_base {
}
declare const MemberNotFound_base: S.Class<MemberNotFound, S.TaggedStruct<"MemberNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MemberNotFound extends /*@__PURE__*/ MemberNotFound_base {
}
declare const MethodNotAllowed_base: S.Class<MethodNotAllowed, S.TaggedStruct<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const MissingAuthenticationToken_base: S.Class<MissingAuthenticationToken, S.TaggedStruct<"MissingAuthenticationToken", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingAuthenticationToken extends /*@__PURE__*/ MissingAuthenticationToken_base {
}
declare const MissingName_base: S.Class<MissingName, S.TaggedStruct<"MissingName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingName extends /*@__PURE__*/ MissingName_base {
}
declare const PermissionGroupNotFound_base: S.Class<PermissionGroupNotFound, S.TaggedStruct<"PermissionGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PermissionGroupNotFound extends /*@__PURE__*/ PermissionGroupNotFound_base {
}
declare const TokenManagedByCloudflare_base: S.Class<TokenManagedByCloudflare, S.TaggedStruct<"TokenManagedByCloudflare", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenManagedByCloudflare extends /*@__PURE__*/ TokenManagedByCloudflare_base {
}
declare const TokenNotFound_base: S.Class<TokenNotFound, S.TaggedStruct<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
declare const UpdateAccountTypeNotSupported_base: S.Class<UpdateAccountTypeNotSupported, S.TaggedStruct<"UpdateAccountTypeNotSupported", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UpdateAccountTypeNotSupported extends /*@__PURE__*/ UpdateAccountTypeNotSupported_base {
}
declare const ValidationError_base: S.Class<ValidationError, S.TaggedStruct<"ValidationError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
export type CreateRequestType = "standard" | "enterprise";
export declare const CreateRequestType: any;
export interface CreateRequestUnit {
    /** Tenant unit ID */
    id?: string;
}
export declare const CreateRequestUnit: S.Schema<CreateRequestUnit>;
export interface CreateAccountRequest {
    /** Account name */
    name: string;
    type?: CreateRequestType | (string & {});
    /** information related to the tenant unit, and optionally, an id of the unit to create the account on. see https://developers.cloudflare.com/tenant/how-to/manage-accounts/ */
    unit?: CreateRequestUnit;
}
export declare const CreateAccountRequest: S.Schema<CreateAccountRequest>;
export type CreateResponseType = "standard" | "enterprise";
export declare const CreateResponseType: any;
export interface CreateResponseManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | null;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | null;
}
export declare const CreateResponseManagedBy: S.Schema<CreateResponseManagedBy>;
export interface CreateResponseSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | null;
    /** Indicates whether membership in this account requires that */
    enforceTwofactor?: boolean | null;
}
export declare const CreateResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: CreateResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export declare const CreateAccountResponse: S.Schema<CreateAccountResponse>;
export interface CreateAccountOrganizationRequest {
    accountId: string;
    destinationOrganizationId: string;
}
export declare const CreateAccountOrganizationRequest: S.Schema<CreateAccountOrganizationRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccountOrganizationResponse {
    accountId: string;
    destinationOrganizationId: string;
    sourceOrganizationId: string;
}
export declare const CreateAccountOrganizationResponse: S.Schema<CreateAccountOrganizationResponse>;
export type MembersCreateRequestRolesList = Array<string>;
export declare const MembersCreateRequestRolesList: S.Schema<MembersCreateRequestRolesList>;
export type MembersCreateRequestStatus = "accepted" | "pending";
export declare const MembersCreateRequestStatus: any;
export type MembersCreateRequestPoliciesItemAccess = "allow" | "deny";
export declare const MembersCreateRequestPoliciesItemAccess: any;
export interface MembersCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the group. */
    id: string;
}
export declare const MembersCreateRequestPoliciesItemPermissionGroupsItem: S.Schema<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersCreateRequestPoliciesItemPermissionGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const MembersCreateRequestPoliciesItemPermissionGroupsList: S.Schema<MembersCreateRequestPoliciesItemPermissionGroupsList>;
export type MembersCreateRequestPoliciesItemResourceGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export declare const MembersCreateRequestPoliciesItemResourceGroupsItem: S.Schema<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersCreateRequestPoliciesItemResourceGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const MembersCreateRequestPoliciesItemResourceGroupsList: S.Schema<MembersCreateRequestPoliciesItemResourceGroupsList>;
export interface MembersCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    access: MembersCreateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: MembersCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource groups that the policy applies to. */
    resourceGroups: MembersCreateRequestPoliciesItemResourceGroupsList;
}
export declare const MembersCreateRequestPoliciesItem: S.Schema<MembersCreateRequestPoliciesItem>;
export type MembersCreateRequestPoliciesList = Array<MembersCreateRequestPoliciesItem>;
export declare const MembersCreateRequestPoliciesList: S.Schema<MembersCreateRequestPoliciesList>;
export interface CreateMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The contact email address of the user. */
    email: string;
    /** Array of roles associated with this member. */
    roles?: MembersCreateRequestRolesList;
    /** Status of the member invitation. If not provided during creation, defaults to 'pending'. */
    status?: MembersCreateRequestStatus | (string & {});
    /** Array of policies associated with this member. */
    policies?: MembersCreateRequestPoliciesList;
}
export declare const CreateMemberRequest: S.Schema<CreateMemberRequest>;
export type MembersCreateResponsePoliciesItemAccess = "allow" | "deny";
export declare const MembersCreateResponsePoliciesItemAccess: any;
export interface MembersCreateResponsePoliciesItemPermissionGroupsItemMeta {
    key?: string | null;
    value?: string | null;
}
export declare const MembersCreateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export interface MembersCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export declare const MembersCreateResponsePoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersCreateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const MembersCreateResponsePoliciesItemPermissionGroupsList: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsList>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export declare const MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export type MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export declare const MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const MembersCreateResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItem>;
export type MembersCreateResponsePoliciesItemResourceGroupsItemScopeList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const MembersCreateResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeList>;
export type MembersCreateResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersCreateResponsePoliciesItemResourceGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersCreateResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const MembersCreateResponsePoliciesItemResourceGroupsItem: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItem>;
export type MembersCreateResponsePoliciesItemResourceGroupsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItem>;
export declare const MembersCreateResponsePoliciesItemResourceGroupsList: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsList>;
export interface MembersCreateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersCreateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersCreateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersCreateResponsePoliciesItemResourceGroupsList | null;
}
export declare const MembersCreateResponsePoliciesItem: S.Schema<MembersCreateResponsePoliciesItem>;
export type MembersCreateResponsePoliciesList = Array<MembersCreateResponsePoliciesItem>;
export declare const MembersCreateResponsePoliciesList: S.Schema<MembersCreateResponsePoliciesList>;
export interface MembersCreateResponseRolesItemPermissionsAnalytics {
    read?: boolean | null;
    write?: boolean | null;
}
export declare const MembersCreateResponseRolesItemPermissionsAnalytics: S.Schema<MembersCreateResponseRolesItemPermissionsAnalytics>;
export interface MembersCreateResponseRolesItemPermissions {
    analytics?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    billing?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    cachePurge?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    dns?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    dnsRecords?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    lb?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    logs?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    organization?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    ssl?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    waf?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    zoneSettings?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
    zones?: MembersCreateResponseRolesItemPermissionsAnalytics | null;
}
export declare const MembersCreateResponseRolesItemPermissions: S.Schema<MembersCreateResponseRolesItemPermissions>;
export interface MembersCreateResponseRolesItem {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description: string;
    /** Role name. */
    name: string;
    permissions: MembersCreateResponseRolesItemPermissions;
}
export declare const MembersCreateResponseRolesItem: S.Schema<MembersCreateResponseRolesItem>;
export type MembersCreateResponseRolesList = Array<MembersCreateResponseRolesItem>;
export declare const MembersCreateResponseRolesList: S.Schema<MembersCreateResponseRolesList>;
export type MembersCreateResponseStatus = "accepted" | "pending";
export declare const MembersCreateResponseStatus: any;
export interface MembersCreateResponseUser {
    /** The contact email address of the user. */
    email: string;
    /** Identifier */
    id?: string | null;
    /** User's first name */
    firstName?: string | null;
    /** User's last name */
    lastName?: string | null;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null;
}
export declare const MembersCreateResponseUser: S.Schema<MembersCreateResponseUser>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMemberResponse {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersCreateResponsePoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersCreateResponseRolesList | null;
    /** A member's status in the account. */
    status?: MembersCreateResponseStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export declare const CreateMemberResponse: S.Schema<CreateMemberResponse>;
export type SubscriptionsCreateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsCreateRequestFrequency: any;
export type SubscriptionsCreateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsCreateRequestRatePlanId: any;
export type SubscriptionsCreateRequestRatePlanSetsList = Array<string>;
export declare const SubscriptionsCreateRequestRatePlanSetsList: S.Schema<SubscriptionsCreateRequestRatePlanSetsList>;
export interface SubscriptionsCreateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateRequestRatePlanSetsList;
}
export declare const SubscriptionsCreateRequestRatePlan: S.Schema<SubscriptionsCreateRequestRatePlan>;
export interface CreateSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateRequestRatePlan;
}
export declare const CreateSubscriptionRequest: S.Schema<CreateSubscriptionRequest>;
export type SubscriptionsCreateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsCreateResponseFrequency: any;
export type SubscriptionsCreateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsCreateResponseRatePlanId: any;
export type SubscriptionsCreateResponseRatePlanSetsList = Array<string>;
export declare const SubscriptionsCreateResponseRatePlanSetsList: S.Schema<SubscriptionsCreateResponseRatePlanSetsList>;
export interface SubscriptionsCreateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateResponseRatePlanSetsList | null;
}
export declare const SubscriptionsCreateResponseRatePlan: S.Schema<SubscriptionsCreateResponseRatePlan>;
export type SubscriptionsCreateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsCreateResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsCreateResponseState | null;
}
export declare const CreateSubscriptionResponse: S.Schema<CreateSubscriptionResponse>;
export type TokensCreateRequestPoliciesItemEffect = "allow" | "deny";
export declare const TokensCreateRequestPoliciesItemEffect: any;
export interface TokensCreateRequestPoliciesItemPermissionGroupsItemMeta {
    key?: string;
    value?: string;
}
export declare const TokensCreateRequestPoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItemMeta>;
export interface TokensCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
    /** Name of the permission group. */
    name?: string;
}
export declare const TokensCreateRequestPoliciesItemPermissionGroupsItem: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensCreateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const TokensCreateRequestPoliciesItemPermissionGroupsList: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsList>;
export type TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensCreateRequestPoliciesItemResourcesValue = string | TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensCreateRequestPoliciesItemResourcesValue: any;
export type TokensCreateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensCreateRequestPoliciesItemResourcesValue | undefined;
};
export declare const TokensCreateRequestPoliciesItemResourcesMap: S.Schema<TokensCreateRequestPoliciesItemResourcesMap>;
export interface TokensCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensCreateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateRequestPoliciesItemResourcesMap;
}
export declare const TokensCreateRequestPoliciesItem: S.Schema<TokensCreateRequestPoliciesItem>;
export type TokensCreateRequestPoliciesList = Array<TokensCreateRequestPoliciesItem>;
export declare const TokensCreateRequestPoliciesList: S.Schema<TokensCreateRequestPoliciesList>;
export type TokensCreateRequestConditionRequestIpInList = Array<string>;
export declare const TokensCreateRequestConditionRequestIpInList: S.Schema<TokensCreateRequestConditionRequestIpInList>;
export type TokensCreateRequestConditionRequestIpNotInList = Array<string>;
export declare const TokensCreateRequestConditionRequestIpNotInList: S.Schema<TokensCreateRequestConditionRequestIpNotInList>;
export interface TokensCreateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateRequestConditionRequestIpNotInList;
}
export declare const TokensCreateRequestConditionRequestIp: S.Schema<TokensCreateRequestConditionRequestIp>;
export interface TokensCreateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateRequestConditionRequestIp;
}
export declare const TokensCreateRequestCondition: S.Schema<TokensCreateRequestCondition>;
export interface CreateTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensCreateRequestPoliciesList;
    condition?: TokensCreateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
}
export declare const CreateTokenRequest: S.Schema<CreateTokenRequest>;
export type TokensCreateResponseConditionRequestIpInList = Array<string>;
export declare const TokensCreateResponseConditionRequestIpInList: S.Schema<TokensCreateResponseConditionRequestIpInList>;
export type TokensCreateResponseConditionRequestIpNotInList = Array<string>;
export declare const TokensCreateResponseConditionRequestIpNotInList: S.Schema<TokensCreateResponseConditionRequestIpNotInList>;
export interface TokensCreateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateResponseConditionRequestIpNotInList | null;
}
export declare const TokensCreateResponseConditionRequestIp: S.Schema<TokensCreateResponseConditionRequestIp>;
export interface TokensCreateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateResponseConditionRequestIp | null;
}
export declare const TokensCreateResponseCondition: S.Schema<TokensCreateResponseCondition>;
export type TokensCreateResponsePoliciesItemEffect = "allow" | "deny";
export declare const TokensCreateResponsePoliciesItemEffect: any;
export type TokensCreateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensCreateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensCreateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensCreateResponsePoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensCreateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensCreateResponsePoliciesItemPermissionGroupsList: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsList>;
export type TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensCreateResponsePoliciesItemResourcesValue = string | TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensCreateResponsePoliciesItemResourcesValue: any;
export type TokensCreateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensCreateResponsePoliciesItemResourcesValue | undefined;
};
export declare const TokensCreateResponsePoliciesItemResourcesMap: S.Schema<TokensCreateResponsePoliciesItemResourcesMap>;
export interface TokensCreateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensCreateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateResponsePoliciesItemResourcesMap;
}
export declare const TokensCreateResponsePoliciesItem: S.Schema<TokensCreateResponsePoliciesItem>;
export type TokensCreateResponsePoliciesList = Array<TokensCreateResponsePoliciesItem>;
export declare const TokensCreateResponsePoliciesList: S.Schema<TokensCreateResponsePoliciesList>;
export type TokensCreateResponseStatus = "active" | "disabled" | "expired";
export declare const TokensCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensCreateResponseCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensCreateResponsePoliciesList | null;
    /** Status of the token. */
    status?: TokensCreateResponseStatus | null;
    /** The token value. */
    value?: string | null;
}
export declare const CreateTokenResponse: S.Schema<CreateTokenResponse>;
export interface DeleteAccountRequest {
    /** The account ID of the account to be deleted */
    accountId: string;
}
export declare const DeleteAccountRequest: S.Schema<DeleteAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAccountResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteAccountResponse: S.Schema<DeleteAccountResponse>;
export interface DeleteMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
}
export declare const DeleteMemberRequest: S.Schema<DeleteMemberRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMemberResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteMemberResponse: S.Schema<DeleteMemberResponse>;
export interface DeleteSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
export declare const DeleteSubscriptionRequest: S.Schema<DeleteSubscriptionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSubscriptionResponse {
    /** Subscription identifier tag. */
    subscriptionId?: string | null;
}
export declare const DeleteSubscriptionResponse: S.Schema<DeleteSubscriptionResponse>;
export interface DeleteTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export declare const DeleteTokenRequest: S.Schema<DeleteTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTokenResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteTokenResponse: S.Schema<DeleteTokenResponse>;
export interface GetAccountRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const GetAccountRequest: S.Schema<GetAccountRequest>;
export type GetResponseType = "standard" | "enterprise";
export declare const GetResponseType: any;
export type GetResponseManagedBy = CreateResponseManagedBy;
export declare const GetResponseManagedBy: S.Schema<CreateResponseManagedBy>;
export type GetResponseSettings = CreateResponseSettings;
export declare const GetResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: GetResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export declare const GetAccountResponse: S.Schema<GetAccountResponse>;
export interface GetAccountProfileRequest {
    accountId: string;
}
export declare const GetAccountProfileRequest: S.Schema<GetAccountProfileRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountProfileResponse {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export declare const GetAccountProfileResponse: S.Schema<GetAccountProfileResponse>;
export interface GetMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
}
export declare const GetMemberRequest: S.Schema<GetMemberRequest>;
export type MembersGetResponsePoliciesItemAccess = "allow" | "deny";
export declare const MembersGetResponsePoliciesItemAccess: any;
export type MembersGetResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersGetResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type MembersGetResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const MembersGetResponsePoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersGetResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const MembersGetResponsePoliciesItemPermissionGroupsList: S.Schema<MembersGetResponsePoliciesItemPermissionGroupsList>;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem;
export declare const MembersGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export declare const MembersGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<MembersGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface MembersGetResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const MembersGetResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<MembersGetResponsePoliciesItemResourceGroupsItemScopeItem>;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeList = Array<MembersGetResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const MembersGetResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<MembersGetResponsePoliciesItemResourceGroupsItemScopeList>;
export type MembersGetResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersGetResponsePoliciesItemResourceGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export interface MembersGetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersGetResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const MembersGetResponsePoliciesItemResourceGroupsItem: S.Schema<MembersGetResponsePoliciesItemResourceGroupsItem>;
export type MembersGetResponsePoliciesItemResourceGroupsList = Array<MembersGetResponsePoliciesItemResourceGroupsItem>;
export declare const MembersGetResponsePoliciesItemResourceGroupsList: S.Schema<MembersGetResponsePoliciesItemResourceGroupsList>;
export interface MembersGetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersGetResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersGetResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersGetResponsePoliciesItemResourceGroupsList | null;
}
export declare const MembersGetResponsePoliciesItem: S.Schema<MembersGetResponsePoliciesItem>;
export type MembersGetResponsePoliciesList = Array<MembersGetResponsePoliciesItem>;
export declare const MembersGetResponsePoliciesList: S.Schema<MembersGetResponsePoliciesList>;
export type MembersGetResponseRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export declare const MembersGetResponseRolesItemPermissionsAnalytics: S.Schema<MembersCreateResponseRolesItemPermissionsAnalytics>;
export type MembersGetResponseRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export declare const MembersGetResponseRolesItemPermissions: S.Schema<MembersCreateResponseRolesItemPermissions>;
export type MembersGetResponseRolesItem = MembersCreateResponseRolesItem;
export declare const MembersGetResponseRolesItem: S.Schema<MembersCreateResponseRolesItem>;
export type MembersGetResponseRolesList = Array<MembersCreateResponseRolesItem>;
export declare const MembersGetResponseRolesList: S.Schema<MembersGetResponseRolesList>;
export type MembersGetResponseStatus = "accepted" | "pending";
export declare const MembersGetResponseStatus: any;
export type MembersGetResponseUser = MembersCreateResponseUser;
export declare const MembersGetResponseUser: S.Schema<MembersCreateResponseUser>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMemberResponse {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersGetResponsePoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersGetResponseRolesList | null;
    /** A member's status in the account. */
    status?: MembersGetResponseStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export declare const GetMemberResponse: S.Schema<GetMemberResponse>;
export interface GetRoleRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Role identifier tag. */
    roleId: string;
}
export declare const GetRoleRequest: S.Schema<GetRoleRequest>;
export type RolesGetResponsePermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export declare const RolesGetResponsePermissionsAnalytics: S.Schema<MembersCreateResponseRolesItemPermissionsAnalytics>;
export type RolesGetResponsePermissions = MembersCreateResponseRolesItemPermissions;
export declare const RolesGetResponsePermissions: S.Schema<MembersCreateResponseRolesItemPermissions>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRoleResponse {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description: string;
    /** Role name. */
    name: string;
    permissions: MembersCreateResponseRolesItemPermissions;
}
export declare const GetRoleResponse: S.Schema<GetRoleResponse>;
export interface GetSubscriptionRequest {
    /** Identifier */
    accountId: string;
}
export declare const GetSubscriptionRequest: S.Schema<GetSubscriptionRequest>;
export type SubscriptionsGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsGetResultItemFrequency: any;
export type SubscriptionsGetResultItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsGetResultItemRatePlanId: any;
export type SubscriptionsGetResultItemRatePlanSetsList = Array<string>;
export declare const SubscriptionsGetResultItemRatePlanSetsList: S.Schema<SubscriptionsGetResultItemRatePlanSetsList>;
export interface SubscriptionsGetResultItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResultItemRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResultItemRatePlanSetsList | null;
}
export declare const SubscriptionsGetResultItemRatePlan: S.Schema<SubscriptionsGetResultItemRatePlan>;
export type SubscriptionsGetResultItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsGetResultItemState: any;
export interface SubscriptionsGetResultItem {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResultItemFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResultItemRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResultItemState | null;
}
export declare const SubscriptionsGetResultItem: S.Schema<SubscriptionsGetResultItem>;
export type SubscriptionsGetResultList = Array<SubscriptionsGetResultItem>;
export declare const SubscriptionsGetResultList: S.Schema<SubscriptionsGetResultList>;
export interface GetSubscriptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetSubscriptionResponse: S.Schema<GetSubscriptionResponse>;
export interface GetTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export declare const GetTokenRequest: S.Schema<GetTokenRequest>;
export type TokensGetResponseConditionRequestIpInList = Array<string>;
export declare const TokensGetResponseConditionRequestIpInList: S.Schema<TokensGetResponseConditionRequestIpInList>;
export type TokensGetResponseConditionRequestIpNotInList = Array<string>;
export declare const TokensGetResponseConditionRequestIpNotInList: S.Schema<TokensGetResponseConditionRequestIpNotInList>;
export interface TokensGetResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensGetResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensGetResponseConditionRequestIpNotInList | null;
}
export declare const TokensGetResponseConditionRequestIp: S.Schema<TokensGetResponseConditionRequestIp>;
export interface TokensGetResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensGetResponseConditionRequestIp | null;
}
export declare const TokensGetResponseCondition: S.Schema<TokensGetResponseCondition>;
export type TokensGetResponsePoliciesItemEffect = "allow" | "deny";
export declare const TokensGetResponsePoliciesItemEffect: any;
export type TokensGetResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensGetResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensGetResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensGetResponsePoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensGetResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensGetResponsePoliciesItemPermissionGroupsList: S.Schema<TokensGetResponsePoliciesItemPermissionGroupsList>;
export type TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensGetResponsePoliciesItemResourcesValue = string | TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensGetResponsePoliciesItemResourcesValue: any;
export type TokensGetResponsePoliciesItemResourcesMap = {
    [key: string]: TokensGetResponsePoliciesItemResourcesValue | undefined;
};
export declare const TokensGetResponsePoliciesItemResourcesMap: S.Schema<TokensGetResponsePoliciesItemResourcesMap>;
export interface TokensGetResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensGetResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensGetResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensGetResponsePoliciesItemResourcesMap;
}
export declare const TokensGetResponsePoliciesItem: S.Schema<TokensGetResponsePoliciesItem>;
export type TokensGetResponsePoliciesList = Array<TokensGetResponsePoliciesItem>;
export declare const TokensGetResponsePoliciesList: S.Schema<TokensGetResponsePoliciesList>;
export type TokensGetResponseStatus = "active" | "disabled" | "expired";
export declare const TokensGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensGetResponseCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensGetResponsePoliciesList | null;
    /** Status of the token. */
    status?: TokensGetResponseStatus | null;
}
export declare const GetTokenResponse: S.Schema<GetTokenResponse>;
export interface GetTokenPermissionGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Filter by the name of the permission group. */
    name?: string;
    /** Filter by the scope of the permission group. */
    scope?: string;
}
export declare const GetTokenPermissionGroupRequest: S.Schema<GetTokenPermissionGroupRequest>;
export type TokensPermissionGroupsGetResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export declare const TokensPermissionGroupsGetResultItemCategory: any;
export type TokensPermissionGroupsGetResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export declare const TokensPermissionGroupsGetResultItemScopesItem: any;
export type TokensPermissionGroupsGetResultItemScopesList = Array<TokensPermissionGroupsGetResultItemScopesItem>;
export declare const TokensPermissionGroupsGetResultItemScopesList: S.Schema<TokensPermissionGroupsGetResultItemScopesList>;
export interface TokensPermissionGroupsGetResultItem {
    /** Public ID. */
    id?: string | null;
    /** Product category that this permission group belongs to. */
    category?: TokensPermissionGroupsGetResultItemCategory | null;
    /** Permission Group Name */
    name?: string | null;
    /** Resources to which the Permission Group is scoped */
    scopes?: TokensPermissionGroupsGetResultItemScopesList | null;
}
export declare const TokensPermissionGroupsGetResultItem: S.Schema<TokensPermissionGroupsGetResultItem>;
export type TokensPermissionGroupsGetResultList = Array<TokensPermissionGroupsGetResultItem>;
export declare const TokensPermissionGroupsGetResultList: S.Schema<TokensPermissionGroupsGetResultList>;
export type GetTokenPermissionGroupResponse = TokensPermissionGroupsGetResultList;
export declare const GetTokenPermissionGroupResponse: S.Schema<GetTokenPermissionGroupResponse>;
export type ListRequestDirection = "asc" | "desc";
export declare const ListRequestDirection: any;
export interface ListAccountsRequest {
    /** Direction to order results. */
    direction?: ListRequestDirection | (string & {});
    /** Name of the account. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListAccountsRequest: S.Schema<ListAccountsRequest>;
export type ListResultItemType = "standard" | "enterprise";
export declare const ListResultItemType: any;
export type ListResultItemManagedBy = CreateResponseManagedBy;
export declare const ListResultItemManagedBy: S.Schema<CreateResponseManagedBy>;
export type ListResultItemSettings = CreateResponseSettings;
export declare const ListResultItemSettings: S.Schema<CreateResponseSettings>;
export interface ListResultItem {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: ListResultItemType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListAccountsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAccountsResponse: S.Schema<ListAccountsResponse>;
export type LogsAuditListRequestIdNotList = Array<string>;
export declare const LogsAuditListRequestIdNotList: S.Schema<LogsAuditListRequestIdNotList>;
export interface LogsAuditListRequestId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestIdNotList;
}
export declare const LogsAuditListRequestId: S.Schema<LogsAuditListRequestId>;
export type LogsAuditListRequestAccountNameNotList = Array<string>;
export declare const LogsAuditListRequestAccountNameNotList: S.Schema<LogsAuditListRequestAccountNameNotList>;
export interface LogsAuditListRequestAccountName {
    /** Filters out audit logs by the account name. */
    not?: LogsAuditListRequestAccountNameNotList;
}
export declare const LogsAuditListRequestAccountName: S.Schema<LogsAuditListRequestAccountName>;
export type LogsAuditListRequestActionResultNotItem = "success" | "failure";
export declare const LogsAuditListRequestActionResultNotItem: any;
export type LogsAuditListRequestActionResultNotList = Array<LogsAuditListRequestActionResultNotItem | (string & {})>;
export declare const LogsAuditListRequestActionResultNotList: S.Schema<LogsAuditListRequestActionResultNotList>;
export interface LogsAuditListRequestActionResult {
    /** Filters out audit logs by whether the action was successful or not. */
    not?: LogsAuditListRequestActionResultNotList;
}
export declare const LogsAuditListRequestActionResult: S.Schema<LogsAuditListRequestActionResult>;
export type LogsAuditListRequestActionTypeNotItem = "create" | "delete" | "view" | "update";
export declare const LogsAuditListRequestActionTypeNotItem: any;
export type LogsAuditListRequestActionTypeNotList = Array<LogsAuditListRequestActionTypeNotItem | (string & {})>;
export declare const LogsAuditListRequestActionTypeNotList: S.Schema<LogsAuditListRequestActionTypeNotList>;
export interface LogsAuditListRequestActionType {
    /** Filters out audit logs by the action type. */
    not?: LogsAuditListRequestActionTypeNotList;
}
export declare const LogsAuditListRequestActionType: S.Schema<LogsAuditListRequestActionType>;
export type LogsAuditListRequestActorContextNotItem = "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export declare const LogsAuditListRequestActorContextNotItem: any;
export type LogsAuditListRequestActorContextNotList = Array<LogsAuditListRequestActorContextNotItem | (string & {})>;
export declare const LogsAuditListRequestActorContextNotList: S.Schema<LogsAuditListRequestActorContextNotList>;
export interface LogsAuditListRequestActorContext {
    /** Filters out audit logs by the actor context. */
    not?: LogsAuditListRequestActorContextNotList;
}
export declare const LogsAuditListRequestActorContext: S.Schema<LogsAuditListRequestActorContext>;
export type LogsAuditListRequestActorEmailNotList = Array<string>;
export declare const LogsAuditListRequestActorEmailNotList: S.Schema<LogsAuditListRequestActorEmailNotList>;
export interface LogsAuditListRequestActorEmail {
    /** Filters out audit logs by the actor's email address. */
    not?: LogsAuditListRequestActorEmailNotList;
}
export declare const LogsAuditListRequestActorEmail: S.Schema<LogsAuditListRequestActorEmail>;
export type LogsAuditListRequestActorIdNotList = Array<string>;
export declare const LogsAuditListRequestActorIdNotList: S.Schema<LogsAuditListRequestActorIdNotList>;
export interface LogsAuditListRequestActorId {
    /** Filters out audit logs by the actor ID. This can be either the Account ID or User ID. */
    not?: LogsAuditListRequestActorIdNotList;
}
export declare const LogsAuditListRequestActorId: S.Schema<LogsAuditListRequestActorId>;
export type LogsAuditListRequestActorIpAddressNotList = Array<string>;
export declare const LogsAuditListRequestActorIpAddressNotList: S.Schema<LogsAuditListRequestActorIpAddressNotList>;
export interface LogsAuditListRequestActorIpAddress {
    /** Filters out audit logs IP address where the action was initiated. */
    not?: LogsAuditListRequestActorIpAddressNotList;
}
export declare const LogsAuditListRequestActorIpAddress: S.Schema<LogsAuditListRequestActorIpAddress>;
export type LogsAuditListRequestActorTokenIdNotList = Array<string>;
export declare const LogsAuditListRequestActorTokenIdNotList: S.Schema<LogsAuditListRequestActorTokenIdNotList>;
export interface LogsAuditListRequestActorTokenId {
    /** Filters out audit logs by the API token ID when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenIdNotList;
}
export declare const LogsAuditListRequestActorTokenId: S.Schema<LogsAuditListRequestActorTokenId>;
export type LogsAuditListRequestActorTokenNameNotList = Array<string>;
export declare const LogsAuditListRequestActorTokenNameNotList: S.Schema<LogsAuditListRequestActorTokenNameNotList>;
export interface LogsAuditListRequestActorTokenName {
    /** Filters out audit logs by the API token name when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenNameNotList;
}
export declare const LogsAuditListRequestActorTokenName: S.Schema<LogsAuditListRequestActorTokenName>;
export type LogsAuditListRequestActorTypeNotItem = "account" | "cloudflare_admin" | "system" | "user";
export declare const LogsAuditListRequestActorTypeNotItem: any;
export type LogsAuditListRequestActorTypeNotList = Array<LogsAuditListRequestActorTypeNotItem | (string & {})>;
export declare const LogsAuditListRequestActorTypeNotList: S.Schema<LogsAuditListRequestActorTypeNotList>;
export interface LogsAuditListRequestActorType {
    /** Filters out audit logs by the actor type. */
    not?: LogsAuditListRequestActorTypeNotList;
}
export declare const LogsAuditListRequestActorType: S.Schema<LogsAuditListRequestActorType>;
export type LogsAuditListRequestAuditLogIdNotList = Array<string>;
export declare const LogsAuditListRequestAuditLogIdNotList: S.Schema<LogsAuditListRequestAuditLogIdNotList>;
export interface LogsAuditListRequestAuditLogId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestAuditLogIdNotList;
}
export declare const LogsAuditListRequestAuditLogId: S.Schema<LogsAuditListRequestAuditLogId>;
export type LogsAuditListRequestDirection = "desc" | "asc";
export declare const LogsAuditListRequestDirection: any;
export type LogsAuditListRequestProductCategoryList = Array<string>;
export declare const LogsAuditListRequestProductCategoryList: S.Schema<LogsAuditListRequestProductCategoryList>;
export type LogsAuditListRequestRawCfRayIdNotList = Array<string>;
export declare const LogsAuditListRequestRawCfRayIdNotList: S.Schema<LogsAuditListRequestRawCfRayIdNotList>;
export interface LogsAuditListRequestRawCfRayId {
    /** Filters out audit logs by the response CF Ray ID. */
    not?: LogsAuditListRequestRawCfRayIdNotList;
}
export declare const LogsAuditListRequestRawCfRayId: S.Schema<LogsAuditListRequestRawCfRayId>;
export type LogsAuditListRequestRawMethodNotList = Array<string>;
export declare const LogsAuditListRequestRawMethodNotList: S.Schema<LogsAuditListRequestRawMethodNotList>;
export interface LogsAuditListRequestRawMethod {
    /** Filters out audit logs by the HTTP method for the API call. */
    not?: LogsAuditListRequestRawMethodNotList;
}
export declare const LogsAuditListRequestRawMethod: S.Schema<LogsAuditListRequestRawMethod>;
export type LogsAuditListRequestRawStatusCodeNotList = Array<number>;
export declare const LogsAuditListRequestRawStatusCodeNotList: S.Schema<LogsAuditListRequestRawStatusCodeNotList>;
export interface LogsAuditListRequestRawStatusCode {
    /** Filters out audit logs by the response status code that was returned. */
    not?: LogsAuditListRequestRawStatusCodeNotList;
}
export declare const LogsAuditListRequestRawStatusCode: S.Schema<LogsAuditListRequestRawStatusCode>;
export type LogsAuditListRequestRawUriNotList = Array<string>;
export declare const LogsAuditListRequestRawUriNotList: S.Schema<LogsAuditListRequestRawUriNotList>;
export interface LogsAuditListRequestRawUri {
    /** Filters out audit logs by the request URI. */
    not?: LogsAuditListRequestRawUriNotList;
}
export declare const LogsAuditListRequestRawUri: S.Schema<LogsAuditListRequestRawUri>;
export type LogsAuditListRequestResourceIdNotList = Array<string>;
export declare const LogsAuditListRequestResourceIdNotList: S.Schema<LogsAuditListRequestResourceIdNotList>;
export interface LogsAuditListRequestResourceId {
    /** Filters out audit logs by the resource ID. */
    not?: LogsAuditListRequestResourceIdNotList;
}
export declare const LogsAuditListRequestResourceId: S.Schema<LogsAuditListRequestResourceId>;
export type LogsAuditListRequestResourceProductNotList = Array<string>;
export declare const LogsAuditListRequestResourceProductNotList: S.Schema<LogsAuditListRequestResourceProductNotList>;
export interface LogsAuditListRequestResourceProduct {
    /** Filters out audit logs by the Cloudflare product associated with the changed resource. */
    not?: LogsAuditListRequestResourceProductNotList;
}
export declare const LogsAuditListRequestResourceProduct: S.Schema<LogsAuditListRequestResourceProduct>;
export type LogsAuditListRequestResourceScopeNotItem = "accounts" | "user" | "zones" | "memberships";
export declare const LogsAuditListRequestResourceScopeNotItem: any;
export type LogsAuditListRequestResourceScopeNotList = Array<LogsAuditListRequestResourceScopeNotItem | (string & {})>;
export declare const LogsAuditListRequestResourceScopeNotList: S.Schema<LogsAuditListRequestResourceScopeNotList>;
export interface LogsAuditListRequestResourceScope {
    /** Filters out audit logs by the resource scope, specifying whether the resource is associated with an user, an account, a zone, or a membership. */
    not?: LogsAuditListRequestResourceScopeNotList;
}
export declare const LogsAuditListRequestResourceScope: S.Schema<LogsAuditListRequestResourceScope>;
export type LogsAuditListRequestResourceTypeNotList = Array<string>;
export declare const LogsAuditListRequestResourceTypeNotList: S.Schema<LogsAuditListRequestResourceTypeNotList>;
export interface LogsAuditListRequestResourceType {
    /** Filters out audit logs based on the unique type of resource changed by the action. */
    not?: LogsAuditListRequestResourceTypeNotList;
}
export declare const LogsAuditListRequestResourceType: S.Schema<LogsAuditListRequestResourceType>;
export type LogsAuditListRequestZoneIdNotList = Array<string>;
export declare const LogsAuditListRequestZoneIdNotList: S.Schema<LogsAuditListRequestZoneIdNotList>;
export interface LogsAuditListRequestZoneId {
    /** Filters out audit logs by the zone ID. */
    not?: LogsAuditListRequestZoneIdNotList;
}
export declare const LogsAuditListRequestZoneId: S.Schema<LogsAuditListRequestZoneId>;
export type LogsAuditListRequestZoneNameNotList = Array<string>;
export declare const LogsAuditListRequestZoneNameNotList: S.Schema<LogsAuditListRequestZoneNameNotList>;
export interface LogsAuditListRequestZoneName {
    /** Filters out audit logs by the zone name associated with the change. */
    not?: LogsAuditListRequestZoneNameNotList;
}
export declare const LogsAuditListRequestZoneName: S.Schema<LogsAuditListRequestZoneName>;
export interface ListLogAuditsRequest {
    /** The unique id that identifies the account. */
    accountId: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    id?: LogsAuditListRequestId;
    accountName?: LogsAuditListRequestAccountName;
    actionResult?: LogsAuditListRequestActionResult;
    actionType?: LogsAuditListRequestActionType;
    actorContext?: LogsAuditListRequestActorContext;
    actorEmail?: LogsAuditListRequestActorEmail;
    actorId?: LogsAuditListRequestActorId;
    actorIpAddress?: LogsAuditListRequestActorIpAddress;
    actorTokenId?: LogsAuditListRequestActorTokenId;
    actorTokenName?: LogsAuditListRequestActorTokenName;
    actorType?: LogsAuditListRequestActorType;
    auditLogId?: LogsAuditListRequestAuditLogId;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string;
    /** Sets sorting order. */
    direction?: LogsAuditListRequestDirection | (string & {});
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
    /** Filters audit logs by one or more predefined product categories. Each product category expands into a curated set of resource_product values and is unioned with any explicit resource_product filter. Matched case-insensitively; unknown product categories return 400. Repeatable. Use the audit log product categories endpoint to discover the available values. */
    productCategory?: LogsAuditListRequestProductCategoryList;
    rawCfRayId?: LogsAuditListRequestRawCfRayId;
    rawMethod?: LogsAuditListRequestRawMethod;
    rawStatusCode?: LogsAuditListRequestRawStatusCode;
    rawUri?: LogsAuditListRequestRawUri;
    resourceId?: LogsAuditListRequestResourceId;
    resourceProduct?: LogsAuditListRequestResourceProduct;
    resourceScope?: LogsAuditListRequestResourceScope;
    resourceType?: LogsAuditListRequestResourceType;
    zoneId?: LogsAuditListRequestZoneId;
    zoneName?: LogsAuditListRequestZoneName;
}
export declare const ListLogAuditsRequest: S.Schema<ListLogAuditsRequest>;
export interface LogsAuditListResultItemAccount {
    /** A unique identifier for the account. */
    id?: string | null;
    /** A string that identifies the account name. */
    name?: string | null;
}
export declare const LogsAuditListResultItemAccount: S.Schema<LogsAuditListResultItemAccount>;
export interface LogsAuditListResultItemAction {
    /** A short description of the action performed. */
    description?: string | null;
    /** The result of the action, indicating success or failure. */
    result?: string | null;
    /** A timestamp indicating when the action was logged. */
    time?: string | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export declare const LogsAuditListResultItemAction: S.Schema<LogsAuditListResultItemAction>;
export type LogsAuditListResultItemActorContext = "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export declare const LogsAuditListResultItemActorContext: any;
export type LogsAuditListResultItemActorType = "account" | "cloudflare_admin" | "system" | "user";
export declare const LogsAuditListResultItemActorType: any;
export interface LogsAuditListResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    context?: LogsAuditListResultItemActorContext | null;
    /** The email of the actor who performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null;
    /** The type of actor. */
    type?: LogsAuditListResultItemActorType | null;
}
export declare const LogsAuditListResultItemActor: S.Schema<LogsAuditListResultItemActor>;
export interface LogsAuditListResultItemRaw {
    /** The Cloudflare Ray ID for the request. */
    cfRayId?: string | null;
    /** The HTTP method of the request. */
    method?: string | null;
    /** The HTTP response status code returned by the API. */
    statusCode?: number | null;
    /** The URI of the request. */
    uri?: string | null;
    /** The client's user agent string sent with the request. */
    userAgent?: string | null;
}
export declare const LogsAuditListResultItemRaw: S.Schema<LogsAuditListResultItemRaw>;
export interface LogsAuditListResultItemResource {
    /** The unique identifier for the affected resource. */
    id?: string | null;
    /** The Cloudflare product associated with the resource. */
    product?: string | null;
    request?: unknown | null;
    response?: unknown | null;
    /** The scope of the resource. */
    scope?: unknown | null;
    /** The type of the resource. */
    type?: string | null;
}
export declare const LogsAuditListResultItemResource: S.Schema<LogsAuditListResultItemResource>;
export interface LogsAuditListResultItemZone {
    /** A string that identifies the zone id. */
    id?: string | null;
    /** A string that identifies the zone name. */
    name?: string | null;
}
export declare const LogsAuditListResultItemZone: S.Schema<LogsAuditListResultItemZone>;
export interface LogsAuditListResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null;
    /** Contains account related information. */
    account?: LogsAuditListResultItemAccount | null;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditListResultItemActor | null;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null;
    /** Provides details about the zone affected by the action. */
    zone?: LogsAuditListResultItemZone | null;
}
export declare const LogsAuditListResultItem: S.Schema<LogsAuditListResultItem>;
export type LogsAuditListResultList = Array<LogsAuditListResultItem>;
export declare const LogsAuditListResultList: S.Schema<LogsAuditListResultList>;
export interface ListLogAuditsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsAuditListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLogAuditsResponse: S.Schema<ListLogAuditsResponse>;
export type MembersListRequestDirection = "asc" | "desc";
export declare const MembersListRequestDirection: any;
export type MembersListRequestOrder = "user.first_name" | "user.last_name" | "user.email" | "status";
export declare const MembersListRequestOrder: any;
export type MembersListRequestStatus = "accepted" | "pending" | "rejected";
export declare const MembersListRequestStatus: any;
export interface ListMembersRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Direction to order results. */
    direction?: MembersListRequestDirection | (string & {});
    /** Field to order results by. */
    order?: MembersListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** A member's status in the account. */
    status?: MembersListRequestStatus | (string & {});
}
export declare const ListMembersRequest: S.Schema<ListMembersRequest>;
export type MembersListResultItemPoliciesItemAccess = "allow" | "deny";
export declare const MembersListResultItemPoliciesItemAccess: any;
export type MembersListResultItemPoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersListResultItemPoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type MembersListResultItemPoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const MembersListResultItemPoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersListResultItemPoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const MembersListResultItemPoliciesItemPermissionGroupsList: S.Schema<MembersListResultItemPoliciesItemPermissionGroupsList>;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem;
export declare const MembersListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export declare const MembersListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<MembersListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface MembersListResultItemPoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const MembersListResultItemPoliciesItemResourceGroupsItemScopeItem: S.Schema<MembersListResultItemPoliciesItemResourceGroupsItemScopeItem>;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeList = Array<MembersListResultItemPoliciesItemResourceGroupsItemScopeItem>;
export declare const MembersListResultItemPoliciesItemResourceGroupsItemScopeList: S.Schema<MembersListResultItemPoliciesItemResourceGroupsItemScopeList>;
export type MembersListResultItemPoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersListResultItemPoliciesItemResourceGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export interface MembersListResultItemPoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersListResultItemPoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const MembersListResultItemPoliciesItemResourceGroupsItem: S.Schema<MembersListResultItemPoliciesItemResourceGroupsItem>;
export type MembersListResultItemPoliciesItemResourceGroupsList = Array<MembersListResultItemPoliciesItemResourceGroupsItem>;
export declare const MembersListResultItemPoliciesItemResourceGroupsList: S.Schema<MembersListResultItemPoliciesItemResourceGroupsList>;
export interface MembersListResultItemPoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersListResultItemPoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersListResultItemPoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersListResultItemPoliciesItemResourceGroupsList | null;
}
export declare const MembersListResultItemPoliciesItem: S.Schema<MembersListResultItemPoliciesItem>;
export type MembersListResultItemPoliciesList = Array<MembersListResultItemPoliciesItem>;
export declare const MembersListResultItemPoliciesList: S.Schema<MembersListResultItemPoliciesList>;
export type MembersListResultItemRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export declare const MembersListResultItemRolesItemPermissionsAnalytics: S.Schema<MembersCreateResponseRolesItemPermissionsAnalytics>;
export type MembersListResultItemRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export declare const MembersListResultItemRolesItemPermissions: S.Schema<MembersCreateResponseRolesItemPermissions>;
export type MembersListResultItemRolesItem = MembersCreateResponseRolesItem;
export declare const MembersListResultItemRolesItem: S.Schema<MembersCreateResponseRolesItem>;
export type MembersListResultItemRolesList = Array<MembersCreateResponseRolesItem>;
export declare const MembersListResultItemRolesList: S.Schema<MembersListResultItemRolesList>;
export type MembersListResultItemStatus = "accepted" | "pending";
export declare const MembersListResultItemStatus: any;
export type MembersListResultItemUser = MembersCreateResponseUser;
export declare const MembersListResultItemUser: S.Schema<MembersCreateResponseUser>;
export interface MembersListResultItem {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersListResultItemPoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersListResultItemRolesList | null;
    /** A member's status in the account. */
    status?: MembersListResultItemStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export declare const MembersListResultItem: S.Schema<MembersListResultItem>;
export type MembersListResultList = Array<MembersListResultItem>;
export declare const MembersListResultList: S.Schema<MembersListResultList>;
export interface ListMembersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MembersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListMembersResponse: S.Schema<ListMembersResponse>;
export interface ListRolesRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of roles per page. */
    perPage?: number;
}
export declare const ListRolesRequest: S.Schema<ListRolesRequest>;
export type RolesListResultItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export declare const RolesListResultItemPermissionsAnalytics: S.Schema<MembersCreateResponseRolesItemPermissionsAnalytics>;
export type RolesListResultItemPermissions = MembersCreateResponseRolesItemPermissions;
export declare const RolesListResultItemPermissions: S.Schema<MembersCreateResponseRolesItemPermissions>;
export type RolesListResultItem = MembersCreateResponseRolesItem;
export declare const RolesListResultItem: S.Schema<MembersCreateResponseRolesItem>;
export type RolesListResultList = Array<MembersCreateResponseRolesItem>;
export declare const RolesListResultList: S.Schema<RolesListResultList>;
export interface ListRolesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RolesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRolesResponse: S.Schema<ListRolesResponse>;
export type TokensListRequestDirection = "asc" | "desc";
export declare const TokensListRequestDirection: any;
export interface ListTokensRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Direction to order results. */
    direction?: TokensListRequestDirection | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListTokensRequest: S.Schema<ListTokensRequest>;
export type TokensListResultItemConditionRequestIpInList = Array<string>;
export declare const TokensListResultItemConditionRequestIpInList: S.Schema<TokensListResultItemConditionRequestIpInList>;
export type TokensListResultItemConditionRequestIpNotInList = Array<string>;
export declare const TokensListResultItemConditionRequestIpNotInList: S.Schema<TokensListResultItemConditionRequestIpNotInList>;
export interface TokensListResultItemConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensListResultItemConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensListResultItemConditionRequestIpNotInList | null;
}
export declare const TokensListResultItemConditionRequestIp: S.Schema<TokensListResultItemConditionRequestIp>;
export interface TokensListResultItemCondition {
    /** Client IP restrictions. */
    requestIp?: TokensListResultItemConditionRequestIp | null;
}
export declare const TokensListResultItemCondition: S.Schema<TokensListResultItemCondition>;
export type TokensListResultItemPoliciesItemEffect = "allow" | "deny";
export declare const TokensListResultItemPoliciesItemEffect: any;
export type TokensListResultItemPoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensListResultItemPoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensListResultItemPoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensListResultItemPoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensListResultItemPoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensListResultItemPoliciesItemPermissionGroupsList: S.Schema<TokensListResultItemPoliciesItemPermissionGroupsList>;
export type TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensListResultItemPoliciesItemResourcesValue = string | TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensListResultItemPoliciesItemResourcesValue: any;
export type TokensListResultItemPoliciesItemResourcesMap = {
    [key: string]: TokensListResultItemPoliciesItemResourcesValue | undefined;
};
export declare const TokensListResultItemPoliciesItemResourcesMap: S.Schema<TokensListResultItemPoliciesItemResourcesMap>;
export interface TokensListResultItemPoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensListResultItemPoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensListResultItemPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensListResultItemPoliciesItemResourcesMap;
}
export declare const TokensListResultItemPoliciesItem: S.Schema<TokensListResultItemPoliciesItem>;
export type TokensListResultItemPoliciesList = Array<TokensListResultItemPoliciesItem>;
export declare const TokensListResultItemPoliciesList: S.Schema<TokensListResultItemPoliciesList>;
export type TokensListResultItemStatus = "active" | "disabled" | "expired";
export declare const TokensListResultItemStatus: any;
export interface TokensListResultItem {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensListResultItemCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensListResultItemPoliciesList | null;
    /** Status of the token. */
    status?: TokensListResultItemStatus | null;
}
export declare const TokensListResultItem: S.Schema<TokensListResultItem>;
export type TokensListResultList = Array<TokensListResultItem>;
export declare const TokensListResultList: S.Schema<TokensListResultList>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTokensResponse: S.Schema<ListTokensResponse>;
export interface ListTokensPermissionGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Filter by the name of the permission group. */
    name?: string;
    /** Filter by the scope of the permission group. */
    scope?: string;
}
export declare const ListTokensPermissionGroupsRequest: S.Schema<ListTokensPermissionGroupsRequest>;
export type ListTokensPermissionGroupsResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export declare const ListTokensPermissionGroupsResultItemCategory: any;
export type ListTokensPermissionGroupsResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export declare const ListTokensPermissionGroupsResultItemScopesItem: any;
export type ListTokensPermissionGroupsResultItemScopesList = Array<ListTokensPermissionGroupsResultItemScopesItem>;
export declare const ListTokensPermissionGroupsResultItemScopesList: S.Schema<ListTokensPermissionGroupsResultItemScopesList>;
export interface ListTokensPermissionGroupsResultItem {
    /** Public ID. */
    id?: string | null;
    /** Product category that this permission group belongs to. */
    category?: ListTokensPermissionGroupsResultItemCategory | null;
    /** Permission Group Name */
    name?: string | null;
    /** Resources to which the Permission Group is scoped */
    scopes?: ListTokensPermissionGroupsResultItemScopesList | null;
}
export declare const ListTokensPermissionGroupsResultItem: S.Schema<ListTokensPermissionGroupsResultItem>;
export type ListTokensPermissionGroupsResultList = Array<ListTokensPermissionGroupsResultItem>;
export declare const ListTokensPermissionGroupsResultList: S.Schema<ListTokensPermissionGroupsResultList>;
export type ListTokensPermissionGroupsResponse = ListTokensPermissionGroupsResultList;
export declare const ListTokensPermissionGroupsResponse: S.Schema<ListTokensPermissionGroupsResponse>;
export interface PutTokenValueRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export declare const PutTokenValueRequest: S.Schema<PutTokenValueRequest>;
export type PutTokenValueResponse = unknown;
export declare const PutTokenValueResponse: S.Schema<PutTokenValueResponse>;
export type UpdateRequestType = "standard" | "enterprise";
export declare const UpdateRequestType: any;
export interface UpdateRequestManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string;
}
export declare const UpdateRequestManagedBy: S.Schema<UpdateRequestManagedBy>;
export interface UpdateRequestSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string;
    /** Indicates whether membership in this account requires that */
    enforceTwofactor?: boolean;
}
export declare const UpdateRequestSettings: S.Schema<UpdateRequestSettings>;
export interface UpdateAccountRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type?: UpdateRequestType | (string & {});
    /** Parent container details */
    managedBy?: UpdateRequestManagedBy;
    /** Account settings */
    settings?: UpdateRequestSettings;
}
export declare const UpdateAccountRequest: S.Schema<UpdateAccountRequest>;
export type UpdateResponseType = "standard" | "enterprise";
export declare const UpdateResponseType: any;
export type UpdateResponseManagedBy = CreateResponseManagedBy;
export declare const UpdateResponseManagedBy: S.Schema<CreateResponseManagedBy>;
export type UpdateResponseSettings = CreateResponseSettings;
export declare const UpdateResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: UpdateResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null;
    /** Account settings */
    settings?: CreateResponseSettings | null;
}
export declare const UpdateAccountResponse: S.Schema<UpdateAccountResponse>;
export interface UpdateAccountProfileRequest {
    accountId: string;
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export declare const UpdateAccountProfileRequest: S.Schema<UpdateAccountProfileRequest>;
export interface UpdateAccountProfileResponse {
}
export declare const UpdateAccountProfileResponse: S.Schema<UpdateAccountProfileResponse>;
export interface MembersUpdateRequestRolesItemPermissionsAnalytics {
    read?: boolean;
    write?: boolean;
}
export declare const MembersUpdateRequestRolesItemPermissionsAnalytics: S.Schema<MembersUpdateRequestRolesItemPermissionsAnalytics>;
export interface MembersUpdateRequestRolesItemPermissions {
    analytics?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    billing?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    cachePurge?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    dns?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    dnsRecords?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    lb?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    logs?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    organization?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    ssl?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    waf?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    zoneSettings?: MembersUpdateRequestRolesItemPermissionsAnalytics;
    zones?: MembersUpdateRequestRolesItemPermissionsAnalytics;
}
export declare const MembersUpdateRequestRolesItemPermissions: S.Schema<MembersUpdateRequestRolesItemPermissions>;
export interface MembersUpdateRequestRolesItem {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description?: string;
    /** Role name. */
    name?: string;
    permissions?: MembersUpdateRequestRolesItemPermissions;
}
export declare const MembersUpdateRequestRolesItem: S.Schema<MembersUpdateRequestRolesItem>;
export type MembersUpdateRequestRolesList = Array<MembersUpdateRequestRolesItem>;
export declare const MembersUpdateRequestRolesList: S.Schema<MembersUpdateRequestRolesList>;
export type MembersUpdateRequestStatus = "accepted" | "pending";
export declare const MembersUpdateRequestStatus: any;
export interface MembersUpdateRequestUser {
    /** The contact email address of the user. */
    email: string;
    /** Identifier */
    id?: string;
    /** User's first name */
    firstName?: string;
    /** User's last name */
    lastName?: string;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean;
}
export declare const MembersUpdateRequestUser: S.Schema<MembersUpdateRequestUser>;
export type MembersUpdateRequestPoliciesItemAccess = "allow" | "deny";
export declare const MembersUpdateRequestPoliciesItemAccess: any;
export type MembersUpdateRequestPoliciesItemPermissionGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export declare const MembersUpdateRequestPoliciesItemPermissionGroupsItem: S.Schema<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersUpdateRequestPoliciesItemPermissionGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const MembersUpdateRequestPoliciesItemPermissionGroupsList: S.Schema<MembersUpdateRequestPoliciesItemPermissionGroupsList>;
export type MembersUpdateRequestPoliciesItemResourceGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export declare const MembersUpdateRequestPoliciesItemResourceGroupsItem: S.Schema<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersUpdateRequestPoliciesItemResourceGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const MembersUpdateRequestPoliciesItemResourceGroupsList: S.Schema<MembersUpdateRequestPoliciesItemResourceGroupsList>;
export interface MembersUpdateRequestPoliciesItem {
    /** Policy identifier. */
    id?: string;
    /** Allow or deny operations against the resources. */
    access: MembersUpdateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: MembersUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource groups that the policy applies to. */
    resourceGroups: MembersUpdateRequestPoliciesItemResourceGroupsList;
}
export declare const MembersUpdateRequestPoliciesItem: S.Schema<MembersUpdateRequestPoliciesItem>;
export type MembersUpdateRequestPoliciesList = Array<MembersUpdateRequestPoliciesItem>;
export declare const MembersUpdateRequestPoliciesList: S.Schema<MembersUpdateRequestPoliciesList>;
export interface UpdateMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
    /** Membership identifier tag. */
    id?: string;
    /** Roles assigned to this member. */
    roles?: MembersUpdateRequestRolesList;
    /** A member's status in the account. */
    status?: MembersUpdateRequestStatus | (string & {});
    /** Details of the user associated to the membership. */
    user?: MembersUpdateRequestUser;
    /** Array of policies associated with this member. */
    policies?: MembersUpdateRequestPoliciesList;
}
export declare const UpdateMemberRequest: S.Schema<UpdateMemberRequest>;
export type MembersUpdateResponsePoliciesItemAccess = "allow" | "deny";
export declare const MembersUpdateResponsePoliciesItemAccess: any;
export type MembersUpdateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersUpdateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type MembersUpdateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const MembersUpdateResponsePoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersUpdateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const MembersUpdateResponsePoliciesItemPermissionGroupsList: S.Schema<MembersUpdateResponsePoliciesItemPermissionGroupsList>;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem;
export declare const MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export declare const MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItem>;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeList = Array<MembersUpdateResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const MembersUpdateResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<MembersUpdateResponsePoliciesItemResourceGroupsItemScopeList>;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const MembersUpdateResponsePoliciesItemResourceGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export interface MembersUpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersUpdateResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const MembersUpdateResponsePoliciesItemResourceGroupsItem: S.Schema<MembersUpdateResponsePoliciesItemResourceGroupsItem>;
export type MembersUpdateResponsePoliciesItemResourceGroupsList = Array<MembersUpdateResponsePoliciesItemResourceGroupsItem>;
export declare const MembersUpdateResponsePoliciesItemResourceGroupsList: S.Schema<MembersUpdateResponsePoliciesItemResourceGroupsList>;
export interface MembersUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: MembersUpdateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersUpdateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersUpdateResponsePoliciesItemResourceGroupsList | null;
}
export declare const MembersUpdateResponsePoliciesItem: S.Schema<MembersUpdateResponsePoliciesItem>;
export type MembersUpdateResponsePoliciesList = Array<MembersUpdateResponsePoliciesItem>;
export declare const MembersUpdateResponsePoliciesList: S.Schema<MembersUpdateResponsePoliciesList>;
export type MembersUpdateResponseRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export declare const MembersUpdateResponseRolesItemPermissionsAnalytics: S.Schema<MembersCreateResponseRolesItemPermissionsAnalytics>;
export type MembersUpdateResponseRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export declare const MembersUpdateResponseRolesItemPermissions: S.Schema<MembersCreateResponseRolesItemPermissions>;
export type MembersUpdateResponseRolesItem = MembersCreateResponseRolesItem;
export declare const MembersUpdateResponseRolesItem: S.Schema<MembersCreateResponseRolesItem>;
export type MembersUpdateResponseRolesList = Array<MembersCreateResponseRolesItem>;
export declare const MembersUpdateResponseRolesList: S.Schema<MembersUpdateResponseRolesList>;
export type MembersUpdateResponseStatus = "accepted" | "pending";
export declare const MembersUpdateResponseStatus: any;
export type MembersUpdateResponseUser = MembersCreateResponseUser;
export declare const MembersUpdateResponseUser: S.Schema<MembersCreateResponseUser>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMemberResponse {
    /** Membership identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Access policy for the membership */
    policies?: MembersUpdateResponsePoliciesList | null;
    /** Roles assigned to this Member. */
    roles?: MembersUpdateResponseRolesList | null;
    /** A member's status in the account. */
    status?: MembersUpdateResponseStatus | null;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null;
}
export declare const UpdateMemberResponse: S.Schema<UpdateMemberResponse>;
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsUpdateRequestFrequency: any;
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsUpdateRequestRatePlanId: any;
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export declare const SubscriptionsUpdateRequestRatePlanSetsList: S.Schema<SubscriptionsUpdateRequestRatePlanSetsList>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList;
}
export declare const SubscriptionsUpdateRequestRatePlan: S.Schema<SubscriptionsUpdateRequestRatePlan>;
export interface UpdateSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan;
}
export declare const UpdateSubscriptionRequest: S.Schema<UpdateSubscriptionRequest>;
export type SubscriptionsUpdateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsUpdateResponseFrequency: any;
export type SubscriptionsUpdateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsUpdateResponseRatePlanId: any;
export type SubscriptionsUpdateResponseRatePlanSetsList = Array<string>;
export declare const SubscriptionsUpdateResponseRatePlanSetsList: S.Schema<SubscriptionsUpdateResponseRatePlanSetsList>;
export interface SubscriptionsUpdateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateResponseRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateResponseRatePlanSetsList | null;
}
export declare const SubscriptionsUpdateResponseRatePlan: S.Schema<SubscriptionsUpdateResponseRatePlan>;
export type SubscriptionsUpdateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsUpdateResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateResponseFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateResponseRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsUpdateResponseState | null;
}
export declare const UpdateSubscriptionResponse: S.Schema<UpdateSubscriptionResponse>;
export type TokensUpdateRequestPoliciesItemEffect = "allow" | "deny";
export declare const TokensUpdateRequestPoliciesItemEffect: any;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta = TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
export declare const TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItemMeta>;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItem = TokensCreateRequestPoliciesItemPermissionGroupsItem;
export declare const TokensUpdateRequestPoliciesItemPermissionGroupsItem: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensUpdateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const TokensUpdateRequestPoliciesItemPermissionGroupsList: S.Schema<TokensUpdateRequestPoliciesItemPermissionGroupsList>;
export type TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensUpdateRequestPoliciesItemResourcesValue = string | TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensUpdateRequestPoliciesItemResourcesValue: any;
export type TokensUpdateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensUpdateRequestPoliciesItemResourcesValue | undefined;
};
export declare const TokensUpdateRequestPoliciesItemResourcesMap: S.Schema<TokensUpdateRequestPoliciesItemResourcesMap>;
export interface TokensUpdateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateRequestPoliciesItemResourcesMap;
}
export declare const TokensUpdateRequestPoliciesItem: S.Schema<TokensUpdateRequestPoliciesItem>;
export type TokensUpdateRequestPoliciesList = Array<TokensUpdateRequestPoliciesItem>;
export declare const TokensUpdateRequestPoliciesList: S.Schema<TokensUpdateRequestPoliciesList>;
export type TokensUpdateRequestConditionRequestIpInList = Array<string>;
export declare const TokensUpdateRequestConditionRequestIpInList: S.Schema<TokensUpdateRequestConditionRequestIpInList>;
export type TokensUpdateRequestConditionRequestIpNotInList = Array<string>;
export declare const TokensUpdateRequestConditionRequestIpNotInList: S.Schema<TokensUpdateRequestConditionRequestIpNotInList>;
export interface TokensUpdateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateRequestConditionRequestIpNotInList;
}
export declare const TokensUpdateRequestConditionRequestIp: S.Schema<TokensUpdateRequestConditionRequestIp>;
export interface TokensUpdateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateRequestConditionRequestIp;
}
export declare const TokensUpdateRequestCondition: S.Schema<TokensUpdateRequestCondition>;
export type TokensUpdateRequestStatus = "active" | "disabled" | "expired";
export declare const TokensUpdateRequestStatus: any;
export interface UpdateTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensUpdateRequestPoliciesList;
    condition?: TokensUpdateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
    /** Status of the token. */
    status?: TokensUpdateRequestStatus | (string & {});
}
export declare const UpdateTokenRequest: S.Schema<UpdateTokenRequest>;
export type TokensUpdateResponseConditionRequestIpInList = Array<string>;
export declare const TokensUpdateResponseConditionRequestIpInList: S.Schema<TokensUpdateResponseConditionRequestIpInList>;
export type TokensUpdateResponseConditionRequestIpNotInList = Array<string>;
export declare const TokensUpdateResponseConditionRequestIpNotInList: S.Schema<TokensUpdateResponseConditionRequestIpNotInList>;
export interface TokensUpdateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateResponseConditionRequestIpNotInList | null;
}
export declare const TokensUpdateResponseConditionRequestIp: S.Schema<TokensUpdateResponseConditionRequestIp>;
export interface TokensUpdateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateResponseConditionRequestIp | null;
}
export declare const TokensUpdateResponseCondition: S.Schema<TokensUpdateResponseCondition>;
export type TokensUpdateResponsePoliciesItemEffect = "allow" | "deny";
export declare const TokensUpdateResponsePoliciesItemEffect: any;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensUpdateResponsePoliciesItemPermissionGroupsItem: S.Schema<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensUpdateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensUpdateResponsePoliciesItemPermissionGroupsList: S.Schema<TokensUpdateResponsePoliciesItemPermissionGroupsList>;
export type TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensUpdateResponsePoliciesItemResourcesValue = string | TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensUpdateResponsePoliciesItemResourcesValue: any;
export type TokensUpdateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensUpdateResponsePoliciesItemResourcesValue | undefined;
};
export declare const TokensUpdateResponsePoliciesItemResourcesMap: S.Schema<TokensUpdateResponsePoliciesItemResourcesMap>;
export interface TokensUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateResponsePoliciesItemResourcesMap;
}
export declare const TokensUpdateResponsePoliciesItem: S.Schema<TokensUpdateResponsePoliciesItem>;
export type TokensUpdateResponsePoliciesList = Array<TokensUpdateResponsePoliciesItem>;
export declare const TokensUpdateResponsePoliciesList: S.Schema<TokensUpdateResponsePoliciesList>;
export type TokensUpdateResponseStatus = "active" | "disabled" | "expired";
export declare const TokensUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensUpdateResponseCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensUpdateResponsePoliciesList | null;
    /** Status of the token. */
    status?: TokensUpdateResponseStatus | null;
}
export declare const UpdateTokenResponse: S.Schema<UpdateTokenResponse>;
export interface VerifyTokenRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const VerifyTokenRequest: S.Schema<VerifyTokenRequest>;
export type TokensVerifyResponseStatus = "active" | "disabled" | "expired";
export declare const TokensVerifyResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VerifyTokenResponse {
    /** Token identifier tag. */
    id: string;
    /** Status of the token. */
    status: TokensVerifyResponseStatus;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
}
export declare const VerifyTokenResponse: S.Schema<VerifyTokenResponse>;
export type CreateAccountError = AccountCreationForbidden | MissingName | CloudflareOpError;
/** Create an account (only available for tenant admins at this time) */
export declare const createAccount: API.OperationMethod<CreateAccountRequest, CreateAccountResponse, CreateAccountError, CloudflareOpContext>;
export type CreateAccountOrganizationError = CloudflareOpError;
/** Move an account within an organization hierarchy or an account outside an organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const createAccountOrganization: API.OperationMethod<CreateAccountOrganizationRequest, CreateAccountOrganizationResponse, CreateAccountOrganizationError, CloudflareOpContext>;
export type CreateMemberError = InvalidRoute | ValidationError | AccountMemberAlreadyExists | CloudflareOpError;
/** Add a user to the list of members for this account. */
export declare const createMember: API.OperationMethod<CreateMemberRequest, CreateMemberResponse, CreateMemberError, CloudflareOpContext>;
export type CreateSubscriptionError = JsonDecodeFailure | InvalidRoute | CloudflareOpError;
/** Creates an account subscription. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type CreateTokenError = InvalidRoute | InvalidTokenName | PermissionGroupNotFound | CloudflareOpError;
/** Create a new Account Owned API token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteAccountError = InvalidRoute | MethodNotAllowed | CloudflareOpError;
/** Delete a specific account (only available for tenant admins at this time). This is a permanent operation that will delete any zones or other resources under the account */
export declare const deleteAccount: API.OperationMethod<DeleteAccountRequest, DeleteAccountResponse, DeleteAccountError, CloudflareOpContext>;
export type DeleteMemberError = MemberNotFound | InvalidRoute | CloudflareOpError;
/** Remove a member from an account. */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest, DeleteMemberResponse, DeleteMemberError, CloudflareOpContext>;
export type DeleteSubscriptionError = InvalidRoute | EndpointNotFound | CloudflareOpError;
/** Deletes an account's subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type DeleteTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | TokenManagedByCloudflare | CloudflareOpError;
/** Destroy an Account Owned API token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type GetAccountError = InvalidRoute | CloudflareOpError;
/** Get information about a specific account that you are a member of. */
export declare const getAccount: API.OperationMethod<GetAccountRequest, GetAccountResponse, GetAccountError, CloudflareOpContext>;
export type GetAccountProfileError = CloudflareOpError;
/** Retrieves the profile information for a specific Cloudflare account, including organization details, settings, and metadata. This endpoint is commonly used to verify account access and retrieve account-level configuration. */
export declare const getAccountProfile: API.OperationMethod<GetAccountProfileRequest, GetAccountProfileResponse, GetAccountProfileError, CloudflareOpContext>;
export type GetMemberError = MemberNotFound | InvalidRoute | CloudflareOpError;
/** Get information about a specific member of an account. */
export declare const getMember: API.OperationMethod<GetMemberRequest, GetMemberResponse, GetMemberError, CloudflareOpContext>;
export type GetRoleError = InvalidRoute | CloudflareOpError;
/** Get information about a specific role for an account. */
export declare const getRole: API.OperationMethod<GetRoleRequest, GetRoleResponse, GetRoleError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists all of an account's subscriptions. */
export declare const getSubscription: API.PaginatedOperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext, SubscriptionsGetResultItem>;
export type GetTokenError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Get information about a specific Account Owned API token. */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, CloudflareOpContext>;
export type GetTokenPermissionGroupError = InvalidRoute | CloudflareOpError;
/** Find all available permission groups for Account Owned API Tokens */
export declare const getTokenPermissionGroup: API.OperationMethod<GetTokenPermissionGroupRequest, GetTokenPermissionGroupResponse, GetTokenPermissionGroupError, CloudflareOpContext>;
export type ListAccountsError = CloudflareOpError;
/** List all accounts you have ownership or verified access to. */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, CloudflareOpContext, ListResultItem>;
export type ListLogAuditsError = CloudflareOpError;
/** Gets a list of audit logs for an account. */
export declare const listLogAudits: API.PaginatedOperationMethod<ListLogAuditsRequest, ListLogAuditsResponse, ListLogAuditsError, CloudflareOpContext, LogsAuditListResultItem>;
export type ListMembersError = CloudflareOpError;
/** List all members of an account. */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, CloudflareOpContext, MembersListResultItem>;
export type ListRolesError = CloudflareOpError;
/** Get all available roles for an account. */
export declare const listRoles: API.PaginatedOperationMethod<ListRolesRequest, ListRolesResponse, ListRolesError, CloudflareOpContext, MembersCreateResponseRolesItem>;
export type ListTokensError = CloudflareOpError;
/** List all Account Owned API tokens created for this account. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type ListTokensPermissionGroupsError = InvalidRoute | CloudflareOpError;
/** Find all available permission groups for Account Owned API Tokens */
export declare const listTokensPermissionGroups: API.OperationMethod<ListTokensPermissionGroupsRequest, ListTokensPermissionGroupsResponse, ListTokensPermissionGroupsError, CloudflareOpContext>;
export type PutTokenValueError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Roll the Account Owned API token secret. */
export declare const putTokenValue: API.OperationMethod<PutTokenValueRequest, PutTokenValueResponse, PutTokenValueError, CloudflareOpContext>;
export type UpdateAccountError = InvalidAccountName | AccountNameTooLong | UpdateAccountTypeNotSupported | InvalidRoute | MethodNotAllowed | CloudflareOpError;
/** Update an existing account. */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest, UpdateAccountResponse, UpdateAccountError, CloudflareOpContext>;
export type UpdateAccountProfileError = CloudflareOpError;
/** Updates the profile information for a Cloudflare account. Allows modification of account-level settings and organizational details. Requires Account Settings Write permission. */
export declare const updateAccountProfile: API.OperationMethod<UpdateAccountProfileRequest, UpdateAccountProfileResponse, UpdateAccountProfileError, CloudflareOpContext>;
export type UpdateMemberError = MemberNotFound | InvalidRoute | BadRequest | MethodNotAllowed | CloudflareOpError;
/** Modify an account member. */
export declare const updateMember: API.OperationMethod<UpdateMemberRequest, UpdateMemberResponse, UpdateMemberError, CloudflareOpContext>;
export type UpdateSubscriptionError = JsonDecodeFailure | InvalidRoute | EndpointNotFound | CloudflareOpError;
/** Updates an account subscription. */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionRequest, UpdateSubscriptionResponse, UpdateSubscriptionError, CloudflareOpContext>;
export type UpdateTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | PermissionGroupNotFound | CloudflareOpError;
/** Update an existing token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type VerifyTokenError = MissingAuthenticationToken | InvalidRoute | CloudflareOpError;
/** Test whether a token works. */
export declare const verifyToken: API.OperationMethod<VerifyTokenRequest, VerifyTokenResponse, VerifyTokenError, CloudflareOpContext>;
export declare const listTokenPermissionGroups: API.OperationMethod<GetTokenPermissionGroupRequest, TokensPermissionGroupsGetResultList, GetTokenPermissionGroupError, CloudflareOpContext>;
export type ListTokenPermissionGroupsRequest = GetTokenPermissionGroupRequest;
export type ListTokenPermissionGroupsResponse = GetTokenPermissionGroupResponse;
export type ListTokenPermissionGroupsError = GetTokenPermissionGroupError;
//# sourceMappingURL=accounts.d.ts.map