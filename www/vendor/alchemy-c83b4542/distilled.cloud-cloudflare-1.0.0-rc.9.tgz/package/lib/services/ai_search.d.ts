import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiSearchInstanceNotFound_base: S.Class<AiSearchInstanceNotFound, S.TaggedStruct<"AiSearchInstanceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AiSearchInstanceNotFound extends /*@__PURE__*/ AiSearchInstanceNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InstanceAlreadyExists_base: S.Class<InstanceAlreadyExists, S.TaggedStruct<"InstanceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceAlreadyExists extends /*@__PURE__*/ InstanceAlreadyExists_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenCredentials_base: S.Class<InvalidTokenCredentials, S.TaggedStruct<"InvalidTokenCredentials", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTokenCredentials extends /*@__PURE__*/ InvalidTokenCredentials_base {
}
declare const MissingSitemap_base: S.Class<MissingSitemap, S.TaggedStruct<"MissingSitemap", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MissingSitemap extends /*@__PURE__*/ MissingSitemap_base {
}
declare const NamespaceAlreadyExists_base: S.Class<NamespaceAlreadyExists, S.TaggedStruct<"NamespaceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NamespaceAlreadyExists extends /*@__PURE__*/ NamespaceAlreadyExists_base {
}
declare const NamespaceNotFound_base: S.Class<NamespaceNotFound, S.TaggedStruct<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const SyncInCooldown_base: S.Class<SyncInCooldown, S.TaggedStruct<"SyncInCooldown", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SyncInCooldown extends /*@__PURE__*/ SyncInCooldown_base {
}
declare const TokenInUseByInstances_base: S.Class<TokenInUseByInstances, S.TaggedStruct<"TokenInUseByInstances", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenInUseByInstances extends /*@__PURE__*/ TokenInUseByInstances_base {
}
declare const TokenNotFound_base: S.Class<TokenNotFound, S.TaggedStruct<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
declare const UnableToConnect_base: S.Class<UnableToConnect, S.TaggedStruct<"UnableToConnect", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnableToConnect extends /*@__PURE__*/ UnableToConnect_base {
}
declare const ValidationError_base: S.Class<ValidationError, S.TaggedStruct<"ValidationError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
declare const WebCrawlerDomainNotOwned_base: S.Class<WebCrawlerDomainNotOwned, S.TaggedStruct<"WebCrawlerDomainNotOwned", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WebCrawlerDomainNotOwned extends /*@__PURE__*/ WebCrawlerDomainNotOwned_base {
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type: any;
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0>;
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl {
    url: string;
}
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type: any;
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1>;
export type InstancesChatCompletionsRequestMessagesItemContentCase1Item = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1;
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1Item: any;
export type InstancesChatCompletionsRequestMessagesItemContentCase1List = Array<InstancesChatCompletionsRequestMessagesItemContentCase1Item>;
export declare const InstancesChatCompletionsRequestMessagesItemContentCase1List: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1List>;
export type InstancesChatCompletionsRequestMessagesItemContent = string | InstancesChatCompletionsRequestMessagesItemContentCase1List;
export declare const InstancesChatCompletionsRequestMessagesItemContent: any;
export type InstancesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const InstancesChatCompletionsRequestMessagesItemRole: any;
export interface InstancesChatCompletionsRequestMessagesItem {
    content?: InstancesChatCompletionsRequestMessagesItemContent | null;
    role: InstancesChatCompletionsRequestMessagesItemRole | (string & {});
}
export declare const InstancesChatCompletionsRequestMessagesItem: S.Schema<InstancesChatCompletionsRequestMessagesItem>;
export type InstancesChatCompletionsRequestMessagesList = Array<InstancesChatCompletionsRequestMessagesItem>;
export declare const InstancesChatCompletionsRequestMessagesList: S.Schema<InstancesChatCompletionsRequestMessagesList>;
export type InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold: any;
export interface InstancesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export declare const InstancesChatCompletionsRequestAiSearchOptionsCache: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsCache>;
export type InstancesChatCompletionsRequestAiSearchOptionsQueryRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesChatCompletionsRequestAiSearchOptionsQueryRewriteModel: any;
export interface InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    model?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewriteModel | (string & {});
    rewritePrompt?: string;
}
export declare const InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite>;
export type InstancesChatCompletionsRequestAiSearchOptionsRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesChatCompletionsRequestAiSearchOptionsRerankingModel: any;
export interface InstancesChatCompletionsRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: InstancesChatCompletionsRequestAiSearchOptionsRerankingModel | (string & {});
}
export declare const InstancesChatCompletionsRequestAiSearchOptionsReranking: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsReranking>;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection: any;
export interface InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList>;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap>;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod: any;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode: any;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType: any;
export interface InstancesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    matchThreshold?: number;
    maxNumResults?: number;
    retrievalType?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export declare const InstancesChatCompletionsRequestAiSearchOptionsRetrieval: S.Schema<InstancesChatCompletionsRequestAiSearchOptionsRetrieval>;
export interface InstancesChatCompletionsRequestAiSearchOptions {
    cache?: InstancesChatCompletionsRequestAiSearchOptionsCache;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: InstancesChatCompletionsRequestAiSearchOptionsRetrieval;
}
export declare const InstancesChatCompletionsRequestAiSearchOptions: S.Schema<InstancesChatCompletionsRequestAiSearchOptions>;
export type InstancesChatCompletionsRequestModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesChatCompletionsRequestModel: any;
export interface ChatCompletionsInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    messages: InstancesChatCompletionsRequestMessagesList;
    aiSearchOptions?: InstancesChatCompletionsRequestAiSearchOptions;
    model?: InstancesChatCompletionsRequestModel | (string & {});
    stream?: boolean;
}
export declare const ChatCompletionsInstanceRequest: S.Schema<ChatCompletionsInstanceRequest>;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type: any;
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0: S.Schema<InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0>;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type: any;
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1: S.Schema<InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1>;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1;
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item: any;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export declare const InstancesChatCompletionsResponseChoicesItemMessageContentCase1List: S.Schema<InstancesChatCompletionsResponseChoicesItemMessageContentCase1List>;
export type InstancesChatCompletionsResponseChoicesItemMessageContent = string | InstancesChatCompletionsResponseChoicesItemMessageContentCase1List;
export declare const InstancesChatCompletionsResponseChoicesItemMessageContent: any;
export type InstancesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const InstancesChatCompletionsResponseChoicesItemMessageRole: any;
export interface InstancesChatCompletionsResponseChoicesItemMessage {
    content: InstancesChatCompletionsResponseChoicesItemMessageContent;
    role: InstancesChatCompletionsResponseChoicesItemMessageRole;
}
export declare const InstancesChatCompletionsResponseChoicesItemMessage: S.Schema<InstancesChatCompletionsResponseChoicesItemMessage>;
export interface InstancesChatCompletionsResponseChoicesItem {
    message: InstancesChatCompletionsResponseChoicesItemMessage;
    index?: number | null;
}
export declare const InstancesChatCompletionsResponseChoicesItem: S.Schema<InstancesChatCompletionsResponseChoicesItem>;
export type InstancesChatCompletionsResponseChoicesList = Array<InstancesChatCompletionsResponseChoicesItem>;
export declare const InstancesChatCompletionsResponseChoicesList: S.Schema<InstancesChatCompletionsResponseChoicesList>;
export type InstancesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const InstancesChatCompletionsResponseChunksItemItemMetadataMap: S.Schema<InstancesChatCompletionsResponseChunksItemItemMetadataMap>;
export interface InstancesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: InstancesChatCompletionsResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const InstancesChatCompletionsResponseChunksItemItem: S.Schema<InstancesChatCompletionsResponseChunksItemItem>;
export type InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export declare const InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod: any;
export interface InstancesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export declare const InstancesChatCompletionsResponseChunksItemScoringDetails: S.Schema<InstancesChatCompletionsResponseChunksItemScoringDetails>;
export interface InstancesChatCompletionsResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: InstancesChatCompletionsResponseChunksItemItem | null;
    scoringDetails?: InstancesChatCompletionsResponseChunksItemScoringDetails | null;
}
export declare const InstancesChatCompletionsResponseChunksItem: S.Schema<InstancesChatCompletionsResponseChunksItem>;
export type InstancesChatCompletionsResponseChunksList = Array<InstancesChatCompletionsResponseChunksItem>;
export declare const InstancesChatCompletionsResponseChunksList: S.Schema<InstancesChatCompletionsResponseChunksList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsInstanceResponse {
    choices: InstancesChatCompletionsResponseChoicesList;
    chunks: InstancesChatCompletionsResponseChunksList;
    id?: string | null;
    model?: string | null;
    object?: string | null;
}
export declare const ChatCompletionsInstanceResponse: S.Schema<ChatCompletionsInstanceResponse>;
export type NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList = Array<string>;
export declare const NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList>;
export type NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold: any;
export interface NamespacesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export declare const NamespacesChatCompletionsRequestAiSearchOptionsCache: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsCache>;
export type NamespacesChatCompletionsRequestAiSearchOptionsQueryRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsQueryRewriteModel: any;
export interface NamespacesChatCompletionsRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    model?: NamespacesChatCompletionsRequestAiSearchOptionsQueryRewriteModel | (string & {});
    rewritePrompt?: string;
}
export declare const NamespacesChatCompletionsRequestAiSearchOptionsQueryRewrite: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsQueryRewrite>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRerankingModel: any;
export interface NamespacesChatCompletionsRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: NamespacesChatCompletionsRequestAiSearchOptionsRerankingModel | (string & {});
}
export declare const NamespacesChatCompletionsRequestAiSearchOptionsReranking: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsReranking>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection: any;
export interface NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod: any;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode: any;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType: any;
export interface NamespacesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    matchThreshold?: number;
    maxNumResults?: number;
    retrievalType?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export declare const NamespacesChatCompletionsRequestAiSearchOptionsRetrieval: S.Schema<NamespacesChatCompletionsRequestAiSearchOptionsRetrieval>;
export interface NamespacesChatCompletionsRequestAiSearchOptions {
    instanceIds: NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList;
    cache?: NamespacesChatCompletionsRequestAiSearchOptionsCache;
    queryRewrite?: NamespacesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: NamespacesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: NamespacesChatCompletionsRequestAiSearchOptionsRetrieval;
}
export declare const NamespacesChatCompletionsRequestAiSearchOptions: S.Schema<NamespacesChatCompletionsRequestAiSearchOptions>;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type: any;
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0: S.Schema<NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0>;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type: any;
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1: S.Schema<NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1>;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1Item = NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1;
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1Item: any;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1List = Array<NamespacesChatCompletionsRequestMessagesItemContentCase1Item>;
export declare const NamespacesChatCompletionsRequestMessagesItemContentCase1List: S.Schema<NamespacesChatCompletionsRequestMessagesItemContentCase1List>;
export type NamespacesChatCompletionsRequestMessagesItemContent = string | NamespacesChatCompletionsRequestMessagesItemContentCase1List;
export declare const NamespacesChatCompletionsRequestMessagesItemContent: any;
export type NamespacesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const NamespacesChatCompletionsRequestMessagesItemRole: any;
export interface NamespacesChatCompletionsRequestMessagesItem {
    content?: NamespacesChatCompletionsRequestMessagesItemContent | null;
    role: NamespacesChatCompletionsRequestMessagesItemRole | (string & {});
}
export declare const NamespacesChatCompletionsRequestMessagesItem: S.Schema<NamespacesChatCompletionsRequestMessagesItem>;
export type NamespacesChatCompletionsRequestMessagesList = Array<NamespacesChatCompletionsRequestMessagesItem>;
export declare const NamespacesChatCompletionsRequestMessagesList: S.Schema<NamespacesChatCompletionsRequestMessagesList>;
export type NamespacesChatCompletionsRequestModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesChatCompletionsRequestModel: any;
export interface ChatCompletionsNamespaceRequest {
    accountId: string;
    name: string;
    aiSearchOptions: NamespacesChatCompletionsRequestAiSearchOptions;
    messages: NamespacesChatCompletionsRequestMessagesList;
    model?: NamespacesChatCompletionsRequestModel | (string & {});
    stream?: boolean;
}
export declare const ChatCompletionsNamespaceRequest: S.Schema<ChatCompletionsNamespaceRequest>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type: any;
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0: S.Schema<NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type: any;
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1: S.Schema<NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item = NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1;
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item: any;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List: S.Schema<NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContent = string | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List;
export declare const NamespacesChatCompletionsResponseChoicesItemMessageContent: any;
export type NamespacesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const NamespacesChatCompletionsResponseChoicesItemMessageRole: any;
export interface NamespacesChatCompletionsResponseChoicesItemMessage {
    content: NamespacesChatCompletionsResponseChoicesItemMessageContent;
    role: NamespacesChatCompletionsResponseChoicesItemMessageRole;
}
export declare const NamespacesChatCompletionsResponseChoicesItemMessage: S.Schema<NamespacesChatCompletionsResponseChoicesItemMessage>;
export interface NamespacesChatCompletionsResponseChoicesItem {
    message: NamespacesChatCompletionsResponseChoicesItemMessage;
    index?: number | null;
}
export declare const NamespacesChatCompletionsResponseChoicesItem: S.Schema<NamespacesChatCompletionsResponseChoicesItem>;
export type NamespacesChatCompletionsResponseChoicesList = Array<NamespacesChatCompletionsResponseChoicesItem>;
export declare const NamespacesChatCompletionsResponseChoicesList: S.Schema<NamespacesChatCompletionsResponseChoicesList>;
export type NamespacesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesChatCompletionsResponseChunksItemItemMetadataMap: S.Schema<NamespacesChatCompletionsResponseChunksItemItemMetadataMap>;
export interface NamespacesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: NamespacesChatCompletionsResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const NamespacesChatCompletionsResponseChunksItemItem: S.Schema<NamespacesChatCompletionsResponseChunksItemItem>;
export type NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export declare const NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod: any;
export interface NamespacesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export declare const NamespacesChatCompletionsResponseChunksItemScoringDetails: S.Schema<NamespacesChatCompletionsResponseChunksItemScoringDetails>;
export interface NamespacesChatCompletionsResponseChunksItem {
    id: string;
    instanceId: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesChatCompletionsResponseChunksItemItem | null;
    scoringDetails?: NamespacesChatCompletionsResponseChunksItemScoringDetails | null;
}
export declare const NamespacesChatCompletionsResponseChunksItem: S.Schema<NamespacesChatCompletionsResponseChunksItem>;
export type NamespacesChatCompletionsResponseChunksList = Array<NamespacesChatCompletionsResponseChunksItem>;
export declare const NamespacesChatCompletionsResponseChunksList: S.Schema<NamespacesChatCompletionsResponseChunksList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsNamespaceResponse {
    choices: NamespacesChatCompletionsResponseChoicesList;
    chunks: NamespacesChatCompletionsResponseChunksList;
    id?: string | null;
    model?: string | null;
    object?: string | null;
}
export declare const ChatCompletionsNamespaceResponse: S.Schema<ChatCompletionsNamespaceResponse>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type: any;
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0: S.Schema<NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type: any;
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1: S.Schema<NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item = NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1;
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item: any;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List = Array<NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item>;
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List: S.Schema<NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContent = string | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List;
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemContent: any;
export type NamespacesInstancesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const NamespacesInstancesChatCompletionsRequestMessagesItemRole: any;
export interface NamespacesInstancesChatCompletionsRequestMessagesItem {
    content?: NamespacesInstancesChatCompletionsRequestMessagesItemContent | null;
    role: NamespacesInstancesChatCompletionsRequestMessagesItemRole | (string & {});
}
export declare const NamespacesInstancesChatCompletionsRequestMessagesItem: S.Schema<NamespacesInstancesChatCompletionsRequestMessagesItem>;
export type NamespacesInstancesChatCompletionsRequestMessagesList = Array<NamespacesInstancesChatCompletionsRequestMessagesItem>;
export declare const NamespacesInstancesChatCompletionsRequestMessagesList: S.Schema<NamespacesInstancesChatCompletionsRequestMessagesList>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold: any;
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewriteModel: any;
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    model?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewriteModel | (string & {});
    rewritePrompt?: string;
}
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewrite: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewrite>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRerankingModel: any;
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRerankingModel | (string & {});
}
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsReranking: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsReranking>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection: any;
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod: any;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode: any;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType: any;
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    matchThreshold?: number;
    maxNumResults?: number;
    retrievalType?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval>;
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptions {
    cache?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache;
    queryRewrite?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
    reranking?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsReranking;
    retrieval?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval;
}
export declare const NamespacesInstancesChatCompletionsRequestAiSearchOptions: S.Schema<NamespacesInstancesChatCompletionsRequestAiSearchOptions>;
export type NamespacesInstancesChatCompletionsRequestModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesChatCompletionsRequestModel: any;
export interface ChatCompletionsNamespaceInstanceRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    messages: NamespacesInstancesChatCompletionsRequestMessagesList;
    aiSearchOptions?: NamespacesInstancesChatCompletionsRequestAiSearchOptions;
    model?: NamespacesInstancesChatCompletionsRequestModel | (string & {});
    stream?: boolean;
}
export declare const ChatCompletionsNamespaceInstanceRequest: S.Schema<ChatCompletionsNamespaceInstanceRequest>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type: any;
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0: S.Schema<NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type: any;
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1: S.Schema<NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item = NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1;
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item: any;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List: S.Schema<NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent = string | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List;
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent: any;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole: any;
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessage {
    content: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent;
    role: NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole;
}
export declare const NamespacesInstancesChatCompletionsResponseChoicesItemMessage: S.Schema<NamespacesInstancesChatCompletionsResponseChoicesItemMessage>;
export interface NamespacesInstancesChatCompletionsResponseChoicesItem {
    message: NamespacesInstancesChatCompletionsResponseChoicesItemMessage;
    index?: number | null;
}
export declare const NamespacesInstancesChatCompletionsResponseChoicesItem: S.Schema<NamespacesInstancesChatCompletionsResponseChoicesItem>;
export type NamespacesInstancesChatCompletionsResponseChoicesList = Array<NamespacesInstancesChatCompletionsResponseChoicesItem>;
export declare const NamespacesInstancesChatCompletionsResponseChoicesList: S.Schema<NamespacesInstancesChatCompletionsResponseChoicesList>;
export type NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap: S.Schema<NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap>;
export interface NamespacesInstancesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const NamespacesInstancesChatCompletionsResponseChunksItemItem: S.Schema<NamespacesInstancesChatCompletionsResponseChunksItemItem>;
export type NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export declare const NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod: any;
export interface NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export declare const NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails: S.Schema<NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails>;
export interface NamespacesInstancesChatCompletionsResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesInstancesChatCompletionsResponseChunksItemItem | null;
    scoringDetails?: NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails | null;
}
export declare const NamespacesInstancesChatCompletionsResponseChunksItem: S.Schema<NamespacesInstancesChatCompletionsResponseChunksItem>;
export type NamespacesInstancesChatCompletionsResponseChunksList = Array<NamespacesInstancesChatCompletionsResponseChunksItem>;
export declare const NamespacesInstancesChatCompletionsResponseChunksList: S.Schema<NamespacesInstancesChatCompletionsResponseChunksList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsNamespaceInstanceResponse {
    choices: NamespacesInstancesChatCompletionsResponseChoicesList;
    chunks: NamespacesInstancesChatCompletionsResponseChunksList;
    id?: string | null;
    model?: string | null;
    object?: string | null;
}
export declare const ChatCompletionsNamespaceInstanceResponse: S.Schema<ChatCompletionsNamespaceInstanceResponse>;
export interface ChunksNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    limit?: number;
    offset?: number;
}
export declare const ChunksNamespaceInstanceItemRequest: S.Schema<ChunksNamespaceInstanceItemRequest>;
export type NamespacesInstancesItemsChunksResultItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesItemsChunksResultItemItemMetadataMap: S.Schema<NamespacesInstancesItemsChunksResultItemItemMetadataMap>;
export interface NamespacesInstancesItemsChunksResultItemItem {
    key: string;
    metadata?: NamespacesInstancesItemsChunksResultItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const NamespacesInstancesItemsChunksResultItemItem: S.Schema<NamespacesInstancesItemsChunksResultItemItem>;
export interface NamespacesInstancesItemsChunksResultItem {
    id: string;
    item: NamespacesInstancesItemsChunksResultItemItem;
    text: string;
    endByte?: number | null;
    startByte?: number | null;
}
export declare const NamespacesInstancesItemsChunksResultItem: S.Schema<NamespacesInstancesItemsChunksResultItem>;
export type NamespacesInstancesItemsChunksResultList = Array<NamespacesInstancesItemsChunksResultItem>;
export declare const NamespacesInstancesItemsChunksResultList: S.Schema<NamespacesInstancesItemsChunksResultList>;
export type ChunksNamespaceInstanceItemResponse = NamespacesInstancesItemsChunksResultList;
export declare const ChunksNamespaceInstanceItemResponse: S.Schema<ChunksNamespaceInstanceItemResponse>;
export type InstancesCreateRequestAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesCreateRequestAiSearchModel: any;
export type InstancesCreateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesCreateRequestCacheThreshold: any;
export type InstancesCreateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesCreateRequestCacheTtl: any;
export type InstancesCreateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesCreateRequestCustomMetadataItemDataType: any;
export interface InstancesCreateRequestCustomMetadataItem {
    dataType: InstancesCreateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export declare const InstancesCreateRequestCustomMetadataItem: S.Schema<InstancesCreateRequestCustomMetadataItem>;
export type InstancesCreateRequestCustomMetadataList = Array<InstancesCreateRequestCustomMetadataItem>;
export declare const InstancesCreateRequestCustomMetadataList: S.Schema<InstancesCreateRequestCustomMetadataList>;
export type InstancesCreateRequestEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesCreateRequestEmbeddingModel: any;
export type InstancesCreateRequestFusionMethod = "max" | "rrf";
export declare const InstancesCreateRequestFusionMethod: any;
export interface InstancesCreateRequestIndexMethod {
    /** Enable keyword (BM25) storage backend. */
    keyword: boolean;
    /** Enable vector (embedding) storage backend. */
    vector: boolean;
}
export declare const InstancesCreateRequestIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesCreateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesCreateRequestIndexingOptionsKeywordTokenizer: any;
export interface InstancesCreateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesCreateRequestIndexingOptionsKeywordTokenizer | (string & {});
}
export declare const InstancesCreateRequestIndexingOptions: S.Schema<InstancesCreateRequestIndexingOptions>;
export interface InstancesCreateRequestMetadata {
    createdFromAisearchWizard?: boolean;
    workerDomain?: string;
}
export declare const InstancesCreateRequestMetadata: S.Schema<InstancesCreateRequestMetadata>;
export type InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList>;
export interface InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint {
    /** Disable chat completions endpoint for this public endpoint */
    disabled?: boolean;
}
export declare const InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesCreateRequestPublicEndpointParamsCustomDomainsList: S.Schema<InstancesCreateRequestPublicEndpointParamsCustomDomainsList>;
export interface InstancesCreateRequestPublicEndpointParamsMcp {
    description?: string;
    /** Disable MCP endpoint for this public endpoint */
    disabled?: boolean;
}
export declare const InstancesCreateRequestPublicEndpointParamsMcp: S.Schema<InstancesCreateRequestPublicEndpointParamsMcp>;
export type InstancesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesCreateRequestPublicEndpointParamsRateLimitTechnique: any;
export interface InstancesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: InstancesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export declare const InstancesCreateRequestPublicEndpointParamsRateLimit: S.Schema<InstancesCreateRequestPublicEndpointParamsRateLimit>;
export interface InstancesCreateRequestPublicEndpointParamsSearchEndpoint {
    /** Disable search endpoint for this public endpoint */
    disabled?: boolean;
}
export declare const InstancesCreateRequestPublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsSearchEndpoint>;
export interface InstancesCreateRequestPublicEndpointParams {
    authorizedHosts?: InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesCreateRequestPublicEndpointParamsCustomDomainsList;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: InstancesCreateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export declare const InstancesCreateRequestPublicEndpointParams: S.Schema<InstancesCreateRequestPublicEndpointParams>;
export type InstancesCreateRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesCreateRequestRerankingModel: any;
export type InstancesCreateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesCreateRequestRetrievalOptionsBoostByItemDirection: any;
export interface InstancesCreateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesCreateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export declare const InstancesCreateRequestRetrievalOptionsBoostByItem: S.Schema<InstancesCreateRequestRetrievalOptionsBoostByItem>;
export type InstancesCreateRequestRetrievalOptionsBoostByList = Array<InstancesCreateRequestRetrievalOptionsBoostByItem>;
export declare const InstancesCreateRequestRetrievalOptionsBoostByList: S.Schema<InstancesCreateRequestRetrievalOptionsBoostByList>;
export type InstancesCreateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesCreateRequestRetrievalOptionsKeywordMatchMode: any;
export interface InstancesCreateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesCreateRequestRetrievalOptionsBoostByList;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesCreateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export declare const InstancesCreateRequestRetrievalOptions: S.Schema<InstancesCreateRequestRetrievalOptions>;
export type InstancesCreateRequestRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesCreateRequestRewriteModel: any;
export type InstancesCreateRequestSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesCreateRequestSourceParamsExcludeItemsList: S.Schema<InstancesCreateRequestSourceParamsExcludeItemsList>;
export type InstancesCreateRequestSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesCreateRequestSourceParamsIncludeItemsList: S.Schema<InstancesCreateRequestSourceParamsIncludeItemsList>;
export interface InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem {
    /** Glob pattern to match against the page URL path. Uses standard glob syntax: * matches within a segment, ** crosses directories. */
    path: string;
    /** CSS selector to extract content from pages matching the path pattern. Must not contain disallowed characters (;, `, $, {, }, ). Must target a single element; if multiple elements match, the selector is ignored and the full page is used. */
    selector: string;
}
export declare const InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesCreateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export declare const InstancesCreateRequestSourceParamsWebCrawlerParseOptions: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptions>;
export type InstancesCreateRequestSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesCreateRequestSourceParamsWebCrawlerParseType: any;
export type WebCrawlerCrawlOptionsSource = "all" | "sitemaps" | "links";
export declare const WebCrawlerCrawlOptionsSource: any;
export interface WebCrawlerCrawlOptions {
    /** Maximum crawl depth from the seed URL. */
    depth?: number | null;
    includeExternalLinks?: boolean | null;
    includeSubdomains?: boolean | null;
    maxAge?: number | null;
    /** Where the crawler discovers URLs: sitemaps, page links, or both. Use links for sitemap-less seeds (avoids missing_sitemap rejections). */
    source?: WebCrawlerCrawlOptionsSource | (string & {}) | null;
}
export declare const WebCrawlerCrawlOptions: S.Schema<WebCrawlerCrawlOptions>;
export interface InstancesCreateRequestSourceParamsWebCrawler {
    parseOptions?: InstancesCreateRequestSourceParamsWebCrawlerParseOptions;
    parseType?: InstancesCreateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export declare const InstancesCreateRequestSourceParamsWebCrawler: S.Schema<InstancesCreateRequestSourceParamsWebCrawler>;
export interface InstancesCreateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesCreateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesCreateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: InstancesCreateRequestSourceParamsWebCrawler;
}
export declare const InstancesCreateRequestSourceParams: S.Schema<InstancesCreateRequestSourceParams>;
export type InstancesCreateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesCreateRequestSyncInterval: any;
export type InstancesCreateRequestType = "r2" | "web-crawler";
export declare const InstancesCreateRequestType: any;
export interface CreateInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiGatewayId?: string;
    aiSearchModel?: InstancesCreateRequestAiSearchModel | (string & {});
    cache?: boolean;
    cacheThreshold?: InstancesCreateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesCreateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: InstancesCreateRequestCustomMetadataList;
    embeddingModel?: InstancesCreateRequestEmbeddingModel | (string & {});
    fusionMethod?: InstancesCreateRequestFusionMethod | (string & {});
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: InstancesCreateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: InstancesCreateRequestMetadata;
    publicEndpointParams?: InstancesCreateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: InstancesCreateRequestRerankingModel | (string & {});
    retrievalOptions?: InstancesCreateRequestRetrievalOptions;
    rewriteModel?: InstancesCreateRequestRewriteModel | (string & {});
    rewriteQuery?: boolean;
    scoreThreshold?: number;
    source?: string;
    sourceParams?: InstancesCreateRequestSourceParams;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesCreateRequestSyncInterval | (number & {});
    tokenId?: string;
    type?: InstancesCreateRequestType | (string & {});
}
export declare const CreateInstanceRequest: S.Schema<CreateInstanceRequest>;
export type InstancesCreateResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesCreateResponseAiSearchModel: any;
export type InstancesCreateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesCreateResponseCacheThreshold: any;
export type InstancesCreateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesCreateResponseCacheTtl: any;
export type InstancesCreateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesCreateResponseCustomMetadataItemDataType: any;
export interface InstancesCreateResponseCustomMetadataItem {
    dataType: InstancesCreateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const InstancesCreateResponseCustomMetadataItem: S.Schema<InstancesCreateResponseCustomMetadataItem>;
export type InstancesCreateResponseCustomMetadataList = Array<InstancesCreateResponseCustomMetadataItem>;
export declare const InstancesCreateResponseCustomMetadataList: S.Schema<InstancesCreateResponseCustomMetadataList>;
export type InstancesCreateResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesCreateResponseEmbeddingModel: any;
export type InstancesCreateResponseFusionMethod = "max" | "rrf";
export declare const InstancesCreateResponseFusionMethod: any;
export type InstancesCreateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const InstancesCreateResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesCreateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesCreateResponseIndexingOptionsKeywordTokenizer: any;
export interface InstancesCreateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesCreateResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const InstancesCreateResponseIndexingOptions: S.Schema<InstancesCreateResponseIndexingOptions>;
export interface InstancesCreateResponseMetadata {
    createdFromAisearchWizard?: boolean | null;
    workerDomain?: string | null;
}
export declare const InstancesCreateResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList>;
export interface InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint {
    /** Disable chat completions endpoint for this public endpoint */
    disabled?: boolean | null;
}
export declare const InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesCreateResponsePublicEndpointParamsCustomDomainsList: S.Schema<InstancesCreateResponsePublicEndpointParamsCustomDomainsList>;
export interface InstancesCreateResponsePublicEndpointParamsMcp {
    description?: string | null;
    /** Disable MCP endpoint for this public endpoint */
    disabled?: boolean | null;
}
export declare const InstancesCreateResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type InstancesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesCreateResponsePublicEndpointParamsRateLimitTechnique: any;
export interface InstancesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesCreateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const InstancesCreateResponsePublicEndpointParamsRateLimit: S.Schema<InstancesCreateResponsePublicEndpointParamsRateLimit>;
export interface InstancesCreateResponsePublicEndpointParamsSearchEndpoint {
    /** Disable search endpoint for this public endpoint */
    disabled?: boolean | null;
}
export declare const InstancesCreateResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface InstancesCreateResponsePublicEndpointParams {
    authorizedHosts?: InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesCreateResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesCreateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const InstancesCreateResponsePublicEndpointParams: S.Schema<InstancesCreateResponsePublicEndpointParams>;
export type InstancesCreateResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesCreateResponseRerankingModel: any;
export type InstancesCreateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesCreateResponseRetrievalOptionsBoostByItemDirection: any;
export interface InstancesCreateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesCreateResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const InstancesCreateResponseRetrievalOptionsBoostByItem: S.Schema<InstancesCreateResponseRetrievalOptionsBoostByItem>;
export type InstancesCreateResponseRetrievalOptionsBoostByList = Array<InstancesCreateResponseRetrievalOptionsBoostByItem>;
export declare const InstancesCreateResponseRetrievalOptionsBoostByList: S.Schema<InstancesCreateResponseRetrievalOptionsBoostByList>;
export type InstancesCreateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesCreateResponseRetrievalOptionsKeywordMatchMode: any;
export interface InstancesCreateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesCreateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesCreateResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const InstancesCreateResponseRetrievalOptions: S.Schema<InstancesCreateResponseRetrievalOptions>;
export type InstancesCreateResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesCreateResponseRewriteModel: any;
export type InstancesCreateResponseSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesCreateResponseSourceParamsExcludeItemsList: S.Schema<InstancesCreateResponseSourceParamsExcludeItemsList>;
export type InstancesCreateResponseSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesCreateResponseSourceParamsIncludeItemsList: S.Schema<InstancesCreateResponseSourceParamsIncludeItemsList>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesCreateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const InstancesCreateResponseSourceParamsWebCrawlerParseOptions: S.Schema<InstancesCreateResponseSourceParamsWebCrawlerParseOptions>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesCreateResponseSourceParamsWebCrawlerParseType: any;
export interface InstancesCreateResponseSourceParamsWebCrawler {
    parseOptions?: InstancesCreateResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: InstancesCreateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const InstancesCreateResponseSourceParamsWebCrawler: S.Schema<InstancesCreateResponseSourceParamsWebCrawler>;
export interface InstancesCreateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesCreateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesCreateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesCreateResponseSourceParamsWebCrawler | null;
}
export declare const InstancesCreateResponseSourceParams: S.Schema<InstancesCreateResponseSourceParams>;
export type InstancesCreateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesCreateResponseSyncInterval: any;
export type InstancesCreateResponseType = "r2" | "web-crawler";
export declare const InstancesCreateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: InstancesCreateResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesCreateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesCreateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesCreateResponseCustomMetadataList | null;
    embeddingModel?: InstancesCreateResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesCreateResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesCreateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesCreateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: InstancesCreateResponseRerankingModel | null;
    retrievalOptions?: InstancesCreateResponseRetrievalOptions | null;
    rewriteModel?: InstancesCreateResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesCreateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesCreateResponseSyncInterval | null;
    tokenId?: string | null;
    type?: InstancesCreateResponseType | null;
}
export declare const CreateInstanceResponse: S.Schema<CreateInstanceResponse>;
export interface CreateInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    description?: string;
}
export declare const CreateInstanceJobRequest: S.Schema<CreateInstanceJobRequest>;
export type InstancesJobsCreateResponseSource = "user" | "schedule";
export declare const InstancesJobsCreateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceJobResponse {
    id: string;
    source: InstancesJobsCreateResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const CreateInstanceJobResponse: S.Schema<CreateInstanceJobResponse>;
export interface CreateNamespaceRequest {
    accountId: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string;
}
export declare const CreateNamespaceRequest: S.Schema<CreateNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
}
export declare const CreateNamespaceResponse: S.Schema<CreateNamespaceResponse>;
export type NamespacesInstancesCreateRequestAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesCreateRequestAiSearchModel: any;
export type NamespacesInstancesCreateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesCreateRequestCacheThreshold: any;
export type NamespacesInstancesCreateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesCreateRequestCacheTtl: any;
export type NamespacesInstancesCreateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesCreateRequestCustomMetadataItemDataType: any;
export interface NamespacesInstancesCreateRequestCustomMetadataItem {
    dataType: NamespacesInstancesCreateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export declare const NamespacesInstancesCreateRequestCustomMetadataItem: S.Schema<NamespacesInstancesCreateRequestCustomMetadataItem>;
export type NamespacesInstancesCreateRequestCustomMetadataList = Array<NamespacesInstancesCreateRequestCustomMetadataItem>;
export declare const NamespacesInstancesCreateRequestCustomMetadataList: S.Schema<NamespacesInstancesCreateRequestCustomMetadataList>;
export type NamespacesInstancesCreateRequestEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesCreateRequestEmbeddingModel: any;
export type NamespacesInstancesCreateRequestFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesCreateRequestFusionMethod: any;
export type NamespacesInstancesCreateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesCreateRequestIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesCreateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer | (string & {});
}
export declare const NamespacesInstancesCreateRequestIndexingOptions: S.Schema<NamespacesInstancesCreateRequestIndexingOptions>;
export type NamespacesInstancesCreateRequestMetadata = InstancesCreateRequestMetadata;
export declare const NamespacesInstancesCreateRequestMetadata: S.Schema<InstancesCreateRequestMetadata>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsMcp: S.Schema<InstancesCreateRequestPublicEndpointParamsMcp>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesCreateRequestPublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesCreateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export declare const NamespacesInstancesCreateRequestPublicEndpointParams: S.Schema<NamespacesInstancesCreateRequestPublicEndpointParams>;
export type NamespacesInstancesCreateRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesCreateRequestRerankingModel: any;
export type NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export declare const NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem>;
export type NamespacesInstancesCreateRequestRetrievalOptionsBoostByList = Array<NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesCreateRequestRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesCreateRequestRetrievalOptionsBoostByList>;
export type NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesCreateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesCreateRequestRetrievalOptionsBoostByList;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export declare const NamespacesInstancesCreateRequestRetrievalOptions: S.Schema<NamespacesInstancesCreateRequestRetrievalOptions>;
export type NamespacesInstancesCreateRequestRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesCreateRequestRewriteModel: any;
export type NamespacesInstancesCreateRequestSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesCreateRequestSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesCreateRequestSourceParamsExcludeItemsList>;
export type NamespacesInstancesCreateRequestSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesCreateRequestSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesCreateRequestSourceParamsIncludeItemsList>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions;
    parseType?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export declare const NamespacesInstancesCreateRequestSourceParamsWebCrawler: S.Schema<NamespacesInstancesCreateRequestSourceParamsWebCrawler>;
export interface NamespacesInstancesCreateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesCreateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesCreateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: NamespacesInstancesCreateRequestSourceParamsWebCrawler;
}
export declare const NamespacesInstancesCreateRequestSourceParams: S.Schema<NamespacesInstancesCreateRequestSourceParams>;
export type NamespacesInstancesCreateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesCreateRequestSyncInterval: any;
export type NamespacesInstancesCreateRequestType = "r2" | "web-crawler";
export declare const NamespacesInstancesCreateRequestType: any;
export interface CreateNamespaceInstanceRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiGatewayId?: string;
    aiSearchModel?: NamespacesInstancesCreateRequestAiSearchModel | (string & {});
    cache?: boolean;
    cacheThreshold?: NamespacesInstancesCreateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesCreateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: NamespacesInstancesCreateRequestCustomMetadataList;
    embeddingModel?: NamespacesInstancesCreateRequestEmbeddingModel | (string & {});
    fusionMethod?: NamespacesInstancesCreateRequestFusionMethod | (string & {});
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: NamespacesInstancesCreateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: InstancesCreateRequestMetadata;
    publicEndpointParams?: NamespacesInstancesCreateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: NamespacesInstancesCreateRequestRerankingModel | (string & {});
    retrievalOptions?: NamespacesInstancesCreateRequestRetrievalOptions;
    rewriteModel?: NamespacesInstancesCreateRequestRewriteModel | (string & {});
    rewriteQuery?: boolean;
    scoreThreshold?: number;
    source?: string;
    sourceParams?: NamespacesInstancesCreateRequestSourceParams;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesCreateRequestSyncInterval | (number & {});
    tokenId?: string;
    type?: NamespacesInstancesCreateRequestType | (string & {});
}
export declare const CreateNamespaceInstanceRequest: S.Schema<CreateNamespaceInstanceRequest>;
export type NamespacesInstancesCreateResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesCreateResponseAiSearchModel: any;
export type NamespacesInstancesCreateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesCreateResponseCacheThreshold: any;
export type NamespacesInstancesCreateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesCreateResponseCacheTtl: any;
export type NamespacesInstancesCreateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesCreateResponseCustomMetadataItemDataType: any;
export interface NamespacesInstancesCreateResponseCustomMetadataItem {
    dataType: NamespacesInstancesCreateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const NamespacesInstancesCreateResponseCustomMetadataItem: S.Schema<NamespacesInstancesCreateResponseCustomMetadataItem>;
export type NamespacesInstancesCreateResponseCustomMetadataList = Array<NamespacesInstancesCreateResponseCustomMetadataItem>;
export declare const NamespacesInstancesCreateResponseCustomMetadataList: S.Schema<NamespacesInstancesCreateResponseCustomMetadataList>;
export type NamespacesInstancesCreateResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesCreateResponseEmbeddingModel: any;
export type NamespacesInstancesCreateResponseFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesCreateResponseFusionMethod: any;
export type NamespacesInstancesCreateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesCreateResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesCreateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const NamespacesInstancesCreateResponseIndexingOptions: S.Schema<NamespacesInstancesCreateResponseIndexingOptions>;
export type NamespacesInstancesCreateResponseMetadata = InstancesCreateResponseMetadata;
export declare const NamespacesInstancesCreateResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesCreateResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesCreateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const NamespacesInstancesCreateResponsePublicEndpointParams: S.Schema<NamespacesInstancesCreateResponsePublicEndpointParams>;
export type NamespacesInstancesCreateResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesCreateResponseRerankingModel: any;
export type NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesCreateResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesCreateResponseRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesCreateResponseRetrievalOptionsBoostByList>;
export type NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesCreateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesCreateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const NamespacesInstancesCreateResponseRetrievalOptions: S.Schema<NamespacesInstancesCreateResponseRetrievalOptions>;
export type NamespacesInstancesCreateResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesCreateResponseRewriteModel: any;
export type NamespacesInstancesCreateResponseSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesCreateResponseSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesCreateResponseSourceParamsExcludeItemsList>;
export type NamespacesInstancesCreateResponseSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesCreateResponseSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesCreateResponseSourceParamsIncludeItemsList>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const NamespacesInstancesCreateResponseSourceParamsWebCrawler: S.Schema<NamespacesInstancesCreateResponseSourceParamsWebCrawler>;
export interface NamespacesInstancesCreateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesCreateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesCreateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesCreateResponseSourceParamsWebCrawler | null;
}
export declare const NamespacesInstancesCreateResponseSourceParams: S.Schema<NamespacesInstancesCreateResponseSourceParams>;
export type NamespacesInstancesCreateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesCreateResponseSyncInterval: any;
export type NamespacesInstancesCreateResponseType = "r2" | "web-crawler";
export declare const NamespacesInstancesCreateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: NamespacesInstancesCreateResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesCreateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesCreateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesCreateResponseCustomMetadataList | null;
    embeddingModel?: NamespacesInstancesCreateResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesCreateResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesCreateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesCreateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: NamespacesInstancesCreateResponseRerankingModel | null;
    retrievalOptions?: NamespacesInstancesCreateResponseRetrievalOptions | null;
    rewriteModel?: NamespacesInstancesCreateResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesCreateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesCreateResponseSyncInterval | null;
    tokenId?: string | null;
    type?: NamespacesInstancesCreateResponseType | null;
}
export declare const CreateNamespaceInstanceResponse: S.Schema<CreateNamespaceInstanceResponse>;
export interface CreateNamespaceInstanceJobRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    description?: string;
}
export declare const CreateNamespaceInstanceJobRequest: S.Schema<CreateNamespaceInstanceJobRequest>;
export type NamespacesInstancesJobsCreateResponseSource = "user" | "schedule";
export declare const NamespacesInstancesJobsCreateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsCreateResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const CreateNamespaceInstanceJobResponse: S.Schema<CreateNamespaceInstanceJobResponse>;
export type NamespacesInstancesItemsCreateOrUpdateRequestNextAction = "INDEX";
export declare const NamespacesInstancesItemsCreateOrUpdateRequestNextAction: any;
export interface CreateOrUpdateNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    /** Item key / filename. Must not exceed 128 characters. */
    key: string;
    nextAction: NamespacesInstancesItemsCreateOrUpdateRequestNextAction | (string & {});
    /** Wait for indexing to fully complete before responding. On RAGs with vector indexing enabled, this additionally waits for Vectorize ingestion confirmation (up to 40s) so the returned item reflects a queryable state. On timeout the item is returned in `running` state and the background alarm continues polling. Defaults to false. */
    waitForCompletion?: boolean;
}
export declare const CreateOrUpdateNamespaceInstanceItemRequest: S.Schema<CreateOrUpdateNamespaceInstanceItemRequest>;
export type NamespacesInstancesItemsCreateOrUpdateResponseNextAction = "INDEX" | "DELETE";
export declare const NamespacesInstancesItemsCreateOrUpdateResponseNextAction: any;
export type NamespacesInstancesItemsCreateOrUpdateResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export declare const NamespacesInstancesItemsCreateOrUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOrUpdateNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    namespace: string;
    nextAction: NamespacesInstancesItemsCreateOrUpdateResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsCreateOrUpdateResponseStatus;
    error?: string | null;
}
export declare const CreateOrUpdateNamespaceInstanceItemResponse: S.Schema<CreateOrUpdateNamespaceInstanceItemResponse>;
export interface CreateTokenRequest {
    accountId: string;
    cfApiId: string;
    cfApiKey: string;
    name: string;
    legacy?: boolean;
}
export declare const CreateTokenRequest: S.Schema<CreateTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export declare const CreateTokenResponse: S.Schema<CreateTokenResponse>;
export interface DeleteInstanceRequest {
    accountId: string;
    id: string;
}
export declare const DeleteInstanceRequest: S.Schema<DeleteInstanceRequest>;
export type InstancesDeleteResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesDeleteResponseAiSearchModel: any;
export type InstancesDeleteResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesDeleteResponseCacheThreshold: any;
export type InstancesDeleteResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesDeleteResponseCacheTtl: any;
export type InstancesDeleteResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesDeleteResponseCustomMetadataItemDataType: any;
export interface InstancesDeleteResponseCustomMetadataItem {
    dataType: InstancesDeleteResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const InstancesDeleteResponseCustomMetadataItem: S.Schema<InstancesDeleteResponseCustomMetadataItem>;
export type InstancesDeleteResponseCustomMetadataList = Array<InstancesDeleteResponseCustomMetadataItem>;
export declare const InstancesDeleteResponseCustomMetadataList: S.Schema<InstancesDeleteResponseCustomMetadataList>;
export type InstancesDeleteResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesDeleteResponseEmbeddingModel: any;
export type InstancesDeleteResponseFusionMethod = "max" | "rrf";
export declare const InstancesDeleteResponseFusionMethod: any;
export type InstancesDeleteResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const InstancesDeleteResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesDeleteResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesDeleteResponseIndexingOptionsKeywordTokenizer: any;
export interface InstancesDeleteResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesDeleteResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const InstancesDeleteResponseIndexingOptions: S.Schema<InstancesDeleteResponseIndexingOptions>;
export type InstancesDeleteResponseMetadata = InstancesCreateResponseMetadata;
export declare const InstancesDeleteResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList>;
export type InstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const InstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesDeleteResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesDeleteResponsePublicEndpointParamsCustomDomainsList: S.Schema<InstancesDeleteResponsePublicEndpointParamsCustomDomainsList>;
export type InstancesDeleteResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const InstancesDeleteResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique: any;
export interface InstancesDeleteResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const InstancesDeleteResponsePublicEndpointParamsRateLimit: S.Schema<InstancesDeleteResponsePublicEndpointParamsRateLimit>;
export type InstancesDeleteResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const InstancesDeleteResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface InstancesDeleteResponsePublicEndpointParams {
    authorizedHosts?: InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesDeleteResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesDeleteResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const InstancesDeleteResponsePublicEndpointParams: S.Schema<InstancesDeleteResponsePublicEndpointParams>;
export type InstancesDeleteResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesDeleteResponseRerankingModel: any;
export type InstancesDeleteResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesDeleteResponseRetrievalOptionsBoostByItemDirection: any;
export interface InstancesDeleteResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesDeleteResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const InstancesDeleteResponseRetrievalOptionsBoostByItem: S.Schema<InstancesDeleteResponseRetrievalOptionsBoostByItem>;
export type InstancesDeleteResponseRetrievalOptionsBoostByList = Array<InstancesDeleteResponseRetrievalOptionsBoostByItem>;
export declare const InstancesDeleteResponseRetrievalOptionsBoostByList: S.Schema<InstancesDeleteResponseRetrievalOptionsBoostByList>;
export type InstancesDeleteResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesDeleteResponseRetrievalOptionsKeywordMatchMode: any;
export interface InstancesDeleteResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesDeleteResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesDeleteResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const InstancesDeleteResponseRetrievalOptions: S.Schema<InstancesDeleteResponseRetrievalOptions>;
export type InstancesDeleteResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesDeleteResponseRewriteModel: any;
export type InstancesDeleteResponseSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesDeleteResponseSourceParamsExcludeItemsList: S.Schema<InstancesDeleteResponseSourceParamsExcludeItemsList>;
export type InstancesDeleteResponseSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesDeleteResponseSourceParamsIncludeItemsList: S.Schema<InstancesDeleteResponseSourceParamsIncludeItemsList>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesDeleteResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const InstancesDeleteResponseSourceParamsWebCrawlerParseOptions: S.Schema<InstancesDeleteResponseSourceParamsWebCrawlerParseOptions>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesDeleteResponseSourceParamsWebCrawlerParseType: any;
export interface InstancesDeleteResponseSourceParamsWebCrawler {
    parseOptions?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: InstancesDeleteResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const InstancesDeleteResponseSourceParamsWebCrawler: S.Schema<InstancesDeleteResponseSourceParamsWebCrawler>;
export interface InstancesDeleteResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesDeleteResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesDeleteResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesDeleteResponseSourceParamsWebCrawler | null;
}
export declare const InstancesDeleteResponseSourceParams: S.Schema<InstancesDeleteResponseSourceParams>;
export type InstancesDeleteResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesDeleteResponseSyncInterval: any;
export type InstancesDeleteResponseType = "r2" | "web-crawler";
export declare const InstancesDeleteResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: InstancesDeleteResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesDeleteResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesDeleteResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesDeleteResponseCustomMetadataList | null;
    embeddingModel?: InstancesDeleteResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesDeleteResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesDeleteResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesDeleteResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: InstancesDeleteResponseRerankingModel | null;
    retrievalOptions?: InstancesDeleteResponseRetrievalOptions | null;
    rewriteModel?: InstancesDeleteResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesDeleteResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesDeleteResponseSyncInterval | null;
    tokenId?: string | null;
    type?: InstancesDeleteResponseType | null;
}
export declare const DeleteInstanceResponse: S.Schema<DeleteInstanceResponse>;
export interface DeleteNamespaceRequest {
    accountId: string;
    name: string;
}
export declare const DeleteNamespaceRequest: S.Schema<DeleteNamespaceRequest>;
export type DeleteNamespaceResponse = unknown;
export declare const DeleteNamespaceResponse: S.Schema<DeleteNamespaceResponse>;
export interface DeleteNamespaceInstanceRequest {
    accountId: string;
    name: string;
    id: string;
}
export declare const DeleteNamespaceInstanceRequest: S.Schema<DeleteNamespaceInstanceRequest>;
export type NamespacesInstancesDeleteResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesDeleteResponseAiSearchModel: any;
export type NamespacesInstancesDeleteResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesDeleteResponseCacheThreshold: any;
export type NamespacesInstancesDeleteResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesDeleteResponseCacheTtl: any;
export type NamespacesInstancesDeleteResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesDeleteResponseCustomMetadataItemDataType: any;
export interface NamespacesInstancesDeleteResponseCustomMetadataItem {
    dataType: NamespacesInstancesDeleteResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const NamespacesInstancesDeleteResponseCustomMetadataItem: S.Schema<NamespacesInstancesDeleteResponseCustomMetadataItem>;
export type NamespacesInstancesDeleteResponseCustomMetadataList = Array<NamespacesInstancesDeleteResponseCustomMetadataItem>;
export declare const NamespacesInstancesDeleteResponseCustomMetadataList: S.Schema<NamespacesInstancesDeleteResponseCustomMetadataList>;
export type NamespacesInstancesDeleteResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesDeleteResponseEmbeddingModel: any;
export type NamespacesInstancesDeleteResponseFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesDeleteResponseFusionMethod: any;
export type NamespacesInstancesDeleteResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesDeleteResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesDeleteResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const NamespacesInstancesDeleteResponseIndexingOptions: S.Schema<NamespacesInstancesDeleteResponseIndexingOptions>;
export type NamespacesInstancesDeleteResponseMetadata = InstancesCreateResponseMetadata;
export declare const NamespacesInstancesDeleteResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesDeleteResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesDeleteResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const NamespacesInstancesDeleteResponsePublicEndpointParams: S.Schema<NamespacesInstancesDeleteResponsePublicEndpointParams>;
export type NamespacesInstancesDeleteResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesDeleteResponseRerankingModel: any;
export type NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList>;
export type NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesDeleteResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const NamespacesInstancesDeleteResponseRetrievalOptions: S.Schema<NamespacesInstancesDeleteResponseRetrievalOptions>;
export type NamespacesInstancesDeleteResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesDeleteResponseRewriteModel: any;
export type NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList>;
export type NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const NamespacesInstancesDeleteResponseSourceParamsWebCrawler: S.Schema<NamespacesInstancesDeleteResponseSourceParamsWebCrawler>;
export interface NamespacesInstancesDeleteResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesDeleteResponseSourceParamsWebCrawler | null;
}
export declare const NamespacesInstancesDeleteResponseSourceParams: S.Schema<NamespacesInstancesDeleteResponseSourceParams>;
export type NamespacesInstancesDeleteResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesDeleteResponseSyncInterval: any;
export type NamespacesInstancesDeleteResponseType = "r2" | "web-crawler";
export declare const NamespacesInstancesDeleteResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: NamespacesInstancesDeleteResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesDeleteResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesDeleteResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesDeleteResponseCustomMetadataList | null;
    embeddingModel?: NamespacesInstancesDeleteResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesDeleteResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesDeleteResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesDeleteResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: NamespacesInstancesDeleteResponseRerankingModel | null;
    retrievalOptions?: NamespacesInstancesDeleteResponseRetrievalOptions | null;
    rewriteModel?: NamespacesInstancesDeleteResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesDeleteResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesDeleteResponseSyncInterval | null;
    tokenId?: string | null;
    type?: NamespacesInstancesDeleteResponseType | null;
}
export declare const DeleteNamespaceInstanceResponse: S.Schema<DeleteNamespaceInstanceResponse>;
export interface DeleteNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export declare const DeleteNamespaceInstanceItemRequest: S.Schema<DeleteNamespaceInstanceItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteNamespaceInstanceItemResponse {
    key: string;
}
export declare const DeleteNamespaceInstanceItemResponse: S.Schema<DeleteNamespaceInstanceItemResponse>;
export interface DeleteTokenRequest {
    accountId: string;
    id: string;
}
export declare const DeleteTokenRequest: S.Schema<DeleteTokenRequest>;
export type DeleteTokenResponse = unknown;
export declare const DeleteTokenResponse: S.Schema<DeleteTokenResponse>;
export interface DownloadNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export declare const DownloadNamespaceInstanceItemRequest: S.Schema<DownloadNamespaceInstanceItemRequest>;
export interface DownloadNamespaceInstanceItemResponse {
}
export declare const DownloadNamespaceInstanceItemResponse: S.Schema<DownloadNamespaceInstanceItemResponse>;
export interface GetInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
}
export declare const GetInstanceJobRequest: S.Schema<GetInstanceJobRequest>;
export type InstancesJobsGetResponseSource = "user" | "schedule";
export declare const InstancesJobsGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInstanceJobResponse {
    id: string;
    source: InstancesJobsGetResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const GetInstanceJobResponse: S.Schema<GetInstanceJobResponse>;
export interface GetNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export declare const GetNamespaceInstanceItemRequest: S.Schema<GetNamespaceInstanceItemRequest>;
export type NamespacesInstancesItemsGetResponseNextAction = "INDEX" | "DELETE";
export declare const NamespacesInstancesItemsGetResponseNextAction: any;
export type NamespacesInstancesItemsGetResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export declare const NamespacesInstancesItemsGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    namespace: string;
    nextAction: NamespacesInstancesItemsGetResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsGetResponseStatus;
    error?: string | null;
}
export declare const GetNamespaceInstanceItemResponse: S.Schema<GetNamespaceInstanceItemResponse>;
export interface GetNamespaceInstanceJobRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
}
export declare const GetNamespaceInstanceJobRequest: S.Schema<GetNamespaceInstanceJobRequest>;
export type NamespacesInstancesJobsGetResponseSource = "user" | "schedule";
export declare const NamespacesInstancesJobsGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsGetResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const GetNamespaceInstanceJobResponse: S.Schema<GetNamespaceInstanceJobResponse>;
export interface ListInstanceJobsRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    page?: number;
    perPage?: number;
}
export declare const ListInstanceJobsRequest: S.Schema<ListInstanceJobsRequest>;
export type InstancesJobsListResultItemSource = "user" | "schedule";
export declare const InstancesJobsListResultItemSource: any;
export interface InstancesJobsListResultItem {
    id: string;
    source: InstancesJobsListResultItemSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const InstancesJobsListResultItem: S.Schema<InstancesJobsListResultItem>;
export type InstancesJobsListResultList = Array<InstancesJobsListResultItem>;
export declare const InstancesJobsListResultList: S.Schema<InstancesJobsListResultList>;
export interface ListInstanceJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInstanceJobsResponse: S.Schema<ListInstanceJobsResponse>;
export type InstancesListRequestOrderBy = "created_at";
export declare const InstancesListRequestOrderBy: any;
export type InstancesListRequestOrderByDirection = "asc" | "desc";
export declare const InstancesListRequestOrderByDirection: any;
export interface ListInstancesRequest {
    accountId: string;
    /** Filter by namespace. */
    namespace?: string;
    /** Field to order results by. */
    orderBy?: InstancesListRequestOrderBy | (string & {});
    /** Order direction. */
    orderByDirection?: InstancesListRequestOrderByDirection | (string & {});
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter instances whose id contains this string (case-insensitive). */
    search?: string;
}
export declare const ListInstancesRequest: S.Schema<ListInstancesRequest>;
export type InstancesListResultItemAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesListResultItemAiSearchModel: any;
export type InstancesListResultItemCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesListResultItemCacheThreshold: any;
export type InstancesListResultItemCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesListResultItemCacheTtl: any;
export type InstancesListResultItemCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesListResultItemCustomMetadataItemDataType: any;
export interface InstancesListResultItemCustomMetadataItem {
    dataType: InstancesListResultItemCustomMetadataItemDataType;
    fieldName: string;
}
export declare const InstancesListResultItemCustomMetadataItem: S.Schema<InstancesListResultItemCustomMetadataItem>;
export type InstancesListResultItemCustomMetadataList = Array<InstancesListResultItemCustomMetadataItem>;
export declare const InstancesListResultItemCustomMetadataList: S.Schema<InstancesListResultItemCustomMetadataList>;
export type InstancesListResultItemEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesListResultItemEmbeddingModel: any;
export type InstancesListResultItemFusionMethod = "max" | "rrf";
export declare const InstancesListResultItemFusionMethod: any;
export type InstancesListResultItemIndexMethod = InstancesCreateRequestIndexMethod;
export declare const InstancesListResultItemIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesListResultItemIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesListResultItemIndexingOptionsKeywordTokenizer: any;
export interface InstancesListResultItemIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesListResultItemIndexingOptionsKeywordTokenizer | null;
}
export declare const InstancesListResultItemIndexingOptions: S.Schema<InstancesListResultItemIndexingOptions>;
export type InstancesListResultItemMetadata = InstancesCreateResponseMetadata;
export declare const InstancesListResultItemMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type InstancesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesListResultItemPublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesListResultItemPublicEndpointParamsAuthorizedHostsList>;
export type InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesListResultItemPublicEndpointParamsCustomDomainsList: S.Schema<InstancesListResultItemPublicEndpointParamsCustomDomainsList>;
export type InstancesListResultItemPublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const InstancesListResultItemPublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type InstancesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesListResultItemPublicEndpointParamsRateLimitTechnique: any;
export interface InstancesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesListResultItemPublicEndpointParamsRateLimitTechnique | null;
}
export declare const InstancesListResultItemPublicEndpointParamsRateLimit: S.Schema<InstancesListResultItemPublicEndpointParamsRateLimit>;
export type InstancesListResultItemPublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const InstancesListResultItemPublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface InstancesListResultItemPublicEndpointParams {
    authorizedHosts?: InstancesListResultItemPublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesListResultItemPublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesListResultItemPublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const InstancesListResultItemPublicEndpointParams: S.Schema<InstancesListResultItemPublicEndpointParams>;
export type InstancesListResultItemRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesListResultItemRerankingModel: any;
export type InstancesListResultItemRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesListResultItemRetrievalOptionsBoostByItemDirection: any;
export interface InstancesListResultItemRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesListResultItemRetrievalOptionsBoostByItemDirection | null;
}
export declare const InstancesListResultItemRetrievalOptionsBoostByItem: S.Schema<InstancesListResultItemRetrievalOptionsBoostByItem>;
export type InstancesListResultItemRetrievalOptionsBoostByList = Array<InstancesListResultItemRetrievalOptionsBoostByItem>;
export declare const InstancesListResultItemRetrievalOptionsBoostByList: S.Schema<InstancesListResultItemRetrievalOptionsBoostByList>;
export type InstancesListResultItemRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesListResultItemRetrievalOptionsKeywordMatchMode: any;
export interface InstancesListResultItemRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesListResultItemRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesListResultItemRetrievalOptionsKeywordMatchMode | null;
}
export declare const InstancesListResultItemRetrievalOptions: S.Schema<InstancesListResultItemRetrievalOptions>;
export type InstancesListResultItemRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesListResultItemRewriteModel: any;
export type InstancesListResultItemSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesListResultItemSourceParamsExcludeItemsList: S.Schema<InstancesListResultItemSourceParamsExcludeItemsList>;
export type InstancesListResultItemSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesListResultItemSourceParamsIncludeItemsList: S.Schema<InstancesListResultItemSourceParamsIncludeItemsList>;
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesListResultItemSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const InstancesListResultItemSourceParamsWebCrawlerParseOptions: S.Schema<InstancesListResultItemSourceParamsWebCrawlerParseOptions>;
export type InstancesListResultItemSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesListResultItemSourceParamsWebCrawlerParseType: any;
export interface InstancesListResultItemSourceParamsWebCrawler {
    parseOptions?: InstancesListResultItemSourceParamsWebCrawlerParseOptions | null;
    parseType?: InstancesListResultItemSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const InstancesListResultItemSourceParamsWebCrawler: S.Schema<InstancesListResultItemSourceParamsWebCrawler>;
export interface InstancesListResultItemSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesListResultItemSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesListResultItemSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesListResultItemSourceParamsWebCrawler | null;
}
export declare const InstancesListResultItemSourceParams: S.Schema<InstancesListResultItemSourceParams>;
export type InstancesListResultItemSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesListResultItemSyncInterval: any;
export type InstancesListResultItemType = "r2" | "web-crawler";
export declare const InstancesListResultItemType: any;
export interface InstancesListResultItem {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: InstancesListResultItemAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesListResultItemCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesListResultItemCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesListResultItemCustomMetadataList | null;
    embeddingModel?: InstancesListResultItemEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesListResultItemFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesListResultItemIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesListResultItemPublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: InstancesListResultItemRerankingModel | null;
    retrievalOptions?: InstancesListResultItemRetrievalOptions | null;
    rewriteModel?: InstancesListResultItemRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesListResultItemSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesListResultItemSyncInterval | null;
    tokenId?: string | null;
    type?: InstancesListResultItemType | null;
}
export declare const InstancesListResultItem: S.Schema<InstancesListResultItem>;
export type InstancesListResultList = Array<InstancesListResultItem>;
export declare const InstancesListResultList: S.Schema<InstancesListResultList>;
export interface ListInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInstancesResponse: S.Schema<ListInstancesResponse>;
export type NamespacesInstancesItemsListRequestSortBy = "status" | "modified_at";
export declare const NamespacesInstancesItemsListRequestSortBy: any;
export type NamespacesInstancesItemsListRequestStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export declare const NamespacesInstancesItemsListRequestStatus: any;
export interface ListNamespaceInstanceItemsRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    /** Filter items by their unique ID. Returns at most one item. */
    itemId?: string;
    /** JSON-encoded metadata filter using Vectorize filter syntax. Examples: {"folder":"reports/"}, {"timestamp":{"$gte":1700000000000}}, {"folder":{"$in":["docs/","reports/"]}} */
    metadataFilter?: string;
    page?: number;
    perPage?: number;
    search?: string;
    /** Sort order for items. "status" (default) sorts by status priority then last_seen_at. "modified_at" sorts by file modification time (most recent first), falling back to created_at. */
    sortBy?: NamespacesInstancesItemsListRequestSortBy | (string & {});
    /** Filter items by source_id. Use "builtin" for uploaded files, or a source identifier like "web-crawler:https://example.com". */
    source?: string;
    status?: NamespacesInstancesItemsListRequestStatus | (string & {});
}
export declare const ListNamespaceInstanceItemsRequest: S.Schema<ListNamespaceInstanceItemsRequest>;
export type NamespacesInstancesItemsListResultItemNextAction = "INDEX" | "DELETE";
export declare const NamespacesInstancesItemsListResultItemNextAction: any;
export type NamespacesInstancesItemsListResultItemStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export declare const NamespacesInstancesItemsListResultItemStatus: any;
export interface NamespacesInstancesItemsListResultItem {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    namespace: string;
    nextAction: NamespacesInstancesItemsListResultItemNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsListResultItemStatus;
    error?: string | null;
}
export declare const NamespacesInstancesItemsListResultItem: S.Schema<NamespacesInstancesItemsListResultItem>;
export type NamespacesInstancesItemsListResultList = Array<NamespacesInstancesItemsListResultItem>;
export declare const NamespacesInstancesItemsListResultList: S.Schema<NamespacesInstancesItemsListResultList>;
export interface ListNamespaceInstanceItemsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesItemsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespaceInstanceItemsResponse: S.Schema<ListNamespaceInstanceItemsResponse>;
export interface ListNamespaceInstanceJobsRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    page?: number;
    perPage?: number;
}
export declare const ListNamespaceInstanceJobsRequest: S.Schema<ListNamespaceInstanceJobsRequest>;
export type NamespacesInstancesJobsListResultItemSource = "user" | "schedule";
export declare const NamespacesInstancesJobsListResultItemSource: any;
export interface NamespacesInstancesJobsListResultItem {
    id: string;
    source: NamespacesInstancesJobsListResultItemSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const NamespacesInstancesJobsListResultItem: S.Schema<NamespacesInstancesJobsListResultItem>;
export type NamespacesInstancesJobsListResultList = Array<NamespacesInstancesJobsListResultItem>;
export declare const NamespacesInstancesJobsListResultList: S.Schema<NamespacesInstancesJobsListResultList>;
export interface ListNamespaceInstanceJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespaceInstanceJobsResponse: S.Schema<ListNamespaceInstanceJobsResponse>;
export type NamespacesInstancesListRequestOrderBy = "created_at";
export declare const NamespacesInstancesListRequestOrderBy: any;
export type NamespacesInstancesListRequestOrderByDirection = "asc" | "desc";
export declare const NamespacesInstancesListRequestOrderByDirection: any;
export interface ListNamespaceInstancesRequest {
    accountId: string;
    name: string;
    /** Filter by namespace. */
    namespace?: string;
    /** Field to order results by. */
    orderBy?: NamespacesInstancesListRequestOrderBy | (string & {});
    /** Order direction. */
    orderByDirection?: NamespacesInstancesListRequestOrderByDirection | (string & {});
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter instances whose id contains this string (case-insensitive). */
    search?: string;
}
export declare const ListNamespaceInstancesRequest: S.Schema<ListNamespaceInstancesRequest>;
export type NamespacesInstancesListResultItemAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesListResultItemAiSearchModel: any;
export type NamespacesInstancesListResultItemCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesListResultItemCacheThreshold: any;
export type NamespacesInstancesListResultItemCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesListResultItemCacheTtl: any;
export type NamespacesInstancesListResultItemCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesListResultItemCustomMetadataItemDataType: any;
export interface NamespacesInstancesListResultItemCustomMetadataItem {
    dataType: NamespacesInstancesListResultItemCustomMetadataItemDataType;
    fieldName: string;
}
export declare const NamespacesInstancesListResultItemCustomMetadataItem: S.Schema<NamespacesInstancesListResultItemCustomMetadataItem>;
export type NamespacesInstancesListResultItemCustomMetadataList = Array<NamespacesInstancesListResultItemCustomMetadataItem>;
export declare const NamespacesInstancesListResultItemCustomMetadataList: S.Schema<NamespacesInstancesListResultItemCustomMetadataList>;
export type NamespacesInstancesListResultItemEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesListResultItemEmbeddingModel: any;
export type NamespacesInstancesListResultItemFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesListResultItemFusionMethod: any;
export type NamespacesInstancesListResultItemIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesListResultItemIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesListResultItemIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer | null;
}
export declare const NamespacesInstancesListResultItemIndexingOptions: S.Schema<NamespacesInstancesListResultItemIndexingOptions>;
export type NamespacesInstancesListResultItemMetadata = InstancesCreateResponseMetadata;
export declare const NamespacesInstancesListResultItemMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesListResultItemPublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const NamespacesInstancesListResultItemPublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique | null;
}
export declare const NamespacesInstancesListResultItemPublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesListResultItemPublicEndpointParamsRateLimit>;
export type NamespacesInstancesListResultItemPublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesListResultItemPublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesListResultItemPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesListResultItemPublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const NamespacesInstancesListResultItemPublicEndpointParams: S.Schema<NamespacesInstancesListResultItemPublicEndpointParams>;
export type NamespacesInstancesListResultItemRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesListResultItemRerankingModel: any;
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesListResultItemRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection | null;
}
export declare const NamespacesInstancesListResultItemRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesListResultItemRetrievalOptionsBoostByItem>;
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByList = Array<NamespacesInstancesListResultItemRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesListResultItemRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesListResultItemRetrievalOptionsBoostByList>;
export type NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesListResultItemRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesListResultItemRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode | null;
}
export declare const NamespacesInstancesListResultItemRetrievalOptions: S.Schema<NamespacesInstancesListResultItemRetrievalOptions>;
export type NamespacesInstancesListResultItemRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesListResultItemRewriteModel: any;
export type NamespacesInstancesListResultItemSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesListResultItemSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesListResultItemSourceParamsExcludeItemsList>;
export type NamespacesInstancesListResultItemSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesListResultItemSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesListResultItemSourceParamsIncludeItemsList>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesListResultItemSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions | null;
    parseType?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const NamespacesInstancesListResultItemSourceParamsWebCrawler: S.Schema<NamespacesInstancesListResultItemSourceParamsWebCrawler>;
export interface NamespacesInstancesListResultItemSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesListResultItemSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesListResultItemSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesListResultItemSourceParamsWebCrawler | null;
}
export declare const NamespacesInstancesListResultItemSourceParams: S.Schema<NamespacesInstancesListResultItemSourceParams>;
export type NamespacesInstancesListResultItemSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesListResultItemSyncInterval: any;
export type NamespacesInstancesListResultItemType = "r2" | "web-crawler";
export declare const NamespacesInstancesListResultItemType: any;
export interface NamespacesInstancesListResultItem {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: NamespacesInstancesListResultItemAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesListResultItemCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesListResultItemCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesListResultItemCustomMetadataList | null;
    embeddingModel?: NamespacesInstancesListResultItemEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesListResultItemFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesListResultItemIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesListResultItemPublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: NamespacesInstancesListResultItemRerankingModel | null;
    retrievalOptions?: NamespacesInstancesListResultItemRetrievalOptions | null;
    rewriteModel?: NamespacesInstancesListResultItemRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesListResultItemSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesListResultItemSyncInterval | null;
    tokenId?: string | null;
    type?: NamespacesInstancesListResultItemType | null;
}
export declare const NamespacesInstancesListResultItem: S.Schema<NamespacesInstancesListResultItem>;
export type NamespacesInstancesListResultList = Array<NamespacesInstancesListResultItem>;
export declare const NamespacesInstancesListResultList: S.Schema<NamespacesInstancesListResultList>;
export interface ListNamespaceInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespaceInstancesResponse: S.Schema<ListNamespaceInstancesResponse>;
export interface ListNamespacesRequest {
    accountId: string;
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter namespaces whose name or description contains this string (case-insensitive). */
    search?: string;
}
export declare const ListNamespacesRequest: S.Schema<ListNamespacesRequest>;
export interface NamespacesListResultItem {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
}
export declare const NamespacesListResultItem: S.Schema<NamespacesListResultItem>;
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export declare const NamespacesListResultList: S.Schema<NamespacesListResultList>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespacesResponse: S.Schema<ListNamespacesResponse>;
export interface ListTokensRequest {
    accountId: string;
    /** Page number (1-indexed). */
    page?: number;
    /** Number of results per page. */
    perPage?: number;
    /** Filter tokens whose name contains this string (case-insensitive). */
    search?: string;
}
export declare const ListTokensRequest: S.Schema<ListTokensRequest>;
export interface TokensListResultItem {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export declare const TokensListResultItem: S.Schema<TokensListResultItem>;
export type TokensListResultList = Array<TokensListResultItem>;
export declare const TokensListResultList: S.Schema<TokensListResultList>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTokensResponse: S.Schema<ListTokensResponse>;
export interface LogsInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    page?: number;
    perPage?: number;
}
export declare const LogsInstanceJobRequest: S.Schema<LogsInstanceJobRequest>;
export interface InstancesJobsLogsResultItem {
    id: number;
    createdAt: number;
    message: string;
    messageType: number;
}
export declare const InstancesJobsLogsResultItem: S.Schema<InstancesJobsLogsResultItem>;
export type InstancesJobsLogsResultList = Array<InstancesJobsLogsResultItem>;
export declare const InstancesJobsLogsResultList: S.Schema<InstancesJobsLogsResultList>;
export type LogsInstanceJobResponse = InstancesJobsLogsResultList;
export declare const LogsInstanceJobResponse: S.Schema<LogsInstanceJobResponse>;
export interface LogsNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    cursor?: string;
    limit?: number;
}
export declare const LogsNamespaceInstanceItemRequest: S.Schema<LogsNamespaceInstanceItemRequest>;
export interface NamespacesInstancesItemsLogsResultItem {
    action: string;
    chunkCount: number;
    errorType: string;
    fileKey: string;
    message: string;
    processingTimeMs: number;
    timestamp: string;
}
export declare const NamespacesInstancesItemsLogsResultItem: S.Schema<NamespacesInstancesItemsLogsResultItem>;
export type NamespacesInstancesItemsLogsResultList = Array<NamespacesInstancesItemsLogsResultItem>;
export declare const NamespacesInstancesItemsLogsResultList: S.Schema<NamespacesInstancesItemsLogsResultList>;
export type LogsNamespaceInstanceItemResponse = NamespacesInstancesItemsLogsResultList;
export declare const LogsNamespaceInstanceItemResponse: S.Schema<LogsNamespaceInstanceItemResponse>;
export interface LogsNamespaceInstanceJobRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    page?: number;
    perPage?: number;
}
export declare const LogsNamespaceInstanceJobRequest: S.Schema<LogsNamespaceInstanceJobRequest>;
export type NamespacesInstancesJobsLogsResultItem = InstancesJobsLogsResultItem;
export declare const NamespacesInstancesJobsLogsResultItem: S.Schema<InstancesJobsLogsResultItem>;
export type NamespacesInstancesJobsLogsResultList = Array<InstancesJobsLogsResultItem>;
export declare const NamespacesInstancesJobsLogsResultList: S.Schema<NamespacesInstancesJobsLogsResultList>;
export type LogsNamespaceInstanceJobResponse = NamespacesInstancesJobsLogsResultList;
export declare const LogsNamespaceInstanceJobResponse: S.Schema<LogsNamespaceInstanceJobResponse>;
export type NamespacesInstancesJobsUpdateRequestAction = "cancel";
export declare const NamespacesInstancesJobsUpdateRequestAction: any;
export interface PatchNamespaceInstanceJobRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    action: NamespacesInstancesJobsUpdateRequestAction | (string & {});
}
export declare const PatchNamespaceInstanceJobRequest: S.Schema<PatchNamespaceInstanceJobRequest>;
export type NamespacesInstancesJobsUpdateResponseSource = "user" | "schedule";
export declare const NamespacesInstancesJobsUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsUpdateResponseSource;
    description?: string | null;
    endReason?: string | null;
    endedAt?: string | null;
    lastSeenAt?: string | null;
    startedAt?: string | null;
}
export declare const PatchNamespaceInstanceJobResponse: S.Schema<PatchNamespaceInstanceJobResponse>;
export interface ReadInstanceRequest {
    accountId: string;
    id: string;
}
export declare const ReadInstanceRequest: S.Schema<ReadInstanceRequest>;
export type InstancesReadResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesReadResponseAiSearchModel: any;
export type InstancesReadResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesReadResponseCacheThreshold: any;
export type InstancesReadResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesReadResponseCacheTtl: any;
export type InstancesReadResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesReadResponseCustomMetadataItemDataType: any;
export interface InstancesReadResponseCustomMetadataItem {
    dataType: InstancesReadResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const InstancesReadResponseCustomMetadataItem: S.Schema<InstancesReadResponseCustomMetadataItem>;
export type InstancesReadResponseCustomMetadataList = Array<InstancesReadResponseCustomMetadataItem>;
export declare const InstancesReadResponseCustomMetadataList: S.Schema<InstancesReadResponseCustomMetadataList>;
export type InstancesReadResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesReadResponseEmbeddingModel: any;
export type InstancesReadResponseFusionMethod = "max" | "rrf";
export declare const InstancesReadResponseFusionMethod: any;
export type InstancesReadResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const InstancesReadResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesReadResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesReadResponseIndexingOptionsKeywordTokenizer: any;
export interface InstancesReadResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesReadResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const InstancesReadResponseIndexingOptions: S.Schema<InstancesReadResponseIndexingOptions>;
export type InstancesReadResponseMetadata = InstancesCreateResponseMetadata;
export declare const InstancesReadResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type InstancesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesReadResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesReadResponsePublicEndpointParamsAuthorizedHostsList>;
export type InstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const InstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesReadResponsePublicEndpointParamsCustomDomainsList: S.Schema<InstancesReadResponsePublicEndpointParamsCustomDomainsList>;
export type InstancesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const InstancesReadResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type InstancesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesReadResponsePublicEndpointParamsRateLimitTechnique: any;
export interface InstancesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesReadResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const InstancesReadResponsePublicEndpointParamsRateLimit: S.Schema<InstancesReadResponsePublicEndpointParamsRateLimit>;
export type InstancesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const InstancesReadResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface InstancesReadResponsePublicEndpointParams {
    authorizedHosts?: InstancesReadResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesReadResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesReadResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const InstancesReadResponsePublicEndpointParams: S.Schema<InstancesReadResponsePublicEndpointParams>;
export type InstancesReadResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesReadResponseRerankingModel: any;
export type InstancesReadResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesReadResponseRetrievalOptionsBoostByItemDirection: any;
export interface InstancesReadResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesReadResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const InstancesReadResponseRetrievalOptionsBoostByItem: S.Schema<InstancesReadResponseRetrievalOptionsBoostByItem>;
export type InstancesReadResponseRetrievalOptionsBoostByList = Array<InstancesReadResponseRetrievalOptionsBoostByItem>;
export declare const InstancesReadResponseRetrievalOptionsBoostByList: S.Schema<InstancesReadResponseRetrievalOptionsBoostByList>;
export type InstancesReadResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesReadResponseRetrievalOptionsKeywordMatchMode: any;
export interface InstancesReadResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesReadResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesReadResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const InstancesReadResponseRetrievalOptions: S.Schema<InstancesReadResponseRetrievalOptions>;
export type InstancesReadResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesReadResponseRewriteModel: any;
export type InstancesReadResponseSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesReadResponseSourceParamsExcludeItemsList: S.Schema<InstancesReadResponseSourceParamsExcludeItemsList>;
export type InstancesReadResponseSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesReadResponseSourceParamsIncludeItemsList: S.Schema<InstancesReadResponseSourceParamsIncludeItemsList>;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesReadResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const InstancesReadResponseSourceParamsWebCrawlerParseOptions: S.Schema<InstancesReadResponseSourceParamsWebCrawlerParseOptions>;
export type InstancesReadResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesReadResponseSourceParamsWebCrawlerParseType: any;
export interface InstancesReadResponseSourceParamsWebCrawler {
    parseOptions?: InstancesReadResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: InstancesReadResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const InstancesReadResponseSourceParamsWebCrawler: S.Schema<InstancesReadResponseSourceParamsWebCrawler>;
export interface InstancesReadResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesReadResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesReadResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesReadResponseSourceParamsWebCrawler | null;
}
export declare const InstancesReadResponseSourceParams: S.Schema<InstancesReadResponseSourceParams>;
export type InstancesReadResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesReadResponseSyncInterval: any;
export type InstancesReadResponseType = "r2" | "web-crawler";
export declare const InstancesReadResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: InstancesReadResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesReadResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesReadResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesReadResponseCustomMetadataList | null;
    embeddingModel?: InstancesReadResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesReadResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesReadResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesReadResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: InstancesReadResponseRerankingModel | null;
    retrievalOptions?: InstancesReadResponseRetrievalOptions | null;
    rewriteModel?: InstancesReadResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesReadResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesReadResponseSyncInterval | null;
    tokenId?: string | null;
    type?: InstancesReadResponseType | null;
}
export declare const ReadInstanceResponse: S.Schema<ReadInstanceResponse>;
export interface ReadNamespaceRequest {
    accountId: string;
    name: string;
}
export declare const ReadNamespaceRequest: S.Schema<ReadNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
}
export declare const ReadNamespaceResponse: S.Schema<ReadNamespaceResponse>;
export interface ReadNamespaceInstanceRequest {
    accountId: string;
    name: string;
    id: string;
}
export declare const ReadNamespaceInstanceRequest: S.Schema<ReadNamespaceInstanceRequest>;
export type NamespacesInstancesReadResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesReadResponseAiSearchModel: any;
export type NamespacesInstancesReadResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesReadResponseCacheThreshold: any;
export type NamespacesInstancesReadResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesReadResponseCacheTtl: any;
export type NamespacesInstancesReadResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesReadResponseCustomMetadataItemDataType: any;
export interface NamespacesInstancesReadResponseCustomMetadataItem {
    dataType: NamespacesInstancesReadResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const NamespacesInstancesReadResponseCustomMetadataItem: S.Schema<NamespacesInstancesReadResponseCustomMetadataItem>;
export type NamespacesInstancesReadResponseCustomMetadataList = Array<NamespacesInstancesReadResponseCustomMetadataItem>;
export declare const NamespacesInstancesReadResponseCustomMetadataList: S.Schema<NamespacesInstancesReadResponseCustomMetadataList>;
export type NamespacesInstancesReadResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesReadResponseEmbeddingModel: any;
export type NamespacesInstancesReadResponseFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesReadResponseFusionMethod: any;
export type NamespacesInstancesReadResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesReadResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesReadResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const NamespacesInstancesReadResponseIndexingOptions: S.Schema<NamespacesInstancesReadResponseIndexingOptions>;
export type NamespacesInstancesReadResponseMetadata = InstancesCreateResponseMetadata;
export declare const NamespacesInstancesReadResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const NamespacesInstancesReadResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const NamespacesInstancesReadResponsePublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesReadResponsePublicEndpointParamsRateLimit>;
export type NamespacesInstancesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesReadResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesReadResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesReadResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const NamespacesInstancesReadResponsePublicEndpointParams: S.Schema<NamespacesInstancesReadResponsePublicEndpointParams>;
export type NamespacesInstancesReadResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesReadResponseRerankingModel: any;
export type NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesReadResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const NamespacesInstancesReadResponseRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesReadResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesReadResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesReadResponseRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesReadResponseRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesReadResponseRetrievalOptionsBoostByList>;
export type NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesReadResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesReadResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const NamespacesInstancesReadResponseRetrievalOptions: S.Schema<NamespacesInstancesReadResponseRetrievalOptions>;
export type NamespacesInstancesReadResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesReadResponseRewriteModel: any;
export type NamespacesInstancesReadResponseSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesReadResponseSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesReadResponseSourceParamsExcludeItemsList>;
export type NamespacesInstancesReadResponseSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesReadResponseSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesReadResponseSourceParamsIncludeItemsList>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesReadResponseSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const NamespacesInstancesReadResponseSourceParamsWebCrawler: S.Schema<NamespacesInstancesReadResponseSourceParamsWebCrawler>;
export interface NamespacesInstancesReadResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesReadResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesReadResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesReadResponseSourceParamsWebCrawler | null;
}
export declare const NamespacesInstancesReadResponseSourceParams: S.Schema<NamespacesInstancesReadResponseSourceParams>;
export type NamespacesInstancesReadResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesReadResponseSyncInterval: any;
export type NamespacesInstancesReadResponseType = "r2" | "web-crawler";
export declare const NamespacesInstancesReadResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: NamespacesInstancesReadResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesReadResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesReadResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesReadResponseCustomMetadataList | null;
    embeddingModel?: NamespacesInstancesReadResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesReadResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesReadResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesReadResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: NamespacesInstancesReadResponseRerankingModel | null;
    retrievalOptions?: NamespacesInstancesReadResponseRetrievalOptions | null;
    rewriteModel?: NamespacesInstancesReadResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesReadResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesReadResponseSyncInterval | null;
    tokenId?: string | null;
    type?: NamespacesInstancesReadResponseType | null;
}
export declare const ReadNamespaceInstanceResponse: S.Schema<ReadNamespaceInstanceResponse>;
export interface ReadTokenRequest {
    accountId: string;
    id: string;
}
export declare const ReadTokenRequest: S.Schema<ReadTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export declare const ReadTokenResponse: S.Schema<ReadTokenResponse>;
export type InstancesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesSearchRequestAiSearchOptionsCacheCacheThreshold: any;
export interface InstancesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: InstancesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export declare const InstancesSearchRequestAiSearchOptionsCache: S.Schema<InstancesSearchRequestAiSearchOptionsCache>;
export type InstancesSearchRequestAiSearchOptionsQueryRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesSearchRequestAiSearchOptionsQueryRewriteModel: any;
export interface InstancesSearchRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    model?: InstancesSearchRequestAiSearchOptionsQueryRewriteModel | (string & {});
    rewritePrompt?: string;
}
export declare const InstancesSearchRequestAiSearchOptionsQueryRewrite: S.Schema<InstancesSearchRequestAiSearchOptionsQueryRewrite>;
export type InstancesSearchRequestAiSearchOptionsRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesSearchRequestAiSearchOptionsRerankingModel: any;
export interface InstancesSearchRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: InstancesSearchRequestAiSearchOptionsRerankingModel | (string & {});
}
export declare const InstancesSearchRequestAiSearchOptionsReranking: S.Schema<InstancesSearchRequestAiSearchOptionsReranking>;
export type InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection: any;
export interface InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export declare const InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem: S.Schema<InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type InstancesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export declare const InstancesSearchRequestAiSearchOptionsRetrievalBoostByList: S.Schema<InstancesSearchRequestAiSearchOptionsRetrievalBoostByList>;
export type InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export declare const InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap: S.Schema<InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap>;
export type InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export declare const InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod: any;
export type InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export declare const InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode: any;
export type InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export declare const InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType: any;
export interface InstancesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesSearchRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    matchThreshold?: number;
    maxNumResults?: number;
    retrievalType?: InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export declare const InstancesSearchRequestAiSearchOptionsRetrieval: S.Schema<InstancesSearchRequestAiSearchOptionsRetrieval>;
export interface InstancesSearchRequestAiSearchOptions {
    cache?: InstancesSearchRequestAiSearchOptionsCache;
    queryRewrite?: InstancesSearchRequestAiSearchOptionsQueryRewrite;
    reranking?: InstancesSearchRequestAiSearchOptionsReranking;
    retrieval?: InstancesSearchRequestAiSearchOptionsRetrieval;
}
export declare const InstancesSearchRequestAiSearchOptions: S.Schema<InstancesSearchRequestAiSearchOptions>;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export declare const InstancesSearchRequestMessagesItemContentCase1ItemCase0Type: any;
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export declare const InstancesSearchRequestMessagesItemContentCase1ItemCase0: S.Schema<InstancesSearchRequestMessagesItemContentCase1ItemCase0>;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const InstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export declare const InstancesSearchRequestMessagesItemContentCase1ItemCase1Type: any;
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export declare const InstancesSearchRequestMessagesItemContentCase1ItemCase1: S.Schema<InstancesSearchRequestMessagesItemContentCase1ItemCase1>;
export type InstancesSearchRequestMessagesItemContentCase1Item = InstancesSearchRequestMessagesItemContentCase1ItemCase0 | InstancesSearchRequestMessagesItemContentCase1ItemCase1;
export declare const InstancesSearchRequestMessagesItemContentCase1Item: any;
export type InstancesSearchRequestMessagesItemContentCase1List = Array<InstancesSearchRequestMessagesItemContentCase1Item>;
export declare const InstancesSearchRequestMessagesItemContentCase1List: S.Schema<InstancesSearchRequestMessagesItemContentCase1List>;
export type InstancesSearchRequestMessagesItemContent = string | InstancesSearchRequestMessagesItemContentCase1List;
export declare const InstancesSearchRequestMessagesItemContent: any;
export type InstancesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const InstancesSearchRequestMessagesItemRole: any;
export interface InstancesSearchRequestMessagesItem {
    content: InstancesSearchRequestMessagesItemContent;
    role: InstancesSearchRequestMessagesItemRole | (string & {});
}
export declare const InstancesSearchRequestMessagesItem: S.Schema<InstancesSearchRequestMessagesItem>;
export type InstancesSearchRequestMessagesList = Array<InstancesSearchRequestMessagesItem>;
export declare const InstancesSearchRequestMessagesList: S.Schema<InstancesSearchRequestMessagesList>;
export interface SearchInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiSearchOptions?: InstancesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'…'}, {type:'image_url', image_url:{url:'…'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: InstancesSearchRequestMessagesList;
    /** A simple text query string. Alternative to 'messages' — provide either this or 'messages', not both. */
    query?: string;
}
export declare const SearchInstanceRequest: S.Schema<SearchInstanceRequest>;
export type InstancesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const InstancesSearchResponseChunksItemItemMetadataMap: S.Schema<InstancesSearchResponseChunksItemItemMetadataMap>;
export interface InstancesSearchResponseChunksItemItem {
    key: string;
    metadata?: InstancesSearchResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const InstancesSearchResponseChunksItemItem: S.Schema<InstancesSearchResponseChunksItemItem>;
export type InstancesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export declare const InstancesSearchResponseChunksItemScoringDetailsFusionMethod: any;
export interface InstancesSearchResponseChunksItemScoringDetails {
    fusionMethod?: InstancesSearchResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export declare const InstancesSearchResponseChunksItemScoringDetails: S.Schema<InstancesSearchResponseChunksItemScoringDetails>;
export interface InstancesSearchResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: InstancesSearchResponseChunksItemItem | null;
    scoringDetails?: InstancesSearchResponseChunksItemScoringDetails | null;
}
export declare const InstancesSearchResponseChunksItem: S.Schema<InstancesSearchResponseChunksItem>;
export type InstancesSearchResponseChunksList = Array<InstancesSearchResponseChunksItem>;
export declare const InstancesSearchResponseChunksList: S.Schema<InstancesSearchResponseChunksList>;
export type InstancesSearchResponseQueryKind = "text" | "image" | "multimodal";
export declare const InstancesSearchResponseQueryKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchInstanceResponse {
    chunks: InstancesSearchResponseChunksList;
    queryKind: InstancesSearchResponseQueryKind;
    searchQuery?: string | null;
}
export declare const SearchInstanceResponse: S.Schema<SearchInstanceResponse>;
export type NamespacesSearchRequestAiSearchOptionsInstanceIdsList = Array<string>;
export declare const NamespacesSearchRequestAiSearchOptionsInstanceIdsList: S.Schema<NamespacesSearchRequestAiSearchOptionsInstanceIdsList>;
export type NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold: any;
export interface NamespacesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export declare const NamespacesSearchRequestAiSearchOptionsCache: S.Schema<NamespacesSearchRequestAiSearchOptionsCache>;
export type NamespacesSearchRequestAiSearchOptionsQueryRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesSearchRequestAiSearchOptionsQueryRewriteModel: any;
export interface NamespacesSearchRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    model?: NamespacesSearchRequestAiSearchOptionsQueryRewriteModel | (string & {});
    rewritePrompt?: string;
}
export declare const NamespacesSearchRequestAiSearchOptionsQueryRewrite: S.Schema<NamespacesSearchRequestAiSearchOptionsQueryRewrite>;
export type NamespacesSearchRequestAiSearchOptionsRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesSearchRequestAiSearchOptionsRerankingModel: any;
export interface NamespacesSearchRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: NamespacesSearchRequestAiSearchOptionsRerankingModel | (string & {});
}
export declare const NamespacesSearchRequestAiSearchOptionsReranking: S.Schema<NamespacesSearchRequestAiSearchOptionsReranking>;
export type NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection: any;
export interface NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem: S.Schema<NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList: S.Schema<NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList>;
export type NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap: S.Schema<NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap>;
export type NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod: any;
export type NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode: any;
export type NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export declare const NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType: any;
export interface NamespacesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    matchThreshold?: number;
    maxNumResults?: number;
    retrievalType?: NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export declare const NamespacesSearchRequestAiSearchOptionsRetrieval: S.Schema<NamespacesSearchRequestAiSearchOptionsRetrieval>;
export interface NamespacesSearchRequestAiSearchOptions {
    instanceIds: NamespacesSearchRequestAiSearchOptionsInstanceIdsList;
    cache?: NamespacesSearchRequestAiSearchOptionsCache;
    queryRewrite?: NamespacesSearchRequestAiSearchOptionsQueryRewrite;
    reranking?: NamespacesSearchRequestAiSearchOptionsReranking;
    retrieval?: NamespacesSearchRequestAiSearchOptionsRetrieval;
}
export declare const NamespacesSearchRequestAiSearchOptions: S.Schema<NamespacesSearchRequestAiSearchOptions>;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export declare const NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type: any;
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export declare const NamespacesSearchRequestMessagesItemContentCase1ItemCase0: S.Schema<NamespacesSearchRequestMessagesItemContentCase1ItemCase0>;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const NamespacesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export declare const NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type: any;
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export declare const NamespacesSearchRequestMessagesItemContentCase1ItemCase1: S.Schema<NamespacesSearchRequestMessagesItemContentCase1ItemCase1>;
export type NamespacesSearchRequestMessagesItemContentCase1Item = NamespacesSearchRequestMessagesItemContentCase1ItemCase0 | NamespacesSearchRequestMessagesItemContentCase1ItemCase1;
export declare const NamespacesSearchRequestMessagesItemContentCase1Item: any;
export type NamespacesSearchRequestMessagesItemContentCase1List = Array<NamespacesSearchRequestMessagesItemContentCase1Item>;
export declare const NamespacesSearchRequestMessagesItemContentCase1List: S.Schema<NamespacesSearchRequestMessagesItemContentCase1List>;
export type NamespacesSearchRequestMessagesItemContent = string | NamespacesSearchRequestMessagesItemContentCase1List;
export declare const NamespacesSearchRequestMessagesItemContent: any;
export type NamespacesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const NamespacesSearchRequestMessagesItemRole: any;
export interface NamespacesSearchRequestMessagesItem {
    content: NamespacesSearchRequestMessagesItemContent;
    role: NamespacesSearchRequestMessagesItemRole | (string & {});
}
export declare const NamespacesSearchRequestMessagesItem: S.Schema<NamespacesSearchRequestMessagesItem>;
export type NamespacesSearchRequestMessagesList = Array<NamespacesSearchRequestMessagesItem>;
export declare const NamespacesSearchRequestMessagesList: S.Schema<NamespacesSearchRequestMessagesList>;
export interface SearchNamespaceRequest {
    accountId: string;
    name: string;
    aiSearchOptions: NamespacesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'…'}, {type:'image_url', image_url:{url:'…'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: NamespacesSearchRequestMessagesList;
    /** A simple text query string. Alternative to 'messages' — provide either this or 'messages', not both. */
    query?: string;
}
export declare const SearchNamespaceRequest: S.Schema<SearchNamespaceRequest>;
export type NamespacesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesSearchResponseChunksItemItemMetadataMap: S.Schema<NamespacesSearchResponseChunksItemItemMetadataMap>;
export interface NamespacesSearchResponseChunksItemItem {
    key: string;
    metadata?: NamespacesSearchResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const NamespacesSearchResponseChunksItemItem: S.Schema<NamespacesSearchResponseChunksItemItem>;
export type NamespacesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export declare const NamespacesSearchResponseChunksItemScoringDetailsFusionMethod: any;
export interface NamespacesSearchResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesSearchResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export declare const NamespacesSearchResponseChunksItemScoringDetails: S.Schema<NamespacesSearchResponseChunksItemScoringDetails>;
export interface NamespacesSearchResponseChunksItem {
    id: string;
    instanceId: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesSearchResponseChunksItemItem | null;
    scoringDetails?: NamespacesSearchResponseChunksItemScoringDetails | null;
}
export declare const NamespacesSearchResponseChunksItem: S.Schema<NamespacesSearchResponseChunksItem>;
export type NamespacesSearchResponseChunksList = Array<NamespacesSearchResponseChunksItem>;
export declare const NamespacesSearchResponseChunksList: S.Schema<NamespacesSearchResponseChunksList>;
export type NamespacesSearchResponseQueryKind = "text" | "image" | "multimodal";
export declare const NamespacesSearchResponseQueryKind: any;
export interface NamespacesSearchResponseErrorsItem {
    instanceId: string;
    message: string;
}
export declare const NamespacesSearchResponseErrorsItem: S.Schema<NamespacesSearchResponseErrorsItem>;
export type NamespacesSearchResponseErrorsList = Array<NamespacesSearchResponseErrorsItem>;
export declare const NamespacesSearchResponseErrorsList: S.Schema<NamespacesSearchResponseErrorsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchNamespaceResponse {
    chunks: NamespacesSearchResponseChunksList;
    queryKind: NamespacesSearchResponseQueryKind;
    errors?: NamespacesSearchResponseErrorsList | null;
    searchQuery?: string | null;
}
export declare const SearchNamespaceResponse: S.Schema<SearchNamespaceResponse>;
export type NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold: any;
export interface NamespacesInstancesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {});
    enabled?: boolean;
}
export declare const NamespacesInstancesSearchRequestAiSearchOptionsCache: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsCache>;
export type NamespacesInstancesSearchRequestAiSearchOptionsQueryRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsQueryRewriteModel: any;
export interface NamespacesInstancesSearchRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean;
    model?: NamespacesInstancesSearchRequestAiSearchOptionsQueryRewriteModel | (string & {});
    rewritePrompt?: string;
}
export declare const NamespacesInstancesSearchRequestAiSearchOptionsQueryRewrite: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsQueryRewrite>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRerankingModel: any;
export interface NamespacesInstancesSearchRequestAiSearchOptionsReranking {
    enabled?: boolean;
    matchThreshold?: number;
    model?: NamespacesInstancesSearchRequestAiSearchOptionsRerankingModel | (string & {});
}
export declare const NamespacesInstancesSearchRequestAiSearchOptionsReranking: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsReranking>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection: any;
export interface NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {});
}
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod: any;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode: any;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType: any;
export interface NamespacesInstancesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList;
    contextExpansion?: number;
    filters?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap;
    fusionMethod?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {});
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {});
    matchThreshold?: number;
    maxNumResults?: number;
    retrievalType?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {});
    returnOnFailure?: boolean;
}
export declare const NamespacesInstancesSearchRequestAiSearchOptionsRetrieval: S.Schema<NamespacesInstancesSearchRequestAiSearchOptionsRetrieval>;
export interface NamespacesInstancesSearchRequestAiSearchOptions {
    cache?: NamespacesInstancesSearchRequestAiSearchOptionsCache;
    queryRewrite?: NamespacesInstancesSearchRequestAiSearchOptionsQueryRewrite;
    reranking?: NamespacesInstancesSearchRequestAiSearchOptionsReranking;
    retrieval?: NamespacesInstancesSearchRequestAiSearchOptionsRetrieval;
}
export declare const NamespacesInstancesSearchRequestAiSearchOptions: S.Schema<NamespacesInstancesSearchRequestAiSearchOptions>;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type: any;
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0: S.Schema<NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0>;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl: S.Schema<InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl>;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type: any;
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1: S.Schema<NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1>;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1Item = NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0 | NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1;
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1Item: any;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1List = Array<NamespacesInstancesSearchRequestMessagesItemContentCase1Item>;
export declare const NamespacesInstancesSearchRequestMessagesItemContentCase1List: S.Schema<NamespacesInstancesSearchRequestMessagesItemContentCase1List>;
export type NamespacesInstancesSearchRequestMessagesItemContent = string | NamespacesInstancesSearchRequestMessagesItemContentCase1List;
export declare const NamespacesInstancesSearchRequestMessagesItemContent: any;
export type NamespacesInstancesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export declare const NamespacesInstancesSearchRequestMessagesItemRole: any;
export interface NamespacesInstancesSearchRequestMessagesItem {
    content: NamespacesInstancesSearchRequestMessagesItemContent;
    role: NamespacesInstancesSearchRequestMessagesItemRole | (string & {});
}
export declare const NamespacesInstancesSearchRequestMessagesItem: S.Schema<NamespacesInstancesSearchRequestMessagesItem>;
export type NamespacesInstancesSearchRequestMessagesList = Array<NamespacesInstancesSearchRequestMessagesItem>;
export declare const NamespacesInstancesSearchRequestMessagesList: S.Schema<NamespacesInstancesSearchRequestMessagesList>;
export interface SearchNamespaceInstanceRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiSearchOptions?: NamespacesInstancesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'…'}, {type:'image_url', image_url:{url:'…'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: NamespacesInstancesSearchRequestMessagesList;
    /** A simple text query string. Alternative to 'messages' — provide either this or 'messages', not both. */
    query?: string;
}
export declare const SearchNamespaceInstanceRequest: S.Schema<SearchNamespaceInstanceRequest>;
export type NamespacesInstancesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesSearchResponseChunksItemItemMetadataMap: S.Schema<NamespacesInstancesSearchResponseChunksItemItemMetadataMap>;
export interface NamespacesInstancesSearchResponseChunksItemItem {
    key: string;
    metadata?: NamespacesInstancesSearchResponseChunksItemItemMetadataMap | null;
    timestamp?: number | null;
}
export declare const NamespacesInstancesSearchResponseChunksItemItem: S.Schema<NamespacesInstancesSearchResponseChunksItemItem>;
export type NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export declare const NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod: any;
export interface NamespacesInstancesSearchResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod | null;
    keywordRank?: number | null;
    keywordScore?: number | null;
    rerankingScore?: number | null;
    vectorRank?: number | null;
    vectorScore?: number | null;
}
export declare const NamespacesInstancesSearchResponseChunksItemScoringDetails: S.Schema<NamespacesInstancesSearchResponseChunksItemScoringDetails>;
export interface NamespacesInstancesSearchResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesInstancesSearchResponseChunksItemItem | null;
    scoringDetails?: NamespacesInstancesSearchResponseChunksItemScoringDetails | null;
}
export declare const NamespacesInstancesSearchResponseChunksItem: S.Schema<NamespacesInstancesSearchResponseChunksItem>;
export type NamespacesInstancesSearchResponseChunksList = Array<NamespacesInstancesSearchResponseChunksItem>;
export declare const NamespacesInstancesSearchResponseChunksList: S.Schema<NamespacesInstancesSearchResponseChunksList>;
export type NamespacesInstancesSearchResponseQueryKind = "text" | "image" | "multimodal";
export declare const NamespacesInstancesSearchResponseQueryKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchNamespaceInstanceResponse {
    chunks: NamespacesInstancesSearchResponseChunksList;
    queryKind: NamespacesInstancesSearchResponseQueryKind;
    searchQuery?: string | null;
}
export declare const SearchNamespaceInstanceResponse: S.Schema<SearchNamespaceInstanceResponse>;
export interface StatsInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export declare const StatsInstanceRequest: S.Schema<StatsInstanceRequest>;
export interface InstancesStatsResponseEngineR2 {
    metadataSizeBytes: number;
    objectCount: number;
    payloadSizeBytes: number;
}
export declare const InstancesStatsResponseEngineR2: S.Schema<InstancesStatsResponseEngineR2>;
export interface InstancesStatsResponseEngineVectorize {
    dimensions: number;
    vectorsCount: number;
}
export declare const InstancesStatsResponseEngineVectorize: S.Schema<InstancesStatsResponseEngineVectorize>;
export interface InstancesStatsResponseEngine {
    /** R2 bucket storage usage in bytes. */
    r2?: InstancesStatsResponseEngineR2 | null;
    /** Vectorize index metadata (dimensions, vector count). */
    vectorize?: InstancesStatsResponseEngineVectorize | null;
}
export declare const InstancesStatsResponseEngine: S.Schema<InstancesStatsResponseEngine>;
export type InstancesStatsResponseFileEmbedErrorsMap = {
    [key: string]: unknown | undefined;
};
export declare const InstancesStatsResponseFileEmbedErrorsMap: S.Schema<InstancesStatsResponseFileEmbedErrorsMap>;
export type InstancesStatsResponseIndexSourceErrorsMap = {
    [key: string]: unknown | undefined;
};
export declare const InstancesStatsResponseIndexSourceErrorsMap: S.Schema<InstancesStatsResponseIndexSourceErrorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatsInstanceResponse {
    completed?: number | null;
    /** True when status counts are unavailable (e.g. legacy stats query exceeded D1 statement-size limit). Counts are omitted in this case. */
    degraded?: boolean | null;
    /** Engine-specific metadata. Present only for managed (v3) instances. */
    engine?: InstancesStatsResponseEngine | null;
    error?: number | null;
    fileEmbedErrors?: InstancesStatsResponseFileEmbedErrorsMap | null;
    indexSourceErrors?: InstancesStatsResponseIndexSourceErrorsMap | null;
    lastActivity?: string | null;
    outdated?: number | null;
    queued?: number | null;
    running?: number | null;
    skipped?: number | null;
}
export declare const StatsInstanceResponse: S.Schema<StatsInstanceResponse>;
export interface StatsNamespaceInstanceRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export declare const StatsNamespaceInstanceRequest: S.Schema<StatsNamespaceInstanceRequest>;
export type NamespacesInstancesStatsResponseEngineR2 = InstancesStatsResponseEngineR2;
export declare const NamespacesInstancesStatsResponseEngineR2: S.Schema<InstancesStatsResponseEngineR2>;
export type NamespacesInstancesStatsResponseEngineVectorize = InstancesStatsResponseEngineVectorize;
export declare const NamespacesInstancesStatsResponseEngineVectorize: S.Schema<InstancesStatsResponseEngineVectorize>;
export type NamespacesInstancesStatsResponseEngine = InstancesStatsResponseEngine;
export declare const NamespacesInstancesStatsResponseEngine: S.Schema<InstancesStatsResponseEngine>;
export type NamespacesInstancesStatsResponseFileEmbedErrorsMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesStatsResponseFileEmbedErrorsMap: S.Schema<NamespacesInstancesStatsResponseFileEmbedErrorsMap>;
export type NamespacesInstancesStatsResponseIndexSourceErrorsMap = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesInstancesStatsResponseIndexSourceErrorsMap: S.Schema<NamespacesInstancesStatsResponseIndexSourceErrorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatsNamespaceInstanceResponse {
    completed?: number | null;
    /** True when status counts are unavailable (e.g. legacy stats query exceeded D1 statement-size limit). Counts are omitted in this case. */
    degraded?: boolean | null;
    /** Engine-specific metadata. Present only for managed (v3) instances. */
    engine?: InstancesStatsResponseEngine | null;
    error?: number | null;
    fileEmbedErrors?: NamespacesInstancesStatsResponseFileEmbedErrorsMap | null;
    indexSourceErrors?: NamespacesInstancesStatsResponseIndexSourceErrorsMap | null;
    lastActivity?: string | null;
    outdated?: number | null;
    queued?: number | null;
    running?: number | null;
    skipped?: number | null;
}
export declare const StatsNamespaceInstanceResponse: S.Schema<StatsNamespaceInstanceResponse>;
export type NamespacesInstancesItemsSyncRequestNextAction = "INDEX";
export declare const NamespacesInstancesItemsSyncRequestNextAction: any;
export interface SyncNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    nextAction: NamespacesInstancesItemsSyncRequestNextAction | (string & {});
    /** Wait for indexing to fully complete before responding. On RAGs with vector indexing enabled, this additionally waits for Vectorize ingestion confirmation (up to 40s) so the returned item reflects a queryable state. On timeout the item is returned in `running` state and the background alarm continues polling. Defaults to false. */
    waitForCompletion?: boolean;
}
export declare const SyncNamespaceInstanceItemRequest: S.Schema<SyncNamespaceInstanceItemRequest>;
export type NamespacesInstancesItemsSyncResponseNextAction = "INDEX" | "DELETE";
export declare const NamespacesInstancesItemsSyncResponseNextAction: any;
export type NamespacesInstancesItemsSyncResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export declare const NamespacesInstancesItemsSyncResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SyncNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    namespace: string;
    nextAction: NamespacesInstancesItemsSyncResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsSyncResponseStatus;
    error?: string | null;
}
export declare const SyncNamespaceInstanceItemResponse: S.Schema<SyncNamespaceInstanceItemResponse>;
export type InstancesUpdateRequestAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesUpdateRequestAiSearchModel: any;
export type InstancesUpdateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesUpdateRequestCacheThreshold: any;
export type InstancesUpdateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesUpdateRequestCacheTtl: any;
export type InstancesUpdateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesUpdateRequestCustomMetadataItemDataType: any;
export interface InstancesUpdateRequestCustomMetadataItem {
    dataType: InstancesUpdateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export declare const InstancesUpdateRequestCustomMetadataItem: S.Schema<InstancesUpdateRequestCustomMetadataItem>;
export type InstancesUpdateRequestCustomMetadataList = Array<InstancesUpdateRequestCustomMetadataItem>;
export declare const InstancesUpdateRequestCustomMetadataList: S.Schema<InstancesUpdateRequestCustomMetadataList>;
export type InstancesUpdateRequestEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesUpdateRequestEmbeddingModel: any;
export type InstancesUpdateRequestFusionMethod = "max" | "rrf";
export declare const InstancesUpdateRequestFusionMethod: any;
export type InstancesUpdateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export declare const InstancesUpdateRequestIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesUpdateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesUpdateRequestIndexingOptionsKeywordTokenizer: any;
export interface InstancesUpdateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesUpdateRequestIndexingOptionsKeywordTokenizer | (string & {});
}
export declare const InstancesUpdateRequestIndexingOptions: S.Schema<InstancesUpdateRequestIndexingOptions>;
export type InstancesUpdateRequestMetadata = InstancesCreateRequestMetadata;
export declare const InstancesUpdateRequestMetadata: S.Schema<InstancesCreateRequestMetadata>;
export type InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList>;
export type InstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export declare const InstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesUpdateRequestPublicEndpointParamsCustomDomainsList: S.Schema<InstancesUpdateRequestPublicEndpointParamsCustomDomainsList>;
export type InstancesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export declare const InstancesUpdateRequestPublicEndpointParamsMcp: S.Schema<InstancesCreateRequestPublicEndpointParamsMcp>;
export type InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique: any;
export interface InstancesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export declare const InstancesUpdateRequestPublicEndpointParamsRateLimit: S.Schema<InstancesUpdateRequestPublicEndpointParamsRateLimit>;
export type InstancesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export declare const InstancesUpdateRequestPublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsSearchEndpoint>;
export interface InstancesUpdateRequestPublicEndpointParams {
    authorizedHosts?: InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesUpdateRequestPublicEndpointParamsCustomDomainsList;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: InstancesUpdateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export declare const InstancesUpdateRequestPublicEndpointParams: S.Schema<InstancesUpdateRequestPublicEndpointParams>;
export type InstancesUpdateRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesUpdateRequestRerankingModel: any;
export type InstancesUpdateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesUpdateRequestRetrievalOptionsBoostByItemDirection: any;
export interface InstancesUpdateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesUpdateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export declare const InstancesUpdateRequestRetrievalOptionsBoostByItem: S.Schema<InstancesUpdateRequestRetrievalOptionsBoostByItem>;
export type InstancesUpdateRequestRetrievalOptionsBoostByList = Array<InstancesUpdateRequestRetrievalOptionsBoostByItem>;
export declare const InstancesUpdateRequestRetrievalOptionsBoostByList: S.Schema<InstancesUpdateRequestRetrievalOptionsBoostByList>;
export type InstancesUpdateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesUpdateRequestRetrievalOptionsKeywordMatchMode: any;
export interface InstancesUpdateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesUpdateRequestRetrievalOptionsBoostByList;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesUpdateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export declare const InstancesUpdateRequestRetrievalOptions: S.Schema<InstancesUpdateRequestRetrievalOptions>;
export type InstancesUpdateRequestRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesUpdateRequestRewriteModel: any;
export type InstancesUpdateRequestSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesUpdateRequestSourceParamsExcludeItemsList: S.Schema<InstancesUpdateRequestSourceParamsExcludeItemsList>;
export type InstancesUpdateRequestSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesUpdateRequestSourceParamsIncludeItemsList: S.Schema<InstancesUpdateRequestSourceParamsIncludeItemsList>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesUpdateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export declare const InstancesUpdateRequestSourceParamsWebCrawlerParseOptions: S.Schema<InstancesUpdateRequestSourceParamsWebCrawlerParseOptions>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesUpdateRequestSourceParamsWebCrawlerParseType: any;
export interface InstancesUpdateRequestSourceParamsWebCrawler {
    parseOptions?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptions;
    parseType?: InstancesUpdateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export declare const InstancesUpdateRequestSourceParamsWebCrawler: S.Schema<InstancesUpdateRequestSourceParamsWebCrawler>;
export interface InstancesUpdateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesUpdateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesUpdateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: InstancesUpdateRequestSourceParamsWebCrawler;
}
export declare const InstancesUpdateRequestSourceParams: S.Schema<InstancesUpdateRequestSourceParams>;
export type InstancesUpdateRequestSummarizationModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesUpdateRequestSummarizationModel: any;
export type InstancesUpdateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesUpdateRequestSyncInterval: any;
export interface UpdateInstanceRequest {
    accountId: string;
    id: string;
    aiGatewayId?: string;
    aiSearchModel?: InstancesUpdateRequestAiSearchModel | (string & {});
    cache?: boolean;
    cacheThreshold?: InstancesUpdateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesUpdateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: InstancesUpdateRequestCustomMetadataList;
    embeddingModel?: InstancesUpdateRequestEmbeddingModel | (string & {});
    fusionMethod?: InstancesUpdateRequestFusionMethod | (string & {});
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: InstancesUpdateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: InstancesCreateRequestMetadata;
    paused?: boolean;
    publicEndpointParams?: InstancesUpdateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: InstancesUpdateRequestRerankingModel | (string & {});
    retrievalOptions?: InstancesUpdateRequestRetrievalOptions;
    rewriteModel?: InstancesUpdateRequestRewriteModel | (string & {});
    rewriteQuery?: boolean;
    scoreThreshold?: number;
    source?: string;
    sourceParams?: InstancesUpdateRequestSourceParams;
    summarization?: boolean;
    summarizationModel?: InstancesUpdateRequestSummarizationModel | (string & {});
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesUpdateRequestSyncInterval | (number & {});
    systemPromptAiSearch?: string;
    systemPromptIndexSummarization?: string;
    systemPromptRewriteQuery?: string;
    tokenId?: string;
}
export declare const UpdateInstanceRequest: S.Schema<UpdateInstanceRequest>;
export type InstancesUpdateResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesUpdateResponseAiSearchModel: any;
export type InstancesUpdateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const InstancesUpdateResponseCacheThreshold: any;
export type InstancesUpdateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const InstancesUpdateResponseCacheTtl: any;
export type InstancesUpdateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const InstancesUpdateResponseCustomMetadataItemDataType: any;
export interface InstancesUpdateResponseCustomMetadataItem {
    dataType: InstancesUpdateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const InstancesUpdateResponseCustomMetadataItem: S.Schema<InstancesUpdateResponseCustomMetadataItem>;
export type InstancesUpdateResponseCustomMetadataList = Array<InstancesUpdateResponseCustomMetadataItem>;
export declare const InstancesUpdateResponseCustomMetadataList: S.Schema<InstancesUpdateResponseCustomMetadataList>;
export type InstancesUpdateResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const InstancesUpdateResponseEmbeddingModel: any;
export type InstancesUpdateResponseFusionMethod = "max" | "rrf";
export declare const InstancesUpdateResponseFusionMethod: any;
export type InstancesUpdateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const InstancesUpdateResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type InstancesUpdateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const InstancesUpdateResponseIndexingOptionsKeywordTokenizer: any;
export interface InstancesUpdateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesUpdateResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const InstancesUpdateResponseIndexingOptions: S.Schema<InstancesUpdateResponseIndexingOptions>;
export type InstancesUpdateResponseMetadata = InstancesCreateResponseMetadata;
export declare const InstancesUpdateResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList>;
export type InstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const InstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type InstancesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const InstancesUpdateResponsePublicEndpointParamsCustomDomainsList: S.Schema<InstancesUpdateResponsePublicEndpointParamsCustomDomainsList>;
export type InstancesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const InstancesUpdateResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique: any;
export interface InstancesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const InstancesUpdateResponsePublicEndpointParamsRateLimit: S.Schema<InstancesUpdateResponsePublicEndpointParamsRateLimit>;
export type InstancesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const InstancesUpdateResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface InstancesUpdateResponsePublicEndpointParams {
    authorizedHosts?: InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesUpdateResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: InstancesUpdateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const InstancesUpdateResponsePublicEndpointParams: S.Schema<InstancesUpdateResponsePublicEndpointParams>;
export type InstancesUpdateResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const InstancesUpdateResponseRerankingModel: any;
export type InstancesUpdateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const InstancesUpdateResponseRetrievalOptionsBoostByItemDirection: any;
export interface InstancesUpdateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesUpdateResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const InstancesUpdateResponseRetrievalOptionsBoostByItem: S.Schema<InstancesUpdateResponseRetrievalOptionsBoostByItem>;
export type InstancesUpdateResponseRetrievalOptionsBoostByList = Array<InstancesUpdateResponseRetrievalOptionsBoostByItem>;
export declare const InstancesUpdateResponseRetrievalOptionsBoostByList: S.Schema<InstancesUpdateResponseRetrievalOptionsBoostByList>;
export type InstancesUpdateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const InstancesUpdateResponseRetrievalOptionsKeywordMatchMode: any;
export interface InstancesUpdateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesUpdateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: InstancesUpdateResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const InstancesUpdateResponseRetrievalOptions: S.Schema<InstancesUpdateResponseRetrievalOptions>;
export type InstancesUpdateResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const InstancesUpdateResponseRewriteModel: any;
export type InstancesUpdateResponseSourceParamsExcludeItemsList = Array<string>;
export declare const InstancesUpdateResponseSourceParamsExcludeItemsList: S.Schema<InstancesUpdateResponseSourceParamsExcludeItemsList>;
export type InstancesUpdateResponseSourceParamsIncludeItemsList = Array<string>;
export declare const InstancesUpdateResponseSourceParamsIncludeItemsList: S.Schema<InstancesUpdateResponseSourceParamsIncludeItemsList>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface InstancesUpdateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const InstancesUpdateResponseSourceParamsWebCrawlerParseOptions: S.Schema<InstancesUpdateResponseSourceParamsWebCrawlerParseOptions>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const InstancesUpdateResponseSourceParamsWebCrawlerParseType: any;
export interface InstancesUpdateResponseSourceParamsWebCrawler {
    parseOptions?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: InstancesUpdateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const InstancesUpdateResponseSourceParamsWebCrawler: S.Schema<InstancesUpdateResponseSourceParamsWebCrawler>;
export interface InstancesUpdateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: InstancesUpdateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: InstancesUpdateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: InstancesUpdateResponseSourceParamsWebCrawler | null;
}
export declare const InstancesUpdateResponseSourceParams: S.Schema<InstancesUpdateResponseSourceParams>;
export type InstancesUpdateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const InstancesUpdateResponseSyncInterval: any;
export type InstancesUpdateResponseType = "r2" | "web-crawler";
export declare const InstancesUpdateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: InstancesUpdateResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: InstancesUpdateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesUpdateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: InstancesUpdateResponseCustomMetadataList | null;
    embeddingModel?: InstancesUpdateResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: InstancesUpdateResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: InstancesUpdateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: InstancesUpdateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: InstancesUpdateResponseRerankingModel | null;
    retrievalOptions?: InstancesUpdateResponseRetrievalOptions | null;
    rewriteModel?: InstancesUpdateResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: InstancesUpdateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: InstancesUpdateResponseSyncInterval | null;
    tokenId?: string | null;
    type?: InstancesUpdateResponseType | null;
}
export declare const UpdateInstanceResponse: S.Schema<UpdateInstanceResponse>;
export interface UpdateNamespaceRequest {
    accountId: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
}
export declare const UpdateNamespaceRequest: S.Schema<UpdateNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null;
}
export declare const UpdateNamespaceResponse: S.Schema<UpdateNamespaceResponse>;
export type NamespacesInstancesUpdateRequestAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesUpdateRequestAiSearchModel: any;
export type NamespacesInstancesUpdateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesUpdateRequestCacheThreshold: any;
export type NamespacesInstancesUpdateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesUpdateRequestCacheTtl: any;
export type NamespacesInstancesUpdateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesUpdateRequestCustomMetadataItemDataType: any;
export interface NamespacesInstancesUpdateRequestCustomMetadataItem {
    dataType: NamespacesInstancesUpdateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export declare const NamespacesInstancesUpdateRequestCustomMetadataItem: S.Schema<NamespacesInstancesUpdateRequestCustomMetadataItem>;
export type NamespacesInstancesUpdateRequestCustomMetadataList = Array<NamespacesInstancesUpdateRequestCustomMetadataItem>;
export declare const NamespacesInstancesUpdateRequestCustomMetadataList: S.Schema<NamespacesInstancesUpdateRequestCustomMetadataList>;
export type NamespacesInstancesUpdateRequestEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesUpdateRequestEmbeddingModel: any;
export type NamespacesInstancesUpdateRequestFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesUpdateRequestFusionMethod: any;
export type NamespacesInstancesUpdateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesUpdateRequestIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesUpdateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer | (string & {});
}
export declare const NamespacesInstancesUpdateRequestIndexingOptions: S.Schema<NamespacesInstancesUpdateRequestIndexingOptions>;
export type NamespacesInstancesUpdateRequestMetadata = InstancesCreateRequestMetadata;
export declare const NamespacesInstancesUpdateRequestMetadata: S.Schema<InstancesCreateRequestMetadata>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsMcp: S.Schema<InstancesCreateRequestPublicEndpointParamsMcp>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number;
    requests?: number;
    technique?: NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {});
}
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesUpdateRequestPublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateRequestPublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesUpdateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList;
    enabled?: boolean;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp;
    rateLimit?: NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
}
export declare const NamespacesInstancesUpdateRequestPublicEndpointParams: S.Schema<NamespacesInstancesUpdateRequestPublicEndpointParams>;
export type NamespacesInstancesUpdateRequestRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesUpdateRequestRerankingModel: any;
export type NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection | (string & {});
}
export declare const NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem>;
export type NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList = Array<NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList>;
export type NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesUpdateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode | (string & {});
}
export declare const NamespacesInstancesUpdateRequestRetrievalOptions: S.Schema<NamespacesInstancesUpdateRequestRetrievalOptions>;
export type NamespacesInstancesUpdateRequestRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesUpdateRequestRewriteModel: any;
export type NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList>;
export type NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap;
    includeImages?: boolean;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList;
    useBrowserRendering?: boolean;
}
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions;
    parseType?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType | (string & {});
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions;
}
export declare const NamespacesInstancesUpdateRequestSourceParamsWebCrawler: S.Schema<NamespacesInstancesUpdateRequestSourceParamsWebCrawler>;
export interface NamespacesInstancesUpdateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList;
    prefix?: string;
    r2Jurisdiction?: string;
    webCrawler?: NamespacesInstancesUpdateRequestSourceParamsWebCrawler;
}
export declare const NamespacesInstancesUpdateRequestSourceParams: S.Schema<NamespacesInstancesUpdateRequestSourceParams>;
export type NamespacesInstancesUpdateRequestSummarizationModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesUpdateRequestSummarizationModel: any;
export type NamespacesInstancesUpdateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesUpdateRequestSyncInterval: any;
export interface UpdateNamespaceInstanceRequest {
    accountId: string;
    name: string;
    id: string;
    aiGatewayId?: string;
    aiSearchModel?: NamespacesInstancesUpdateRequestAiSearchModel | (string & {});
    cache?: boolean;
    cacheThreshold?: NamespacesInstancesUpdateRequestCacheThreshold | (string & {});
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesUpdateRequestCacheTtl | (number & {});
    chunk?: boolean;
    chunkOverlap?: number;
    chunkSize?: number;
    customMetadata?: NamespacesInstancesUpdateRequestCustomMetadataList;
    embeddingModel?: NamespacesInstancesUpdateRequestEmbeddingModel | (string & {});
    fusionMethod?: NamespacesInstancesUpdateRequestFusionMethod | (string & {});
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod;
    indexingOptions?: NamespacesInstancesUpdateRequestIndexingOptions;
    maxNumResults?: number;
    metadata?: InstancesCreateRequestMetadata;
    paused?: boolean;
    publicEndpointParams?: NamespacesInstancesUpdateRequestPublicEndpointParams;
    reranking?: boolean;
    rerankingModel?: NamespacesInstancesUpdateRequestRerankingModel | (string & {});
    retrievalOptions?: NamespacesInstancesUpdateRequestRetrievalOptions;
    rewriteModel?: NamespacesInstancesUpdateRequestRewriteModel | (string & {});
    rewriteQuery?: boolean;
    scoreThreshold?: number;
    source?: string;
    sourceParams?: NamespacesInstancesUpdateRequestSourceParams;
    summarization?: boolean;
    summarizationModel?: NamespacesInstancesUpdateRequestSummarizationModel | (string & {});
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesUpdateRequestSyncInterval | (number & {});
    systemPromptAiSearch?: string;
    systemPromptIndexSummarization?: string;
    systemPromptRewriteQuery?: string;
    tokenId?: string;
}
export declare const UpdateNamespaceInstanceRequest: S.Schema<UpdateNamespaceInstanceRequest>;
export type NamespacesInstancesUpdateResponseAiSearchModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesUpdateResponseAiSearchModel: any;
export type NamespacesInstancesUpdateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export declare const NamespacesInstancesUpdateResponseCacheThreshold: any;
export type NamespacesInstancesUpdateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export declare const NamespacesInstancesUpdateResponseCacheTtl: any;
export type NamespacesInstancesUpdateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export declare const NamespacesInstancesUpdateResponseCustomMetadataItemDataType: any;
export interface NamespacesInstancesUpdateResponseCustomMetadataItem {
    dataType: NamespacesInstancesUpdateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export declare const NamespacesInstancesUpdateResponseCustomMetadataItem: S.Schema<NamespacesInstancesUpdateResponseCustomMetadataItem>;
export type NamespacesInstancesUpdateResponseCustomMetadataList = Array<NamespacesInstancesUpdateResponseCustomMetadataItem>;
export declare const NamespacesInstancesUpdateResponseCustomMetadataList: S.Schema<NamespacesInstancesUpdateResponseCustomMetadataList>;
export type NamespacesInstancesUpdateResponseEmbeddingModel = "@cf/qwen/qwen3-embedding-0.6b" | "@cf/qwen/qwen3-vl-embedding-2b" | "@cf/baai/bge-m3" | "@cf/baai/bge-large-en-v1.5" | "@cf/google/embeddinggemma-300m" | "google-ai-studio/gemini-embedding-001" | "google-ai-studio/gemini-embedding-2-preview" | "google-ai-studio/gemini-embedding-2" | "openai/text-embedding-3-small" | "openai/text-embedding-3-large" | "";
export declare const NamespacesInstancesUpdateResponseEmbeddingModel: any;
export type NamespacesInstancesUpdateResponseFusionMethod = "max" | "rrf";
export declare const NamespacesInstancesUpdateResponseFusionMethod: any;
export type NamespacesInstancesUpdateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export declare const NamespacesInstancesUpdateResponseIndexMethod: S.Schema<InstancesCreateRequestIndexMethod>;
export type NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export declare const NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer: any;
export interface NamespacesInstancesUpdateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer | null;
}
export declare const NamespacesInstancesUpdateResponseIndexingOptions: S.Schema<NamespacesInstancesUpdateResponseIndexingOptions>;
export type NamespacesInstancesUpdateResponseMetadata = InstancesCreateResponseMetadata;
export declare const NamespacesInstancesUpdateResponseMetadata: S.Schema<InstancesCreateResponseMetadata>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList: S.Schema<NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList: S.Schema<NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsMcp: S.Schema<InstancesCreateResponsePublicEndpointParamsMcp>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique: any;
export interface NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null;
    requests?: number | null;
    technique?: NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique | null;
}
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit: S.Schema<NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export declare const NamespacesInstancesUpdateResponsePublicEndpointParamsSearchEndpoint: S.Schema<InstancesCreateResponsePublicEndpointParamsSearchEndpoint>;
export interface NamespacesInstancesUpdateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList | null;
    enabled?: boolean | null;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null;
    rateLimit?: NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit | null;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null;
}
export declare const NamespacesInstancesUpdateResponsePublicEndpointParams: S.Schema<NamespacesInstancesUpdateResponsePublicEndpointParams>;
export type NamespacesInstancesUpdateResponseRerankingModel = "@cf/baai/bge-reranker-base" | "";
export declare const NamespacesInstancesUpdateResponseRerankingModel: any;
export type NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export declare const NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection: any;
export interface NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection | null;
}
export declare const NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem: S.Schema<NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem>;
export declare const NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList: S.Schema<NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList>;
export type NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export declare const NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode: any;
export interface NamespacesInstancesUpdateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList | null;
    /** Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. Defaults to 'and'. */
    keywordMatchMode?: NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode | null;
}
export declare const NamespacesInstancesUpdateResponseRetrievalOptions: S.Schema<NamespacesInstancesUpdateResponseRetrievalOptions>;
export type NamespacesInstancesUpdateResponseRewriteModel = "@cf/meta/llama-3.3-70b-instruct-fp8-fast" | "@cf/zai-org/glm-4.7-flash" | "@cf/meta/llama-3.1-8b-instruct-fast" | "@cf/meta/llama-3.1-8b-instruct-fp8" | "@cf/meta/llama-4-scout-17b-16e-instruct" | "@cf/qwen/qwen3-30b-a3b-fp8" | "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b" | "@cf/moonshotai/kimi-k2-instruct" | "@cf/google/gemma-3-12b-it" | "@cf/google/gemma-4-26b-a4b-it" | "@cf/moonshotai/kimi-k2.5" | "anthropic/claude-3-7-sonnet" | "anthropic/claude-sonnet-4" | "anthropic/claude-opus-4" | "anthropic/claude-3-5-haiku" | "cerebras/qwen-3-235b-a22b-instruct" | "cerebras/qwen-3-235b-a22b-thinking" | "cerebras/llama-3.3-70b" | "cerebras/llama-4-maverick-17b-128e-instruct" | "cerebras/llama-4-scout-17b-16e-instruct" | "cerebras/gpt-oss-120b" | "google-ai-studio/gemini-2.5-flash" | "google-ai-studio/gemini-2.5-pro" | "grok/grok-4" | "groq/llama-3.3-70b-versatile" | "groq/llama-3.1-8b-instant" | "openai/gpt-5" | "openai/gpt-5-mini" | "openai/gpt-5-nano" | "";
export declare const NamespacesInstancesUpdateResponseRewriteModel: any;
export type NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList = Array<string>;
export declare const NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList: S.Schema<NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList>;
export type NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList = Array<string>;
export declare const NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList: S.Schema<NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem: S.Schema<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList: S.Schema<NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap: S.Schema<NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList: S.Schema<NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList>;
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected. */
    contentSelector?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF). */
    includeHeaders?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null;
    includeImages?: boolean | null;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null;
    useBrowserRendering?: boolean | null;
}
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions: S.Schema<NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType = "sitemap" | "crawl";
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType: any;
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawler {
    parseOptions?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions | null;
    parseType?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType | null;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null;
}
export declare const NamespacesInstancesUpdateResponseSourceParamsWebCrawler: S.Schema<NamespacesInstancesUpdateResponseSourceParamsWebCrawler>;
export interface NamespacesInstancesUpdateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced) */
    excludeItems?: NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList | null;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post) */
    includeItems?: NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList | null;
    prefix?: string | null;
    r2Jurisdiction?: string | null;
    webCrawler?: NamespacesInstancesUpdateResponseSourceParamsWebCrawler | null;
}
export declare const NamespacesInstancesUpdateResponseSourceParams: S.Schema<NamespacesInstancesUpdateResponseSourceParams>;
export type NamespacesInstancesUpdateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export declare const NamespacesInstancesUpdateResponseSyncInterval: any;
export type NamespacesInstancesUpdateResponseType = "r2" | "web-crawler";
export declare const NamespacesInstancesUpdateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null;
    aiSearchModel?: NamespacesInstancesUpdateResponseAiSearchModel | null;
    cache?: boolean | null;
    cacheThreshold?: NamespacesInstancesUpdateResponseCacheThreshold | null;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesUpdateResponseCacheTtl | null;
    chunkOverlap?: number | null;
    chunkSize?: number | null;
    createdBy?: string | null;
    customMetadata?: NamespacesInstancesUpdateResponseCustomMetadataList | null;
    embeddingModel?: NamespacesInstancesUpdateResponseEmbeddingModel | null;
    enable?: boolean | null;
    engineVersion?: number | null;
    fusionMethod?: NamespacesInstancesUpdateResponseFusionMethod | null;
    /** Deprecated — use index_method instead. */
    hybridSearchEnabled?: boolean | null;
    /** Controls which storage backends are used during indexing. Defaults to vector-only. */
    indexMethod?: InstancesCreateRequestIndexMethod | null;
    indexingOptions?: NamespacesInstancesUpdateResponseIndexingOptions | null;
    lastActivity?: string | null;
    maxNumResults?: number | null;
    metadata?: InstancesCreateResponseMetadata | null;
    modifiedBy?: string | null;
    namespace?: string | null;
    paused?: boolean | null;
    publicEndpointId?: string | null;
    publicEndpointParams?: NamespacesInstancesUpdateResponsePublicEndpointParams | null;
    reranking?: boolean | null;
    rerankingModel?: NamespacesInstancesUpdateResponseRerankingModel | null;
    retrievalOptions?: NamespacesInstancesUpdateResponseRetrievalOptions | null;
    rewriteModel?: NamespacesInstancesUpdateResponseRewriteModel | null;
    rewriteQuery?: boolean | null;
    scoreThreshold?: number | null;
    source?: string | null;
    sourceParams?: NamespacesInstancesUpdateResponseSourceParams | null;
    status?: string | null;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). */
    syncInterval?: NamespacesInstancesUpdateResponseSyncInterval | null;
    tokenId?: string | null;
    type?: NamespacesInstancesUpdateResponseType | null;
}
export declare const UpdateNamespaceInstanceResponse: S.Schema<UpdateNamespaceInstanceResponse>;
export interface UpdateTokenRequest {
    accountId: string;
    id: string;
    cfApiId: string;
    cfApiKey: string;
    name: string;
    legacy?: boolean;
}
export declare const UpdateTokenRequest: S.Schema<UpdateTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null;
    enabled?: boolean | null;
    legacy?: boolean | null;
    modifiedBy?: string | null;
}
export declare const UpdateTokenResponse: S.Schema<UpdateTokenResponse>;
export interface UploadNamespaceInstanceItemRequest {
    accountId: string;
    name: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export declare const UploadNamespaceInstanceItemRequest: S.Schema<UploadNamespaceInstanceItemRequest>;
export type NamespacesInstancesItemsUploadResponseNextAction = "INDEX" | "DELETE";
export declare const NamespacesInstancesItemsUploadResponseNextAction: any;
export type NamespacesInstancesItemsUploadResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export declare const NamespacesInstancesItemsUploadResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UploadNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    namespace: string;
    nextAction: NamespacesInstancesItemsUploadResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsUploadResponseStatus;
    error?: string | null;
}
export declare const UploadNamespaceInstanceItemResponse: S.Schema<UploadNamespaceInstanceItemResponse>;
export type ChatCompletionsInstanceError = CloudflareOpError;
/** Performs a chat completion request against an AI Search instance, using indexed content as context for generating responses. */
export declare const chatCompletionsInstance: API.OperationMethod<ChatCompletionsInstanceRequest, ChatCompletionsInstanceResponse, ChatCompletionsInstanceError, CloudflareOpContext>;
export type ChatCompletionsNamespaceError = CloudflareOpError;
/** Performs a chat completion request against multiple AI Search instances in parallel, merging retrieved content as context for generating a response. */
export declare const chatCompletionsNamespace: API.OperationMethod<ChatCompletionsNamespaceRequest, ChatCompletionsNamespaceResponse, ChatCompletionsNamespaceError, CloudflareOpContext>;
export type ChatCompletionsNamespaceInstanceError = CloudflareOpError;
/** Performs a chat completion request against an AI Search instance, using indexed content as context for generating responses. */
export declare const chatCompletionsNamespaceInstance: API.OperationMethod<ChatCompletionsNamespaceInstanceRequest, ChatCompletionsNamespaceInstanceResponse, ChatCompletionsNamespaceInstanceError, CloudflareOpContext>;
export type ChunksNamespaceInstanceItemError = CloudflareOpError;
/** Lists chunks for a specific item in an AI Search instance, including their text content. */
export declare const chunksNamespaceInstanceItem: API.OperationMethod<ChunksNamespaceInstanceItemRequest, ChunksNamespaceInstanceItemResponse, ChunksNamespaceInstanceItemError, CloudflareOpContext>;
export type CreateInstanceError = ValidationError | NotFound | InvalidRoute | InstanceAlreadyExists | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Create a new instance. */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, CloudflareOpContext>;
export type CreateInstanceJobError = ValidationError | NotFound | InvalidRoute | UnableToConnect | SyncInCooldown | CloudflareOpError;
/** Creates a new indexing job for an AI Search instance. */
export declare const createInstanceJob: API.OperationMethod<CreateInstanceJobRequest, CreateInstanceJobResponse, CreateInstanceJobError, CloudflareOpContext>;
export type CreateNamespaceError = NamespaceAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new namespace. */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, CloudflareOpContext>;
export type CreateNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | InstanceAlreadyExists | InvalidTokenCredentials | WebCrawlerDomainNotOwned | MissingSitemap | Forbidden | CloudflareOpError;
/** Create a new instance. */
export declare const createNamespaceInstance: API.OperationMethod<CreateNamespaceInstanceRequest, CreateNamespaceInstanceResponse, CreateNamespaceInstanceError, CloudflareOpContext>;
export type CreateNamespaceInstanceJobError = CloudflareOpError;
/** Creates a new indexing job for an AI Search instance. */
export declare const createNamespaceInstanceJob: API.OperationMethod<CreateNamespaceInstanceJobRequest, CreateNamespaceInstanceJobResponse, CreateNamespaceInstanceJobError, CloudflareOpContext>;
export type CreateOrUpdateNamespaceInstanceItemError = CloudflareOpError;
/** Creates or updates an indexed item in an AI Search instance. */
export declare const createOrUpdateNamespaceInstanceItem: API.OperationMethod<CreateOrUpdateNamespaceInstanceItemRequest, CreateOrUpdateNamespaceInstanceItemResponse, CreateOrUpdateNamespaceInstanceItemError, CloudflareOpContext>;
export type CreateTokenError = ValidationError | NotFound | InvalidRoute | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Create a new token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteInstanceError = ValidationError | NotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Delete instance. */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest, DeleteInstanceResponse, DeleteInstanceError, CloudflareOpContext>;
export type DeleteNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Delete namespace. */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Delete instance. */
export declare const deleteNamespaceInstance: API.OperationMethod<DeleteNamespaceInstanceRequest, DeleteNamespaceInstanceResponse, DeleteNamespaceInstanceError, CloudflareOpContext>;
export type DeleteNamespaceInstanceItemError = CloudflareOpError;
/** Deletes a file from a managed AI Search instance and triggers a reindex. */
export declare const deleteNamespaceInstanceItem: API.OperationMethod<DeleteNamespaceInstanceItemRequest, DeleteNamespaceInstanceItemResponse, DeleteNamespaceInstanceItemError, CloudflareOpContext>;
export type DeleteTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | TokenInUseByInstances | Forbidden | CloudflareOpError;
/** Delete token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type DownloadNamespaceInstanceItemError = CloudflareOpError;
/** Downloads the raw file content for a specific item from the managed AI Search instance storage. */
export declare const downloadNamespaceInstanceItem: API.OperationMethod<DownloadNamespaceInstanceItemRequest, DownloadNamespaceInstanceItemResponse, DownloadNamespaceInstanceItemError, CloudflareOpContext>;
export type GetInstanceJobError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Retrieves details for a specific AI Search indexing job. */
export declare const getInstanceJob: API.OperationMethod<GetInstanceJobRequest, GetInstanceJobResponse, GetInstanceJobError, CloudflareOpContext>;
export type GetNamespaceInstanceItemError = CloudflareOpError;
/** Retrieves a specific indexed item from an AI Search instance. */
export declare const getNamespaceInstanceItem: API.OperationMethod<GetNamespaceInstanceItemRequest, GetNamespaceInstanceItemResponse, GetNamespaceInstanceItemError, CloudflareOpContext>;
export type GetNamespaceInstanceJobError = CloudflareOpError;
/** Retrieves details for a specific AI Search indexing job. */
export declare const getNamespaceInstanceJob: API.OperationMethod<GetNamespaceInstanceJobRequest, GetNamespaceInstanceJobResponse, GetNamespaceInstanceJobError, CloudflareOpContext>;
export type ListInstanceJobsError = CloudflareOpError;
/** Lists indexing jobs for an AI Search instance. */
export declare const listInstanceJobs: API.PaginatedOperationMethod<ListInstanceJobsRequest, ListInstanceJobsResponse, ListInstanceJobsError, CloudflareOpContext, InstancesJobsListResultItem>;
export type ListInstancesError = InvalidRoute | Forbidden | CloudflareOpError;
/** List instances. */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, CloudflareOpContext, InstancesListResultItem>;
export type ListNamespaceInstanceItemsError = CloudflareOpError;
/** Lists indexed items in an AI Search instance. */
export declare const listNamespaceInstanceItems: API.PaginatedOperationMethod<ListNamespaceInstanceItemsRequest, ListNamespaceInstanceItemsResponse, ListNamespaceInstanceItemsError, CloudflareOpContext, NamespacesInstancesItemsListResultItem>;
export type ListNamespaceInstanceJobsError = CloudflareOpError;
/** Lists indexing jobs for an AI Search instance. */
export declare const listNamespaceInstanceJobs: API.PaginatedOperationMethod<ListNamespaceInstanceJobsRequest, ListNamespaceInstanceJobsResponse, ListNamespaceInstanceJobsError, CloudflareOpContext, NamespacesInstancesJobsListResultItem>;
export type ListNamespaceInstancesError = NamespaceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** List instances. */
export declare const listNamespaceInstances: API.PaginatedOperationMethod<ListNamespaceInstancesRequest, ListNamespaceInstancesResponse, ListNamespaceInstancesError, CloudflareOpContext, NamespacesInstancesListResultItem>;
export type ListNamespacesError = CloudflareOpError;
/** List namespaces. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
export type ListTokensError = InvalidRoute | Forbidden | CloudflareOpError;
/** List tokens. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type LogsInstanceJobError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Lists log entries for an AI Search indexing job. */
export declare const logsInstanceJob: API.OperationMethod<LogsInstanceJobRequest, LogsInstanceJobResponse, LogsInstanceJobError, CloudflareOpContext>;
export type LogsNamespaceInstanceItemError = CloudflareOpError;
/** Lists processing logs for a specific item in an AI Search instance. */
export declare const logsNamespaceInstanceItem: API.OperationMethod<LogsNamespaceInstanceItemRequest, LogsNamespaceInstanceItemResponse, LogsNamespaceInstanceItemError, CloudflareOpContext>;
export type LogsNamespaceInstanceJobError = CloudflareOpError;
/** Lists log entries for an AI Search indexing job. */
export declare const logsNamespaceInstanceJob: API.OperationMethod<LogsNamespaceInstanceJobRequest, LogsNamespaceInstanceJobResponse, LogsNamespaceInstanceJobError, CloudflareOpContext>;
export type PatchNamespaceInstanceJobError = CloudflareOpError;
/** Updates the status of an AI Search indexing job. */
export declare const patchNamespaceInstanceJob: API.OperationMethod<PatchNamespaceInstanceJobRequest, PatchNamespaceInstanceJobResponse, PatchNamespaceInstanceJobError, CloudflareOpContext>;
export type ReadInstanceError = ValidationError | NotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Read instance. */
export declare const readInstance: API.OperationMethod<ReadInstanceRequest, ReadInstanceResponse, ReadInstanceError, CloudflareOpContext>;
export type ReadNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Read namespace. */
export declare const readNamespace: API.OperationMethod<ReadNamespaceRequest, ReadNamespaceResponse, ReadNamespaceError, CloudflareOpContext>;
export type ReadNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Read instance. */
export declare const readNamespaceInstance: API.OperationMethod<ReadNamespaceInstanceRequest, ReadNamespaceInstanceResponse, ReadNamespaceInstanceError, CloudflareOpContext>;
export type ReadTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | Forbidden | CloudflareOpError;
/** Read token. */
export declare const readToken: API.OperationMethod<ReadTokenRequest, ReadTokenResponse, ReadTokenError, CloudflareOpContext>;
export type SearchInstanceError = CloudflareOpError;
/** Executes a semantic search query against an AI Search instance to find relevant indexed content. */
export declare const searchInstance: API.OperationMethod<SearchInstanceRequest, SearchInstanceResponse, SearchInstanceError, CloudflareOpContext>;
export type SearchNamespaceError = CloudflareOpError;
/** Performs a semantic search query against multiple AI Search instances in parallel, merging the retrieved results into a single ranked response. */
export declare const searchNamespace: API.OperationMethod<SearchNamespaceRequest, SearchNamespaceResponse, SearchNamespaceError, CloudflareOpContext>;
export type SearchNamespaceInstanceError = CloudflareOpError;
/** Executes a semantic search query against an AI Search instance to find relevant indexed content. */
export declare const searchNamespaceInstance: API.OperationMethod<SearchNamespaceInstanceRequest, SearchNamespaceInstanceResponse, SearchNamespaceInstanceError, CloudflareOpContext>;
export type StatsInstanceError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Retrieves usage statistics for AI Search instances. */
export declare const statsInstance: API.OperationMethod<StatsInstanceRequest, StatsInstanceResponse, StatsInstanceError, CloudflareOpContext>;
export type StatsNamespaceInstanceError = CloudflareOpError;
/** Retrieves usage statistics for AI Search instances. */
export declare const statsNamespaceInstance: API.OperationMethod<StatsNamespaceInstanceRequest, StatsNamespaceInstanceResponse, StatsNamespaceInstanceError, CloudflareOpContext>;
export type SyncNamespaceInstanceItemError = CloudflareOpError;
/** Syncs an item to an AI Search instance index. */
export declare const syncNamespaceInstanceItem: API.OperationMethod<SyncNamespaceInstanceItemRequest, SyncNamespaceInstanceItemResponse, SyncNamespaceInstanceItemError, CloudflareOpContext>;
export type UpdateInstanceError = ValidationError | NotFound | InvalidRoute | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Update instance. */
export declare const updateInstance: API.OperationMethod<UpdateInstanceRequest, UpdateInstanceResponse, UpdateInstanceError, CloudflareOpContext>;
export type UpdateNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Update namespace. */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest, UpdateNamespaceResponse, UpdateNamespaceError, CloudflareOpContext>;
export type UpdateNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | InvalidTokenCredentials | WebCrawlerDomainNotOwned | Forbidden | CloudflareOpError;
/** Update instance. */
export declare const updateNamespaceInstance: API.OperationMethod<UpdateNamespaceInstanceRequest, UpdateNamespaceInstanceResponse, UpdateNamespaceInstanceError, CloudflareOpContext>;
export type UpdateTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | Forbidden | InvalidTokenCredentials | CloudflareOpError;
/** Update token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type UploadNamespaceInstanceItemError = CloudflareOpError;
/** Uploads a file to a managed AI Search instance via multipart/form-data (max 4MB). */
export declare const uploadNamespaceInstanceItem: API.OperationMethod<UploadNamespaceInstanceItemRequest, UploadNamespaceInstanceItemResponse, UploadNamespaceInstanceItemError, CloudflareOpContext>;
//# sourceMappingURL=ai_search.d.ts.map