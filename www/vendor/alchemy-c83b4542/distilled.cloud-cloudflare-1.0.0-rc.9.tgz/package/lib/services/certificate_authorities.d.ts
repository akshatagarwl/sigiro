import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface GetHostnameAssociationRequest {
    /** Identifier. */
    zoneId: string;
    /** The UUID to match against for a certificate that was uploaded to the mTLS Certificate Management endpoint. If no mtls_certificate_id is given, the results will be the hostnames associated to your active Cloudflare Managed CA. */
    mtlsCertificateId?: string;
}
export declare const GetHostnameAssociationRequest: S.Schema<GetHostnameAssociationRequest>;
export type HostnameAssociationsGetResponseHostnamesList = Array<string>;
export declare const HostnameAssociationsGetResponseHostnamesList: S.Schema<HostnameAssociationsGetResponseHostnamesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameAssociationResponse {
    hostnames?: HostnameAssociationsGetResponseHostnamesList | null;
}
export declare const GetHostnameAssociationResponse: S.Schema<GetHostnameAssociationResponse>;
export type HostnameAssociationsUpdateRequestHostnamesList = Array<string>;
export declare const HostnameAssociationsUpdateRequestHostnamesList: S.Schema<HostnameAssociationsUpdateRequestHostnamesList>;
export interface PutHostnameAssociationRequest {
    /** Identifier. */
    zoneId: string;
    hostnames?: HostnameAssociationsUpdateRequestHostnamesList;
    /** The UUID for a certificate that was uploaded to the mTLS Certificate Management endpoint. If no mtls_certificate_id is given, the hostnames will be associated to your active Cloudflare Managed CA. */
    mtlsCertificateId?: string;
}
export declare const PutHostnameAssociationRequest: S.Schema<PutHostnameAssociationRequest>;
export type HostnameAssociationsUpdateResponseHostnamesList = Array<string>;
export declare const HostnameAssociationsUpdateResponseHostnamesList: S.Schema<HostnameAssociationsUpdateResponseHostnamesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutHostnameAssociationResponse {
    hostnames?: HostnameAssociationsUpdateResponseHostnamesList | null;
}
export declare const PutHostnameAssociationResponse: S.Schema<PutHostnameAssociationResponse>;
export type GetHostnameAssociationError = Forbidden | CloudflareOpError;
/** List Hostname Associations. */
export declare const getHostnameAssociation: API.OperationMethod<GetHostnameAssociationRequest, GetHostnameAssociationResponse, GetHostnameAssociationError, CloudflareOpContext>;
export type PutHostnameAssociationError = Forbidden | CloudflareOpError;
/** Replace Hostname Associations. */
export declare const putHostnameAssociation: API.OperationMethod<PutHostnameAssociationRequest, PutHostnameAssociationResponse, PutHostnameAssociationError, CloudflareOpContext>;
//# sourceMappingURL=certificate_authorities.d.ts.map