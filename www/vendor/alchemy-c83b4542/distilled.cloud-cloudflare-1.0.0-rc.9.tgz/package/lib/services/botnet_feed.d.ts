import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DayReportAsnRequest {
    /** Identifier. */
    accountId: string;
    asnId: number;
    date?: string;
}
export declare const DayReportAsnRequest: S.Schema<DayReportAsnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DayReportAsnResponse {
    cidr?: string | null;
    date?: string | null;
    offenseCount?: number | null;
}
export declare const DayReportAsnResponse: S.Schema<DayReportAsnResponse>;
export interface DeleteConfigAsnRequest {
    /** Identifier. */
    accountId: string;
    asnId: number;
}
export declare const DeleteConfigAsnRequest: S.Schema<DeleteConfigAsnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConfigAsnResponse {
    asn?: number | null;
}
export declare const DeleteConfigAsnResponse: S.Schema<DeleteConfigAsnResponse>;
export interface FullReportAsnRequest {
    /** Identifier. */
    accountId: string;
    asnId: number;
}
export declare const FullReportAsnRequest: S.Schema<FullReportAsnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface FullReportAsnResponse {
    cidr?: string | null;
    date?: string | null;
    offenseCount?: number | null;
}
export declare const FullReportAsnResponse: S.Schema<FullReportAsnResponse>;
export interface GetConfigAsnRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetConfigAsnRequest: S.Schema<GetConfigAsnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigAsnResponse {
    asn?: number | null;
}
export declare const GetConfigAsnResponse: S.Schema<GetConfigAsnResponse>;
export type DayReportAsnError = CloudflareOpError;
/** Gets all the data the botnet tracking database has for a given ASN registered to user account for given date. If no date is given, it will return results for the previous day. */
export declare const dayReportAsn: API.OperationMethod<DayReportAsnRequest, DayReportAsnResponse, DayReportAsnError, CloudflareOpContext>;
export type DeleteConfigAsnError = CloudflareOpError;
/** Delete an ASN from botnet threat feed for a given user. */
export declare const deleteConfigAsn: API.OperationMethod<DeleteConfigAsnRequest, DeleteConfigAsnResponse, DeleteConfigAsnError, CloudflareOpContext>;
export type FullReportAsnError = CloudflareOpError;
/** Gets all the data the botnet threat feed tracking database has for a given ASN registered to user account. */
export declare const fullReportAsn: API.OperationMethod<FullReportAsnRequest, FullReportAsnResponse, FullReportAsnError, CloudflareOpContext>;
export type GetConfigAsnError = CloudflareOpError;
/** Gets a list of all ASNs registered for a user for the DDoS Botnet Feed API. */
export declare const getConfigAsn: API.OperationMethod<GetConfigAsnRequest, GetConfigAsnResponse, GetConfigAsnError, CloudflareOpContext>;
//# sourceMappingURL=botnet_feed.d.ts.map