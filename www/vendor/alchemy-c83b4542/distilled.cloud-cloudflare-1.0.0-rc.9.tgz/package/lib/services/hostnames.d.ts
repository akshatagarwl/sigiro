import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AdvancedCertificateManagerRequired_base: S.Class<AdvancedCertificateManagerRequired, S.TaggedStruct<"AdvancedCertificateManagerRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AdvancedCertificateManagerRequired extends /*@__PURE__*/ AdvancedCertificateManagerRequired_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameTlsSettingNotFound_base: S.Class<HostnameTlsSettingNotFound, S.TaggedStruct<"HostnameTlsSettingNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameTlsSettingNotFound extends /*@__PURE__*/ HostnameTlsSettingNotFound_base {
}
export type SettingsTlsDeleteRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export declare const SettingsTlsDeleteRequestSettingId: any;
export interface DeleteSettingTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. */
    settingId: SettingsTlsDeleteRequestSettingId | (string & {});
    /** The hostname for which the tls settings are set. */
    hostname: string;
}
export declare const DeleteSettingTlsRequest: S.Schema<DeleteSettingTlsRequest>;
export type SettingsTlsDeleteResponseValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export declare const SettingsTlsDeleteResponseValueCase0: any;
export type SettingsTlsDeleteResponseValueCase1List = Array<string>;
export declare const SettingsTlsDeleteResponseValueCase1List: S.Schema<SettingsTlsDeleteResponseValueCase1List>;
export type SettingsTlsDeleteResponseValue = SettingsTlsDeleteResponseValueCase0 | SettingsTlsDeleteResponseValueCase1List;
export declare const SettingsTlsDeleteResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingTlsResponse {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. */
    value?: SettingsTlsDeleteResponseValue | null;
}
export declare const DeleteSettingTlsResponse: S.Schema<DeleteSettingTlsResponse>;
export type SettingsTlsGetRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export declare const SettingsTlsGetRequestSettingId: any;
export interface GetSettingTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. */
    settingId: SettingsTlsGetRequestSettingId | (string & {});
}
export declare const GetSettingTlsRequest: S.Schema<GetSettingTlsRequest>;
export type SettingsTlsGetResultItemValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export declare const SettingsTlsGetResultItemValueCase0: any;
export type SettingsTlsGetResultItemValueCase1List = Array<string>;
export declare const SettingsTlsGetResultItemValueCase1List: S.Schema<SettingsTlsGetResultItemValueCase1List>;
export type SettingsTlsGetResultItemValue = SettingsTlsGetResultItemValueCase0 | SettingsTlsGetResultItemValueCase1List;
export declare const SettingsTlsGetResultItemValue: any;
export interface SettingsTlsGetResultItem {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. */
    value?: SettingsTlsGetResultItemValue | null;
}
export declare const SettingsTlsGetResultItem: S.Schema<SettingsTlsGetResultItem>;
export type SettingsTlsGetResultList = Array<SettingsTlsGetResultItem>;
export declare const SettingsTlsGetResultList: S.Schema<SettingsTlsGetResultList>;
export interface GetSettingTlsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsTlsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetSettingTlsResponse: S.Schema<GetSettingTlsResponse>;
export type SettingsTlsUpdateRequestSettingId = "ciphers" | "min_tls_version" | "http2";
export declare const SettingsTlsUpdateRequestSettingId: any;
export type SettingsTlsUpdateRequestValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export declare const SettingsTlsUpdateRequestValueCase0: any;
export type SettingsTlsUpdateRequestValueCase1List = Array<string>;
export declare const SettingsTlsUpdateRequestValueCase1List: S.Schema<SettingsTlsUpdateRequestValueCase1List>;
export type SettingsTlsUpdateRequestValue = SettingsTlsUpdateRequestValueCase0 | (string & {}) | SettingsTlsUpdateRequestValueCase1List;
export declare const SettingsTlsUpdateRequestValue: any;
export interface PutSettingTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** The TLS Setting name. */
    settingId: SettingsTlsUpdateRequestSettingId | (string & {});
    /** The hostname for which the tls settings are set. */
    hostname: string;
    /** The TLS setting value. */
    value: SettingsTlsUpdateRequestValue;
}
export declare const PutSettingTlsRequest: S.Schema<PutSettingTlsRequest>;
export type SettingsTlsUpdateResponseValueCase0 = "1.0" | "1.1" | "1.2" | "1.3" | "on" | "off";
export declare const SettingsTlsUpdateResponseValueCase0: any;
export type SettingsTlsUpdateResponseValueCase1List = Array<string>;
export declare const SettingsTlsUpdateResponseValueCase1List: S.Schema<SettingsTlsUpdateResponseValueCase1List>;
export type SettingsTlsUpdateResponseValue = SettingsTlsUpdateResponseValueCase0 | SettingsTlsUpdateResponseValueCase1List;
export declare const SettingsTlsUpdateResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingTlsResponse {
    /** This is the time the tls setting was originally created for this hostname. */
    createdAt?: string | null;
    /** The hostname for which the tls settings are set. */
    hostname?: string | null;
    /** Deployment status for the given tls setting. */
    status?: string | null;
    /** This is the time the tls setting was updated. */
    updatedAt?: string | null;
    /** The TLS setting value. */
    value?: SettingsTlsUpdateResponseValue | null;
}
export declare const PutSettingTlsResponse: S.Schema<PutSettingTlsResponse>;
export type DeleteSettingTlsError = AdvancedCertificateManagerRequired | HostnameTlsSettingNotFound | Forbidden | CloudflareOpError;
/** Delete the tls setting value for the hostname. */
export declare const deleteSettingTls: API.OperationMethod<DeleteSettingTlsRequest, DeleteSettingTlsResponse, DeleteSettingTlsError, CloudflareOpContext>;
export type GetSettingTlsError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** List the requested TLS setting for the hostnames under this zone. */
export declare const getSettingTls: API.PaginatedOperationMethod<GetSettingTlsRequest, GetSettingTlsResponse, GetSettingTlsError, CloudflareOpContext, SettingsTlsGetResultItem>;
export type PutSettingTlsError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** Update the tls setting value for the hostname. */
export declare const putSettingTls: API.OperationMethod<PutSettingTlsRequest, PutSettingTlsResponse, PutSettingTlsError, CloudflareOpContext>;
//# sourceMappingURL=hostnames.d.ts.map