import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type QueriesBulkRequestQueriesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const QueriesBulkRequestQueriesItemMap: S.Schema<QueriesBulkRequestQueriesItemMap>;
export type QueriesBulkRequestQueriesList = Array<QueriesBulkRequestQueriesItemMap>;
export declare const QueriesBulkRequestQueriesList: S.Schema<QueriesBulkRequestQueriesList>;
export interface BulkQueryRequest {
    accountId: string;
    queries?: QueriesBulkRequestQueriesList;
}
export declare const BulkQueryRequest: S.Schema<BulkQueryRequest>;
export interface BulkQueryResponse {
}
export declare const BulkQueryResponse: S.Schema<BulkQueryResponse>;
export interface CreateLogoRequest {
    accountId: string;
    matchType?: string;
    tag?: string;
    threshold?: number;
}
export declare const CreateLogoRequest: S.Schema<CreateLogoRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateLogoResponse {
    id?: number | null;
    tag?: string | null;
    uploadPath?: string | null;
}
export declare const CreateLogoResponse: S.Schema<CreateLogoResponse>;
export interface CreateQueryRequest {
    accountId: string;
    id?: string;
    scan?: boolean;
    tag?: string;
    maxTime?: string;
    minTime?: string;
    stringMatches?: unknown;
    bodyScan?: boolean;
    bodyTag?: string;
}
export declare const CreateQueryRequest: S.Schema<CreateQueryRequest>;
export interface CreateQueryResponse {
}
export declare const CreateQueryResponse: S.Schema<CreateQueryResponse>;
export interface CreateV2LogoRequest {
    accountId: string;
    /** Base64 encoded image data. Can include data URI prefix (e.g., 'data:image/png;base64,...') or just the base64 string. */
    imageData: string;
    /** Minimum similarity score (0-1) required for visual matches */
    similarityThreshold: number;
    /** Unique identifier for the logo query */
    tag: string;
    /** If true, search historic scanned images for matches above the similarity threshold */
    searchLookback?: boolean;
}
export declare const CreateV2LogoRequest: S.Schema<CreateV2LogoRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateV2LogoResponse {
    message: string;
    queryId?: number | null;
}
export declare const CreateV2LogoResponse: S.Schema<CreateV2LogoResponse>;
export interface DeleteLogoRequest {
    accountId: string;
    logoId: string;
}
export declare const DeleteLogoRequest: S.Schema<DeleteLogoRequest>;
export interface DeleteLogoResponse {
}
export declare const DeleteLogoResponse: S.Schema<DeleteLogoResponse>;
export interface DeleteQueryRequest {
    accountId: string;
    id?: string;
    scan?: boolean;
    tag?: string;
}
export declare const DeleteQueryRequest: S.Schema<DeleteQueryRequest>;
export interface DeleteQueryResponse {
}
export declare const DeleteQueryResponse: S.Schema<DeleteQueryResponse>;
export interface DeleteV2LogoRequest {
    accountId: string;
    queryId: string;
}
export declare const DeleteV2LogoRequest: S.Schema<DeleteV2LogoRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteV2LogoResponse {
    message: string;
}
export declare const DeleteV2LogoResponse: S.Schema<DeleteV2LogoResponse>;
export type LogoMatchesDownloadRequestLogoIdList = Array<string>;
export declare const LogoMatchesDownloadRequestLogoIdList: S.Schema<LogoMatchesDownloadRequestLogoIdList>;
export interface DownloadLogoMatchRequest {
    accountId: string;
    limit?: string;
    logoId?: LogoMatchesDownloadRequestLogoIdList;
    offset?: string;
}
export declare const DownloadLogoMatchRequest: S.Schema<DownloadLogoMatchRequest>;
export type LogoMatchesDownloadResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const LogoMatchesDownloadResponseMatchesItemMap: S.Schema<LogoMatchesDownloadResponseMatchesItemMap>;
export type LogoMatchesDownloadResponseMatchesList = Array<LogoMatchesDownloadResponseMatchesItemMap>;
export declare const LogoMatchesDownloadResponseMatchesList: S.Schema<LogoMatchesDownloadResponseMatchesList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DownloadLogoMatchResponse {
    matches?: LogoMatchesDownloadResponseMatchesList | null;
    total?: number | null;
}
export declare const DownloadLogoMatchResponse: S.Schema<DownloadLogoMatchResponse>;
export interface DownloadMatchRequest {
    accountId: string;
    id?: string;
    includeDomainId?: boolean;
    limit?: number;
    offset?: number;
}
export declare const DownloadMatchRequest: S.Schema<DownloadMatchRequest>;
export type MatchesDownloadResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const MatchesDownloadResponseMatchesItemMap: S.Schema<MatchesDownloadResponseMatchesItemMap>;
export type MatchesDownloadResponseMatchesList = Array<MatchesDownloadResponseMatchesItemMap>;
export declare const MatchesDownloadResponseMatchesList: S.Schema<MatchesDownloadResponseMatchesList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DownloadMatchResponse {
    matches?: MatchesDownloadResponseMatchesList | null;
    total?: number | null;
}
export declare const DownloadMatchResponse: S.Schema<DownloadMatchResponse>;
export type LogoMatchesGetRequestLogoIdList = Array<string>;
export declare const LogoMatchesGetRequestLogoIdList: S.Schema<LogoMatchesGetRequestLogoIdList>;
export interface GetLogoMatchRequest {
    accountId: string;
    limit?: string;
    logoId?: LogoMatchesGetRequestLogoIdList;
    offset?: string;
}
export declare const GetLogoMatchRequest: S.Schema<GetLogoMatchRequest>;
export type LogoMatchesGetResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const LogoMatchesGetResponseMatchesItemMap: S.Schema<LogoMatchesGetResponseMatchesItemMap>;
export type LogoMatchesGetResponseMatchesList = Array<LogoMatchesGetResponseMatchesItemMap>;
export declare const LogoMatchesGetResponseMatchesList: S.Schema<LogoMatchesGetResponseMatchesList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLogoMatchResponse {
    matches?: LogoMatchesGetResponseMatchesList | null;
    total?: number | null;
}
export declare const GetLogoMatchResponse: S.Schema<GetLogoMatchResponse>;
export interface GetMatchRequest {
    accountId: string;
    id?: string;
    includeDomainId?: boolean;
    limit?: number;
    offset?: number;
}
export declare const GetMatchRequest: S.Schema<GetMatchRequest>;
export type MatchesGetResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const MatchesGetResponseMatchesItemMap: S.Schema<MatchesGetResponseMatchesItemMap>;
export type MatchesGetResponseMatchesList = Array<MatchesGetResponseMatchesItemMap>;
export declare const MatchesGetResponseMatchesList: S.Schema<MatchesGetResponseMatchesList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMatchResponse {
    matches?: MatchesGetResponseMatchesList | null;
    total?: number | null;
}
export declare const GetMatchResponse: S.Schema<GetMatchResponse>;
export interface GetV2LogoRequest {
    accountId: string;
    /** Optional query ID to retrieve a specific logo query */
    id?: string;
    /** If true, include base64-encoded image data in the response */
    download?: string;
}
export declare const GetV2LogoRequest: S.Schema<GetV2LogoRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2LogoResponse {
    id: number;
    r2Path: string;
    similarityThreshold: number;
    tag: string;
    uploadedAt: string;
    /** MIME type of the image (only present when download=true) */
    contentType?: string | null;
    /** Base64-encoded image data (only present when download=true) */
    imageData?: string | null;
}
export declare const GetV2LogoResponse: S.Schema<GetV2LogoResponse>;
export type V2LogoMatchesGetRequestOrder = "asc" | "desc";
export declare const V2LogoMatchesGetRequestOrder: any;
export type V2LogoMatchesGetRequestOrderBy = "matchedAt" | "domain" | "similarityScore" | "registrar";
export declare const V2LogoMatchesGetRequestOrderBy: any;
export interface GetV2LogoMatchRequest {
    accountId: string;
    queryId: string;
    download?: string;
    limit?: string;
    offset?: string;
    /** Sort order. Options: 'asc' (ascending) or 'desc' (descending) */
    order?: V2LogoMatchesGetRequestOrder | (string & {});
    /** Column to sort by. Options: 'matchedAt', 'domain', 'similarityScore', or 'registrar' */
    orderBy?: V2LogoMatchesGetRequestOrderBy | (string & {});
}
export declare const GetV2LogoMatchRequest: S.Schema<GetV2LogoMatchRequest>;
export interface V2LogoMatchesGetResponseMatchesItem {
    id: number;
    domain: string;
    matchedAt: string;
    queryId: number;
    registrar: string;
    similarityScore: number;
    urlScanId: string;
    contentType?: string | null;
    imageData?: string | null;
}
export declare const V2LogoMatchesGetResponseMatchesItem: S.Schema<V2LogoMatchesGetResponseMatchesItem>;
export type V2LogoMatchesGetResponseMatchesList = Array<V2LogoMatchesGetResponseMatchesItem>;
export declare const V2LogoMatchesGetResponseMatchesList: S.Schema<V2LogoMatchesGetResponseMatchesList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2LogoMatchResponse {
    matches: V2LogoMatchesGetResponseMatchesList;
    total: number;
}
export declare const GetV2LogoMatchResponse: S.Schema<GetV2LogoMatchResponse>;
export type V2MatchesGetRequestQueryIdList = Array<string>;
export declare const V2MatchesGetRequestQueryIdList: S.Schema<V2MatchesGetRequestQueryIdList>;
export type V2MatchesGetRequestOrder = "asc" | "desc";
export declare const V2MatchesGetRequestOrder: any;
export type V2MatchesGetRequestOrderBy = "domain" | "first_seen" | "registrar";
export declare const V2MatchesGetRequestOrderBy: any;
export interface GetV2MatchRequest {
    accountId: string;
    /** Query ID or comma-separated list of Query IDs. When multiple IDs are provided, matches are deduplicated across queries and each match includes a match_details array with per-match query metadata and dismissed state. */
    queryId: V2MatchesGetRequestQueryIdList;
    /** Filter matches by domain name (substring match) */
    domainSearch?: string;
    includeDismissed?: string;
    includeDomainId?: string;
    limit?: string;
    offset?: string;
    /** Sort order. Options: 'asc' (ascending) or 'desc' (descending) */
    order?: V2MatchesGetRequestOrder | (string & {});
    /** Column to sort by. Options: 'domain', 'first_seen', or 'registrar' */
    orderBy?: V2MatchesGetRequestOrderBy | (string & {});
}
export declare const GetV2MatchRequest: S.Schema<GetV2MatchRequest>;
export interface V2MatchesGetResponseMatchesItemPublicScans {
    submissionId: string;
}
export declare const V2MatchesGetResponseMatchesItemPublicScans: S.Schema<V2MatchesGetResponseMatchesItemPublicScans>;
export interface V2MatchesGetResponseMatchesItemMatchDetailsItem {
    /** Individual dismissed state for this specific match. */
    dismissed: boolean;
    matchId: number;
    queryId: number;
    /** Tag associated with the query, if one exists. */
    queryTag: string;
}
export declare const V2MatchesGetResponseMatchesItemMatchDetailsItem: S.Schema<V2MatchesGetResponseMatchesItemMatchDetailsItem>;
export type V2MatchesGetResponseMatchesItemMatchDetailsList = Array<V2MatchesGetResponseMatchesItemMatchDetailsItem>;
export declare const V2MatchesGetResponseMatchesItemMatchDetailsList: S.Schema<V2MatchesGetResponseMatchesItemMatchDetailsList>;
export interface V2MatchesGetResponseMatchesItem {
    domain: string;
    firstSeen: string;
    publicScans: V2MatchesGetResponseMatchesItemPublicScans;
    registrar: string;
    scanStatus: string;
    scanSubmissionId: number;
    source: string;
    /** Whether the match is dismissed. Only present for single-query requests. For multi-query requests, use the dismissed field in each match_details entry. */
    dismissed?: boolean | null;
    /** Per-match detail objects with query metadata and individual dismissed state. Only present when multiple query_ids are requested. */
    matchDetails?: V2MatchesGetResponseMatchesItemMatchDetailsList | null;
}
export declare const V2MatchesGetResponseMatchesItem: S.Schema<V2MatchesGetResponseMatchesItem>;
export type V2MatchesGetResponseMatchesList = Array<V2MatchesGetResponseMatchesItem>;
export declare const V2MatchesGetResponseMatchesList: S.Schema<V2MatchesGetResponseMatchesList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2MatchResponse {
    matches: V2MatchesGetResponseMatchesList;
    total: number;
}
export declare const GetV2MatchResponse: S.Schema<GetV2MatchResponse>;
export interface GetV2QueryRequest {
    accountId: string;
    id?: string;
}
export declare const GetV2QueryRequest: S.Schema<GetV2QueryRequest>;
export interface V2QueriesGetResponseParametersStringMatchesItem {
    pattern: string;
}
export declare const V2QueriesGetResponseParametersStringMatchesItem: S.Schema<V2QueriesGetResponseParametersStringMatchesItem>;
export type V2QueriesGetResponseParametersStringMatchesList = Array<V2QueriesGetResponseParametersStringMatchesItem>;
export declare const V2QueriesGetResponseParametersStringMatchesList: S.Schema<V2QueriesGetResponseParametersStringMatchesList>;
export interface V2QueriesGetResponseParameters {
    stringMatches: V2QueriesGetResponseParametersStringMatchesList;
    maxTime?: string | null;
    minTime?: string | null;
}
export declare const V2QueriesGetResponseParameters: S.Schema<V2QueriesGetResponseParameters>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2QueryResponse {
    created: string;
    parameters: V2QueriesGetResponseParameters;
    queryId: number;
    queryTag: string;
    scan: boolean;
    updated: string;
}
export declare const GetV2QueryResponse: S.Schema<GetV2QueryResponse>;
export interface SubmitBrandProtectionRequest {
    accountId: string;
}
export declare const SubmitBrandProtectionRequest: S.Schema<SubmitBrandProtectionRequest>;
export type SubmitResponseSkippedUrlsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const SubmitResponseSkippedUrlsItemMap: S.Schema<SubmitResponseSkippedUrlsItemMap>;
export type SubmitResponseSkippedUrlsList = Array<SubmitResponseSkippedUrlsItemMap>;
export declare const SubmitResponseSkippedUrlsList: S.Schema<SubmitResponseSkippedUrlsList>;
export type SubmitResponseSubmittedUrlsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const SubmitResponseSubmittedUrlsItemMap: S.Schema<SubmitResponseSubmittedUrlsItemMap>;
export type SubmitResponseSubmittedUrlsList = Array<SubmitResponseSubmittedUrlsItemMap>;
export declare const SubmitResponseSubmittedUrlsList: S.Schema<SubmitResponseSubmittedUrlsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface SubmitBrandProtectionResponse {
    skippedUrls?: SubmitResponseSkippedUrlsList | null;
    submittedUrls?: SubmitResponseSubmittedUrlsList | null;
}
export declare const SubmitBrandProtectionResponse: S.Schema<SubmitBrandProtectionResponse>;
export interface UrlInfoBrandProtectionRequest {
    accountId: string;
}
export declare const UrlInfoBrandProtectionRequest: S.Schema<UrlInfoBrandProtectionRequest>;
export type UrlInfoResultItemMap = {
    [key: string]: unknown | undefined;
};
export declare const UrlInfoResultItemMap: S.Schema<UrlInfoResultItemMap>;
export type UrlInfoResultList = Array<UrlInfoResultItemMap>;
export declare const UrlInfoResultList: S.Schema<UrlInfoResultList>;
export interface UrlInfoBrandProtectionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UrlInfoResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const UrlInfoBrandProtectionResponse: S.Schema<UrlInfoBrandProtectionResponse>;
export type BulkQueryError = CloudflareOpError;
/** Return a success message after creating new saved string queries in bulk */
export declare const bulkQuery: API.OperationMethod<BulkQueryRequest, BulkQueryResponse, BulkQueryError, CloudflareOpContext>;
export type CreateLogoError = CloudflareOpError;
/** Return new saved logo queries created from image files */
export declare const createLogo: API.OperationMethod<CreateLogoRequest, CreateLogoResponse, CreateLogoError, CloudflareOpContext>;
export type CreateQueryError = CloudflareOpError;
/** Return a success message after creating new saved string queries */
export declare const createQuery: API.OperationMethod<CreateQueryRequest, CreateQueryResponse, CreateQueryError, CloudflareOpContext>;
export type CreateV2LogoError = CloudflareOpError;
/** Create a new saved brand protection logo query for visual similarity matching */
export declare const createV2Logo: API.OperationMethod<CreateV2LogoRequest, CreateV2LogoResponse, CreateV2LogoError, CloudflareOpContext>;
export type DeleteLogoError = CloudflareOpError;
/** Return a success message after deleting saved logo queries by ID */
export declare const deleteLogo: API.OperationMethod<DeleteLogoRequest, DeleteLogoResponse, DeleteLogoError, CloudflareOpContext>;
export type DeleteQueryError = CloudflareOpError;
/** Return a success message after deleting saved string queries by ID */
export declare const deleteQuery: API.OperationMethod<DeleteQueryRequest, DeleteQueryResponse, DeleteQueryError, CloudflareOpContext>;
export type DeleteV2LogoError = CloudflareOpError;
/** Delete a saved brand protection logo query. Returns 404 if the query ID doesn't exist. */
export declare const deleteV2Logo: API.OperationMethod<DeleteV2LogoRequest, DeleteV2LogoResponse, DeleteV2LogoError, CloudflareOpContext>;
export type DownloadLogoMatchError = CloudflareOpError;
/** Return matches as CSV for logo queries based on ID */
export declare const downloadLogoMatch: API.OperationMethod<DownloadLogoMatchRequest, DownloadLogoMatchResponse, DownloadLogoMatchError, CloudflareOpContext>;
export type DownloadMatchError = CloudflareOpError;
/** Return matches as CSV for string queries based on ID */
export declare const downloadMatch: API.OperationMethod<DownloadMatchRequest, DownloadMatchResponse, DownloadMatchError, CloudflareOpContext>;
export type GetLogoMatchError = CloudflareOpError;
/** Return matches for logo queries based on ID */
export declare const getLogoMatch: API.OperationMethod<GetLogoMatchRequest, GetLogoMatchResponse, GetLogoMatchError, CloudflareOpContext>;
export type GetMatchError = CloudflareOpError;
/** Return matches for string queries based on ID */
export declare const getMatch: API.OperationMethod<GetMatchRequest, GetMatchResponse, GetMatchError, CloudflareOpContext>;
export type GetV2LogoError = CloudflareOpError;
/** Get all saved brand protection logo queries for an account. Optionally specify id to get a single query. Set download=true to include base64-encoded image data. */
export declare const getV2Logo: API.OperationMethod<GetV2LogoRequest, GetV2LogoResponse, GetV2LogoError, CloudflareOpContext>;
export type GetV2LogoMatchError = CloudflareOpError;
/** Get paginated list of logo matches for a specific brand protection logo query */
export declare const getV2LogoMatch: API.OperationMethod<GetV2LogoMatchRequest, GetV2LogoMatchResponse, GetV2LogoMatchError, CloudflareOpContext>;
export type GetV2MatchError = CloudflareOpError;
/** Get paginated list of domain matches for one or more brand protection queries. When multiple query_ids are provided (comma-separated), matches are deduplicated across queries and each match includes a match_details array with per-match query metadata and individual dismissed state. */
export declare const getV2Match: API.OperationMethod<GetV2MatchRequest, GetV2MatchResponse, GetV2MatchError, CloudflareOpContext>;
export type GetV2QueryError = CloudflareOpError;
/** Get all saved brand protection queries for an account */
export declare const getV2Query: API.OperationMethod<GetV2QueryRequest, GetV2QueryResponse, GetV2QueryError, CloudflareOpContext>;
export type SubmitBrandProtectionError = CloudflareOpError;
/** Return new URL submissions */
export declare const submitBrandProtection: API.OperationMethod<SubmitBrandProtectionRequest, SubmitBrandProtectionResponse, SubmitBrandProtectionError, CloudflareOpContext>;
export type UrlInfoBrandProtectionError = CloudflareOpError;
/** Return submitted URLs based on ID */
export declare const urlInfoBrandProtection: API.PaginatedOperationMethod<UrlInfoBrandProtectionRequest, UrlInfoBrandProtectionResponse, UrlInfoBrandProtectionError, CloudflareOpContext, UrlInfoResultItemMap>;
//# sourceMappingURL=brand_protection.d.ts.map