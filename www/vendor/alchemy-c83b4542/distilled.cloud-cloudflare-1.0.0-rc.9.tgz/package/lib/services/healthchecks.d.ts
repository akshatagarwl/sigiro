import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HealthcheckAlreadyExists_base: S.Class<HealthcheckAlreadyExists, S.TaggedStruct<"HealthcheckAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HealthcheckAlreadyExists extends /*@__PURE__*/ HealthcheckAlreadyExists_base {
}
declare const HealthcheckNotFound_base: S.Class<HealthcheckNotFound, S.TaggedStruct<"HealthcheckNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HealthcheckNotFound extends /*@__PURE__*/ HealthcheckNotFound_base {
}
export type CreateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const CreateRequestCheckRegionsItem: any;
export type CreateRequestCheckRegionsList = Array<CreateRequestCheckRegionsItem | (string & {})>;
export declare const CreateRequestCheckRegionsList: S.Schema<CreateRequestCheckRegionsList>;
export type CreateRequestHttpConfigExpectedCodesList = Array<string>;
export declare const CreateRequestHttpConfigExpectedCodesList: S.Schema<CreateRequestHttpConfigExpectedCodesList>;
export type CreateRequestHttpConfigHeaderValueList = Array<string>;
export declare const CreateRequestHttpConfigHeaderValueList: S.Schema<CreateRequestHttpConfigHeaderValueList>;
export type CreateRequestHttpConfigHeaderMap = {
    [key: string]: CreateRequestHttpConfigHeaderValueList | undefined;
};
export declare const CreateRequestHttpConfigHeaderMap: S.Schema<CreateRequestHttpConfigHeaderMap>;
export type CreateRequestHttpConfigMethod = "GET" | "HEAD";
export declare const CreateRequestHttpConfigMethod: any;
export interface CreateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: CreateRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const CreateRequestHttpConfig: S.Schema<CreateRequestHttpConfig>;
export type CreateRequestTcpConfigMethod = "connection_established";
export declare const CreateRequestTcpConfigMethod: any;
export interface CreateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const CreateRequestTcpConfig: S.Schema<CreateRequestTcpConfig>;
export interface CreateHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const CreateHealthcheckRequest: S.Schema<CreateHealthcheckRequest>;
export type CreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const CreateResponseCheckRegionsItem: any;
export type CreateResponseCheckRegionsList = Array<CreateResponseCheckRegionsItem>;
export declare const CreateResponseCheckRegionsList: S.Schema<CreateResponseCheckRegionsList>;
export type CreateResponseHttpConfigExpectedCodesList = Array<string>;
export declare const CreateResponseHttpConfigExpectedCodesList: S.Schema<CreateResponseHttpConfigExpectedCodesList>;
export type CreateResponseHttpConfigHeaderValueList = Array<string>;
export declare const CreateResponseHttpConfigHeaderValueList: S.Schema<CreateResponseHttpConfigHeaderValueList>;
export type CreateResponseHttpConfigHeaderMap = {
    [key: string]: CreateResponseHttpConfigHeaderValueList | undefined;
};
export declare const CreateResponseHttpConfigHeaderMap: S.Schema<CreateResponseHttpConfigHeaderMap>;
export type CreateResponseHttpConfigMethod = "GET" | "HEAD";
export declare const CreateResponseHttpConfigMethod: any;
export interface CreateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: CreateResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const CreateResponseHttpConfig: S.Schema<CreateResponseHttpConfig>;
export type CreateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const CreateResponseStatus: any;
export type CreateResponseTcpConfigMethod = "connection_established";
export declare const CreateResponseTcpConfigMethod: any;
export interface CreateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const CreateResponseTcpConfig: S.Schema<CreateResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: CreateResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const CreateHealthcheckResponse: S.Schema<CreateHealthcheckResponse>;
export type PreviewsCreateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PreviewsCreateRequestCheckRegionsItem: any;
export type PreviewsCreateRequestCheckRegionsList = Array<PreviewsCreateRequestCheckRegionsItem | (string & {})>;
export declare const PreviewsCreateRequestCheckRegionsList: S.Schema<PreviewsCreateRequestCheckRegionsList>;
export type PreviewsCreateRequestHttpConfigExpectedCodesList = Array<string>;
export declare const PreviewsCreateRequestHttpConfigExpectedCodesList: S.Schema<PreviewsCreateRequestHttpConfigExpectedCodesList>;
export type PreviewsCreateRequestHttpConfigHeaderValueList = Array<string>;
export declare const PreviewsCreateRequestHttpConfigHeaderValueList: S.Schema<PreviewsCreateRequestHttpConfigHeaderValueList>;
export type PreviewsCreateRequestHttpConfigHeaderMap = {
    [key: string]: PreviewsCreateRequestHttpConfigHeaderValueList | undefined;
};
export declare const PreviewsCreateRequestHttpConfigHeaderMap: S.Schema<PreviewsCreateRequestHttpConfigHeaderMap>;
export type PreviewsCreateRequestHttpConfigMethod = "GET" | "HEAD";
export declare const PreviewsCreateRequestHttpConfigMethod: any;
export interface PreviewsCreateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsCreateRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsCreateRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: PreviewsCreateRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const PreviewsCreateRequestHttpConfig: S.Schema<PreviewsCreateRequestHttpConfig>;
export type PreviewsCreateRequestTcpConfigMethod = "connection_established";
export declare const PreviewsCreateRequestTcpConfigMethod: any;
export interface PreviewsCreateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsCreateRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const PreviewsCreateRequestTcpConfig: S.Schema<PreviewsCreateRequestTcpConfig>;
export interface CreatePreviewRequest {
    /** Identifier */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsCreateRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsCreateRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsCreateRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const CreatePreviewRequest: S.Schema<CreatePreviewRequest>;
export type PreviewsCreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PreviewsCreateResponseCheckRegionsItem: any;
export type PreviewsCreateResponseCheckRegionsList = Array<PreviewsCreateResponseCheckRegionsItem>;
export declare const PreviewsCreateResponseCheckRegionsList: S.Schema<PreviewsCreateResponseCheckRegionsList>;
export type PreviewsCreateResponseHttpConfigExpectedCodesList = Array<string>;
export declare const PreviewsCreateResponseHttpConfigExpectedCodesList: S.Schema<PreviewsCreateResponseHttpConfigExpectedCodesList>;
export type PreviewsCreateResponseHttpConfigHeaderValueList = Array<string>;
export declare const PreviewsCreateResponseHttpConfigHeaderValueList: S.Schema<PreviewsCreateResponseHttpConfigHeaderValueList>;
export type PreviewsCreateResponseHttpConfigHeaderMap = {
    [key: string]: PreviewsCreateResponseHttpConfigHeaderValueList | undefined;
};
export declare const PreviewsCreateResponseHttpConfigHeaderMap: S.Schema<PreviewsCreateResponseHttpConfigHeaderMap>;
export type PreviewsCreateResponseHttpConfigMethod = "GET" | "HEAD";
export declare const PreviewsCreateResponseHttpConfigMethod: any;
export interface PreviewsCreateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsCreateResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsCreateResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: PreviewsCreateResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const PreviewsCreateResponseHttpConfig: S.Schema<PreviewsCreateResponseHttpConfig>;
export type PreviewsCreateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const PreviewsCreateResponseStatus: any;
export type PreviewsCreateResponseTcpConfigMethod = "connection_established";
export declare const PreviewsCreateResponseTcpConfigMethod: any;
export interface PreviewsCreateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsCreateResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const PreviewsCreateResponseTcpConfig: S.Schema<PreviewsCreateResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePreviewResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsCreateResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsCreateResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: PreviewsCreateResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsCreateResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const CreatePreviewResponse: S.Schema<CreatePreviewResponse>;
export interface DeleteHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export declare const DeleteHealthcheckRequest: S.Schema<DeleteHealthcheckRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHealthcheckResponse {
    /** Identifier */
    id?: string | null;
}
export declare const DeleteHealthcheckResponse: S.Schema<DeleteHealthcheckResponse>;
export interface DeletePreviewRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export declare const DeletePreviewRequest: S.Schema<DeletePreviewRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePreviewResponse {
    /** Identifier */
    id?: string | null;
}
export declare const DeletePreviewResponse: S.Schema<DeletePreviewResponse>;
export interface GetHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export declare const GetHealthcheckRequest: S.Schema<GetHealthcheckRequest>;
export type GetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const GetResponseCheckRegionsItem: any;
export type GetResponseCheckRegionsList = Array<GetResponseCheckRegionsItem>;
export declare const GetResponseCheckRegionsList: S.Schema<GetResponseCheckRegionsList>;
export type GetResponseHttpConfigExpectedCodesList = Array<string>;
export declare const GetResponseHttpConfigExpectedCodesList: S.Schema<GetResponseHttpConfigExpectedCodesList>;
export type GetResponseHttpConfigHeaderValueList = Array<string>;
export declare const GetResponseHttpConfigHeaderValueList: S.Schema<GetResponseHttpConfigHeaderValueList>;
export type GetResponseHttpConfigHeaderMap = {
    [key: string]: GetResponseHttpConfigHeaderValueList | undefined;
};
export declare const GetResponseHttpConfigHeaderMap: S.Schema<GetResponseHttpConfigHeaderMap>;
export type GetResponseHttpConfigMethod = "GET" | "HEAD";
export declare const GetResponseHttpConfigMethod: any;
export interface GetResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: GetResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: GetResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: GetResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const GetResponseHttpConfig: S.Schema<GetResponseHttpConfig>;
export type GetResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const GetResponseStatus: any;
export type GetResponseTcpConfigMethod = "connection_established";
export declare const GetResponseTcpConfigMethod: any;
export interface GetResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: GetResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const GetResponseTcpConfig: S.Schema<GetResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: GetResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: GetResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: GetResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: GetResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const GetHealthcheckResponse: S.Schema<GetHealthcheckResponse>;
export interface GetPreviewRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export declare const GetPreviewRequest: S.Schema<GetPreviewRequest>;
export type PreviewsGetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const PreviewsGetResponseCheckRegionsItem: any;
export type PreviewsGetResponseCheckRegionsList = Array<PreviewsGetResponseCheckRegionsItem>;
export declare const PreviewsGetResponseCheckRegionsList: S.Schema<PreviewsGetResponseCheckRegionsList>;
export type PreviewsGetResponseHttpConfigExpectedCodesList = Array<string>;
export declare const PreviewsGetResponseHttpConfigExpectedCodesList: S.Schema<PreviewsGetResponseHttpConfigExpectedCodesList>;
export type PreviewsGetResponseHttpConfigHeaderValueList = Array<string>;
export declare const PreviewsGetResponseHttpConfigHeaderValueList: S.Schema<PreviewsGetResponseHttpConfigHeaderValueList>;
export type PreviewsGetResponseHttpConfigHeaderMap = {
    [key: string]: PreviewsGetResponseHttpConfigHeaderValueList | undefined;
};
export declare const PreviewsGetResponseHttpConfigHeaderMap: S.Schema<PreviewsGetResponseHttpConfigHeaderMap>;
export type PreviewsGetResponseHttpConfigMethod = "GET" | "HEAD";
export declare const PreviewsGetResponseHttpConfigMethod: any;
export interface PreviewsGetResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsGetResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsGetResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: PreviewsGetResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const PreviewsGetResponseHttpConfig: S.Schema<PreviewsGetResponseHttpConfig>;
export type PreviewsGetResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const PreviewsGetResponseStatus: any;
export type PreviewsGetResponseTcpConfigMethod = "connection_established";
export declare const PreviewsGetResponseTcpConfigMethod: any;
export interface PreviewsGetResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsGetResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const PreviewsGetResponseTcpConfig: S.Schema<PreviewsGetResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPreviewResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsGetResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsGetResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: PreviewsGetResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsGetResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const GetPreviewResponse: S.Schema<GetPreviewResponse>;
export interface ListHealthchecksRequest {
    /** Identifier */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number;
}
export declare const ListHealthchecksRequest: S.Schema<ListHealthchecksRequest>;
export type ListResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const ListResultItemCheckRegionsItem: any;
export type ListResultItemCheckRegionsList = Array<ListResultItemCheckRegionsItem>;
export declare const ListResultItemCheckRegionsList: S.Schema<ListResultItemCheckRegionsList>;
export type ListResultItemHttpConfigExpectedCodesList = Array<string>;
export declare const ListResultItemHttpConfigExpectedCodesList: S.Schema<ListResultItemHttpConfigExpectedCodesList>;
export type ListResultItemHttpConfigHeaderValueList = Array<string>;
export declare const ListResultItemHttpConfigHeaderValueList: S.Schema<ListResultItemHttpConfigHeaderValueList>;
export type ListResultItemHttpConfigHeaderMap = {
    [key: string]: ListResultItemHttpConfigHeaderValueList | undefined;
};
export declare const ListResultItemHttpConfigHeaderMap: S.Schema<ListResultItemHttpConfigHeaderMap>;
export type ListResultItemHttpConfigMethod = "GET" | "HEAD";
export declare const ListResultItemHttpConfigMethod: any;
export interface ListResultItemHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: ListResultItemHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: ListResultItemHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: ListResultItemHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const ListResultItemHttpConfig: S.Schema<ListResultItemHttpConfig>;
export type ListResultItemStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const ListResultItemStatus: any;
export type ListResultItemTcpConfigMethod = "connection_established";
export declare const ListResultItemTcpConfigMethod: any;
export interface ListResultItemTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: ListResultItemTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const ListResultItemTcpConfig: S.Schema<ListResultItemTcpConfig>;
export interface ListResultItem {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: ListResultItemCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: ListResultItemHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: ListResultItemStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: ListResultItemTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListHealthchecksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListHealthchecksResponse: S.Schema<ListHealthchecksResponse>;
export type EditRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const EditRequestCheckRegionsItem: any;
export type EditRequestCheckRegionsList = Array<EditRequestCheckRegionsItem | (string & {})>;
export declare const EditRequestCheckRegionsList: S.Schema<EditRequestCheckRegionsList>;
export type EditRequestHttpConfigExpectedCodesList = Array<string>;
export declare const EditRequestHttpConfigExpectedCodesList: S.Schema<EditRequestHttpConfigExpectedCodesList>;
export type EditRequestHttpConfigHeaderValueList = Array<string>;
export declare const EditRequestHttpConfigHeaderValueList: S.Schema<EditRequestHttpConfigHeaderValueList>;
export type EditRequestHttpConfigHeaderMap = {
    [key: string]: EditRequestHttpConfigHeaderValueList | undefined;
};
export declare const EditRequestHttpConfigHeaderMap: S.Schema<EditRequestHttpConfigHeaderMap>;
export type EditRequestHttpConfigMethod = "GET" | "HEAD";
export declare const EditRequestHttpConfigMethod: any;
export interface EditRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: EditRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const EditRequestHttpConfig: S.Schema<EditRequestHttpConfig>;
export type EditRequestTcpConfigMethod = "connection_established";
export declare const EditRequestTcpConfigMethod: any;
export interface EditRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const EditRequestTcpConfig: S.Schema<EditRequestTcpConfig>;
export interface PatchHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const PatchHealthcheckRequest: S.Schema<PatchHealthcheckRequest>;
export type EditResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const EditResponseCheckRegionsItem: any;
export type EditResponseCheckRegionsList = Array<EditResponseCheckRegionsItem>;
export declare const EditResponseCheckRegionsList: S.Schema<EditResponseCheckRegionsList>;
export type EditResponseHttpConfigExpectedCodesList = Array<string>;
export declare const EditResponseHttpConfigExpectedCodesList: S.Schema<EditResponseHttpConfigExpectedCodesList>;
export type EditResponseHttpConfigHeaderValueList = Array<string>;
export declare const EditResponseHttpConfigHeaderValueList: S.Schema<EditResponseHttpConfigHeaderValueList>;
export type EditResponseHttpConfigHeaderMap = {
    [key: string]: EditResponseHttpConfigHeaderValueList | undefined;
};
export declare const EditResponseHttpConfigHeaderMap: S.Schema<EditResponseHttpConfigHeaderMap>;
export type EditResponseHttpConfigMethod = "GET" | "HEAD";
export declare const EditResponseHttpConfigMethod: any;
export interface EditResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: EditResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const EditResponseHttpConfig: S.Schema<EditResponseHttpConfig>;
export type EditResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const EditResponseStatus: any;
export type EditResponseTcpConfigMethod = "connection_established";
export declare const EditResponseTcpConfigMethod: any;
export interface EditResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const EditResponseTcpConfig: S.Schema<EditResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: EditResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const PatchHealthcheckResponse: S.Schema<PatchHealthcheckResponse>;
export type UpdateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const UpdateRequestCheckRegionsItem: any;
export type UpdateRequestCheckRegionsList = Array<UpdateRequestCheckRegionsItem | (string & {})>;
export declare const UpdateRequestCheckRegionsList: S.Schema<UpdateRequestCheckRegionsList>;
export type UpdateRequestHttpConfigExpectedCodesList = Array<string>;
export declare const UpdateRequestHttpConfigExpectedCodesList: S.Schema<UpdateRequestHttpConfigExpectedCodesList>;
export type UpdateRequestHttpConfigHeaderValueList = Array<string>;
export declare const UpdateRequestHttpConfigHeaderValueList: S.Schema<UpdateRequestHttpConfigHeaderValueList>;
export type UpdateRequestHttpConfigHeaderMap = {
    [key: string]: UpdateRequestHttpConfigHeaderValueList | undefined;
};
export declare const UpdateRequestHttpConfigHeaderMap: S.Schema<UpdateRequestHttpConfigHeaderMap>;
export type UpdateRequestHttpConfigMethod = "GET" | "HEAD";
export declare const UpdateRequestHttpConfigMethod: any;
export interface UpdateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateRequestHttpConfigExpectedCodesList;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateRequestHttpConfigHeaderMap;
    /** The HTTP method to use for the health check. */
    method?: UpdateRequestHttpConfigMethod | (string & {});
    /** The endpoint path to health check against. */
    path?: string;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number;
}
export declare const UpdateRequestHttpConfig: S.Schema<UpdateRequestHttpConfig>;
export type UpdateRequestTcpConfigMethod = "connection_established";
export declare const UpdateRequestTcpConfigMethod: any;
export interface UpdateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateRequestTcpConfigMethod | (string & {});
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number;
}
export declare const UpdateRequestTcpConfig: S.Schema<UpdateRequestTcpConfig>;
export interface UpdateHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateRequestCheckRegionsList;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number;
    /** A human-readable description of the health check. */
    description?: string;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateRequestHttpConfig;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateRequestTcpConfig;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string;
}
export declare const UpdateHealthcheckRequest: S.Schema<UpdateHealthcheckRequest>;
export type UpdateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export declare const UpdateResponseCheckRegionsItem: any;
export type UpdateResponseCheckRegionsList = Array<UpdateResponseCheckRegionsItem>;
export declare const UpdateResponseCheckRegionsList: S.Schema<UpdateResponseCheckRegionsList>;
export type UpdateResponseHttpConfigExpectedCodesList = Array<string>;
export declare const UpdateResponseHttpConfigExpectedCodesList: S.Schema<UpdateResponseHttpConfigExpectedCodesList>;
export type UpdateResponseHttpConfigHeaderValueList = Array<string>;
export declare const UpdateResponseHttpConfigHeaderValueList: S.Schema<UpdateResponseHttpConfigHeaderValueList>;
export type UpdateResponseHttpConfigHeaderMap = {
    [key: string]: UpdateResponseHttpConfigHeaderValueList | undefined;
};
export declare const UpdateResponseHttpConfigHeaderMap: S.Schema<UpdateResponseHttpConfigHeaderMap>;
export type UpdateResponseHttpConfigMethod = "GET" | "HEAD";
export declare const UpdateResponseHttpConfigMethod: any;
export interface UpdateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateResponseHttpConfigExpectedCodesList | null;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateResponseHttpConfigHeaderMap | null;
    /** The HTTP method to use for the health check. */
    method?: UpdateResponseHttpConfigMethod | null;
    /** The endpoint path to health check against. */
    path?: string | null;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null;
}
export declare const UpdateResponseHttpConfig: S.Schema<UpdateResponseHttpConfig>;
export type UpdateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export declare const UpdateResponseStatus: any;
export type UpdateResponseTcpConfigMethod = "connection_established";
export declare const UpdateResponseTcpConfigMethod: any;
export interface UpdateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateResponseTcpConfigMethod | null;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null;
}
export declare const UpdateResponseTcpConfig: S.Schema<UpdateResponseTcpConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateHealthcheckResponse {
    /** Identifier */
    id?: string | null;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateResponseCheckRegionsList | null;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null;
    createdOn?: string | null;
    /** A human-readable description of the health check. */
    description?: string | null;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateResponseHttpConfig | null;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null;
    modifiedOn?: string | null;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null;
    /** The current status of the origin server according to the health check. */
    status?: UpdateResponseStatus | null;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateResponseTcpConfig | null;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null;
}
export declare const UpdateHealthcheckResponse: S.Schema<UpdateHealthcheckResponse>;
export type CreateHealthcheckError = HealthcheckAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new health check. */
export declare const createHealthcheck: API.OperationMethod<CreateHealthcheckRequest, CreateHealthcheckResponse, CreateHealthcheckError, CloudflareOpContext>;
export type CreatePreviewError = CloudflareOpError;
/** Create a new preview health check. */
export declare const createPreview: API.OperationMethod<CreatePreviewRequest, CreatePreviewResponse, CreatePreviewError, CloudflareOpContext>;
export type DeleteHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Delete a health check. */
export declare const deleteHealthcheck: API.OperationMethod<DeleteHealthcheckRequest, DeleteHealthcheckResponse, DeleteHealthcheckError, CloudflareOpContext>;
export type DeletePreviewError = CloudflareOpError;
/** Delete a health check. */
export declare const deletePreview: API.OperationMethod<DeletePreviewRequest, DeletePreviewResponse, DeletePreviewError, CloudflareOpContext>;
export type GetHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured health check. */
export declare const getHealthcheck: API.OperationMethod<GetHealthcheckRequest, GetHealthcheckResponse, GetHealthcheckError, CloudflareOpContext>;
export type GetPreviewError = CloudflareOpError;
/** Fetch a single configured health check preview. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, GetPreviewResponse, GetPreviewError, CloudflareOpContext>;
export type ListHealthchecksError = Forbidden | CloudflareOpError;
/** List configured health checks. */
export declare const listHealthchecks: API.PaginatedOperationMethod<ListHealthchecksRequest, ListHealthchecksResponse, ListHealthchecksError, CloudflareOpContext, ListResultItem>;
export type PatchHealthcheckError = CloudflareOpError;
/** Patch a configured health check. */
export declare const patchHealthcheck: API.OperationMethod<PatchHealthcheckRequest, PatchHealthcheckResponse, PatchHealthcheckError, CloudflareOpContext>;
export type UpdateHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Update a configured health check. */
export declare const updateHealthcheck: API.OperationMethod<UpdateHealthcheckRequest, UpdateHealthcheckResponse, UpdateHealthcheckError, CloudflareOpContext>;
//# sourceMappingURL=healthchecks.d.ts.map