import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotEntitled_base: S.Class<NotEntitled, S.TaggedStruct<"NotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotEntitled extends /*@__PURE__*/ NotEntitled_base {
}
declare const PolicyNotFound_base: S.Class<PolicyNotFound, S.TaggedStruct<"PolicyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PolicyNotFound extends /*@__PURE__*/ PolicyNotFound_base {
}
declare const PolicyQuotaExceeded_base: S.Class<PolicyQuotaExceeded, S.TaggedStruct<"PolicyQuotaExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PolicyQuotaExceeded extends /*@__PURE__*/ PolicyQuotaExceeded_base {
}
export type PoliciesCreateRequestAction = "allow" | "log" | "add_reporting_directives";
export declare const PoliciesCreateRequestAction: any;
export interface CreatePolicyRequest {
    /** Identifier */
    zoneId: string;
    /** The action to take if the expression matches */
    action: PoliciesCreateRequestAction | (string & {});
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export declare const CreatePolicyRequest: S.Schema<CreatePolicyRequest>;
export type PoliciesCreateResponseAction = "allow" | "log" | "add_reporting_directives";
export declare const PoliciesCreateResponseAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePolicyResponse {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesCreateResponseAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export declare const CreatePolicyResponse: S.Schema<CreatePolicyResponse>;
export interface DeletePolicyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    policyId: string;
}
export declare const DeletePolicyRequest: S.Schema<DeletePolicyRequest>;
export interface DeletePolicyResponse {
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface GetConnectionRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    connectionId: string;
}
export declare const GetConnectionRequest: S.Schema<GetConnectionRequest>;
export type ConnectionsGetResponseMaliciousDomainCategoriesList = Array<string>;
export declare const ConnectionsGetResponseMaliciousDomainCategoriesList: S.Schema<ConnectionsGetResponseMaliciousDomainCategoriesList>;
export type ConnectionsGetResponseMaliciousUrlCategoriesList = Array<string>;
export declare const ConnectionsGetResponseMaliciousUrlCategoriesList: S.Schema<ConnectionsGetResponseMaliciousUrlCategoriesList>;
export type ConnectionsGetResponsePageUrlsList = Array<string>;
export declare const ConnectionsGetResponsePageUrlsList: S.Schema<ConnectionsGetResponsePageUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectionResponse {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    domainReportedMalicious?: boolean | null;
    firstPageUrl?: string | null;
    maliciousDomainCategories?: ConnectionsGetResponseMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ConnectionsGetResponseMaliciousUrlCategoriesList | null;
    pageUrls?: ConnectionsGetResponsePageUrlsList | null;
    urlReportedMalicious?: boolean | null;
}
export declare const GetConnectionResponse: S.Schema<GetConnectionResponse>;
export interface GetCookyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    cookieId: string;
}
export declare const GetCookyRequest: S.Schema<GetCookyRequest>;
export type CookiesGetResponseType = "first_party" | "unknown";
export declare const CookiesGetResponseType: any;
export type CookiesGetResponsePageUrlsList = Array<string>;
export declare const CookiesGetResponsePageUrlsList: S.Schema<CookiesGetResponsePageUrlsList>;
export type CookiesGetResponseSameSiteAttribute = "lax" | "strict" | "none";
export declare const CookiesGetResponseSameSiteAttribute: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCookyResponse {
    /** Identifier */
    id: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    name: string;
    type: CookiesGetResponseType;
    domainAttribute?: string | null;
    expiresAttribute?: string | null;
    httpOnlyAttribute?: boolean | null;
    maxAgeAttribute?: number | null;
    pageUrls?: CookiesGetResponsePageUrlsList | null;
    pathAttribute?: string | null;
    sameSiteAttribute?: CookiesGetResponseSameSiteAttribute | null;
    secureAttribute?: boolean | null;
}
export declare const GetCookyResponse: S.Schema<GetCookyResponse>;
export interface GetPageShieldRequest {
    /** Identifier */
    zoneId: string;
}
export declare const GetPageShieldRequest: S.Schema<GetPageShieldRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPageShieldResponse {
    /** When true, indicates that Page Shield is enabled. */
    enabled: boolean;
    /** The timestamp of when Page Shield was last updated. */
    updatedAt: string;
    /** When true, CSP reports will be sent to https://csp-reporting.cloudflare.com/cdn-cgi/script_monitor/report */
    useCloudflareReportingEndpoint: boolean;
    /** When true, the paths associated with connections URLs will also be analyzed. */
    useConnectionUrlPath: boolean;
}
export declare const GetPageShieldResponse: S.Schema<GetPageShieldResponse>;
export interface GetPolicyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    policyId: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export type PoliciesGetResponseAction = "allow" | "log" | "add_reporting_directives";
export declare const PoliciesGetResponseAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPolicyResponse {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesGetResponseAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export interface GetScriptRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    scriptId: string;
}
export declare const GetScriptRequest: S.Schema<GetScriptRequest>;
export type ScriptsGetResponseMaliciousDomainCategoriesList = Array<string>;
export declare const ScriptsGetResponseMaliciousDomainCategoriesList: S.Schema<ScriptsGetResponseMaliciousDomainCategoriesList>;
export type ScriptsGetResponseMaliciousUrlCategoriesList = Array<string>;
export declare const ScriptsGetResponseMaliciousUrlCategoriesList: S.Schema<ScriptsGetResponseMaliciousUrlCategoriesList>;
export type ScriptsGetResponsePageUrlsList = Array<string>;
export declare const ScriptsGetResponsePageUrlsList: S.Schema<ScriptsGetResponsePageUrlsList>;
export interface ScriptsGetResponseVersionsItem {
    /** The cryptomining score of the JavaScript content. */
    cryptominingScore?: number | null;
    /** The dataflow score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    dataflowScore?: number | null;
    /** The timestamp of when the script was last fetched. */
    fetchedAt?: string | null;
    /** The computed hash of the analyzed script. */
    hash?: string | null;
    /** The integrity score of the JavaScript content. */
    jsIntegrityScore?: number | null;
    /** The magecart score of the JavaScript content. */
    magecartScore?: number | null;
    /** The malware score of the JavaScript content. */
    malwareScore?: number | null;
    /** The obfuscation score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    obfuscationScore?: number | null;
}
export declare const ScriptsGetResponseVersionsItem: S.Schema<ScriptsGetResponseVersionsItem>;
export type ScriptsGetResponseVersionsList = Array<ScriptsGetResponseVersionsItem>;
export declare const ScriptsGetResponseVersionsList: S.Schema<ScriptsGetResponseVersionsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptResponse {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    /** The cryptomining score of the JavaScript content. */
    cryptominingScore?: number | null;
    /** The dataflow score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    dataflowScore?: number | null;
    domainReportedMalicious?: boolean | null;
    /** The timestamp of when the script was last fetched. */
    fetchedAt?: string | null;
    firstPageUrl?: string | null;
    /** The computed hash of the analyzed script. */
    hash?: string | null;
    /** The integrity score of the JavaScript content. */
    jsIntegrityScore?: number | null;
    /** The magecart score of the JavaScript content. */
    magecartScore?: number | null;
    maliciousDomainCategories?: ScriptsGetResponseMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ScriptsGetResponseMaliciousUrlCategoriesList | null;
    /** The malware score of the JavaScript content. */
    malwareScore?: number | null;
    /** The obfuscation score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    obfuscationScore?: number | null;
    pageUrls?: ScriptsGetResponsePageUrlsList | null;
    urlReportedMalicious?: boolean | null;
    versions?: ScriptsGetResponseVersionsList | null;
}
export declare const GetScriptResponse: S.Schema<GetScriptResponse>;
export type ConnectionsListRequestDirection = "asc" | "desc";
export declare const ConnectionsListRequestDirection: any;
export type ConnectionsListRequestExport = "csv";
export declare const ConnectionsListRequestExport: any;
export type ConnectionsListRequestOrderBy = "first_seen_at" | "last_seen_at";
export declare const ConnectionsListRequestOrderBy: any;
export interface ListConnectionsRequest {
    /** Identifier */
    zoneId: string;
    /** The direction used to sort returned connections. */
    direction?: ConnectionsListRequestDirection | (string & {});
    /** When true, excludes connections seen in a `/cdn-cgi` path from the returned connections. The default value is true. */
    excludeCdnCgi?: boolean;
    /** Excludes connections whose URL contains one of the URL-encoded URLs separated by commas. */
    excludeUrls?: string;
    /** Export the list of connections as a file, limited to 50000 entries. */
    export?: ConnectionsListRequestExport | (string & {});
    /** Includes connections that match one or more URL-encoded hostnames separated by commas. */
    hosts?: string;
    /** The field used to sort returned connections. */
    orderBy?: ConnectionsListRequestOrderBy | (string & {});
    /** The current page number of the paginated results. */
    page?: string;
    /** Includes connections that match one or more page URLs (separated by commas) where they were last seen */
    pageUrl?: string;
    /** The number of results per page. */
    perPage?: number;
    /** When true, malicious connections appear first in the returned connections. */
    prioritizeMalicious?: boolean;
    /** Filters the returned connections using a comma-separated list of connection statuses. Accepted values: `active`, `infrequent`, and `inactive`. The default value is `active`. */
    status?: string;
    /** Includes connections whose URL contain one or more URL-encoded URLs separated by commas. */
    urls?: string;
}
export declare const ListConnectionsRequest: S.Schema<ListConnectionsRequest>;
export type ConnectionsListResultItemMaliciousDomainCategoriesList = Array<string>;
export declare const ConnectionsListResultItemMaliciousDomainCategoriesList: S.Schema<ConnectionsListResultItemMaliciousDomainCategoriesList>;
export type ConnectionsListResultItemMaliciousUrlCategoriesList = Array<string>;
export declare const ConnectionsListResultItemMaliciousUrlCategoriesList: S.Schema<ConnectionsListResultItemMaliciousUrlCategoriesList>;
export type ConnectionsListResultItemPageUrlsList = Array<string>;
export declare const ConnectionsListResultItemPageUrlsList: S.Schema<ConnectionsListResultItemPageUrlsList>;
export interface ConnectionsListResultItem {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    domainReportedMalicious?: boolean | null;
    firstPageUrl?: string | null;
    maliciousDomainCategories?: ConnectionsListResultItemMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ConnectionsListResultItemMaliciousUrlCategoriesList | null;
    pageUrls?: ConnectionsListResultItemPageUrlsList | null;
    urlReportedMalicious?: boolean | null;
}
export declare const ConnectionsListResultItem: S.Schema<ConnectionsListResultItem>;
export type ConnectionsListResultList = Array<ConnectionsListResultItem>;
export declare const ConnectionsListResultList: S.Schema<ConnectionsListResultList>;
export interface ListConnectionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConnectionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListConnectionsResponse: S.Schema<ListConnectionsResponse>;
export type CookiesListRequestDirection = "asc" | "desc";
export declare const CookiesListRequestDirection: any;
export type CookiesListRequestExport = "csv";
export declare const CookiesListRequestExport: any;
export type CookiesListRequestOrderBy = "first_seen_at" | "last_seen_at";
export declare const CookiesListRequestOrderBy: any;
export type CookiesListRequestSameSite = "lax" | "strict" | "none";
export declare const CookiesListRequestSameSite: any;
export type CookiesListRequestType = "first_party" | "unknown";
export declare const CookiesListRequestType: any;
export interface ListCookiesRequest {
    /** Identifier */
    zoneId: string;
    /** The direction used to sort returned cookies.' */
    direction?: CookiesListRequestDirection | (string & {});
    /** Filters the returned cookies that match the specified domain attribute */
    domain?: string;
    /** Export the list of cookies as a file, limited to 50000 entries. */
    export?: CookiesListRequestExport | (string & {});
    /** Includes cookies that match one or more URL-encoded hostnames separated by commas. */
    hosts?: string;
    /** Filters the returned cookies that are set with HttpOnly */
    httpOnly?: boolean;
    /** Filters the returned cookies that match the specified name. */
    name?: string;
    /** The field used to sort returned cookies. */
    orderBy?: CookiesListRequestOrderBy | (string & {});
    /** The current page number of the paginated results. */
    page?: string;
    /** Includes connections that match one or more page URLs (separated by commas) where they were last seen */
    pageUrl?: string;
    /** Filters the returned cookies that match the specified path attribute */
    path?: string;
    /** The number of results per page. */
    perPage?: number;
    /** Filters the returned cookies that match the specified same_site attribute */
    sameSite?: CookiesListRequestSameSite | (string & {});
    /** Filters the returned cookies that are set with Secure */
    secure?: boolean;
    /** Filters the returned cookies that match the specified type attribute */
    type?: CookiesListRequestType | (string & {});
}
export declare const ListCookiesRequest: S.Schema<ListCookiesRequest>;
export type CookiesListResultItemType = "first_party" | "unknown";
export declare const CookiesListResultItemType: any;
export type CookiesListResultItemPageUrlsList = Array<string>;
export declare const CookiesListResultItemPageUrlsList: S.Schema<CookiesListResultItemPageUrlsList>;
export type CookiesListResultItemSameSiteAttribute = "lax" | "strict" | "none";
export declare const CookiesListResultItemSameSiteAttribute: any;
export interface CookiesListResultItem {
    /** Identifier */
    id: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    name: string;
    type: CookiesListResultItemType;
    domainAttribute?: string | null;
    expiresAttribute?: string | null;
    httpOnlyAttribute?: boolean | null;
    maxAgeAttribute?: number | null;
    pageUrls?: CookiesListResultItemPageUrlsList | null;
    pathAttribute?: string | null;
    sameSiteAttribute?: CookiesListResultItemSameSiteAttribute | null;
    secureAttribute?: boolean | null;
}
export declare const CookiesListResultItem: S.Schema<CookiesListResultItem>;
export type CookiesListResultList = Array<CookiesListResultItem>;
export declare const CookiesListResultList: S.Schema<CookiesListResultList>;
export interface ListCookiesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CookiesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCookiesResponse: S.Schema<ListCookiesResponse>;
export interface ListPoliciesRequest {
    /** Identifier */
    zoneId: string;
}
export declare const ListPoliciesRequest: S.Schema<ListPoliciesRequest>;
export type PoliciesListResultItemAction = "allow" | "log" | "add_reporting_directives";
export declare const PoliciesListResultItemAction: any;
export interface PoliciesListResultItem {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesListResultItemAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export declare const PoliciesListResultItem: S.Schema<PoliciesListResultItem>;
export type PoliciesListResultList = Array<PoliciesListResultItem>;
export declare const PoliciesListResultList: S.Schema<PoliciesListResultList>;
export interface ListPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPoliciesResponse: S.Schema<ListPoliciesResponse>;
export type ScriptsListRequestDirection = "asc" | "desc";
export declare const ScriptsListRequestDirection: any;
export type ScriptsListRequestExport = "csv";
export declare const ScriptsListRequestExport: any;
export type ScriptsListRequestOrderBy = "first_seen_at" | "last_seen_at";
export declare const ScriptsListRequestOrderBy: any;
export interface ListScriptsRequest {
    /** Identifier */
    zoneId: string;
    /** The direction used to sort returned scripts. */
    direction?: ScriptsListRequestDirection | (string & {});
    /** When true, excludes scripts seen in a `/cdn-cgi` path from the returned scripts. The default value is true. */
    excludeCdnCgi?: boolean;
    /** When true, excludes duplicate scripts. We consider a script duplicate of another if their javascript */
    excludeDuplicates?: boolean;
    /** Excludes scripts whose URL contains one of the URL-encoded URLs separated by commas. */
    excludeUrls?: string;
    /** Export the list of scripts as a file, limited to 50000 entries. */
    export?: ScriptsListRequestExport | (string & {});
    /** Includes scripts that match one or more URL-encoded hostnames separated by commas. */
    hosts?: string;
    /** The field used to sort returned scripts. */
    orderBy?: ScriptsListRequestOrderBy | (string & {});
    /** The current page number of the paginated results. */
    page?: string;
    /** Includes scripts that match one or more page URLs (separated by commas) where they were last seen */
    pageUrl?: string;
    /** The number of results per page. */
    perPage?: number;
    /** When true, malicious scripts appear first in the returned scripts. */
    prioritizeMalicious?: boolean;
    /** Filters the returned scripts using a comma-separated list of scripts statuses. Accepted values: `active`, `infrequent`, and `inactive`. The default value is `active`. */
    status?: string;
    /** Includes scripts whose URL contain one or more URL-encoded URLs separated by commas. */
    urls?: string;
}
export declare const ListScriptsRequest: S.Schema<ListScriptsRequest>;
export type ScriptsListResultItemMaliciousDomainCategoriesList = Array<string>;
export declare const ScriptsListResultItemMaliciousDomainCategoriesList: S.Schema<ScriptsListResultItemMaliciousDomainCategoriesList>;
export type ScriptsListResultItemMaliciousUrlCategoriesList = Array<string>;
export declare const ScriptsListResultItemMaliciousUrlCategoriesList: S.Schema<ScriptsListResultItemMaliciousUrlCategoriesList>;
export type ScriptsListResultItemPageUrlsList = Array<string>;
export declare const ScriptsListResultItemPageUrlsList: S.Schema<ScriptsListResultItemPageUrlsList>;
export interface ScriptsListResultItem {
    /** Identifier */
    id: string;
    addedAt: string;
    firstSeenAt: string;
    host: string;
    lastSeenAt: string;
    url: string;
    urlContainsCdnCgiPath: boolean;
    /** The cryptomining score of the JavaScript content. */
    cryptominingScore?: number | null;
    /** The dataflow score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    dataflowScore?: number | null;
    domainReportedMalicious?: boolean | null;
    /** The timestamp of when the script was last fetched. */
    fetchedAt?: string | null;
    firstPageUrl?: string | null;
    /** The computed hash of the analyzed script. */
    hash?: string | null;
    /** The integrity score of the JavaScript content. */
    jsIntegrityScore?: number | null;
    /** The magecart score of the JavaScript content. */
    magecartScore?: number | null;
    maliciousDomainCategories?: ScriptsListResultItemMaliciousDomainCategoriesList | null;
    maliciousUrlCategories?: ScriptsListResultItemMaliciousUrlCategoriesList | null;
    /** The malware score of the JavaScript content. */
    malwareScore?: number | null;
    /** The obfuscation score of the JavaScript content. This field has been deprecated in favour of js_integrity_score. */
    obfuscationScore?: number | null;
    pageUrls?: ScriptsListResultItemPageUrlsList | null;
    urlReportedMalicious?: boolean | null;
}
export declare const ScriptsListResultItem: S.Schema<ScriptsListResultItem>;
export type ScriptsListResultList = Array<ScriptsListResultItem>;
export declare const ScriptsListResultList: S.Schema<ScriptsListResultList>;
export interface ListScriptsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScriptsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListScriptsResponse: S.Schema<ListScriptsResponse>;
export interface PutPageShieldRequest {
    /** Identifier */
    zoneId: string;
    /** When true, indicates that Page Shield is enabled. */
    enabled?: boolean;
    /** When true, CSP reports will be sent to https://csp-reporting.cloudflare.com/cdn-cgi/script_monitor/report */
    useCloudflareReportingEndpoint?: boolean;
    /** When true, the paths associated with connections URLs will also be analyzed. */
    useConnectionUrlPath?: boolean;
}
export declare const PutPageShieldRequest: S.Schema<PutPageShieldRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutPageShieldResponse {
    /** When true, indicates that Page Shield is enabled. */
    enabled: boolean;
    /** The timestamp of when Page Shield was last updated. */
    updatedAt: string;
    /** When true, CSP reports will be sent to https://csp-reporting.cloudflare.com/cdn-cgi/script_monitor/report */
    useCloudflareReportingEndpoint: boolean;
    /** When true, the paths associated with connections URLs will also be analyzed. */
    useConnectionUrlPath: boolean;
}
export declare const PutPageShieldResponse: S.Schema<PutPageShieldResponse>;
export type PoliciesUpdateRequestAction = "allow" | "log" | "add_reporting_directives";
export declare const PoliciesUpdateRequestAction: any;
export interface UpdatePolicyRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    policyId: string;
    /** The action to take if the expression matches */
    action?: PoliciesUpdateRequestAction | (string & {});
    /** A description for the policy */
    description?: string;
    /** Whether the policy is enabled */
    enabled?: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression?: string;
    /** The policy which will be applied */
    value?: string;
}
export declare const UpdatePolicyRequest: S.Schema<UpdatePolicyRequest>;
export type PoliciesUpdateResponseAction = "allow" | "log" | "add_reporting_directives";
export declare const PoliciesUpdateResponseAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePolicyResponse {
    /** Identifier */
    id: string;
    /** The action to take if the expression matches */
    action: PoliciesUpdateResponseAction;
    /** A description for the policy */
    description: string;
    /** Whether the policy is enabled */
    enabled: boolean;
    /** The expression which must match for the policy to be applied, using the Cloudflare Firewall rule expression syntax */
    expression: string;
    /** The policy which will be applied */
    value: string;
}
export declare const UpdatePolicyResponse: S.Schema<UpdatePolicyResponse>;
export type CreatePolicyError = PolicyQuotaExceeded | Forbidden | CloudflareOpError;
/** Create a Page Shield policy. */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, CloudflareOpContext>;
export type DeletePolicyError = PolicyNotFound | Forbidden | CloudflareOpError;
/** Delete a Page Shield policy by ID. */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, CloudflareOpContext>;
export type GetConnectionError = CloudflareOpError;
/** Fetches a connection detected by Page Shield by connection ID. */
export declare const getConnection: API.OperationMethod<GetConnectionRequest, GetConnectionResponse, GetConnectionError, CloudflareOpContext>;
export type GetCookyError = CloudflareOpError;
/** Fetches a cookie collected by Page Shield by cookie ID. */
export declare const getCooky: API.OperationMethod<GetCookyRequest, GetCookyResponse, GetCookyError, CloudflareOpContext>;
export type GetPageShieldError = Forbidden | CloudflareOpError;
/** Fetches the Page Shield settings. */
export declare const getPageShield: API.OperationMethod<GetPageShieldRequest, GetPageShieldResponse, GetPageShieldError, CloudflareOpContext>;
export type GetPolicyError = PolicyNotFound | Forbidden | CloudflareOpError;
/** Fetches a Page Shield policy by ID. */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, CloudflareOpContext>;
export type GetScriptError = CloudflareOpError;
/** Fetches a script detected by Page Shield by script ID. */
export declare const getScript: API.OperationMethod<GetScriptRequest, GetScriptResponse, GetScriptError, CloudflareOpContext>;
export type ListConnectionsError = CloudflareOpError;
/** Lists all connections detected by Page Shield. */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsRequest, ListConnectionsResponse, ListConnectionsError, CloudflareOpContext, ConnectionsListResultItem>;
export type ListCookiesError = CloudflareOpError;
/** Lists all cookies collected by Page Shield. */
export declare const listCookies: API.PaginatedOperationMethod<ListCookiesRequest, ListCookiesResponse, ListCookiesError, CloudflareOpContext, CookiesListResultItem>;
export type ListPoliciesError = Forbidden | CloudflareOpError;
/** Lists all Page Shield policies. */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, CloudflareOpContext, PoliciesListResultItem>;
export type ListScriptsError = CloudflareOpError;
/** Lists all scripts detected by Page Shield. */
export declare const listScripts: API.PaginatedOperationMethod<ListScriptsRequest, ListScriptsResponse, ListScriptsError, CloudflareOpContext, ScriptsListResultItem>;
export type PutPageShieldError = NotEntitled | Forbidden | CloudflareOpError;
/** Updates Page Shield settings. */
export declare const putPageShield: API.OperationMethod<PutPageShieldRequest, PutPageShieldResponse, PutPageShieldError, CloudflareOpContext>;
export type UpdatePolicyError = PolicyNotFound | Forbidden | CloudflareOpError;
/** Update a Page Shield policy by ID. */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest, UpdatePolicyResponse, UpdatePolicyError, CloudflareOpContext>;
//# sourceMappingURL=page_shield.d.ts.map