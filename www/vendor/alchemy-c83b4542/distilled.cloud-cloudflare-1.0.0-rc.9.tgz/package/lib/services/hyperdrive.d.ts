import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const HyperdriveConfigNotFound_base: S.Class<HyperdriveConfigNotFound, S.TaggedStruct<"HyperdriveConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HyperdriveConfigNotFound extends /*@__PURE__*/ HyperdriveConfigNotFound_base {
}
declare const InvalidHyperdriveConfig_base: S.Class<InvalidHyperdriveConfig, S.TaggedStruct<"InvalidHyperdriveConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidHyperdriveConfig extends /*@__PURE__*/ InvalidHyperdriveConfig_base {
}
declare const InvalidObjectIdentifier_base: S.Class<InvalidObjectIdentifier, S.TaggedStruct<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const MethodNotAllowed_base: S.Class<MethodNotAllowed, S.TaggedStruct<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const PrivateHostNotAllowed_base: S.Class<PrivateHostNotAllowed, S.TaggedStruct<"PrivateHostNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PrivateHostNotAllowed extends /*@__PURE__*/ PrivateHostNotAllowed_base {
}
export type ConfigsCreateRequestOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsCreateRequestOriginPublicDatabaseScheme: any;
export interface ConfigsCreateRequestOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateRequestOriginPublicDatabaseScheme | (string & {});
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsCreateRequestOriginPublicDatabase: S.Schema<ConfigsCreateRequestOriginPublicDatabase>;
export type ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme | (string & {});
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPCScheme | (string & {});
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsCreateRequestOrigin = ConfigsCreateRequestOriginPublicDatabase | ConfigsCreateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsCreateRequestOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsCreateRequestOrigin: any;
export interface ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon {
    /** Set to true to disable caching of SQL responses. Default is false. */
    disabled?: boolean;
}
export declare const ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon>;
export interface ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled {
    /** Set to true to disable caching of SQL responses. Default is false. */
    disabled?: boolean;
    /** Specify the maximum duration (in seconds) items should persist in the cache. Defaults to 60 seconds if not specified. */
    maxAge?: number;
    /** Specify the number of seconds the cache may serve a stale response. Defaults to 15 seconds if not specified. */
    staleWhileRevalidate?: number;
}
export declare const ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsCreateRequestCaching = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsCreateRequestCaching: any;
export interface ConfigsCreateRequestMtls {
    /** Define CA certificate ID obtained after uploading CA cert. */
    caCertificateId?: string;
    /** Define mTLS certificate ID obtained after uploading client cert. */
    mtlsCertificateId?: string;
    /** Set SSL mode to 'require', 'verify-ca', or 'verify-full' to verify the CA. */
    sslmode?: string;
}
export declare const ConfigsCreateRequestMtls: S.Schema<ConfigsCreateRequestMtls>;
export interface CreateConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsCreateRequestOrigin;
    caching?: ConfigsCreateRequestCaching;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateRequestMtls;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number;
}
export declare const CreateConfigRequest: S.Schema<CreateConfigRequest>;
export type ConfigsCreateResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsCreateResponseOriginPublicDatabaseScheme: any;
export interface ConfigsCreateResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsCreateResponseOriginPublicDatabase: S.Schema<ConfigsCreateResponseOriginPublicDatabase>;
export type ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsCreateResponseOrigin = ConfigsCreateResponseOriginPublicDatabase | ConfigsCreateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsCreateResponseOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsCreateResponseOrigin: any;
export interface ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon {
    /** Set to true to disable caching of SQL responses. Default is false. */
    disabled?: boolean | null;
}
export declare const ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon>;
export interface ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled {
    /** Set to true to disable caching of SQL responses. Default is false. */
    disabled?: boolean | null;
    /** Specify the maximum duration (in seconds) items should persist in the cache. Defaults to 60 seconds if not specified. */
    maxAge?: number | null;
    /** Specify the number of seconds the cache may serve a stale response. Defaults to 15 seconds if not specified. */
    staleWhileRevalidate?: number | null;
}
export declare const ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsCreateResponseCaching = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsCreateResponseCaching: any;
export interface ConfigsCreateResponseMtls {
    /** Define CA certificate ID obtained after uploading CA cert. */
    caCertificateId?: string | null;
    /** Define mTLS certificate ID obtained after uploading client cert. */
    mtlsCertificateId?: string | null;
    /** Set SSL mode to 'require', 'verify-ca', or 'verify-full' to verify the CA. */
    sslmode?: string | null;
}
export declare const ConfigsCreateResponseMtls: S.Schema<ConfigsCreateResponseMtls>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsCreateResponseOrigin;
    caching?: ConfigsCreateResponseCaching | null;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
}
export declare const CreateConfigResponse: S.Schema<CreateConfigResponse>;
export interface DeleteConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
}
export declare const DeleteConfigRequest: S.Schema<DeleteConfigRequest>;
export type DeleteConfigResponse = unknown;
export declare const DeleteConfigResponse: S.Schema<DeleteConfigResponse>;
export interface GetConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
}
export declare const GetConfigRequest: S.Schema<GetConfigRequest>;
export type ConfigsGetResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsGetResponseOriginPublicDatabaseScheme: any;
export interface ConfigsGetResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsGetResponseOriginPublicDatabase: S.Schema<ConfigsGetResponseOriginPublicDatabase>;
export type ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsGetResponseOrigin = ConfigsGetResponseOriginPublicDatabase | ConfigsGetResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsGetResponseOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsGetResponseOrigin: any;
export type ConfigsGetResponseCachingHyperdriveHyperdriveCachingCommon = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon;
export declare const ConfigsGetResponseCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon>;
export type ConfigsGetResponseCachingHyperdriveHyperdriveCachingEnabled = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsGetResponseCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsGetResponseCaching = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsGetResponseCaching: any;
export type ConfigsGetResponseMtls = ConfigsCreateResponseMtls;
export declare const ConfigsGetResponseMtls: S.Schema<ConfigsCreateResponseMtls>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsGetResponseOrigin;
    caching?: ConfigsGetResponseCaching | null;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
}
export declare const GetConfigResponse: S.Schema<GetConfigResponse>;
export interface ListConfigsRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
}
export declare const ListConfigsRequest: S.Schema<ListConfigsRequest>;
export type ConfigsListResultItemOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsListResultItemOriginPublicDatabaseScheme: any;
export interface ConfigsListResultItemOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsListResultItemOriginPublicDatabase: S.Schema<ConfigsListResultItemOriginPublicDatabase>;
export type ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsListResultItemOrigin = ConfigsListResultItemOriginPublicDatabase | ConfigsListResultItemOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsListResultItemOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsListResultItemOrigin: any;
export type ConfigsListResultItemCachingHyperdriveHyperdriveCachingCommon = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon;
export declare const ConfigsListResultItemCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon>;
export type ConfigsListResultItemCachingHyperdriveHyperdriveCachingEnabled = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsListResultItemCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsListResultItemCaching = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsListResultItemCaching: any;
export type ConfigsListResultItemMtls = ConfigsCreateResponseMtls;
export declare const ConfigsListResultItemMtls: S.Schema<ConfigsCreateResponseMtls>;
export interface ConfigsListResultItem {
    /** Define configurations using a unique string identifier. */
    id: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsListResultItemOrigin;
    caching?: ConfigsListResultItemCaching | null;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
}
export declare const ConfigsListResultItem: S.Schema<ConfigsListResultItem>;
export type ConfigsListResultList = Array<ConfigsListResultItem>;
export declare const ConfigsListResultList: S.Schema<ConfigsListResultList>;
export interface ListConfigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConfigsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListConfigsResponse: S.Schema<ListConfigsResponse>;
export type ConfigsEditRequestCachingHyperdriveHyperdriveCachingCommon = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon;
export declare const ConfigsEditRequestCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon>;
export type ConfigsEditRequestCachingHyperdriveHyperdriveCachingEnabled = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsEditRequestCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsEditRequestCaching = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsEditRequestCaching: any;
export type ConfigsEditRequestMtls = ConfigsCreateRequestMtls;
export declare const ConfigsEditRequestMtls: S.Schema<ConfigsCreateRequestMtls>;
export type ConfigsEditRequestOriginHyperdriveHyperdriveDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsEditRequestOriginHyperdriveHyperdriveDatabaseScheme: any;
export interface ConfigsEditRequestOriginHyperdriveHyperdriveDatabase {
    /** Set the name of your origin database. */
    database?: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password?: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme?: ConfigsEditRequestOriginHyperdriveHyperdriveDatabaseScheme | (string & {});
    /** Set the user of your origin database. */
    user?: string;
}
export declare const ConfigsEditRequestOriginHyperdriveHyperdriveDatabase: S.Schema<ConfigsEditRequestOriginHyperdriveHyperdriveDatabase>;
export interface ConfigsEditRequestOriginHyperdriveInternetOrigin {
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
}
export declare const ConfigsEditRequestOriginHyperdriveInternetOrigin: S.Schema<ConfigsEditRequestOriginHyperdriveInternetOrigin>;
export interface ConfigsEditRequestOriginHyperdriveOverAccessOrigin {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
}
export declare const ConfigsEditRequestOriginHyperdriveOverAccessOrigin: S.Schema<ConfigsEditRequestOriginHyperdriveOverAccessOrigin>;
export interface ConfigsEditRequestOriginHyperdriveVPCServiceOrigin {
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
}
export declare const ConfigsEditRequestOriginHyperdriveVPCServiceOrigin: S.Schema<ConfigsEditRequestOriginHyperdriveVPCServiceOrigin>;
export type ConfigsEditRequestOrigin = ConfigsEditRequestOriginHyperdriveHyperdriveDatabase | ConfigsEditRequestOriginHyperdriveInternetOrigin | ConfigsEditRequestOriginHyperdriveOverAccessOrigin | ConfigsEditRequestOriginHyperdriveVPCServiceOrigin;
export declare const ConfigsEditRequestOrigin: any;
export interface PatchConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
    caching?: ConfigsEditRequestCaching;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateRequestMtls;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name?: string;
    /** Connect to a database through a Workers VPC Service. TLS settings (mTLS, sslmode) cannot be configured on the Hyperdrive when using a VPC Service origin; TLS must be managed on the VPC Service itself. */
    origin?: ConfigsEditRequestOrigin;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number;
}
export declare const PatchConfigRequest: S.Schema<PatchConfigRequest>;
export type ConfigsEditResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsEditResponseOriginPublicDatabaseScheme: any;
export interface ConfigsEditResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsEditResponseOriginPublicDatabase: S.Schema<ConfigsEditResponseOriginPublicDatabase>;
export type ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsEditResponseOrigin = ConfigsEditResponseOriginPublicDatabase | ConfigsEditResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsEditResponseOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsEditResponseOrigin: any;
export type ConfigsEditResponseCachingHyperdriveHyperdriveCachingCommon = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon;
export declare const ConfigsEditResponseCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon>;
export type ConfigsEditResponseCachingHyperdriveHyperdriveCachingEnabled = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsEditResponseCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsEditResponseCaching = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsEditResponseCaching: any;
export type ConfigsEditResponseMtls = ConfigsCreateResponseMtls;
export declare const ConfigsEditResponseMtls: S.Schema<ConfigsCreateResponseMtls>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsEditResponseOrigin;
    caching?: ConfigsEditResponseCaching | null;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
}
export declare const PatchConfigResponse: S.Schema<PatchConfigResponse>;
export type ConfigsUpdateRequestOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsUpdateRequestOriginPublicDatabaseScheme: any;
export interface ConfigsUpdateRequestOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateRequestOriginPublicDatabaseScheme | (string & {});
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsUpdateRequestOriginPublicDatabase: S.Schema<ConfigsUpdateRequestOriginPublicDatabase>;
export type ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme | (string & {});
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Set the password needed to access your origin database. The API never returns this write-only value. */
    password: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPCScheme | (string & {});
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsUpdateRequestOrigin = ConfigsUpdateRequestOriginPublicDatabase | ConfigsUpdateRequestOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsUpdateRequestOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsUpdateRequestOrigin: any;
export type ConfigsUpdateRequestCachingHyperdriveHyperdriveCachingCommon = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon;
export declare const ConfigsUpdateRequestCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon>;
export type ConfigsUpdateRequestCachingHyperdriveHyperdriveCachingEnabled = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsUpdateRequestCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsUpdateRequestCaching = ConfigsCreateRequestCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateRequestCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsUpdateRequestCaching: any;
export type ConfigsUpdateRequestMtls = ConfigsCreateRequestMtls;
export declare const ConfigsUpdateRequestMtls: S.Schema<ConfigsCreateRequestMtls>;
export interface UpdateConfigRequest {
    /** Define configurations using a unique string identifier. */
    accountId: string;
    /** Define configurations using a unique string identifier. */
    hyperdriveId: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsUpdateRequestOrigin;
    caching?: ConfigsUpdateRequestCaching;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateRequestMtls;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number;
}
export declare const UpdateConfigRequest: S.Schema<UpdateConfigRequest>;
export type ConfigsUpdateResponseOriginPublicDatabaseScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsUpdateResponseOriginPublicDatabaseScheme: any;
export interface ConfigsUpdateResponseOriginPublicDatabase {
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Defines the port of your origin database. Defaults to 5432 for PostgreSQL or 3306 for MySQL if not specified. */
    port: number;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseOriginPublicDatabaseScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsUpdateResponseOriginPublicDatabase: S.Schema<ConfigsUpdateResponseOriginPublicDatabase>;
export type ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme: any;
export interface ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel {
    /** Defines the Client ID of the Access token to use when connecting to the origin database. */
    accessClientId: string;
    /** Defines the Client Secret of the Access Token to use when connecting to the origin database. The API never returns this write-only value. */
    accessClientSecret: string;
    /** Set the name of your origin database. */
    database: string;
    /** Defines the host (hostname or IP) of your origin database. */
    host: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnelScheme;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel: S.Schema<ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel>;
export type ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPCScheme = "postgres" | "postgresql" | "mysql";
export declare const ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPCScheme: any;
export interface ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPC {
    /** Set the name of your origin database. */
    database: string;
    /** Specifies the URL scheme used to connect to your origin database. */
    scheme: ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPCScheme;
    /** The identifier of the Workers VPC Service to connect through. Hyperdrive will egress through the specified VPC Service to reach the origin database. */
    serviceId: string;
    /** Set the user of your origin database. */
    user: string;
}
export declare const ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPC: S.Schema<ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPC>;
export type ConfigsUpdateResponseOrigin = ConfigsUpdateResponseOriginPublicDatabase | ConfigsUpdateResponseOriginAccessProtectedDatabaseBehindCloudflareTunnel | ConfigsUpdateResponseOriginDatabaseReachableThroughAWorkersVPC;
export declare const ConfigsUpdateResponseOrigin: any;
export type ConfigsUpdateResponseCachingHyperdriveHyperdriveCachingCommon = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon;
export declare const ConfigsUpdateResponseCachingHyperdriveHyperdriveCachingCommon: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon>;
export type ConfigsUpdateResponseCachingHyperdriveHyperdriveCachingEnabled = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsUpdateResponseCachingHyperdriveHyperdriveCachingEnabled: S.Schema<ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled>;
export type ConfigsUpdateResponseCaching = ConfigsCreateResponseCachingHyperdriveHyperdriveCachingCommon | ConfigsCreateResponseCachingHyperdriveHyperdriveCachingEnabled;
export declare const ConfigsUpdateResponseCaching: any;
export type ConfigsUpdateResponseMtls = ConfigsCreateResponseMtls;
export declare const ConfigsUpdateResponseMtls: S.Schema<ConfigsCreateResponseMtls>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateConfigResponse {
    /** Define configurations using a unique string identifier. */
    id: string;
    /** The name of the Hyperdrive configuration. Used to identify the configuration in the Cloudflare dashboard and API. */
    name: string;
    origin: ConfigsUpdateResponseOrigin;
    caching?: ConfigsUpdateResponseCaching | null;
    /** Defines the creation time of the Hyperdrive configuration. */
    createdOn?: string | null;
    /** Defines the last modified time of the Hyperdrive configuration. */
    modifiedOn?: string | null;
    /** mTLS configuration for the origin connection. Cannot be used with VPC Service origins; TLS must be managed on the VPC Service. */
    mtls?: ConfigsCreateResponseMtls | null;
    /** The (soft) maximum number of connections the Hyperdrive is allowed to make to the origin database. */
    originConnectionLimit?: number | null;
}
export declare const UpdateConfigResponse: S.Schema<UpdateConfigResponse>;
export type CreateConfigError = PrivateHostNotAllowed | InvalidHyperdriveConfig | InvalidObjectIdentifier | CloudflareOpError;
/** Creates and returns a new Hyperdrive configuration. */
export declare const createConfig: API.OperationMethod<CreateConfigRequest, CreateConfigResponse, CreateConfigError, CloudflareOpContext>;
export type DeleteConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | MethodNotAllowed | CloudflareOpError;
/** Deletes the specified Hyperdrive. */
export declare const deleteConfig: API.OperationMethod<DeleteConfigRequest, DeleteConfigResponse, DeleteConfigError, CloudflareOpContext>;
export type GetConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the specified Hyperdrive configuration. */
export declare const getConfig: API.OperationMethod<GetConfigRequest, GetConfigResponse, GetConfigError, CloudflareOpContext>;
export type ListConfigsError = PrivateHostNotAllowed | InvalidObjectIdentifier | CloudflareOpError;
/** Returns a list of Hyperdrives. */
export declare const listConfigs: API.PaginatedOperationMethod<ListConfigsRequest, ListConfigsResponse, ListConfigsError, CloudflareOpContext, ConfigsListResultItem>;
export type PatchConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | MethodNotAllowed | CloudflareOpError;
/** Patches and returns the specified Hyperdrive configuration. Custom caching settings are not kept if caching is disabled. */
export declare const patchConfig: API.OperationMethod<PatchConfigRequest, PatchConfigResponse, PatchConfigError, CloudflareOpContext>;
export type UpdateConfigError = PrivateHostNotAllowed | HyperdriveConfigNotFound | InvalidObjectIdentifier | MethodNotAllowed | CloudflareOpError;
/** Updates and returns the specified Hyperdrive configuration. */
export declare const updateConfig: API.OperationMethod<UpdateConfigRequest, UpdateConfigResponse, UpdateConfigError, CloudflareOpContext>;
//# sourceMappingURL=hyperdrive.d.ts.map