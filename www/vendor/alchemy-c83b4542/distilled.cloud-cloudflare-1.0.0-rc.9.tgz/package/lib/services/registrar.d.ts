import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const RegistrarDomainNotOwned_base: S.Class<RegistrarDomainNotOwned, S.TaggedStruct<"RegistrarDomainNotOwned", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RegistrarDomainNotOwned extends /*@__PURE__*/ RegistrarDomainNotOwned_base {
}
declare const RegistrarUpdateNotAllowed_base: S.Class<RegistrarUpdateNotAllowed, S.TaggedStruct<"RegistrarUpdateNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RegistrarUpdateNotAllowed extends /*@__PURE__*/ RegistrarUpdateNotAllowed_base {
}
export type CheckRequestDomainsList = Array<string>;
export declare const CheckRequestDomainsList: S.Schema<CheckRequestDomainsList>;
export interface CheckRegistrarRequest {
    /** Identifier */
    accountId: string;
    /** List of fully qualified domain names (FQDNs) to check for availability. Each domain must include the extension. */
    domains: CheckRequestDomainsList;
}
export declare const CheckRegistrarRequest: S.Schema<CheckRegistrarRequest>;
export interface CheckResponseDomainsItemPricing {
    /** ISO-4217 currency code for the prices (e.g., "USD", "EUR", "GBP"). */
    currency: string;
    /** The first-year cost to register this domain. For premium domains */
    registrationCost: string;
    /** Per-year renewal cost for this domain. Applied to each year beyond */
    renewalCost: string;
}
export declare const CheckResponseDomainsItemPricing: S.Schema<CheckResponseDomainsItemPricing>;
export type CheckResponseDomainsItemReason = "extension_not_supported_via_api" | "extension_not_supported" | "extension_disallows_registration" | "domain_premium" | "domain_unavailable";
export declare const CheckResponseDomainsItemReason: any;
export type CheckResponseDomainsItemTier = "standard" | "premium";
export declare const CheckResponseDomainsItemTier: any;
export interface CheckResponseDomainsItem {
    /** The fully qualified domain name (FQDN) in punycode format for internationalized domain names (IDNs). */
    name: string;
    /** Indicates whether this domain can be registered programmatically through this API based on a real-time registry check. */
    registrable: boolean;
    /** Annual pricing information for a registrable domain. This object is only */
    pricing?: CheckResponseDomainsItemPricing | null;
    /** Present only when `registrable` is `false`. Explains why the domain cannot be registered via this API. */
    reason?: CheckResponseDomainsItemReason | null;
    /** The pricing tier for this domain. Always present when `registrable` is `true`; defaults to `standard` for most domains. May be absent when `registrable` is `false`. */
    tier?: CheckResponseDomainsItemTier | null;
}
export declare const CheckResponseDomainsItem: S.Schema<CheckResponseDomainsItem>;
export type CheckResponseDomainsList = Array<CheckResponseDomainsItem>;
export declare const CheckResponseDomainsList: S.Schema<CheckResponseDomainsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CheckRegistrarResponse {
    /** Array of domain availability results. Domains on unsupported */
    domains: CheckResponseDomainsList;
}
export declare const CheckRegistrarResponse: S.Schema<CheckRegistrarResponse>;
export interface CreateRegistrationRequestContactsRegistrantPostalInfoAddress {
    /** City or locality name. */
    city: string;
    /** Two-letter country code per ISO 3166-1 alpha-2 (e.g., `US`, `GB`, `CA`, `DE`). */
    countryCode: string;
    /** Postal or ZIP code. */
    postalCode: string;
    /** State, province, or region. Use the standard abbreviation where applicable (e.g., `TX` for Texas, `ON` for Ontario). */
    state: string;
    /** Street address including building/suite number. */
    street: string;
}
export declare const CreateRegistrationRequestContactsRegistrantPostalInfoAddress: S.Schema<CreateRegistrationRequestContactsRegistrantPostalInfoAddress>;
export interface CreateRegistrationRequestContactsRegistrantPostalInfo {
    /** Physical mailing address for the registrant contact. */
    address: CreateRegistrationRequestContactsRegistrantPostalInfoAddress;
    /** Full legal name of the registrant (individual or authorized representative). */
    name: string;
    /** Organization or company name. Optional for individual registrants. */
    organization?: string;
}
export declare const CreateRegistrationRequestContactsRegistrantPostalInfo: S.Schema<CreateRegistrationRequestContactsRegistrantPostalInfo>;
export interface CreateRegistrationRequestContactsRegistrant {
    /** Email address for the registrant. Used for domain-related */
    email: string;
    /** Phone number in E.164 format: `+{country_code}.{number}` with no */
    phone: string;
    /** Postal/mailing information for the registrant contact. */
    postalInfo: CreateRegistrationRequestContactsRegistrantPostalInfo;
    /** Fax number in E.164 format (e.g., `+1.5555555555`). Optional. */
    fax?: string;
}
export declare const CreateRegistrationRequestContactsRegistrant: S.Schema<CreateRegistrationRequestContactsRegistrant>;
export interface CreateRegistrationRequestContacts {
    /** Registrant contact data for the domain registration. This information */
    registrant?: CreateRegistrationRequestContactsRegistrant;
}
export declare const CreateRegistrationRequestContacts: S.Schema<CreateRegistrationRequestContacts>;
export type CreateRegistrationRequestPrivacyMode = "redaction";
export declare const CreateRegistrationRequestPrivacyMode: any;
export interface CreateRegistrationRequest {
    /** Identifier */
    accountId: string;
    prefer?: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
    /** Enable or disable automatic renewal. Defaults to `false` if omitted. */
    autoRenew?: boolean;
    /** Contact data for the registration request. */
    contacts?: CreateRegistrationRequestContacts;
    /** WHOIS privacy mode for the registration. Defaults to `redaction`. */
    privacyMode?: CreateRegistrationRequestPrivacyMode | (string & {});
    /** Number of years to register (1–10). If omitted, defaults to the */
    years?: number;
}
export declare const CreateRegistrationRequest: S.Schema<CreateRegistrationRequest>;
export interface CreateRegistrationResponseLinks {
    /** URL to this status resource. */
    self: string;
    /** URL to the domain resource. */
    resource?: string | null;
}
export declare const CreateRegistrationResponseLinks: S.Schema<CreateRegistrationResponseLinks>;
export type CreateRegistrationResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export declare const CreateRegistrationResponseState: any;
export type CreateRegistrationResponseContextMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateRegistrationResponseContextMap: S.Schema<CreateRegistrationResponseContextMap>;
export interface CreateRegistrationResponseError {
    /** Machine-readable error code identifying the failure reason. */
    code: string;
    /** Human-readable explanation of the failure. May include registry-specific details. */
    message: string;
}
export declare const CreateRegistrationResponseError: S.Schema<CreateRegistrationResponseError>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRegistrationResponse {
    /** Whether the workflow has reached a terminal state. `true` when */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Workflow lifecycle state. */
    state: CreateRegistrationResponseState;
    updatedAt: string;
    /** Workflow-specific data for this workflow. */
    context?: CreateRegistrationResponseContextMap | null;
    /** Error details when a workflow reaches the `failed` state. The specific */
    error?: CreateRegistrationResponseError | null;
}
export declare const CreateRegistrationResponse: S.Schema<CreateRegistrationResponse>;
export type EditRegistrationRequestPrefer = "respond-async";
export declare const EditRegistrationRequestPrefer: any;
export interface EditRegistrationRequest {
    /** Identifier */
    accountId: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
    prefer?: EditRegistrationRequestPrefer | (string & {});
    /** Enable or disable automatic renewal. */
    autoRenew?: boolean;
}
export declare const EditRegistrationRequest: S.Schema<EditRegistrationRequest>;
export type EditRegistrationResponseLinks = CreateRegistrationResponseLinks;
export declare const EditRegistrationResponseLinks: S.Schema<CreateRegistrationResponseLinks>;
export type EditRegistrationResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export declare const EditRegistrationResponseState: any;
export type EditRegistrationResponseContextMap = {
    [key: string]: unknown | undefined;
};
export declare const EditRegistrationResponseContextMap: S.Schema<EditRegistrationResponseContextMap>;
export type EditRegistrationResponseError = CreateRegistrationResponseError;
export declare const EditRegistrationResponseError: S.Schema<CreateRegistrationResponseError>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditRegistrationResponse {
    /** Whether the workflow has reached a terminal state. `true` when */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Workflow lifecycle state. */
    state: EditRegistrationResponseState;
    updatedAt: string;
    /** Workflow-specific data for this workflow. */
    context?: EditRegistrationResponseContextMap | null;
    /** Error details when a workflow reaches the `failed` state. The specific */
    error?: CreateRegistrationResponseError | null;
}
export declare const EditRegistrationResponse: S.Schema<EditRegistrationResponse>;
export interface GetDomainRequest {
    /** Identifier */
    accountId: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
}
export declare const GetDomainRequest: S.Schema<GetDomainRequest>;
export type GetDomainResponse = unknown;
export declare const GetDomainResponse: S.Schema<GetDomainResponse>;
export interface GetRegistrationRequest {
    /** Identifier */
    accountId: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
}
export declare const GetRegistrationRequest: S.Schema<GetRegistrationRequest>;
export type GetRegistrationResponsePrivacyMode = "redaction";
export declare const GetRegistrationResponsePrivacyMode: any;
export type GetRegistrationResponseStatus = "active" | "registration_pending" | "expired" | "suspended" | "redemption_period" | "pending_delete";
export declare const GetRegistrationResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegistrationResponse {
    /** Whether the domain will be automatically renewed before expiration. */
    autoRenew: boolean;
    /** When the domain was registered. Present when the registration resource exists. */
    createdAt: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
    /** When the domain registration expires. Present when the registration is ready; may be null only while `status` is `registration_pending`. */
    expiresAt: string;
    /** Whether the domain is locked for transfer. */
    locked: boolean;
    /** Current WHOIS privacy mode for the registration. */
    privacyMode: GetRegistrationResponsePrivacyMode;
    /** Current registration status. */
    status: GetRegistrationResponseStatus;
}
export declare const GetRegistrationResponse: S.Schema<GetRegistrationResponse>;
export interface GetRegistrationStatusRequest {
    /** Identifier */
    accountId: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
}
export declare const GetRegistrationStatusRequest: S.Schema<GetRegistrationStatusRequest>;
export type RegistrationStatusGetResponseLinks = CreateRegistrationResponseLinks;
export declare const RegistrationStatusGetResponseLinks: S.Schema<CreateRegistrationResponseLinks>;
export type RegistrationStatusGetResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export declare const RegistrationStatusGetResponseState: any;
export type RegistrationStatusGetResponseContextMap = {
    [key: string]: unknown | undefined;
};
export declare const RegistrationStatusGetResponseContextMap: S.Schema<RegistrationStatusGetResponseContextMap>;
export type RegistrationStatusGetResponseError = CreateRegistrationResponseError;
export declare const RegistrationStatusGetResponseError: S.Schema<CreateRegistrationResponseError>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegistrationStatusResponse {
    /** Whether the workflow has reached a terminal state. `true` when */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Workflow lifecycle state. */
    state: RegistrationStatusGetResponseState;
    updatedAt: string;
    /** Workflow-specific data for this workflow. */
    context?: RegistrationStatusGetResponseContextMap | null;
    /** Error details when a workflow reaches the `failed` state. The specific */
    error?: CreateRegistrationResponseError | null;
}
export declare const GetRegistrationStatusResponse: S.Schema<GetRegistrationStatusResponse>;
export interface GetUpdateStatusRequest {
    /** Identifier */
    accountId: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
}
export declare const GetUpdateStatusRequest: S.Schema<GetUpdateStatusRequest>;
export type UpdateStatusGetResponseLinks = CreateRegistrationResponseLinks;
export declare const UpdateStatusGetResponseLinks: S.Schema<CreateRegistrationResponseLinks>;
export type UpdateStatusGetResponseState = "pending" | "in_progress" | "action_required" | "blocked" | "succeeded" | "failed";
export declare const UpdateStatusGetResponseState: any;
export type UpdateStatusGetResponseContextMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateStatusGetResponseContextMap: S.Schema<UpdateStatusGetResponseContextMap>;
export type UpdateStatusGetResponseError = CreateRegistrationResponseError;
export declare const UpdateStatusGetResponseError: S.Schema<CreateRegistrationResponseError>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUpdateStatusResponse {
    /** Whether the workflow has reached a terminal state. `true` when */
    completed: boolean;
    createdAt: string;
    links: CreateRegistrationResponseLinks;
    /** Workflow lifecycle state. */
    state: UpdateStatusGetResponseState;
    updatedAt: string;
    /** Workflow-specific data for this workflow. */
    context?: UpdateStatusGetResponseContextMap | null;
    /** Error details when a workflow reaches the `failed` state. The specific */
    error?: CreateRegistrationResponseError | null;
}
export declare const GetUpdateStatusResponse: S.Schema<GetUpdateStatusResponse>;
export interface ListDomainsRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListDomainsRequest: S.Schema<ListDomainsRequest>;
export interface DomainsListResultItemRegistrantContact {
    /** Address. */
    address: string;
    /** City. */
    city: string;
    /** The country in which the user lives. */
    country: string;
    /** User's first name */
    firstName: string;
    /** User's last name */
    lastName: string;
    /** Name of organization. */
    organization: string;
    /** User's telephone number */
    phone: string;
    /** State. */
    state: string;
    /** The zipcode or postal code where the user lives. */
    zip: string;
    /** Contact Identifier. */
    id?: string | null;
    /** Optional address line for unit, floor, suite, etc. */
    address2?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Contact fax number. */
    fax?: string | null;
}
export declare const DomainsListResultItemRegistrantContact: S.Schema<DomainsListResultItemRegistrantContact>;
export type DomainsListResultItemTransferInAcceptFoa = "needed" | "ok";
export declare const DomainsListResultItemTransferInAcceptFoa: any;
export type DomainsListResultItemTransferInApproveTransfer = "needed" | "ok" | "pending" | "trying" | "rejected" | "unknown";
export declare const DomainsListResultItemTransferInApproveTransfer: any;
export type DomainsListResultItemTransferInDisablePrivacy = "needed" | "ok" | "unknown";
export declare const DomainsListResultItemTransferInDisablePrivacy: any;
export type DomainsListResultItemTransferInEnterAuthCode = "needed" | "ok" | "pending" | "trying" | "rejected";
export declare const DomainsListResultItemTransferInEnterAuthCode: any;
export type DomainsListResultItemTransferInUnlockDomain = "needed" | "ok" | "pending" | "trying" | "unknown";
export declare const DomainsListResultItemTransferInUnlockDomain: any;
export interface DomainsListResultItemTransferIn {
    /** Form of authorization has been accepted by the registrant. */
    acceptFoa?: DomainsListResultItemTransferInAcceptFoa | null;
    /** Shows transfer status with the registry. */
    approveTransfer?: DomainsListResultItemTransferInApproveTransfer | null;
    /** Indicates if cancellation is still possible. */
    canCancelTransfer?: boolean | null;
    /** Privacy guards are disabled at the foreign registrar. */
    disablePrivacy?: DomainsListResultItemTransferInDisablePrivacy | null;
    /** Auth code has been entered and verified. */
    enterAuthCode?: DomainsListResultItemTransferInEnterAuthCode | null;
    /** Domain is unlocked at the foreign registrar. */
    unlockDomain?: DomainsListResultItemTransferInUnlockDomain | null;
}
export declare const DomainsListResultItemTransferIn: S.Schema<DomainsListResultItemTransferIn>;
export interface DomainsListResultItem {
    /** Domain identifier. */
    id?: string | null;
    /** Shows if a domain is available for transferring into Cloudflare Registrar. */
    available?: boolean | null;
    /** Indicates if the domain can be registered as a new domain. */
    canRegister?: boolean | null;
    /** Shows time of creation. */
    createdAt?: string | null;
    /** Shows name of current registrar. */
    currentRegistrar?: string | null;
    /** Shows when domain name registration expires. */
    expiresAt?: string | null;
    /** Shows whether a registrar lock is in place for a domain. */
    locked?: boolean | null;
    /** Shows contact information for domain registrant. */
    registrantContact?: DomainsListResultItemRegistrantContact | null;
    /** A comma-separated list of registry status codes. A full list of status codes can be found at [EPP Status Codes](https://www.icann.org/resources/pages/epp-status-codes-2014-06-16-en). */
    registryStatuses?: string | null;
    /** Whether a particular TLD is currently supported by Cloudflare Registrar. Refer to [TLD Policies](https://www.cloudflare.com/tld-policies/) for a list of supported TLDs. */
    supportedTld?: boolean | null;
    /** Statuses for domain transfers into Cloudflare Registrar. */
    transferIn?: DomainsListResultItemTransferIn | null;
    /** Last updated. */
    updatedAt?: string | null;
    /** Domain name. */
    name?: string | null;
    /** Whether the domain auto-renews. */
    autoRenew?: boolean | null;
    /** Whether WHOIS privacy is enabled. */
    privacy?: boolean | null;
}
export declare const DomainsListResultItem: S.Schema<DomainsListResultItem>;
export type DomainsListResultList = Array<DomainsListResultItem>;
export declare const DomainsListResultList: S.Schema<DomainsListResultList>;
export interface ListDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDomainsResponse: S.Schema<ListDomainsResponse>;
export type ListRegistrationsRequestDirection = "asc" | "desc";
export declare const ListRegistrationsRequestDirection: any;
export type ListRegistrationsRequestSortBy = "registry_created_at" | "registry_expires_at" | "name";
export declare const ListRegistrationsRequestSortBy: any;
export interface ListRegistrationsRequest {
    /** Identifier */
    accountId: string;
    /** Opaque token from a previous response's `result_info.cursor`. */
    cursor?: string;
    /** Sort direction for results. Defaults to ascending order. */
    direction?: ListRegistrationsRequestDirection | (string & {});
    /** Number of items to return per page. */
    perPage?: number;
    /** Column to sort results by. Defaults to registration date */
    sortBy?: ListRegistrationsRequestSortBy | (string & {});
}
export declare const ListRegistrationsRequest: S.Schema<ListRegistrationsRequest>;
export type ListRegistrationsResultItemPrivacyMode = "redaction";
export declare const ListRegistrationsResultItemPrivacyMode: any;
export type ListRegistrationsResultItemStatus = "active" | "registration_pending" | "expired" | "suspended" | "redemption_period" | "pending_delete";
export declare const ListRegistrationsResultItemStatus: any;
export interface ListRegistrationsResultItem {
    /** Whether the domain will be automatically renewed before expiration. */
    autoRenew: boolean;
    /** When the domain was registered. Present when the registration resource exists. */
    createdAt: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
    /** When the domain registration expires. Present when the registration is ready; may be null only while `status` is `registration_pending`. */
    expiresAt: string;
    /** Whether the domain is locked for transfer. */
    locked: boolean;
    /** Current WHOIS privacy mode for the registration. */
    privacyMode: ListRegistrationsResultItemPrivacyMode;
    /** Current registration status. */
    status: ListRegistrationsResultItemStatus;
}
export declare const ListRegistrationsResultItem: S.Schema<ListRegistrationsResultItem>;
export type ListRegistrationsResultList = Array<ListRegistrationsResultItem>;
export declare const ListRegistrationsResultList: S.Schema<ListRegistrationsResultList>;
export type ListRegistrationsResponse = ListRegistrationsResultList;
export declare const ListRegistrationsResponse: S.Schema<ListRegistrationsResponse>;
export interface PutDomainRequest {
    /** Identifier */
    accountId: string;
    /** Fully qualified domain name (FQDN) including the extension */
    domainName: string;
    /** Auto-renew controls whether subscription is automatically renewed upon domain expiration. */
    autoRenew?: boolean;
    /** Shows whether a registrar lock is in place for a domain. */
    locked?: boolean;
    /** Privacy option controls redacting WHOIS information. */
    privacy?: boolean;
}
export declare const PutDomainRequest: S.Schema<PutDomainRequest>;
export type PutDomainResponse = unknown;
export declare const PutDomainResponse: S.Schema<PutDomainResponse>;
export type SearchRequestExtensionsList = Array<string>;
export declare const SearchRequestExtensionsList: S.Schema<SearchRequestExtensionsList>;
export interface SearchRegistrarRequest {
    /** Identifier */
    accountId: string;
    /** The search term to find domain suggestions. Accepts keywords, phrases, or full domain names. */
    q: string;
    /** Limits results to specific domain extensions from the supported set. If not specified, */
    extensions?: SearchRequestExtensionsList;
    /** Maximum number of domain suggestions to return. Defaults to 20 if not specified. */
    limit?: number;
}
export declare const SearchRegistrarRequest: S.Schema<SearchRegistrarRequest>;
export type SearchResponseDomainsItemPricing = CheckResponseDomainsItemPricing;
export declare const SearchResponseDomainsItemPricing: S.Schema<CheckResponseDomainsItemPricing>;
export type SearchResponseDomainsItemReason = "extension_not_supported_via_api" | "extension_not_supported" | "extension_disallows_registration" | "domain_premium" | "domain_unavailable";
export declare const SearchResponseDomainsItemReason: any;
export type SearchResponseDomainsItemTier = "standard" | "premium";
export declare const SearchResponseDomainsItemTier: any;
export interface SearchResponseDomainsItem {
    /** The fully qualified domain name (FQDN) in punycode format for internationalized domain names (IDNs). */
    name: string;
    /** Indicates whether this domain appears available based on search data. Search results are non-authoritative and may be stale. - `true`: The domain appears available. Use POST /domain-check to confirm before registration. */
    registrable: boolean;
    /** Annual pricing information for a registrable domain. This object is only */
    pricing?: CheckResponseDomainsItemPricing | null;
    /** Present only when `registrable` is `false` on search results. Explains why the domain does not appear registrable through this API. These values are advisory; use POST /domain-check for authoritative status. */
    reason?: SearchResponseDomainsItemReason | null;
    /** The pricing tier for this domain. Always present when `registrable` is `true`; */
    tier?: SearchResponseDomainsItemTier | null;
}
export declare const SearchResponseDomainsItem: S.Schema<SearchResponseDomainsItem>;
export type SearchResponseDomainsList = Array<SearchResponseDomainsItem>;
export declare const SearchResponseDomainsList: S.Schema<SearchResponseDomainsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchRegistrarResponse {
    /** Array of domain suggestions sorted by relevance. May be empty if no domains match the search criteria. */
    domains: SearchResponseDomainsList;
}
export declare const SearchRegistrarResponse: S.Schema<SearchRegistrarResponse>;
export type CheckRegistrarError = CloudflareOpError;
/** Performs real-time, authoritative availability checks directly against domain registries. Use this endpoint to verify a domain is available before attempting registration via `POST /registrations`. **Important:** Unlike the Search endpoint, these results are authoritative and reflect current registry status. Always check availability immediately before registration as domain status can change rapidly. **Note:** This endpoint uses POST to accept a list of domains in the request body. It is a read-only operation — it does not create, modify, or reserve any domains. */
export declare const checkRegistrar: API.OperationMethod<CheckRegistrarRequest, CheckRegistrarResponse, CheckRegistrarError, CloudflareOpContext>;
export type CreateRegistrationError = CloudflareOpError;
/** Starts a domain registration workflow. This is a billable operation — successful registration charges the account's default payment method. All successful domain registrations are non-refundable — once the workflow completes with `state: succeeded`, the charge cannot be reversed. */
export declare const createRegistration: API.OperationMethod<CreateRegistrationRequest, CreateRegistrationResponse, CreateRegistrationError, CloudflareOpContext>;
export type EditRegistrationError = CloudflareOpError;
/** Updates an existing domain registration. By default, the server holds the connection for a bounded, server-defined amount of time while the update completes. Most updates finish within this window and return `200 OK` with a completed workflow status. If the update is still processing after this synchronous wait window, the server returns `202 Accepted`. Poll the URL in `links.self` to track progress. To skip the wait and receive an immediate `202`, send `Prefer: respond-async`. This endpoint currently supports updating `auto_renew` only. */
export declare const editRegistration: API.OperationMethod<EditRegistrationRequest, EditRegistrationResponse, EditRegistrationError, CloudflareOpContext>;
export type GetDomainError = Forbidden | CloudflareOpError;
/** Show individual domain. */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, CloudflareOpContext>;
export type GetRegistrationError = CloudflareOpError;
/** Returns the current state of a domain registration. This is the canonical read endpoint for a domain you own. It returns the full registration resource including current settings and expiration. When the registration resource is ready, both `created_at` and `expires_at` are present in the response. */
export declare const getRegistration: API.OperationMethod<GetRegistrationRequest, GetRegistrationResponse, GetRegistrationError, CloudflareOpContext>;
export type GetRegistrationStatusError = CloudflareOpError;
/** Returns the current status of a domain registration workflow. Use this endpoint to poll for completion when the POST response returned `202 Accepted`. The URL is provided in the `links.self` field of the workflow status response. Poll this endpoint until the workflow reaches a terminal state or a state that requires user attention. **Terminal states:** `succeeded` and `failed` are terminal and always have `completed: true`. **Non-terminal states:** - `action_required` has `completed: false` and will not resolve on its own. The workflow is paused pending user intervention. - `blocked` has `completed: false` and indicates the workflow is waiting on a third party such as the extension registry or losing registrar. Continue polling while informing the user of the delay. Use increasing backoff between polls. When `state: blocked`, use a longer polling interval and do not poll indefinitely. A naive polling loop that only checks `completed` can run indefinitely when `state: action_required`. Break explicitly on `action_required`: ```js let status; do { await new Promise(r => setTimeout(r, 2000)); status = await cloudflare.request({ method: 'GET', path: reg.result.links.self, }); } while ( !status.result.completed && status.result.state !== 'action_required' ); if (status.result.state === 'action_required') { // Surface context.action and context.confirmation_sent_to to the user. // Do not re-submit the registration request. } ``` */
export declare const getRegistrationStatus: API.OperationMethod<GetRegistrationStatusRequest, GetRegistrationStatusResponse, GetRegistrationStatusError, CloudflareOpContext>;
export type GetUpdateStatusError = CloudflareOpError;
/** Returns the current status of a domain update workflow. Use this endpoint to poll for completion when the PATCH response returned `202 Accepted`. The URL is provided in the `links.self` field of the workflow status response. Poll this endpoint until the workflow reaches a terminal state or a state that requires user attention. Use increasing backoff between polls. When the workflow remains blocked on a third party, use a longer polling interval and do not poll indefinitely. */
export declare const getUpdateStatus: API.OperationMethod<GetUpdateStatusRequest, GetUpdateStatusResponse, GetUpdateStatusError, CloudflareOpContext>;
export type ListDomainsError = Forbidden | CloudflareOpError;
/** List domains handled by Registrar. */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, CloudflareOpContext, DomainsListResultItem>;
export type ListRegistrationsError = CloudflareOpError;
/** Returns a paginated list of domain registrations owned by the account. This endpoint uses cursor-based pagination. Results are ordered by registration date by default. To fetch the next page, pass the `cursor` value from the `result_info` object in the response as the `cursor` query parameter in your next request. An empty `cursor` string indicates there are no more pages. */
export declare const listRegistrations: API.OperationMethod<ListRegistrationsRequest, ListRegistrationsResponse, ListRegistrationsError, CloudflareOpContext>;
export type PutDomainError = RegistrarDomainNotOwned | RegistrarUpdateNotAllowed | Forbidden | CloudflareOpError;
/** Update individual domain. */
export declare const putDomain: API.OperationMethod<PutDomainRequest, PutDomainResponse, PutDomainError, CloudflareOpContext>;
export type SearchRegistrarError = CloudflareOpError;
/** Searches for domain name suggestions based on a keyword, phrase, or partial domain name. Returns a list of potentially available domains with pricing information. **Important:** Results are non-authoritative and based on cached data. Always use the `/domain-check` endpoint to verify real-time availability before attempting registration. Suggestions are scoped to extensions supported for programmatic registration via this API (`POST /registrations`). Domains on unsupported extensions will not appear in results, even if they are available at the registry level. */
export declare const searchRegistrar: API.OperationMethod<SearchRegistrarRequest, SearchRegistrarResponse, SearchRegistrarError, CloudflareOpContext>;
//# sourceMappingURL=registrar.d.ts.map