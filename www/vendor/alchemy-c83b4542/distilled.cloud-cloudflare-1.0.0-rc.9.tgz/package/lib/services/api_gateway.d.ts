import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidObjectIdentifier_base: S.Class<InvalidObjectIdentifier, S.TaggedStruct<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const LabelAlreadyExists_base: S.Class<LabelAlreadyExists, S.TaggedStruct<"LabelAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LabelAlreadyExists extends /*@__PURE__*/ LabelAlreadyExists_base {
}
declare const LabelNotFound_base: S.Class<LabelNotFound, S.TaggedStruct<"LabelNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LabelNotFound extends /*@__PURE__*/ LabelNotFound_base {
}
declare const NotEntitled_base: S.Class<NotEntitled, S.TaggedStruct<"NotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotEntitled extends /*@__PURE__*/ NotEntitled_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const OperationNotFound_base: S.Class<OperationNotFound, S.TaggedStruct<"OperationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OperationNotFound extends /*@__PURE__*/ OperationNotFound_base {
}
declare const SchemaNotFound_base: S.Class<SchemaNotFound, S.TaggedStruct<"SchemaNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SchemaNotFound extends /*@__PURE__*/ SchemaNotFound_base {
}
declare const ZonePurged_base: S.Class<ZonePurged, S.TaggedStruct<"ZonePurged", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZonePurged extends /*@__PURE__*/ ZonePurged_base {
}
export interface LabelsUserBulkCreateRequestBodyItem {
    /** The name of the label */
    name: string;
    /** The description of the label */
    description?: string;
    /** Metadata for the label */
    metadata?: unknown;
}
export declare const LabelsUserBulkCreateRequestBodyItem: S.Schema<LabelsUserBulkCreateRequestBodyItem>;
export type LabelsUserBulkCreateRequestBodyList = Array<LabelsUserBulkCreateRequestBodyItem>;
export declare const LabelsUserBulkCreateRequestBodyList: S.Schema<LabelsUserBulkCreateRequestBodyList>;
export interface BulkCreateLabelUsersRequest {
    /** Identifier. */
    zoneId: string;
    body: LabelsUserBulkCreateRequestBodyList;
}
export declare const BulkCreateLabelUsersRequest: S.Schema<BulkCreateLabelUsersRequest>;
export type LabelsUserBulkCreateResultItemSource = "user" | "managed";
export declare const LabelsUserBulkCreateResultItemSource: any;
export interface LabelsUserBulkCreateResultItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserBulkCreateResultItemSource;
}
export declare const LabelsUserBulkCreateResultItem: S.Schema<LabelsUserBulkCreateResultItem>;
export type LabelsUserBulkCreateResultList = Array<LabelsUserBulkCreateResultItem>;
export declare const LabelsUserBulkCreateResultList: S.Schema<LabelsUserBulkCreateResultList>;
export interface BulkCreateLabelUsersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LabelsUserBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkCreateLabelUsersResponse: S.Schema<BulkCreateLabelUsersResponse>;
export type OperationsLabelsBulkCreateRequestSelectorIncludeOperationIdsList = Array<string>;
export declare const OperationsLabelsBulkCreateRequestSelectorIncludeOperationIdsList: S.Schema<OperationsLabelsBulkCreateRequestSelectorIncludeOperationIdsList>;
export interface OperationsLabelsBulkCreateRequestSelectorInclude {
    operationIds: OperationsLabelsBulkCreateRequestSelectorIncludeOperationIdsList;
}
export declare const OperationsLabelsBulkCreateRequestSelectorInclude: S.Schema<OperationsLabelsBulkCreateRequestSelectorInclude>;
export interface OperationsLabelsBulkCreateRequestSelector {
    include: OperationsLabelsBulkCreateRequestSelectorInclude;
}
export declare const OperationsLabelsBulkCreateRequestSelector: S.Schema<OperationsLabelsBulkCreateRequestSelector>;
export type OperationsLabelsBulkCreateRequestManagedLabelsList = Array<string>;
export declare const OperationsLabelsBulkCreateRequestManagedLabelsList: S.Schema<OperationsLabelsBulkCreateRequestManagedLabelsList>;
export interface OperationsLabelsBulkCreateRequestManaged {
    /** List of managed label names. */
    labels?: OperationsLabelsBulkCreateRequestManagedLabelsList;
}
export declare const OperationsLabelsBulkCreateRequestManaged: S.Schema<OperationsLabelsBulkCreateRequestManaged>;
export type OperationsLabelsBulkCreateRequestUserLabelsList = Array<string>;
export declare const OperationsLabelsBulkCreateRequestUserLabelsList: S.Schema<OperationsLabelsBulkCreateRequestUserLabelsList>;
export interface OperationsLabelsBulkCreateRequestUser {
    /** List of user label names. */
    labels?: OperationsLabelsBulkCreateRequestUserLabelsList;
}
export declare const OperationsLabelsBulkCreateRequestUser: S.Schema<OperationsLabelsBulkCreateRequestUser>;
export interface BulkCreateOperationLabelsRequest {
    /** Identifier. */
    zoneId: string;
    /** Operation IDs selector */
    selector: OperationsLabelsBulkCreateRequestSelector;
    managed?: OperationsLabelsBulkCreateRequestManaged;
    user?: OperationsLabelsBulkCreateRequestUser;
}
export declare const BulkCreateOperationLabelsRequest: S.Schema<BulkCreateOperationLabelsRequest>;
export type OperationsLabelsBulkCreateResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsLabelsBulkCreateResultItemMethod: any;
export type OperationsLabelsBulkCreateResultItemLabelsItemSource = "user" | "managed";
export declare const OperationsLabelsBulkCreateResultItemLabelsItemSource: any;
export interface OperationsLabelsBulkCreateResultItemLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: OperationsLabelsBulkCreateResultItemLabelsItemSource;
}
export declare const OperationsLabelsBulkCreateResultItemLabelsItem: S.Schema<OperationsLabelsBulkCreateResultItemLabelsItem>;
export type OperationsLabelsBulkCreateResultItemLabelsList = Array<OperationsLabelsBulkCreateResultItemLabelsItem>;
export declare const OperationsLabelsBulkCreateResultItemLabelsList: S.Schema<OperationsLabelsBulkCreateResultItemLabelsList>;
export interface OperationsLabelsBulkCreateResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsBulkCreateResultItemMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsBulkCreateResultItemLabelsList | null;
}
export declare const OperationsLabelsBulkCreateResultItem: S.Schema<OperationsLabelsBulkCreateResultItem>;
export type OperationsLabelsBulkCreateResultList = Array<OperationsLabelsBulkCreateResultItem>;
export declare const OperationsLabelsBulkCreateResultList: S.Schema<OperationsLabelsBulkCreateResultList>;
export interface BulkCreateOperationLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsLabelsBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkCreateOperationLabelsResponse: S.Schema<BulkCreateOperationLabelsResponse>;
export type OperationsBulkCreateRequestBodyItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsBulkCreateRequestBodyItemMethod: any;
export interface OperationsBulkCreateRequestBodyItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsBulkCreateRequestBodyItemMethod | (string & {});
}
export declare const OperationsBulkCreateRequestBodyItem: S.Schema<OperationsBulkCreateRequestBodyItem>;
export type OperationsBulkCreateRequestBodyList = Array<OperationsBulkCreateRequestBodyItem>;
export declare const OperationsBulkCreateRequestBodyList: S.Schema<OperationsBulkCreateRequestBodyList>;
export interface BulkCreateOperationsRequest {
    /** Identifier. */
    zoneId: string;
    body: OperationsBulkCreateRequestBodyList;
}
export declare const BulkCreateOperationsRequest: S.Schema<BulkCreateOperationsRequest>;
export type OperationsBulkCreateResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsBulkCreateResultItemMethod: any;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds {
    /** The total number of auth-ids seen across this calculation. */
    authIdTokens?: number | null;
    /** The number of data points used for the threshold suggestion calculation. */
    dataPoints?: number | null;
    lastUpdated?: string | null;
    /** The p50 quantile of requests (in period_seconds). */
    p50?: number | null;
    /** The p90 quantile of requests (in period_seconds). */
    p90?: number | null;
    /** The p99 quantile of requests (in period_seconds). */
    p99?: number | null;
    /** The period over which this threshold is suggested. */
    periodSeconds?: number | null;
    /** The estimated number of requests covered by these calculations. */
    requests?: number | null;
    /** The suggested threshold in requests done by the same auth_id or period_seconds. */
    suggestedThreshold?: number | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds {
    thresholds?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds>;
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemas: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemas>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting {
    lastUpdated?: string | null;
    /** Target route. */
    route?: string | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting {
    /** API Routing settings on endpoint. */
    apiRouting?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 {
    /** Lower bound for percentile estimate */
    lower?: number | null;
    /** Upper bound for percentile estimate */
    upper?: number | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals {
    /** Upper and lower bound for percentile estimate */
    p90?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 | null;
    /** Upper and lower bound for percentile estimate */
    p95?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 | null;
    /** Upper and lower bound for percentile estimate */
    p99?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold {
    confidenceIntervals?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals | null;
    /** Suggested threshold. */
    mean?: number | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals {
    lastUpdated?: string | null;
    suggestedThreshold?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals {
    confidenceIntervals?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema {
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    /** True if schema is Cloudflare-provided. */
    isLearned?: boolean | null;
    /** Schema file name. */
    name?: string | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema>;
export type OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction: any;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** True if a Cloudflare-provided learned schema is available for this endpoint. */
    learnedAvailable?: boolean | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo>;
export interface OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export declare const OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfo: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfo>;
export type OperationsBulkCreateResultItemFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfo;
export declare const OperationsBulkCreateResultItemFeatures: any;
export interface OperationsBulkCreateResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsBulkCreateResultItemMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsBulkCreateResultItemFeatures | null;
}
export declare const OperationsBulkCreateResultItem: S.Schema<OperationsBulkCreateResultItem>;
export type OperationsBulkCreateResultList = Array<OperationsBulkCreateResultItem>;
export declare const OperationsBulkCreateResultList: S.Schema<OperationsBulkCreateResultList>;
export interface BulkCreateOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkCreateOperationsResponse: S.Schema<BulkCreateOperationsResponse>;
export interface BulkDeleteLabelUsersRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const BulkDeleteLabelUsersRequest: S.Schema<BulkDeleteLabelUsersRequest>;
export type LabelsUserBulkDeleteResultItemSource = "user" | "managed";
export declare const LabelsUserBulkDeleteResultItemSource: any;
export interface LabelsUserBulkDeleteResultItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserBulkDeleteResultItemSource;
}
export declare const LabelsUserBulkDeleteResultItem: S.Schema<LabelsUserBulkDeleteResultItem>;
export type LabelsUserBulkDeleteResultList = Array<LabelsUserBulkDeleteResultItem>;
export declare const LabelsUserBulkDeleteResultList: S.Schema<LabelsUserBulkDeleteResultList>;
export interface BulkDeleteLabelUsersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LabelsUserBulkDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkDeleteLabelUsersResponse: S.Schema<BulkDeleteLabelUsersResponse>;
export interface BulkDeleteOperationLabelsRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const BulkDeleteOperationLabelsRequest: S.Schema<BulkDeleteOperationLabelsRequest>;
export type OperationsLabelsBulkDeleteResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsLabelsBulkDeleteResultItemMethod: any;
export type OperationsLabelsBulkDeleteResultItemLabelsItemSource = "user" | "managed";
export declare const OperationsLabelsBulkDeleteResultItemLabelsItemSource: any;
export interface OperationsLabelsBulkDeleteResultItemLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: OperationsLabelsBulkDeleteResultItemLabelsItemSource;
}
export declare const OperationsLabelsBulkDeleteResultItemLabelsItem: S.Schema<OperationsLabelsBulkDeleteResultItemLabelsItem>;
export type OperationsLabelsBulkDeleteResultItemLabelsList = Array<OperationsLabelsBulkDeleteResultItemLabelsItem>;
export declare const OperationsLabelsBulkDeleteResultItemLabelsList: S.Schema<OperationsLabelsBulkDeleteResultItemLabelsList>;
export interface OperationsLabelsBulkDeleteResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsBulkDeleteResultItemMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsBulkDeleteResultItemLabelsList | null;
}
export declare const OperationsLabelsBulkDeleteResultItem: S.Schema<OperationsLabelsBulkDeleteResultItem>;
export type OperationsLabelsBulkDeleteResultList = Array<OperationsLabelsBulkDeleteResultItem>;
export declare const OperationsLabelsBulkDeleteResultList: S.Schema<OperationsLabelsBulkDeleteResultList>;
export interface BulkDeleteOperationLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsLabelsBulkDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkDeleteOperationLabelsResponse: S.Schema<BulkDeleteOperationLabelsResponse>;
export interface BulkDeleteOperationsRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const BulkDeleteOperationsRequest: S.Schema<BulkDeleteOperationsRequest>;
export interface BulkDeleteOperationsResponse {
}
export declare const BulkDeleteOperationsResponse: S.Schema<BulkDeleteOperationsResponse>;
export type DiscoveryOperationsBulkEditRequestBodyValueState = "review" | "ignored";
export declare const DiscoveryOperationsBulkEditRequestBodyValueState: any;
export interface DiscoveryOperationsBulkEditRequestBodyValue {
    /** Mark state of operation in API Discovery */
    state?: DiscoveryOperationsBulkEditRequestBodyValueState | (string & {});
}
export declare const DiscoveryOperationsBulkEditRequestBodyValue: S.Schema<DiscoveryOperationsBulkEditRequestBodyValue>;
export type DiscoveryOperationsBulkEditRequestBodyMap = {
    [key: string]: DiscoveryOperationsBulkEditRequestBodyValue | undefined;
};
export declare const DiscoveryOperationsBulkEditRequestBodyMap: S.Schema<DiscoveryOperationsBulkEditRequestBodyMap>;
export interface BulkPatchDiscoveryOperationsRequest {
    /** Identifier. */
    zoneId: string;
    body: DiscoveryOperationsBulkEditRequestBodyMap;
}
export declare const BulkPatchDiscoveryOperationsRequest: S.Schema<BulkPatchDiscoveryOperationsRequest>;
export type DiscoveryOperationsBulkEditResultValueState = "review" | "ignored";
export declare const DiscoveryOperationsBulkEditResultValueState: any;
export interface DiscoveryOperationsBulkEditResultValue {
    /** Mark state of operation in API Discovery */
    state?: DiscoveryOperationsBulkEditResultValueState | null;
}
export declare const DiscoveryOperationsBulkEditResultValue: S.Schema<DiscoveryOperationsBulkEditResultValue>;
export type DiscoveryOperationsBulkEditResultMap = {
    [key: string]: DiscoveryOperationsBulkEditResultValue | undefined;
};
export declare const DiscoveryOperationsBulkEditResultMap: S.Schema<DiscoveryOperationsBulkEditResultMap>;
export type BulkPatchDiscoveryOperationsResponse = DiscoveryOperationsBulkEditResultMap;
export declare const BulkPatchDiscoveryOperationsResponse: S.Schema<BulkPatchDiscoveryOperationsResponse>;
export type OperationsLabelsBulkUpdateRequestManagedLabelsList = Array<string>;
export declare const OperationsLabelsBulkUpdateRequestManagedLabelsList: S.Schema<OperationsLabelsBulkUpdateRequestManagedLabelsList>;
export interface OperationsLabelsBulkUpdateRequestManaged {
    /** List of managed label names. Providing an empty array will result in all managed labels being removed from all affected operations */
    labels: OperationsLabelsBulkUpdateRequestManagedLabelsList;
}
export declare const OperationsLabelsBulkUpdateRequestManaged: S.Schema<OperationsLabelsBulkUpdateRequestManaged>;
export type OperationsLabelsBulkUpdateRequestSelectorIncludeOperationIdsList = Array<string>;
export declare const OperationsLabelsBulkUpdateRequestSelectorIncludeOperationIdsList: S.Schema<OperationsLabelsBulkUpdateRequestSelectorIncludeOperationIdsList>;
export interface OperationsLabelsBulkUpdateRequestSelectorInclude {
    operationIds: OperationsLabelsBulkUpdateRequestSelectorIncludeOperationIdsList;
}
export declare const OperationsLabelsBulkUpdateRequestSelectorInclude: S.Schema<OperationsLabelsBulkUpdateRequestSelectorInclude>;
export interface OperationsLabelsBulkUpdateRequestSelector {
    include: OperationsLabelsBulkUpdateRequestSelectorInclude;
}
export declare const OperationsLabelsBulkUpdateRequestSelector: S.Schema<OperationsLabelsBulkUpdateRequestSelector>;
export type OperationsLabelsBulkUpdateRequestUserLabelsList = Array<string>;
export declare const OperationsLabelsBulkUpdateRequestUserLabelsList: S.Schema<OperationsLabelsBulkUpdateRequestUserLabelsList>;
export interface OperationsLabelsBulkUpdateRequestUser {
    /** List of user label names. Providing an empty array will result in all user labels being removed from all affected operations */
    labels: OperationsLabelsBulkUpdateRequestUserLabelsList;
}
export declare const OperationsLabelsBulkUpdateRequestUser: S.Schema<OperationsLabelsBulkUpdateRequestUser>;
export interface BulkUpdateOperationLabelsRequest {
    /** Identifier. */
    zoneId: string;
    /** Managed labels to replace for all affected operations */
    managed: OperationsLabelsBulkUpdateRequestManaged;
    /** Operation IDs selector */
    selector: OperationsLabelsBulkUpdateRequestSelector;
    /** User labels to replace for all affected operations */
    user: OperationsLabelsBulkUpdateRequestUser;
}
export declare const BulkUpdateOperationLabelsRequest: S.Schema<BulkUpdateOperationLabelsRequest>;
export type OperationsLabelsBulkUpdateResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsLabelsBulkUpdateResultItemMethod: any;
export type OperationsLabelsBulkUpdateResultItemLabelsItemSource = "user" | "managed";
export declare const OperationsLabelsBulkUpdateResultItemLabelsItemSource: any;
export interface OperationsLabelsBulkUpdateResultItemLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: OperationsLabelsBulkUpdateResultItemLabelsItemSource;
}
export declare const OperationsLabelsBulkUpdateResultItemLabelsItem: S.Schema<OperationsLabelsBulkUpdateResultItemLabelsItem>;
export type OperationsLabelsBulkUpdateResultItemLabelsList = Array<OperationsLabelsBulkUpdateResultItemLabelsItem>;
export declare const OperationsLabelsBulkUpdateResultItemLabelsList: S.Schema<OperationsLabelsBulkUpdateResultItemLabelsList>;
export interface OperationsLabelsBulkUpdateResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsBulkUpdateResultItemMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsBulkUpdateResultItemLabelsList | null;
}
export declare const OperationsLabelsBulkUpdateResultItem: S.Schema<OperationsLabelsBulkUpdateResultItem>;
export type OperationsLabelsBulkUpdateResultList = Array<OperationsLabelsBulkUpdateResultItem>;
export declare const OperationsLabelsBulkUpdateResultList: S.Schema<OperationsLabelsBulkUpdateResultList>;
export interface BulkUpdateOperationLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsLabelsBulkUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkUpdateOperationLabelsResponse: S.Schema<BulkUpdateOperationLabelsResponse>;
export type ExpressionTemplateFallthroughCreateRequestHostsList = Array<string>;
export declare const ExpressionTemplateFallthroughCreateRequestHostsList: S.Schema<ExpressionTemplateFallthroughCreateRequestHostsList>;
export interface CreateExpressionTemplateFallthroughRequest {
    /** Identifier. */
    zoneId: string;
    /** List of hosts to be targeted in the expression */
    hosts: ExpressionTemplateFallthroughCreateRequestHostsList;
}
export declare const CreateExpressionTemplateFallthroughRequest: S.Schema<CreateExpressionTemplateFallthroughRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateExpressionTemplateFallthroughResponse {
    /** WAF Expression for fallthrough */
    expression: string;
    /** Title for the expression */
    title: string;
}
export declare const CreateExpressionTemplateFallthroughResponse: S.Schema<CreateExpressionTemplateFallthroughResponse>;
export type OperationsCreateRequestMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsCreateRequestMethod: any;
export interface CreateOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsCreateRequestMethod | (string & {});
}
export declare const CreateOperationRequest: S.Schema<CreateOperationRequest>;
export type OperationsCreateResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsCreateResponseMethod: any;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureThresholdsThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList: S.Schema<OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList>;
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas: S.Schema<OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas>;
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas: S.Schema<OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas>;
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemas: S.Schema<OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemas>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureAPIRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema>;
export type OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction: any;
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** True if a Cloudflare-provided learned schema is available for this endpoint. */
    learnedAvailable?: boolean | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo: S.Schema<OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo>;
export interface OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export declare const OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfo: S.Schema<OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfo>;
export type OperationsCreateResponseFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsCreateResponseFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsCreateResponseFeaturesAPIShieldOperationFeatureSchemaInfo;
export declare const OperationsCreateResponseFeatures: any;
export type OperationsCreateResponseSchemasLearnedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsCreateResponseSchemasLearnedParametersItemMap: S.Schema<OperationsCreateResponseSchemasLearnedParametersItemMap>;
export type OperationsCreateResponseSchemasLearnedParametersList = Array<OperationsCreateResponseSchemasLearnedParametersItemMap>;
export declare const OperationsCreateResponseSchemasLearnedParametersList: S.Schema<OperationsCreateResponseSchemasLearnedParametersList>;
export type OperationsCreateResponseSchemasLearnedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsCreateResponseSchemasLearnedRequestBodyMap: S.Schema<OperationsCreateResponseSchemasLearnedRequestBodyMap>;
export interface OperationsCreateResponseSchemasLearned {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsCreateResponseSchemasLearnedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsCreateResponseSchemasLearnedRequestBodyMap | null;
}
export declare const OperationsCreateResponseSchemasLearned: S.Schema<OperationsCreateResponseSchemasLearned>;
export type OperationsCreateResponseSchemasUploadedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsCreateResponseSchemasUploadedParametersItemMap: S.Schema<OperationsCreateResponseSchemasUploadedParametersItemMap>;
export type OperationsCreateResponseSchemasUploadedParametersList = Array<OperationsCreateResponseSchemasUploadedParametersItemMap>;
export declare const OperationsCreateResponseSchemasUploadedParametersList: S.Schema<OperationsCreateResponseSchemasUploadedParametersList>;
export type OperationsCreateResponseSchemasUploadedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsCreateResponseSchemasUploadedRequestBodyMap: S.Schema<OperationsCreateResponseSchemasUploadedRequestBodyMap>;
export interface OperationsCreateResponseSchemasUploaded {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsCreateResponseSchemasUploadedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsCreateResponseSchemasUploadedRequestBodyMap | null;
}
export declare const OperationsCreateResponseSchemasUploaded: S.Schema<OperationsCreateResponseSchemasUploaded>;
export interface OperationsCreateResponseSchemas {
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    learned?: OperationsCreateResponseSchemasLearned | null;
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    uploaded?: OperationsCreateResponseSchemasUploaded | null;
}
export declare const OperationsCreateResponseSchemas: S.Schema<OperationsCreateResponseSchemas>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOperationResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsCreateResponseMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsCreateResponseFeatures | null;
    /** OpenAPI JSON schemas for an operation, including both user-uploaded and Cloudflare-learned schemas. */
    schemas?: OperationsCreateResponseSchemas | null;
}
export declare const CreateOperationResponse: S.Schema<CreateOperationResponse>;
export type OperationsLabelsCreateRequestManagedList = Array<string>;
export declare const OperationsLabelsCreateRequestManagedList: S.Schema<OperationsLabelsCreateRequestManagedList>;
export type OperationsLabelsCreateRequestUserList = Array<string>;
export declare const OperationsLabelsCreateRequestUserList: S.Schema<OperationsLabelsCreateRequestUserList>;
export interface CreateOperationLabelRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** List of managed label names. */
    managed?: OperationsLabelsCreateRequestManagedList;
    /** List of user label names. */
    user?: OperationsLabelsCreateRequestUserList;
}
export declare const CreateOperationLabelRequest: S.Schema<CreateOperationLabelRequest>;
export type OperationsLabelsCreateResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsLabelsCreateResponseMethod: any;
export type OperationsLabelsCreateResponseLabelsItemSource = "user" | "managed";
export declare const OperationsLabelsCreateResponseLabelsItemSource: any;
export interface OperationsLabelsCreateResponseLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: OperationsLabelsCreateResponseLabelsItemSource;
}
export declare const OperationsLabelsCreateResponseLabelsItem: S.Schema<OperationsLabelsCreateResponseLabelsItem>;
export type OperationsLabelsCreateResponseLabelsList = Array<OperationsLabelsCreateResponseLabelsItem>;
export declare const OperationsLabelsCreateResponseLabelsList: S.Schema<OperationsLabelsCreateResponseLabelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOperationLabelResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsCreateResponseMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsCreateResponseLabelsList | null;
}
export declare const CreateOperationLabelResponse: S.Schema<CreateOperationLabelResponse>;
export interface CreateUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** Schema file bytes (File/Blob), sent as the multipart `file` part. */
    file: unknown;
    /** Kind of schema (openapi_v3). */
    kind: string;
    /** Name of the schema. */
    name?: string;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export declare const CreateUserSchemaRequest: S.Schema<CreateUserSchemaRequest>;
export type UserSchemasCreateResponseSchemaKind = "openapi_v3";
export declare const UserSchemasCreateResponseSchemaKind: any;
export interface UserSchemasCreateResponseSchema {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasCreateResponseSchemaKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export declare const UserSchemasCreateResponseSchema: S.Schema<UserSchemasCreateResponseSchema>;
export type UserSchemasCreateResponseUploadDetailsWarningsItemLocationsList = Array<string>;
export declare const UserSchemasCreateResponseUploadDetailsWarningsItemLocationsList: S.Schema<UserSchemasCreateResponseUploadDetailsWarningsItemLocationsList>;
export interface UserSchemasCreateResponseUploadDetailsWarningsItem {
    /** Code that identifies the event that occurred. */
    code: number;
    /** JSONPath location(s) in the schema where these events were encountered. See <https://goessner.net/articles/JsonPath/> for JSONPath specification. */
    locations?: UserSchemasCreateResponseUploadDetailsWarningsItemLocationsList | null;
    /** Diagnostic message that describes the event. */
    message?: string | null;
}
export declare const UserSchemasCreateResponseUploadDetailsWarningsItem: S.Schema<UserSchemasCreateResponseUploadDetailsWarningsItem>;
export type UserSchemasCreateResponseUploadDetailsWarningsList = Array<UserSchemasCreateResponseUploadDetailsWarningsItem>;
export declare const UserSchemasCreateResponseUploadDetailsWarningsList: S.Schema<UserSchemasCreateResponseUploadDetailsWarningsList>;
export interface UserSchemasCreateResponseUploadDetails {
    /** Diagnostic warning events that occurred during processing. These events are non-critical errors found within the schema. */
    warnings?: UserSchemasCreateResponseUploadDetailsWarningsList | null;
}
export declare const UserSchemasCreateResponseUploadDetails: S.Schema<UserSchemasCreateResponseUploadDetails>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateUserSchemaResponse {
    schema: UserSchemasCreateResponseSchema;
    uploadDetails?: UserSchemasCreateResponseUploadDetails | null;
}
export declare const CreateUserSchemaResponse: S.Schema<CreateUserSchemaResponse>;
export interface DeleteLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
}
export declare const DeleteLabelUserRequest: S.Schema<DeleteLabelUserRequest>;
export type LabelsUserDeleteResponseSource = "user" | "managed";
export declare const LabelsUserDeleteResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserDeleteResponseSource;
}
export declare const DeleteLabelUserResponse: S.Schema<DeleteLabelUserResponse>;
export interface DeleteOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export declare const DeleteOperationRequest: S.Schema<DeleteOperationRequest>;
export interface DeleteOperationResponse {
}
export declare const DeleteOperationResponse: S.Schema<DeleteOperationResponse>;
export interface DeleteOperationLabelRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export declare const DeleteOperationLabelRequest: S.Schema<DeleteOperationLabelRequest>;
export type OperationsLabelsDeleteResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsLabelsDeleteResponseMethod: any;
export type OperationsLabelsDeleteResponseLabelsItemSource = "user" | "managed";
export declare const OperationsLabelsDeleteResponseLabelsItemSource: any;
export interface OperationsLabelsDeleteResponseLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: OperationsLabelsDeleteResponseLabelsItemSource;
}
export declare const OperationsLabelsDeleteResponseLabelsItem: S.Schema<OperationsLabelsDeleteResponseLabelsItem>;
export type OperationsLabelsDeleteResponseLabelsList = Array<OperationsLabelsDeleteResponseLabelsItem>;
export declare const OperationsLabelsDeleteResponseLabelsList: S.Schema<OperationsLabelsDeleteResponseLabelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOperationLabelResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsDeleteResponseMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsDeleteResponseLabelsList | null;
}
export declare const DeleteOperationLabelResponse: S.Schema<DeleteOperationLabelResponse>;
export interface DeleteUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
}
export declare const DeleteUserSchemaRequest: S.Schema<DeleteUserSchemaRequest>;
export interface DeleteUserSchemaResponse {
}
export declare const DeleteUserSchemaResponse: S.Schema<DeleteUserSchemaResponse>;
export interface GetConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** Ensures that the configuration is written or retrieved in normalized fashion */
    normalize?: boolean;
}
export declare const GetConfigurationRequest: S.Schema<GetConfigurationRequest>;
export type ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType = "header" | "cookie";
export declare const ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType: any;
export interface ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic {
    /** The name of the characteristic field, i.e., the header or cookie name. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType;
}
export declare const ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic: S.Schema<ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic>;
export type ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType = "jwt";
export declare const ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType: any;
export interface ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim {
    /** Claim location expressed as `$(token_config_id):$(json_path)`, where `token_config_id` */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType;
}
export declare const ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim: S.Schema<ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim>;
export type ConfigurationsGetResponseAuthIdCharacteristicsItem = ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic | ConfigurationsGetResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim;
export declare const ConfigurationsGetResponseAuthIdCharacteristicsItem: any;
export type ConfigurationsGetResponseAuthIdCharacteristicsList = Array<ConfigurationsGetResponseAuthIdCharacteristicsItem>;
export declare const ConfigurationsGetResponseAuthIdCharacteristicsList: S.Schema<ConfigurationsGetResponseAuthIdCharacteristicsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigurationResponse {
    authIdCharacteristics: ConfigurationsGetResponseAuthIdCharacteristicsList;
}
export declare const GetConfigurationResponse: S.Schema<GetConfigurationResponse>;
export interface GetDiscoveryRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetDiscoveryRequest: S.Schema<GetDiscoveryRequest>;
export type DiscoveryGetResponseSchemasList = Array<unknown>;
export declare const DiscoveryGetResponseSchemasList: S.Schema<DiscoveryGetResponseSchemasList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDiscoveryResponse {
    schemas: DiscoveryGetResponseSchemasList;
    timestamp: string;
}
export declare const GetDiscoveryResponse: S.Schema<GetDiscoveryResponse>;
export interface GetLabelManagedRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Include `mapped_resources` for each label */
    withMappedResourceCounts?: boolean;
}
export declare const GetLabelManagedRequest: S.Schema<GetLabelManagedRequest>;
export type LabelsManagedGetResponseSource = "user" | "managed";
export declare const LabelsManagedGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLabelManagedResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsManagedGetResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export declare const GetLabelManagedResponse: S.Schema<GetLabelManagedResponse>;
export interface GetLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Include `mapped_resources` for each label */
    withMappedResourceCounts?: boolean;
}
export declare const GetLabelUserRequest: S.Schema<GetLabelUserRequest>;
export type LabelsUserGetResponseSource = "user" | "managed";
export declare const LabelsUserGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserGetResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export declare const GetLabelUserResponse: S.Schema<GetLabelUserResponse>;
export type OperationsGetRequestFeature = "thresholds" | "parameter_schemas" | "schema_info";
export declare const OperationsGetRequestFeature: any;
export type OperationsGetRequestFeatureList = Array<OperationsGetRequestFeature | (string & {})>;
export declare const OperationsGetRequestFeatureList: S.Schema<OperationsGetRequestFeatureList>;
export interface GetOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: OperationsGetRequestFeatureList;
    /** When true, includes OpenAPI schemas (both uploaded and learned) for the operation in the response. Due to the conversion overhead, this parameter is only supported on single-operation retrieval. */
    withSchemas?: boolean;
}
export declare const GetOperationRequest: S.Schema<GetOperationRequest>;
export type OperationsGetResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsGetResponseMethod: any;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureThresholdsThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList: S.Schema<OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList>;
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas: S.Schema<OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas>;
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas: S.Schema<OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas>;
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemas: S.Schema<OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemas>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureAPIRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema>;
export type OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction: any;
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** True if a Cloudflare-provided learned schema is available for this endpoint. */
    learnedAvailable?: boolean | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo: S.Schema<OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo>;
export interface OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export declare const OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfo: S.Schema<OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfo>;
export type OperationsGetResponseFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsGetResponseFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsGetResponseFeaturesAPIShieldOperationFeatureSchemaInfo;
export declare const OperationsGetResponseFeatures: any;
export type OperationsGetResponseSchemasLearnedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsGetResponseSchemasLearnedParametersItemMap: S.Schema<OperationsGetResponseSchemasLearnedParametersItemMap>;
export type OperationsGetResponseSchemasLearnedParametersList = Array<OperationsGetResponseSchemasLearnedParametersItemMap>;
export declare const OperationsGetResponseSchemasLearnedParametersList: S.Schema<OperationsGetResponseSchemasLearnedParametersList>;
export type OperationsGetResponseSchemasLearnedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsGetResponseSchemasLearnedRequestBodyMap: S.Schema<OperationsGetResponseSchemasLearnedRequestBodyMap>;
export interface OperationsGetResponseSchemasLearned {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsGetResponseSchemasLearnedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsGetResponseSchemasLearnedRequestBodyMap | null;
}
export declare const OperationsGetResponseSchemasLearned: S.Schema<OperationsGetResponseSchemasLearned>;
export type OperationsGetResponseSchemasUploadedParametersItemMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsGetResponseSchemasUploadedParametersItemMap: S.Schema<OperationsGetResponseSchemasUploadedParametersItemMap>;
export type OperationsGetResponseSchemasUploadedParametersList = Array<OperationsGetResponseSchemasUploadedParametersItemMap>;
export declare const OperationsGetResponseSchemasUploadedParametersList: S.Schema<OperationsGetResponseSchemasUploadedParametersList>;
export type OperationsGetResponseSchemasUploadedRequestBodyMap = {
    [key: string]: unknown | undefined;
};
export declare const OperationsGetResponseSchemasUploadedRequestBodyMap: S.Schema<OperationsGetResponseSchemasUploadedRequestBodyMap>;
export interface OperationsGetResponseSchemasUploaded {
    /** OpenAPI parameter objects describing path, query, header, or cookie parameters. */
    parameters?: OperationsGetResponseSchemasUploadedParametersList | null;
    /** OpenAPI request body object describing the expected request payload. */
    requestBody?: OperationsGetResponseSchemasUploadedRequestBodyMap | null;
}
export declare const OperationsGetResponseSchemasUploaded: S.Schema<OperationsGetResponseSchemasUploaded>;
export interface OperationsGetResponseSchemas {
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    learned?: OperationsGetResponseSchemasLearned | null;
    /** An OpenAPI operation object fragment containing schema information for an operation. May include parameter definitions, request body specifications, and a component schema extension. */
    uploaded?: OperationsGetResponseSchemasUploaded | null;
}
export declare const OperationsGetResponseSchemas: S.Schema<OperationsGetResponseSchemas>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOperationResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsGetResponseMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsGetResponseFeatures | null;
    /** OpenAPI JSON schemas for an operation, including both user-uploaded and Cloudflare-learned schemas. */
    schemas?: OperationsGetResponseSchemas | null;
}
export declare const GetOperationResponse: S.Schema<GetOperationResponse>;
export interface GetOperationSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export declare const GetOperationSchemaValidationRequest: S.Schema<GetOperationSchemaValidationRequest>;
export type OperationsSchemaValidationGetResponseMitigationAction = "log" | "block" | "none";
export declare const OperationsSchemaValidationGetResponseMitigationAction: any;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetOperationSchemaValidationResponse {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationGetResponseMitigationAction | null;
    /** UUID. */
    operationId?: string | null;
}
export declare const GetOperationSchemaValidationResponse: S.Schema<GetOperationSchemaValidationResponse>;
export interface GetSettingSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetSettingSchemaValidationRequest: S.Schema<GetSettingSchemaValidationRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSettingSchemaValidationResponse {
}
export declare const GetSettingSchemaValidationResponse: S.Schema<GetSettingSchemaValidationResponse>;
export interface GetUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
}
export declare const GetUserSchemaRequest: S.Schema<GetUserSchemaRequest>;
export type UserSchemasGetResponseKind = "openapi_v3";
export declare const UserSchemasGetResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserSchemaResponse {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasGetResponseKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export declare const GetUserSchemaResponse: S.Schema<GetUserSchemaResponse>;
export type DiscoveryOperationsListRequestDirection = "asc" | "desc";
export declare const DiscoveryOperationsListRequestDirection: any;
export type DiscoveryOperationsListRequestHostList = Array<string>;
export declare const DiscoveryOperationsListRequestHostList: S.Schema<DiscoveryOperationsListRequestHostList>;
export type DiscoveryOperationsListRequestMethodList = Array<string>;
export declare const DiscoveryOperationsListRequestMethodList: S.Schema<DiscoveryOperationsListRequestMethodList>;
export type DiscoveryOperationsListRequestOrder = "host" | "method" | "endpoint" | "traffic_stats.requests" | "traffic_stats.last_updated";
export declare const DiscoveryOperationsListRequestOrder: any;
export type DiscoveryOperationsListRequestOrigin = "ML" | "SessionIdentifier" | "LabelDiscovery";
export declare const DiscoveryOperationsListRequestOrigin: any;
export type DiscoveryOperationsListRequestState = "review" | "saved" | "ignored";
export declare const DiscoveryOperationsListRequestState: any;
export interface ListDiscoveryOperationsRequest {
    /** Identifier. */
    zoneId: string;
    /** When `true`, only return API Discovery results that are not saved into API Shield Endpoint Management */
    diff?: boolean;
    /** Direction to order results. */
    direction?: DiscoveryOperationsListRequestDirection | (string & {});
    /** Filter results to only include endpoints containing this pattern. */
    endpoint?: string;
    /** Filter results to only include the specified hosts. */
    host?: DiscoveryOperationsListRequestHostList;
    /** Filter results to only include the specified HTTP methods. */
    method?: DiscoveryOperationsListRequestMethodList;
    /** Field to order by */
    order?: DiscoveryOperationsListRequestOrder | (string & {});
    /** Filter results to only include discovery results sourced from a particular discovery engine */
    origin?: DiscoveryOperationsListRequestOrigin | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter results to only include discovery results in a particular state. States are as follows */
    state?: DiscoveryOperationsListRequestState | (string & {});
}
export declare const ListDiscoveryOperationsRequest: S.Schema<ListDiscoveryOperationsRequest>;
export type DiscoveryOperationsListResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const DiscoveryOperationsListResultItemMethod: any;
export type DiscoveryOperationsListResultItemOriginItem = "ML" | "SessionIdentifier" | "LabelDiscovery";
export declare const DiscoveryOperationsListResultItemOriginItem: any;
export type DiscoveryOperationsListResultItemOriginList = Array<DiscoveryOperationsListResultItemOriginItem>;
export declare const DiscoveryOperationsListResultItemOriginList: S.Schema<DiscoveryOperationsListResultItemOriginList>;
export type DiscoveryOperationsListResultItemState = "review" | "saved" | "ignored";
export declare const DiscoveryOperationsListResultItemState: any;
export interface DiscoveryOperationsListResultItemFeaturesTrafficStats {
    lastUpdated: string;
    /** The period in seconds these statistics were computed over */
    periodSeconds: number;
    /** The average number of requests seen during this period */
    requests: number;
}
export declare const DiscoveryOperationsListResultItemFeaturesTrafficStats: S.Schema<DiscoveryOperationsListResultItemFeaturesTrafficStats>;
export interface DiscoveryOperationsListResultItemFeatures {
    trafficStats?: DiscoveryOperationsListResultItemFeaturesTrafficStats | null;
}
export declare const DiscoveryOperationsListResultItemFeatures: S.Schema<DiscoveryOperationsListResultItemFeatures>;
export interface DiscoveryOperationsListResultItem {
    /** UUID. */
    id: string;
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: DiscoveryOperationsListResultItemMethod;
    /** API discovery engine(s) that discovered this operation */
    origin: DiscoveryOperationsListResultItemOriginList;
    /** State of operation in API Discovery */
    state: DiscoveryOperationsListResultItemState;
    features?: DiscoveryOperationsListResultItemFeatures | null;
}
export declare const DiscoveryOperationsListResultItem: S.Schema<DiscoveryOperationsListResultItem>;
export type DiscoveryOperationsListResultList = Array<DiscoveryOperationsListResultItem>;
export declare const DiscoveryOperationsListResultList: S.Schema<DiscoveryOperationsListResultList>;
export interface ListDiscoveryOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DiscoveryOperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDiscoveryOperationsResponse: S.Schema<ListDiscoveryOperationsResponse>;
export type LabelsListRequestDirection = "asc" | "desc";
export declare const LabelsListRequestDirection: any;
export type LabelsListRequestOrder = "name" | "description" | "created_at" | "last_updated" | "mapped_resources.operations";
export declare const LabelsListRequestOrder: any;
export type LabelsListRequestSource = "user" | "managed";
export declare const LabelsListRequestSource: any;
export interface ListLabelsRequest {
    /** Identifier. */
    zoneId: string;
    /** Direction to order results. */
    direction?: LabelsListRequestDirection | (string & {});
    /** Filter for labels where the name or description matches using substring match */
    filter?: string;
    /** Field to order by */
    order?: LabelsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter for labels with source */
    source?: LabelsListRequestSource | (string & {});
    /** Include `mapped_resources` for each label */
    withMappedResourceCounts?: boolean;
}
export declare const ListLabelsRequest: S.Schema<ListLabelsRequest>;
export type LabelsListResultItemSource = "user" | "managed";
export declare const LabelsListResultItemSource: any;
export interface LabelsListResultItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsListResultItemSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export declare const LabelsListResultItem: S.Schema<LabelsListResultItem>;
export type LabelsListResultList = Array<LabelsListResultItem>;
export declare const LabelsListResultList: S.Schema<LabelsListResultList>;
export interface ListLabelsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LabelsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLabelsResponse: S.Schema<ListLabelsResponse>;
export type OperationsListRequestDirection = "asc" | "desc";
export declare const OperationsListRequestDirection: any;
export type OperationsListRequestFeature = "thresholds" | "parameter_schemas" | "schema_info";
export declare const OperationsListRequestFeature: any;
export type OperationsListRequestFeatureList = Array<OperationsListRequestFeature | (string & {})>;
export declare const OperationsListRequestFeatureList: S.Schema<OperationsListRequestFeatureList>;
export type OperationsListRequestHostList = Array<string>;
export declare const OperationsListRequestHostList: S.Schema<OperationsListRequestHostList>;
export type OperationsListRequestMethodList = Array<string>;
export declare const OperationsListRequestMethodList: S.Schema<OperationsListRequestMethodList>;
export type OperationsListRequestOrder = "method" | "host" | "endpoint" | "thresholds.$key";
export declare const OperationsListRequestOrder: any;
export interface ListOperationsRequest {
    /** Identifier. */
    zoneId: string;
    /** Direction to order results. */
    direction?: OperationsListRequestDirection | (string & {});
    /** Filter results to only include endpoints containing this pattern. */
    endpoint?: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: OperationsListRequestFeatureList;
    /** Filter results to only include the specified hosts. */
    host?: OperationsListRequestHostList;
    /** Filter results to only include the specified HTTP methods. */
    method?: OperationsListRequestMethodList;
    /** Field to order by. When requesting a feature, the feature keys are available for ordering as well, e.g., `thresholds.suggested_threshold`. */
    order?: OperationsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListOperationsRequest: S.Schema<ListOperationsRequest>;
export type OperationsListResultItemMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsListResultItemMethod: any;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList: S.Schema<OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList>;
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas: S.Schema<OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas>;
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas: S.Schema<OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas>;
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemas: S.Schema<OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemas>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureAPIRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema>;
export type OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction: any;
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** True if a Cloudflare-provided learned schema is available for this endpoint. */
    learnedAvailable?: boolean | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo: S.Schema<OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo>;
export interface OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export declare const OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfo: S.Schema<OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfo>;
export type OperationsListResultItemFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | OperationsListResultItemFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | OperationsListResultItemFeaturesAPIShieldOperationFeatureSchemaInfo;
export declare const OperationsListResultItemFeatures: any;
export interface OperationsListResultItem {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsListResultItemMethod;
    /** UUID. */
    operationId: string;
    features?: OperationsListResultItemFeatures | null;
}
export declare const OperationsListResultItem: S.Schema<OperationsListResultItem>;
export type OperationsListResultList = Array<OperationsListResultItem>;
export declare const OperationsListResultList: S.Schema<OperationsListResultList>;
export interface ListOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOperationsResponse: S.Schema<ListOperationsResponse>;
export type SchemasListRequestFeature = "thresholds" | "parameter_schemas" | "schema_info";
export declare const SchemasListRequestFeature: any;
export type SchemasListRequestFeatureList = Array<SchemasListRequestFeature | (string & {})>;
export declare const SchemasListRequestFeatureList: S.Schema<SchemasListRequestFeatureList>;
export type SchemasListRequestHostList = Array<string>;
export declare const SchemasListRequestHostList: S.Schema<SchemasListRequestHostList>;
export interface ListSchemasRequest {
    /** Identifier. */
    zoneId: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: SchemasListRequestFeatureList;
    /** Receive schema only for the given host(s). */
    host?: SchemasListRequestHostList;
}
export declare const ListSchemasRequest: S.Schema<ListSchemasRequest>;
export type SchemasListResponseSchemasList = Array<unknown>;
export declare const SchemasListResponseSchemasList: S.Schema<SchemasListResponseSchemasList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListSchemasResponse {
    schemas?: SchemasListResponseSchemasList | null;
    timestamp?: string | null;
}
export declare const ListSchemasResponse: S.Schema<ListSchemasResponse>;
export interface ListUserSchemaHostsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListUserSchemaHostsRequest: S.Schema<ListUserSchemaHostsRequest>;
export type UserSchemasHostsListResultItemHostsList = Array<string>;
export declare const UserSchemasHostsListResultItemHostsList: S.Schema<UserSchemasHostsListResultItemHostsList>;
export interface UserSchemasHostsListResultItem {
    createdAt: string;
    /** Hosts serving the schema, e.g zone.host.com */
    hosts: UserSchemasHostsListResultItemHostsList;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
}
export declare const UserSchemasHostsListResultItem: S.Schema<UserSchemasHostsListResultItem>;
export type UserSchemasHostsListResultList = Array<UserSchemasHostsListResultItem>;
export declare const UserSchemasHostsListResultList: S.Schema<UserSchemasHostsListResultList>;
export interface ListUserSchemaHostsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserSchemasHostsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListUserSchemaHostsResponse: S.Schema<ListUserSchemaHostsResponse>;
export type UserSchemasOperationsListRequestFeature = "thresholds" | "parameter_schemas" | "schema_info";
export declare const UserSchemasOperationsListRequestFeature: any;
export type UserSchemasOperationsListRequestFeatureList = Array<UserSchemasOperationsListRequestFeature | (string & {})>;
export declare const UserSchemasOperationsListRequestFeatureList: S.Schema<UserSchemasOperationsListRequestFeatureList>;
export type UserSchemasOperationsListRequestHostList = Array<string>;
export declare const UserSchemasOperationsListRequestHostList: S.Schema<UserSchemasOperationsListRequestHostList>;
export type UserSchemasOperationsListRequestMethodList = Array<string>;
export declare const UserSchemasOperationsListRequestMethodList: S.Schema<UserSchemasOperationsListRequestMethodList>;
export type UserSchemasOperationsListRequestOperationStatus = "new" | "existing";
export declare const UserSchemasOperationsListRequestOperationStatus: any;
export interface ListUserSchemaOperationsRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
    /** Filter results to only include endpoints containing this pattern. */
    endpoint?: string;
    /** Add feature(s) to the results. The feature name that is given here corresponds to the resulting feature object. Have a look at the top-level object description for more details on the specific meaning. */
    feature?: UserSchemasOperationsListRequestFeatureList;
    /** Filter results to only include the specified hosts. */
    host?: UserSchemasOperationsListRequestHostList;
    /** Filter results to only include the specified HTTP methods. */
    method?: UserSchemasOperationsListRequestMethodList;
    /** Filter results by whether operations exist in API Shield Endpoint Management or not. `new` will just return operations from the schema that do not exist in API Shield Endpoint Management. `existing` will just return operations from the schema that already exist in API Shield Endpoint Management. */
    operationStatus?: UserSchemasOperationsListRequestOperationStatus | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListUserSchemaOperationsRequest: S.Schema<ListUserSchemaOperationsRequest>;
export type UserSchemasOperationsListResultItemAPIShieldOperationMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const UserSchemasOperationsListResultItemAPIShieldOperationMethod: any;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureThresholdsThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureThresholdsThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholdsThresholds>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureThresholds = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureThresholds: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList = Array<unknown>;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList>;
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas {
    /** An array containing the learned parameter schemas. */
    parameters?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemasParametersList | null;
    /** An empty response object. This field is required to yield a valid operation schema. */
    responses?: unknown | null;
}
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas>;
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas {
    lastUpdated?: string | null;
    /** An operation schema object containing a response. */
    parameterSchemas?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemasParameterSchemas | null;
}
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas>;
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemas {
    parameterSchemas: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemasParameterSchemas;
}
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemas: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemas>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRoutingApiRouting>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureAPIRouting = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureAPIRouting: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP95: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99 = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP99: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervalsP90>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThresholdConfidenceIntervals>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervalsSuggestedThreshold>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervalsConfidenceIntervals>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervals = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureConfidenceIntervals: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema: S.Schema<OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction = "none" | "log" | "block";
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction: any;
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo {
    /** Schema active on endpoint. */
    activeSchema?: OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoActiveSchema | null;
    /** True if a Cloudflare-provided learned schema is available for this endpoint. */
    learnedAvailable?: boolean | null;
    /** Action taken on requests failing validation. */
    mitigationAction?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfoMitigationAction | null;
}
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo>;
export interface UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfo {
    schemaInfo?: UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfoSchemaInfo | null;
}
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfo: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfo>;
export type UserSchemasOperationsListResultItemAPIShieldOperationFeatures = OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureThresholds | UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureParameterSchemas | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureAPIRouting | OperationsBulkCreateResultItemFeaturesAPIShieldOperationFeatureConfidenceIntervals | UserSchemasOperationsListResultItemAPIShieldOperationFeaturesAPIShieldOperationFeatureSchemaInfo;
export declare const UserSchemasOperationsListResultItemAPIShieldOperationFeatures: any;
export interface UserSchemasOperationsListResultItemAPIShieldOperation {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: UserSchemasOperationsListResultItemAPIShieldOperationMethod;
    /** UUID. */
    operationId: string;
    features?: UserSchemasOperationsListResultItemAPIShieldOperationFeatures | null;
}
export declare const UserSchemasOperationsListResultItemAPIShieldOperation: S.Schema<UserSchemasOperationsListResultItemAPIShieldOperation>;
export type UserSchemasOperationsListResultItemAPIShieldBasicOperationMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const UserSchemasOperationsListResultItemAPIShieldBasicOperationMethod: any;
export interface UserSchemasOperationsListResultItemAPIShieldBasicOperation {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    /** The HTTP method used to access the endpoint. */
    method: UserSchemasOperationsListResultItemAPIShieldBasicOperationMethod;
}
export declare const UserSchemasOperationsListResultItemAPIShieldBasicOperation: S.Schema<UserSchemasOperationsListResultItemAPIShieldBasicOperation>;
export type UserSchemasOperationsListResultItem = UserSchemasOperationsListResultItemAPIShieldOperation | UserSchemasOperationsListResultItemAPIShieldBasicOperation;
export declare const UserSchemasOperationsListResultItem: any;
export type UserSchemasOperationsListResultList = Array<UserSchemasOperationsListResultItem>;
export declare const UserSchemasOperationsListResultList: S.Schema<UserSchemasOperationsListResultList>;
export interface ListUserSchemaOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserSchemasOperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListUserSchemaOperationsResponse: S.Schema<ListUserSchemaOperationsResponse>;
export interface ListUserSchemasRequest {
    /** Identifier. */
    zoneId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export declare const ListUserSchemasRequest: S.Schema<ListUserSchemasRequest>;
export type UserSchemasListResultItemKind = "openapi_v3";
export declare const UserSchemasListResultItemKind: any;
export interface UserSchemasListResultItem {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasListResultItemKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export declare const UserSchemasListResultItem: S.Schema<UserSchemasListResultItem>;
export type UserSchemasListResultList = Array<UserSchemasListResultItem>;
export declare const UserSchemasListResultList: S.Schema<UserSchemasListResultList>;
export interface ListUserSchemasResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserSchemasListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListUserSchemasResponse: S.Schema<ListUserSchemasResponse>;
export interface PatchLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** The description of the label */
    description?: string;
    /** Metadata for the label */
    metadata?: unknown;
}
export declare const PatchLabelUserRequest: S.Schema<PatchLabelUserRequest>;
export type LabelsUserEditResponseSource = "user" | "managed";
export declare const LabelsUserEditResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserEditResponseSource;
}
export declare const PatchLabelUserResponse: S.Schema<PatchLabelUserResponse>;
export type OperationsSchemaValidationEditRequestSettingsMultipleRequestMitigationAction = "log" | "block" | "none";
export declare const OperationsSchemaValidationEditRequestSettingsMultipleRequestMitigationAction: any;
export interface OperationsSchemaValidationEditRequestSettingsMultipleRequest {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationEditRequestSettingsMultipleRequestMitigationAction | (string & {});
}
export declare const OperationsSchemaValidationEditRequestSettingsMultipleRequest: S.Schema<OperationsSchemaValidationEditRequestSettingsMultipleRequest>;
export interface PatchOperationSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    settingsMultipleRequest: OperationsSchemaValidationEditRequestSettingsMultipleRequest;
}
export declare const PatchOperationSchemaValidationRequest: S.Schema<PatchOperationSchemaValidationRequest>;
export type OperationsSchemaValidationEditResponseMitigationAction = "log" | "block" | "none";
export declare const OperationsSchemaValidationEditResponseMitigationAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOperationSchemaValidationResponse {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationEditResponseMitigationAction | null;
}
export declare const PatchOperationSchemaValidationResponse: S.Schema<PatchOperationSchemaValidationResponse>;
export type SettingsSchemaValidationEditRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsSchemaValidationEditRequestValidationDefaultMitigationAction: any;
export type SettingsSchemaValidationEditRequestValidationOverrideMitigationAction = "none" | "disable_override";
export declare const SettingsSchemaValidationEditRequestValidationOverrideMitigationAction: any;
export interface PatchSettingSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used when there is no mitigation action defined on the operation */
    validationDefaultMitigationAction?: SettingsSchemaValidationEditRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsSchemaValidationEditRequestValidationOverrideMitigationAction | (string & {});
}
export declare const PatchSettingSchemaValidationRequest: S.Schema<PatchSettingSchemaValidationRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchSettingSchemaValidationResponse {
}
export declare const PatchSettingSchemaValidationResponse: S.Schema<PatchSettingSchemaValidationResponse>;
export interface PatchUserSchemaRequest {
    /** Identifier. */
    zoneId: string;
    schemaId: string;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export declare const PatchUserSchemaRequest: S.Schema<PatchUserSchemaRequest>;
export type UserSchemasEditResponseKind = "openapi_v3";
export declare const UserSchemasEditResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUserSchemaResponse {
    createdAt: string;
    /** Kind of schema */
    kind: UserSchemasEditResponseKind;
    /** Name of the schema */
    name: string;
    /** UUID. */
    schemaId: string;
    /** Source of the schema */
    source?: string | null;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean | null;
}
export declare const PatchUserSchemaResponse: S.Schema<PatchUserSchemaResponse>;
export type ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType = "header" | "cookie";
export declare const ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType: any;
export interface ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic {
    /** The name of the characteristic field, i.e., the header or cookie name. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType | (string & {});
}
export declare const ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic: S.Schema<ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic>;
export type ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType = "jwt";
export declare const ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType: any;
export interface ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim {
    /** Claim location expressed as `$(token_config_id):$(json_path)`, where `token_config_id` */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType;
}
export declare const ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim: S.Schema<ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim>;
export type ConfigurationsUpdateRequestAuthIdCharacteristicsItem = ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic | ConfigurationsUpdateRequestAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim;
export declare const ConfigurationsUpdateRequestAuthIdCharacteristicsItem: any;
export type ConfigurationsUpdateRequestAuthIdCharacteristicsList = Array<ConfigurationsUpdateRequestAuthIdCharacteristicsItem>;
export declare const ConfigurationsUpdateRequestAuthIdCharacteristicsList: S.Schema<ConfigurationsUpdateRequestAuthIdCharacteristicsList>;
export interface PutConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** Ensures that the configuration is written or retrieved in normalized fashion */
    normalize?: boolean;
    authIdCharacteristics: ConfigurationsUpdateRequestAuthIdCharacteristicsList;
}
export declare const PutConfigurationRequest: S.Schema<PutConfigurationRequest>;
export type ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType = "header" | "cookie";
export declare const ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType: any;
export interface ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic {
    /** The name of the characteristic field, i.e., the header or cookie name. */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicType;
}
export declare const ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic: S.Schema<ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic>;
export type ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType = "jwt";
export declare const ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType: any;
export interface ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim {
    /** Claim location expressed as `$(token_config_id):$(json_path)`, where `token_config_id` */
    name: string;
    /** The type of characteristic. */
    type: ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaimType;
}
export declare const ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim: S.Schema<ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim>;
export type ConfigurationsUpdateResponseAuthIdCharacteristicsItem = ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristic | ConfigurationsUpdateResponseAuthIdCharacteristicsItemAPIShieldAuthIDCharacteristicJWTClaim;
export declare const ConfigurationsUpdateResponseAuthIdCharacteristicsItem: any;
export type ConfigurationsUpdateResponseAuthIdCharacteristicsList = Array<ConfigurationsUpdateResponseAuthIdCharacteristicsItem>;
export declare const ConfigurationsUpdateResponseAuthIdCharacteristicsList: S.Schema<ConfigurationsUpdateResponseAuthIdCharacteristicsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutConfigurationResponse {
    authIdCharacteristics: ConfigurationsUpdateResponseAuthIdCharacteristicsList;
}
export declare const PutConfigurationResponse: S.Schema<PutConfigurationResponse>;
export type LabelsManagedResourcesOperationUpdateRequestSelectorIncludeOperationIdsList = Array<string>;
export declare const LabelsManagedResourcesOperationUpdateRequestSelectorIncludeOperationIdsList: S.Schema<LabelsManagedResourcesOperationUpdateRequestSelectorIncludeOperationIdsList>;
export interface LabelsManagedResourcesOperationUpdateRequestSelectorInclude {
    operationIds: LabelsManagedResourcesOperationUpdateRequestSelectorIncludeOperationIdsList;
}
export declare const LabelsManagedResourcesOperationUpdateRequestSelectorInclude: S.Schema<LabelsManagedResourcesOperationUpdateRequestSelectorInclude>;
export interface LabelsManagedResourcesOperationUpdateRequestSelector {
    include: LabelsManagedResourcesOperationUpdateRequestSelectorInclude;
}
export declare const LabelsManagedResourcesOperationUpdateRequestSelector: S.Schema<LabelsManagedResourcesOperationUpdateRequestSelector>;
export interface PutLabelManagedResourceOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Operation IDs selector */
    selector: LabelsManagedResourcesOperationUpdateRequestSelector;
}
export declare const PutLabelManagedResourceOperationRequest: S.Schema<PutLabelManagedResourceOperationRequest>;
export type LabelsManagedResourcesOperationUpdateResponseSource = "user" | "managed";
export declare const LabelsManagedResourcesOperationUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutLabelManagedResourceOperationResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsManagedResourcesOperationUpdateResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export declare const PutLabelManagedResourceOperationResponse: S.Schema<PutLabelManagedResourceOperationResponse>;
export interface PutLabelUserRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** The description of the label */
    description?: string;
    /** Metadata for the label */
    metadata?: unknown;
}
export declare const PutLabelUserRequest: S.Schema<PutLabelUserRequest>;
export type LabelsUserUpdateResponseSource = "user" | "managed";
export declare const LabelsUserUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutLabelUserResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserUpdateResponseSource;
}
export declare const PutLabelUserResponse: S.Schema<PutLabelUserResponse>;
export type LabelsUserResourcesOperationUpdateRequestSelectorIncludeOperationIdsList = Array<string>;
export declare const LabelsUserResourcesOperationUpdateRequestSelectorIncludeOperationIdsList: S.Schema<LabelsUserResourcesOperationUpdateRequestSelectorIncludeOperationIdsList>;
export interface LabelsUserResourcesOperationUpdateRequestSelectorInclude {
    operationIds: LabelsUserResourcesOperationUpdateRequestSelectorIncludeOperationIdsList;
}
export declare const LabelsUserResourcesOperationUpdateRequestSelectorInclude: S.Schema<LabelsUserResourcesOperationUpdateRequestSelectorInclude>;
export interface LabelsUserResourcesOperationUpdateRequestSelector {
    include: LabelsUserResourcesOperationUpdateRequestSelectorInclude;
}
export declare const LabelsUserResourcesOperationUpdateRequestSelector: S.Schema<LabelsUserResourcesOperationUpdateRequestSelector>;
export interface PutLabelUserResourceOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** The name of the label */
    name: string;
    /** Operation IDs selector */
    selector: LabelsUserResourcesOperationUpdateRequestSelector;
}
export declare const PutLabelUserResourceOperationRequest: S.Schema<PutLabelUserResourceOperationRequest>;
export type LabelsUserResourcesOperationUpdateResponseSource = "user" | "managed";
export declare const LabelsUserResourcesOperationUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutLabelUserResourceOperationResponse {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: LabelsUserResourcesOperationUpdateResponseSource;
    /** Provides counts of what resources are linked to this label */
    mappedResources?: unknown | null;
}
export declare const PutLabelUserResourceOperationResponse: S.Schema<PutLabelUserResourceOperationResponse>;
export type OperationsSchemaValidationUpdateRequestMitigationAction = "log" | "block" | "none";
export declare const OperationsSchemaValidationUpdateRequestMitigationAction: any;
export interface PutOperationSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationUpdateRequestMitigationAction | (string & {});
}
export declare const PutOperationSchemaValidationRequest: S.Schema<PutOperationSchemaValidationRequest>;
export type OperationsSchemaValidationUpdateResponseMitigationAction = "log" | "block" | "none";
export declare const OperationsSchemaValidationUpdateResponseMitigationAction: any;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutOperationSchemaValidationResponse {
    /** When set, this applies a mitigation action to this operation */
    mitigationAction?: OperationsSchemaValidationUpdateResponseMitigationAction | null;
    /** UUID. */
    operationId?: string | null;
}
export declare const PutOperationSchemaValidationResponse: S.Schema<PutOperationSchemaValidationResponse>;
export type SettingsSchemaValidationUpdateRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsSchemaValidationUpdateRequestValidationDefaultMitigationAction: any;
export type SettingsSchemaValidationUpdateRequestValidationOverrideMitigationAction = "none" | "disable_override";
export declare const SettingsSchemaValidationUpdateRequestValidationOverrideMitigationAction: any;
export interface PutSettingSchemaValidationRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used when there is no mitigation action defined on the operation */
    validationDefaultMitigationAction: SettingsSchemaValidationUpdateRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsSchemaValidationUpdateRequestValidationOverrideMitigationAction | (string & {});
}
export declare const PutSettingSchemaValidationRequest: S.Schema<PutSettingSchemaValidationRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutSettingSchemaValidationResponse {
}
export declare const PutSettingSchemaValidationResponse: S.Schema<PutSettingSchemaValidationResponse>;
export type OperationsLabelsUpdateRequestManagedList = Array<string>;
export declare const OperationsLabelsUpdateRequestManagedList: S.Schema<OperationsLabelsUpdateRequestManagedList>;
export type OperationsLabelsUpdateRequestUserList = Array<string>;
export declare const OperationsLabelsUpdateRequestUserList: S.Schema<OperationsLabelsUpdateRequestUserList>;
export interface UpdateOperationLabelRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** List of managed label names. Omitting this property or passing an empty array will result in all managed labels being removed from the operation */
    managed?: OperationsLabelsUpdateRequestManagedList;
    /** List of user label names. Omitting this property or passing an empty array will result in all user labels being removed from the operation */
    user?: OperationsLabelsUpdateRequestUserList;
}
export declare const UpdateOperationLabelRequest: S.Schema<UpdateOperationLabelRequest>;
export type OperationsLabelsUpdateResponseMethod = "GET" | "POST" | "HEAD" | "OPTIONS" | "PUT" | "DELETE" | "CONNECT" | "PATCH" | "TRACE";
export declare const OperationsLabelsUpdateResponseMethod: any;
export type OperationsLabelsUpdateResponseLabelsItemSource = "user" | "managed";
export declare const OperationsLabelsUpdateResponseLabelsItemSource: any;
export interface OperationsLabelsUpdateResponseLabelsItem {
    createdAt: string;
    /** The description of the label */
    description: string;
    lastUpdated: string;
    /** Metadata for the label */
    metadata: unknown;
    /** The name of the label */
    name: string;
    /** * `user` - label is owned by the user */
    source: OperationsLabelsUpdateResponseLabelsItemSource;
}
export declare const OperationsLabelsUpdateResponseLabelsItem: S.Schema<OperationsLabelsUpdateResponseLabelsItem>;
export type OperationsLabelsUpdateResponseLabelsList = Array<OperationsLabelsUpdateResponseLabelsItem>;
export declare const OperationsLabelsUpdateResponseLabelsList: S.Schema<OperationsLabelsUpdateResponseLabelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOperationLabelResponse {
    /** The endpoint which can contain path parameter templates in curly braces, each will be replaced from left to right with {varN}, starting with {var1}, during insertion. This will further be Cloudflare-normalized upon insertion. See: https://developers.cloudflare.com/rules/normalization/how-it-works/. */
    endpoint: string;
    /** RFC3986-compliant host. */
    host: string;
    lastUpdated: string;
    /** The HTTP method used to access the endpoint. */
    method: OperationsLabelsUpdateResponseMethod;
    /** UUID. */
    operationId: string;
    labels?: OperationsLabelsUpdateResponseLabelsList | null;
}
export declare const UpdateOperationLabelResponse: S.Schema<UpdateOperationLabelResponse>;
export type BulkCreateLabelUsersError = LabelAlreadyExists | Forbidden | CloudflareOpError;
/** Create user labels */
export declare const bulkCreateLabelUsers: API.PaginatedOperationMethod<BulkCreateLabelUsersRequest, BulkCreateLabelUsersResponse, BulkCreateLabelUsersError, CloudflareOpContext, LabelsUserBulkCreateResultItem>;
export type BulkCreateOperationLabelsError = CloudflareOpError;
/** Bulk attach label(s) on operation(s) in endpoint management */
export declare const bulkCreateOperationLabels: API.PaginatedOperationMethod<BulkCreateOperationLabelsRequest, BulkCreateOperationLabelsResponse, BulkCreateOperationLabelsError, CloudflareOpContext, OperationsLabelsBulkCreateResultItem>;
export type BulkCreateOperationsError = CloudflareOpError;
/** Add one or more operations to a zone. Endpoints can contain path variables. Host, method, endpoint will be normalized to a canoncial form when creating an operation and must be unique on the zone. Inserting an operation that matches an existing one will return the record of the already existing operation and update its last_updated date. */
export declare const bulkCreateOperations: API.PaginatedOperationMethod<BulkCreateOperationsRequest, BulkCreateOperationsResponse, BulkCreateOperationsError, CloudflareOpContext, OperationsBulkCreateResultItem>;
export type BulkDeleteLabelUsersError = CloudflareOpError;
/** Delete user labels */
export declare const bulkDeleteLabelUsers: API.PaginatedOperationMethod<BulkDeleteLabelUsersRequest, BulkDeleteLabelUsersResponse, BulkDeleteLabelUsersError, CloudflareOpContext, LabelsUserBulkDeleteResultItem>;
export type BulkDeleteOperationLabelsError = CloudflareOpError;
/** Bulk remove label(s) on operation(s) in endpoint management */
export declare const bulkDeleteOperationLabels: API.PaginatedOperationMethod<BulkDeleteOperationLabelsRequest, BulkDeleteOperationLabelsResponse, BulkDeleteOperationLabelsError, CloudflareOpContext, OperationsLabelsBulkDeleteResultItem>;
export type BulkDeleteOperationsError = InvalidObjectIdentifier | CloudflareOpError;
/** Bulk removes multiple API operations from API Shield endpoint management in a single request. Efficient for cleaning up unused endpoints. */
export declare const bulkDeleteOperations: API.OperationMethod<BulkDeleteOperationsRequest, BulkDeleteOperationsResponse, BulkDeleteOperationsError, CloudflareOpContext>;
export type BulkPatchDiscoveryOperationsError = InvalidObjectIdentifier | NotEntitled | CloudflareOpError;
/** Update the `state` on one or more discovered operations */
export declare const bulkPatchDiscoveryOperations: API.OperationMethod<BulkPatchDiscoveryOperationsRequest, BulkPatchDiscoveryOperationsResponse, BulkPatchDiscoveryOperationsError, CloudflareOpContext>;
export type BulkUpdateOperationLabelsError = CloudflareOpError;
/** Bulk replace label(s) on operation(s) in endpoint management */
export declare const bulkUpdateOperationLabels: API.PaginatedOperationMethod<BulkUpdateOperationLabelsRequest, BulkUpdateOperationLabelsResponse, BulkUpdateOperationLabelsError, CloudflareOpContext, OperationsLabelsBulkUpdateResultItem>;
export type CreateExpressionTemplateFallthroughError = InvalidObjectIdentifier | CloudflareOpError;
/** Creates an expression template fallthrough rule for API Shield. Used for configuring default behavior when no other expression templates match. */
export declare const createExpressionTemplateFallthrough: API.OperationMethod<CreateExpressionTemplateFallthroughRequest, CreateExpressionTemplateFallthroughResponse, CreateExpressionTemplateFallthroughError, CloudflareOpContext>;
export type CreateOperationError = InvalidObjectIdentifier | Forbidden | CloudflareOpError;
/** Add one operation to a zone. Endpoints can contain path variables. Host, method, endpoint will be normalized to a canoncial form when creating an operation and must be unique on the zone. Inserting an operation that matches an existing one will return the record of the already existing operation and update its last_updated date. */
export declare const createOperation: API.OperationMethod<CreateOperationRequest, CreateOperationResponse, CreateOperationError, CloudflareOpContext>;
export type CreateOperationLabelError = CloudflareOpError;
/** Attach label(s) on an operation in endpoint management */
export declare const createOperationLabel: API.OperationMethod<CreateOperationLabelRequest, CreateOperationLabelResponse, CreateOperationLabelError, CloudflareOpContext>;
export type CreateUserSchemaError = InvalidObjectIdentifier | Forbidden | CloudflareOpError;
/** Uploads a new OpenAPI schema for API Shield schema validation. The schema defines expected request/response formats for API endpoints. */
export declare const createUserSchema: API.OperationMethod<CreateUserSchemaRequest, CreateUserSchemaResponse, CreateUserSchemaError, CloudflareOpContext>;
export type DeleteLabelUserError = LabelNotFound | Forbidden | CloudflareOpError;
/** Delete user label */
export declare const deleteLabelUser: API.OperationMethod<DeleteLabelUserRequest, DeleteLabelUserResponse, DeleteLabelUserError, CloudflareOpContext>;
export type DeleteOperationError = InvalidObjectIdentifier | OperationNotFound | Forbidden | CloudflareOpError;
/** Removes a single API operation from API Shield endpoint management. The operation will no longer be tracked or protected by API Shield rules. */
export declare const deleteOperation: API.OperationMethod<DeleteOperationRequest, DeleteOperationResponse, DeleteOperationError, CloudflareOpContext>;
export type DeleteOperationLabelError = CloudflareOpError;
/** Remove label(s) on an operation in endpoint management */
export declare const deleteOperationLabel: API.OperationMethod<DeleteOperationLabelRequest, DeleteOperationLabelResponse, DeleteOperationLabelError, CloudflareOpContext>;
export type DeleteUserSchemaError = InvalidObjectIdentifier | SchemaNotFound | Forbidden | CloudflareOpError;
/** Permanently removes an uploaded OpenAPI schema from API Shield schema validation. Operations using this schema will lose their validation rules. */
export declare const deleteUserSchema: API.OperationMethod<DeleteUserSchemaRequest, DeleteUserSchemaResponse, DeleteUserSchemaError, CloudflareOpContext>;
export type GetConfigurationError = InvalidObjectIdentifier | NotEntitled | Forbidden | CloudflareOpError;
/** Gets the current API Shield configuration settings for a zone, including validation behavior and enforcement mode. */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, GetConfigurationResponse, GetConfigurationError, CloudflareOpContext>;
export type GetDiscoveryError = InvalidObjectIdentifier | NotEntitled | CloudflareOpError;
/** Retrieve the most up to date view of discovered operations, rendered as OpenAPI schemas */
export declare const getDiscovery: API.OperationMethod<GetDiscoveryRequest, GetDiscoveryResponse, GetDiscoveryError, CloudflareOpContext>;
export type GetLabelManagedError = CloudflareOpError;
/** Retrieve managed label */
export declare const getLabelManaged: API.OperationMethod<GetLabelManagedRequest, GetLabelManagedResponse, GetLabelManagedError, CloudflareOpContext>;
export type GetLabelUserError = LabelNotFound | Forbidden | CloudflareOpError;
/** Retrieve user label */
export declare const getLabelUser: API.OperationMethod<GetLabelUserRequest, GetLabelUserResponse, GetLabelUserError, CloudflareOpContext>;
export type GetOperationError = InvalidObjectIdentifier | OperationNotFound | Forbidden | CloudflareOpError;
/** Gets detailed information about a specific API operation in API Shield, including its schema validation settings and traffic statistics. */
export declare const getOperation: API.OperationMethod<GetOperationRequest, GetOperationResponse, GetOperationError, CloudflareOpContext>;
export type GetOperationSchemaValidationError = InvalidObjectIdentifier | OperationNotFound | CloudflareOpError;
/** Retrieves operation-level schema validation settings on the zone */
export declare const getOperationSchemaValidation: API.OperationMethod<GetOperationSchemaValidationRequest, GetOperationSchemaValidationResponse, GetOperationSchemaValidationError, CloudflareOpContext>;
export type GetSettingSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Retrieves zone level schema validation settings currently set on the zone */
export declare const getSettingSchemaValidation: API.OperationMethod<GetSettingSchemaValidationRequest, GetSettingSchemaValidationResponse, GetSettingSchemaValidationError, CloudflareOpContext>;
export type GetUserSchemaError = InvalidObjectIdentifier | SchemaNotFound | Forbidden | CloudflareOpError;
/** Gets detailed information about a specific uploaded OpenAPI schema, including its contents and validation configuration. */
export declare const getUserSchema: API.OperationMethod<GetUserSchemaRequest, GetUserSchemaResponse, GetUserSchemaError, CloudflareOpContext>;
export type ListDiscoveryOperationsError = CloudflareOpError;
/** Retrieve the most up to date view of discovered operations */
export declare const listDiscoveryOperations: API.PaginatedOperationMethod<ListDiscoveryOperationsRequest, ListDiscoveryOperationsResponse, ListDiscoveryOperationsError, CloudflareOpContext, DiscoveryOperationsListResultItem>;
export type ListLabelsError = ZonePurged | Forbidden | NotFound | CloudflareOpError;
/** Retrieve all labels */
export declare const listLabels: API.PaginatedOperationMethod<ListLabelsRequest, ListLabelsResponse, ListLabelsError, CloudflareOpContext, LabelsListResultItem>;
export type ListOperationsError = Forbidden | CloudflareOpError;
/** Lists all API operations tracked by API Shield for a zone with pagination. Returns operation details including method, path, and feature configurations. */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsRequest, ListOperationsResponse, ListOperationsError, CloudflareOpContext, OperationsListResultItem>;
export type ListSchemasError = InvalidObjectIdentifier | CloudflareOpError;
/** Retrieves API operations and their features exported as OpenAPI schemas. */
export declare const listSchemas: API.OperationMethod<ListSchemasRequest, ListSchemasResponse, ListSchemasError, CloudflareOpContext>;
export type ListUserSchemaHostsError = CloudflareOpError;
/** Lists all unique hosts found in uploaded OpenAPI schemas for the zone. Useful for understanding which domains have schema coverage. */
export declare const listUserSchemaHosts: API.PaginatedOperationMethod<ListUserSchemaHostsRequest, ListUserSchemaHostsResponse, ListUserSchemaHostsError, CloudflareOpContext, UserSchemasHostsListResultItem>;
export type ListUserSchemaOperationsError = CloudflareOpError;
/** Retrieves all operations from the schema. Operations that already exist in API Shield Endpoint Management will be returned as full operations. */
export declare const listUserSchemaOperations: API.PaginatedOperationMethod<ListUserSchemaOperationsRequest, ListUserSchemaOperationsResponse, ListUserSchemaOperationsError, CloudflareOpContext, UserSchemasOperationsListResultItem>;
export type ListUserSchemasError = ZonePurged | Forbidden | CloudflareOpError;
/** Lists all OpenAPI schemas uploaded to API Shield for the zone, including their validation status and associated operations. */
export declare const listUserSchemas: API.PaginatedOperationMethod<ListUserSchemasRequest, ListUserSchemasResponse, ListUserSchemasError, CloudflareOpContext, UserSchemasListResultItem>;
export type PatchLabelUserError = LabelNotFound | CloudflareOpError;
/** Update certain fields on a label */
export declare const patchLabelUser: API.OperationMethod<PatchLabelUserRequest, PatchLabelUserResponse, PatchLabelUserError, CloudflareOpContext>;
export type PatchOperationSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Updates multiple operation-level schema validation settings on the zone */
export declare const patchOperationSchemaValidation: API.OperationMethod<PatchOperationSchemaValidationRequest, PatchOperationSchemaValidationResponse, PatchOperationSchemaValidationError, CloudflareOpContext>;
export type PatchSettingSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Updates zone level schema validation settings on the zone */
export declare const patchSettingSchemaValidation: API.OperationMethod<PatchSettingSchemaValidationRequest, PatchSettingSchemaValidationResponse, PatchSettingSchemaValidationError, CloudflareOpContext>;
export type PatchUserSchemaError = InvalidObjectIdentifier | SchemaNotFound | Forbidden | CloudflareOpError;
/** Activates schema validation for an uploaded OpenAPI schema. Requests to matching endpoints will be validated against the schema definitions. */
export declare const patchUserSchema: API.OperationMethod<PatchUserSchemaRequest, PatchUserSchemaResponse, PatchUserSchemaError, CloudflareOpContext>;
export type PutConfigurationError = InvalidObjectIdentifier | NotEntitled | Forbidden | CloudflareOpError;
/** Updates API Shield configuration settings for a zone. Can modify validation strictness, enforcement mode, and other global settings. */
export declare const putConfiguration: API.OperationMethod<PutConfigurationRequest, PutConfigurationResponse, PutConfigurationError, CloudflareOpContext>;
export type PutLabelManagedResourceOperationError = CloudflareOpError;
/** Replace all operations(s) attached to a managed label */
export declare const putLabelManagedResourceOperation: API.OperationMethod<PutLabelManagedResourceOperationRequest, PutLabelManagedResourceOperationResponse, PutLabelManagedResourceOperationError, CloudflareOpContext>;
export type PutLabelUserError = LabelNotFound | CloudflareOpError;
/** Update all fields on a label */
export declare const putLabelUser: API.OperationMethod<PutLabelUserRequest, PutLabelUserResponse, PutLabelUserError, CloudflareOpContext>;
export type PutLabelUserResourceOperationError = CloudflareOpError;
/** Replace all operations(s) attached to a user label */
export declare const putLabelUserResourceOperation: API.OperationMethod<PutLabelUserResourceOperationRequest, PutLabelUserResourceOperationResponse, PutLabelUserResourceOperationError, CloudflareOpContext>;
export type PutOperationSchemaValidationError = InvalidObjectIdentifier | OperationNotFound | CloudflareOpError;
/** Updates operation-level schema validation settings on the zone */
export declare const putOperationSchemaValidation: API.OperationMethod<PutOperationSchemaValidationRequest, PutOperationSchemaValidationResponse, PutOperationSchemaValidationError, CloudflareOpContext>;
export type PutSettingSchemaValidationError = InvalidObjectIdentifier | CloudflareOpError;
/** Updates zone level schema validation settings on the zone */
export declare const putSettingSchemaValidation: API.OperationMethod<PutSettingSchemaValidationRequest, PutSettingSchemaValidationResponse, PutSettingSchemaValidationError, CloudflareOpContext>;
export type UpdateOperationLabelError = CloudflareOpError;
/** Replace label(s) on an operation in endpoint management */
export declare const updateOperationLabel: API.OperationMethod<UpdateOperationLabelRequest, UpdateOperationLabelResponse, UpdateOperationLabelError, CloudflareOpContext>;
//# sourceMappingURL=api_gateway.d.ts.map