import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OriginCloudRegionNotFound_base: S.Class<OriginCloudRegionNotFound, S.TaggedStruct<"OriginCloudRegionNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OriginCloudRegionNotFound extends /*@__PURE__*/ OriginCloudRegionNotFound_base {
}
declare const SettingUnavailableForPlan_base: S.Class<SettingUnavailableForPlan, S.TaggedStruct<"SettingUnavailableForPlan", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SettingUnavailableForPlan extends /*@__PURE__*/ SettingUnavailableForPlan_base {
}
declare const Unauthorized_base: S.Class<Unauthorized, S.TaggedStruct<"Unauthorized", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Unauthorized extends /*@__PURE__*/ Unauthorized_base {
}
declare const VariantsNotConfigured_base: S.Class<VariantsNotConfigured, S.TaggedStruct<"VariantsNotConfigured", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VariantsNotConfigured extends /*@__PURE__*/ VariantsNotConfigured_base {
}
export interface BulkDeleteOriginCloudRegionsRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const BulkDeleteOriginCloudRegionsRequest: S.Schema<BulkDeleteOriginCloudRegionsRequest>;
export interface OriginCloudRegionsBulkDeleteResponseFailedItem {
    /** The origin IP address for this item. */
    originIp: string;
    /** Error message explaining why the item failed. Present only on failed items. */
    error?: string | null;
    /** Cloud vendor region identifier. Present on succeeded items (the new value for upsert, the deleted value for delete). */
    region?: string | null;
    /** Cloud vendor identifier. Present on succeeded items (the new value for upsert, the deleted value for delete). */
    vendor?: string | null;
}
export declare const OriginCloudRegionsBulkDeleteResponseFailedItem: S.Schema<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export type OriginCloudRegionsBulkDeleteResponseFailedList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export declare const OriginCloudRegionsBulkDeleteResponseFailedList: S.Schema<OriginCloudRegionsBulkDeleteResponseFailedList>;
export type OriginCloudRegionsBulkDeleteResponseSucceededItem = OriginCloudRegionsBulkDeleteResponseFailedItem;
export declare const OriginCloudRegionsBulkDeleteResponseSucceededItem: S.Schema<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export type OriginCloudRegionsBulkDeleteResponseSucceededList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export declare const OriginCloudRegionsBulkDeleteResponseSucceededList: S.Schema<OriginCloudRegionsBulkDeleteResponseSucceededList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkDeleteOriginCloudRegionsResponse {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkDeleteResponseFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkDeleteResponseSucceededList;
}
export declare const BulkDeleteOriginCloudRegionsResponse: S.Schema<BulkDeleteOriginCloudRegionsResponse>;
export type OriginCloudRegionsBulkUpdateRequestBodyItemVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsBulkUpdateRequestBodyItemVendor: any;
export interface OriginCloudRegionsBulkUpdateRequestBodyItem {
    /** Origin IP address (IPv4 or IPv6). For the single PUT endpoint (`PUT /origin/cloud_regions/{origin_ip}`), this field must match the path parameter or the request will be rejected with a 400 error. For the batch PUT endpoint, this field identifies which mapping to upsert. */
    originIp: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsBulkUpdateRequestBodyItemVendor | (string & {});
}
export declare const OriginCloudRegionsBulkUpdateRequestBodyItem: S.Schema<OriginCloudRegionsBulkUpdateRequestBodyItem>;
export type OriginCloudRegionsBulkUpdateRequestBodyList = Array<OriginCloudRegionsBulkUpdateRequestBodyItem>;
export declare const OriginCloudRegionsBulkUpdateRequestBodyList: S.Schema<OriginCloudRegionsBulkUpdateRequestBodyList>;
export interface BulkPutOriginCloudRegionsRequest {
    /** Identifier. */
    zoneId: string;
    body: OriginCloudRegionsBulkUpdateRequestBodyList;
}
export declare const BulkPutOriginCloudRegionsRequest: S.Schema<BulkPutOriginCloudRegionsRequest>;
export type OriginCloudRegionsBulkUpdateResponseFailedItem = OriginCloudRegionsBulkDeleteResponseFailedItem;
export declare const OriginCloudRegionsBulkUpdateResponseFailedItem: S.Schema<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export type OriginCloudRegionsBulkUpdateResponseFailedList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export declare const OriginCloudRegionsBulkUpdateResponseFailedList: S.Schema<OriginCloudRegionsBulkUpdateResponseFailedList>;
export type OriginCloudRegionsBulkUpdateResponseSucceededItem = OriginCloudRegionsBulkDeleteResponseFailedItem;
export declare const OriginCloudRegionsBulkUpdateResponseSucceededItem: S.Schema<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export type OriginCloudRegionsBulkUpdateResponseSucceededList = Array<OriginCloudRegionsBulkDeleteResponseFailedItem>;
export declare const OriginCloudRegionsBulkUpdateResponseSucceededList: S.Schema<OriginCloudRegionsBulkUpdateResponseSucceededList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutOriginCloudRegionsResponse {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkUpdateResponseFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkUpdateResponseSucceededList;
}
export declare const BulkPutOriginCloudRegionsResponse: S.Schema<BulkPutOriginCloudRegionsResponse>;
export interface ClearCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ClearCacheReserveRequest: S.Schema<ClearCacheReserveRequest>;
export type CacheReserveClearResponseId = "cache_reserve_clear";
export declare const CacheReserveClearResponseId: any;
export type CacheReserveClearResponseState = "In-progress" | "Completed";
export declare const CacheReserveClearResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ClearCacheReserveResponse {
    /** ID of the zone setting. */
    id: CacheReserveClearResponseId;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: CacheReserveClearResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const ClearCacheReserveResponse: S.Schema<ClearCacheReserveResponse>;
export type SmartTieredCacheCreateRequestValue = "on" | "off";
export declare const SmartTieredCacheCreateRequestValue: any;
export interface CreateSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable or disable the Smart Tiered Cache. */
    value: SmartTieredCacheCreateRequestValue | (string & {});
}
export declare const CreateSmartTieredCacheRequest: S.Schema<CreateSmartTieredCacheRequest>;
export type SmartTieredCacheCreateResponseId = "tiered_cache_smart_topology_enable";
export declare const SmartTieredCacheCreateResponseId: any;
export type SmartTieredCacheCreateResponseValue = "on" | "off";
export declare const SmartTieredCacheCreateResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheCreateResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Smart Tiered Cache zone setting. */
    value: SmartTieredCacheCreateResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const CreateSmartTieredCacheResponse: S.Schema<CreateSmartTieredCacheResponse>;
export interface DeleteOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
    originIP: string;
}
export declare const DeleteOriginCloudRegionRequest: S.Schema<DeleteOriginCloudRegionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginCloudRegionResponse {
    /** The origin IP address whose mapping was deleted. */
    originIp: string;
}
export declare const DeleteOriginCloudRegionResponse: S.Schema<DeleteOriginCloudRegionResponse>;
export interface DeleteSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const DeleteSmartTieredCacheRequest: S.Schema<DeleteSmartTieredCacheRequest>;
export type SmartTieredCacheDeleteResponseId = "tiered_cache_smart_topology_enable";
export declare const SmartTieredCacheDeleteResponseId: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheDeleteResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const DeleteSmartTieredCacheResponse: S.Schema<DeleteSmartTieredCacheResponse>;
export interface DeleteVariantRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const DeleteVariantRequest: S.Schema<DeleteVariantRequest>;
export type VariantsDeleteResponseId = "variants";
export declare const VariantsDeleteResponseId: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteVariantResponse {
    /** The identifier of the caching setting. */
    id: VariantsDeleteResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const DeleteVariantResponse: S.Schema<DeleteVariantResponse>;
export interface GetCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetCacheReserveRequest: S.Schema<GetCacheReserveRequest>;
export type CacheReserveGetResponseId = "cache_reserve";
export declare const CacheReserveGetResponseId: any;
export type CacheReserveGetResponseValue = "on" | "off";
export declare const CacheReserveGetResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCacheReserveResponse {
    /** The identifier of the caching setting. */
    id: CacheReserveGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Cache Reserve zone setting. */
    value: CacheReserveGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const GetCacheReserveResponse: S.Schema<GetCacheReserveResponse>;
export interface GetOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
    originIP: string;
}
export declare const GetOriginCloudRegionRequest: S.Schema<GetOriginCloudRegionRequest>;
export type OriginCloudRegionsGetResponseVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsGetResponseVendor: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginCloudRegionResponse {
    /** The origin IP address (IPv4 or IPv6). Normalized to canonical form (RFC 5952 for IPv6). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsGetResponseVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const GetOriginCloudRegionResponse: S.Schema<GetOriginCloudRegionResponse>;
export interface GetRegionalTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetRegionalTieredCacheRequest: S.Schema<GetRegionalTieredCacheRequest>;
export type RegionalTieredCacheGetResponseId = "tc_regional";
export declare const RegionalTieredCacheGetResponseId: any;
export type RegionalTieredCacheGetResponseValue = "on" | "off";
export declare const RegionalTieredCacheGetResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionalTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: RegionalTieredCacheGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Regional Tiered Cache zone setting. */
    value: RegionalTieredCacheGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const GetRegionalTieredCacheResponse: S.Schema<GetRegionalTieredCacheResponse>;
export interface GetSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetSmartTieredCacheRequest: S.Schema<GetSmartTieredCacheRequest>;
export type SmartTieredCacheGetResponseId = "tiered_cache_smart_topology_enable";
export declare const SmartTieredCacheGetResponseId: any;
export type SmartTieredCacheGetResponseValue = "on" | "off";
export declare const SmartTieredCacheGetResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Smart Tiered Cache zone setting. */
    value: SmartTieredCacheGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const GetSmartTieredCacheResponse: S.Schema<GetSmartTieredCacheResponse>;
export interface GetVariantRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetVariantRequest: S.Schema<GetVariantRequest>;
export type VariantsGetResponseId = "variants";
export declare const VariantsGetResponseId: any;
export type VariantsGetResponseValueAvifList = Array<string>;
export declare const VariantsGetResponseValueAvifList: S.Schema<VariantsGetResponseValueAvifList>;
export type VariantsGetResponseValueBmpList = Array<string>;
export declare const VariantsGetResponseValueBmpList: S.Schema<VariantsGetResponseValueBmpList>;
export type VariantsGetResponseValueGifList = Array<string>;
export declare const VariantsGetResponseValueGifList: S.Schema<VariantsGetResponseValueGifList>;
export type VariantsGetResponseValueJp2List = Array<string>;
export declare const VariantsGetResponseValueJp2List: S.Schema<VariantsGetResponseValueJp2List>;
export type VariantsGetResponseValueJpegList = Array<string>;
export declare const VariantsGetResponseValueJpegList: S.Schema<VariantsGetResponseValueJpegList>;
export type VariantsGetResponseValueJpgList = Array<string>;
export declare const VariantsGetResponseValueJpgList: S.Schema<VariantsGetResponseValueJpgList>;
export type VariantsGetResponseValueJpg2List = Array<string>;
export declare const VariantsGetResponseValueJpg2List: S.Schema<VariantsGetResponseValueJpg2List>;
export type VariantsGetResponseValuePngList = Array<string>;
export declare const VariantsGetResponseValuePngList: S.Schema<VariantsGetResponseValuePngList>;
export type VariantsGetResponseValueTifList = Array<string>;
export declare const VariantsGetResponseValueTifList: S.Schema<VariantsGetResponseValueTifList>;
export type VariantsGetResponseValueTiffList = Array<string>;
export declare const VariantsGetResponseValueTiffList: S.Schema<VariantsGetResponseValueTiffList>;
export type VariantsGetResponseValueWebpList = Array<string>;
export declare const VariantsGetResponseValueWebpList: S.Schema<VariantsGetResponseValueWebpList>;
export interface VariantsGetResponseValue {
    /** List of strings with the MIME types of all the variants that should be served for avif. */
    avif?: VariantsGetResponseValueAvifList | null;
    /** List of strings with the MIME types of all the variants that should be served for bmp. */
    bmp?: VariantsGetResponseValueBmpList | null;
    /** List of strings with the MIME types of all the variants that should be served for gif. */
    gif?: VariantsGetResponseValueGifList | null;
    /** List of strings with the MIME types of all the variants that should be served for jp2. */
    jp2?: VariantsGetResponseValueJp2List | null;
    /** List of strings with the MIME types of all the variants that should be served for jpeg. */
    jpeg?: VariantsGetResponseValueJpegList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg. */
    jpg?: VariantsGetResponseValueJpgList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg2. */
    jpg2?: VariantsGetResponseValueJpg2List | null;
    /** List of strings with the MIME types of all the variants that should be served for png. */
    png?: VariantsGetResponseValuePngList | null;
    /** List of strings with the MIME types of all the variants that should be served for tif. */
    tif?: VariantsGetResponseValueTifList | null;
    /** List of strings with the MIME types of all the variants that should be served for tiff. */
    tiff?: VariantsGetResponseValueTiffList | null;
    /** List of strings with the MIME types of all the variants that should be served for webp. */
    webp?: VariantsGetResponseValueWebpList | null;
}
export declare const VariantsGetResponseValue: S.Schema<VariantsGetResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVariantResponse {
    /** The identifier of the caching setting. */
    id: VariantsGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the zone setting. */
    value: VariantsGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const GetVariantResponse: S.Schema<GetVariantResponse>;
export interface ListOriginCloudRegionsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export declare const ListOriginCloudRegionsRequest: S.Schema<ListOriginCloudRegionsRequest>;
export type OriginCloudRegionsListResultItemVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsListResultItemVendor: any;
export interface OriginCloudRegionsListResultItem {
    /** The origin IP address (IPv4 or IPv6). Normalized to canonical form (RFC 5952 for IPv6). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsListResultItemVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsListResultItem: S.Schema<OriginCloudRegionsListResultItem>;
export type OriginCloudRegionsListResultList = Array<OriginCloudRegionsListResultItem>;
export declare const OriginCloudRegionsListResultList: S.Schema<OriginCloudRegionsListResultList>;
export interface ListOriginCloudRegionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OriginCloudRegionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOriginCloudRegionsResponse: S.Schema<ListOriginCloudRegionsResponse>;
export interface OriginCloudRegionsBulkDeleteV1Request {
    /** Identifier. */
    zoneId: string;
}
export declare const OriginCloudRegionsBulkDeleteV1Request: S.Schema<OriginCloudRegionsBulkDeleteV1Request>;
export type OriginCloudRegionsBulkDeleteV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsBulkDeleteV1ResponseId: any;
export interface OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem {
    /** The origin IP address for this item. */
    originIp: string;
    /** Error message explaining why the item failed. Present only on failed items. */
    error?: string | null;
    /** Cloud vendor region identifier. Present on succeeded items for patch operations. */
    region?: string | null;
    /** Cloud vendor identifier. Present on succeeded items for patch operations. */
    vendor?: string | null;
}
export declare const OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export type OriginCloudRegionsBulkDeleteV1ResponseValueFailedList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export declare const OriginCloudRegionsBulkDeleteV1ResponseValueFailedList: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValueFailedList>;
export type OriginCloudRegionsBulkDeleteV1ResponseValueSucceededItem = OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem;
export declare const OriginCloudRegionsBulkDeleteV1ResponseValueSucceededItem: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export type OriginCloudRegionsBulkDeleteV1ResponseValueSucceededList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export declare const OriginCloudRegionsBulkDeleteV1ResponseValueSucceededList: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValueSucceededList>;
export interface OriginCloudRegionsBulkDeleteV1ResponseValue {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkDeleteV1ResponseValueFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkDeleteV1ResponseValueSucceededList;
}
export declare const OriginCloudRegionsBulkDeleteV1ResponseValue: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsBulkDeleteV1Response {
    id: OriginCloudRegionsBulkDeleteV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsBulkDeleteV1ResponseValue;
    /** Time the mapping set was last modified. Null when no items were successfully applied. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsBulkDeleteV1Response: S.Schema<OriginCloudRegionsBulkDeleteV1Response>;
export type OriginCloudRegionsBulkEditV1RequestBodyItemVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsBulkEditV1RequestBodyItemVendor: any;
export interface OriginCloudRegionsBulkEditV1RequestBodyItem {
    /** Origin IP address (IPv4 or IPv6). Normalized to canonical form before storage (RFC 5952 for IPv6). */
    ip: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsBulkEditV1RequestBodyItemVendor | (string & {});
}
export declare const OriginCloudRegionsBulkEditV1RequestBodyItem: S.Schema<OriginCloudRegionsBulkEditV1RequestBodyItem>;
export type OriginCloudRegionsBulkEditV1RequestBodyList = Array<OriginCloudRegionsBulkEditV1RequestBodyItem>;
export declare const OriginCloudRegionsBulkEditV1RequestBodyList: S.Schema<OriginCloudRegionsBulkEditV1RequestBodyList>;
export interface OriginCloudRegionsBulkEditV1Request {
    /** Identifier. */
    zoneId: string;
    body: OriginCloudRegionsBulkEditV1RequestBodyList;
}
export declare const OriginCloudRegionsBulkEditV1Request: S.Schema<OriginCloudRegionsBulkEditV1Request>;
export type OriginCloudRegionsBulkEditV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsBulkEditV1ResponseId: any;
export type OriginCloudRegionsBulkEditV1ResponseValueFailedItem = OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem;
export declare const OriginCloudRegionsBulkEditV1ResponseValueFailedItem: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export type OriginCloudRegionsBulkEditV1ResponseValueFailedList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export declare const OriginCloudRegionsBulkEditV1ResponseValueFailedList: S.Schema<OriginCloudRegionsBulkEditV1ResponseValueFailedList>;
export type OriginCloudRegionsBulkEditV1ResponseValueSucceededItem = OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem;
export declare const OriginCloudRegionsBulkEditV1ResponseValueSucceededItem: S.Schema<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export type OriginCloudRegionsBulkEditV1ResponseValueSucceededList = Array<OriginCloudRegionsBulkDeleteV1ResponseValueFailedItem>;
export declare const OriginCloudRegionsBulkEditV1ResponseValueSucceededList: S.Schema<OriginCloudRegionsBulkEditV1ResponseValueSucceededList>;
export interface OriginCloudRegionsBulkEditV1ResponseValue {
    /** Items that could not be applied, with error details. */
    failed: OriginCloudRegionsBulkEditV1ResponseValueFailedList;
    /** Items that were successfully applied. */
    succeeded: OriginCloudRegionsBulkEditV1ResponseValueSucceededList;
}
export declare const OriginCloudRegionsBulkEditV1ResponseValue: S.Schema<OriginCloudRegionsBulkEditV1ResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsBulkEditV1Response {
    id: OriginCloudRegionsBulkEditV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsBulkEditV1ResponseValue;
    /** Time the mapping set was last modified. Null when no items were successfully applied. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsBulkEditV1Response: S.Schema<OriginCloudRegionsBulkEditV1Response>;
export type OriginCloudRegionsCreateV1RequestVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsCreateV1RequestVendor: any;
export interface OriginCloudRegionsCreateV1Request {
    /** Identifier. */
    zoneId: string;
    /** Origin IP address (IPv4 or IPv6). Normalized to canonical form before storage (RFC 5952 for IPv6). */
    ip: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsCreateV1RequestVendor | (string & {});
}
export declare const OriginCloudRegionsCreateV1Request: S.Schema<OriginCloudRegionsCreateV1Request>;
export type OriginCloudRegionsCreateV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsCreateV1ResponseId: any;
export type OriginCloudRegionsCreateV1ResponseValueVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsCreateV1ResponseValueVendor: any;
export interface OriginCloudRegionsCreateV1ResponseValue {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsCreateV1ResponseValueVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsCreateV1ResponseValue: S.Schema<OriginCloudRegionsCreateV1ResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsCreateV1Response {
    id: OriginCloudRegionsCreateV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    /** A single origin IP-to-cloud-region mapping. */
    value: OriginCloudRegionsCreateV1ResponseValue;
    /** Time the mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsCreateV1Response: S.Schema<OriginCloudRegionsCreateV1Response>;
export interface OriginCloudRegionsDeleteV1Request {
    /** Identifier. */
    zoneId: string;
    originIp: string;
}
export declare const OriginCloudRegionsDeleteV1Request: S.Schema<OriginCloudRegionsDeleteV1Request>;
export type OriginCloudRegionsDeleteV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsDeleteV1ResponseId: any;
export type OriginCloudRegionsDeleteV1ResponseValueVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsDeleteV1ResponseValueVendor: any;
export interface OriginCloudRegionsDeleteV1ResponseValue {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsDeleteV1ResponseValueVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsDeleteV1ResponseValue: S.Schema<OriginCloudRegionsDeleteV1ResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsDeleteV1Response {
    id: OriginCloudRegionsDeleteV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    /** A single origin IP-to-cloud-region mapping. */
    value: OriginCloudRegionsDeleteV1ResponseValue;
    /** Time the mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsDeleteV1Response: S.Schema<OriginCloudRegionsDeleteV1Response>;
export type OriginCloudRegionsEditV1RequestVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsEditV1RequestVendor: any;
export interface OriginCloudRegionsEditV1Request {
    /** Identifier. */
    zoneId: string;
    /** Origin IP address (IPv4 or IPv6). Normalized to canonical form before storage (RFC 5952 for IPv6). */
    ip: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsEditV1RequestVendor | (string & {});
}
export declare const OriginCloudRegionsEditV1Request: S.Schema<OriginCloudRegionsEditV1Request>;
export type OriginCloudRegionsEditV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsEditV1ResponseId: any;
export type OriginCloudRegionsEditV1ResponseValueItemVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsEditV1ResponseValueItemVendor: any;
export interface OriginCloudRegionsEditV1ResponseValueItem {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsEditV1ResponseValueItemVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsEditV1ResponseValueItem: S.Schema<OriginCloudRegionsEditV1ResponseValueItem>;
export type OriginCloudRegionsEditV1ResponseValueList = Array<OriginCloudRegionsEditV1ResponseValueItem>;
export declare const OriginCloudRegionsEditV1ResponseValueList: S.Schema<OriginCloudRegionsEditV1ResponseValueList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsEditV1Response {
    id: OriginCloudRegionsEditV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsEditV1ResponseValueList;
    /** Time the mapping set was last modified. Null when no mappings exist. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsEditV1Response: S.Schema<OriginCloudRegionsEditV1Response>;
export interface OriginCloudRegionsGetV1Request {
    /** Identifier. */
    zoneId: string;
    originIp: string;
}
export declare const OriginCloudRegionsGetV1Request: S.Schema<OriginCloudRegionsGetV1Request>;
export type OriginCloudRegionsGetV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsGetV1ResponseId: any;
export type OriginCloudRegionsGetV1ResponseValueVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsGetV1ResponseValueVendor: any;
export interface OriginCloudRegionsGetV1ResponseValue {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsGetV1ResponseValueVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsGetV1ResponseValue: S.Schema<OriginCloudRegionsGetV1ResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsGetV1Response {
    id: OriginCloudRegionsGetV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    /** A single origin IP-to-cloud-region mapping. */
    value: OriginCloudRegionsGetV1ResponseValue;
    /** Time the mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsGetV1Response: S.Schema<OriginCloudRegionsGetV1Response>;
export interface OriginCloudRegionsListV1Request {
    /** Identifier. */
    zoneId: string;
}
export declare const OriginCloudRegionsListV1Request: S.Schema<OriginCloudRegionsListV1Request>;
export type OriginCloudRegionsListV1ResponseId = "origin_public_cloud_region";
export declare const OriginCloudRegionsListV1ResponseId: any;
export type OriginCloudRegionsListV1ResponseValueItemVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsListV1ResponseValueItemVendor: any;
export interface OriginCloudRegionsListV1ResponseValueItem {
    /** The origin IP address (IPv4 or IPv6, canonicalized). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsListV1ResponseValueItemVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsListV1ResponseValueItem: S.Schema<OriginCloudRegionsListV1ResponseValueItem>;
export type OriginCloudRegionsListV1ResponseValueList = Array<OriginCloudRegionsListV1ResponseValueItem>;
export declare const OriginCloudRegionsListV1ResponseValueList: S.Schema<OriginCloudRegionsListV1ResponseValueList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsListV1Response {
    id: OriginCloudRegionsListV1ResponseId;
    /** Whether the setting can be modified by the current user. */
    editable: boolean;
    value: OriginCloudRegionsListV1ResponseValueList;
    /** Time the mapping set was last modified. Null when no mappings exist. */
    modifiedOn?: string | null;
}
export declare const OriginCloudRegionsListV1Response: S.Schema<OriginCloudRegionsListV1Response>;
export interface OriginCloudRegionsSupportedRegionsV1Request {
    /** Identifier. */
    zoneId: string;
}
export declare const OriginCloudRegionsSupportedRegionsV1Request: S.Schema<OriginCloudRegionsSupportedRegionsV1Request>;
export type OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItemUpperTierColosList = Array<string>;
export declare const OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItemUpperTierColosList: S.Schema<OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItemUpperTierColosList>;
export interface OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItem {
    /** Cloud vendor region identifier. */
    name: string;
    /** Cloudflare Tiered Cache upper-tier colocation codes co-located with this cloud region. Requests from zones with a matching origin mapping will be routed through these colos. */
    upperTierColos: OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItemUpperTierColosList;
}
export declare const OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItem: S.Schema<OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItem>;
export type OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueList = Array<OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueItem>;
export declare const OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueList: S.Schema<OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueList>;
export type OriginCloudRegionsSupportedRegionsV1ResponseVendorsMap = {
    [key: string]: OriginCloudRegionsSupportedRegionsV1ResponseVendorsValueList | undefined;
};
export declare const OriginCloudRegionsSupportedRegionsV1ResponseVendorsMap: S.Schema<OriginCloudRegionsSupportedRegionsV1ResponseVendorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginCloudRegionsSupportedRegionsV1Response {
    /** Whether Cloudflare airport codes (IATA colo identifiers) were successfully resolved for the `upper_tier_colos` field on each region. When `false`, the `upper_tier_colos` arrays may be empty or incomplete. */
    obtainedCodes: boolean;
    /** Map of vendor name to list of supported regions. */
    vendors: OriginCloudRegionsSupportedRegionsV1ResponseVendorsMap;
}
export declare const OriginCloudRegionsSupportedRegionsV1Response: S.Schema<OriginCloudRegionsSupportedRegionsV1Response>;
export type CacheReserveEditRequestValue = "on" | "off";
export declare const CacheReserveEditRequestValue: any;
export interface PatchCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the Cache Reserve zone setting. */
    value: CacheReserveEditRequestValue | (string & {});
}
export declare const PatchCacheReserveRequest: S.Schema<PatchCacheReserveRequest>;
export type CacheReserveEditResponseId = "cache_reserve";
export declare const CacheReserveEditResponseId: any;
export type CacheReserveEditResponseValue = "on" | "off";
export declare const CacheReserveEditResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCacheReserveResponse {
    /** The identifier of the caching setting. */
    id: CacheReserveEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Cache Reserve zone setting. */
    value: CacheReserveEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const PatchCacheReserveResponse: S.Schema<PatchCacheReserveResponse>;
export type RegionalTieredCacheEditRequestValue = "on" | "off";
export declare const RegionalTieredCacheEditRequestValue: any;
export interface PatchRegionalTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the Regional Tiered Cache zone setting. */
    value: RegionalTieredCacheEditRequestValue | (string & {});
}
export declare const PatchRegionalTieredCacheRequest: S.Schema<PatchRegionalTieredCacheRequest>;
export type RegionalTieredCacheEditResponseId = "tc_regional";
export declare const RegionalTieredCacheEditResponseId: any;
export type RegionalTieredCacheEditResponseValue = "on" | "off";
export declare const RegionalTieredCacheEditResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRegionalTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: RegionalTieredCacheEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Regional Tiered Cache zone setting. */
    value: RegionalTieredCacheEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const PatchRegionalTieredCacheResponse: S.Schema<PatchRegionalTieredCacheResponse>;
export type SmartTieredCacheEditRequestValue = "on" | "off";
export declare const SmartTieredCacheEditRequestValue: any;
export interface PatchSmartTieredCacheRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable or disable the Smart Tiered Cache. */
    value: SmartTieredCacheEditRequestValue | (string & {});
}
export declare const PatchSmartTieredCacheRequest: S.Schema<PatchSmartTieredCacheRequest>;
export type SmartTieredCacheEditResponseId = "tiered_cache_smart_topology_enable";
export declare const SmartTieredCacheEditResponseId: any;
export type SmartTieredCacheEditResponseValue = "on" | "off";
export declare const SmartTieredCacheEditResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSmartTieredCacheResponse {
    /** The identifier of the caching setting. */
    id: SmartTieredCacheEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Smart Tiered Cache zone setting. */
    value: SmartTieredCacheEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const PatchSmartTieredCacheResponse: S.Schema<PatchSmartTieredCacheResponse>;
export type VariantsEditRequestValueAvifList = Array<string>;
export declare const VariantsEditRequestValueAvifList: S.Schema<VariantsEditRequestValueAvifList>;
export type VariantsEditRequestValueBmpList = Array<string>;
export declare const VariantsEditRequestValueBmpList: S.Schema<VariantsEditRequestValueBmpList>;
export type VariantsEditRequestValueGifList = Array<string>;
export declare const VariantsEditRequestValueGifList: S.Schema<VariantsEditRequestValueGifList>;
export type VariantsEditRequestValueJp2List = Array<string>;
export declare const VariantsEditRequestValueJp2List: S.Schema<VariantsEditRequestValueJp2List>;
export type VariantsEditRequestValueJpegList = Array<string>;
export declare const VariantsEditRequestValueJpegList: S.Schema<VariantsEditRequestValueJpegList>;
export type VariantsEditRequestValueJpgList = Array<string>;
export declare const VariantsEditRequestValueJpgList: S.Schema<VariantsEditRequestValueJpgList>;
export type VariantsEditRequestValueJpg2List = Array<string>;
export declare const VariantsEditRequestValueJpg2List: S.Schema<VariantsEditRequestValueJpg2List>;
export type VariantsEditRequestValuePngList = Array<string>;
export declare const VariantsEditRequestValuePngList: S.Schema<VariantsEditRequestValuePngList>;
export type VariantsEditRequestValueTifList = Array<string>;
export declare const VariantsEditRequestValueTifList: S.Schema<VariantsEditRequestValueTifList>;
export type VariantsEditRequestValueTiffList = Array<string>;
export declare const VariantsEditRequestValueTiffList: S.Schema<VariantsEditRequestValueTiffList>;
export type VariantsEditRequestValueWebpList = Array<string>;
export declare const VariantsEditRequestValueWebpList: S.Schema<VariantsEditRequestValueWebpList>;
export interface VariantsEditRequestValue {
    /** List of strings with the MIME types of all the variants that should be served for avif. */
    avif?: VariantsEditRequestValueAvifList;
    /** List of strings with the MIME types of all the variants that should be served for bmp. */
    bmp?: VariantsEditRequestValueBmpList;
    /** List of strings with the MIME types of all the variants that should be served for gif. */
    gif?: VariantsEditRequestValueGifList;
    /** List of strings with the MIME types of all the variants that should be served for jp2. */
    jp2?: VariantsEditRequestValueJp2List;
    /** List of strings with the MIME types of all the variants that should be served for jpeg. */
    jpeg?: VariantsEditRequestValueJpegList;
    /** List of strings with the MIME types of all the variants that should be served for jpg. */
    jpg?: VariantsEditRequestValueJpgList;
    /** List of strings with the MIME types of all the variants that should be served for jpg2. */
    jpg2?: VariantsEditRequestValueJpg2List;
    /** List of strings with the MIME types of all the variants that should be served for png. */
    png?: VariantsEditRequestValuePngList;
    /** List of strings with the MIME types of all the variants that should be served for tif. */
    tif?: VariantsEditRequestValueTifList;
    /** List of strings with the MIME types of all the variants that should be served for tiff. */
    tiff?: VariantsEditRequestValueTiffList;
    /** List of strings with the MIME types of all the variants that should be served for webp. */
    webp?: VariantsEditRequestValueWebpList;
}
export declare const VariantsEditRequestValue: S.Schema<VariantsEditRequestValue>;
export interface PatchVariantRequest {
    /** Identifier. */
    zoneId: string;
    /** Value of the zone setting. */
    value: VariantsEditRequestValue;
}
export declare const PatchVariantRequest: S.Schema<PatchVariantRequest>;
export type VariantsEditResponseId = "variants";
export declare const VariantsEditResponseId: any;
export type VariantsEditResponseValueAvifList = Array<string>;
export declare const VariantsEditResponseValueAvifList: S.Schema<VariantsEditResponseValueAvifList>;
export type VariantsEditResponseValueBmpList = Array<string>;
export declare const VariantsEditResponseValueBmpList: S.Schema<VariantsEditResponseValueBmpList>;
export type VariantsEditResponseValueGifList = Array<string>;
export declare const VariantsEditResponseValueGifList: S.Schema<VariantsEditResponseValueGifList>;
export type VariantsEditResponseValueJp2List = Array<string>;
export declare const VariantsEditResponseValueJp2List: S.Schema<VariantsEditResponseValueJp2List>;
export type VariantsEditResponseValueJpegList = Array<string>;
export declare const VariantsEditResponseValueJpegList: S.Schema<VariantsEditResponseValueJpegList>;
export type VariantsEditResponseValueJpgList = Array<string>;
export declare const VariantsEditResponseValueJpgList: S.Schema<VariantsEditResponseValueJpgList>;
export type VariantsEditResponseValueJpg2List = Array<string>;
export declare const VariantsEditResponseValueJpg2List: S.Schema<VariantsEditResponseValueJpg2List>;
export type VariantsEditResponseValuePngList = Array<string>;
export declare const VariantsEditResponseValuePngList: S.Schema<VariantsEditResponseValuePngList>;
export type VariantsEditResponseValueTifList = Array<string>;
export declare const VariantsEditResponseValueTifList: S.Schema<VariantsEditResponseValueTifList>;
export type VariantsEditResponseValueTiffList = Array<string>;
export declare const VariantsEditResponseValueTiffList: S.Schema<VariantsEditResponseValueTiffList>;
export type VariantsEditResponseValueWebpList = Array<string>;
export declare const VariantsEditResponseValueWebpList: S.Schema<VariantsEditResponseValueWebpList>;
export interface VariantsEditResponseValue {
    /** List of strings with the MIME types of all the variants that should be served for avif. */
    avif?: VariantsEditResponseValueAvifList | null;
    /** List of strings with the MIME types of all the variants that should be served for bmp. */
    bmp?: VariantsEditResponseValueBmpList | null;
    /** List of strings with the MIME types of all the variants that should be served for gif. */
    gif?: VariantsEditResponseValueGifList | null;
    /** List of strings with the MIME types of all the variants that should be served for jp2. */
    jp2?: VariantsEditResponseValueJp2List | null;
    /** List of strings with the MIME types of all the variants that should be served for jpeg. */
    jpeg?: VariantsEditResponseValueJpegList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg. */
    jpg?: VariantsEditResponseValueJpgList | null;
    /** List of strings with the MIME types of all the variants that should be served for jpg2. */
    jpg2?: VariantsEditResponseValueJpg2List | null;
    /** List of strings with the MIME types of all the variants that should be served for png. */
    png?: VariantsEditResponseValuePngList | null;
    /** List of strings with the MIME types of all the variants that should be served for tif. */
    tif?: VariantsEditResponseValueTifList | null;
    /** List of strings with the MIME types of all the variants that should be served for tiff. */
    tiff?: VariantsEditResponseValueTiffList | null;
    /** List of strings with the MIME types of all the variants that should be served for webp. */
    webp?: VariantsEditResponseValueWebpList | null;
}
export declare const VariantsEditResponseValue: S.Schema<VariantsEditResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchVariantResponse {
    /** The identifier of the caching setting. */
    id: VariantsEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the zone setting. */
    value: VariantsEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const PatchVariantResponse: S.Schema<PatchVariantResponse>;
export type PurgeRequestTagsList = Array<string>;
export declare const PurgeRequestTagsList: S.Schema<PurgeRequestTagsList>;
export type PurgeRequestHostsList = Array<string>;
export declare const PurgeRequestHostsList: S.Schema<PurgeRequestHostsList>;
export type PurgeRequestPrefixesList = Array<string>;
export declare const PurgeRequestPrefixesList: S.Schema<PurgeRequestPrefixesList>;
export type PurgeRequestFilesCachePurgeSingleFileList = Array<string>;
export declare const PurgeRequestFilesCachePurgeSingleFileList: S.Schema<PurgeRequestFilesCachePurgeSingleFileList>;
export type PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap = {
    [key: string]: string | undefined;
};
export declare const PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap: S.Schema<PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap>;
export interface PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItem {
    headers?: PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap;
    url?: string;
}
export declare const PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItem: S.Schema<PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export type PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersList = Array<PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export declare const PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersList: S.Schema<PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersList>;
export type PurgeRequestFiles = PurgeRequestFilesCachePurgeSingleFileList | PurgeRequestFilesCachePurgeSingleFileWithURLAndHeadersList;
export declare const PurgeRequestFiles: any;
export interface PurgeCacheRequest {
    zoneId: string;
    /** For more information on cache tags and purging by tags, please refer to [purge by cache-tags documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-tags/). */
    tags?: PurgeRequestTagsList;
    /** For more information purging by hostnames, please refer to [purge by hostname documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-hostname/). */
    hosts?: PurgeRequestHostsList;
    /** For more information on purging by prefixes, please refer to [purge by prefix documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge_by_prefix/). */
    prefixes?: PurgeRequestPrefixesList;
    /** For more information, please refer to [purge everything documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-everything/). */
    purgeEverything?: boolean;
    /** For more information on purging files, please refer to [purge by single-file documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-single-file/). */
    files?: PurgeRequestFiles;
}
export declare const PurgeCacheRequest: S.Schema<PurgeCacheRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeCacheResponse {
    id: string;
}
export declare const PurgeCacheResponse: S.Schema<PurgeCacheResponse>;
export type PurgeEnvironmentRequestTagsList = Array<string>;
export declare const PurgeEnvironmentRequestTagsList: S.Schema<PurgeEnvironmentRequestTagsList>;
export type PurgeEnvironmentRequestHostsList = Array<string>;
export declare const PurgeEnvironmentRequestHostsList: S.Schema<PurgeEnvironmentRequestHostsList>;
export type PurgeEnvironmentRequestPrefixesList = Array<string>;
export declare const PurgeEnvironmentRequestPrefixesList: S.Schema<PurgeEnvironmentRequestPrefixesList>;
export type PurgeEnvironmentRequestFilesCachePurgeSingleFileList = Array<string>;
export declare const PurgeEnvironmentRequestFilesCachePurgeSingleFileList: S.Schema<PurgeEnvironmentRequestFilesCachePurgeSingleFileList>;
export type PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap = {
    [key: string]: string | undefined;
};
export declare const PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap: S.Schema<PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap>;
export interface PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem {
    headers?: PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItemHeadersMap;
    url?: string;
}
export declare const PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem: S.Schema<PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export type PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList = Array<PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersItem>;
export declare const PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList: S.Schema<PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList>;
export type PurgeEnvironmentRequestFiles = PurgeEnvironmentRequestFilesCachePurgeSingleFileList | PurgeEnvironmentRequestFilesCachePurgeSingleFileWithURLAndHeadersList;
export declare const PurgeEnvironmentRequestFiles: any;
export interface PurgeEnvironmentCacheRequest {
    zoneId: string;
    environmentId: string;
    /** For more information on cache tags and purging by tags, please refer to [purge by cache-tags documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-tags/). */
    tags?: PurgeEnvironmentRequestTagsList;
    /** For more information purging by hostnames, please refer to [purge by hostname documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-hostname/). */
    hosts?: PurgeEnvironmentRequestHostsList;
    /** For more information on purging by prefixes, please refer to [purge by prefix documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge_by_prefix/). */
    prefixes?: PurgeEnvironmentRequestPrefixesList;
    /** For more information, please refer to [purge everything documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-everything/). */
    purgeEverything?: boolean;
    /** For more information on purging files, please refer to [purge by single-file documentation page](https://developers.cloudflare.com/cache/how-to/purge-cache/purge-by-single-file/). */
    files?: PurgeEnvironmentRequestFiles;
}
export declare const PurgeEnvironmentCacheRequest: S.Schema<PurgeEnvironmentCacheRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeEnvironmentCacheResponse {
    id: string;
}
export declare const PurgeEnvironmentCacheResponse: S.Schema<PurgeEnvironmentCacheResponse>;
export type OriginCloudRegionsUpdateRequestVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsUpdateRequestVendor: any;
export interface PutOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
    /** Cloud vendor region identifier. Must be a valid region for the specified vendor as returned by the supported_regions endpoint. */
    region: string;
    /** Cloud vendor hosting the origin. Must be one of the supported vendors. */
    vendor: OriginCloudRegionsUpdateRequestVendor | (string & {});
    originIP: string;
    /** Origin IP address (IPv4 or IPv6). For the single PUT endpoint (`PUT /origin/cloud_regions/{origin_ip}`), this field must match the path parameter or the request will be rejected with a 400 error. For the batch PUT endpoint, this field identifies which mapping to upsert. */
    originIp: string;
}
export declare const PutOriginCloudRegionRequest: S.Schema<PutOriginCloudRegionRequest>;
export type OriginCloudRegionsUpdateResponseVendor = "aws" | "azure" | "gcp" | "oci";
export declare const OriginCloudRegionsUpdateResponseVendor: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutOriginCloudRegionResponse {
    /** The origin IP address (IPv4 or IPv6). Normalized to canonical form (RFC 5952 for IPv6). */
    originIp: string;
    /** Cloud vendor region identifier. */
    region: string;
    /** Cloud vendor hosting the origin. */
    vendor: OriginCloudRegionsUpdateResponseVendor;
    /** Time this mapping was last modified. */
    modifiedOn?: string | null;
}
export declare const PutOriginCloudRegionResponse: S.Schema<PutOriginCloudRegionResponse>;
export interface StatusCacheReserveRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const StatusCacheReserveRequest: S.Schema<StatusCacheReserveRequest>;
export type CacheReserveStatusResponseId = "cache_reserve_clear";
export declare const CacheReserveStatusResponseId: any;
export type CacheReserveStatusResponseState = "In-progress" | "Completed";
export declare const CacheReserveStatusResponseState: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatusCacheReserveResponse {
    /** ID of the zone setting. */
    id: CacheReserveStatusResponseId;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs: string;
    /** The current state of the Cache Reserve Clear operation. */
    state: CacheReserveStatusResponseState;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null;
    /** Last time this setting was modified. */
    modifiedOn?: string | null;
}
export declare const StatusCacheReserveResponse: S.Schema<StatusCacheReserveResponse>;
export interface SupportedRegionsOriginCloudRegionRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const SupportedRegionsOriginCloudRegionRequest: S.Schema<SupportedRegionsOriginCloudRegionRequest>;
export type OriginCloudRegionsSupportedRegionsResponseVendorsValueItemUpperTierColosList = Array<string>;
export declare const OriginCloudRegionsSupportedRegionsResponseVendorsValueItemUpperTierColosList: S.Schema<OriginCloudRegionsSupportedRegionsResponseVendorsValueItemUpperTierColosList>;
export interface OriginCloudRegionsSupportedRegionsResponseVendorsValueItem {
    /** Cloud vendor region identifier. */
    name: string;
    /** Cloudflare Tiered Cache upper-tier colocation codes co-located with this cloud region. Requests from zones with a matching origin mapping will be routed through these colos. */
    upperTierColos: OriginCloudRegionsSupportedRegionsResponseVendorsValueItemUpperTierColosList;
}
export declare const OriginCloudRegionsSupportedRegionsResponseVendorsValueItem: S.Schema<OriginCloudRegionsSupportedRegionsResponseVendorsValueItem>;
export type OriginCloudRegionsSupportedRegionsResponseVendorsValueList = Array<OriginCloudRegionsSupportedRegionsResponseVendorsValueItem>;
export declare const OriginCloudRegionsSupportedRegionsResponseVendorsValueList: S.Schema<OriginCloudRegionsSupportedRegionsResponseVendorsValueList>;
export type OriginCloudRegionsSupportedRegionsResponseVendorsMap = {
    [key: string]: OriginCloudRegionsSupportedRegionsResponseVendorsValueList | undefined;
};
export declare const OriginCloudRegionsSupportedRegionsResponseVendorsMap: S.Schema<OriginCloudRegionsSupportedRegionsResponseVendorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SupportedRegionsOriginCloudRegionResponse {
    /** Whether Cloudflare airport codes (IATA colo identifiers) were successfully resolved for the `upper_tier_colos` field on each region. When `false`, the `upper_tier_colos` arrays may be empty or incomplete. */
    obtainedCodes: boolean;
    /** Map of vendor name to list of supported regions. */
    vendors: OriginCloudRegionsSupportedRegionsResponseVendorsMap;
}
export declare const SupportedRegionsOriginCloudRegionResponse: S.Schema<SupportedRegionsOriginCloudRegionResponse>;
export type BulkDeleteOriginCloudRegionsError = CloudflareOpError;
/** Removes up to 100 IP-to-cloud-region mappings in a single request. Each IP is validated independently — successfully deleted items are returned in the `succeeded` array and IPs that could not be found or are invalid are returned in the `failed` array. */
export declare const bulkDeleteOriginCloudRegions: API.OperationMethod<BulkDeleteOriginCloudRegionsRequest, BulkDeleteOriginCloudRegionsResponse, BulkDeleteOriginCloudRegionsError, CloudflareOpContext>;
export type BulkPutOriginCloudRegionsError = CloudflareOpError;
/** Upserts up to 100 IP-to-cloud-region mappings in a single request. Items in the request body are created or replaced; mappings not included in the request body are preserved unchanged (this is a merge operation, not a full collection replacement). Each item is validated independently — valid items are applied and invalid items are returned in the `failed` array. The vendor and region for every item are validated against the list from `GET /zones/{zone_id}/origin/cloud_regions/supported_regions`. */
export declare const bulkPutOriginCloudRegions: API.OperationMethod<BulkPutOriginCloudRegionsRequest, BulkPutOriginCloudRegionsResponse, BulkPutOriginCloudRegionsError, CloudflareOpContext>;
export type ClearCacheReserveError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const clearCacheReserve: API.OperationMethod<ClearCacheReserveRequest, ClearCacheReserveResponse, ClearCacheReserveError, CloudflareOpContext>;
export type CreateSmartTieredCacheError = CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website's origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const createSmartTieredCache: API.OperationMethod<CreateSmartTieredCacheRequest, CreateSmartTieredCacheResponse, CreateSmartTieredCacheError, CloudflareOpContext>;
export type DeleteOriginCloudRegionError = OriginCloudRegionNotFound | Forbidden | CloudflareOpError;
/** Removes the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup. Returns the deleted IP on success. Returns 404 if no mapping exists for the specified IP. When the last mapping for the zone is removed the underlying rule record is also deleted. */
export declare const deleteOriginCloudRegion: API.OperationMethod<DeleteOriginCloudRegionRequest, DeleteOriginCloudRegionResponse, DeleteOriginCloudRegionError, CloudflareOpContext>;
export type DeleteSmartTieredCacheError = CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website’s origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const deleteSmartTieredCache: API.OperationMethod<DeleteSmartTieredCacheRequest, DeleteSmartTieredCacheResponse, DeleteSmartTieredCacheError, CloudflareOpContext>;
export type DeleteVariantError = VariantsNotConfigured | Forbidden | CloudflareOpError;
/** Variant support enables caching variants of images with certain file extensions in addition to the original. This only applies when the origin server sends the 'Vary: Accept' response header. If the origin server sends 'Vary: Accept' but does not serve the variant requested, the response will not be cached. This will be indicated with BYPASS cache status in the response headers. */
export declare const deleteVariant: API.OperationMethod<DeleteVariantRequest, DeleteVariantResponse, DeleteVariantError, CloudflareOpContext>;
export type GetCacheReserveError = SettingUnavailableForPlan | Forbidden | CloudflareOpError;
/** Increase cache lifetimes by automatically storing all cacheable files into Cloudflare's persistent object storage buckets. Requires Cache Reserve subscription. Note: using Tiered Cache with Cache Reserve is highly recommended to reduce Reserve operations costs. See the [developer docs](https://developers.cloudflare.com/cache/about/cache-reserve) for more information. */
export declare const getCacheReserve: API.OperationMethod<GetCacheReserveRequest, GetCacheReserveResponse, GetCacheReserveError, CloudflareOpContext>;
export type GetOriginCloudRegionError = OriginCloudRegionNotFound | Forbidden | CloudflareOpError;
/** Returns the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup (RFC 5952 for IPv6). Returns 404 if the zone has no mappings or if the specified IP has no mapping. */
export declare const getOriginCloudRegion: API.OperationMethod<GetOriginCloudRegionRequest, GetOriginCloudRegionResponse, GetOriginCloudRegionError, CloudflareOpContext>;
export type GetRegionalTieredCacheError = SettingUnavailableForPlan | Forbidden | Unauthorized | CloudflareOpError;
/** Instructs Cloudflare to check a regional hub data center on the way to your upper tier. This can help improve performance for smart and custom tiered cache topologies. */
export declare const getRegionalTieredCache: API.OperationMethod<GetRegionalTieredCacheRequest, GetRegionalTieredCacheResponse, GetRegionalTieredCacheError, CloudflareOpContext>;
export type GetSmartTieredCacheError = Forbidden | CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website’s origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const getSmartTieredCache: API.OperationMethod<GetSmartTieredCacheRequest, GetSmartTieredCacheResponse, GetSmartTieredCacheError, CloudflareOpContext>;
export type GetVariantError = VariantsNotConfigured | Forbidden | CloudflareOpError;
/** Variant support enables caching variants of images with certain file extensions in addition to the original. This only applies when the origin server sends the 'Vary: Accept' response header. If the origin server sends 'Vary: Accept' but does not serve the variant requested, the response will not be cached. This will be indicated with BYPASS cache status in the response headers. */
export declare const getVariant: API.OperationMethod<GetVariantRequest, GetVariantResponse, GetVariantError, CloudflareOpContext>;
export type ListOriginCloudRegionsError = Forbidden | CloudflareOpError;
/** Returns all IP-to-cloud-region mappings configured for the zone with pagination support. Each mapping tells Cloudflare which cloud vendor and region hosts the origin at that IP, enabling the edge to route via the nearest Tiered Cache upper-tier co-located with that cloud provider. Returns an empty array when no mappings exist. */
export declare const listOriginCloudRegions: API.PaginatedOperationMethod<ListOriginCloudRegionsRequest, ListOriginCloudRegionsResponse, ListOriginCloudRegionsError, CloudflareOpContext, OriginCloudRegionsListResultItem>;
export type OriginCloudRegionsBulkDeleteV1Error = CloudflareOpError;
/** Removes up to 100 IP-to-cloud-region mappings in a single request. Each IP is validated independently — successfully deleted items are returned in the `succeeded` array and IPs that could not be found or are invalid are returned in the `failed` array. */
export declare const originCloudRegionsBulkDeleteV1: API.OperationMethod<OriginCloudRegionsBulkDeleteV1Request, OriginCloudRegionsBulkDeleteV1Response, OriginCloudRegionsBulkDeleteV1Error, CloudflareOpContext>;
export type OriginCloudRegionsBulkEditV1Error = CloudflareOpError;
/** Adds or updates up to 100 IP-to-cloud-region mappings in a single request. Each item is validated independently — valid items are applied and invalid items are returned in the `failed` array. The vendor and region for every item are validated against the list from `GET /zones/{zone_id}/cache/origin_cloud_regions/supported_regions`. */
export declare const originCloudRegionsBulkEditV1: API.OperationMethod<OriginCloudRegionsBulkEditV1Request, OriginCloudRegionsBulkEditV1Response, OriginCloudRegionsBulkEditV1Error, CloudflareOpContext>;
export type OriginCloudRegionsCreateV1Error = CloudflareOpError;
/** Adds a single IP-to-cloud-region mapping for the zone. The IP must be a valid IPv4 or IPv6 address and is normalized to canonical form before storage (RFC 5952 for IPv6). Returns 400 (code 1145) if a mapping for that IP already exists — use PATCH to update an existing entry. The vendor and region are validated against the list from `GET /zones/{zone_id}/cache/origin_cloud_regions/supported_regions`. */
export declare const originCloudRegionsCreateV1: API.OperationMethod<OriginCloudRegionsCreateV1Request, OriginCloudRegionsCreateV1Response, OriginCloudRegionsCreateV1Error, CloudflareOpContext>;
export type OriginCloudRegionsDeleteV1Error = CloudflareOpError;
/** Removes the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup. Returns the deleted entry on success. Returns 404 (code 1163) if no mapping exists for the specified IP. When the last mapping for the zone is removed the underlying rule record is also deleted. */
export declare const originCloudRegionsDeleteV1: API.OperationMethod<OriginCloudRegionsDeleteV1Request, OriginCloudRegionsDeleteV1Response, OriginCloudRegionsDeleteV1Error, CloudflareOpContext>;
export type OriginCloudRegionsEditV1Error = CloudflareOpError;
/** Adds or updates a single IP-to-cloud-region mapping for the zone. Unlike POST, this operation is idempotent — if a mapping for the IP already exists it is overwritten. Returns the complete updated list of all mappings for the zone. Returns 403 (code 1164) when the zone has reached the limit of 3,500 IP mappings. */
export declare const originCloudRegionsEditV1: API.OperationMethod<OriginCloudRegionsEditV1Request, OriginCloudRegionsEditV1Response, OriginCloudRegionsEditV1Error, CloudflareOpContext>;
export type OriginCloudRegionsGetV1Error = CloudflareOpError;
/** Returns the cloud region mapping for a single origin IP address. The IP path parameter is normalized before lookup (RFC 5952 for IPv6). Returns 404 (code 1142) if the zone has no mappings or if the specified IP has no mapping. */
export declare const originCloudRegionsGetV1: API.OperationMethod<OriginCloudRegionsGetV1Request, OriginCloudRegionsGetV1Response, OriginCloudRegionsGetV1Error, CloudflareOpContext>;
export type OriginCloudRegionsListV1Error = CloudflareOpError;
/** Returns all IP-to-cloud-region mappings configured for the zone. Each mapping tells Cloudflare which cloud vendor and region hosts the origin at that IP, enabling the edge to route via the nearest Tiered Cache upper-tier co-located with that cloud provider. Returns an empty array when no mappings exist. */
export declare const originCloudRegionsListV1: API.OperationMethod<OriginCloudRegionsListV1Request, OriginCloudRegionsListV1Response, OriginCloudRegionsListV1Error, CloudflareOpContext>;
export type OriginCloudRegionsSupportedRegionsV1Error = CloudflareOpError;
/** Returns the cloud vendors and regions that are valid values for origin cloud region mappings. Each region includes the Tiered Cache upper-tier colocation codes that will be used for cache routing when a mapping targeting that region is active. Requires the zone to have Tiered Cache enabled. */
export declare const originCloudRegionsSupportedRegionsV1: API.OperationMethod<OriginCloudRegionsSupportedRegionsV1Request, OriginCloudRegionsSupportedRegionsV1Response, OriginCloudRegionsSupportedRegionsV1Error, CloudflareOpContext>;
export type PatchCacheReserveError = SettingUnavailableForPlan | Forbidden | CloudflareOpError;
/** Increase cache lifetimes by automatically storing all cacheable files into Cloudflare's persistent object storage buckets. Requires Cache Reserve subscription. Note: using Tiered Cache with Cache Reserve is highly recommended to reduce Reserve operations costs. See the [developer docs](https://developers.cloudflare.com/cache/about/cache-reserve) for more information. */
export declare const patchCacheReserve: API.OperationMethod<PatchCacheReserveRequest, PatchCacheReserveResponse, PatchCacheReserveError, CloudflareOpContext>;
export type PatchRegionalTieredCacheError = SettingUnavailableForPlan | Forbidden | CloudflareOpError;
/** Instructs Cloudflare to check a regional hub data center on the way to your upper tier. This can help improve performance for smart and custom tiered cache topologies. */
export declare const patchRegionalTieredCache: API.OperationMethod<PatchRegionalTieredCacheRequest, PatchRegionalTieredCacheResponse, PatchRegionalTieredCacheError, CloudflareOpContext>;
export type PatchSmartTieredCacheError = Forbidden | CloudflareOpError;
/** Smart Tiered Cache dynamically selects the single closest upper tier for each of your website’s origins with no configuration required, using our in-house performance and routing data. Cloudflare collects latency data for each request to an origin, and uses the latency data to determine how well any upper-tier data center is connected with an origin. As a result, Cloudflare can select the data center with the lowest latency to be the upper-tier for an origin. */
export declare const patchSmartTieredCache: API.OperationMethod<PatchSmartTieredCacheRequest, PatchSmartTieredCacheResponse, PatchSmartTieredCacheError, CloudflareOpContext>;
export type PatchVariantError = Forbidden | CloudflareOpError;
/** Variant support enables caching variants of images with certain file extensions in addition to the original. This only applies when the origin server sends the 'Vary: Accept' response header. If the origin server sends 'Vary: Accept' but does not serve the variant requested, the response will not be cached. This will be indicated with BYPASS cache status in the response headers. */
export declare const patchVariant: API.OperationMethod<PatchVariantRequest, PatchVariantResponse, PatchVariantError, CloudflareOpContext>;
export type PurgeCacheError = CloudflareOpError;
export declare const purgeCache: API.OperationMethod<PurgeCacheRequest, PurgeCacheResponse, PurgeCacheError, CloudflareOpContext>;
export type PurgeEnvironmentCacheError = CloudflareOpError;
/** Purge cached content scoped to a specific environment. Supports the same purge types as the zone-level endpoint (purge everything, by URL, by tag, host, or prefix). */
export declare const purgeEnvironmentCache: API.OperationMethod<PurgeEnvironmentCacheRequest, PurgeEnvironmentCacheResponse, PurgeEnvironmentCacheError, CloudflareOpContext>;
export type PutOriginCloudRegionError = Forbidden | CloudflareOpError;
/** Creates a new IP-to-cloud-region mapping or replaces the existing mapping for the specified IP. PUT is idempotent — calling it repeatedly with the same body produces the same result. The IP path parameter is normalized to canonical form (RFC 5952 for IPv6) before storage. The vendor and region are validated against the list from `GET /zones/{zone_id}/origin/cloud_regions/supported_regions`. Returns 400 if the `origin_ip` in the body does not match the URL path parameter. Returns 403 (code 1164) when the zone has reached the limit of 3,500 IP mappings. */
export declare const putOriginCloudRegion: API.OperationMethod<PutOriginCloudRegionRequest, PutOriginCloudRegionResponse, PutOriginCloudRegionError, CloudflareOpContext>;
export type StatusCacheReserveError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const statusCacheReserve: API.OperationMethod<StatusCacheReserveRequest, StatusCacheReserveResponse, StatusCacheReserveError, CloudflareOpContext>;
export type SupportedRegionsOriginCloudRegionError = CloudflareOpError;
/** Returns the cloud vendors and regions that are valid values for origin cloud region mappings. Each region includes the Tiered Cache upper-tier colocation codes that will be used for cache routing when a mapping targeting that region is active. Requires the zone to have Tiered Cache enabled. */
export declare const supportedRegionsOriginCloudRegion: API.OperationMethod<SupportedRegionsOriginCloudRegionRequest, SupportedRegionsOriginCloudRegionResponse, SupportedRegionsOriginCloudRegionError, CloudflareOpContext>;
//# sourceMappingURL=cache.d.ts.map