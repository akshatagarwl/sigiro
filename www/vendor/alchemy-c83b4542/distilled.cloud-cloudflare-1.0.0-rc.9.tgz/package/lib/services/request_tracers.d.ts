import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface TracesCreateRequestBody {
    /** Base64 encoded request body */
    base64?: string;
    /** Arbitrary json as request body */
    json?: unknown;
    /** Request body as plain text */
    plainText?: string;
}
export declare const TracesCreateRequestBody: S.Schema<TracesCreateRequestBody>;
export interface TracesCreateRequestContextGeoloc {
    city?: string;
    continent?: string;
    isEuCountry?: boolean;
    isoCode?: string;
    latitude?: number;
    longitude?: number;
    postalCode?: string;
    regionCode?: string;
    subdivision_2_iso_code?: string;
    timezone?: string;
}
export declare const TracesCreateRequestContextGeoloc: S.Schema<TracesCreateRequestContextGeoloc>;
export interface TracesCreateRequestContext {
    /** Bot score used for evaluating tracing request processing */
    botScore?: number;
    /** Geodata for tracing request */
    geoloc?: TracesCreateRequestContextGeoloc;
    /** Whether to skip any challenges for tracing request (e.g.: captcha) */
    skipChallenge?: boolean;
    /** Threat score used for evaluating tracing request processing */
    threatScore?: number;
}
export declare const TracesCreateRequestContext: S.Schema<TracesCreateRequestContext>;
export type TracesCreateRequestCookiesMap = {
    [key: string]: string | undefined;
};
export declare const TracesCreateRequestCookiesMap: S.Schema<TracesCreateRequestCookiesMap>;
export type TracesCreateRequestHeadersMap = {
    [key: string]: string | undefined;
};
export declare const TracesCreateRequestHeadersMap: S.Schema<TracesCreateRequestHeadersMap>;
export interface CreateTraceRequest {
    /** Identifier. */
    accountId: string;
    /** HTTP Method of tracing request */
    method: string;
    /** URL to which perform tracing request */
    url: string;
    body?: TracesCreateRequestBody;
    /** Additional request parameters */
    context?: TracesCreateRequestContext;
    /** Cookies added to tracing request */
    cookies?: TracesCreateRequestCookiesMap;
    /** Headers added to tracing request */
    headers?: TracesCreateRequestHeadersMap;
    /** HTTP Protocol of tracing request */
    protocol?: string;
    /** Skip sending the request to the Origin server after all rules evaluation */
    skipResponse?: boolean;
}
export declare const CreateTraceRequest: S.Schema<CreateTraceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTraceResponse {
    /** HTTP Status code of zone response */
    statusCode?: number | null;
    trace?: unknown | null;
}
export declare const CreateTraceResponse: S.Schema<CreateTraceResponse>;
export type CreateTraceError = CloudflareOpError;
/** Request Trace */
export declare const createTrace: API.OperationMethod<CreateTraceRequest, CreateTraceResponse, CreateTraceError, CloudflareOpContext>;
//# sourceMappingURL=request_tracers.d.ts.map