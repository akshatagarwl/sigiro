import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const D1DatabaseNotFound_base: S.Class<D1DatabaseNotFound, S.TaggedStruct<"D1DatabaseNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class D1DatabaseNotFound extends /*@__PURE__*/ D1DatabaseNotFound_base {
}
declare const DispatchNamespaceAlreadyExists_base: S.Class<DispatchNamespaceAlreadyExists, S.TaggedStruct<"DispatchNamespaceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DispatchNamespaceAlreadyExists extends /*@__PURE__*/ DispatchNamespaceAlreadyExists_base {
}
declare const DispatchNamespaceNotFound_base: S.Class<DispatchNamespaceNotFound, S.TaggedStruct<"DispatchNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DispatchNamespaceNotFound extends /*@__PURE__*/ DispatchNamespaceNotFound_base {
}
declare const DispatchNamespaceScriptNotFound_base: S.Class<DispatchNamespaceScriptNotFound, S.TaggedStruct<"DispatchNamespaceScriptNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DispatchNamespaceScriptNotFound extends /*@__PURE__*/ DispatchNamespaceScriptNotFound_base {
}
declare const DurableObjectClassNotFound_base: S.Class<DurableObjectClassNotFound, S.TaggedStruct<"DurableObjectClassNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DurableObjectClassNotFound extends /*@__PURE__*/ DurableObjectClassNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HyperdriveConfigNotFound_base: S.Class<HyperdriveConfigNotFound, S.TaggedStruct<"HyperdriveConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HyperdriveConfigNotFound extends /*@__PURE__*/ HyperdriveConfigNotFound_base {
}
declare const KVNamespaceNotFound_base: S.Class<KVNamespaceNotFound, S.TaggedStruct<"KVNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KVNamespaceNotFound extends /*@__PURE__*/ KVNamespaceNotFound_base {
}
declare const MtlsCertificateNotFound_base: S.Class<MtlsCertificateNotFound, S.TaggedStruct<"MtlsCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MtlsCertificateNotFound extends /*@__PURE__*/ MtlsCertificateNotFound_base {
}
declare const QueueNotFound_base: S.Class<QueueNotFound, S.TaggedStruct<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const R2BucketNotFound_base: S.Class<R2BucketNotFound, S.TaggedStruct<"R2BucketNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class R2BucketNotFound extends /*@__PURE__*/ R2BucketNotFound_base {
}
declare const SecretsStoreBindingNotFound_base: S.Class<SecretsStoreBindingNotFound, S.TaggedStruct<"SecretsStoreBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretsStoreBindingNotFound extends /*@__PURE__*/ SecretsStoreBindingNotFound_base {
}
declare const ServiceBindingNotFound_base: S.Class<ServiceBindingNotFound, S.TaggedStruct<"ServiceBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceBindingNotFound extends /*@__PURE__*/ ServiceBindingNotFound_base {
}
declare const VectorizeIndexNotFound_base: S.Class<VectorizeIndexNotFound, S.TaggedStruct<"VectorizeIndexNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VectorizeIndexNotFound extends /*@__PURE__*/ VectorizeIndexNotFound_base {
}
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretTextType: any;
export interface DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretTextType;
}
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretText: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretText>;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyFormat: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyType: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesItem | (string & {})>;
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKey: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKey>;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestSecrets = DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretText | DispatchNamespacesScriptsSecretsBulkUpdateRequestSecretsSecretKey;
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestSecrets: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateRequestVersionTagsMap = {
    [key: string]: unknown | undefined;
};
export declare const DispatchNamespacesScriptsSecretsBulkUpdateRequestVersionTagsMap: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateRequestVersionTagsMap>;
export interface BulkUpdateDispatchNamespaceScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Map of secret names to secret values: */
    secrets?: DispatchNamespacesScriptsSecretsBulkUpdateRequestSecrets;
    /** Optional version tags to apply to the new script version. */
    versionTags?: DispatchNamespacesScriptsSecretsBulkUpdateRequestVersionTagsMap;
}
export declare const BulkUpdateDispatchNamespaceScriptSecretsRequest: S.Schema<BulkUpdateDispatchNamespaceScriptSecretsRequest>;
export type DispatchNamespacesScriptsSecretsBulkUpdateResultSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretTextType: any;
export interface DispatchNamespacesScriptsSecretsBulkUpdateResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateResultSecretTextType;
}
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretText: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateResultSecretText>;
export type DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyFormat: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyType: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKey: S.Schema<DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKey>;
export type DispatchNamespacesScriptsSecretsBulkUpdateResult = DispatchNamespacesScriptsSecretsBulkUpdateResultSecretText | DispatchNamespacesScriptsSecretsBulkUpdateResultSecretKey;
export declare const DispatchNamespacesScriptsSecretsBulkUpdateResult: any;
export type BulkUpdateDispatchNamespaceScriptSecretsResponse = DispatchNamespacesScriptsSecretsBulkUpdateResult;
export declare const BulkUpdateDispatchNamespaceScriptSecretsResponse: S.Schema<BulkUpdateDispatchNamespaceScriptSecretsResponse>;
export interface CreateDispatchNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** The name of the dispatch namespace. */
    name?: string;
}
export declare const CreateDispatchNamespaceRequest: S.Schema<CreateDispatchNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDispatchNamespaceResponse {
    /** Identifier. */
    createdBy?: string | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Identifier. */
    modifiedBy?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** API Resource UUID tag. */
    namespaceId?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    namespaceName?: string | null;
    /** The current number of scripts in this Dispatch Namespace. */
    scriptCount?: number | null;
    /** Whether the Workers in the namespace are executed in a "trusted" manner. When a Worker is trusted, it has access to the shared caches for the zone in the Cache API, and has access to the `request.cf` object on incoming Requests. When a Worker is untrusted, caches are not shared across the zone, and `request.cf` is undefined. By default, Workers in a namespace are "untrusted". */
    trustedWorkers?: boolean | null;
}
export declare const CreateDispatchNamespaceResponse: S.Schema<CreateDispatchNamespaceResponse>;
export interface DispatchNamespacesScriptsAssetUploadCreateRequestManifestValue {
    /** The hash of the file. */
    hash: string;
    /** The size of the file in bytes. */
    size: number;
}
export declare const DispatchNamespacesScriptsAssetUploadCreateRequestManifestValue: S.Schema<DispatchNamespacesScriptsAssetUploadCreateRequestManifestValue>;
export type DispatchNamespacesScriptsAssetUploadCreateRequestManifestMap = {
    [key: string]: DispatchNamespacesScriptsAssetUploadCreateRequestManifestValue | undefined;
};
export declare const DispatchNamespacesScriptsAssetUploadCreateRequestManifestMap: S.Schema<DispatchNamespacesScriptsAssetUploadCreateRequestManifestMap>;
export interface CreateDispatchNamespaceScriptAssetUploadRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A manifest ([path]: {hash, size}) map of files to upload. As an example, `/blog/hello-world.html` would be a valid path key. */
    manifest: DispatchNamespacesScriptsAssetUploadCreateRequestManifestMap;
}
export declare const CreateDispatchNamespaceScriptAssetUploadRequest: S.Schema<CreateDispatchNamespaceScriptAssetUploadRequest>;
export type DispatchNamespacesScriptsAssetUploadCreateResponseBucketsItemList = Array<string>;
export declare const DispatchNamespacesScriptsAssetUploadCreateResponseBucketsItemList: S.Schema<DispatchNamespacesScriptsAssetUploadCreateResponseBucketsItemList>;
export type DispatchNamespacesScriptsAssetUploadCreateResponseBucketsList = Array<DispatchNamespacesScriptsAssetUploadCreateResponseBucketsItemList>;
export declare const DispatchNamespacesScriptsAssetUploadCreateResponseBucketsList: S.Schema<DispatchNamespacesScriptsAssetUploadCreateResponseBucketsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDispatchNamespaceScriptAssetUploadResponse {
    /** The requests to make to upload assets. */
    buckets?: DispatchNamespacesScriptsAssetUploadCreateResponseBucketsList | null;
    /** A JWT to use as authentication for uploading assets. */
    jwt?: string | null;
}
export declare const CreateDispatchNamespaceScriptAssetUploadResponse: S.Schema<CreateDispatchNamespaceScriptAssetUploadResponse>;
export interface DeleteDispatchNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
}
export declare const DeleteDispatchNamespaceRequest: S.Schema<DeleteDispatchNamespaceRequest>;
export type DeleteDispatchNamespaceResponse = unknown;
export declare const DeleteDispatchNamespaceResponse: S.Schema<DeleteDispatchNamespaceResponse>;
export interface DeleteDispatchNamespaceScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** If set to true, delete will not be stopped by associated service binding, durable object, or other binding. Any of these associated bindings/durable objects will be deleted along with the script. */
    force?: boolean;
}
export declare const DeleteDispatchNamespaceScriptRequest: S.Schema<DeleteDispatchNamespaceScriptRequest>;
export type DeleteDispatchNamespaceScriptResponse = unknown;
export declare const DeleteDispatchNamespaceScriptResponse: S.Schema<DeleteDispatchNamespaceScriptResponse>;
export interface DeleteDispatchNamespaceScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export declare const DeleteDispatchNamespaceScriptSecretRequest: S.Schema<DeleteDispatchNamespaceScriptSecretRequest>;
export type DeleteDispatchNamespaceScriptSecretResponse = unknown;
export declare const DeleteDispatchNamespaceScriptSecretResponse: S.Schema<DeleteDispatchNamespaceScriptSecretResponse>;
export interface DeleteDispatchNamespaceScriptTagRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    tag: string;
}
export declare const DeleteDispatchNamespaceScriptTagRequest: S.Schema<DeleteDispatchNamespaceScriptTagRequest>;
export type DeleteDispatchNamespaceScriptTagResponse = unknown;
export declare const DeleteDispatchNamespaceScriptTagResponse: S.Schema<DeleteDispatchNamespaceScriptTagResponse>;
export interface GetDispatchNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
}
export declare const GetDispatchNamespaceRequest: S.Schema<GetDispatchNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDispatchNamespaceResponse {
    /** Identifier. */
    createdBy?: string | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Identifier. */
    modifiedBy?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** API Resource UUID tag. */
    namespaceId?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    namespaceName?: string | null;
    /** The current number of scripts in this Dispatch Namespace. */
    scriptCount?: number | null;
    /** Whether the Workers in the namespace are executed in a "trusted" manner. When a Worker is trusted, it has access to the shared caches for the zone in the Cache API, and has access to the `request.cf` object on incoming Requests. When a Worker is untrusted, caches are not shared across the zone, and `request.cf` is undefined. By default, Workers in a namespace are "untrusted". */
    trustedWorkers?: boolean | null;
}
export declare const GetDispatchNamespaceResponse: S.Schema<GetDispatchNamespaceResponse>;
export interface GetDispatchNamespaceScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetDispatchNamespaceScriptRequest: S.Schema<GetDispatchNamespaceScriptRequest>;
export interface DispatchNamespacesScriptsGetResponseScriptCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version */
    crossVersionCache?: boolean | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptCacheOptions: S.Schema<DispatchNamespacesScriptsGetResponseScriptCacheOptions>;
export type DispatchNamespacesScriptsGetResponseScriptCompatibilityFlagsList = Array<string>;
export declare const DispatchNamespacesScriptsGetResponseScriptCompatibilityFlagsList: S.Schema<DispatchNamespacesScriptsGetResponseScriptCompatibilityFlagsList>;
export type DispatchNamespacesScriptsGetResponseScriptHandlersList = Array<string>;
export declare const DispatchNamespacesScriptsGetResponseScriptHandlersList: S.Schema<DispatchNamespacesScriptsGetResponseScriptHandlersList>;
export type DispatchNamespacesScriptsGetResponseScriptNamedHandlersItemHandlersList = Array<string>;
export declare const DispatchNamespacesScriptsGetResponseScriptNamedHandlersItemHandlersList: S.Schema<DispatchNamespacesScriptsGetResponseScriptNamedHandlersItemHandlersList>;
export interface DispatchNamespacesScriptsGetResponseScriptNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: DispatchNamespacesScriptsGetResponseScriptNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptNamedHandlersItem: S.Schema<DispatchNamespacesScriptsGetResponseScriptNamedHandlersItem>;
export type DispatchNamespacesScriptsGetResponseScriptNamedHandlersList = Array<DispatchNamespacesScriptsGetResponseScriptNamedHandlersItem>;
export declare const DispatchNamespacesScriptsGetResponseScriptNamedHandlersList: S.Schema<DispatchNamespacesScriptsGetResponseScriptNamedHandlersList>;
export type DispatchNamespacesScriptsGetResponseScriptObservabilityLogsDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsGetResponseScriptObservabilityLogsDestinationsList: S.Schema<DispatchNamespacesScriptsGetResponseScriptObservabilityLogsDestinationsList>;
export interface DispatchNamespacesScriptsGetResponseScriptObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsGetResponseScriptObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptObservabilityLogs: S.Schema<DispatchNamespacesScriptsGetResponseScriptObservabilityLogs>;
export type DispatchNamespacesScriptsGetResponseScriptObservabilityTracesDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsGetResponseScriptObservabilityTracesDestinationsList: S.Schema<DispatchNamespacesScriptsGetResponseScriptObservabilityTracesDestinationsList>;
export type DispatchNamespacesScriptsGetResponseScriptObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const DispatchNamespacesScriptsGetResponseScriptObservabilityTracesPropagationPolicy: any;
export interface DispatchNamespacesScriptsGetResponseScriptObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsGetResponseScriptObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: DispatchNamespacesScriptsGetResponseScriptObservabilityTracesPropagationPolicy | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptObservabilityTraces: S.Schema<DispatchNamespacesScriptsGetResponseScriptObservabilityTraces>;
export interface DispatchNamespacesScriptsGetResponseScriptObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsGetResponseScriptObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsGetResponseScriptObservabilityTraces | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptObservability: S.Schema<DispatchNamespacesScriptsGetResponseScriptObservability>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase0Mode = "smart";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase0Mode: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase0Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase0Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase0: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase0>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase1Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase1Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase1: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase1>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase2Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase2Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase2: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase2>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase3Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase3Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase3: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase3>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase4Mode = "targeted";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase4Mode: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase4Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase4Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase4: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase4>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase5Mode = "targeted";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase5Mode: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase5Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase5Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase5: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase5>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase6Mode = "targeted";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase6Mode: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase6Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase6Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase6: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase6>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7Mode = "targeted";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7Mode: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion {
    /** Cloud region in format 'provider:region'. */
    region: string;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion>;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname {
    /** HTTP hostname for targeted placement. */
    hostname: string;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost {
    /** TCP host:port for targeted placement. */
    host: string;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItem: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetList = Array<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItem>;
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetList: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetList>;
export type DispatchNamespacesScriptsGetResponseScriptPlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7Status: any;
export interface DispatchNamespacesScriptsGetResponseScriptPlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsGetResponseScriptPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsGetResponseScriptPlacementCase7Status | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementCase7: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7>;
export type DispatchNamespacesScriptsGetResponseScriptPlacement = DispatchNamespacesScriptsGetResponseScriptPlacementCase0 | DispatchNamespacesScriptsGetResponseScriptPlacementCase1 | DispatchNamespacesScriptsGetResponseScriptPlacementCase2 | DispatchNamespacesScriptsGetResponseScriptPlacementCase3 | DispatchNamespacesScriptsGetResponseScriptPlacementCase4 | DispatchNamespacesScriptsGetResponseScriptPlacementCase5 | DispatchNamespacesScriptsGetResponseScriptPlacementCase6 | DispatchNamespacesScriptsGetResponseScriptPlacementCase7;
export declare const DispatchNamespacesScriptsGetResponseScriptPlacement: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementMode = "smart" | "targeted";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementMode: any;
export type DispatchNamespacesScriptsGetResponseScriptPlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsGetResponseScriptPlacementStatus: any;
export type DispatchNamespacesScriptsGetResponseScriptTagsList = Array<string>;
export declare const DispatchNamespacesScriptsGetResponseScriptTagsList: S.Schema<DispatchNamespacesScriptsGetResponseScriptTagsList>;
export interface DispatchNamespacesScriptsGetResponseScriptTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string | null;
}
export declare const DispatchNamespacesScriptsGetResponseScriptTailConsumersItem: S.Schema<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsGetResponseScriptTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export declare const DispatchNamespacesScriptsGetResponseScriptTailConsumersList: S.Schema<DispatchNamespacesScriptsGetResponseScriptTailConsumersList>;
export type DispatchNamespacesScriptsGetResponseScriptUsageModel = "standard" | "bundled" | "unbound";
export declare const DispatchNamespacesScriptsGetResponseScriptUsageModel: any;
export interface DispatchNamespacesScriptsGetResponseScript {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsGetResponseScriptCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: DispatchNamespacesScriptsGetResponseScriptHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: DispatchNamespacesScriptsGetResponseScriptNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsGetResponseScriptObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsGetResponseScriptPlacement | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placementMode?: DispatchNamespacesScriptsGetResponseScriptPlacementMode | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    placementStatus?: DispatchNamespacesScriptsGetResponseScriptPlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsGetResponseScriptTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsGetResponseScriptTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsGetResponseScriptUsageModel | null;
}
export declare const DispatchNamespacesScriptsGetResponseScript: S.Schema<DispatchNamespacesScriptsGetResponseScript>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDispatchNamespaceScriptResponse {
    /** When the script was created. */
    createdOn?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    script?: DispatchNamespacesScriptsGetResponseScript | null;
}
export declare const GetDispatchNamespaceScriptResponse: S.Schema<GetDispatchNamespaceScriptResponse>;
export interface GetDispatchNamespaceScriptBindingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetDispatchNamespaceScriptBindingRequest: S.Schema<GetDispatchNamespaceScriptBindingRequest>;
export type DispatchNamespacesScriptsBindingsGetResultItemAIType = "ai";
export declare const DispatchNamespacesScriptsBindingsGetResultItemAIType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAIType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemAI: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemAI>;
export type DispatchNamespacesScriptsBindingsGetResultItemAISearchType = "ai_search";
export declare const DispatchNamespacesScriptsBindingsGetResultItemAISearchType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemAISearch: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemAISearch>;
export type DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespaceType = "ai_search_namespace";
export declare const DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespaceType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespaceType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespace: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespace>;
export type DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngineType = "analytics_engine";
export declare const DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngineType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngineType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngine: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngine>;
export type DispatchNamespacesScriptsBindingsGetResultItemAssetsType = "assets";
export declare const DispatchNamespacesScriptsBindingsGetResultItemAssetsType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemAssetsType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemAssets: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemAssets>;
export type DispatchNamespacesScriptsBindingsGetResultItemBrowserType = "browser";
export declare const DispatchNamespacesScriptsBindingsGetResultItemBrowserType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemBrowserType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemBrowser: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemBrowser>;
export type DispatchNamespacesScriptsBindingsGetResultItemD1Type = "d1";
export declare const DispatchNamespacesScriptsBindingsGetResultItemD1Type: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemD1: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemD1>;
export type DispatchNamespacesScriptsBindingsGetResultItemDataBlobType = "data_blob";
export declare const DispatchNamespacesScriptsBindingsGetResultItemDataBlobType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemDataBlobType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemDataBlob: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDataBlob>;
export type DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceType = "dispatch_namespace";
export declare const DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem {
    /** Name of the parameter. */
    name: string;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export type DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export declare const DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsList: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsList>;
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string | null;
    /** Environment of the outbound worker. */
    environment?: string | null;
    /** Name of the outbound worker. */
    service?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker>;
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutbound: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutbound>;
export interface DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutbound | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespace: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespace>;
export type DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespaceType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespace: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespace>;
export type DispatchNamespacesScriptsBindingsGetResultItemHyperdriveType = "hyperdrive";
export declare const DispatchNamespacesScriptsBindingsGetResultItemHyperdriveType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemHyperdriveType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemHyperdrive: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemHyperdrive>;
export type DispatchNamespacesScriptsBindingsGetResultItemInheritType = "inherit";
export declare const DispatchNamespacesScriptsBindingsGetResultItemInheritType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemInherit: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemInherit>;
export type DispatchNamespacesScriptsBindingsGetResultItemImagesType = "images";
export declare const DispatchNamespacesScriptsBindingsGetResultItemImagesType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemImagesType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemImages: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemImages>;
export type DispatchNamespacesScriptsBindingsGetResultItemJsonType = "json";
export declare const DispatchNamespacesScriptsBindingsGetResultItemJsonType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemJsonType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemJson: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemJson>;
export type DispatchNamespacesScriptsBindingsGetResultItemKVNamespaceType = "kv_namespace";
export declare const DispatchNamespacesScriptsBindingsGetResultItemKVNamespaceType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemKVNamespaceType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemKVNamespace: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemKVNamespace>;
export type DispatchNamespacesScriptsBindingsGetResultItemMediaType = "media";
export declare const DispatchNamespacesScriptsBindingsGetResultItemMediaType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemMediaType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemMedia: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemMedia>;
export type DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificateType = "mtls_certificate";
export declare const DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificateType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificateType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificate: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificate>;
export type DispatchNamespacesScriptsBindingsGetResultItemPlainTextType = "plain_text";
export declare const DispatchNamespacesScriptsBindingsGetResultItemPlainTextType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemPlainTextType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemPlainText: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemPlainText>;
export type DispatchNamespacesScriptsBindingsGetResultItemPipelinesType = "pipelines";
export declare const DispatchNamespacesScriptsBindingsGetResultItemPipelinesType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemPipelinesType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemPipelines: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemPipelines>;
export type DispatchNamespacesScriptsBindingsGetResultItemQueueType = "queue";
export declare const DispatchNamespacesScriptsBindingsGetResultItemQueueType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemQueueType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemQueue: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemQueue>;
export interface DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple>;
export type DispatchNamespacesScriptsBindingsGetResultItemRatelimitType = "ratelimit";
export declare const DispatchNamespacesScriptsBindingsGetResultItemRatelimitType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemRatelimitType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemRatelimit: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemRatelimit>;
export type DispatchNamespacesScriptsBindingsGetResultItemR2BucketType = "r2_bucket";
export declare const DispatchNamespacesScriptsBindingsGetResultItemR2BucketType: any;
export type DispatchNamespacesScriptsBindingsGetResultItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const DispatchNamespacesScriptsBindingsGetResultItemR2BucketJurisdiction: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsBindingsGetResultItemR2BucketJurisdiction | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemR2Bucket: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemR2Bucket>;
export type DispatchNamespacesScriptsBindingsGetResultItemSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretTextType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSecretTextType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretText: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSecretText>;
export type DispatchNamespacesScriptsBindingsGetResultItemSendEmailType = "send_email";
export declare const DispatchNamespacesScriptsBindingsGetResultItemSendEmailType: any;
export type DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedDestinationAddressesList: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedDestinationAddressesList>;
export type DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedSenderAddressesList: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedSenderAddressesList>;
export interface DispatchNamespacesScriptsBindingsGetResultItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsBindingsGetResultItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemSendEmail: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSendEmail>;
export type DispatchNamespacesScriptsBindingsGetResultItemServiceType = "service";
export declare const DispatchNamespacesScriptsBindingsGetResultItemServiceType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemService: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemService>;
export type DispatchNamespacesScriptsBindingsGetResultItemTextBlobType = "text_blob";
export declare const DispatchNamespacesScriptsBindingsGetResultItemTextBlobType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemTextBlobType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemTextBlob: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemTextBlob>;
export type DispatchNamespacesScriptsBindingsGetResultItemVectorizeType = "vectorize";
export declare const DispatchNamespacesScriptsBindingsGetResultItemVectorizeType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVectorizeType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemVectorize: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemVectorize>;
export type DispatchNamespacesScriptsBindingsGetResultItemVersionMetadataType = "version_metadata";
export declare const DispatchNamespacesScriptsBindingsGetResultItemVersionMetadataType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVersionMetadataType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemVersionMetadata: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemVersionMetadata>;
export type DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecretType = "secrets_store_secret";
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecretType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecretType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecret: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecret>;
export type DispatchNamespacesScriptsBindingsGetResultItemFlagshipType = "flagship";
export declare const DispatchNamespacesScriptsBindingsGetResultItemFlagshipType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemFlagshipType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemFlagship: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemFlagship>;
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretKeyFormat: any;
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretKeyType: any;
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsBindingsGetResultItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsBindingsGetResultItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsBindingsGetResultItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemSecretKey: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemSecretKey>;
export type DispatchNamespacesScriptsBindingsGetResultItemWorkflowType = "workflow";
export declare const DispatchNamespacesScriptsBindingsGetResultItemWorkflowType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemWorkflow: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemWorkflow>;
export type DispatchNamespacesScriptsBindingsGetResultItemWasmModuleType = "wasm_module";
export declare const DispatchNamespacesScriptsBindingsGetResultItemWasmModuleType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemWasmModuleType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemWasmModule: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemWasmModule>;
export type DispatchNamespacesScriptsBindingsGetResultItemVPCServiceType = "vpc_service";
export declare const DispatchNamespacesScriptsBindingsGetResultItemVPCServiceType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVPCServiceType;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemVPCService: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemVPCService>;
export type DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkType = "vpc_network";
export declare const DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkType: any;
export interface DispatchNamespacesScriptsBindingsGetResultItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsBindingsGetResultItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const DispatchNamespacesScriptsBindingsGetResultItemVPCNetwork: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemVPCNetwork>;
export type DispatchNamespacesScriptsBindingsGetResultItem = DispatchNamespacesScriptsBindingsGetResultItemAI | DispatchNamespacesScriptsBindingsGetResultItemAISearch | DispatchNamespacesScriptsBindingsGetResultItemAISearchNamespace | DispatchNamespacesScriptsBindingsGetResultItemAnalyticsEngine | DispatchNamespacesScriptsBindingsGetResultItemAssets | DispatchNamespacesScriptsBindingsGetResultItemBrowser | DispatchNamespacesScriptsBindingsGetResultItemD1 | DispatchNamespacesScriptsBindingsGetResultItemDataBlob | DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespace | DispatchNamespacesScriptsBindingsGetResultItemDurableObjectNamespace | DispatchNamespacesScriptsBindingsGetResultItemHyperdrive | DispatchNamespacesScriptsBindingsGetResultItemInherit | DispatchNamespacesScriptsBindingsGetResultItemImages | DispatchNamespacesScriptsBindingsGetResultItemJson | DispatchNamespacesScriptsBindingsGetResultItemKVNamespace | DispatchNamespacesScriptsBindingsGetResultItemMedia | DispatchNamespacesScriptsBindingsGetResultItemMTLSCertificate | DispatchNamespacesScriptsBindingsGetResultItemPlainText | DispatchNamespacesScriptsBindingsGetResultItemPipelines | DispatchNamespacesScriptsBindingsGetResultItemQueue | DispatchNamespacesScriptsBindingsGetResultItemRatelimit | DispatchNamespacesScriptsBindingsGetResultItemR2Bucket | DispatchNamespacesScriptsBindingsGetResultItemSecretText | DispatchNamespacesScriptsBindingsGetResultItemSendEmail | DispatchNamespacesScriptsBindingsGetResultItemService | DispatchNamespacesScriptsBindingsGetResultItemTextBlob | DispatchNamespacesScriptsBindingsGetResultItemVectorize | DispatchNamespacesScriptsBindingsGetResultItemVersionMetadata | DispatchNamespacesScriptsBindingsGetResultItemSecretsStoreSecret | DispatchNamespacesScriptsBindingsGetResultItemFlagship | DispatchNamespacesScriptsBindingsGetResultItemSecretKey | DispatchNamespacesScriptsBindingsGetResultItemWorkflow | DispatchNamespacesScriptsBindingsGetResultItemWasmModule | DispatchNamespacesScriptsBindingsGetResultItemVPCService | DispatchNamespacesScriptsBindingsGetResultItemVPCNetwork;
export declare const DispatchNamespacesScriptsBindingsGetResultItem: any;
export type DispatchNamespacesScriptsBindingsGetResultList = Array<DispatchNamespacesScriptsBindingsGetResultItem>;
export declare const DispatchNamespacesScriptsBindingsGetResultList: S.Schema<DispatchNamespacesScriptsBindingsGetResultList>;
export interface GetDispatchNamespaceScriptBindingResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsBindingsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetDispatchNamespaceScriptBindingResponse: S.Schema<GetDispatchNamespaceScriptBindingResponse>;
export interface GetDispatchNamespaceScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetDispatchNamespaceScriptContentRequest: S.Schema<GetDispatchNamespaceScriptContentRequest>;
export interface GetDispatchNamespaceScriptContentResponse {
}
export declare const GetDispatchNamespaceScriptContentResponse: S.Schema<GetDispatchNamespaceScriptContentResponse>;
export interface GetDispatchNamespaceScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export declare const GetDispatchNamespaceScriptSecretRequest: S.Schema<GetDispatchNamespaceScriptSecretRequest>;
export type DispatchNamespacesScriptsSecretsGetResultSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSecretsGetResultSecretTextType: any;
export interface DispatchNamespacesScriptsSecretsGetResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsGetResultSecretTextType;
}
export declare const DispatchNamespacesScriptsSecretsGetResultSecretText: S.Schema<DispatchNamespacesScriptsSecretsGetResultSecretText>;
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSecretsGetResultSecretKeyFormat: any;
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSecretsGetResultSecretKeyType: any;
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSecretsGetResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsGetResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsGetResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsGetResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsSecretsGetResultSecretKey: S.Schema<DispatchNamespacesScriptsSecretsGetResultSecretKey>;
export type DispatchNamespacesScriptsSecretsGetResult = DispatchNamespacesScriptsSecretsGetResultSecretText | DispatchNamespacesScriptsSecretsGetResultSecretKey;
export declare const DispatchNamespacesScriptsSecretsGetResult: any;
export type GetDispatchNamespaceScriptSecretResponse = DispatchNamespacesScriptsSecretsGetResult;
export declare const GetDispatchNamespaceScriptSecretResponse: S.Schema<GetDispatchNamespaceScriptSecretResponse>;
export interface GetDispatchNamespaceScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetDispatchNamespaceScriptSettingRequest: S.Schema<GetDispatchNamespaceScriptSettingRequest>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAIType = "ai";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAIType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAIType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAI: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemAI>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchType = "ai_search";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearch: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearch>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespaceType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespaceType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespace: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespace>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngineType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngineType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngine: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngine>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssetsType = "assets";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssetsType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssetsType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssets: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssets>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowserType = "browser";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowserType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowserType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowser: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowser>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1Type = "d1";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1Type: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlobType = "data_blob";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlobType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlobType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlob: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlob>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceType: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundWorker = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundWorker: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker>;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutbound: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutbound>;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespaceOutbound | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespace: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespace>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespaceType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespace: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespace>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdriveType = "hyperdrive";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdriveType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdriveType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdrive: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdrive>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemInheritType = "inherit";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemInheritType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemInherit: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemInherit>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemImagesType = "images";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemImagesType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemImagesType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemImages: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemImages>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemJsonType = "json";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemJsonType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemJsonType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemJson: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemJson>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespaceType = "kv_namespace";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespaceType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespaceType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespace: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespace>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemMediaType = "media";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemMediaType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemMediaType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemMedia: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemMedia>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificateType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificateType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificate: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificate>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainTextType = "plain_text";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainTextType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainTextType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainText: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainText>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelinesType = "pipelines";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelinesType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelinesType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelines: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelines>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueueType = "queue";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueueType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueueType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueue: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueue>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitSimple = DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitSimple: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitType = "ratelimit";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimitType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimit: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimit>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketType = "r2_bucket";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketType: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketJurisdiction: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2BucketJurisdiction | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2Bucket: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2Bucket>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretTextType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretTextType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretText: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretText>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailType = "send_email";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailType: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList>;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmail: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmail>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemServiceType = "service";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemServiceType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemService: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemService>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlobType = "text_blob";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlobType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlobType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlob: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlob>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorizeType = "vectorize";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorizeType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorizeType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorize: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorize>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadataType = "version_metadata";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadataType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadataType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadata: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadata>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecretType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecretType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecret: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecret>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagshipType = "flagship";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagshipType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagshipType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagship: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagship>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyFormat: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyType: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKey: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKey>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflowType = "workflow";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflowType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflow: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflow>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModuleType = "wasm_module";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModuleType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModuleType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModule: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModule>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCServiceType = "vpc_service";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCServiceType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCServiceType;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCService: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCService>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkType = "vpc_network";
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetwork: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetwork>;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsItem = DispatchNamespacesScriptsSettingsGetResponseBindingsItemAI | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearch | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAISearchNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAnalyticsEngine | DispatchNamespacesScriptsSettingsGetResponseBindingsItemAssets | DispatchNamespacesScriptsSettingsGetResponseBindingsItemBrowser | DispatchNamespacesScriptsSettingsGetResponseBindingsItemD1 | DispatchNamespacesScriptsSettingsGetResponseBindingsItemDataBlob | DispatchNamespacesScriptsSettingsGetResponseBindingsItemDispatchNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemDurableObjectNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemHyperdrive | DispatchNamespacesScriptsSettingsGetResponseBindingsItemInherit | DispatchNamespacesScriptsSettingsGetResponseBindingsItemImages | DispatchNamespacesScriptsSettingsGetResponseBindingsItemJson | DispatchNamespacesScriptsSettingsGetResponseBindingsItemKVNamespace | DispatchNamespacesScriptsSettingsGetResponseBindingsItemMedia | DispatchNamespacesScriptsSettingsGetResponseBindingsItemMTLSCertificate | DispatchNamespacesScriptsSettingsGetResponseBindingsItemPlainText | DispatchNamespacesScriptsSettingsGetResponseBindingsItemPipelines | DispatchNamespacesScriptsSettingsGetResponseBindingsItemQueue | DispatchNamespacesScriptsSettingsGetResponseBindingsItemRatelimit | DispatchNamespacesScriptsSettingsGetResponseBindingsItemR2Bucket | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretText | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSendEmail | DispatchNamespacesScriptsSettingsGetResponseBindingsItemService | DispatchNamespacesScriptsSettingsGetResponseBindingsItemTextBlob | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVectorize | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVersionMetadata | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretsStoreSecret | DispatchNamespacesScriptsSettingsGetResponseBindingsItemFlagship | DispatchNamespacesScriptsSettingsGetResponseBindingsItemSecretKey | DispatchNamespacesScriptsSettingsGetResponseBindingsItemWorkflow | DispatchNamespacesScriptsSettingsGetResponseBindingsItemWasmModule | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCService | DispatchNamespacesScriptsSettingsGetResponseBindingsItemVPCNetwork;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsItem: any;
export type DispatchNamespacesScriptsSettingsGetResponseBindingsList = Array<DispatchNamespacesScriptsSettingsGetResponseBindingsItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseBindingsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseBindingsList>;
export type DispatchNamespacesScriptsSettingsGetResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export declare const DispatchNamespacesScriptsSettingsGetResponseCacheOptions: S.Schema<DispatchNamespacesScriptsGetResponseScriptCacheOptions>;
export type DispatchNamespacesScriptsSettingsGetResponseCompatibilityFlagsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseCompatibilityFlagsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseCompatibilityFlagsList>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsValueType = "worker" | "durable-object";
export declare const DispatchNamespacesScriptsSettingsGetResponseExportsValueType: any;
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValueCache {
    /** Whether caching is enabled for this entrypoint. */
    enabled: boolean;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseExportsValueCache: S.Schema<DispatchNamespacesScriptsSettingsGetResponseExportsValueCache>;
export interface DispatchNamespacesScriptsSettingsGetResponseExportsValue {
    /** The kind of export. */
    type: DispatchNamespacesScriptsSettingsGetResponseExportsValueType;
    /** Cache override for this entrypoint. It applies only to */
    cache?: DispatchNamespacesScriptsSettingsGetResponseExportsValueCache | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseExportsValue: S.Schema<DispatchNamespacesScriptsSettingsGetResponseExportsValue>;
export type DispatchNamespacesScriptsSettingsGetResponseExportsMap = {
    [key: string]: DispatchNamespacesScriptsSettingsGetResponseExportsValue | undefined;
};
export declare const DispatchNamespacesScriptsSettingsGetResponseExportsMap: S.Schema<DispatchNamespacesScriptsSettingsGetResponseExportsMap>;
export interface DispatchNamespacesScriptsSettingsGetResponseLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number | null;
    /** The number of subrequests this Worker can make per request. */
    subrequests?: number | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseLimits: S.Schema<DispatchNamespacesScriptsSettingsGetResponseLimits>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewClassesList>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string | null;
    to?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string | null;
    fromScript?: string | null;
    to?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigration: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigration>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrations: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrations>;
export type DispatchNamespacesScriptsSettingsGetResponseMigrations = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigration | DispatchNamespacesScriptsSettingsGetResponseMigrationsWorkersMultipleStepMigrations;
export declare const DispatchNamespacesScriptsSettingsGetResponseMigrations: any;
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityLogsDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseObservabilityLogsDestinationsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseObservabilityLogsDestinationsList>;
export interface DispatchNamespacesScriptsSettingsGetResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsGetResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseObservabilityLogs: S.Schema<DispatchNamespacesScriptsSettingsGetResponseObservabilityLogs>;
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesDestinationsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesDestinationsList>;
export type DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesPropagationPolicy: any;
export interface DispatchNamespacesScriptsSettingsGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: DispatchNamespacesScriptsSettingsGetResponseObservabilityTracesPropagationPolicy | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseObservabilityTraces: S.Schema<DispatchNamespacesScriptsSettingsGetResponseObservabilityTraces>;
export interface DispatchNamespacesScriptsSettingsGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsSettingsGetResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsSettingsGetResponseObservabilityTraces | null;
}
export declare const DispatchNamespacesScriptsSettingsGetResponseObservability: S.Schema<DispatchNamespacesScriptsSettingsGetResponseObservability>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementModeMode = "smart";
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementModeMode: any;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementModeMode;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementMode: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementMode>;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementRegion {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementRegion: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementRegion>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementHost {
    /** TCP host and port for targeted placement. */
    host: string;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementHost: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementHost>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase4Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase4Mode: any;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase4: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementCase4>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase5Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase5Mode: any;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase5Mode;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase5: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementCase5>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase6Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase6Mode: any;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase6Mode;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase6: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementCase6>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7Mode: any;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemRegion: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItemHost: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItem: any;
export type DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetList: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetList>;
export interface DispatchNamespacesScriptsSettingsGetResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsGetResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsSettingsGetResponsePlacementCase7TargetList;
}
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacementCase7: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementCase7>;
export type DispatchNamespacesScriptsSettingsGetResponsePlacement = DispatchNamespacesScriptsSettingsGetResponsePlacementMode | DispatchNamespacesScriptsSettingsGetResponsePlacementRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsSettingsGetResponsePlacementHost | DispatchNamespacesScriptsSettingsGetResponsePlacementCase4 | DispatchNamespacesScriptsSettingsGetResponsePlacementCase5 | DispatchNamespacesScriptsSettingsGetResponsePlacementCase6 | DispatchNamespacesScriptsSettingsGetResponsePlacementCase7;
export declare const DispatchNamespacesScriptsSettingsGetResponsePlacement: any;
export type DispatchNamespacesScriptsSettingsGetResponseTagsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsGetResponseTagsList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseTagsList>;
export type DispatchNamespacesScriptsSettingsGetResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export declare const DispatchNamespacesScriptsSettingsGetResponseTailConsumersItem: S.Schema<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsSettingsGetResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export declare const DispatchNamespacesScriptsSettingsGetResponseTailConsumersList: S.Schema<DispatchNamespacesScriptsSettingsGetResponseTailConsumersList>;
export type DispatchNamespacesScriptsSettingsGetResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const DispatchNamespacesScriptsSettingsGetResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDispatchNamespaceScriptSettingResponse {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: DispatchNamespacesScriptsSettingsGetResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsSettingsGetResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries */
    exports?: DispatchNamespacesScriptsSettingsGetResponseExportsMap | null;
    /** Limits to apply for this Worker. */
    limits?: DispatchNamespacesScriptsSettingsGetResponseLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: DispatchNamespacesScriptsSettingsGetResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsSettingsGetResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsSettingsGetResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsSettingsGetResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsSettingsGetResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsSettingsGetResponseUsageModel | null;
}
export declare const GetDispatchNamespaceScriptSettingResponse: S.Schema<GetDispatchNamespaceScriptSettingResponse>;
export interface ListDispatchNamespacesRequest {
    /** Identifier. */
    accountId: string;
}
export declare const ListDispatchNamespacesRequest: S.Schema<ListDispatchNamespacesRequest>;
export interface DispatchNamespacesListResultItem {
    /** Identifier. */
    createdBy?: string | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Identifier. */
    modifiedBy?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** API Resource UUID tag. */
    namespaceId?: string | null;
    /** Name of the Workers for Platforms dispatch namespace. */
    namespaceName?: string | null;
    /** The current number of scripts in this Dispatch Namespace. */
    scriptCount?: number | null;
    /** Whether the Workers in the namespace are executed in a "trusted" manner. When a Worker is trusted, it has access to the shared caches for the zone in the Cache API, and has access to the `request.cf` object on incoming Requests. When a Worker is untrusted, caches are not shared across the zone, and `request.cf` is undefined. By default, Workers in a namespace are "untrusted". */
    trustedWorkers?: boolean | null;
}
export declare const DispatchNamespacesListResultItem: S.Schema<DispatchNamespacesListResultItem>;
export type DispatchNamespacesListResultList = Array<DispatchNamespacesListResultItem>;
export declare const DispatchNamespacesListResultList: S.Schema<DispatchNamespacesListResultList>;
export interface ListDispatchNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDispatchNamespacesResponse: S.Schema<ListDispatchNamespacesResponse>;
export interface ListDispatchNamespaceScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const ListDispatchNamespaceScriptSecretsRequest: S.Schema<ListDispatchNamespaceScriptSecretsRequest>;
export type DispatchNamespacesScriptsSecretsListResultItemSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretTextType: any;
export interface DispatchNamespacesScriptsSecretsListResultItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsListResultItemSecretTextType;
}
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretText: S.Schema<DispatchNamespacesScriptsSecretsListResultItemSecretText>;
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretKeyFormat: any;
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretKeyType: any;
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSecretsListResultItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsListResultItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsListResultItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsListResultItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsSecretsListResultItemSecretKey: S.Schema<DispatchNamespacesScriptsSecretsListResultItemSecretKey>;
export type DispatchNamespacesScriptsSecretsListResultItem = DispatchNamespacesScriptsSecretsListResultItemSecretText | DispatchNamespacesScriptsSecretsListResultItemSecretKey;
export declare const DispatchNamespacesScriptsSecretsListResultItem: any;
export type DispatchNamespacesScriptsSecretsListResultList = Array<DispatchNamespacesScriptsSecretsListResultItem>;
export declare const DispatchNamespacesScriptsSecretsListResultList: S.Schema<DispatchNamespacesScriptsSecretsListResultList>;
export interface ListDispatchNamespaceScriptSecretsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsSecretsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDispatchNamespaceScriptSecretsResponse: S.Schema<ListDispatchNamespaceScriptSecretsResponse>;
export interface ListDispatchNamespaceScriptTagsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const ListDispatchNamespaceScriptTagsRequest: S.Schema<ListDispatchNamespaceScriptTagsRequest>;
export type DispatchNamespacesScriptsTagsListResultList = Array<string>;
export declare const DispatchNamespacesScriptsTagsListResultList: S.Schema<DispatchNamespacesScriptsTagsListResultList>;
export interface ListDispatchNamespaceScriptTagsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsTagsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDispatchNamespaceScriptTagsResponse: S.Schema<ListDispatchNamespaceScriptTagsResponse>;
export interface PatchDispatchNamespaceScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const PatchDispatchNamespaceScriptSettingRequest: S.Schema<PatchDispatchNamespaceScriptSettingRequest>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAIType = "ai";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAIType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAIType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAI: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemAI>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchType = "ai_search";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearch: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearch>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespaceType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespaceType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespace: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespace>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngineType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngineType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngine: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngine>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssetsType = "assets";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssetsType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssetsType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssets: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssets>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowserType = "browser";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowserType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowserType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowser: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowser>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1Type = "d1";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1Type: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlobType = "data_blob";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlobType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlobType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlob: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlob>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceType: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsItem = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundParamsItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundWorker = DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundWorker: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker>;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: DispatchNamespacesScriptsBindingsGetResultItemDispatchNamespaceOutboundWorker | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutbound: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutbound>;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespaceOutbound | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespace: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespace>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespaceType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespace: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespace>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdriveType = "hyperdrive";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdriveType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdriveType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdrive: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdrive>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemInheritType = "inherit";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemInheritType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemInherit: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemInherit>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemImagesType = "images";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemImagesType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemImagesType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemImages: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemImages>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemJsonType = "json";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemJsonType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemJsonType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemJson: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemJson>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespaceType = "kv_namespace";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespaceType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespaceType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespace: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespace>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemMediaType = "media";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemMediaType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemMediaType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemMedia: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemMedia>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificateType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificateType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificate: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificate>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainTextType = "plain_text";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainTextType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainTextType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainText: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainText>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelinesType = "pipelines";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelinesType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelinesType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelines: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelines>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueueType = "queue";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueueType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueueType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueue: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueue>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitSimple = DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitSimple: S.Schema<DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitType = "ratelimit";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: DispatchNamespacesScriptsBindingsGetResultItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimitType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimit: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimit>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketType = "r2_bucket";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketType: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketJurisdiction: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2BucketJurisdiction | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2Bucket: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2Bucket>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretTextType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretTextType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretText: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretText>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailType = "send_email";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailType: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList>;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmail: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmail>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemServiceType = "service";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemServiceType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemService: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemService>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlobType = "text_blob";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlobType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlobType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlob: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlob>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorizeType = "vectorize";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorizeType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorizeType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorize: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorize>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadataType = "version_metadata";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadataType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadataType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadata: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadata>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecretType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecretType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecret: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecret>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagshipType = "flagship";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagshipType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagshipType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagship: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagship>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyFormat: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyType: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesList = Array<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKey: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKey>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflowType = "workflow";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflowType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflow: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflow>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModuleType = "wasm_module";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModuleType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModuleType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModule: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModule>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCServiceType = "vpc_service";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCServiceType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCServiceType;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCService: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCService>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkType = "vpc_network";
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkType: any;
export interface DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetwork: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetwork>;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsItem = DispatchNamespacesScriptsSettingsEditResponseBindingsItemAI | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearch | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAISearchNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAnalyticsEngine | DispatchNamespacesScriptsSettingsEditResponseBindingsItemAssets | DispatchNamespacesScriptsSettingsEditResponseBindingsItemBrowser | DispatchNamespacesScriptsSettingsEditResponseBindingsItemD1 | DispatchNamespacesScriptsSettingsEditResponseBindingsItemDataBlob | DispatchNamespacesScriptsSettingsEditResponseBindingsItemDispatchNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemDurableObjectNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemHyperdrive | DispatchNamespacesScriptsSettingsEditResponseBindingsItemInherit | DispatchNamespacesScriptsSettingsEditResponseBindingsItemImages | DispatchNamespacesScriptsSettingsEditResponseBindingsItemJson | DispatchNamespacesScriptsSettingsEditResponseBindingsItemKVNamespace | DispatchNamespacesScriptsSettingsEditResponseBindingsItemMedia | DispatchNamespacesScriptsSettingsEditResponseBindingsItemMTLSCertificate | DispatchNamespacesScriptsSettingsEditResponseBindingsItemPlainText | DispatchNamespacesScriptsSettingsEditResponseBindingsItemPipelines | DispatchNamespacesScriptsSettingsEditResponseBindingsItemQueue | DispatchNamespacesScriptsSettingsEditResponseBindingsItemRatelimit | DispatchNamespacesScriptsSettingsEditResponseBindingsItemR2Bucket | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretText | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSendEmail | DispatchNamespacesScriptsSettingsEditResponseBindingsItemService | DispatchNamespacesScriptsSettingsEditResponseBindingsItemTextBlob | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVectorize | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVersionMetadata | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretsStoreSecret | DispatchNamespacesScriptsSettingsEditResponseBindingsItemFlagship | DispatchNamespacesScriptsSettingsEditResponseBindingsItemSecretKey | DispatchNamespacesScriptsSettingsEditResponseBindingsItemWorkflow | DispatchNamespacesScriptsSettingsEditResponseBindingsItemWasmModule | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCService | DispatchNamespacesScriptsSettingsEditResponseBindingsItemVPCNetwork;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsItem: any;
export type DispatchNamespacesScriptsSettingsEditResponseBindingsList = Array<DispatchNamespacesScriptsSettingsEditResponseBindingsItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseBindingsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseBindingsList>;
export type DispatchNamespacesScriptsSettingsEditResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export declare const DispatchNamespacesScriptsSettingsEditResponseCacheOptions: S.Schema<DispatchNamespacesScriptsGetResponseScriptCacheOptions>;
export type DispatchNamespacesScriptsSettingsEditResponseCompatibilityFlagsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseCompatibilityFlagsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseCompatibilityFlagsList>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueType = "worker" | "durable-object";
export declare const DispatchNamespacesScriptsSettingsEditResponseExportsValueType: any;
export type DispatchNamespacesScriptsSettingsEditResponseExportsValueCache = DispatchNamespacesScriptsSettingsGetResponseExportsValueCache;
export declare const DispatchNamespacesScriptsSettingsEditResponseExportsValueCache: S.Schema<DispatchNamespacesScriptsSettingsGetResponseExportsValueCache>;
export interface DispatchNamespacesScriptsSettingsEditResponseExportsValue {
    /** The kind of export. */
    type: DispatchNamespacesScriptsSettingsEditResponseExportsValueType;
    /** Cache override for this entrypoint. It applies only to */
    cache?: DispatchNamespacesScriptsSettingsGetResponseExportsValueCache | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseExportsValue: S.Schema<DispatchNamespacesScriptsSettingsEditResponseExportsValue>;
export type DispatchNamespacesScriptsSettingsEditResponseExportsMap = {
    [key: string]: DispatchNamespacesScriptsSettingsEditResponseExportsValue | undefined;
};
export declare const DispatchNamespacesScriptsSettingsEditResponseExportsMap: S.Schema<DispatchNamespacesScriptsSettingsEditResponseExportsMap>;
export type DispatchNamespacesScriptsSettingsEditResponseLimits = DispatchNamespacesScriptsSettingsGetResponseLimits;
export declare const DispatchNamespacesScriptsSettingsEditResponseLimits: S.Schema<DispatchNamespacesScriptsSettingsGetResponseLimits>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList>;
export interface DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigration: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigration>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<DispatchNamespacesScriptsSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrations: S.Schema<DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrations>;
export type DispatchNamespacesScriptsSettingsEditResponseMigrations = DispatchNamespacesScriptsSettingsEditResponseMigrationsSingleStepMigration | DispatchNamespacesScriptsSettingsEditResponseMigrationsWorkersMultipleStepMigrations;
export declare const DispatchNamespacesScriptsSettingsEditResponseMigrations: any;
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityLogsDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseObservabilityLogsDestinationsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseObservabilityLogsDestinationsList>;
export interface DispatchNamespacesScriptsSettingsEditResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsEditResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseObservabilityLogs: S.Schema<DispatchNamespacesScriptsSettingsEditResponseObservabilityLogs>;
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesDestinationsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesDestinationsList>;
export type DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesPropagationPolicy: any;
export interface DispatchNamespacesScriptsSettingsEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: DispatchNamespacesScriptsSettingsEditResponseObservabilityTracesPropagationPolicy | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseObservabilityTraces: S.Schema<DispatchNamespacesScriptsSettingsEditResponseObservabilityTraces>;
export interface DispatchNamespacesScriptsSettingsEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsSettingsEditResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsSettingsEditResponseObservabilityTraces | null;
}
export declare const DispatchNamespacesScriptsSettingsEditResponseObservability: S.Schema<DispatchNamespacesScriptsSettingsEditResponseObservability>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementModeMode = "smart";
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementModeMode: any;
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementModeMode;
}
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementMode: S.Schema<DispatchNamespacesScriptsSettingsEditResponsePlacementMode>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementRegion = DispatchNamespacesScriptsSettingsGetResponsePlacementRegion;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementRegion: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementRegion>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementHost = DispatchNamespacesScriptsSettingsGetResponsePlacementHost;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementHost: S.Schema<DispatchNamespacesScriptsSettingsGetResponsePlacementHost>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase4Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase4Mode: any;
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase4: S.Schema<DispatchNamespacesScriptsSettingsEditResponsePlacementCase4>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase5Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase5Mode: any;
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase5Mode;
}
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase5: S.Schema<DispatchNamespacesScriptsSettingsEditResponsePlacementCase5>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase6Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase6Mode: any;
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase6Mode;
}
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase6: S.Schema<DispatchNamespacesScriptsSettingsEditResponsePlacementCase6>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7Mode = "targeted";
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7Mode: any;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemRegion: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItemHost: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItem: any;
export type DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetList: S.Schema<DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetList>;
export interface DispatchNamespacesScriptsSettingsEditResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsSettingsEditResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsSettingsEditResponsePlacementCase7TargetList;
}
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacementCase7: S.Schema<DispatchNamespacesScriptsSettingsEditResponsePlacementCase7>;
export type DispatchNamespacesScriptsSettingsEditResponsePlacement = DispatchNamespacesScriptsSettingsEditResponsePlacementMode | DispatchNamespacesScriptsSettingsGetResponsePlacementRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsSettingsGetResponsePlacementHost | DispatchNamespacesScriptsSettingsEditResponsePlacementCase4 | DispatchNamespacesScriptsSettingsEditResponsePlacementCase5 | DispatchNamespacesScriptsSettingsEditResponsePlacementCase6 | DispatchNamespacesScriptsSettingsEditResponsePlacementCase7;
export declare const DispatchNamespacesScriptsSettingsEditResponsePlacement: any;
export type DispatchNamespacesScriptsSettingsEditResponseTagsList = Array<string>;
export declare const DispatchNamespacesScriptsSettingsEditResponseTagsList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseTagsList>;
export type DispatchNamespacesScriptsSettingsEditResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export declare const DispatchNamespacesScriptsSettingsEditResponseTailConsumersItem: S.Schema<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsSettingsEditResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export declare const DispatchNamespacesScriptsSettingsEditResponseTailConsumersList: S.Schema<DispatchNamespacesScriptsSettingsEditResponseTailConsumersList>;
export type DispatchNamespacesScriptsSettingsEditResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const DispatchNamespacesScriptsSettingsEditResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDispatchNamespaceScriptSettingResponse {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: DispatchNamespacesScriptsSettingsEditResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsSettingsEditResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries */
    exports?: DispatchNamespacesScriptsSettingsEditResponseExportsMap | null;
    /** Limits to apply for this Worker. */
    limits?: DispatchNamespacesScriptsSettingsGetResponseLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: DispatchNamespacesScriptsSettingsEditResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsSettingsEditResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsSettingsEditResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsSettingsEditResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsSettingsEditResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsSettingsEditResponseUsageModel | null;
}
export declare const PatchDispatchNamespaceScriptSettingResponse: S.Schema<PatchDispatchNamespaceScriptSettingResponse>;
export type DispatchNamespacesScriptsUpdateRequestBindingsInherit = "strict";
export declare const DispatchNamespacesScriptsUpdateRequestBindingsInherit: any;
export type PutDispatchNamespaceScriptMetadataStringList = Array<string>;
export declare const PutDispatchNamespaceScriptMetadataStringList: S.Schema<PutDispatchNamespaceScriptMetadataStringList>;
/** JSON-encoded metadata about the uploaded parts and Worker configuration. See https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export interface PutDispatchNamespaceScriptMetadata {
    annotations?: unknown;
    assets?: unknown;
    bindings?: unknown;
    bodyPart?: string;
    cache?: unknown;
    compatibilityDate?: string;
    compatibilityFlags?: PutDispatchNamespaceScriptMetadataStringList;
    containers?: unknown;
    keepAssets?: boolean;
    keepBindings?: PutDispatchNamespaceScriptMetadataStringList;
    limits?: unknown;
    logpush?: boolean;
    mainModule?: string;
    migrations?: unknown;
    observability?: unknown;
    placement?: unknown;
    tags?: PutDispatchNamespaceScriptMetadataStringList;
    tailConsumers?: unknown;
    usageModel?: string;
}
export declare const PutDispatchNamespaceScriptMetadata: S.Schema<PutDispatchNamespaceScriptMetadata>;
export interface PutDispatchNamespaceScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** When set to "strict", the upload will fail if any `inherit` type bindings cannot be resolved against the previous version of the script. Without this, unresolvable inherit bindings are silently dropped. */
    bindingsInherit?: DispatchNamespacesScriptsUpdateRequestBindingsInherit | (string & {});
    metadata: PutDispatchNamespaceScriptMetadata;
    /** Module / asset file parts, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export declare const PutDispatchNamespaceScriptRequest: S.Schema<PutDispatchNamespaceScriptRequest>;
export type DispatchNamespacesScriptsUpdateResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export declare const DispatchNamespacesScriptsUpdateResponseCacheOptions: S.Schema<DispatchNamespacesScriptsGetResponseScriptCacheOptions>;
export type DispatchNamespacesScriptsUpdateResponseCompatibilityFlagsList = Array<string>;
export declare const DispatchNamespacesScriptsUpdateResponseCompatibilityFlagsList: S.Schema<DispatchNamespacesScriptsUpdateResponseCompatibilityFlagsList>;
export type DispatchNamespacesScriptsUpdateResponseHandlersList = Array<string>;
export declare const DispatchNamespacesScriptsUpdateResponseHandlersList: S.Schema<DispatchNamespacesScriptsUpdateResponseHandlersList>;
export type DispatchNamespacesScriptsUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export declare const DispatchNamespacesScriptsUpdateResponseNamedHandlersItemHandlersList: S.Schema<DispatchNamespacesScriptsUpdateResponseNamedHandlersItemHandlersList>;
export interface DispatchNamespacesScriptsUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: DispatchNamespacesScriptsUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export declare const DispatchNamespacesScriptsUpdateResponseNamedHandlersItem: S.Schema<DispatchNamespacesScriptsUpdateResponseNamedHandlersItem>;
export type DispatchNamespacesScriptsUpdateResponseNamedHandlersList = Array<DispatchNamespacesScriptsUpdateResponseNamedHandlersItem>;
export declare const DispatchNamespacesScriptsUpdateResponseNamedHandlersList: S.Schema<DispatchNamespacesScriptsUpdateResponseNamedHandlersList>;
export type DispatchNamespacesScriptsUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsUpdateResponseObservabilityLogsDestinationsList: S.Schema<DispatchNamespacesScriptsUpdateResponseObservabilityLogsDestinationsList>;
export interface DispatchNamespacesScriptsUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const DispatchNamespacesScriptsUpdateResponseObservabilityLogs: S.Schema<DispatchNamespacesScriptsUpdateResponseObservabilityLogs>;
export type DispatchNamespacesScriptsUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsUpdateResponseObservabilityTracesDestinationsList: S.Schema<DispatchNamespacesScriptsUpdateResponseObservabilityTracesDestinationsList>;
export type DispatchNamespacesScriptsUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const DispatchNamespacesScriptsUpdateResponseObservabilityTracesPropagationPolicy: any;
export interface DispatchNamespacesScriptsUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: DispatchNamespacesScriptsUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export declare const DispatchNamespacesScriptsUpdateResponseObservabilityTraces: S.Schema<DispatchNamespacesScriptsUpdateResponseObservabilityTraces>;
export interface DispatchNamespacesScriptsUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsUpdateResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsUpdateResponseObservabilityTraces | null;
}
export declare const DispatchNamespacesScriptsUpdateResponseObservability: S.Schema<DispatchNamespacesScriptsUpdateResponseObservability>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase0Mode = "smart";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase0Mode: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase0Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase0Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase0: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase0>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase1Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase1Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase1: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase1>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase2Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase2Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase2: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase2>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase3Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase3Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase3: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase3>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase4Mode = "targeted";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase4Mode: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase4Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase4Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase4: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase4>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase5Mode = "targeted";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase5Mode: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase5Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase5Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase5: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase5>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase6Mode = "targeted";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase6Mode: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase6Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase6Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase6: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase6>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7Mode = "targeted";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7Mode: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemRegion: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItemHost: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItem: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetItem>;
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetList: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetList>;
export type DispatchNamespacesScriptsUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7Status: any;
export interface DispatchNamespacesScriptsUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsUpdateResponsePlacementCase7Status | null;
}
export declare const DispatchNamespacesScriptsUpdateResponsePlacementCase7: S.Schema<DispatchNamespacesScriptsUpdateResponsePlacementCase7>;
export type DispatchNamespacesScriptsUpdateResponsePlacement = DispatchNamespacesScriptsUpdateResponsePlacementCase0 | DispatchNamespacesScriptsUpdateResponsePlacementCase1 | DispatchNamespacesScriptsUpdateResponsePlacementCase2 | DispatchNamespacesScriptsUpdateResponsePlacementCase3 | DispatchNamespacesScriptsUpdateResponsePlacementCase4 | DispatchNamespacesScriptsUpdateResponsePlacementCase5 | DispatchNamespacesScriptsUpdateResponsePlacementCase6 | DispatchNamespacesScriptsUpdateResponsePlacementCase7;
export declare const DispatchNamespacesScriptsUpdateResponsePlacement: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementMode = "smart" | "targeted";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementMode: any;
export type DispatchNamespacesScriptsUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsUpdateResponsePlacementStatus: any;
export type DispatchNamespacesScriptsUpdateResponseTagsList = Array<string>;
export declare const DispatchNamespacesScriptsUpdateResponseTagsList: S.Schema<DispatchNamespacesScriptsUpdateResponseTagsList>;
export type DispatchNamespacesScriptsUpdateResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export declare const DispatchNamespacesScriptsUpdateResponseTailConsumersItem: S.Schema<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsUpdateResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export declare const DispatchNamespacesScriptsUpdateResponseTailConsumersList: S.Schema<DispatchNamespacesScriptsUpdateResponseTailConsumersList>;
export type DispatchNamespacesScriptsUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const DispatchNamespacesScriptsUpdateResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutDispatchNamespaceScriptResponse {
    startupTimeMs: number;
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** The entry point for the script. */
    entryPoint?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: DispatchNamespacesScriptsUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: DispatchNamespacesScriptsUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsUpdateResponsePlacement | null;
    placementMode?: DispatchNamespacesScriptsUpdateResponsePlacementMode | null;
    placementStatus?: DispatchNamespacesScriptsUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsUpdateResponseUsageModel | null;
}
export declare const PutDispatchNamespaceScriptResponse: S.Schema<PutDispatchNamespaceScriptResponse>;
export interface PutDispatchNamespaceScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    cfworkerbodypart?: string;
    cfworkermainmodulepart?: string;
}
export declare const PutDispatchNamespaceScriptContentRequest: S.Schema<PutDispatchNamespaceScriptContentRequest>;
export type DispatchNamespacesScriptsContentUpdateResponseCacheOptions = DispatchNamespacesScriptsGetResponseScriptCacheOptions;
export declare const DispatchNamespacesScriptsContentUpdateResponseCacheOptions: S.Schema<DispatchNamespacesScriptsGetResponseScriptCacheOptions>;
export type DispatchNamespacesScriptsContentUpdateResponseCompatibilityFlagsList = Array<string>;
export declare const DispatchNamespacesScriptsContentUpdateResponseCompatibilityFlagsList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseCompatibilityFlagsList>;
export type DispatchNamespacesScriptsContentUpdateResponseHandlersList = Array<string>;
export declare const DispatchNamespacesScriptsContentUpdateResponseHandlersList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseHandlersList>;
export type DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export declare const DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItemHandlersList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItemHandlersList>;
export interface DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItem: S.Schema<DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItem>;
export type DispatchNamespacesScriptsContentUpdateResponseNamedHandlersList = Array<DispatchNamespacesScriptsContentUpdateResponseNamedHandlersItem>;
export declare const DispatchNamespacesScriptsContentUpdateResponseNamedHandlersList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseNamedHandlersList>;
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsContentUpdateResponseObservabilityLogsDestinationsList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseObservabilityLogsDestinationsList>;
export interface DispatchNamespacesScriptsContentUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: DispatchNamespacesScriptsContentUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponseObservabilityLogs: S.Schema<DispatchNamespacesScriptsContentUpdateResponseObservabilityLogs>;
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export declare const DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesDestinationsList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesDestinationsList>;
export type DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesPropagationPolicy: any;
export interface DispatchNamespacesScriptsContentUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: DispatchNamespacesScriptsContentUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponseObservabilityTraces: S.Schema<DispatchNamespacesScriptsContentUpdateResponseObservabilityTraces>;
export interface DispatchNamespacesScriptsContentUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: DispatchNamespacesScriptsContentUpdateResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: DispatchNamespacesScriptsContentUpdateResponseObservabilityTraces | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponseObservability: S.Schema<DispatchNamespacesScriptsContentUpdateResponseObservability>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Mode = "smart";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Mode: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase0Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase0: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase0>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase1Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase1Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase1: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase1>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase2Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase2Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase2: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase2>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase3Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase3Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase3: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase3>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Mode = "targeted";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Mode: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase4Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase4: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase4>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Mode = "targeted";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Mode: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase5Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase5: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase5>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Mode = "targeted";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Mode: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase6Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase6: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase6>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Mode = "targeted";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Mode: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemRegion = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion;
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemRegion: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemHostname = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname;
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemHostname: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemHost = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItemHost: S.Schema<DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItem = DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemRegion | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHostname | DispatchNamespacesScriptsGetResponseScriptPlacementCase7TargetItemHost;
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItem: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetList = Array<DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetItem>;
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetList: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetList>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Status: any;
export interface DispatchNamespacesScriptsContentUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: DispatchNamespacesScriptsContentUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: DispatchNamespacesScriptsContentUpdateResponsePlacementCase7Status | null;
}
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementCase7: S.Schema<DispatchNamespacesScriptsContentUpdateResponsePlacementCase7>;
export type DispatchNamespacesScriptsContentUpdateResponsePlacement = DispatchNamespacesScriptsContentUpdateResponsePlacementCase0 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase1 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase2 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase3 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase4 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase5 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase6 | DispatchNamespacesScriptsContentUpdateResponsePlacementCase7;
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacement: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementMode = "smart" | "targeted";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementMode: any;
export type DispatchNamespacesScriptsContentUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const DispatchNamespacesScriptsContentUpdateResponsePlacementStatus: any;
export type DispatchNamespacesScriptsContentUpdateResponseTagsList = Array<string>;
export declare const DispatchNamespacesScriptsContentUpdateResponseTagsList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseTagsList>;
export type DispatchNamespacesScriptsContentUpdateResponseTailConsumersItem = DispatchNamespacesScriptsGetResponseScriptTailConsumersItem;
export declare const DispatchNamespacesScriptsContentUpdateResponseTailConsumersItem: S.Schema<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export type DispatchNamespacesScriptsContentUpdateResponseTailConsumersList = Array<DispatchNamespacesScriptsGetResponseScriptTailConsumersItem>;
export declare const DispatchNamespacesScriptsContentUpdateResponseTailConsumersList: S.Schema<DispatchNamespacesScriptsContentUpdateResponseTailConsumersList>;
export type DispatchNamespacesScriptsContentUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const DispatchNamespacesScriptsContentUpdateResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutDispatchNamespaceScriptContentResponse {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: DispatchNamespacesScriptsGetResponseScriptCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: DispatchNamespacesScriptsContentUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: DispatchNamespacesScriptsContentUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: DispatchNamespacesScriptsContentUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: DispatchNamespacesScriptsContentUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: DispatchNamespacesScriptsContentUpdateResponsePlacement | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placementMode?: DispatchNamespacesScriptsContentUpdateResponsePlacementMode | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    placementStatus?: DispatchNamespacesScriptsContentUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: DispatchNamespacesScriptsContentUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: DispatchNamespacesScriptsContentUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: DispatchNamespacesScriptsContentUpdateResponseUsageModel | null;
}
export declare const PutDispatchNamespaceScriptContentResponse: S.Schema<PutDispatchNamespaceScriptContentResponse>;
export type DispatchNamespacesScriptsSecretsUpdateRequestType = "secret_text" | "secret_key";
export declare const DispatchNamespacesScriptsSecretsUpdateRequestType: any;
export type DispatchNamespacesScriptsSecretsUpdateRequestFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSecretsUpdateRequestFormat: any;
export type DispatchNamespacesScriptsSecretsUpdateRequestUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSecretsUpdateRequestUsagesItem: any;
export type DispatchNamespacesScriptsSecretsUpdateRequestUsagesList = Array<DispatchNamespacesScriptsSecretsUpdateRequestUsagesItem | (string & {})>;
export declare const DispatchNamespacesScriptsSecretsUpdateRequestUsagesList: S.Schema<DispatchNamespacesScriptsSecretsUpdateRequestUsagesList>;
export interface PutDispatchNamespaceScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text?: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsUpdateRequestType | (string & {});
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm?: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format?: DispatchNamespacesScriptsSecretsUpdateRequestFormat | (string & {});
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages?: DispatchNamespacesScriptsSecretsUpdateRequestUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export declare const PutDispatchNamespaceScriptSecretRequest: S.Schema<PutDispatchNamespaceScriptSecretRequest>;
export type DispatchNamespacesScriptsSecretsUpdateResultSecretTextType = "secret_text";
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretTextType: any;
export interface DispatchNamespacesScriptsSecretsUpdateResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsUpdateResultSecretTextType;
}
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretText: S.Schema<DispatchNamespacesScriptsSecretsUpdateResultSecretText>;
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretKeyFormat: any;
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyType = "secret_key";
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretKeyType: any;
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesItem: any;
export type DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesList = Array<DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesItem>;
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesList: S.Schema<DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesList>;
export interface DispatchNamespacesScriptsSecretsUpdateResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: DispatchNamespacesScriptsSecretsUpdateResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: DispatchNamespacesScriptsSecretsUpdateResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: DispatchNamespacesScriptsSecretsUpdateResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const DispatchNamespacesScriptsSecretsUpdateResultSecretKey: S.Schema<DispatchNamespacesScriptsSecretsUpdateResultSecretKey>;
export type DispatchNamespacesScriptsSecretsUpdateResult = DispatchNamespacesScriptsSecretsUpdateResultSecretText | DispatchNamespacesScriptsSecretsUpdateResultSecretKey;
export declare const DispatchNamespacesScriptsSecretsUpdateResult: any;
export type PutDispatchNamespaceScriptSecretResponse = DispatchNamespacesScriptsSecretsUpdateResult;
export declare const PutDispatchNamespaceScriptSecretResponse: S.Schema<PutDispatchNamespaceScriptSecretResponse>;
export type DispatchNamespacesScriptsTagsUpdateRequestBodyList = Array<string>;
export declare const DispatchNamespacesScriptsTagsUpdateRequestBodyList: S.Schema<DispatchNamespacesScriptsTagsUpdateRequestBodyList>;
export interface PutDispatchNamespaceScriptTagRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Workers for Platforms dispatch namespace. */
    dispatchNamespace: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Tags associated with the Worker. */
    body: DispatchNamespacesScriptsTagsUpdateRequestBodyList;
}
export declare const PutDispatchNamespaceScriptTagRequest: S.Schema<PutDispatchNamespaceScriptTagRequest>;
export type DispatchNamespacesScriptsTagsUpdateResultList = Array<string>;
export declare const DispatchNamespacesScriptsTagsUpdateResultList: S.Schema<DispatchNamespacesScriptsTagsUpdateResultList>;
export interface PutDispatchNamespaceScriptTagResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DispatchNamespacesScriptsTagsUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const PutDispatchNamespaceScriptTagResponse: S.Schema<PutDispatchNamespaceScriptTagResponse>;
export type BulkUpdateDispatchNamespaceScriptSecretsError = CloudflareOpError;
/** Create, update, or delete multiple secrets on a script in a single operation using JSON Merge Patch (RFC 7396). Usage: - To create or update a secret, set its value to a secret object. - To delete a secret, set its value to `null`. - Secrets not included in the request are left unchanged. */
export declare const bulkUpdateDispatchNamespaceScriptSecrets: API.OperationMethod<BulkUpdateDispatchNamespaceScriptSecretsRequest, BulkUpdateDispatchNamespaceScriptSecretsResponse, BulkUpdateDispatchNamespaceScriptSecretsError, CloudflareOpContext>;
export type CreateDispatchNamespaceError = DispatchNamespaceAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new Workers for Platforms namespace. */
export declare const createDispatchNamespace: API.OperationMethod<CreateDispatchNamespaceRequest, CreateDispatchNamespaceResponse, CreateDispatchNamespaceError, CloudflareOpContext>;
export type CreateDispatchNamespaceScriptAssetUploadError = CloudflareOpError;
/** Start uploading a collection of assets for use in a Worker version. To learn more about the direct uploads of assets, see https://developers.cloudflare.com/workers/static-assets/direct-upload/. */
export declare const createDispatchNamespaceScriptAssetUpload: API.OperationMethod<CreateDispatchNamespaceScriptAssetUploadRequest, CreateDispatchNamespaceScriptAssetUploadResponse, CreateDispatchNamespaceScriptAssetUploadError, CloudflareOpContext>;
export type DeleteDispatchNamespaceError = DispatchNamespaceNotFound | Forbidden | CloudflareOpError;
/** Delete a Workers for Platforms namespace. */
export declare const deleteDispatchNamespace: API.OperationMethod<DeleteDispatchNamespaceRequest, DeleteDispatchNamespaceResponse, DeleteDispatchNamespaceError, CloudflareOpContext>;
export type DeleteDispatchNamespaceScriptError = DispatchNamespaceScriptNotFound | DispatchNamespaceNotFound | Forbidden | CloudflareOpError;
/** Delete a worker from a Workers for Platforms namespace. This call has no response body on a successful delete. */
export declare const deleteDispatchNamespaceScript: API.OperationMethod<DeleteDispatchNamespaceScriptRequest, DeleteDispatchNamespaceScriptResponse, DeleteDispatchNamespaceScriptError, CloudflareOpContext>;
export type DeleteDispatchNamespaceScriptSecretError = CloudflareOpError;
/** Remove a secret from a script uploaded to a Workers for Platforms namespace. */
export declare const deleteDispatchNamespaceScriptSecret: API.OperationMethod<DeleteDispatchNamespaceScriptSecretRequest, DeleteDispatchNamespaceScriptSecretResponse, DeleteDispatchNamespaceScriptSecretError, CloudflareOpContext>;
export type DeleteDispatchNamespaceScriptTagError = CloudflareOpError;
/** Delete script tag for a script uploaded to a Workers for Platforms namespace. */
export declare const deleteDispatchNamespaceScriptTag: API.OperationMethod<DeleteDispatchNamespaceScriptTagRequest, DeleteDispatchNamespaceScriptTagResponse, DeleteDispatchNamespaceScriptTagError, CloudflareOpContext>;
export type GetDispatchNamespaceError = DispatchNamespaceNotFound | Forbidden | CloudflareOpError;
/** Get a Workers for Platforms namespace. */
export declare const getDispatchNamespace: API.OperationMethod<GetDispatchNamespaceRequest, GetDispatchNamespaceResponse, GetDispatchNamespaceError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptError = DispatchNamespaceNotFound | DispatchNamespaceScriptNotFound | Forbidden | CloudflareOpError;
/** Fetch information about a script uploaded to a Workers for Platforms namespace. */
export declare const getDispatchNamespaceScript: API.OperationMethod<GetDispatchNamespaceScriptRequest, GetDispatchNamespaceScriptResponse, GetDispatchNamespaceScriptError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptBindingError = CloudflareOpError;
/** Fetch script bindings from a script uploaded to a Workers for Platforms namespace. */
export declare const getDispatchNamespaceScriptBinding: API.PaginatedOperationMethod<GetDispatchNamespaceScriptBindingRequest, GetDispatchNamespaceScriptBindingResponse, GetDispatchNamespaceScriptBindingError, CloudflareOpContext, DispatchNamespacesScriptsBindingsGetResultItem>;
export type GetDispatchNamespaceScriptContentError = CloudflareOpError;
/** Fetch script content from a script uploaded to a Workers for Platforms namespace. */
export declare const getDispatchNamespaceScriptContent: API.OperationMethod<GetDispatchNamespaceScriptContentRequest, GetDispatchNamespaceScriptContentResponse, GetDispatchNamespaceScriptContentError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptSecretError = CloudflareOpError;
/** Get a given secret binding (value omitted) on a script uploaded to a Workers for Platforms namespace. */
export declare const getDispatchNamespaceScriptSecret: API.OperationMethod<GetDispatchNamespaceScriptSecretRequest, GetDispatchNamespaceScriptSecretResponse, GetDispatchNamespaceScriptSecretError, CloudflareOpContext>;
export type GetDispatchNamespaceScriptSettingError = DispatchNamespaceNotFound | DispatchNamespaceScriptNotFound | Forbidden | CloudflareOpError;
/** Get script settings from a script uploaded to a Workers for Platforms namespace. */
export declare const getDispatchNamespaceScriptSetting: API.OperationMethod<GetDispatchNamespaceScriptSettingRequest, GetDispatchNamespaceScriptSettingResponse, GetDispatchNamespaceScriptSettingError, CloudflareOpContext>;
export type ListDispatchNamespacesError = CloudflareOpError;
/** Fetch a list of Workers for Platforms namespaces. */
export declare const listDispatchNamespaces: API.PaginatedOperationMethod<ListDispatchNamespacesRequest, ListDispatchNamespacesResponse, ListDispatchNamespacesError, CloudflareOpContext, DispatchNamespacesListResultItem>;
export type ListDispatchNamespaceScriptSecretsError = CloudflareOpError;
/** List secrets bound to a script uploaded to a Workers for Platforms namespace. */
export declare const listDispatchNamespaceScriptSecrets: API.PaginatedOperationMethod<ListDispatchNamespaceScriptSecretsRequest, ListDispatchNamespaceScriptSecretsResponse, ListDispatchNamespaceScriptSecretsError, CloudflareOpContext, DispatchNamespacesScriptsSecretsListResultItem>;
export type ListDispatchNamespaceScriptTagsError = CloudflareOpError;
/** Fetch tags from a script uploaded to a Workers for Platforms namespace. */
export declare const listDispatchNamespaceScriptTags: API.PaginatedOperationMethod<ListDispatchNamespaceScriptTagsRequest, ListDispatchNamespaceScriptTagsResponse, ListDispatchNamespaceScriptTagsError, CloudflareOpContext, string>;
export type PatchDispatchNamespaceScriptSettingError = CloudflareOpError;
/** Patch script metadata, such as bindings. */
export declare const patchDispatchNamespaceScriptSetting: API.OperationMethod<PatchDispatchNamespaceScriptSettingRequest, PatchDispatchNamespaceScriptSettingResponse, PatchDispatchNamespaceScriptSettingError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptError = DispatchNamespaceNotFound | Forbidden | SecretsStoreBindingNotFound | KVNamespaceNotFound | R2BucketNotFound | D1DatabaseNotFound | QueueNotFound | ServiceBindingNotFound | DurableObjectClassNotFound | HyperdriveConfigNotFound | VectorizeIndexNotFound | MtlsCertificateNotFound | CloudflareOpError;
/** Upload a worker module to a Workers for Platforms namespace. You can find more about the multipart metadata on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export declare const putDispatchNamespaceScript: API.OperationMethod<PutDispatchNamespaceScriptRequest, PutDispatchNamespaceScriptResponse, PutDispatchNamespaceScriptError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptContentError = CloudflareOpError;
/** Put script content for a script uploaded to a Workers for Platforms namespace. */
export declare const putDispatchNamespaceScriptContent: API.OperationMethod<PutDispatchNamespaceScriptContentRequest, PutDispatchNamespaceScriptContentResponse, PutDispatchNamespaceScriptContentError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptSecretError = CloudflareOpError;
/** Add a secret to a script uploaded to a Workers for Platforms namespace. */
export declare const putDispatchNamespaceScriptSecret: API.OperationMethod<PutDispatchNamespaceScriptSecretRequest, PutDispatchNamespaceScriptSecretResponse, PutDispatchNamespaceScriptSecretError, CloudflareOpContext>;
export type PutDispatchNamespaceScriptTagError = CloudflareOpError;
/** Put script tags for a script uploaded to a Workers for Platforms namespace. */
export declare const putDispatchNamespaceScriptTag: API.PaginatedOperationMethod<PutDispatchNamespaceScriptTagRequest, PutDispatchNamespaceScriptTagResponse, PutDispatchNamespaceScriptTagError, CloudflareOpContext, string>;
//# sourceMappingURL=workers_for_platforms.d.ts.map