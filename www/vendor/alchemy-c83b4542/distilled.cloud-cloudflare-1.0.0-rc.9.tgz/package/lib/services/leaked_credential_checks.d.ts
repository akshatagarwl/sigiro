import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DetectionNotFound_base: S.Class<DetectionNotFound, S.TaggedStruct<"DetectionNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DetectionNotFound extends /*@__PURE__*/ DetectionNotFound_base {
}
declare const DetectionQuotaExceeded_base: S.Class<DetectionQuotaExceeded, S.TaggedStruct<"DetectionQuotaExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DetectionQuotaExceeded extends /*@__PURE__*/ DetectionQuotaExceeded_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LeakedCredentialChecksDisabled_base: S.Class<LeakedCredentialChecksDisabled, S.TaggedStruct<"LeakedCredentialChecksDisabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LeakedCredentialChecksDisabled extends /*@__PURE__*/ LeakedCredentialChecksDisabled_base {
}
export interface CreateDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string;
}
export declare const CreateDetectionRequest: S.Schema<CreateDetectionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDetectionResponse {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export declare const CreateDetectionResponse: S.Schema<CreateDetectionResponse>;
export interface CreateLeakedCredentialCheckRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Determines whether or not Leaked Credential Checks are enabled. */
    enabled?: boolean;
}
export declare const CreateLeakedCredentialCheckRequest: S.Schema<CreateLeakedCredentialCheckRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLeakedCredentialCheckResponse {
    /** Determines whether or not Leaked Credential Checks are enabled. */
    enabled?: boolean | null;
}
export declare const CreateLeakedCredentialCheckResponse: S.Schema<CreateLeakedCredentialCheckResponse>;
export interface DeleteDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this custom detection. */
    detectionId: string;
}
export declare const DeleteDetectionRequest: S.Schema<DeleteDetectionRequest>;
export type DeleteDetectionResponse = unknown;
export declare const DeleteDetectionResponse: S.Schema<DeleteDetectionResponse>;
export interface GetDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this custom detection. */
    detectionId: string;
}
export declare const GetDetectionRequest: S.Schema<GetDetectionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDetectionResponse {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export declare const GetDetectionResponse: S.Schema<GetDetectionResponse>;
export interface GetLeakedCredentialCheckRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const GetLeakedCredentialCheckRequest: S.Schema<GetLeakedCredentialCheckRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLeakedCredentialCheckResponse {
    /** Determines whether or not Leaked Credential Checks are enabled. */
    enabled?: boolean | null;
}
export declare const GetLeakedCredentialCheckResponse: S.Schema<GetLeakedCredentialCheckResponse>;
export interface ListDetectionsRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const ListDetectionsRequest: S.Schema<ListDetectionsRequest>;
export interface DetectionsListResultItem {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export declare const DetectionsListResultItem: S.Schema<DetectionsListResultItem>;
export type DetectionsListResultList = Array<DetectionsListResultItem>;
export declare const DetectionsListResultList: S.Schema<DetectionsListResultList>;
export interface ListDetectionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DetectionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDetectionsResponse: S.Schema<ListDetectionsResponse>;
export interface UpdateDetectionRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique ID for this custom detection. */
    detectionId: string;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string;
}
export declare const UpdateDetectionRequest: S.Schema<UpdateDetectionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDetectionResponse {
    /** Defines the unique ID for this custom detection. */
    id?: string | null;
    /** Defines ehe ruleset expression to use in matching the password in a request. */
    password?: string | null;
    /** Defines the ruleset expression to use in matching the username in a request. */
    username?: string | null;
}
export declare const UpdateDetectionResponse: S.Schema<UpdateDetectionResponse>;
export type CreateDetectionError = DetectionQuotaExceeded | LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** Create user-defined detection pattern for Leaked Credential Checks. */
export declare const createDetection: API.OperationMethod<CreateDetectionRequest, CreateDetectionResponse, CreateDetectionError, CloudflareOpContext>;
export type CreateLeakedCredentialCheckError = Forbidden | CloudflareOpError;
/** Updates the current status of Leaked Credential Checks. */
export declare const createLeakedCredentialCheck: API.OperationMethod<CreateLeakedCredentialCheckRequest, CreateLeakedCredentialCheckResponse, CreateLeakedCredentialCheckError, CloudflareOpContext>;
export type DeleteDetectionError = DetectionNotFound | LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** Remove user-defined detection pattern for Leaked Credential Checks. */
export declare const deleteDetection: API.OperationMethod<DeleteDetectionRequest, DeleteDetectionResponse, DeleteDetectionError, CloudflareOpContext>;
export type GetDetectionError = DetectionNotFound | LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** Get user-defined detection pattern for Leaked Credential Checks. */
export declare const getDetection: API.OperationMethod<GetDetectionRequest, GetDetectionResponse, GetDetectionError, CloudflareOpContext>;
export type GetLeakedCredentialCheckError = Forbidden | CloudflareOpError;
/** Retrieves the current status of Leaked Credential Checks. */
export declare const getLeakedCredentialCheck: API.OperationMethod<GetLeakedCredentialCheckRequest, GetLeakedCredentialCheckResponse, GetLeakedCredentialCheckError, CloudflareOpContext>;
export type ListDetectionsError = LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** List user-defined detection patterns for Leaked Credential Checks. */
export declare const listDetections: API.PaginatedOperationMethod<ListDetectionsRequest, ListDetectionsResponse, ListDetectionsError, CloudflareOpContext, DetectionsListResultItem>;
export type UpdateDetectionError = DetectionNotFound | LeakedCredentialChecksDisabled | Forbidden | CloudflareOpError;
/** Update user-defined detection pattern for Leaked Credential Checks. */
export declare const updateDetection: API.OperationMethod<UpdateDetectionRequest, UpdateDetectionResponse, UpdateDetectionError, CloudflareOpContext>;
//# sourceMappingURL=leaked_credential_checks.d.ts.map