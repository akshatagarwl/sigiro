import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TokenConfigurationNotFound_base: S.Class<TokenConfigurationNotFound, S.TaggedStruct<"TokenConfigurationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenConfigurationNotFound extends /*@__PURE__*/ TokenConfigurationNotFound_base {
}
declare const TokenValidationNotEntitled_base: S.Class<TokenValidationNotEntitled, S.TaggedStruct<"TokenValidationNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenValidationNotEntitled extends /*@__PURE__*/ TokenValidationNotEntitled_base {
}
declare const TokenValidationRuleNotFound_base: S.Class<TokenValidationRuleNotFound, S.TaggedStruct<"TokenValidationRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenValidationRuleNotFound extends /*@__PURE__*/ TokenValidationRuleNotFound_base {
}
export type RulesBulkCreateRequestBodyItemAction = "log" | "block";
export declare const RulesBulkCreateRequestBodyItemAction: any;
export type RulesBulkCreateRequestBodyItemSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesBulkCreateRequestBodyItemSelectorExcludeItemOperationIdsList: S.Schema<RulesBulkCreateRequestBodyItemSelectorExcludeItemOperationIdsList>;
export interface RulesBulkCreateRequestBodyItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkCreateRequestBodyItemSelectorExcludeItemOperationIdsList;
}
export declare const RulesBulkCreateRequestBodyItemSelectorExcludeItem: S.Schema<RulesBulkCreateRequestBodyItemSelectorExcludeItem>;
export type RulesBulkCreateRequestBodyItemSelectorExcludeList = Array<RulesBulkCreateRequestBodyItemSelectorExcludeItem>;
export declare const RulesBulkCreateRequestBodyItemSelectorExcludeList: S.Schema<RulesBulkCreateRequestBodyItemSelectorExcludeList>;
export type RulesBulkCreateRequestBodyItemSelectorIncludeItemHostList = Array<string>;
export declare const RulesBulkCreateRequestBodyItemSelectorIncludeItemHostList: S.Schema<RulesBulkCreateRequestBodyItemSelectorIncludeItemHostList>;
export interface RulesBulkCreateRequestBodyItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkCreateRequestBodyItemSelectorIncludeItemHostList;
}
export declare const RulesBulkCreateRequestBodyItemSelectorIncludeItem: S.Schema<RulesBulkCreateRequestBodyItemSelectorIncludeItem>;
export type RulesBulkCreateRequestBodyItemSelectorIncludeList = Array<RulesBulkCreateRequestBodyItemSelectorIncludeItem>;
export declare const RulesBulkCreateRequestBodyItemSelectorIncludeList: S.Schema<RulesBulkCreateRequestBodyItemSelectorIncludeList>;
export interface RulesBulkCreateRequestBodyItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkCreateRequestBodyItemSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesBulkCreateRequestBodyItemSelectorIncludeList;
}
export declare const RulesBulkCreateRequestBodyItemSelector: S.Schema<RulesBulkCreateRequestBodyItemSelector>;
export interface RulesBulkCreateRequestBodyItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesBulkCreateRequestBodyItemAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesBulkCreateRequestBodyItemSelector;
    /** A human-readable name for the rule. */
    title: string;
}
export declare const RulesBulkCreateRequestBodyItem: S.Schema<RulesBulkCreateRequestBodyItem>;
export type RulesBulkCreateRequestBodyList = Array<RulesBulkCreateRequestBodyItem>;
export declare const RulesBulkCreateRequestBodyList: S.Schema<RulesBulkCreateRequestBodyList>;
export interface BulkCreateRulesRequest {
    /** Identifier. */
    zoneId: string;
    body: RulesBulkCreateRequestBodyList;
}
export declare const BulkCreateRulesRequest: S.Schema<BulkCreateRulesRequest>;
export type RulesBulkCreateResultItemAction = "log" | "block";
export declare const RulesBulkCreateResultItemAction: any;
export type RulesBulkCreateResultItemSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesBulkCreateResultItemSelectorExcludeItemOperationIdsList: S.Schema<RulesBulkCreateResultItemSelectorExcludeItemOperationIdsList>;
export interface RulesBulkCreateResultItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkCreateResultItemSelectorExcludeItemOperationIdsList | null;
}
export declare const RulesBulkCreateResultItemSelectorExcludeItem: S.Schema<RulesBulkCreateResultItemSelectorExcludeItem>;
export type RulesBulkCreateResultItemSelectorExcludeList = Array<RulesBulkCreateResultItemSelectorExcludeItem>;
export declare const RulesBulkCreateResultItemSelectorExcludeList: S.Schema<RulesBulkCreateResultItemSelectorExcludeList>;
export type RulesBulkCreateResultItemSelectorIncludeItemHostList = Array<string>;
export declare const RulesBulkCreateResultItemSelectorIncludeItemHostList: S.Schema<RulesBulkCreateResultItemSelectorIncludeItemHostList>;
export interface RulesBulkCreateResultItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkCreateResultItemSelectorIncludeItemHostList | null;
}
export declare const RulesBulkCreateResultItemSelectorIncludeItem: S.Schema<RulesBulkCreateResultItemSelectorIncludeItem>;
export type RulesBulkCreateResultItemSelectorIncludeList = Array<RulesBulkCreateResultItemSelectorIncludeItem>;
export declare const RulesBulkCreateResultItemSelectorIncludeList: S.Schema<RulesBulkCreateResultItemSelectorIncludeList>;
export interface RulesBulkCreateResultItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkCreateResultItemSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesBulkCreateResultItemSelectorIncludeList | null;
}
export declare const RulesBulkCreateResultItemSelector: S.Schema<RulesBulkCreateResultItemSelector>;
export interface RulesBulkCreateResultItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesBulkCreateResultItemAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesBulkCreateResultItemSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export declare const RulesBulkCreateResultItem: S.Schema<RulesBulkCreateResultItem>;
export type RulesBulkCreateResultList = Array<RulesBulkCreateResultItem>;
export declare const RulesBulkCreateResultList: S.Schema<RulesBulkCreateResultList>;
export interface BulkCreateRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkCreateRulesResponse: S.Schema<BulkCreateRulesResponse>;
export type RulesBulkEditRequestBodyItemAction = "log" | "block";
export declare const RulesBulkEditRequestBodyItemAction: any;
export interface RulesBulkEditRequestBodyItemPositionAPIShieldIndex {
    /** Move rule to this position */
    index: number;
}
export declare const RulesBulkEditRequestBodyItemPositionAPIShieldIndex: S.Schema<RulesBulkEditRequestBodyItemPositionAPIShieldIndex>;
export interface RulesBulkEditRequestBodyItemPositionAPIShieldBefore {
    /** Move rule to before rule with this ID. */
    before?: string;
}
export declare const RulesBulkEditRequestBodyItemPositionAPIShieldBefore: S.Schema<RulesBulkEditRequestBodyItemPositionAPIShieldBefore>;
export interface RulesBulkEditRequestBodyItemPositionAPIShieldAfter {
    /** Move rule to after rule with this ID. */
    after?: string;
}
export declare const RulesBulkEditRequestBodyItemPositionAPIShieldAfter: S.Schema<RulesBulkEditRequestBodyItemPositionAPIShieldAfter>;
export type RulesBulkEditRequestBodyItemPosition = RulesBulkEditRequestBodyItemPositionAPIShieldIndex | RulesBulkEditRequestBodyItemPositionAPIShieldBefore | RulesBulkEditRequestBodyItemPositionAPIShieldAfter;
export declare const RulesBulkEditRequestBodyItemPosition: any;
export type RulesBulkEditRequestBodyItemSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesBulkEditRequestBodyItemSelectorExcludeItemOperationIdsList: S.Schema<RulesBulkEditRequestBodyItemSelectorExcludeItemOperationIdsList>;
export interface RulesBulkEditRequestBodyItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkEditRequestBodyItemSelectorExcludeItemOperationIdsList;
}
export declare const RulesBulkEditRequestBodyItemSelectorExcludeItem: S.Schema<RulesBulkEditRequestBodyItemSelectorExcludeItem>;
export type RulesBulkEditRequestBodyItemSelectorExcludeList = Array<RulesBulkEditRequestBodyItemSelectorExcludeItem>;
export declare const RulesBulkEditRequestBodyItemSelectorExcludeList: S.Schema<RulesBulkEditRequestBodyItemSelectorExcludeList>;
export type RulesBulkEditRequestBodyItemSelectorIncludeItemHostList = Array<string>;
export declare const RulesBulkEditRequestBodyItemSelectorIncludeItemHostList: S.Schema<RulesBulkEditRequestBodyItemSelectorIncludeItemHostList>;
export interface RulesBulkEditRequestBodyItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkEditRequestBodyItemSelectorIncludeItemHostList;
}
export declare const RulesBulkEditRequestBodyItemSelectorIncludeItem: S.Schema<RulesBulkEditRequestBodyItemSelectorIncludeItem>;
export type RulesBulkEditRequestBodyItemSelectorIncludeList = Array<RulesBulkEditRequestBodyItemSelectorIncludeItem>;
export declare const RulesBulkEditRequestBodyItemSelectorIncludeList: S.Schema<RulesBulkEditRequestBodyItemSelectorIncludeList>;
export interface RulesBulkEditRequestBodyItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkEditRequestBodyItemSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesBulkEditRequestBodyItemSelectorIncludeList;
}
export declare const RulesBulkEditRequestBodyItemSelector: S.Schema<RulesBulkEditRequestBodyItemSelector>;
export interface RulesBulkEditRequestBodyItem {
    /** Rule ID this patch applies to */
    id: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action?: RulesBulkEditRequestBodyItemAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description?: string;
    /** Toggle rule on or off. */
    enabled?: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression?: string;
    /** Update rule order among zone rules. */
    position?: RulesBulkEditRequestBodyItemPosition;
    /** Select operations covered by this rule. */
    selector?: RulesBulkEditRequestBodyItemSelector;
    /** A human-readable name for the rule. */
    title?: string;
}
export declare const RulesBulkEditRequestBodyItem: S.Schema<RulesBulkEditRequestBodyItem>;
export type RulesBulkEditRequestBodyList = Array<RulesBulkEditRequestBodyItem>;
export declare const RulesBulkEditRequestBodyList: S.Schema<RulesBulkEditRequestBodyList>;
export interface BulkPatchRulesRequest {
    /** Identifier. */
    zoneId: string;
    body: RulesBulkEditRequestBodyList;
}
export declare const BulkPatchRulesRequest: S.Schema<BulkPatchRulesRequest>;
export type RulesBulkEditResultItemAction = "log" | "block";
export declare const RulesBulkEditResultItemAction: any;
export type RulesBulkEditResultItemSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesBulkEditResultItemSelectorExcludeItemOperationIdsList: S.Schema<RulesBulkEditResultItemSelectorExcludeItemOperationIdsList>;
export interface RulesBulkEditResultItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesBulkEditResultItemSelectorExcludeItemOperationIdsList | null;
}
export declare const RulesBulkEditResultItemSelectorExcludeItem: S.Schema<RulesBulkEditResultItemSelectorExcludeItem>;
export type RulesBulkEditResultItemSelectorExcludeList = Array<RulesBulkEditResultItemSelectorExcludeItem>;
export declare const RulesBulkEditResultItemSelectorExcludeList: S.Schema<RulesBulkEditResultItemSelectorExcludeList>;
export type RulesBulkEditResultItemSelectorIncludeItemHostList = Array<string>;
export declare const RulesBulkEditResultItemSelectorIncludeItemHostList: S.Schema<RulesBulkEditResultItemSelectorIncludeItemHostList>;
export interface RulesBulkEditResultItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesBulkEditResultItemSelectorIncludeItemHostList | null;
}
export declare const RulesBulkEditResultItemSelectorIncludeItem: S.Schema<RulesBulkEditResultItemSelectorIncludeItem>;
export type RulesBulkEditResultItemSelectorIncludeList = Array<RulesBulkEditResultItemSelectorIncludeItem>;
export declare const RulesBulkEditResultItemSelectorIncludeList: S.Schema<RulesBulkEditResultItemSelectorIncludeList>;
export interface RulesBulkEditResultItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesBulkEditResultItemSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesBulkEditResultItemSelectorIncludeList | null;
}
export declare const RulesBulkEditResultItemSelector: S.Schema<RulesBulkEditResultItemSelector>;
export interface RulesBulkEditResultItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesBulkEditResultItemAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesBulkEditResultItemSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export declare const RulesBulkEditResultItem: S.Schema<RulesBulkEditResultItem>;
export type RulesBulkEditResultList = Array<RulesBulkEditResultItem>;
export declare const RulesBulkEditResultList: S.Schema<RulesBulkEditResultList>;
export interface BulkPatchRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkPatchRulesResponse: S.Schema<BulkPatchRulesResponse>;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg: any;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty: any;
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg | (string & {});
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA: S.Schema<ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA>;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg: any;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv: any;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty: any;
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256: S.Schema<ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256>;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg: any;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv: any;
export type ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty: any;
export interface ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384: S.Schema<ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384>;
export type ConfigurationCreateRequestCredentialsKeysItem = ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCreateRequestCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384;
export declare const ConfigurationCreateRequestCredentialsKeysItem: any;
export type ConfigurationCreateRequestCredentialsKeysList = Array<ConfigurationCreateRequestCredentialsKeysItem>;
export declare const ConfigurationCreateRequestCredentialsKeysList: S.Schema<ConfigurationCreateRequestCredentialsKeysList>;
export interface ConfigurationCreateRequestCredentials {
    keys: ConfigurationCreateRequestCredentialsKeysList;
}
export declare const ConfigurationCreateRequestCredentials: S.Schema<ConfigurationCreateRequestCredentials>;
export type ConfigurationCreateRequestTokenSourcesList = Array<string>;
export declare const ConfigurationCreateRequestTokenSourcesList: S.Schema<ConfigurationCreateRequestTokenSourcesList>;
export type ConfigurationCreateRequestTokenType = "JWT";
export declare const ConfigurationCreateRequestTokenType: any;
export interface CreateConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    credentials: ConfigurationCreateRequestCredentials;
    description: string;
    title: string;
    tokenSources: ConfigurationCreateRequestTokenSourcesList;
    tokenType: ConfigurationCreateRequestTokenType | (string & {});
}
export declare const CreateConfigurationRequest: S.Schema<CreateConfigurationRequest>;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg: any;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty: any;
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA: S.Schema<ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA>;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg: any;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv: any;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty: any;
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256: S.Schema<ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256>;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg: any;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv: any;
export type ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty: any;
export interface ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384: S.Schema<ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384>;
export type ConfigurationCreateResponseCredentialsKeysItem = ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCreateResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384;
export declare const ConfigurationCreateResponseCredentialsKeysItem: any;
export type ConfigurationCreateResponseCredentialsKeysList = Array<ConfigurationCreateResponseCredentialsKeysItem>;
export declare const ConfigurationCreateResponseCredentialsKeysList: S.Schema<ConfigurationCreateResponseCredentialsKeysList>;
export interface ConfigurationCreateResponseCredentials {
    keys: ConfigurationCreateResponseCredentialsKeysList;
}
export declare const ConfigurationCreateResponseCredentials: S.Schema<ConfigurationCreateResponseCredentials>;
export type ConfigurationCreateResponseTokenSourcesList = Array<string>;
export declare const ConfigurationCreateResponseTokenSourcesList: S.Schema<ConfigurationCreateResponseTokenSourcesList>;
export type ConfigurationCreateResponseTokenType = "JWT";
export declare const ConfigurationCreateResponseTokenType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConfigurationResponse {
    /** UUID. */
    id: string;
    createdAt: string;
    credentials: ConfigurationCreateResponseCredentials;
    description: string;
    lastUpdated: string;
    title: string;
    tokenSources: ConfigurationCreateResponseTokenSourcesList;
    tokenType: ConfigurationCreateResponseTokenType;
}
export declare const CreateConfigurationResponse: S.Schema<CreateConfigurationResponse>;
export type RulesCreateRequestAction = "log" | "block";
export declare const RulesCreateRequestAction: any;
export type RulesCreateRequestSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesCreateRequestSelectorExcludeItemOperationIdsList: S.Schema<RulesCreateRequestSelectorExcludeItemOperationIdsList>;
export interface RulesCreateRequestSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesCreateRequestSelectorExcludeItemOperationIdsList;
}
export declare const RulesCreateRequestSelectorExcludeItem: S.Schema<RulesCreateRequestSelectorExcludeItem>;
export type RulesCreateRequestSelectorExcludeList = Array<RulesCreateRequestSelectorExcludeItem>;
export declare const RulesCreateRequestSelectorExcludeList: S.Schema<RulesCreateRequestSelectorExcludeList>;
export type RulesCreateRequestSelectorIncludeItemHostList = Array<string>;
export declare const RulesCreateRequestSelectorIncludeItemHostList: S.Schema<RulesCreateRequestSelectorIncludeItemHostList>;
export interface RulesCreateRequestSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesCreateRequestSelectorIncludeItemHostList;
}
export declare const RulesCreateRequestSelectorIncludeItem: S.Schema<RulesCreateRequestSelectorIncludeItem>;
export type RulesCreateRequestSelectorIncludeList = Array<RulesCreateRequestSelectorIncludeItem>;
export declare const RulesCreateRequestSelectorIncludeList: S.Schema<RulesCreateRequestSelectorIncludeList>;
export interface RulesCreateRequestSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesCreateRequestSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesCreateRequestSelectorIncludeList;
}
export declare const RulesCreateRequestSelector: S.Schema<RulesCreateRequestSelector>;
export interface CreateRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesCreateRequestAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesCreateRequestSelector;
    /** A human-readable name for the rule. */
    title: string;
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export type RulesCreateResponseAction = "log" | "block";
export declare const RulesCreateResponseAction: any;
export type RulesCreateResponseSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesCreateResponseSelectorExcludeItemOperationIdsList: S.Schema<RulesCreateResponseSelectorExcludeItemOperationIdsList>;
export interface RulesCreateResponseSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesCreateResponseSelectorExcludeItemOperationIdsList | null;
}
export declare const RulesCreateResponseSelectorExcludeItem: S.Schema<RulesCreateResponseSelectorExcludeItem>;
export type RulesCreateResponseSelectorExcludeList = Array<RulesCreateResponseSelectorExcludeItem>;
export declare const RulesCreateResponseSelectorExcludeList: S.Schema<RulesCreateResponseSelectorExcludeList>;
export type RulesCreateResponseSelectorIncludeItemHostList = Array<string>;
export declare const RulesCreateResponseSelectorIncludeItemHostList: S.Schema<RulesCreateResponseSelectorIncludeItemHostList>;
export interface RulesCreateResponseSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesCreateResponseSelectorIncludeItemHostList | null;
}
export declare const RulesCreateResponseSelectorIncludeItem: S.Schema<RulesCreateResponseSelectorIncludeItem>;
export type RulesCreateResponseSelectorIncludeList = Array<RulesCreateResponseSelectorIncludeItem>;
export declare const RulesCreateResponseSelectorIncludeList: S.Schema<RulesCreateResponseSelectorIncludeList>;
export interface RulesCreateResponseSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesCreateResponseSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesCreateResponseSelectorIncludeList | null;
}
export declare const RulesCreateResponseSelector: S.Schema<RulesCreateResponseSelector>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesCreateResponseAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesCreateResponseSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export declare const CreateRuleResponse: S.Schema<CreateRuleResponse>;
export interface DeleteConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
}
export declare const DeleteConfigurationRequest: S.Schema<DeleteConfigurationRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConfigurationResponse {
    /** UUID. */
    id?: string | null;
}
export declare const DeleteConfigurationResponse: S.Schema<DeleteConfigurationResponse>;
export interface DeleteRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    ruleId: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export type DeleteRuleResponse = unknown;
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface GetConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
}
export declare const GetConfigurationRequest: S.Schema<GetConfigurationRequest>;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg: any;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty: any;
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA: S.Schema<ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA>;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg: any;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv: any;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty: any;
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256: S.Schema<ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256>;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg: any;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv: any;
export type ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty: any;
export interface ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384: S.Schema<ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384>;
export type ConfigurationGetResponseCredentialsKeysItem = ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationGetResponseCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384;
export declare const ConfigurationGetResponseCredentialsKeysItem: any;
export type ConfigurationGetResponseCredentialsKeysList = Array<ConfigurationGetResponseCredentialsKeysItem>;
export declare const ConfigurationGetResponseCredentialsKeysList: S.Schema<ConfigurationGetResponseCredentialsKeysList>;
export interface ConfigurationGetResponseCredentials {
    keys: ConfigurationGetResponseCredentialsKeysList;
}
export declare const ConfigurationGetResponseCredentials: S.Schema<ConfigurationGetResponseCredentials>;
export type ConfigurationGetResponseTokenSourcesList = Array<string>;
export declare const ConfigurationGetResponseTokenSourcesList: S.Schema<ConfigurationGetResponseTokenSourcesList>;
export type ConfigurationGetResponseTokenType = "JWT";
export declare const ConfigurationGetResponseTokenType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConfigurationResponse {
    /** UUID. */
    id: string;
    createdAt: string;
    credentials: ConfigurationGetResponseCredentials;
    description: string;
    lastUpdated: string;
    title: string;
    tokenSources: ConfigurationGetResponseTokenSourcesList;
    tokenType: ConfigurationGetResponseTokenType;
}
export declare const GetConfigurationResponse: S.Schema<GetConfigurationResponse>;
export interface GetRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    ruleId: string;
}
export declare const GetRuleRequest: S.Schema<GetRuleRequest>;
export type RulesGetResponseAction = "log" | "block";
export declare const RulesGetResponseAction: any;
export type RulesGetResponseSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesGetResponseSelectorExcludeItemOperationIdsList: S.Schema<RulesGetResponseSelectorExcludeItemOperationIdsList>;
export interface RulesGetResponseSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesGetResponseSelectorExcludeItemOperationIdsList | null;
}
export declare const RulesGetResponseSelectorExcludeItem: S.Schema<RulesGetResponseSelectorExcludeItem>;
export type RulesGetResponseSelectorExcludeList = Array<RulesGetResponseSelectorExcludeItem>;
export declare const RulesGetResponseSelectorExcludeList: S.Schema<RulesGetResponseSelectorExcludeList>;
export type RulesGetResponseSelectorIncludeItemHostList = Array<string>;
export declare const RulesGetResponseSelectorIncludeItemHostList: S.Schema<RulesGetResponseSelectorIncludeItemHostList>;
export interface RulesGetResponseSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesGetResponseSelectorIncludeItemHostList | null;
}
export declare const RulesGetResponseSelectorIncludeItem: S.Schema<RulesGetResponseSelectorIncludeItem>;
export type RulesGetResponseSelectorIncludeList = Array<RulesGetResponseSelectorIncludeItem>;
export declare const RulesGetResponseSelectorIncludeList: S.Schema<RulesGetResponseSelectorIncludeList>;
export interface RulesGetResponseSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesGetResponseSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesGetResponseSelectorIncludeList | null;
}
export declare const RulesGetResponseSelector: S.Schema<RulesGetResponseSelector>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesGetResponseAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesGetResponseSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export declare const GetRuleResponse: S.Schema<GetRuleResponse>;
export interface ListConfigurationsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListConfigurationsRequest: S.Schema<ListConfigurationsRequest>;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg: any;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty: any;
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA: S.Schema<ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA>;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg: any;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv: any;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty: any;
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256: S.Schema<ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256>;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg: any;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv: any;
export type ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty: any;
export interface ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384: S.Schema<ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384>;
export type ConfigurationListResultItemCredentialsKeysItem = ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationListResultItemCredentialsKeysItemAPIShieldCredentialsJWTKeyEcEs384;
export declare const ConfigurationListResultItemCredentialsKeysItem: any;
export type ConfigurationListResultItemCredentialsKeysList = Array<ConfigurationListResultItemCredentialsKeysItem>;
export declare const ConfigurationListResultItemCredentialsKeysList: S.Schema<ConfigurationListResultItemCredentialsKeysList>;
export interface ConfigurationListResultItemCredentials {
    keys: ConfigurationListResultItemCredentialsKeysList;
}
export declare const ConfigurationListResultItemCredentials: S.Schema<ConfigurationListResultItemCredentials>;
export type ConfigurationListResultItemTokenSourcesList = Array<string>;
export declare const ConfigurationListResultItemTokenSourcesList: S.Schema<ConfigurationListResultItemTokenSourcesList>;
export type ConfigurationListResultItemTokenType = "JWT";
export declare const ConfigurationListResultItemTokenType: any;
export interface ConfigurationListResultItem {
    /** UUID. */
    id: string;
    createdAt: string;
    credentials: ConfigurationListResultItemCredentials;
    description: string;
    lastUpdated: string;
    title: string;
    tokenSources: ConfigurationListResultItemTokenSourcesList;
    tokenType: ConfigurationListResultItemTokenType;
}
export declare const ConfigurationListResultItem: S.Schema<ConfigurationListResultItem>;
export type ConfigurationListResultList = Array<ConfigurationListResultItem>;
export declare const ConfigurationListResultList: S.Schema<ConfigurationListResultList>;
export interface ListConfigurationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConfigurationListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListConfigurationsResponse: S.Schema<ListConfigurationsResponse>;
export type RulesListRequestAction = "log" | "block";
export declare const RulesListRequestAction: any;
export type RulesListRequestTokenConfigurationList = Array<string>;
export declare const RulesListRequestTokenConfigurationList: S.Schema<RulesListRequestTokenConfigurationList>;
export interface ListRulesRequest {
    /** Identifier. */
    zoneId: string;
    /** Select rules with these IDs. */
    id?: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action?: RulesListRequestAction | (string & {});
    /** Toggle rule on or off. */
    enabled?: boolean;
    /** Select rules with this host in `include`. */
    host?: string;
    /** Select rules with this host in `include`. */
    hostname?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Select rules with these IDs. */
    ruleId?: string;
    /** Select rules using any of these token configurations. */
    tokenConfiguration?: RulesListRequestTokenConfigurationList;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export type RulesListResultItemAction = "log" | "block";
export declare const RulesListResultItemAction: any;
export type RulesListResultItemSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesListResultItemSelectorExcludeItemOperationIdsList: S.Schema<RulesListResultItemSelectorExcludeItemOperationIdsList>;
export interface RulesListResultItemSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesListResultItemSelectorExcludeItemOperationIdsList | null;
}
export declare const RulesListResultItemSelectorExcludeItem: S.Schema<RulesListResultItemSelectorExcludeItem>;
export type RulesListResultItemSelectorExcludeList = Array<RulesListResultItemSelectorExcludeItem>;
export declare const RulesListResultItemSelectorExcludeList: S.Schema<RulesListResultItemSelectorExcludeList>;
export type RulesListResultItemSelectorIncludeItemHostList = Array<string>;
export declare const RulesListResultItemSelectorIncludeItemHostList: S.Schema<RulesListResultItemSelectorIncludeItemHostList>;
export interface RulesListResultItemSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesListResultItemSelectorIncludeItemHostList | null;
}
export declare const RulesListResultItemSelectorIncludeItem: S.Schema<RulesListResultItemSelectorIncludeItem>;
export type RulesListResultItemSelectorIncludeList = Array<RulesListResultItemSelectorIncludeItem>;
export declare const RulesListResultItemSelectorIncludeList: S.Schema<RulesListResultItemSelectorIncludeList>;
export interface RulesListResultItemSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesListResultItemSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesListResultItemSelectorIncludeList | null;
}
export declare const RulesListResultItemSelector: S.Schema<RulesListResultItemSelector>;
export interface RulesListResultItem {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesListResultItemAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesListResultItemSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export declare const RulesListResultItem: S.Schema<RulesListResultItem>;
export type RulesListResultList = Array<RulesListResultItem>;
export declare const RulesListResultList: S.Schema<RulesListResultList>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export type ConfigurationEditRequestTokenSourcesList = Array<string>;
export declare const ConfigurationEditRequestTokenSourcesList: S.Schema<ConfigurationEditRequestTokenSourcesList>;
export interface PatchConfigurationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
    description?: string;
    title?: string;
    tokenSources?: ConfigurationEditRequestTokenSourcesList;
}
export declare const PatchConfigurationRequest: S.Schema<PatchConfigurationRequest>;
export type ConfigurationEditResponseTokenSourcesList = Array<string>;
export declare const ConfigurationEditResponseTokenSourcesList: S.Schema<ConfigurationEditResponseTokenSourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConfigurationResponse {
    /** UUID. */
    id?: string | null;
    description?: string | null;
    title?: string | null;
    tokenSources?: ConfigurationEditResponseTokenSourcesList | null;
}
export declare const PatchConfigurationResponse: S.Schema<PatchConfigurationResponse>;
export type RulesEditRequestAction = "log" | "block";
export declare const RulesEditRequestAction: any;
export type RulesEditRequestPositionAPIShieldIndex = RulesBulkEditRequestBodyItemPositionAPIShieldIndex;
export declare const RulesEditRequestPositionAPIShieldIndex: S.Schema<RulesBulkEditRequestBodyItemPositionAPIShieldIndex>;
export type RulesEditRequestPositionAPIShieldBefore = RulesBulkEditRequestBodyItemPositionAPIShieldBefore;
export declare const RulesEditRequestPositionAPIShieldBefore: S.Schema<RulesBulkEditRequestBodyItemPositionAPIShieldBefore>;
export type RulesEditRequestPositionAPIShieldAfter = RulesBulkEditRequestBodyItemPositionAPIShieldAfter;
export declare const RulesEditRequestPositionAPIShieldAfter: S.Schema<RulesBulkEditRequestBodyItemPositionAPIShieldAfter>;
export type RulesEditRequestPosition = RulesBulkEditRequestBodyItemPositionAPIShieldIndex | RulesBulkEditRequestBodyItemPositionAPIShieldBefore | RulesBulkEditRequestBodyItemPositionAPIShieldAfter;
export declare const RulesEditRequestPosition: any;
export type RulesEditRequestSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesEditRequestSelectorExcludeItemOperationIdsList: S.Schema<RulesEditRequestSelectorExcludeItemOperationIdsList>;
export interface RulesEditRequestSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesEditRequestSelectorExcludeItemOperationIdsList;
}
export declare const RulesEditRequestSelectorExcludeItem: S.Schema<RulesEditRequestSelectorExcludeItem>;
export type RulesEditRequestSelectorExcludeList = Array<RulesEditRequestSelectorExcludeItem>;
export declare const RulesEditRequestSelectorExcludeList: S.Schema<RulesEditRequestSelectorExcludeList>;
export type RulesEditRequestSelectorIncludeItemHostList = Array<string>;
export declare const RulesEditRequestSelectorIncludeItemHostList: S.Schema<RulesEditRequestSelectorIncludeItemHostList>;
export interface RulesEditRequestSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesEditRequestSelectorIncludeItemHostList;
}
export declare const RulesEditRequestSelectorIncludeItem: S.Schema<RulesEditRequestSelectorIncludeItem>;
export type RulesEditRequestSelectorIncludeList = Array<RulesEditRequestSelectorIncludeItem>;
export declare const RulesEditRequestSelectorIncludeList: S.Schema<RulesEditRequestSelectorIncludeList>;
export interface RulesEditRequestSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesEditRequestSelectorExcludeList;
    /** Select all matching operations. */
    include?: RulesEditRequestSelectorIncludeList;
}
export declare const RulesEditRequestSelector: S.Schema<RulesEditRequestSelector>;
export interface PatchRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    ruleId: string;
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action?: RulesEditRequestAction | (string & {});
    /** A human-readable description that gives more details than `title`. */
    description?: string;
    /** Toggle rule on or off. */
    enabled?: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression?: string;
    /** Update rule order among zone rules. */
    position?: RulesEditRequestPosition;
    /** Select operations covered by this rule. */
    selector?: RulesEditRequestSelector;
    /** A human-readable name for the rule. */
    title?: string;
}
export declare const PatchRuleRequest: S.Schema<PatchRuleRequest>;
export type RulesEditResponseAction = "log" | "block";
export declare const RulesEditResponseAction: any;
export type RulesEditResponseSelectorExcludeItemOperationIdsList = Array<string>;
export declare const RulesEditResponseSelectorExcludeItemOperationIdsList: S.Schema<RulesEditResponseSelectorExcludeItemOperationIdsList>;
export interface RulesEditResponseSelectorExcludeItem {
    /** Excluded operation IDs. */
    operationIds?: RulesEditResponseSelectorExcludeItemOperationIdsList | null;
}
export declare const RulesEditResponseSelectorExcludeItem: S.Schema<RulesEditResponseSelectorExcludeItem>;
export type RulesEditResponseSelectorExcludeList = Array<RulesEditResponseSelectorExcludeItem>;
export declare const RulesEditResponseSelectorExcludeList: S.Schema<RulesEditResponseSelectorExcludeList>;
export type RulesEditResponseSelectorIncludeItemHostList = Array<string>;
export declare const RulesEditResponseSelectorIncludeItemHostList: S.Schema<RulesEditResponseSelectorIncludeItemHostList>;
export interface RulesEditResponseSelectorIncludeItem {
    /** Included hostnames. */
    host?: RulesEditResponseSelectorIncludeItemHostList | null;
}
export declare const RulesEditResponseSelectorIncludeItem: S.Schema<RulesEditResponseSelectorIncludeItem>;
export type RulesEditResponseSelectorIncludeList = Array<RulesEditResponseSelectorIncludeItem>;
export declare const RulesEditResponseSelectorIncludeList: S.Schema<RulesEditResponseSelectorIncludeList>;
export interface RulesEditResponseSelector {
    /** Ignore operations that were otherwise included by `include`. */
    exclude?: RulesEditResponseSelectorExcludeList | null;
    /** Select all matching operations. */
    include?: RulesEditResponseSelectorIncludeList | null;
}
export declare const RulesEditResponseSelector: S.Schema<RulesEditResponseSelector>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRuleResponse {
    /** Action to take on requests that match operations included in `selector` and fail `expression`. */
    action: RulesEditResponseAction;
    /** A human-readable description that gives more details than `title`. */
    description: string;
    /** Toggle rule on or off. */
    enabled: boolean;
    /** Rule expression. Requests that fail to match this expression will be subject to `action`. */
    expression: string;
    /** Select operations covered by this rule. */
    selector: RulesEditResponseSelector;
    /** A human-readable name for the rule. */
    title: string;
    /** UUID. */
    id?: string | null;
    createdAt?: string | null;
    lastUpdated?: string | null;
}
export declare const PatchRuleResponse: S.Schema<PatchRuleResponse>;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg: any;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty: any;
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAAlg | (string & {});
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSA: S.Schema<ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSA>;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg: any;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv: any;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty: any;
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256: S.Schema<ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256>;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg: any;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv: any;
export type ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty: any;
export interface ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384: S.Schema<ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384>;
export type ConfigurationCredentialsUpdateRequestKeysItem = ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCredentialsUpdateRequestKeysItemAPIShieldCredentialsJWTKeyEcEs384;
export declare const ConfigurationCredentialsUpdateRequestKeysItem: any;
export type ConfigurationCredentialsUpdateRequestKeysList = Array<ConfigurationCredentialsUpdateRequestKeysItem>;
export declare const ConfigurationCredentialsUpdateRequestKeysList: S.Schema<ConfigurationCredentialsUpdateRequestKeysList>;
export interface PutConfigurationCredentialRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    configId: string;
    keys: ConfigurationCredentialsUpdateRequestKeysList;
}
export declare const PutConfigurationCredentialRequest: S.Schema<PutConfigurationCredentialRequest>;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg = "RS256" | "RS384" | "RS512" | "PS256" | "PS384" | "PS512";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg: any;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty = "RSA";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty: any;
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSA {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAAlg;
    /** RSA exponent */
    e: string;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSAKty;
    /** RSA modulus */
    n: string;
}
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSA: S.Schema<ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSA>;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg = "ES256";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg: any;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv = "P-256";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv: any;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty = "EC";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty: any;
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256: S.Schema<ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256>;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg = "ES384";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg: any;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv = "P-384";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv: any;
export type ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty = "EC";
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty: any;
export interface ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384 {
    /** Algorithm */
    alg: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Alg;
    /** Curve */
    crv: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Crv;
    /** Key ID */
    kid: string;
    /** Key Type */
    kty: ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384Kty;
    /** X EC coordinate */
    x: string;
    /** Y EC coordinate */
    y: string;
}
export declare const ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384: S.Schema<ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384>;
export type ConfigurationCredentialsUpdateResponseKeysItem = ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyRSA | ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs256 | ConfigurationCredentialsUpdateResponseKeysItemAPIShieldCredentialsJWTKeyEcEs384;
export declare const ConfigurationCredentialsUpdateResponseKeysItem: any;
export type ConfigurationCredentialsUpdateResponseKeysList = Array<ConfigurationCredentialsUpdateResponseKeysItem>;
export declare const ConfigurationCredentialsUpdateResponseKeysList: S.Schema<ConfigurationCredentialsUpdateResponseKeysList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutConfigurationCredentialResponse {
    keys: ConfigurationCredentialsUpdateResponseKeysList;
}
export declare const PutConfigurationCredentialResponse: S.Schema<PutConfigurationCredentialResponse>;
export type BulkCreateRulesError = CloudflareOpError;
/** Create zone token validation rules. A request can create multiple Token Validation Rules. */
export declare const bulkCreateRules: API.PaginatedOperationMethod<BulkCreateRulesRequest, BulkCreateRulesResponse, BulkCreateRulesError, CloudflareOpContext, RulesBulkCreateResultItem>;
export type BulkPatchRulesError = CloudflareOpError;
/** Edit token validation rules. A request can update multiple Token Validation Rules. Rules can be re-ordered using the `position` field. Returns all updated rules. */
export declare const bulkPatchRules: API.PaginatedOperationMethod<BulkPatchRulesRequest, BulkPatchRulesResponse, BulkPatchRulesError, CloudflareOpContext, RulesBulkEditResultItem>;
export type CreateConfigurationError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Create a new Token Validation configuration */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest, CreateConfigurationResponse, CreateConfigurationError, CloudflareOpContext>;
export type CreateRuleError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Create a token validation rule. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type DeleteConfigurationError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Delete Token Configuration */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest, DeleteConfigurationResponse, DeleteConfigurationError, CloudflareOpContext>;
export type DeleteRuleError = TokenValidationRuleNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Delete a zone token validation rule. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type GetConfigurationError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Get a single Token Configuration */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, GetConfigurationResponse, GetConfigurationError, CloudflareOpContext>;
export type GetRuleError = TokenValidationRuleNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Get a zone token validation rule. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type ListConfigurationsError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Lists all token validation configurations for this zone */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest, ListConfigurationsResponse, ListConfigurationsError, CloudflareOpContext, ConfigurationListResultItem>;
export type ListRulesError = TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** List token validation rules */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type PatchConfigurationError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Edit fields of an existing Token Configuration */
export declare const patchConfiguration: API.OperationMethod<PatchConfigurationRequest, PatchConfigurationResponse, PatchConfigurationError, CloudflareOpContext>;
export type PatchRuleError = TokenValidationRuleNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Edit a zone token validation rule. */
export declare const patchRule: API.OperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext>;
export type PutConfigurationCredentialError = TokenConfigurationNotFound | TokenValidationNotEntitled | Forbidden | CloudflareOpError;
/** Update Token Configuration credentials */
export declare const putConfigurationCredential: API.OperationMethod<PutConfigurationCredentialRequest, PutConfigurationCredentialResponse, PutConfigurationCredentialError, CloudflareOpContext>;
//# sourceMappingURL=token_validation.d.ts.map