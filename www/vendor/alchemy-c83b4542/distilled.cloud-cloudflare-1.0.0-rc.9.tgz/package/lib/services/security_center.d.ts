import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DismissInsightForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    issueId: string;
    dismiss?: boolean;
}
export declare const DismissInsightForAccountRequest: S.Schema<DismissInsightForAccountRequest>;
export interface DismissInsightForAccountResponse {
}
export declare const DismissInsightForAccountResponse: S.Schema<DismissInsightForAccountResponse>;
export interface DismissInsightForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    issueId: string;
    dismiss?: boolean;
}
export declare const DismissInsightForZoneRequest: S.Schema<DismissInsightForZoneRequest>;
export interface DismissInsightForZoneResponse {
}
export declare const DismissInsightForZoneResponse: S.Schema<DismissInsightForZoneResponse>;
export type InsightsClassGetRequestIssueClassList = Array<string>;
export declare const InsightsClassGetRequestIssueClassList: S.Schema<InsightsClassGetRequestIssueClassList>;
export type InsightsClassGetRequestIssueClassNeqList = Array<string>;
export declare const InsightsClassGetRequestIssueClassNeqList: S.Schema<InsightsClassGetRequestIssueClassNeqList>;
export type InsightsClassGetRequestIssueTypeList = Array<string>;
export declare const InsightsClassGetRequestIssueTypeList: S.Schema<InsightsClassGetRequestIssueTypeList>;
export type InsightsClassGetRequestIssueTypeNeqList = Array<string>;
export declare const InsightsClassGetRequestIssueTypeNeqList: S.Schema<InsightsClassGetRequestIssueTypeNeqList>;
export type InsightsClassGetRequestProductList = Array<string>;
export declare const InsightsClassGetRequestProductList: S.Schema<InsightsClassGetRequestProductList>;
export type InsightsClassGetRequestProductNeqList = Array<string>;
export declare const InsightsClassGetRequestProductNeqList: S.Schema<InsightsClassGetRequestProductNeqList>;
export type InsightsClassGetRequestSeverityList = Array<string>;
export declare const InsightsClassGetRequestSeverityList: S.Schema<InsightsClassGetRequestSeverityList>;
export type InsightsClassGetRequestSeverityNeqList = Array<string>;
export declare const InsightsClassGetRequestSeverityNeqList: S.Schema<InsightsClassGetRequestSeverityNeqList>;
export type InsightsClassGetRequestSubjectList = Array<string>;
export declare const InsightsClassGetRequestSubjectList: S.Schema<InsightsClassGetRequestSubjectList>;
export type InsightsClassGetRequestSubjectNeqList = Array<string>;
export declare const InsightsClassGetRequestSubjectNeqList: S.Schema<InsightsClassGetRequestSubjectNeqList>;
export interface GetInsightClassForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: InsightsClassGetRequestIssueClassList;
    issueClassNeq?: InsightsClassGetRequestIssueClassNeqList;
    issueType?: InsightsClassGetRequestIssueTypeList;
    issueTypeNeq?: InsightsClassGetRequestIssueTypeNeqList;
    product?: InsightsClassGetRequestProductList;
    productNeq?: InsightsClassGetRequestProductNeqList;
    severity?: InsightsClassGetRequestSeverityList;
    severityNeq?: InsightsClassGetRequestSeverityNeqList;
    subject?: InsightsClassGetRequestSubjectList;
    subjectNeq?: InsightsClassGetRequestSubjectNeqList;
}
export declare const GetInsightClassForAccountRequest: S.Schema<GetInsightClassForAccountRequest>;
export interface InsightsClassGetResultItem {
    count?: number | null;
    value?: string | null;
}
export declare const InsightsClassGetResultItem: S.Schema<InsightsClassGetResultItem>;
export type InsightsClassGetResultList = Array<InsightsClassGetResultItem>;
export declare const InsightsClassGetResultList: S.Schema<InsightsClassGetResultList>;
export type GetInsightClassResponse = InsightsClassGetResultList;
export declare const GetInsightClassResponse: S.Schema<GetInsightClassResponse>;
export interface GetInsightClassForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean;
    issueClass?: InsightsClassGetRequestIssueClassList;
    issueClassNeq?: InsightsClassGetRequestIssueClassNeqList;
    issueType?: InsightsClassGetRequestIssueTypeList;
    issueTypeNeq?: InsightsClassGetRequestIssueTypeNeqList;
    product?: InsightsClassGetRequestProductList;
    productNeq?: InsightsClassGetRequestProductNeqList;
    severity?: InsightsClassGetRequestSeverityList;
    severityNeq?: InsightsClassGetRequestSeverityNeqList;
    subject?: InsightsClassGetRequestSubjectList;
    subjectNeq?: InsightsClassGetRequestSubjectNeqList;
}
export declare const GetInsightClassForZoneRequest: S.Schema<GetInsightClassForZoneRequest>;
export interface GetInsightContextRequest {
    /** Identifier. */
    accountId: string;
    issueId: string;
}
export declare const GetInsightContextRequest: S.Schema<GetInsightContextRequest>;
export type InsightsContextGetResultMap = {
    [key: string]: unknown | undefined;
};
export declare const InsightsContextGetResultMap: S.Schema<InsightsContextGetResultMap>;
export type GetInsightContextResponse = InsightsContextGetResultMap;
export declare const GetInsightContextResponse: S.Schema<GetInsightContextResponse>;
export type InsightsSeverityGetRequestIssueClassList = Array<string>;
export declare const InsightsSeverityGetRequestIssueClassList: S.Schema<InsightsSeverityGetRequestIssueClassList>;
export type InsightsSeverityGetRequestIssueClassNeqList = Array<string>;
export declare const InsightsSeverityGetRequestIssueClassNeqList: S.Schema<InsightsSeverityGetRequestIssueClassNeqList>;
export type InsightsSeverityGetRequestIssueTypeList = Array<string>;
export declare const InsightsSeverityGetRequestIssueTypeList: S.Schema<InsightsSeverityGetRequestIssueTypeList>;
export type InsightsSeverityGetRequestIssueTypeNeqList = Array<string>;
export declare const InsightsSeverityGetRequestIssueTypeNeqList: S.Schema<InsightsSeverityGetRequestIssueTypeNeqList>;
export type InsightsSeverityGetRequestProductList = Array<string>;
export declare const InsightsSeverityGetRequestProductList: S.Schema<InsightsSeverityGetRequestProductList>;
export type InsightsSeverityGetRequestProductNeqList = Array<string>;
export declare const InsightsSeverityGetRequestProductNeqList: S.Schema<InsightsSeverityGetRequestProductNeqList>;
export type InsightsSeverityGetRequestSeverityList = Array<string>;
export declare const InsightsSeverityGetRequestSeverityList: S.Schema<InsightsSeverityGetRequestSeverityList>;
export type InsightsSeverityGetRequestSeverityNeqList = Array<string>;
export declare const InsightsSeverityGetRequestSeverityNeqList: S.Schema<InsightsSeverityGetRequestSeverityNeqList>;
export type InsightsSeverityGetRequestSubjectList = Array<string>;
export declare const InsightsSeverityGetRequestSubjectList: S.Schema<InsightsSeverityGetRequestSubjectList>;
export type InsightsSeverityGetRequestSubjectNeqList = Array<string>;
export declare const InsightsSeverityGetRequestSubjectNeqList: S.Schema<InsightsSeverityGetRequestSubjectNeqList>;
export interface GetInsightSeverityForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: InsightsSeverityGetRequestIssueClassList;
    issueClassNeq?: InsightsSeverityGetRequestIssueClassNeqList;
    issueType?: InsightsSeverityGetRequestIssueTypeList;
    issueTypeNeq?: InsightsSeverityGetRequestIssueTypeNeqList;
    product?: InsightsSeverityGetRequestProductList;
    productNeq?: InsightsSeverityGetRequestProductNeqList;
    severity?: InsightsSeverityGetRequestSeverityList;
    severityNeq?: InsightsSeverityGetRequestSeverityNeqList;
    subject?: InsightsSeverityGetRequestSubjectList;
    subjectNeq?: InsightsSeverityGetRequestSubjectNeqList;
}
export declare const GetInsightSeverityForAccountRequest: S.Schema<GetInsightSeverityForAccountRequest>;
export type InsightsSeverityGetResultItem = InsightsClassGetResultItem;
export declare const InsightsSeverityGetResultItem: S.Schema<InsightsClassGetResultItem>;
export type InsightsSeverityGetResultList = Array<InsightsClassGetResultItem>;
export declare const InsightsSeverityGetResultList: S.Schema<InsightsSeverityGetResultList>;
export type GetInsightSeverityResponse = InsightsSeverityGetResultList;
export declare const GetInsightSeverityResponse: S.Schema<GetInsightSeverityResponse>;
export interface GetInsightSeverityForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean;
    issueClass?: InsightsSeverityGetRequestIssueClassList;
    issueClassNeq?: InsightsSeverityGetRequestIssueClassNeqList;
    issueType?: InsightsSeverityGetRequestIssueTypeList;
    issueTypeNeq?: InsightsSeverityGetRequestIssueTypeNeqList;
    product?: InsightsSeverityGetRequestProductList;
    productNeq?: InsightsSeverityGetRequestProductNeqList;
    severity?: InsightsSeverityGetRequestSeverityList;
    severityNeq?: InsightsSeverityGetRequestSeverityNeqList;
    subject?: InsightsSeverityGetRequestSubjectList;
    subjectNeq?: InsightsSeverityGetRequestSubjectNeqList;
}
export declare const GetInsightSeverityForZoneRequest: S.Schema<GetInsightSeverityForZoneRequest>;
export type InsightsTypeGetRequestIssueClassList = Array<string>;
export declare const InsightsTypeGetRequestIssueClassList: S.Schema<InsightsTypeGetRequestIssueClassList>;
export type InsightsTypeGetRequestIssueClassNeqList = Array<string>;
export declare const InsightsTypeGetRequestIssueClassNeqList: S.Schema<InsightsTypeGetRequestIssueClassNeqList>;
export type InsightsTypeGetRequestIssueTypeList = Array<string>;
export declare const InsightsTypeGetRequestIssueTypeList: S.Schema<InsightsTypeGetRequestIssueTypeList>;
export type InsightsTypeGetRequestIssueTypeNeqList = Array<string>;
export declare const InsightsTypeGetRequestIssueTypeNeqList: S.Schema<InsightsTypeGetRequestIssueTypeNeqList>;
export type InsightsTypeGetRequestProductList = Array<string>;
export declare const InsightsTypeGetRequestProductList: S.Schema<InsightsTypeGetRequestProductList>;
export type InsightsTypeGetRequestProductNeqList = Array<string>;
export declare const InsightsTypeGetRequestProductNeqList: S.Schema<InsightsTypeGetRequestProductNeqList>;
export type InsightsTypeGetRequestSeverityList = Array<string>;
export declare const InsightsTypeGetRequestSeverityList: S.Schema<InsightsTypeGetRequestSeverityList>;
export type InsightsTypeGetRequestSeverityNeqList = Array<string>;
export declare const InsightsTypeGetRequestSeverityNeqList: S.Schema<InsightsTypeGetRequestSeverityNeqList>;
export type InsightsTypeGetRequestSubjectList = Array<string>;
export declare const InsightsTypeGetRequestSubjectList: S.Schema<InsightsTypeGetRequestSubjectList>;
export type InsightsTypeGetRequestSubjectNeqList = Array<string>;
export declare const InsightsTypeGetRequestSubjectNeqList: S.Schema<InsightsTypeGetRequestSubjectNeqList>;
export interface GetInsightTypeForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: InsightsTypeGetRequestIssueClassList;
    issueClassNeq?: InsightsTypeGetRequestIssueClassNeqList;
    issueType?: InsightsTypeGetRequestIssueTypeList;
    issueTypeNeq?: InsightsTypeGetRequestIssueTypeNeqList;
    product?: InsightsTypeGetRequestProductList;
    productNeq?: InsightsTypeGetRequestProductNeqList;
    severity?: InsightsTypeGetRequestSeverityList;
    severityNeq?: InsightsTypeGetRequestSeverityNeqList;
    subject?: InsightsTypeGetRequestSubjectList;
    subjectNeq?: InsightsTypeGetRequestSubjectNeqList;
}
export declare const GetInsightTypeForAccountRequest: S.Schema<GetInsightTypeForAccountRequest>;
export type InsightsTypeGetResultItem = InsightsClassGetResultItem;
export declare const InsightsTypeGetResultItem: S.Schema<InsightsClassGetResultItem>;
export type InsightsTypeGetResultList = Array<InsightsClassGetResultItem>;
export declare const InsightsTypeGetResultList: S.Schema<InsightsTypeGetResultList>;
export type GetInsightTypeResponse = InsightsTypeGetResultList;
export declare const GetInsightTypeResponse: S.Schema<GetInsightTypeResponse>;
export interface GetInsightTypeForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean;
    issueClass?: InsightsTypeGetRequestIssueClassList;
    issueClassNeq?: InsightsTypeGetRequestIssueClassNeqList;
    issueType?: InsightsTypeGetRequestIssueTypeList;
    issueTypeNeq?: InsightsTypeGetRequestIssueTypeNeqList;
    product?: InsightsTypeGetRequestProductList;
    productNeq?: InsightsTypeGetRequestProductNeqList;
    severity?: InsightsTypeGetRequestSeverityList;
    severityNeq?: InsightsTypeGetRequestSeverityNeqList;
    subject?: InsightsTypeGetRequestSubjectList;
    subjectNeq?: InsightsTypeGetRequestSubjectNeqList;
}
export declare const GetInsightTypeForZoneRequest: S.Schema<GetInsightTypeForZoneRequest>;
export type InsightsAuditLogsListByInsightRequestFieldChanged = "status" | "user_classification";
export declare const InsightsAuditLogsListByInsightRequestFieldChanged: any;
export type InsightsAuditLogsListByInsightRequestOrder = "asc" | "desc";
export declare const InsightsAuditLogsListByInsightRequestOrder: any;
export interface ListByInsightInsightAuditLogForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    issueId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string;
    /** Filter by the actor that made the change. */
    changedBy?: string;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListByInsightRequestFieldChanged | (string & {});
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListByInsightRequestOrder | (string & {});
    /** Number of results per page. */
    perPage?: number;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string;
}
export declare const ListByInsightInsightAuditLogForAccountRequest: S.Schema<ListByInsightInsightAuditLogForAccountRequest>;
export type InsightsAuditLogsListByInsightResultItemFieldChanged = "status" | "user_classification";
export declare const InsightsAuditLogsListByInsightResultItemFieldChanged: any;
export interface InsightsAuditLogsListByInsightResultItem {
    /** UUIDv7 identifier for the audit log entry, time-ordered. */
    id?: string | null;
    /** The timestamp when the change occurred. */
    changedAt?: string | null;
    /** The actor that made the change. 'system' for automated changes, or a user identifier. */
    changedBy?: string | null;
    /** The value of the field after the change. Null if the field was cleared. */
    currentValue?: string | null;
    /** The field that was changed. */
    fieldChanged?: InsightsAuditLogsListByInsightResultItemFieldChanged | null;
    /** The ID of the insight this audit log entry relates to. */
    issueId?: string | null;
    /** The value of the field before the change. Null if the field was not previously set. */
    previousValue?: string | null;
    /** Optional rationale provided for the change. */
    rationale?: string | null;
    /** The zone ID associated with the insight. Only present for zone-level insights. */
    zoneId?: number | null;
}
export declare const InsightsAuditLogsListByInsightResultItem: S.Schema<InsightsAuditLogsListByInsightResultItem>;
export type InsightsAuditLogsListByInsightResultList = Array<InsightsAuditLogsListByInsightResultItem>;
export declare const InsightsAuditLogsListByInsightResultList: S.Schema<InsightsAuditLogsListByInsightResultList>;
export interface ListByInsightInsightAuditLogResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InsightsAuditLogsListByInsightResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListByInsightInsightAuditLogResponse: S.Schema<ListByInsightInsightAuditLogResponse>;
export interface ListByInsightInsightAuditLogForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    issueId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string;
    /** Filter by the actor that made the change. */
    changedBy?: string;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListByInsightRequestFieldChanged | (string & {});
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListByInsightRequestOrder | (string & {});
    /** Number of results per page. */
    perPage?: number;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string;
}
export declare const ListByInsightInsightAuditLogForZoneRequest: S.Schema<ListByInsightInsightAuditLogForZoneRequest>;
export type InsightsAuditLogsListRequestFieldChanged = "status" | "user_classification";
export declare const InsightsAuditLogsListRequestFieldChanged: any;
export type InsightsAuditLogsListRequestOrder = "asc" | "desc";
export declare const InsightsAuditLogsListRequestOrder: any;
export interface ListInsightAuditLogsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string;
    /** Filter by the actor that made the change. */
    changedBy?: string;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListRequestFieldChanged | (string & {});
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListRequestOrder | (string & {});
    /** Number of results per page. */
    perPage?: number;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string;
}
export declare const ListInsightAuditLogsForAccountRequest: S.Schema<ListInsightAuditLogsForAccountRequest>;
export type InsightsAuditLogsListResultItemFieldChanged = "status" | "user_classification";
export declare const InsightsAuditLogsListResultItemFieldChanged: any;
export interface InsightsAuditLogsListResultItem {
    /** UUIDv7 identifier for the audit log entry, time-ordered. */
    id?: string | null;
    /** The timestamp when the change occurred. */
    changedAt?: string | null;
    /** The actor that made the change. 'system' for automated changes, or a user identifier. */
    changedBy?: string | null;
    /** The value of the field after the change. Null if the field was cleared. */
    currentValue?: string | null;
    /** The field that was changed. */
    fieldChanged?: InsightsAuditLogsListResultItemFieldChanged | null;
    /** The ID of the insight this audit log entry relates to. */
    issueId?: string | null;
    /** The value of the field before the change. Null if the field was not previously set. */
    previousValue?: string | null;
    /** Optional rationale provided for the change. */
    rationale?: string | null;
    /** The zone ID associated with the insight. Only present for zone-level insights. */
    zoneId?: number | null;
}
export declare const InsightsAuditLogsListResultItem: S.Schema<InsightsAuditLogsListResultItem>;
export type InsightsAuditLogsListResultList = Array<InsightsAuditLogsListResultItem>;
export declare const InsightsAuditLogsListResultList: S.Schema<InsightsAuditLogsListResultList>;
export interface ListInsightAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InsightsAuditLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInsightAuditLogsResponse: S.Schema<ListInsightAuditLogsResponse>;
export interface ListInsightAuditLogsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string;
    /** Filter by the actor that made the change. */
    changedBy?: string;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListRequestFieldChanged | (string & {});
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListRequestOrder | (string & {});
    /** Number of results per page. */
    perPage?: number;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string;
}
export declare const ListInsightAuditLogsForZoneRequest: S.Schema<ListInsightAuditLogsForZoneRequest>;
export type InsightsListRequestIssueClassList = Array<string>;
export declare const InsightsListRequestIssueClassList: S.Schema<InsightsListRequestIssueClassList>;
export type InsightsListRequestIssueClassNeqList = Array<string>;
export declare const InsightsListRequestIssueClassNeqList: S.Schema<InsightsListRequestIssueClassNeqList>;
export type InsightsListRequestIssueTypeList = Array<string>;
export declare const InsightsListRequestIssueTypeList: S.Schema<InsightsListRequestIssueTypeList>;
export type InsightsListRequestIssueTypeNeqList = Array<string>;
export declare const InsightsListRequestIssueTypeNeqList: S.Schema<InsightsListRequestIssueTypeNeqList>;
export type InsightsListRequestProductList = Array<string>;
export declare const InsightsListRequestProductList: S.Schema<InsightsListRequestProductList>;
export type InsightsListRequestProductNeqList = Array<string>;
export declare const InsightsListRequestProductNeqList: S.Schema<InsightsListRequestProductNeqList>;
export type InsightsListRequestSeverityList = Array<string>;
export declare const InsightsListRequestSeverityList: S.Schema<InsightsListRequestSeverityList>;
export type InsightsListRequestSeverityNeqList = Array<string>;
export declare const InsightsListRequestSeverityNeqList: S.Schema<InsightsListRequestSeverityNeqList>;
export type InsightsListRequestSubjectList = Array<string>;
export declare const InsightsListRequestSubjectList: S.Schema<InsightsListRequestSubjectList>;
export type InsightsListRequestSubjectNeqList = Array<string>;
export declare const InsightsListRequestSubjectNeqList: S.Schema<InsightsListRequestSubjectNeqList>;
export interface ListInsightsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean;
    issueClass?: InsightsListRequestIssueClassList;
    issueClassNeq?: InsightsListRequestIssueClassNeqList;
    issueType?: InsightsListRequestIssueTypeList;
    issueTypeNeq?: InsightsListRequestIssueTypeNeqList;
    /** Specifies the current page within paginated list of results. */
    page?: number;
    /** Sets the number of results per page of results. */
    perPage?: number;
    product?: InsightsListRequestProductList;
    productNeq?: InsightsListRequestProductNeqList;
    severity?: InsightsListRequestSeverityList;
    severityNeq?: InsightsListRequestSeverityNeqList;
    subject?: InsightsListRequestSubjectList;
    subjectNeq?: InsightsListRequestSubjectNeqList;
}
export declare const ListInsightsForAccountRequest: S.Schema<ListInsightsForAccountRequest>;
export type InsightsListResponseIssuesItemIssueType = "compliance_violation" | "email_security" | "exposed_infrastructure" | "insecure_configuration" | "weak_authentication" | "configuration_suggestion";
export declare const InsightsListResponseIssuesItemIssueType: any;
export interface InsightsListResponseIssuesItemPayload {
    /** Describes the method used to detect insight. */
    detectionMethod?: string | null;
    zoneTag?: string | null;
}
export declare const InsightsListResponseIssuesItemPayload: S.Schema<InsightsListResponseIssuesItemPayload>;
export type InsightsListResponseIssuesItemSeverity = "Low" | "Moderate" | "Critical";
export declare const InsightsListResponseIssuesItemSeverity: any;
export type InsightsListResponseIssuesItemStatus = "active" | "resolved";
export declare const InsightsListResponseIssuesItemStatus: any;
export type InsightsListResponseIssuesItemUserClassification = "false_positive" | "accept_risk" | "other";
export declare const InsightsListResponseIssuesItemUserClassification: any;
export interface InsightsListResponseIssuesItem {
    id?: string | null;
    dismissed?: boolean | null;
    /** Indicates whether the insight has a large payload that requires fetching via the context endpoint. */
    hasExtendedContext?: boolean | null;
    issueClass?: string | null;
    issueType?: InsightsListResponseIssuesItemIssueType | null;
    payload?: InsightsListResponseIssuesItemPayload | null;
    resolveLink?: string | null;
    resolveText?: string | null;
    severity?: InsightsListResponseIssuesItemSeverity | null;
    since?: string | null;
    /** The current status of the insight. */
    status?: InsightsListResponseIssuesItemStatus | null;
    subject?: string | null;
    timestamp?: string | null;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    userClassification?: InsightsListResponseIssuesItemUserClassification | null;
}
export declare const InsightsListResponseIssuesItem: S.Schema<InsightsListResponseIssuesItem>;
export type InsightsListResponseIssuesList = Array<InsightsListResponseIssuesItem>;
export declare const InsightsListResponseIssuesList: S.Schema<InsightsListResponseIssuesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListInsightsResponse {
    /** Indicates the total number of results. */
    count?: number | null;
    issues?: InsightsListResponseIssuesList | null;
    /** Specifies the current page within paginated list of results. */
    page?: number | null;
    /** Sets the number of results per page of results. */
    perPage?: number | null;
}
export declare const ListInsightsResponse: S.Schema<ListInsightsResponse>;
export interface ListInsightsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean;
    issueClass?: InsightsListRequestIssueClassList;
    issueClassNeq?: InsightsListRequestIssueClassNeqList;
    issueType?: InsightsListRequestIssueTypeList;
    issueTypeNeq?: InsightsListRequestIssueTypeNeqList;
    /** Specifies the current page within paginated list of results. */
    page?: number;
    /** Sets the number of results per page of results. */
    perPage?: number;
    product?: InsightsListRequestProductList;
    productNeq?: InsightsListRequestProductNeqList;
    severity?: InsightsListRequestSeverityList;
    severityNeq?: InsightsListRequestSeverityNeqList;
    subject?: InsightsListRequestSubjectList;
    subjectNeq?: InsightsListRequestSubjectNeqList;
}
export declare const ListInsightsForZoneRequest: S.Schema<ListInsightsForZoneRequest>;
export type InsightsClassificationUpdateRequestClassification = "false_positive" | "accept_risk" | "other";
export declare const InsightsClassificationUpdateRequestClassification: any;
export interface PatchInsightClassificationForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    issueId: string;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    classification?: InsightsClassificationUpdateRequestClassification | (string & {});
    /** Rationale for the classification change. Required when classification is 'accept_risk' or 'other'. */
    rationale?: string;
}
export declare const PatchInsightClassificationForAccountRequest: S.Schema<PatchInsightClassificationForAccountRequest>;
export interface PatchInsightClassificationForAccountResponse {
}
export declare const PatchInsightClassificationForAccountResponse: S.Schema<PatchInsightClassificationForAccountResponse>;
export interface PatchInsightClassificationForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    issueId: string;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    classification?: InsightsClassificationUpdateRequestClassification | (string & {});
    /** Rationale for the classification change. Required when classification is 'accept_risk' or 'other'. */
    rationale?: string;
}
export declare const PatchInsightClassificationForZoneRequest: S.Schema<PatchInsightClassificationForZoneRequest>;
export interface PatchInsightClassificationForZoneResponse {
}
export declare const PatchInsightClassificationForZoneResponse: S.Schema<PatchInsightClassificationForZoneResponse>;
export type DismissInsightForAccountError = CloudflareOpError;
/** Archives a Security Center insight for an account or zone, removing it from the active insights list while preserving historical data. */
export declare const dismissInsightForAccount: API.OperationMethod<DismissInsightForAccountRequest, DismissInsightForAccountResponse, DismissInsightForAccountError, CloudflareOpContext>;
export type DismissInsightForZoneError = CloudflareOpError;
/** Archives a Security Center insight for an account or zone, removing it from the active insights list while preserving historical data. */
export declare const dismissInsightForZone: API.OperationMethod<DismissInsightForZoneRequest, DismissInsightForZoneResponse, DismissInsightForZoneError, CloudflareOpContext>;
export type GetInsightClassForAccountError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by classification class. */
export declare const getInsightClassForAccount: API.OperationMethod<GetInsightClassForAccountRequest, GetInsightClassResponse, GetInsightClassForAccountError, CloudflareOpContext>;
export type GetInsightClassForZoneError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by classification class. */
export declare const getInsightClassForZone: API.OperationMethod<GetInsightClassForZoneRequest, GetInsightClassResponse, GetInsightClassForZoneError, CloudflareOpContext>;
export type GetInsightContextError = CloudflareOpError;
/** Returns the full context payload for an insight. This endpoint is used for insights with large payloads that are not included inline in the list response. */
export declare const getInsightContext: API.OperationMethod<GetInsightContextRequest, GetInsightContextResponse, GetInsightContextError, CloudflareOpContext>;
export type GetInsightSeverityForAccountError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by severity level (critical, high, medium, low). */
export declare const getInsightSeverityForAccount: API.OperationMethod<GetInsightSeverityForAccountRequest, GetInsightSeverityResponse, GetInsightSeverityForAccountError, CloudflareOpContext>;
export type GetInsightSeverityForZoneError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by severity level (critical, high, medium, low). */
export declare const getInsightSeverityForZone: API.OperationMethod<GetInsightSeverityForZoneRequest, GetInsightSeverityResponse, GetInsightSeverityForZoneError, CloudflareOpContext>;
export type GetInsightTypeForAccountError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by insight type. */
export declare const getInsightTypeForAccount: API.OperationMethod<GetInsightTypeForAccountRequest, GetInsightTypeResponse, GetInsightTypeForAccountError, CloudflareOpContext>;
export type GetInsightTypeForZoneError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by insight type. */
export declare const getInsightTypeForZone: API.OperationMethod<GetInsightTypeForZoneRequest, GetInsightTypeResponse, GetInsightTypeForZoneError, CloudflareOpContext>;
export type ListByInsightInsightAuditLogForAccountError = CloudflareOpError;
/** Lists audit log entries for a specific Security Center insight, showing changes to its status and classification over time. */
export declare const listByInsightInsightAuditLogForAccount: API.PaginatedOperationMethod<ListByInsightInsightAuditLogForAccountRequest, ListByInsightInsightAuditLogResponse, ListByInsightInsightAuditLogForAccountError, CloudflareOpContext, InsightsAuditLogsListByInsightResultItem>;
export type ListByInsightInsightAuditLogForZoneError = CloudflareOpError;
/** Lists audit log entries for a specific Security Center insight, showing changes to its status and classification over time. */
export declare const listByInsightInsightAuditLogForZone: API.PaginatedOperationMethod<ListByInsightInsightAuditLogForZoneRequest, ListByInsightInsightAuditLogResponse, ListByInsightInsightAuditLogForZoneError, CloudflareOpContext, InsightsAuditLogsListByInsightResultItem>;
export type ListInsightAuditLogsForAccountError = CloudflareOpError;
/** Lists audit log entries for all Security Center insights in the account or zone, showing changes to insight status and classification. */
export declare const listInsightAuditLogsForAccount: API.PaginatedOperationMethod<ListInsightAuditLogsForAccountRequest, ListInsightAuditLogsResponse, ListInsightAuditLogsForAccountError, CloudflareOpContext, InsightsAuditLogsListResultItem>;
export type ListInsightAuditLogsForZoneError = CloudflareOpError;
/** Lists audit log entries for all Security Center insights in the account or zone, showing changes to insight status and classification. */
export declare const listInsightAuditLogsForZone: API.PaginatedOperationMethod<ListInsightAuditLogsForZoneRequest, ListInsightAuditLogsResponse, ListInsightAuditLogsForZoneError, CloudflareOpContext, InsightsAuditLogsListResultItem>;
export type ListInsightsForAccountError = CloudflareOpError;
/** Lists all Security Center insights for the account or zone, showing security findings and recommendations. */
export declare const listInsightsForAccount: API.OperationMethod<ListInsightsForAccountRequest, ListInsightsResponse, ListInsightsForAccountError, CloudflareOpContext>;
export type ListInsightsForZoneError = CloudflareOpError;
/** Lists all Security Center insights for the account or zone, showing security findings and recommendations. */
export declare const listInsightsForZone: API.OperationMethod<ListInsightsForZoneRequest, ListInsightsResponse, ListInsightsForZoneError, CloudflareOpContext>;
export type PatchInsightClassificationForAccountError = CloudflareOpError;
/** Updates the user classification for a Security Center insight. Valid values are 'false_positive' or 'accept_risk'. To reset, set classification to null. Cannot change directly between classification values - must reset to null first. */
export declare const patchInsightClassificationForAccount: API.OperationMethod<PatchInsightClassificationForAccountRequest, PatchInsightClassificationForAccountResponse, PatchInsightClassificationForAccountError, CloudflareOpContext>;
export type PatchInsightClassificationForZoneError = CloudflareOpError;
/** Updates the user classification for a Security Center insight. Valid values are 'false_positive' or 'accept_risk'. To reset, set classification to null. Cannot change directly between classification values - must reset to null first. */
export declare const patchInsightClassificationForZone: API.OperationMethod<PatchInsightClassificationForZoneRequest, PatchInsightClassificationForZoneResponse, PatchInsightClassificationForZoneError, CloudflareOpContext>;
//# sourceMappingURL=security_center.d.ts.map