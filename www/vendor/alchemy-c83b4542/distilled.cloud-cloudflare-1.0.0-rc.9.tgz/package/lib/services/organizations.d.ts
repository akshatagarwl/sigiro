import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OrganizationNotFound_base: S.Class<OrganizationNotFound, S.TaggedStruct<"OrganizationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OrganizationNotFound extends /*@__PURE__*/ OrganizationNotFound_base {
}
export interface CreateMemberRequestMemberUser {
    email: string;
}
export declare const CreateMemberRequestMemberUser: S.Schema<CreateMemberRequestMemberUser>;
export type CreateMemberRequestMemberStatus = "active" | "canceled";
export declare const CreateMemberRequestMemberStatus: any;
export interface CreateMemberRequestMember {
    user: CreateMemberRequestMemberUser;
    status?: CreateMemberRequestMemberStatus | (string & {});
}
export declare const CreateMemberRequestMember: S.Schema<CreateMemberRequestMember>;
export interface CreateMemberRequest {
    organizationId: string;
    member: CreateMemberRequestMember;
}
export declare const CreateMemberRequest: S.Schema<CreateMemberRequest>;
export type CreateMemberResponseMetaMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateMemberResponseMetaMap: S.Schema<CreateMemberResponseMetaMap>;
export type CreateMemberResponseStatus = "active" | "canceled";
export declare const CreateMemberResponseStatus: any;
export interface CreateMemberResponseUser {
    id: string;
    email: string;
    name: string;
    twoFactorAuthenticationEnabled: boolean;
}
export declare const CreateMemberResponseUser: S.Schema<CreateMemberResponseUser>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMemberResponse {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: CreateMemberResponseMetaMap;
    status: CreateMemberResponseStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
}
export declare const CreateMemberResponse: S.Schema<CreateMemberResponse>;
export interface CreateRequestParent {
    id: string;
    name?: string;
}
export declare const CreateRequestParent: S.Schema<CreateRequestParent>;
export interface CreateRequestProfile {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export declare const CreateRequestProfile: S.Schema<CreateRequestProfile>;
export interface CreateOrganizationRequest {
    name: string;
    parent?: CreateRequestParent;
    profile?: CreateRequestProfile;
}
export declare const CreateOrganizationRequest: S.Schema<CreateOrganizationRequest>;
export interface CreateResponseMetaFlags {
    accountCreation: string;
    accountDeletion: string;
    accountMigration: string;
    accountMobility: string;
    subOrgCreation: string;
}
export declare const CreateResponseMetaFlags: S.Schema<CreateResponseMetaFlags>;
export type CreateResponseMetaHierarchyTagsList = Array<string>;
export declare const CreateResponseMetaHierarchyTagsList: S.Schema<CreateResponseMetaHierarchyTagsList>;
export interface CreateResponseMeta {
    /** Enable features for Organizations. */
    flags?: CreateResponseMetaFlags | null;
    /** Ordered chain of organization tags from the root organization down to */
    hierarchyTags?: CreateResponseMetaHierarchyTagsList | null;
    managedBy?: string | null;
}
export declare const CreateResponseMeta: S.Schema<CreateResponseMeta>;
export interface CreateResponseParent {
    id: string;
    name: string;
}
export declare const CreateResponseParent: S.Schema<CreateResponseParent>;
export type CreateResponseProfile = CreateRequestProfile;
export declare const CreateResponseProfile: S.Schema<CreateRequestProfile>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOrganizationResponse {
    id: string;
    createTime: string;
    meta: CreateResponseMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export declare const CreateOrganizationResponse: S.Schema<CreateOrganizationResponse>;
export interface DeleteMemberRequest {
    organizationId: string;
    /** Organization Member ID */
    memberId: string;
}
export declare const DeleteMemberRequest: S.Schema<DeleteMemberRequest>;
export interface DeleteMemberResponse {
}
export declare const DeleteMemberResponse: S.Schema<DeleteMemberResponse>;
export interface DeleteOrganizationRequest {
    organizationId: string;
}
export declare const DeleteOrganizationRequest: S.Schema<DeleteOrganizationRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOrganizationResponse {
    id: string;
}
export declare const DeleteOrganizationResponse: S.Schema<DeleteOrganizationResponse>;
export interface GetBillingUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    organizationId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string;
    /** Filter results by billable metric id (e.g., workers_standard_requests). */
    metric?: string;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string;
}
export declare const GetBillingUsageRequest: S.Schema<GetBillingUsageRequest>;
export type BillingUsageGetResultItemChargeCategory = "Usage";
export declare const BillingUsageGetResultItemChargeCategory: any;
export type BillingUsageGetResultItemChargeFrequency = "Usage-Based";
export declare const BillingUsageGetResultItemChargeFrequency: any;
export type BillingUsageGetResultItemChargeClass = "Correction";
export declare const BillingUsageGetResultItemChargeClass: any;
export interface BillingUsageGetResultItem {
    /** Public identifier of the Cloudflare account (account tag). */
    billingAccountId: string;
    /** Display name of the Cloudflare account. */
    billingAccountName: string;
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: BillingUsageGetResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: BillingUsageGetResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity: number;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: BillingUsageGetResultItemChargeClass | null;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId?: string | null;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null;
    /** The identifier for the Cloudflare zone (zone tag). Cloudflare extension. */
    xZoneId?: string | null;
    /** The display name of the Cloudflare zone. Cloudflare extension. */
    xZoneName?: string | null;
}
export declare const BillingUsageGetResultItem: S.Schema<BillingUsageGetResultItem>;
export type BillingUsageGetResultList = Array<BillingUsageGetResultItem>;
export declare const BillingUsageGetResultList: S.Schema<BillingUsageGetResultList>;
export type GetBillingUsageResponse = BillingUsageGetResultList;
export declare const GetBillingUsageResponse: S.Schema<GetBillingUsageResponse>;
export interface GetMemberRequest {
    organizationId: string;
    /** Organization Member ID */
    memberId: string;
}
export declare const GetMemberRequest: S.Schema<GetMemberRequest>;
export type GetMemberResponseMetaMap = {
    [key: string]: unknown | undefined;
};
export declare const GetMemberResponseMetaMap: S.Schema<GetMemberResponseMetaMap>;
export type GetMemberResponseStatus = "active" | "canceled";
export declare const GetMemberResponseStatus: any;
export type GetMemberResponseUser = CreateMemberResponseUser;
export declare const GetMemberResponseUser: S.Schema<CreateMemberResponseUser>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMemberResponse {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: GetMemberResponseMetaMap;
    status: GetMemberResponseStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
}
export declare const GetMemberResponse: S.Schema<GetMemberResponse>;
export interface GetOrganizationRequest {
    organizationId: string;
}
export declare const GetOrganizationRequest: S.Schema<GetOrganizationRequest>;
export type GetResponseMetaFlags = CreateResponseMetaFlags;
export declare const GetResponseMetaFlags: S.Schema<CreateResponseMetaFlags>;
export type GetResponseMetaHierarchyTagsList = Array<string>;
export declare const GetResponseMetaHierarchyTagsList: S.Schema<GetResponseMetaHierarchyTagsList>;
export interface GetResponseMeta {
    /** Enable features for Organizations. */
    flags?: CreateResponseMetaFlags | null;
    /** Ordered chain of organization tags from the root organization down to */
    hierarchyTags?: GetResponseMetaHierarchyTagsList | null;
    managedBy?: string | null;
}
export declare const GetResponseMeta: S.Schema<GetResponseMeta>;
export type GetResponseParent = CreateResponseParent;
export declare const GetResponseParent: S.Schema<CreateResponseParent>;
export type GetResponseProfile = CreateRequestProfile;
export declare const GetResponseProfile: S.Schema<CreateRequestProfile>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOrganizationResponse {
    id: string;
    createTime: string;
    meta: GetResponseMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export declare const GetOrganizationResponse: S.Schema<GetOrganizationResponse>;
export interface GetOrganizationAccountRequestAccountPubname {
    /** (case-insensitive) Filter the list of accounts to where the account_pubname contains */
    contains?: string;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname ends with */
    endsWith?: string;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname starts with */
    startsWith?: string;
}
export declare const GetOrganizationAccountRequestAccountPubname: S.Schema<GetOrganizationAccountRequestAccountPubname>;
export type GetOrganizationAccountRequestDirection = "asc" | "desc";
export declare const GetOrganizationAccountRequestDirection: any;
export interface GetOrganizationAccountRequestName {
    /** (case-insensitive) Filter the list of accounts to where the name contains a particular */
    contains?: string;
    /** (case-insensitive) Filter the list of accounts to where the name ends with a particular */
    endsWith?: string;
    /** (case-insensitive) Filter the list of accounts to where the name starts with a */
    startsWith?: string;
}
export declare const GetOrganizationAccountRequestName: S.Schema<GetOrganizationAccountRequestName>;
export type GetOrganizationAccountRequestOrderBy = "account_name";
export declare const GetOrganizationAccountRequestOrderBy: any;
export interface GetOrganizationAccountRequest {
    organizationId: string;
    accountPubname?: GetOrganizationAccountRequestAccountPubname;
    /** Sort direction for the order_by field. Valid values: `asc`, `desc`. */
    direction?: GetOrganizationAccountRequestDirection | (string & {});
    name?: GetOrganizationAccountRequestName;
    /** Field to order results by. Currently supported values: `account_name`. */
    orderBy?: GetOrganizationAccountRequestOrderBy | (string & {});
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number;
    /** An opaque token returned from the last list response that when */
    pageToken?: string;
}
export declare const GetOrganizationAccountRequest: S.Schema<GetOrganizationAccountRequest>;
export interface GetOrganizationAccountResultItemSettings {
    abuseContactEmail: string;
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    defaultNameservers: string;
    enforceTwofactor: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    useAccountCustomNsByDefault: boolean;
}
export declare const GetOrganizationAccountResultItemSettings: S.Schema<GetOrganizationAccountResultItemSettings>;
export type GetOrganizationAccountResultItemType = "standard" | "enterprise";
export declare const GetOrganizationAccountResultItemType: any;
export interface GetOrganizationAccountResultItem {
    id: string;
    createdOn: string;
    name: string;
    settings: GetOrganizationAccountResultItemSettings;
    type: GetOrganizationAccountResultItemType;
}
export declare const GetOrganizationAccountResultItem: S.Schema<GetOrganizationAccountResultItem>;
export type GetOrganizationAccountResultList = Array<GetOrganizationAccountResultItem>;
export declare const GetOrganizationAccountResultList: S.Schema<GetOrganizationAccountResultList>;
export type GetOrganizationAccountResponse = GetOrganizationAccountResultList;
export declare const GetOrganizationAccountResponse: S.Schema<GetOrganizationAccountResponse>;
export interface GetOrganizationProfileRequest {
    organizationId: string;
}
export declare const GetOrganizationProfileRequest: S.Schema<GetOrganizationProfileRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOrganizationProfileResponse {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export declare const GetOrganizationProfileResponse: S.Schema<GetOrganizationProfileResponse>;
export type LogsAuditListRequestIdNotList = Array<string>;
export declare const LogsAuditListRequestIdNotList: S.Schema<LogsAuditListRequestIdNotList>;
export interface LogsAuditListRequestId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestIdNotList;
}
export declare const LogsAuditListRequestId: S.Schema<LogsAuditListRequestId>;
export type LogsAuditListRequestActionResultNotItem = "success" | "failure";
export declare const LogsAuditListRequestActionResultNotItem: any;
export type LogsAuditListRequestActionResultNotList = Array<LogsAuditListRequestActionResultNotItem | (string & {})>;
export declare const LogsAuditListRequestActionResultNotList: S.Schema<LogsAuditListRequestActionResultNotList>;
export interface LogsAuditListRequestActionResult {
    /** Filters out audit logs by whether the action was successful or not. */
    not?: LogsAuditListRequestActionResultNotList;
}
export declare const LogsAuditListRequestActionResult: S.Schema<LogsAuditListRequestActionResult>;
export type LogsAuditListRequestActionTypeNotItem = "create" | "delete" | "view" | "update";
export declare const LogsAuditListRequestActionTypeNotItem: any;
export type LogsAuditListRequestActionTypeNotList = Array<LogsAuditListRequestActionTypeNotItem | (string & {})>;
export declare const LogsAuditListRequestActionTypeNotList: S.Schema<LogsAuditListRequestActionTypeNotList>;
export interface LogsAuditListRequestActionType {
    /** Filters out audit logs by the action type. */
    not?: LogsAuditListRequestActionTypeNotList;
}
export declare const LogsAuditListRequestActionType: S.Schema<LogsAuditListRequestActionType>;
export type LogsAuditListRequestActorContextNotItem = "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export declare const LogsAuditListRequestActorContextNotItem: any;
export type LogsAuditListRequestActorContextNotList = Array<LogsAuditListRequestActorContextNotItem | (string & {})>;
export declare const LogsAuditListRequestActorContextNotList: S.Schema<LogsAuditListRequestActorContextNotList>;
export interface LogsAuditListRequestActorContext {
    /** Filters out audit logs by the actor context. */
    not?: LogsAuditListRequestActorContextNotList;
}
export declare const LogsAuditListRequestActorContext: S.Schema<LogsAuditListRequestActorContext>;
export type LogsAuditListRequestActorEmailNotList = Array<string>;
export declare const LogsAuditListRequestActorEmailNotList: S.Schema<LogsAuditListRequestActorEmailNotList>;
export interface LogsAuditListRequestActorEmail {
    /** Filters out audit logs by the actor's email address. */
    not?: LogsAuditListRequestActorEmailNotList;
}
export declare const LogsAuditListRequestActorEmail: S.Schema<LogsAuditListRequestActorEmail>;
export type LogsAuditListRequestActorIdNotList = Array<string>;
export declare const LogsAuditListRequestActorIdNotList: S.Schema<LogsAuditListRequestActorIdNotList>;
export interface LogsAuditListRequestActorId {
    /** Filters out audit logs by the actor's user ID. */
    not?: LogsAuditListRequestActorIdNotList;
}
export declare const LogsAuditListRequestActorId: S.Schema<LogsAuditListRequestActorId>;
export type LogsAuditListRequestActorIpAddressNotList = Array<string>;
export declare const LogsAuditListRequestActorIpAddressNotList: S.Schema<LogsAuditListRequestActorIpAddressNotList>;
export interface LogsAuditListRequestActorIpAddress {
    /** Filters out audit logs IP address where the action was initiated. */
    not?: LogsAuditListRequestActorIpAddressNotList;
}
export declare const LogsAuditListRequestActorIpAddress: S.Schema<LogsAuditListRequestActorIpAddress>;
export type LogsAuditListRequestActorTokenIdNotList = Array<string>;
export declare const LogsAuditListRequestActorTokenIdNotList: S.Schema<LogsAuditListRequestActorTokenIdNotList>;
export interface LogsAuditListRequestActorTokenId {
    /** Filters out audit logs by the API token ID when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenIdNotList;
}
export declare const LogsAuditListRequestActorTokenId: S.Schema<LogsAuditListRequestActorTokenId>;
export type LogsAuditListRequestActorTokenNameNotList = Array<string>;
export declare const LogsAuditListRequestActorTokenNameNotList: S.Schema<LogsAuditListRequestActorTokenNameNotList>;
export interface LogsAuditListRequestActorTokenName {
    /** Filters out audit logs by the API token name when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenNameNotList;
}
export declare const LogsAuditListRequestActorTokenName: S.Schema<LogsAuditListRequestActorTokenName>;
export type LogsAuditListRequestActorTypeNotItem = "cloudflare_admin" | "system" | "user";
export declare const LogsAuditListRequestActorTypeNotItem: any;
export type LogsAuditListRequestActorTypeNotList = Array<LogsAuditListRequestActorTypeNotItem | (string & {})>;
export declare const LogsAuditListRequestActorTypeNotList: S.Schema<LogsAuditListRequestActorTypeNotList>;
export interface LogsAuditListRequestActorType {
    /** Filters out audit logs by the actor type. */
    not?: LogsAuditListRequestActorTypeNotList;
}
export declare const LogsAuditListRequestActorType: S.Schema<LogsAuditListRequestActorType>;
export type LogsAuditListRequestDirection = "desc" | "asc";
export declare const LogsAuditListRequestDirection: any;
export type LogsAuditListRequestRawCfRayIdNotList = Array<string>;
export declare const LogsAuditListRequestRawCfRayIdNotList: S.Schema<LogsAuditListRequestRawCfRayIdNotList>;
export interface LogsAuditListRequestRawCfRayId {
    /** Filters out audit logs by the response CF Ray ID. */
    not?: LogsAuditListRequestRawCfRayIdNotList;
}
export declare const LogsAuditListRequestRawCfRayId: S.Schema<LogsAuditListRequestRawCfRayId>;
export type LogsAuditListRequestRawMethodNotList = Array<string>;
export declare const LogsAuditListRequestRawMethodNotList: S.Schema<LogsAuditListRequestRawMethodNotList>;
export interface LogsAuditListRequestRawMethod {
    /** Filters out audit logs by the HTTP method for the API call. */
    not?: LogsAuditListRequestRawMethodNotList;
}
export declare const LogsAuditListRequestRawMethod: S.Schema<LogsAuditListRequestRawMethod>;
export type LogsAuditListRequestRawStatusCodeNotList = Array<number>;
export declare const LogsAuditListRequestRawStatusCodeNotList: S.Schema<LogsAuditListRequestRawStatusCodeNotList>;
export interface LogsAuditListRequestRawStatusCode {
    /** Filters out audit logs by the response status code that was returned. */
    not?: LogsAuditListRequestRawStatusCodeNotList;
}
export declare const LogsAuditListRequestRawStatusCode: S.Schema<LogsAuditListRequestRawStatusCode>;
export type LogsAuditListRequestRawUriNotList = Array<string>;
export declare const LogsAuditListRequestRawUriNotList: S.Schema<LogsAuditListRequestRawUriNotList>;
export interface LogsAuditListRequestRawUri {
    /** Filters out audit logs by the request URI. */
    not?: LogsAuditListRequestRawUriNotList;
}
export declare const LogsAuditListRequestRawUri: S.Schema<LogsAuditListRequestRawUri>;
export type LogsAuditListRequestResourceIdNotList = Array<string>;
export declare const LogsAuditListRequestResourceIdNotList: S.Schema<LogsAuditListRequestResourceIdNotList>;
export interface LogsAuditListRequestResourceId {
    /** Filters out audit logs by the resource ID. */
    not?: LogsAuditListRequestResourceIdNotList;
}
export declare const LogsAuditListRequestResourceId: S.Schema<LogsAuditListRequestResourceId>;
export type LogsAuditListRequestResourceProductNotList = Array<string>;
export declare const LogsAuditListRequestResourceProductNotList: S.Schema<LogsAuditListRequestResourceProductNotList>;
export interface LogsAuditListRequestResourceProduct {
    /** Filters out audit logs by the Cloudflare product associated with the changed resource. */
    not?: LogsAuditListRequestResourceProductNotList;
}
export declare const LogsAuditListRequestResourceProduct: S.Schema<LogsAuditListRequestResourceProduct>;
export type LogsAuditListRequestResourceScopeNotItem = "organizations";
export declare const LogsAuditListRequestResourceScopeNotItem: any;
export type LogsAuditListRequestResourceScopeNotList = Array<LogsAuditListRequestResourceScopeNotItem | (string & {})>;
export declare const LogsAuditListRequestResourceScopeNotList: S.Schema<LogsAuditListRequestResourceScopeNotList>;
export interface LogsAuditListRequestResourceScope {
    /** Filters out audit logs by the resource scope, specifying whether the resource is associated with an organization. */
    not?: LogsAuditListRequestResourceScopeNotList;
}
export declare const LogsAuditListRequestResourceScope: S.Schema<LogsAuditListRequestResourceScope>;
export type LogsAuditListRequestResourceTypeNotList = Array<string>;
export declare const LogsAuditListRequestResourceTypeNotList: S.Schema<LogsAuditListRequestResourceTypeNotList>;
export interface LogsAuditListRequestResourceType {
    /** Filters out audit logs based on the unique type of resource changed by the action. */
    not?: LogsAuditListRequestResourceTypeNotList;
}
export declare const LogsAuditListRequestResourceType: S.Schema<LogsAuditListRequestResourceType>;
export interface ListLogAuditsRequest {
    /** The unique id that identifies the organization. */
    organizationId: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    id?: LogsAuditListRequestId;
    actionResult?: LogsAuditListRequestActionResult;
    actionType?: LogsAuditListRequestActionType;
    actorContext?: LogsAuditListRequestActorContext;
    actorEmail?: LogsAuditListRequestActorEmail;
    actorId?: LogsAuditListRequestActorId;
    actorIpAddress?: LogsAuditListRequestActorIpAddress;
    actorTokenId?: LogsAuditListRequestActorTokenId;
    actorTokenName?: LogsAuditListRequestActorTokenName;
    actorType?: LogsAuditListRequestActorType;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string;
    /** Sets sorting order. */
    direction?: LogsAuditListRequestDirection | (string & {});
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
    rawCfRayId?: LogsAuditListRequestRawCfRayId;
    rawMethod?: LogsAuditListRequestRawMethod;
    rawStatusCode?: LogsAuditListRequestRawStatusCode;
    rawUri?: LogsAuditListRequestRawUri;
    resourceId?: LogsAuditListRequestResourceId;
    resourceProduct?: LogsAuditListRequestResourceProduct;
    resourceScope?: LogsAuditListRequestResourceScope;
    resourceType?: LogsAuditListRequestResourceType;
}
export declare const ListLogAuditsRequest: S.Schema<ListLogAuditsRequest>;
export interface LogsAuditListResultItemAction {
    /** A short description of the action performed. */
    description?: string | null;
    /** The result of the action, indicating success or failure. */
    result?: string | null;
    /** A timestamp indicating when the action was logged. */
    time?: string | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export declare const LogsAuditListResultItemAction: S.Schema<LogsAuditListResultItemAction>;
export type LogsAuditListResultItemActorContext = "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export declare const LogsAuditListResultItemActorContext: any;
export type LogsAuditListResultItemActorType = "cloudflare_admin" | "system" | "user";
export declare const LogsAuditListResultItemActorType: any;
export interface LogsAuditListResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    context?: LogsAuditListResultItemActorContext | null;
    /** The email of the actor who performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null;
    /** The type of actor. */
    type?: LogsAuditListResultItemActorType | null;
}
export declare const LogsAuditListResultItemActor: S.Schema<LogsAuditListResultItemActor>;
export interface LogsAuditListResultItemOrganization {
    /** A unique identifier for the organization. */
    id?: string | null;
}
export declare const LogsAuditListResultItemOrganization: S.Schema<LogsAuditListResultItemOrganization>;
export interface LogsAuditListResultItemRaw {
    /** The Cloudflare Ray ID for the request. */
    cfRayId?: string | null;
    /** The HTTP method of the request. */
    method?: string | null;
    /** The HTTP response status code returned by the API. */
    statusCode?: number | null;
    /** The URI of the request. */
    uri?: string | null;
    /** The client's user agent string sent with the request. */
    userAgent?: string | null;
}
export declare const LogsAuditListResultItemRaw: S.Schema<LogsAuditListResultItemRaw>;
export interface LogsAuditListResultItemResource {
    /** The unique identifier for the affected resource. */
    id?: string | null;
    /** The Cloudflare product associated with the resource. */
    product?: string | null;
    request?: unknown | null;
    response?: unknown | null;
    /** The scope of the resource. */
    scope?: unknown | null;
    /** The type of the resource. */
    type?: string | null;
}
export declare const LogsAuditListResultItemResource: S.Schema<LogsAuditListResultItemResource>;
export interface LogsAuditListResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditListResultItemActor | null;
    /** Contains organization related information. */
    organization?: LogsAuditListResultItemOrganization | null;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null;
}
export declare const LogsAuditListResultItem: S.Schema<LogsAuditListResultItem>;
export type LogsAuditListResultList = Array<LogsAuditListResultItem>;
export declare const LogsAuditListResultList: S.Schema<LogsAuditListResultList>;
export interface ListLogAuditsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsAuditListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLogAuditsResponse: S.Schema<ListLogAuditsResponse>;
export type ListMembersRequestStatus = "active" | "canceled";
export declare const ListMembersRequestStatus: any;
export type ListMembersRequestStatusList = Array<ListMembersRequestStatus | (string & {})>;
export declare const ListMembersRequestStatusList: S.Schema<ListMembersRequestStatusList>;
export interface ListMembersRequestUser {
    /** Filter the list of memberships for a specific email that ends with a substring. */
    email?: string;
}
export declare const ListMembersRequestUser: S.Schema<ListMembersRequestUser>;
export interface ListMembersRequest {
    organizationId: string;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number;
    /** An opaque token returned from the last list response that when */
    pageToken?: string;
    /** Filter the list of memberships by membership status. */
    status?: ListMembersRequestStatusList;
    user?: ListMembersRequestUser;
}
export declare const ListMembersRequest: S.Schema<ListMembersRequest>;
export type ListMembersResultItemMetaMap = {
    [key: string]: unknown | undefined;
};
export declare const ListMembersResultItemMetaMap: S.Schema<ListMembersResultItemMetaMap>;
export type ListMembersResultItemStatus = "active" | "canceled";
export declare const ListMembersResultItemStatus: any;
export type ListMembersResultItemUser = CreateMemberResponseUser;
export declare const ListMembersResultItemUser: S.Schema<CreateMemberResponseUser>;
export interface ListMembersResultItem {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: ListMembersResultItemMetaMap;
    status: ListMembersResultItemStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
}
export declare const ListMembersResultItem: S.Schema<ListMembersResultItem>;
export type ListMembersResultList = Array<ListMembersResultItem>;
export declare const ListMembersResultList: S.Schema<ListMembersResultList>;
export type ListMembersResponse = ListMembersResultList;
export declare const ListMembersResponse: S.Schema<ListMembersResponse>;
export type ListRequestIdList = Array<string>;
export declare const ListRequestIdList: S.Schema<ListRequestIdList>;
export interface ListRequestContaining {
    /** Filter the list of organizations to the ones that contain this particular */
    account?: string;
    /** Filter the list of organizations to the ones that contain this particular */
    organization?: string;
    /** Filter the list of organizations to the ones that contain this particular */
    user?: string;
}
export declare const ListRequestContaining: S.Schema<ListRequestContaining>;
export interface ListRequestName {
    /** (case-insensitive) Filter the list of organizations to where the name contains a particular */
    contains?: string;
    /** (case-insensitive) Filter the list of organizations to where the name ends with a particular */
    endsWith?: string;
    /** (case-insensitive) Filter the list of organizations to where the name starts with a */
    startsWith?: string;
}
export declare const ListRequestName: S.Schema<ListRequestName>;
export interface ListRequestParent {
    /** Filter the list of organizations to the ones that are a sub-organization */
    id?: string;
}
export declare const ListRequestParent: S.Schema<ListRequestParent>;
export interface ListOrganizationsRequest {
    /** Only return organizations with the specified IDs (ex. id=foo&id=bar). Send multiple elements */
    id?: ListRequestIdList;
    containing?: ListRequestContaining;
    name?: ListRequestName;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number;
    /** An opaque token returned from the last list response that when */
    pageToken?: string;
    parent?: ListRequestParent;
}
export declare const ListOrganizationsRequest: S.Schema<ListOrganizationsRequest>;
export type ListResultItemMetaFlags = CreateResponseMetaFlags;
export declare const ListResultItemMetaFlags: S.Schema<CreateResponseMetaFlags>;
export type ListResultItemMetaHierarchyTagsList = Array<string>;
export declare const ListResultItemMetaHierarchyTagsList: S.Schema<ListResultItemMetaHierarchyTagsList>;
export interface ListResultItemMeta {
    /** Enable features for Organizations. */
    flags?: CreateResponseMetaFlags | null;
    /** Ordered chain of organization tags from the root organization down to */
    hierarchyTags?: ListResultItemMetaHierarchyTagsList | null;
    managedBy?: string | null;
}
export declare const ListResultItemMeta: S.Schema<ListResultItemMeta>;
export type ListResultItemParent = CreateResponseParent;
export declare const ListResultItemParent: S.Schema<CreateResponseParent>;
export type ListResultItemProfile = CreateRequestProfile;
export declare const ListResultItemProfile: S.Schema<CreateRequestProfile>;
export interface ListResultItem {
    id: string;
    createTime: string;
    meta: ListResultItemMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListOrganizationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOrganizationsResponse: S.Schema<ListOrganizationsResponse>;
export interface PutOrganizationProfileRequest {
    organizationId: string;
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export declare const PutOrganizationProfileRequest: S.Schema<PutOrganizationProfileRequest>;
export interface PutOrganizationProfileResponse {
}
export declare const PutOrganizationProfileResponse: S.Schema<PutOrganizationProfileResponse>;
export type UpdateRequestParent = CreateRequestParent;
export declare const UpdateRequestParent: S.Schema<CreateRequestParent>;
export type UpdateRequestProfile = CreateRequestProfile;
export declare const UpdateRequestProfile: S.Schema<CreateRequestProfile>;
export interface UpdateOrganizationRequest {
    organizationId: string;
    name: string;
    parent?: CreateRequestParent;
    profile?: CreateRequestProfile;
}
export declare const UpdateOrganizationRequest: S.Schema<UpdateOrganizationRequest>;
export type UpdateResponseMetaFlags = CreateResponseMetaFlags;
export declare const UpdateResponseMetaFlags: S.Schema<CreateResponseMetaFlags>;
export type UpdateResponseMetaHierarchyTagsList = Array<string>;
export declare const UpdateResponseMetaHierarchyTagsList: S.Schema<UpdateResponseMetaHierarchyTagsList>;
export interface UpdateResponseMeta {
    /** Enable features for Organizations. */
    flags?: CreateResponseMetaFlags | null;
    /** Ordered chain of organization tags from the root organization down to */
    hierarchyTags?: UpdateResponseMetaHierarchyTagsList | null;
    managedBy?: string | null;
}
export declare const UpdateResponseMeta: S.Schema<UpdateResponseMeta>;
export type UpdateResponseParent = CreateResponseParent;
export declare const UpdateResponseParent: S.Schema<CreateResponseParent>;
export type UpdateResponseProfile = CreateRequestProfile;
export declare const UpdateResponseProfile: S.Schema<CreateRequestProfile>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOrganizationResponse {
    id: string;
    createTime: string;
    meta: UpdateResponseMeta;
    name: string;
    parent?: CreateResponseParent | null;
    profile?: CreateRequestProfile | null;
}
export declare const UpdateOrganizationResponse: S.Schema<UpdateOrganizationResponse>;
export type CreateMemberError = CloudflareOpError;
/** Create a membership that grants access to a specific Organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const createMember: API.OperationMethod<CreateMemberRequest, CreateMemberResponse, CreateMemberError, CloudflareOpContext>;
export type CreateOrganizationError = Forbidden | CloudflareOpError;
/** Create a new organization for a user. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const createOrganization: API.OperationMethod<CreateOrganizationRequest, CreateOrganizationResponse, CreateOrganizationError, CloudflareOpContext>;
export type DeleteMemberError = CloudflareOpError;
/** Delete a membership to a particular Organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest, DeleteMemberResponse, DeleteMemberError, CloudflareOpContext>;
export type DeleteOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Delete an organization. The organization MUST be empty before deleting. It must not contain any sub-organizations, accounts, members or users. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) **Access Control:** Restricted to enterprise organizations. */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest, DeleteOrganizationResponse, DeleteOrganizationError, CloudflareOpContext>;
export type GetBillingUsageError = CloudflareOpError;
/** Returns cost and usage data for all accounts within an organization, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. The response includes usage for every account belonging to the specified organization. **Note:** Cost and pricing fields are not yet populated and will be absent from responses until billing integration is complete. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. */
export declare const getBillingUsage: API.OperationMethod<GetBillingUsageRequest, GetBillingUsageResponse, GetBillingUsageError, CloudflareOpContext>;
export type GetMemberError = CloudflareOpError;
/** Retrieve a single membership from an Organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const getMember: API.OperationMethod<GetMemberRequest, GetMemberResponse, GetMemberError, CloudflareOpContext>;
export type GetOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Retrieve the details of a certain organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, GetOrganizationResponse, GetOrganizationError, CloudflareOpContext>;
export type GetOrganizationAccountError = CloudflareOpError;
/** Retrieve a list of accounts that belong to a specific organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const getOrganizationAccount: API.OperationMethod<GetOrganizationAccountRequest, GetOrganizationAccountResponse, GetOrganizationAccountError, CloudflareOpContext>;
export type GetOrganizationProfileError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Get an organizations profile if it exists. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const getOrganizationProfile: API.OperationMethod<GetOrganizationProfileRequest, GetOrganizationProfileResponse, GetOrganizationProfileError, CloudflareOpContext>;
export type ListLogAuditsError = CloudflareOpError;
/** Gets a list of audit logs for an organization. */
export declare const listLogAudits: API.PaginatedOperationMethod<ListLogAuditsRequest, ListLogAuditsResponse, ListLogAuditsError, CloudflareOpContext, LogsAuditListResultItem>;
export type ListMembersError = CloudflareOpError;
/** List memberships for an Organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const listMembers: API.OperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, CloudflareOpContext>;
export type ListOrganizationsError = Forbidden | CloudflareOpError;
/** Retrieve a list of organizations a particular user has access to. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, ListOrganizationsResponse, ListOrganizationsError, CloudflareOpContext, ListResultItem>;
export type PutOrganizationProfileError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Modify organization profile. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const putOrganizationProfile: API.OperationMethod<PutOrganizationProfileRequest, PutOrganizationProfileResponse, PutOrganizationProfileError, CloudflareOpContext>;
export type UpdateOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Modify organization. (Currently in Public Beta - see https://developers.cloudflare.com/fundamentals/organizations/) */
export declare const updateOrganization: API.OperationMethod<UpdateOrganizationRequest, UpdateOrganizationResponse, UpdateOrganizationError, CloudflareOpContext>;
//# sourceMappingURL=organizations.d.ts.map