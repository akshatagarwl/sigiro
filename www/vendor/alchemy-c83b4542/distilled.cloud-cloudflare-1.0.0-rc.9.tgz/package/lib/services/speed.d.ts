import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TestScheduleAlreadyExists_base: S.Class<TestScheduleAlreadyExists, S.TaggedStruct<"TestScheduleAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TestScheduleAlreadyExists extends /*@__PURE__*/ TestScheduleAlreadyExists_base {
}
declare const TestScheduleNotFound_base: S.Class<TestScheduleNotFound, S.TaggedStruct<"TestScheduleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TestScheduleNotFound extends /*@__PURE__*/ TestScheduleNotFound_base {
}
declare const TestScheduleQuotaReached_base: S.Class<TestScheduleQuotaReached, S.TaggedStruct<"TestScheduleQuotaReached", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TestScheduleQuotaReached extends /*@__PURE__*/ TestScheduleQuotaReached_base {
}
export type PagesTestsCreateRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTestsCreateRequestRegion: any;
export interface CreatePageTestRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: PagesTestsCreateRequestRegion | (string & {});
}
export declare const CreatePageTestRequest: S.Schema<CreatePageTestRequest>;
export type PagesTestsCreateResponseDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export declare const PagesTestsCreateResponseDesktopReportDeviceType: any;
export type PagesTestsCreateResponseDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export declare const PagesTestsCreateResponseDesktopReportErrorCode: any;
export interface PagesTestsCreateResponseDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsCreateResponseDesktopReportErrorCode | null;
    /** Detailed error message. */
    detail?: string | null;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null;
}
export declare const PagesTestsCreateResponseDesktopReportError: S.Schema<PagesTestsCreateResponseDesktopReportError>;
export type PagesTestsCreateResponseDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export declare const PagesTestsCreateResponseDesktopReportState: any;
export interface PagesTestsCreateResponseDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null;
    /** The type of device. */
    deviceType?: PagesTestsCreateResponseDesktopReportDeviceType | null;
    error?: PagesTestsCreateResponseDesktopReportError | null;
    /** First Contentful Paint. */
    fcp?: number | null;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null;
    /** Largest Contentful Paint. */
    lcp?: number | null;
    /** The Lighthouse performance score. */
    performanceScore?: number | null;
    /** Speed Index. */
    si?: number | null;
    /** The state of the Lighthouse report. */
    state?: PagesTestsCreateResponseDesktopReportState | null;
    /** Total Blocking Time. */
    tbt?: number | null;
    /** Time To First Byte. */
    ttfb?: number | null;
    /** Time To Interactive. */
    tti?: number | null;
}
export declare const PagesTestsCreateResponseDesktopReport: S.Schema<PagesTestsCreateResponseDesktopReport>;
export type PagesTestsCreateResponseRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTestsCreateResponseRegionValue: any;
export interface PagesTestsCreateResponseRegion {
    label?: string | null;
    /** A test region. */
    value?: PagesTestsCreateResponseRegionValue | null;
}
export declare const PagesTestsCreateResponseRegion: S.Schema<PagesTestsCreateResponseRegion>;
export type PagesTestsCreateResponseScheduleFrequency = "DAILY" | "WEEKLY";
export declare const PagesTestsCreateResponseScheduleFrequency: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePageTestResponse {
    /** UUID. */
    id?: string | null;
    date?: string | null;
    /** The Lighthouse report. */
    desktopReport?: PagesTestsCreateResponseDesktopReport | null;
    /** The Lighthouse report. */
    mobileReport?: PagesTestsCreateResponseDesktopReport | null;
    /** A test region with a label. */
    region?: PagesTestsCreateResponseRegion | null;
    /** The frequency of the test. */
    scheduleFrequency?: PagesTestsCreateResponseScheduleFrequency | null;
    /** A URL. */
    url?: string | null;
}
export declare const CreatePageTestResponse: S.Schema<CreatePageTestResponse>;
export type ScheduleCreateRequestFrequency = "DAILY" | "WEEKLY";
export declare const ScheduleCreateRequestFrequency: any;
export type ScheduleCreateRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const ScheduleCreateRequestRegion: any;
export interface CreateScheduleRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** The frequency of the scheduled test. Defaults to WEEKLY for free plans, DAILY for paid plans. */
    frequency?: ScheduleCreateRequestFrequency | (string & {});
    /** A test region. */
    region?: ScheduleCreateRequestRegion | (string & {});
}
export declare const CreateScheduleRequest: S.Schema<CreateScheduleRequest>;
export type ScheduleCreateResponseScheduleFrequency = "DAILY" | "WEEKLY";
export declare const ScheduleCreateResponseScheduleFrequency: any;
export type ScheduleCreateResponseScheduleRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const ScheduleCreateResponseScheduleRegion: any;
export interface ScheduleCreateResponseSchedule {
    /** The frequency of the test. */
    frequency?: ScheduleCreateResponseScheduleFrequency | null;
    /** A test region. */
    region?: ScheduleCreateResponseScheduleRegion | null;
    /** A URL. */
    url?: string | null;
}
export declare const ScheduleCreateResponseSchedule: S.Schema<ScheduleCreateResponseSchedule>;
export type ScheduleCreateResponseTestDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export declare const ScheduleCreateResponseTestDesktopReportDeviceType: any;
export type ScheduleCreateResponseTestDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export declare const ScheduleCreateResponseTestDesktopReportErrorCode: any;
export interface ScheduleCreateResponseTestDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: ScheduleCreateResponseTestDesktopReportErrorCode | null;
    /** Detailed error message. */
    detail?: string | null;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null;
}
export declare const ScheduleCreateResponseTestDesktopReportError: S.Schema<ScheduleCreateResponseTestDesktopReportError>;
export type ScheduleCreateResponseTestDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export declare const ScheduleCreateResponseTestDesktopReportState: any;
export interface ScheduleCreateResponseTestDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null;
    /** The type of device. */
    deviceType?: ScheduleCreateResponseTestDesktopReportDeviceType | null;
    error?: ScheduleCreateResponseTestDesktopReportError | null;
    /** First Contentful Paint. */
    fcp?: number | null;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null;
    /** Largest Contentful Paint. */
    lcp?: number | null;
    /** The Lighthouse performance score. */
    performanceScore?: number | null;
    /** Speed Index. */
    si?: number | null;
    /** The state of the Lighthouse report. */
    state?: ScheduleCreateResponseTestDesktopReportState | null;
    /** Total Blocking Time. */
    tbt?: number | null;
    /** Time To First Byte. */
    ttfb?: number | null;
    /** Time To Interactive. */
    tti?: number | null;
}
export declare const ScheduleCreateResponseTestDesktopReport: S.Schema<ScheduleCreateResponseTestDesktopReport>;
export type ScheduleCreateResponseTestRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const ScheduleCreateResponseTestRegionValue: any;
export interface ScheduleCreateResponseTestRegion {
    label?: string | null;
    /** A test region. */
    value?: ScheduleCreateResponseTestRegionValue | null;
}
export declare const ScheduleCreateResponseTestRegion: S.Schema<ScheduleCreateResponseTestRegion>;
export type ScheduleCreateResponseTestScheduleFrequency = "DAILY" | "WEEKLY";
export declare const ScheduleCreateResponseTestScheduleFrequency: any;
export interface ScheduleCreateResponseTest {
    /** UUID. */
    id?: string | null;
    date?: string | null;
    /** The Lighthouse report. */
    desktopReport?: ScheduleCreateResponseTestDesktopReport | null;
    /** The Lighthouse report. */
    mobileReport?: ScheduleCreateResponseTestDesktopReport | null;
    /** A test region with a label. */
    region?: ScheduleCreateResponseTestRegion | null;
    /** The frequency of the test. */
    scheduleFrequency?: ScheduleCreateResponseTestScheduleFrequency | null;
    /** A URL. */
    url?: string | null;
}
export declare const ScheduleCreateResponseTest: S.Schema<ScheduleCreateResponseTest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScheduleResponse {
    /** The test schedule. */
    schedule?: ScheduleCreateResponseSchedule | null;
    test?: ScheduleCreateResponseTest | null;
}
export declare const CreateScheduleResponse: S.Schema<CreateScheduleResponse>;
export type PagesTestsDeleteRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTestsDeleteRequestRegion: any;
export interface DeletePageTestRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: PagesTestsDeleteRequestRegion | (string & {});
}
export declare const DeletePageTestRequest: S.Schema<DeletePageTestRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePageTestResponse {
    /** Number of items affected. */
    count?: number | null;
}
export declare const DeletePageTestResponse: S.Schema<DeletePageTestResponse>;
export type ScheduleDeleteRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const ScheduleDeleteRequestRegion: any;
export interface DeleteScheduleRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: ScheduleDeleteRequestRegion | (string & {});
}
export declare const DeleteScheduleRequest: S.Schema<DeleteScheduleRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteScheduleResponse {
    /** Number of items affected. */
    count?: number | null;
}
export declare const DeleteScheduleResponse: S.Schema<DeleteScheduleResponse>;
export interface GetPageTestRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    testId: string;
}
export declare const GetPageTestRequest: S.Schema<GetPageTestRequest>;
export type PagesTestsGetResponseDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export declare const PagesTestsGetResponseDesktopReportDeviceType: any;
export type PagesTestsGetResponseDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export declare const PagesTestsGetResponseDesktopReportErrorCode: any;
export interface PagesTestsGetResponseDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsGetResponseDesktopReportErrorCode | null;
    /** Detailed error message. */
    detail?: string | null;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null;
}
export declare const PagesTestsGetResponseDesktopReportError: S.Schema<PagesTestsGetResponseDesktopReportError>;
export type PagesTestsGetResponseDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export declare const PagesTestsGetResponseDesktopReportState: any;
export interface PagesTestsGetResponseDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null;
    /** The type of device. */
    deviceType?: PagesTestsGetResponseDesktopReportDeviceType | null;
    error?: PagesTestsGetResponseDesktopReportError | null;
    /** First Contentful Paint. */
    fcp?: number | null;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null;
    /** Largest Contentful Paint. */
    lcp?: number | null;
    /** The Lighthouse performance score. */
    performanceScore?: number | null;
    /** Speed Index. */
    si?: number | null;
    /** The state of the Lighthouse report. */
    state?: PagesTestsGetResponseDesktopReportState | null;
    /** Total Blocking Time. */
    tbt?: number | null;
    /** Time To First Byte. */
    ttfb?: number | null;
    /** Time To Interactive. */
    tti?: number | null;
}
export declare const PagesTestsGetResponseDesktopReport: S.Schema<PagesTestsGetResponseDesktopReport>;
export type PagesTestsGetResponseRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTestsGetResponseRegionValue: any;
export interface PagesTestsGetResponseRegion {
    label?: string | null;
    /** A test region. */
    value?: PagesTestsGetResponseRegionValue | null;
}
export declare const PagesTestsGetResponseRegion: S.Schema<PagesTestsGetResponseRegion>;
export type PagesTestsGetResponseScheduleFrequency = "DAILY" | "WEEKLY";
export declare const PagesTestsGetResponseScheduleFrequency: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPageTestResponse {
    /** UUID. */
    id?: string | null;
    date?: string | null;
    /** The Lighthouse report. */
    desktopReport?: PagesTestsGetResponseDesktopReport | null;
    /** The Lighthouse report. */
    mobileReport?: PagesTestsGetResponseDesktopReport | null;
    /** A test region with a label. */
    region?: PagesTestsGetResponseRegion | null;
    /** The frequency of the test. */
    scheduleFrequency?: PagesTestsGetResponseScheduleFrequency | null;
    /** A URL. */
    url?: string | null;
}
export declare const GetPageTestResponse: S.Schema<GetPageTestResponse>;
export type ScheduleGetRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const ScheduleGetRequestRegion: any;
export interface GetScheduleRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: ScheduleGetRequestRegion | (string & {});
}
export declare const GetScheduleRequest: S.Schema<GetScheduleRequest>;
export type ScheduleGetResponseFrequency = "DAILY" | "WEEKLY";
export declare const ScheduleGetResponseFrequency: any;
export type ScheduleGetResponseRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const ScheduleGetResponseRegion: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScheduleResponse {
    /** The frequency of the test. */
    frequency?: ScheduleGetResponseFrequency | null;
    /** A test region. */
    region?: ScheduleGetResponseRegion | null;
    /** A URL. */
    url?: string | null;
}
export declare const GetScheduleResponse: S.Schema<GetScheduleResponse>;
export interface ListAvailabilitiesRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListAvailabilitiesRequest: S.Schema<ListAvailabilitiesRequest>;
export interface AvailabilitiesListResponseQuotaQuotasPerPlanValue {
    business?: number | null;
    enterprise?: number | null;
    free?: number | null;
    pro?: number | null;
}
export declare const AvailabilitiesListResponseQuotaQuotasPerPlanValue: S.Schema<AvailabilitiesListResponseQuotaQuotasPerPlanValue>;
export interface AvailabilitiesListResponseQuotaQuotasPerPlan {
    /** Counts per account plan. */
    value?: AvailabilitiesListResponseQuotaQuotasPerPlanValue | null;
}
export declare const AvailabilitiesListResponseQuotaQuotasPerPlan: S.Schema<AvailabilitiesListResponseQuotaQuotasPerPlan>;
export type AvailabilitiesListResponseQuotaScheduleQuotasPerPlanValue = AvailabilitiesListResponseQuotaQuotasPerPlanValue;
export declare const AvailabilitiesListResponseQuotaScheduleQuotasPerPlanValue: S.Schema<AvailabilitiesListResponseQuotaQuotasPerPlanValue>;
export type AvailabilitiesListResponseQuotaScheduleQuotasPerPlan = AvailabilitiesListResponseQuotaQuotasPerPlan;
export declare const AvailabilitiesListResponseQuotaScheduleQuotasPerPlan: S.Schema<AvailabilitiesListResponseQuotaQuotasPerPlan>;
export interface AvailabilitiesListResponseQuota {
    /** Cloudflare plan. */
    plan?: string | null;
    /** The number of tests available per plan. */
    quotasPerPlan?: AvailabilitiesListResponseQuotaQuotasPerPlan | null;
    /** The number of remaining schedules available. */
    remainingSchedules?: number | null;
    /** The number of remaining tests available. */
    remainingTests?: number | null;
    /** The number of schedules available per plan. */
    scheduleQuotasPerPlan?: AvailabilitiesListResponseQuotaQuotasPerPlan | null;
}
export declare const AvailabilitiesListResponseQuota: S.Schema<AvailabilitiesListResponseQuota>;
export type AvailabilitiesListResponseRegionsItemValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const AvailabilitiesListResponseRegionsItemValue: any;
export interface AvailabilitiesListResponseRegionsItem {
    label?: string | null;
    /** A test region. */
    value?: AvailabilitiesListResponseRegionsItemValue | null;
}
export declare const AvailabilitiesListResponseRegionsItem: S.Schema<AvailabilitiesListResponseRegionsItem>;
export type AvailabilitiesListResponseRegionsList = Array<AvailabilitiesListResponseRegionsItem>;
export declare const AvailabilitiesListResponseRegionsList: S.Schema<AvailabilitiesListResponseRegionsList>;
export interface AvailabilitiesListResponseRegionsPerPlanBusinessItem {
    label?: string | null;
    /** A test region. */
    value?: string | null;
}
export declare const AvailabilitiesListResponseRegionsPerPlanBusinessItem: S.Schema<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export type AvailabilitiesListResponseRegionsPerPlanBusinessList = Array<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export declare const AvailabilitiesListResponseRegionsPerPlanBusinessList: S.Schema<AvailabilitiesListResponseRegionsPerPlanBusinessList>;
export type AvailabilitiesListResponseRegionsPerPlanEnterpriseItem = AvailabilitiesListResponseRegionsPerPlanBusinessItem;
export declare const AvailabilitiesListResponseRegionsPerPlanEnterpriseItem: S.Schema<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export type AvailabilitiesListResponseRegionsPerPlanEnterpriseList = Array<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export declare const AvailabilitiesListResponseRegionsPerPlanEnterpriseList: S.Schema<AvailabilitiesListResponseRegionsPerPlanEnterpriseList>;
export type AvailabilitiesListResponseRegionsPerPlanFreeItem = AvailabilitiesListResponseRegionsPerPlanBusinessItem;
export declare const AvailabilitiesListResponseRegionsPerPlanFreeItem: S.Schema<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export type AvailabilitiesListResponseRegionsPerPlanFreeList = Array<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export declare const AvailabilitiesListResponseRegionsPerPlanFreeList: S.Schema<AvailabilitiesListResponseRegionsPerPlanFreeList>;
export type AvailabilitiesListResponseRegionsPerPlanProItem = AvailabilitiesListResponseRegionsPerPlanBusinessItem;
export declare const AvailabilitiesListResponseRegionsPerPlanProItem: S.Schema<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export type AvailabilitiesListResponseRegionsPerPlanProList = Array<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export declare const AvailabilitiesListResponseRegionsPerPlanProList: S.Schema<AvailabilitiesListResponseRegionsPerPlanProList>;
export interface AvailabilitiesListResponseRegionsPerPlan {
    business?: AvailabilitiesListResponseRegionsPerPlanBusinessList | null;
    enterprise?: AvailabilitiesListResponseRegionsPerPlanEnterpriseList | null;
    free?: AvailabilitiesListResponseRegionsPerPlanFreeList | null;
    pro?: AvailabilitiesListResponseRegionsPerPlanProList | null;
}
export declare const AvailabilitiesListResponseRegionsPerPlan: S.Schema<AvailabilitiesListResponseRegionsPerPlan>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListAvailabilitiesResponse {
    quota?: AvailabilitiesListResponseQuota | null;
    regions?: AvailabilitiesListResponseRegionsList | null;
    /** Available regions. */
    regionsPerPlan?: AvailabilitiesListResponseRegionsPerPlan | null;
}
export declare const ListAvailabilitiesResponse: S.Schema<ListAvailabilitiesResponse>;
export interface ListPagesRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListPagesRequest: S.Schema<ListPagesRequest>;
export type PagesListResultItemRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesListResultItemRegionValue: any;
export interface PagesListResultItemRegion {
    label?: string | null;
    /** A test region. */
    value?: PagesListResultItemRegionValue | null;
}
export declare const PagesListResultItemRegion: S.Schema<PagesListResultItemRegion>;
export type PagesListResultItemScheduleFrequency = "DAILY" | "WEEKLY";
export declare const PagesListResultItemScheduleFrequency: any;
export type PagesListResultItemTestsItemDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export declare const PagesListResultItemTestsItemDesktopReportDeviceType: any;
export type PagesListResultItemTestsItemDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export declare const PagesListResultItemTestsItemDesktopReportErrorCode: any;
export interface PagesListResultItemTestsItemDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesListResultItemTestsItemDesktopReportErrorCode | null;
    /** Detailed error message. */
    detail?: string | null;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null;
}
export declare const PagesListResultItemTestsItemDesktopReportError: S.Schema<PagesListResultItemTestsItemDesktopReportError>;
export type PagesListResultItemTestsItemDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export declare const PagesListResultItemTestsItemDesktopReportState: any;
export interface PagesListResultItemTestsItemDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null;
    /** The type of device. */
    deviceType?: PagesListResultItemTestsItemDesktopReportDeviceType | null;
    error?: PagesListResultItemTestsItemDesktopReportError | null;
    /** First Contentful Paint. */
    fcp?: number | null;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null;
    /** Largest Contentful Paint. */
    lcp?: number | null;
    /** The Lighthouse performance score. */
    performanceScore?: number | null;
    /** Speed Index. */
    si?: number | null;
    /** The state of the Lighthouse report. */
    state?: PagesListResultItemTestsItemDesktopReportState | null;
    /** Total Blocking Time. */
    tbt?: number | null;
    /** Time To First Byte. */
    ttfb?: number | null;
    /** Time To Interactive. */
    tti?: number | null;
}
export declare const PagesListResultItemTestsItemDesktopReport: S.Schema<PagesListResultItemTestsItemDesktopReport>;
export type PagesListResultItemTestsItemScheduleFrequency = "DAILY" | "WEEKLY";
export declare const PagesListResultItemTestsItemScheduleFrequency: any;
export interface PagesListResultItemTestsItem {
    /** UUID. */
    id?: string | null;
    date?: string | null;
    /** The Lighthouse report. */
    desktopReport?: PagesListResultItemTestsItemDesktopReport | null;
    /** The Lighthouse report. */
    mobileReport?: PagesListResultItemTestsItemDesktopReport | null;
    /** A test region with a label. */
    region?: PagesListResultItemRegion | null;
    /** The frequency of the test. */
    scheduleFrequency?: PagesListResultItemTestsItemScheduleFrequency | null;
    /** A URL. */
    url?: string | null;
}
export declare const PagesListResultItemTestsItem: S.Schema<PagesListResultItemTestsItem>;
export type PagesListResultItemTestsList = Array<PagesListResultItemTestsItem>;
export declare const PagesListResultItemTestsList: S.Schema<PagesListResultItemTestsList>;
export interface PagesListResultItem {
    /** A test region with a label. */
    region?: PagesListResultItemRegion | null;
    /** The frequency of the test. */
    scheduleFrequency?: PagesListResultItemScheduleFrequency | null;
    tests?: PagesListResultItemTestsList | null;
    /** A URL. */
    url?: string | null;
}
export declare const PagesListResultItem: S.Schema<PagesListResultItem>;
export type PagesListResultList = Array<PagesListResultItem>;
export declare const PagesListResultList: S.Schema<PagesListResultList>;
export interface ListPagesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PagesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPagesResponse: S.Schema<ListPagesResponse>;
export type PagesTestsListRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTestsListRequestRegion: any;
export interface ListPageTestsRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    page?: number;
    perPage?: number;
    /** A test region. */
    region?: PagesTestsListRequestRegion | (string & {});
}
export declare const ListPageTestsRequest: S.Schema<ListPageTestsRequest>;
export type PagesTestsListResultItemDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export declare const PagesTestsListResultItemDesktopReportDeviceType: any;
export type PagesTestsListResultItemDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export declare const PagesTestsListResultItemDesktopReportErrorCode: any;
export interface PagesTestsListResultItemDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsListResultItemDesktopReportErrorCode | null;
    /** Detailed error message. */
    detail?: string | null;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null;
}
export declare const PagesTestsListResultItemDesktopReportError: S.Schema<PagesTestsListResultItemDesktopReportError>;
export type PagesTestsListResultItemDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export declare const PagesTestsListResultItemDesktopReportState: any;
export interface PagesTestsListResultItemDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null;
    /** The type of device. */
    deviceType?: PagesTestsListResultItemDesktopReportDeviceType | null;
    error?: PagesTestsListResultItemDesktopReportError | null;
    /** First Contentful Paint. */
    fcp?: number | null;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null;
    /** Largest Contentful Paint. */
    lcp?: number | null;
    /** The Lighthouse performance score. */
    performanceScore?: number | null;
    /** Speed Index. */
    si?: number | null;
    /** The state of the Lighthouse report. */
    state?: PagesTestsListResultItemDesktopReportState | null;
    /** Total Blocking Time. */
    tbt?: number | null;
    /** Time To First Byte. */
    ttfb?: number | null;
    /** Time To Interactive. */
    tti?: number | null;
}
export declare const PagesTestsListResultItemDesktopReport: S.Schema<PagesTestsListResultItemDesktopReport>;
export type PagesTestsListResultItemRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTestsListResultItemRegionValue: any;
export interface PagesTestsListResultItemRegion {
    label?: string | null;
    /** A test region. */
    value?: PagesTestsListResultItemRegionValue | null;
}
export declare const PagesTestsListResultItemRegion: S.Schema<PagesTestsListResultItemRegion>;
export type PagesTestsListResultItemScheduleFrequency = "DAILY" | "WEEKLY";
export declare const PagesTestsListResultItemScheduleFrequency: any;
export interface PagesTestsListResultItem {
    /** UUID. */
    id?: string | null;
    date?: string | null;
    /** The Lighthouse report. */
    desktopReport?: PagesTestsListResultItemDesktopReport | null;
    /** The Lighthouse report. */
    mobileReport?: PagesTestsListResultItemDesktopReport | null;
    /** A test region with a label. */
    region?: PagesTestsListResultItemRegion | null;
    /** The frequency of the test. */
    scheduleFrequency?: PagesTestsListResultItemScheduleFrequency | null;
    /** A URL. */
    url?: string | null;
}
export declare const PagesTestsListResultItem: S.Schema<PagesTestsListResultItem>;
export type PagesTestsListResultList = Array<PagesTestsListResultItem>;
export declare const PagesTestsListResultList: S.Schema<PagesTestsListResultList>;
export interface ListPageTestsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PagesTestsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPageTestsResponse: S.Schema<ListPageTestsResponse>;
export type PagesTrendRequestDeviceType = "DESKTOP" | "MOBILE";
export declare const PagesTrendRequestDeviceType: any;
export type PagesTrendRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export declare const PagesTrendRequestRegion: any;
export interface TrendPageRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** The type of device. */
    deviceType: PagesTrendRequestDeviceType | (string & {});
    /** A comma-separated list of metrics to include in the results. */
    metrics: string;
    /** A test region. */
    region: PagesTrendRequestRegion | (string & {});
    start: string;
    /** The timezone of the start and end timestamps. */
    tz: string;
    end?: string;
}
export declare const TrendPageRequest: S.Schema<TrendPageRequest>;
export type PagesTrendResponseClsList = Array<number>;
export declare const PagesTrendResponseClsList: S.Schema<PagesTrendResponseClsList>;
export type PagesTrendResponseFcpList = Array<number>;
export declare const PagesTrendResponseFcpList: S.Schema<PagesTrendResponseFcpList>;
export type PagesTrendResponseLcpList = Array<number>;
export declare const PagesTrendResponseLcpList: S.Schema<PagesTrendResponseLcpList>;
export type PagesTrendResponsePerformanceScoreList = Array<number>;
export declare const PagesTrendResponsePerformanceScoreList: S.Schema<PagesTrendResponsePerformanceScoreList>;
export type PagesTrendResponseSiList = Array<number>;
export declare const PagesTrendResponseSiList: S.Schema<PagesTrendResponseSiList>;
export type PagesTrendResponseTbtList = Array<number>;
export declare const PagesTrendResponseTbtList: S.Schema<PagesTrendResponseTbtList>;
export type PagesTrendResponseTtfbList = Array<number>;
export declare const PagesTrendResponseTtfbList: S.Schema<PagesTrendResponseTtfbList>;
export type PagesTrendResponseTtiList = Array<number>;
export declare const PagesTrendResponseTtiList: S.Schema<PagesTrendResponseTtiList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TrendPageResponse {
    /** Cumulative Layout Shift trend. */
    cls?: PagesTrendResponseClsList | null;
    /** First Contentful Paint trend. */
    fcp?: PagesTrendResponseFcpList | null;
    /** Largest Contentful Paint trend. */
    lcp?: PagesTrendResponseLcpList | null;
    /** The Lighthouse score trend. */
    performanceScore?: PagesTrendResponsePerformanceScoreList | null;
    /** Speed Index trend. */
    si?: PagesTrendResponseSiList | null;
    /** Total Blocking Time trend. */
    tbt?: PagesTrendResponseTbtList | null;
    /** Time To First Byte trend. */
    ttfb?: PagesTrendResponseTtfbList | null;
    /** Time To Interactive trend. */
    tti?: PagesTrendResponseTtiList | null;
}
export declare const TrendPageResponse: S.Schema<TrendPageResponse>;
export type CreatePageTestError = CloudflareOpError;
/** Starts a test for a specific webpage, in a specific region. */
export declare const createPageTest: API.OperationMethod<CreatePageTestRequest, CreatePageTestResponse, CreatePageTestError, CloudflareOpContext>;
export type CreateScheduleError = TestScheduleAlreadyExists | TestScheduleQuotaReached | Forbidden | CloudflareOpError;
/** Creates a scheduled test for a page. */
export declare const createSchedule: API.OperationMethod<CreateScheduleRequest, CreateScheduleResponse, CreateScheduleError, CloudflareOpContext>;
export type DeletePageTestError = CloudflareOpError;
/** Deletes all tests for a specific webpage from a specific region. Deleted tests are still counted as part of the quota. */
export declare const deletePageTest: API.OperationMethod<DeletePageTestRequest, DeletePageTestResponse, DeletePageTestError, CloudflareOpContext>;
export type DeleteScheduleError = TestScheduleNotFound | Forbidden | CloudflareOpError;
/** Deletes a scheduled test for a page. */
export declare const deleteSchedule: API.OperationMethod<DeleteScheduleRequest, DeleteScheduleResponse, DeleteScheduleError, CloudflareOpContext>;
export type GetPageTestError = CloudflareOpError;
/** Retrieves the result of a specific test. */
export declare const getPageTest: API.OperationMethod<GetPageTestRequest, GetPageTestResponse, GetPageTestError, CloudflareOpContext>;
export type GetScheduleError = TestScheduleNotFound | Forbidden | CloudflareOpError;
/** Retrieves the test schedule for a page in a specific region. */
export declare const getSchedule: API.OperationMethod<GetScheduleRequest, GetScheduleResponse, GetScheduleError, CloudflareOpContext>;
export type ListAvailabilitiesError = CloudflareOpError;
/** Retrieves quota for all plans, as well as the current zone quota. */
export declare const listAvailabilities: API.OperationMethod<ListAvailabilitiesRequest, ListAvailabilitiesResponse, ListAvailabilitiesError, CloudflareOpContext>;
export type ListPagesError = CloudflareOpError;
/** Lists all webpages which have been tested. */
export declare const listPages: API.PaginatedOperationMethod<ListPagesRequest, ListPagesResponse, ListPagesError, CloudflareOpContext, PagesListResultItem>;
export type ListPageTestsError = CloudflareOpError;
/** Test history (list of tests) for a specific webpage. */
export declare const listPageTests: API.PaginatedOperationMethod<ListPageTestsRequest, ListPageTestsResponse, ListPageTestsError, CloudflareOpContext, PagesTestsListResultItem>;
export type TrendPageError = CloudflareOpError;
/** Lists the core web vital metrics trend over time for a specific page. */
export declare const trendPage: API.OperationMethod<TrendPageRequest, TrendPageResponse, TrendPageError, CloudflareOpContext>;
//# sourceMappingURL=speed.d.ts.map