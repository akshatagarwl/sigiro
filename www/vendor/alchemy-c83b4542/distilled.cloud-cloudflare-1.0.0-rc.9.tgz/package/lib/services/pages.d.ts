import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ActiveProductionDeployment_base: S.Class<ActiveProductionDeployment, S.TaggedStruct<"ActiveProductionDeployment", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ActiveProductionDeployment extends /*@__PURE__*/ ActiveProductionDeployment_base {
}
declare const DeploymentNotFound_base: S.Class<DeploymentNotFound, S.TaggedStruct<"DeploymentNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentNotFound extends /*@__PURE__*/ DeploymentNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const PagesDomainAlreadyExists_base: S.Class<PagesDomainAlreadyExists, S.TaggedStruct<"PagesDomainAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PagesDomainAlreadyExists extends /*@__PURE__*/ PagesDomainAlreadyExists_base {
}
declare const PagesDomainNotFound_base: S.Class<PagesDomainNotFound, S.TaggedStruct<"PagesDomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PagesDomainNotFound extends /*@__PURE__*/ PagesDomainNotFound_base {
}
declare const ProjectAlreadyExists_base: S.Class<ProjectAlreadyExists, S.TaggedStruct<"ProjectAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ProjectAlreadyExists extends /*@__PURE__*/ ProjectAlreadyExists_base {
}
declare const ProjectNotFound_base: S.Class<ProjectNotFound, S.TaggedStruct<"ProjectNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ProjectNotFound extends /*@__PURE__*/ ProjectNotFound_base {
}
export interface ProjectsCreateRequestBuildConfig {
    /** Enable build caching for the project. */
    buildCaching?: boolean;
    /** Command used to build project. */
    buildCommand?: string;
    /** Output directory of the build. */
    destinationDir?: string;
    /** Directory to run the command. */
    rootDir?: string;
    /** The classifying tag for analytics. */
    webAnalyticsTag?: string;
    /** The auth token for analytics. */
    webAnalyticsToken?: string;
}
export declare const ProjectsCreateRequestBuildConfig: S.Schema<ProjectsCreateRequestBuildConfig>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue {
    projectId: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue {
    /** Name of the dataset. */
    dataset: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap>;
export type ProjectsCreateRequestDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewBrowsersMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewBrowsersMap>;
export type ProjectsCreateRequestDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export declare const ProjectsCreateRequestDeploymentConfigsPreviewCompatibilityFlagsList: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewCompatibilityFlagsList>;
export type ProjectsCreateRequestDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewD1DatabasesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewD1DatabasesMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue {
    /** ID of the Durable Object namespace. */
    namespaceId: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesMap>;
export type UntypedBindingMap = {
    [key: string]: unknown | undefined;
};
export declare const UntypedBindingMap: S.Schema<UntypedBindingMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue {
    id: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsMap>;
export type ProjectsCreateRequestDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewKvNamespacesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewKvNamespacesMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewLimits {
    /** CPU time limit in milliseconds. */
    cpuMs: number;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue {
    certificateId: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewPlacement {
    /** Placement mode. */
    mode: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue {
    /** Name of the Queue. */
    name: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersMap>;
export type ProjectsCreateRequestDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewR2BucketsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewR2BucketsMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreviewServicesValue {
    /** The Service name. */
    service: string;
    /** The entrypoint to bind to. */
    entrypoint?: string;
    /** The Service environment. */
    environment?: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewServicesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewServicesValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewServicesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewServicesMap>;
export type ProjectsCreateRequestDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsCreateRequestDeploymentConfigsPreviewUsageModel: any;
export interface ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue {
    indexName: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsMap>;
export interface ProjectsCreateRequestDeploymentConfigsPreview {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateRequestDeploymentConfigsPreviewBrowsersMap;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsCreateRequestDeploymentConfigsPreviewCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateRequestDeploymentConfigsPreviewD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateRequestDeploymentConfigsPreviewKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateRequestDeploymentConfigsPreviewR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateRequestDeploymentConfigsPreviewServicesMap;
    /** The usage model for Pages Functions. */
    usageModel?: ProjectsCreateRequestDeploymentConfigsPreviewUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsPreview: S.Schema<ProjectsCreateRequestDeploymentConfigsPreview>;
export type ProjectsCreateRequestDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionAiBindingsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionAiBindingsMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionBrowsersMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionBrowsersMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export declare const ProjectsCreateRequestDeploymentConfigsProductionCompatibilityFlagsList: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionCompatibilityFlagsList>;
export type ProjectsCreateRequestDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionD1DatabasesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionD1DatabasesMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionKvNamespacesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionKvNamespacesMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsCreateRequestDeploymentConfigsProductionLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsCreateRequestDeploymentConfigsProductionPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsCreateRequestDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionQueueProducersMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionQueueProducersMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionR2BucketsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionR2BucketsMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionServicesValue = ProjectsCreateRequestDeploymentConfigsPreviewServicesValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionServicesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewServicesValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionServicesMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionServicesMap>;
export type ProjectsCreateRequestDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsCreateRequestDeploymentConfigsProductionUsageModel: any;
export type ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsMap: S.Schema<ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsMap>;
export interface ProjectsCreateRequestDeploymentConfigsProduction {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateRequestDeploymentConfigsProductionAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateRequestDeploymentConfigsProductionBrowsersMap;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsCreateRequestDeploymentConfigsProductionCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateRequestDeploymentConfigsProductionD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateRequestDeploymentConfigsProductionDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateRequestDeploymentConfigsProductionHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateRequestDeploymentConfigsProductionKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateRequestDeploymentConfigsProductionMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateRequestDeploymentConfigsProductionQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateRequestDeploymentConfigsProductionR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateRequestDeploymentConfigsProductionServicesMap;
    /** The usage model for Pages Functions. */
    usageModel?: ProjectsCreateRequestDeploymentConfigsProductionUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateRequestDeploymentConfigsProductionVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export declare const ProjectsCreateRequestDeploymentConfigsProduction: S.Schema<ProjectsCreateRequestDeploymentConfigsProduction>;
export interface ProjectsCreateRequestDeploymentConfigs {
    /** Configs for preview deploys. */
    preview?: ProjectsCreateRequestDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production?: ProjectsCreateRequestDeploymentConfigsProduction;
}
export declare const ProjectsCreateRequestDeploymentConfigs: S.Schema<ProjectsCreateRequestDeploymentConfigs>;
export type ProjectsCreateRequestSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsCreateRequestSourceConfigPathExcludesList: S.Schema<ProjectsCreateRequestSourceConfigPathExcludesList>;
export type ProjectsCreateRequestSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsCreateRequestSourceConfigPathIncludesList: S.Schema<ProjectsCreateRequestSourceConfigPathIncludesList>;
export type ProjectsCreateRequestSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsCreateRequestSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsCreateRequestSourceConfigPreviewBranchExcludesList>;
export type ProjectsCreateRequestSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsCreateRequestSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsCreateRequestSourceConfigPreviewBranchIncludesList>;
export type ProjectsCreateRequestSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsCreateRequestSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsCreateRequestSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled?: boolean;
    /** The owner of the repository. */
    owner?: string;
    /** The owner ID of the repository. */
    ownerId?: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes?: ProjectsCreateRequestSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes?: ProjectsCreateRequestSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled?: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes?: ProjectsCreateRequestSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes?: ProjectsCreateRequestSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting?: ProjectsCreateRequestSourceConfigPreviewDeploymentSetting | (string & {});
    /** The production branch of the repository. */
    productionBranch?: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled?: boolean;
    /** The ID of the repository. */
    repoId?: string;
    /** The name of the repository. */
    repoName?: string;
}
export declare const ProjectsCreateRequestSourceConfig: S.Schema<ProjectsCreateRequestSourceConfig>;
export type ProjectsCreateRequestSourceType = "github" | "gitlab";
export declare const ProjectsCreateRequestSourceType: any;
export interface ProjectsCreateRequestSource {
    config: ProjectsCreateRequestSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateRequestSourceType | (string & {});
}
export declare const ProjectsCreateRequestSource: S.Schema<ProjectsCreateRequestSource>;
export interface CreateProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    name: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateRequestBuildConfig;
    /** Configs for deployments in a project. */
    deploymentConfigs?: ProjectsCreateRequestDeploymentConfigs;
    /** Configs for the project source control. */
    source?: ProjectsCreateRequestSource;
}
export declare const CreateProjectRequest: S.Schema<CreateProjectRequest>;
export type ProjectsCreateResponseCanonicalDeploymentAliasesList = Array<string>;
export declare const ProjectsCreateResponseCanonicalDeploymentAliasesList: S.Schema<ProjectsCreateResponseCanonicalDeploymentAliasesList>;
export interface ProjectsCreateResponseCanonicalDeploymentBuildConfig {
    /** The classifying tag for analytics. */
    webAnalyticsTag: string;
    /** The auth token for analytics. */
    webAnalyticsToken: string;
    /** Enable build caching for the project. */
    buildCaching?: boolean | null;
    /** Command used to build project. */
    buildCommand?: string | null;
    /** Assets output directory of the build. */
    destinationDir?: string | null;
    /** Directory to run the command. */
    rootDir?: string | null;
}
export declare const ProjectsCreateResponseCanonicalDeploymentBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export interface ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata {
    /** Where the trigger happened. */
    branch: string;
    /** Whether the deployment trigger commit was dirty. */
    commitDirty: boolean;
    /** Hash of the deployment trigger commit. */
    commitHash: string;
    /** Message of the deployment trigger commit. */
    commitMessage: string;
}
export declare const ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerType: any;
export interface ProjectsCreateResponseCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerType;
}
export declare const ProjectsCreateResponseCanonicalDeploymentDeploymentTrigger: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTrigger>;
export type ProjectsCreateResponseCanonicalDeploymentEnvironment = "preview" | "production";
export declare const ProjectsCreateResponseCanonicalDeploymentEnvironment: any;
export type ProjectsCreateResponseCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsCreateResponseCanonicalDeploymentLatestStageName: any;
export type ProjectsCreateResponseCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsCreateResponseCanonicalDeploymentLatestStageStatus: any;
export interface ProjectsCreateResponseCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsCreateResponseCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsCreateResponseCanonicalDeploymentLatestStageStatus;
}
export declare const ProjectsCreateResponseCanonicalDeploymentLatestStage: S.Schema<ProjectsCreateResponseCanonicalDeploymentLatestStage>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsCreateResponseCanonicalDeploymentSourceConfigPathExcludesList: S.Schema<ProjectsCreateResponseCanonicalDeploymentSourceConfigPathExcludesList>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsCreateResponseCanonicalDeploymentSourceConfigPathIncludesList: S.Schema<ProjectsCreateResponseCanonicalDeploymentSourceConfigPathIncludesList>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList>;
export type ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsCreateResponseCanonicalDeploymentSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsCreateResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsCreateResponseCanonicalDeploymentSourceConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentSourceConfig>;
export type ProjectsCreateResponseCanonicalDeploymentSourceType = "github" | "gitlab";
export declare const ProjectsCreateResponseCanonicalDeploymentSourceType: any;
export interface ProjectsCreateResponseCanonicalDeploymentSource {
    config: ProjectsCreateResponseCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateResponseCanonicalDeploymentSourceType;
}
export declare const ProjectsCreateResponseCanonicalDeploymentSource: S.Schema<ProjectsCreateResponseCanonicalDeploymentSource>;
export interface ProjectsCreateResponseCanonicalDeploymentStagesItem {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: string;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: string;
}
export declare const ProjectsCreateResponseCanonicalDeploymentStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsCreateResponseCanonicalDeploymentStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsCreateResponseCanonicalDeploymentStagesList: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesList>;
export interface ProjectsCreateResponseCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsCreateResponseCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsCreateResponseCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsCreateResponseCanonicalDeploymentEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsCreateResponseCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsCreateResponseCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsCreateResponseCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const ProjectsCreateResponseCanonicalDeployment: S.Schema<ProjectsCreateResponseCanonicalDeployment>;
export type ProjectsCreateResponseDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewCompatibilityFlagsList: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewCompatibilityFlagsList>;
export type ProjectsCreateResponseDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsCreateResponseDeploymentConfigsPreviewUsageModel: any;
export type ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewBrowsersMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewBrowsersMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewD1DatabasesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewD1DatabasesMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewKvNamespacesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewKvNamespacesMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewR2BucketsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewR2BucketsMap>;
export interface ProjectsCreateResponseDeploymentConfigsPreviewServicesValue {
    /** The Service environment. */
    environment: string;
    /** The Service name. */
    service: string;
    /** The entrypoint to bind to. */
    entrypoint?: string | null;
}
export declare const ProjectsCreateResponseDeploymentConfigsPreviewServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewServicesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesMap>;
export type ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsMap>;
export interface ProjectsCreateResponseDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsCreateResponseDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsCreateResponseDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateResponseDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateResponseDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateResponseDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateResponseDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateResponseDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateResponseDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateResponseDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateResponseDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateResponseDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateResponseDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateResponseDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsCreateResponseDeploymentConfigsPreview: S.Schema<ProjectsCreateResponseDeploymentConfigsPreview>;
export type ProjectsCreateResponseDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export declare const ProjectsCreateResponseDeploymentConfigsProductionCompatibilityFlagsList: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionCompatibilityFlagsList>;
export type ProjectsCreateResponseDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsCreateResponseDeploymentConfigsProductionUsageModel: any;
export type ProjectsCreateResponseDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionAiBindingsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionAiBindingsMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionBrowsersMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionBrowsersMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionD1DatabasesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionD1DatabasesMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionKvNamespacesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionKvNamespacesMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsCreateResponseDeploymentConfigsProductionLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsCreateResponseDeploymentConfigsProductionPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsCreateResponseDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionQueueProducersMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionQueueProducersMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionR2BucketsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionR2BucketsMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionServicesMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionServicesMap>;
export type ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsMap: S.Schema<ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsMap>;
export interface ProjectsCreateResponseDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsCreateResponseDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsCreateResponseDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsCreateResponseDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsCreateResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsCreateResponseDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsCreateResponseDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsCreateResponseDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsCreateResponseDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsCreateResponseDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsCreateResponseDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsCreateResponseDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsCreateResponseDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsCreateResponseDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsCreateResponseDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsCreateResponseDeploymentConfigsProduction: S.Schema<ProjectsCreateResponseDeploymentConfigsProduction>;
export interface ProjectsCreateResponseDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsCreateResponseDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsCreateResponseDeploymentConfigsProduction;
}
export declare const ProjectsCreateResponseDeploymentConfigs: S.Schema<ProjectsCreateResponseDeploymentConfigs>;
export type ProjectsCreateResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsCreateResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsCreateResponseDomainsList = Array<string>;
export declare const ProjectsCreateResponseDomainsList: S.Schema<ProjectsCreateResponseDomainsList>;
export type ProjectsCreateResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsCreateResponseSourceConfigPathExcludesList: S.Schema<ProjectsCreateResponseSourceConfigPathExcludesList>;
export type ProjectsCreateResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsCreateResponseSourceConfigPathIncludesList: S.Schema<ProjectsCreateResponseSourceConfigPathIncludesList>;
export type ProjectsCreateResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsCreateResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsCreateResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsCreateResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsCreateResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsCreateResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsCreateResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsCreateResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsCreateResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsCreateResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsCreateResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsCreateResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsCreateResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsCreateResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsCreateResponseSourceConfig: S.Schema<ProjectsCreateResponseSourceConfig>;
export type ProjectsCreateResponseSourceType = "github" | "gitlab";
export declare const ProjectsCreateResponseSourceType: any;
export interface ProjectsCreateResponseSource {
    config: ProjectsCreateResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsCreateResponseSourceType;
}
export declare const ProjectsCreateResponseSource: S.Schema<ProjectsCreateResponseSource>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectResponse {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsCreateResponseCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsCreateResponseDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsCreateResponseCanonicalDeployment;
    /** Name of the project. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsCreateResponseDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsCreateResponseSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export declare const CreateProjectResponse: S.Schema<CreateProjectResponse>;
export interface CreateProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** The branch to build the new deployment from. */
    branch?: string;
    commitDirty?: boolean;
    commitHash?: string;
    commitMessage?: string;
    /** JSON string mapping file paths to their content hashes. */
    manifest?: string;
    pagesBuildOutputDir?: string;
    wranglerConfigHash?: string;
    headers?: unknown;
    redirects?: unknown;
    routesJson?: unknown;
    workerBundle?: unknown;
    workerJs?: unknown;
    functionsFilepathRoutingConfigJson?: unknown;
}
export declare const CreateProjectDeploymentRequest: S.Schema<CreateProjectDeploymentRequest>;
export type ProjectsDeploymentsCreateResponseAliasesList = Array<string>;
export declare const ProjectsDeploymentsCreateResponseAliasesList: S.Schema<ProjectsDeploymentsCreateResponseAliasesList>;
export type ProjectsDeploymentsCreateResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsDeploymentsCreateResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsDeploymentsCreateResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsDeploymentsCreateResponseDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsDeploymentsCreateResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsDeploymentsCreateResponseDeploymentTriggerType: any;
export interface ProjectsDeploymentsCreateResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsCreateResponseDeploymentTriggerType;
}
export declare const ProjectsDeploymentsCreateResponseDeploymentTrigger: S.Schema<ProjectsDeploymentsCreateResponseDeploymentTrigger>;
export type ProjectsDeploymentsCreateResponseEnvironment = "preview" | "production";
export declare const ProjectsDeploymentsCreateResponseEnvironment: any;
export type ProjectsDeploymentsCreateResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsDeploymentsCreateResponseLatestStageName: any;
export type ProjectsDeploymentsCreateResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsDeploymentsCreateResponseLatestStageStatus: any;
export interface ProjectsDeploymentsCreateResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsCreateResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsCreateResponseLatestStageStatus;
}
export declare const ProjectsDeploymentsCreateResponseLatestStage: S.Schema<ProjectsDeploymentsCreateResponseLatestStage>;
export type ProjectsDeploymentsCreateResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsDeploymentsCreateResponseSourceConfigPathExcludesList: S.Schema<ProjectsDeploymentsCreateResponseSourceConfigPathExcludesList>;
export type ProjectsDeploymentsCreateResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsDeploymentsCreateResponseSourceConfigPathIncludesList: S.Schema<ProjectsDeploymentsCreateResponseSourceConfigPathIncludesList>;
export type ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsDeploymentsCreateResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsDeploymentsCreateResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsDeploymentsCreateResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsCreateResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsCreateResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsCreateResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsCreateResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsDeploymentsCreateResponseSourceConfig: S.Schema<ProjectsDeploymentsCreateResponseSourceConfig>;
export type ProjectsDeploymentsCreateResponseSourceType = "github" | "gitlab";
export declare const ProjectsDeploymentsCreateResponseSourceType: any;
export interface ProjectsDeploymentsCreateResponseSource {
    config: ProjectsDeploymentsCreateResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsCreateResponseSourceType;
}
export declare const ProjectsDeploymentsCreateResponseSource: S.Schema<ProjectsDeploymentsCreateResponseSource>;
export type ProjectsDeploymentsCreateResponseStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsDeploymentsCreateResponseStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsDeploymentsCreateResponseStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsDeploymentsCreateResponseStagesList: S.Schema<ProjectsDeploymentsCreateResponseStagesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsCreateResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsCreateResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsCreateResponseEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsCreateResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsCreateResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsCreateResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const CreateProjectDeploymentResponse: S.Schema<CreateProjectDeploymentResponse>;
export interface CreateProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** The domain name. */
    name: string;
}
export declare const CreateProjectDomainRequest: S.Schema<CreateProjectDomainRequest>;
export type ProjectsDomainsCreateResponseCertificateAuthority = "google" | "lets_encrypt";
export declare const ProjectsDomainsCreateResponseCertificateAuthority: any;
export type ProjectsDomainsCreateResponseStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsCreateResponseStatus: any;
export type ProjectsDomainsCreateResponseValidationDataMethod = "http" | "txt";
export declare const ProjectsDomainsCreateResponseValidationDataMethod: any;
export type ProjectsDomainsCreateResponseValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export declare const ProjectsDomainsCreateResponseValidationDataStatus: any;
export interface ProjectsDomainsCreateResponseValidationData {
    method: ProjectsDomainsCreateResponseValidationDataMethod;
    status: ProjectsDomainsCreateResponseValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export declare const ProjectsDomainsCreateResponseValidationData: S.Schema<ProjectsDomainsCreateResponseValidationData>;
export type ProjectsDomainsCreateResponseVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsCreateResponseVerificationDataStatus: any;
export interface ProjectsDomainsCreateResponseVerificationData {
    status: ProjectsDomainsCreateResponseVerificationDataStatus;
    errorMessage?: string | null;
}
export declare const ProjectsDomainsCreateResponseVerificationData: S.Schema<ProjectsDomainsCreateResponseVerificationData>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProjectDomainResponse {
    id: string;
    certificateAuthority: ProjectsDomainsCreateResponseCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** The domain name. */
    name: string;
    status: ProjectsDomainsCreateResponseStatus;
    validationData: ProjectsDomainsCreateResponseValidationData;
    verificationData: ProjectsDomainsCreateResponseVerificationData;
    zoneTag: string;
}
export declare const CreateProjectDomainResponse: S.Schema<CreateProjectDomainResponse>;
export interface DeleteProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
}
export declare const DeleteProjectRequest: S.Schema<DeleteProjectRequest>;
export type DeleteProjectResponse = unknown;
export declare const DeleteProjectResponse: S.Schema<DeleteProjectResponse>;
export interface DeleteProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** Identifier. */
    deploymentId: string;
    /** Allow deletion of aliased non-production deployments when a normal delete would be rejected. */
    force?: boolean;
}
export declare const DeleteProjectDeploymentRequest: S.Schema<DeleteProjectDeploymentRequest>;
export type DeleteProjectDeploymentResponse = unknown;
export declare const DeleteProjectDeploymentResponse: S.Schema<DeleteProjectDeploymentResponse>;
export interface DeleteProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** The domain name. */
    domainName: string;
}
export declare const DeleteProjectDomainRequest: S.Schema<DeleteProjectDomainRequest>;
export type DeleteProjectDomainResponse = unknown;
export declare const DeleteProjectDomainResponse: S.Schema<DeleteProjectDomainResponse>;
export interface GetProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
}
export declare const GetProjectRequest: S.Schema<GetProjectRequest>;
export type ProjectsGetResponseCanonicalDeploymentAliasesList = Array<string>;
export declare const ProjectsGetResponseCanonicalDeploymentAliasesList: S.Schema<ProjectsGetResponseCanonicalDeploymentAliasesList>;
export type ProjectsGetResponseCanonicalDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsGetResponseCanonicalDeploymentBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsGetResponseCanonicalDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsGetResponseCanonicalDeploymentDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsGetResponseCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsGetResponseCanonicalDeploymentDeploymentTriggerType: any;
export interface ProjectsGetResponseCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsGetResponseCanonicalDeploymentDeploymentTriggerType;
}
export declare const ProjectsGetResponseCanonicalDeploymentDeploymentTrigger: S.Schema<ProjectsGetResponseCanonicalDeploymentDeploymentTrigger>;
export type ProjectsGetResponseCanonicalDeploymentEnvironment = "preview" | "production";
export declare const ProjectsGetResponseCanonicalDeploymentEnvironment: any;
export type ProjectsGetResponseCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsGetResponseCanonicalDeploymentLatestStageName: any;
export type ProjectsGetResponseCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsGetResponseCanonicalDeploymentLatestStageStatus: any;
export interface ProjectsGetResponseCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsGetResponseCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsGetResponseCanonicalDeploymentLatestStageStatus;
}
export declare const ProjectsGetResponseCanonicalDeploymentLatestStage: S.Schema<ProjectsGetResponseCanonicalDeploymentLatestStage>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsGetResponseCanonicalDeploymentSourceConfigPathExcludesList: S.Schema<ProjectsGetResponseCanonicalDeploymentSourceConfigPathExcludesList>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsGetResponseCanonicalDeploymentSourceConfigPathIncludesList: S.Schema<ProjectsGetResponseCanonicalDeploymentSourceConfigPathIncludesList>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList>;
export type ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsGetResponseCanonicalDeploymentSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsGetResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsGetResponseCanonicalDeploymentSourceConfig: S.Schema<ProjectsGetResponseCanonicalDeploymentSourceConfig>;
export type ProjectsGetResponseCanonicalDeploymentSourceType = "github" | "gitlab";
export declare const ProjectsGetResponseCanonicalDeploymentSourceType: any;
export interface ProjectsGetResponseCanonicalDeploymentSource {
    config: ProjectsGetResponseCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsGetResponseCanonicalDeploymentSourceType;
}
export declare const ProjectsGetResponseCanonicalDeploymentSource: S.Schema<ProjectsGetResponseCanonicalDeploymentSource>;
export type ProjectsGetResponseCanonicalDeploymentStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsGetResponseCanonicalDeploymentStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsGetResponseCanonicalDeploymentStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsGetResponseCanonicalDeploymentStagesList: S.Schema<ProjectsGetResponseCanonicalDeploymentStagesList>;
export interface ProjectsGetResponseCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsGetResponseCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsGetResponseCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsGetResponseCanonicalDeploymentEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsGetResponseCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsGetResponseCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsGetResponseCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const ProjectsGetResponseCanonicalDeployment: S.Schema<ProjectsGetResponseCanonicalDeployment>;
export type ProjectsGetResponseDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export declare const ProjectsGetResponseDeploymentConfigsPreviewCompatibilityFlagsList: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewCompatibilityFlagsList>;
export type ProjectsGetResponseDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsGetResponseDeploymentConfigsPreviewUsageModel: any;
export type ProjectsGetResponseDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewAiBindingsMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewAiBindingsMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewBrowsersMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewBrowsersMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewD1DatabasesMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewD1DatabasesMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewKvNamespacesMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewKvNamespacesMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsGetResponseDeploymentConfigsPreviewLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsGetResponseDeploymentConfigsPreviewPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsGetResponseDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewQueueProducersMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewQueueProducersMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewR2BucketsMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewR2BucketsMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewServicesMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewServicesMap>;
export type ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsMap: S.Schema<ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsMap>;
export interface ProjectsGetResponseDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsGetResponseDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsGetResponseDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsGetResponseDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsGetResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsGetResponseDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsGetResponseDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsGetResponseDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsGetResponseDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsGetResponseDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsGetResponseDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsGetResponseDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsGetResponseDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsGetResponseDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsGetResponseDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsGetResponseDeploymentConfigsPreview: S.Schema<ProjectsGetResponseDeploymentConfigsPreview>;
export type ProjectsGetResponseDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export declare const ProjectsGetResponseDeploymentConfigsProductionCompatibilityFlagsList: S.Schema<ProjectsGetResponseDeploymentConfigsProductionCompatibilityFlagsList>;
export type ProjectsGetResponseDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsGetResponseDeploymentConfigsProductionUsageModel: any;
export type ProjectsGetResponseDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsGetResponseDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionAiBindingsMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionAiBindingsMap>;
export type ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap>;
export type ProjectsGetResponseDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionBrowsersMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionBrowsersMap>;
export type ProjectsGetResponseDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionD1DatabasesMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionD1DatabasesMap>;
export type ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesMap>;
export type ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsMap>;
export type ProjectsGetResponseDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionKvNamespacesMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionKvNamespacesMap>;
export type ProjectsGetResponseDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsGetResponseDeploymentConfigsProductionLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesMap>;
export type ProjectsGetResponseDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsGetResponseDeploymentConfigsProductionPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsGetResponseDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsGetResponseDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionQueueProducersMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionQueueProducersMap>;
export type ProjectsGetResponseDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionR2BucketsMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionR2BucketsMap>;
export type ProjectsGetResponseDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsGetResponseDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionServicesMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionServicesMap>;
export type ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsMap: S.Schema<ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsMap>;
export interface ProjectsGetResponseDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsGetResponseDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsGetResponseDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsGetResponseDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsGetResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsGetResponseDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsGetResponseDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsGetResponseDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsGetResponseDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsGetResponseDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsGetResponseDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsGetResponseDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsGetResponseDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsGetResponseDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsGetResponseDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsGetResponseDeploymentConfigsProduction: S.Schema<ProjectsGetResponseDeploymentConfigsProduction>;
export interface ProjectsGetResponseDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsGetResponseDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsGetResponseDeploymentConfigsProduction;
}
export declare const ProjectsGetResponseDeploymentConfigs: S.Schema<ProjectsGetResponseDeploymentConfigs>;
export type ProjectsGetResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsGetResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsGetResponseDomainsList = Array<string>;
export declare const ProjectsGetResponseDomainsList: S.Schema<ProjectsGetResponseDomainsList>;
export type ProjectsGetResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsGetResponseSourceConfigPathExcludesList: S.Schema<ProjectsGetResponseSourceConfigPathExcludesList>;
export type ProjectsGetResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsGetResponseSourceConfigPathIncludesList: S.Schema<ProjectsGetResponseSourceConfigPathIncludesList>;
export type ProjectsGetResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsGetResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsGetResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsGetResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsGetResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsGetResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsGetResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsGetResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsGetResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsGetResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsGetResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsGetResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsGetResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsGetResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsGetResponseSourceConfig: S.Schema<ProjectsGetResponseSourceConfig>;
export type ProjectsGetResponseSourceType = "github" | "gitlab";
export declare const ProjectsGetResponseSourceType: any;
export interface ProjectsGetResponseSource {
    config: ProjectsGetResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsGetResponseSourceType;
}
export declare const ProjectsGetResponseSource: S.Schema<ProjectsGetResponseSource>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectResponse {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsGetResponseCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsGetResponseDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsGetResponseCanonicalDeployment;
    /** Name of the project. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsGetResponseDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsGetResponseSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export declare const GetProjectResponse: S.Schema<GetProjectResponse>;
export interface GetProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** Identifier. */
    deploymentId: string;
}
export declare const GetProjectDeploymentRequest: S.Schema<GetProjectDeploymentRequest>;
export type ProjectsDeploymentsGetResponseAliasesList = Array<string>;
export declare const ProjectsDeploymentsGetResponseAliasesList: S.Schema<ProjectsDeploymentsGetResponseAliasesList>;
export type ProjectsDeploymentsGetResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsDeploymentsGetResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsDeploymentsGetResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsDeploymentsGetResponseDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsDeploymentsGetResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsDeploymentsGetResponseDeploymentTriggerType: any;
export interface ProjectsDeploymentsGetResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsGetResponseDeploymentTriggerType;
}
export declare const ProjectsDeploymentsGetResponseDeploymentTrigger: S.Schema<ProjectsDeploymentsGetResponseDeploymentTrigger>;
export type ProjectsDeploymentsGetResponseEnvironment = "preview" | "production";
export declare const ProjectsDeploymentsGetResponseEnvironment: any;
export type ProjectsDeploymentsGetResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsDeploymentsGetResponseLatestStageName: any;
export type ProjectsDeploymentsGetResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsDeploymentsGetResponseLatestStageStatus: any;
export interface ProjectsDeploymentsGetResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsGetResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsGetResponseLatestStageStatus;
}
export declare const ProjectsDeploymentsGetResponseLatestStage: S.Schema<ProjectsDeploymentsGetResponseLatestStage>;
export type ProjectsDeploymentsGetResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsDeploymentsGetResponseSourceConfigPathExcludesList: S.Schema<ProjectsDeploymentsGetResponseSourceConfigPathExcludesList>;
export type ProjectsDeploymentsGetResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsDeploymentsGetResponseSourceConfigPathIncludesList: S.Schema<ProjectsDeploymentsGetResponseSourceConfigPathIncludesList>;
export type ProjectsDeploymentsGetResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsDeploymentsGetResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsDeploymentsGetResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsDeploymentsGetResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsDeploymentsGetResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsDeploymentsGetResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsDeploymentsGetResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsDeploymentsGetResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsDeploymentsGetResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsGetResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsGetResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsGetResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsGetResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsGetResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsDeploymentsGetResponseSourceConfig: S.Schema<ProjectsDeploymentsGetResponseSourceConfig>;
export type ProjectsDeploymentsGetResponseSourceType = "github" | "gitlab";
export declare const ProjectsDeploymentsGetResponseSourceType: any;
export interface ProjectsDeploymentsGetResponseSource {
    config: ProjectsDeploymentsGetResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsGetResponseSourceType;
}
export declare const ProjectsDeploymentsGetResponseSource: S.Schema<ProjectsDeploymentsGetResponseSource>;
export type ProjectsDeploymentsGetResponseStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsDeploymentsGetResponseStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsDeploymentsGetResponseStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsDeploymentsGetResponseStagesList: S.Schema<ProjectsDeploymentsGetResponseStagesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsGetResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsGetResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsGetResponseEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsGetResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsGetResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsGetResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const GetProjectDeploymentResponse: S.Schema<GetProjectDeploymentResponse>;
export interface GetProjectDeploymentHistoryLogRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** Identifier. */
    deploymentId: string;
}
export declare const GetProjectDeploymentHistoryLogRequest: S.Schema<GetProjectDeploymentHistoryLogRequest>;
export interface ProjectsDeploymentsHistoryLogsGetResponseDataItem {
    line: string;
    ts: string;
}
export declare const ProjectsDeploymentsHistoryLogsGetResponseDataItem: S.Schema<ProjectsDeploymentsHistoryLogsGetResponseDataItem>;
export type ProjectsDeploymentsHistoryLogsGetResponseDataList = Array<ProjectsDeploymentsHistoryLogsGetResponseDataItem>;
export declare const ProjectsDeploymentsHistoryLogsGetResponseDataList: S.Schema<ProjectsDeploymentsHistoryLogsGetResponseDataList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectDeploymentHistoryLogResponse {
    data: ProjectsDeploymentsHistoryLogsGetResponseDataList;
    includesContainerLogs: boolean;
    total: number;
}
export declare const GetProjectDeploymentHistoryLogResponse: S.Schema<GetProjectDeploymentHistoryLogResponse>;
export interface GetProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** The domain name. */
    domainName: string;
}
export declare const GetProjectDomainRequest: S.Schema<GetProjectDomainRequest>;
export type ProjectsDomainsGetResponseCertificateAuthority = "google" | "lets_encrypt";
export declare const ProjectsDomainsGetResponseCertificateAuthority: any;
export type ProjectsDomainsGetResponseStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsGetResponseStatus: any;
export type ProjectsDomainsGetResponseValidationDataMethod = "http" | "txt";
export declare const ProjectsDomainsGetResponseValidationDataMethod: any;
export type ProjectsDomainsGetResponseValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export declare const ProjectsDomainsGetResponseValidationDataStatus: any;
export interface ProjectsDomainsGetResponseValidationData {
    method: ProjectsDomainsGetResponseValidationDataMethod;
    status: ProjectsDomainsGetResponseValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export declare const ProjectsDomainsGetResponseValidationData: S.Schema<ProjectsDomainsGetResponseValidationData>;
export type ProjectsDomainsGetResponseVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsGetResponseVerificationDataStatus: any;
export interface ProjectsDomainsGetResponseVerificationData {
    status: ProjectsDomainsGetResponseVerificationDataStatus;
    errorMessage?: string | null;
}
export declare const ProjectsDomainsGetResponseVerificationData: S.Schema<ProjectsDomainsGetResponseVerificationData>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProjectDomainResponse {
    id: string;
    certificateAuthority: ProjectsDomainsGetResponseCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** The domain name. */
    name: string;
    status: ProjectsDomainsGetResponseStatus;
    validationData: ProjectsDomainsGetResponseValidationData;
    verificationData: ProjectsDomainsGetResponseVerificationData;
    zoneTag: string;
}
export declare const GetProjectDomainResponse: S.Schema<GetProjectDomainResponse>;
export type ProjectsDeploymentsListRequestEnv = "production" | "preview";
export declare const ProjectsDeploymentsListRequestEnv: any;
export interface ListProjectDeploymentsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** What type of deployments to fetch. */
    env?: ProjectsDeploymentsListRequestEnv | (string & {});
    /** Which page of deployments to fetch. */
    page?: number;
    /** How many deployments to return per page. */
    perPage?: number;
}
export declare const ListProjectDeploymentsRequest: S.Schema<ListProjectDeploymentsRequest>;
export type ProjectsDeploymentsListResultItemAliasesList = Array<string>;
export declare const ProjectsDeploymentsListResultItemAliasesList: S.Schema<ProjectsDeploymentsListResultItemAliasesList>;
export type ProjectsDeploymentsListResultItemBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsDeploymentsListResultItemBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsDeploymentsListResultItemDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsDeploymentsListResultItemDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsDeploymentsListResultItemDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsDeploymentsListResultItemDeploymentTriggerType: any;
export interface ProjectsDeploymentsListResultItemDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsListResultItemDeploymentTriggerType;
}
export declare const ProjectsDeploymentsListResultItemDeploymentTrigger: S.Schema<ProjectsDeploymentsListResultItemDeploymentTrigger>;
export type ProjectsDeploymentsListResultItemEnvironment = "preview" | "production";
export declare const ProjectsDeploymentsListResultItemEnvironment: any;
export type ProjectsDeploymentsListResultItemLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsDeploymentsListResultItemLatestStageName: any;
export type ProjectsDeploymentsListResultItemLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsDeploymentsListResultItemLatestStageStatus: any;
export interface ProjectsDeploymentsListResultItemLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsListResultItemLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsListResultItemLatestStageStatus;
}
export declare const ProjectsDeploymentsListResultItemLatestStage: S.Schema<ProjectsDeploymentsListResultItemLatestStage>;
export type ProjectsDeploymentsListResultItemSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsDeploymentsListResultItemSourceConfigPathExcludesList: S.Schema<ProjectsDeploymentsListResultItemSourceConfigPathExcludesList>;
export type ProjectsDeploymentsListResultItemSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsDeploymentsListResultItemSourceConfigPathIncludesList: S.Schema<ProjectsDeploymentsListResultItemSourceConfigPathIncludesList>;
export type ProjectsDeploymentsListResultItemSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsDeploymentsListResultItemSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsDeploymentsListResultItemSourceConfigPreviewBranchExcludesList>;
export type ProjectsDeploymentsListResultItemSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsDeploymentsListResultItemSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsDeploymentsListResultItemSourceConfigPreviewBranchIncludesList>;
export type ProjectsDeploymentsListResultItemSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsDeploymentsListResultItemSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsDeploymentsListResultItemSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsListResultItemSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsListResultItemSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsListResultItemSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsListResultItemSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsListResultItemSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsDeploymentsListResultItemSourceConfig: S.Schema<ProjectsDeploymentsListResultItemSourceConfig>;
export type ProjectsDeploymentsListResultItemSourceType = "github" | "gitlab";
export declare const ProjectsDeploymentsListResultItemSourceType: any;
export interface ProjectsDeploymentsListResultItemSource {
    config: ProjectsDeploymentsListResultItemSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsListResultItemSourceType;
}
export declare const ProjectsDeploymentsListResultItemSource: S.Schema<ProjectsDeploymentsListResultItemSource>;
export type ProjectsDeploymentsListResultItemStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsDeploymentsListResultItemStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsDeploymentsListResultItemStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsDeploymentsListResultItemStagesList: S.Schema<ProjectsDeploymentsListResultItemStagesList>;
export interface ProjectsDeploymentsListResultItem {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsListResultItemAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsListResultItemDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsListResultItemEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsListResultItemLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsListResultItemSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsListResultItemStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const ProjectsDeploymentsListResultItem: S.Schema<ProjectsDeploymentsListResultItem>;
export type ProjectsDeploymentsListResultList = Array<ProjectsDeploymentsListResultItem>;
export declare const ProjectsDeploymentsListResultList: S.Schema<ProjectsDeploymentsListResultList>;
export interface ListProjectDeploymentsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProjectsDeploymentsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListProjectDeploymentsResponse: S.Schema<ListProjectDeploymentsResponse>;
export interface ListProjectDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
}
export declare const ListProjectDomainsRequest: S.Schema<ListProjectDomainsRequest>;
export type ProjectsDomainsListResultItemCertificateAuthority = "google" | "lets_encrypt";
export declare const ProjectsDomainsListResultItemCertificateAuthority: any;
export type ProjectsDomainsListResultItemStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsListResultItemStatus: any;
export type ProjectsDomainsListResultItemValidationDataMethod = "http" | "txt";
export declare const ProjectsDomainsListResultItemValidationDataMethod: any;
export type ProjectsDomainsListResultItemValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export declare const ProjectsDomainsListResultItemValidationDataStatus: any;
export interface ProjectsDomainsListResultItemValidationData {
    method: ProjectsDomainsListResultItemValidationDataMethod;
    status: ProjectsDomainsListResultItemValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export declare const ProjectsDomainsListResultItemValidationData: S.Schema<ProjectsDomainsListResultItemValidationData>;
export type ProjectsDomainsListResultItemVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsListResultItemVerificationDataStatus: any;
export interface ProjectsDomainsListResultItemVerificationData {
    status: ProjectsDomainsListResultItemVerificationDataStatus;
    errorMessage?: string | null;
}
export declare const ProjectsDomainsListResultItemVerificationData: S.Schema<ProjectsDomainsListResultItemVerificationData>;
export interface ProjectsDomainsListResultItem {
    id: string;
    certificateAuthority: ProjectsDomainsListResultItemCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** The domain name. */
    name: string;
    status: ProjectsDomainsListResultItemStatus;
    validationData: ProjectsDomainsListResultItemValidationData;
    verificationData: ProjectsDomainsListResultItemVerificationData;
    zoneTag: string;
}
export declare const ProjectsDomainsListResultItem: S.Schema<ProjectsDomainsListResultItem>;
export type ProjectsDomainsListResultList = Array<ProjectsDomainsListResultItem>;
export declare const ProjectsDomainsListResultList: S.Schema<ProjectsDomainsListResultList>;
export interface ListProjectDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProjectsDomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListProjectDomainsResponse: S.Schema<ListProjectDomainsResponse>;
export interface ListProjectsRequest {
    /** Identifier. */
    accountId: string;
    /** Which page of projects to fetch. */
    page?: number;
    /** How many projects to return per page. */
    perPage?: number;
}
export declare const ListProjectsRequest: S.Schema<ListProjectsRequest>;
export type ProjectsListResultItemCanonicalDeploymentAliasesList = Array<string>;
export declare const ProjectsListResultItemCanonicalDeploymentAliasesList: S.Schema<ProjectsListResultItemCanonicalDeploymentAliasesList>;
export type ProjectsListResultItemCanonicalDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsListResultItemCanonicalDeploymentBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsListResultItemCanonicalDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsListResultItemCanonicalDeploymentDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsListResultItemCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsListResultItemCanonicalDeploymentDeploymentTriggerType: any;
export interface ProjectsListResultItemCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsListResultItemCanonicalDeploymentDeploymentTriggerType;
}
export declare const ProjectsListResultItemCanonicalDeploymentDeploymentTrigger: S.Schema<ProjectsListResultItemCanonicalDeploymentDeploymentTrigger>;
export type ProjectsListResultItemCanonicalDeploymentEnvironment = "preview" | "production";
export declare const ProjectsListResultItemCanonicalDeploymentEnvironment: any;
export type ProjectsListResultItemCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsListResultItemCanonicalDeploymentLatestStageName: any;
export type ProjectsListResultItemCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsListResultItemCanonicalDeploymentLatestStageStatus: any;
export interface ProjectsListResultItemCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsListResultItemCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsListResultItemCanonicalDeploymentLatestStageStatus;
}
export declare const ProjectsListResultItemCanonicalDeploymentLatestStage: S.Schema<ProjectsListResultItemCanonicalDeploymentLatestStage>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsListResultItemCanonicalDeploymentSourceConfigPathExcludesList: S.Schema<ProjectsListResultItemCanonicalDeploymentSourceConfigPathExcludesList>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsListResultItemCanonicalDeploymentSourceConfigPathIncludesList: S.Schema<ProjectsListResultItemCanonicalDeploymentSourceConfigPathIncludesList>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchExcludesList>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchIncludesList>;
export type ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsListResultItemCanonicalDeploymentSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsListResultItemCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsListResultItemCanonicalDeploymentSourceConfig: S.Schema<ProjectsListResultItemCanonicalDeploymentSourceConfig>;
export type ProjectsListResultItemCanonicalDeploymentSourceType = "github" | "gitlab";
export declare const ProjectsListResultItemCanonicalDeploymentSourceType: any;
export interface ProjectsListResultItemCanonicalDeploymentSource {
    config: ProjectsListResultItemCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsListResultItemCanonicalDeploymentSourceType;
}
export declare const ProjectsListResultItemCanonicalDeploymentSource: S.Schema<ProjectsListResultItemCanonicalDeploymentSource>;
export type ProjectsListResultItemCanonicalDeploymentStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsListResultItemCanonicalDeploymentStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsListResultItemCanonicalDeploymentStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsListResultItemCanonicalDeploymentStagesList: S.Schema<ProjectsListResultItemCanonicalDeploymentStagesList>;
export interface ProjectsListResultItemCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsListResultItemCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsListResultItemCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsListResultItemCanonicalDeploymentEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsListResultItemCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsListResultItemCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsListResultItemCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const ProjectsListResultItemCanonicalDeployment: S.Schema<ProjectsListResultItemCanonicalDeployment>;
export type ProjectsListResultItemDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export declare const ProjectsListResultItemDeploymentConfigsPreviewCompatibilityFlagsList: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewCompatibilityFlagsList>;
export type ProjectsListResultItemDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsListResultItemDeploymentConfigsPreviewUsageModel: any;
export type ProjectsListResultItemDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewAiBindingsMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewAiBindingsMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewBrowsersMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewBrowsersMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewD1DatabasesMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewD1DatabasesMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewKvNamespacesMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewKvNamespacesMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsListResultItemDeploymentConfigsPreviewLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsListResultItemDeploymentConfigsPreviewPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsListResultItemDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewQueueProducersMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewQueueProducersMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewR2BucketsMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewR2BucketsMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewServicesMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewServicesMap>;
export type ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsMap: S.Schema<ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsMap>;
export interface ProjectsListResultItemDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsListResultItemDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsListResultItemDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsListResultItemDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsListResultItemDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsListResultItemDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsListResultItemDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsListResultItemDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsListResultItemDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsListResultItemDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsListResultItemDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsListResultItemDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsListResultItemDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsListResultItemDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsListResultItemDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsListResultItemDeploymentConfigsPreview: S.Schema<ProjectsListResultItemDeploymentConfigsPreview>;
export type ProjectsListResultItemDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export declare const ProjectsListResultItemDeploymentConfigsProductionCompatibilityFlagsList: S.Schema<ProjectsListResultItemDeploymentConfigsProductionCompatibilityFlagsList>;
export type ProjectsListResultItemDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsListResultItemDeploymentConfigsProductionUsageModel: any;
export type ProjectsListResultItemDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsListResultItemDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionAiBindingsMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionAiBindingsMap>;
export type ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsMap>;
export type ProjectsListResultItemDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionBrowsersMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionBrowsersMap>;
export type ProjectsListResultItemDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionD1DatabasesMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionD1DatabasesMap>;
export type ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesMap>;
export type ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsMap>;
export type ProjectsListResultItemDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionKvNamespacesMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionKvNamespacesMap>;
export type ProjectsListResultItemDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsListResultItemDeploymentConfigsProductionLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesMap>;
export type ProjectsListResultItemDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsListResultItemDeploymentConfigsProductionPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsListResultItemDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsListResultItemDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionQueueProducersMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionQueueProducersMap>;
export type ProjectsListResultItemDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionR2BucketsMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionR2BucketsMap>;
export type ProjectsListResultItemDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsListResultItemDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionServicesMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionServicesMap>;
export type ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsMap: S.Schema<ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsMap>;
export interface ProjectsListResultItemDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsListResultItemDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsListResultItemDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsListResultItemDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsListResultItemDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsListResultItemDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsListResultItemDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsListResultItemDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsListResultItemDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsListResultItemDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsListResultItemDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsListResultItemDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsListResultItemDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsListResultItemDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsListResultItemDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsListResultItemDeploymentConfigsProduction: S.Schema<ProjectsListResultItemDeploymentConfigsProduction>;
export interface ProjectsListResultItemDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsListResultItemDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsListResultItemDeploymentConfigsProduction;
}
export declare const ProjectsListResultItemDeploymentConfigs: S.Schema<ProjectsListResultItemDeploymentConfigs>;
export type ProjectsListResultItemBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsListResultItemBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsListResultItemDomainsList = Array<string>;
export declare const ProjectsListResultItemDomainsList: S.Schema<ProjectsListResultItemDomainsList>;
export type ProjectsListResultItemSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsListResultItemSourceConfigPathExcludesList: S.Schema<ProjectsListResultItemSourceConfigPathExcludesList>;
export type ProjectsListResultItemSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsListResultItemSourceConfigPathIncludesList: S.Schema<ProjectsListResultItemSourceConfigPathIncludesList>;
export type ProjectsListResultItemSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsListResultItemSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsListResultItemSourceConfigPreviewBranchExcludesList>;
export type ProjectsListResultItemSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsListResultItemSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsListResultItemSourceConfigPreviewBranchIncludesList>;
export type ProjectsListResultItemSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsListResultItemSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsListResultItemSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsListResultItemSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsListResultItemSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsListResultItemSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsListResultItemSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsListResultItemSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsListResultItemSourceConfig: S.Schema<ProjectsListResultItemSourceConfig>;
export type ProjectsListResultItemSourceType = "github" | "gitlab";
export declare const ProjectsListResultItemSourceType: any;
export interface ProjectsListResultItemSource {
    config: ProjectsListResultItemSourceConfig;
    /** The source control management provider. */
    type: ProjectsListResultItemSourceType;
}
export declare const ProjectsListResultItemSource: S.Schema<ProjectsListResultItemSource>;
export interface ProjectsListResultItem {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsListResultItemCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsListResultItemDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsListResultItemCanonicalDeployment;
    /** Name of the project. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsListResultItemDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsListResultItemSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export declare const ProjectsListResultItem: S.Schema<ProjectsListResultItem>;
export type ProjectsListResultList = Array<ProjectsListResultItem>;
export declare const ProjectsListResultList: S.Schema<ProjectsListResultList>;
export interface ListProjectsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProjectsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListProjectsResponse: S.Schema<ListProjectsResponse>;
export type ProjectsEditRequestBuildConfig = ProjectsCreateRequestBuildConfig;
export declare const ProjectsEditRequestBuildConfig: S.Schema<ProjectsCreateRequestBuildConfig>;
export type ProjectsEditRequestDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewAiBindingsMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewAiBindingsMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewBrowsersMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewBrowsersMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export declare const ProjectsEditRequestDeploymentConfigsPreviewCompatibilityFlagsList: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewCompatibilityFlagsList>;
export type ProjectsEditRequestDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewD1DatabasesMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewD1DatabasesMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewKvNamespacesMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewKvNamespacesMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsEditRequestDeploymentConfigsPreviewLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsEditRequestDeploymentConfigsPreviewPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsEditRequestDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewQueueProducersMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewQueueProducersMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewR2BucketsMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewR2BucketsMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewServicesValue = ProjectsCreateRequestDeploymentConfigsPreviewServicesValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewServicesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewServicesValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewServicesMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewServicesMap>;
export type ProjectsEditRequestDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsEditRequestDeploymentConfigsPreviewUsageModel: any;
export type ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsMap: S.Schema<ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsMap>;
export interface ProjectsEditRequestDeploymentConfigsPreview {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditRequestDeploymentConfigsPreviewAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditRequestDeploymentConfigsPreviewBrowsersMap;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsEditRequestDeploymentConfigsPreviewCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditRequestDeploymentConfigsPreviewD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditRequestDeploymentConfigsPreviewDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditRequestDeploymentConfigsPreviewHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditRequestDeploymentConfigsPreviewKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditRequestDeploymentConfigsPreviewMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditRequestDeploymentConfigsPreviewQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditRequestDeploymentConfigsPreviewR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsEditRequestDeploymentConfigsPreviewServicesMap;
    /** The usage model for Pages Functions. */
    usageModel?: ProjectsEditRequestDeploymentConfigsPreviewUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditRequestDeploymentConfigsPreviewVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export declare const ProjectsEditRequestDeploymentConfigsPreview: S.Schema<ProjectsEditRequestDeploymentConfigsPreview>;
export type ProjectsEditRequestDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsEditRequestDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionAiBindingsMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionAiBindingsMap>;
export type ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap>;
export type ProjectsEditRequestDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionBrowsersMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionBrowsersMap>;
export type ProjectsEditRequestDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export declare const ProjectsEditRequestDeploymentConfigsProductionCompatibilityFlagsList: S.Schema<ProjectsEditRequestDeploymentConfigsProductionCompatibilityFlagsList>;
export type ProjectsEditRequestDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionD1DatabasesMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionD1DatabasesMap>;
export type ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesMap>;
export type ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsMap>;
export type ProjectsEditRequestDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionKvNamespacesMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionKvNamespacesMap>;
export type ProjectsEditRequestDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsEditRequestDeploymentConfigsProductionLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesMap>;
export type ProjectsEditRequestDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsEditRequestDeploymentConfigsProductionPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsEditRequestDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsEditRequestDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionQueueProducersMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionQueueProducersMap>;
export type ProjectsEditRequestDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionR2BucketsMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionR2BucketsMap>;
export type ProjectsEditRequestDeploymentConfigsProductionServicesValue = ProjectsCreateRequestDeploymentConfigsPreviewServicesValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionServicesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewServicesValue>;
export type ProjectsEditRequestDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionServicesMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionServicesMap>;
export type ProjectsEditRequestDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsEditRequestDeploymentConfigsProductionUsageModel: any;
export type ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsMap: S.Schema<ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsMap>;
export interface ProjectsEditRequestDeploymentConfigsProduction {
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditRequestDeploymentConfigsProductionAiBindingsMap;
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate?: boolean;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditRequestDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditRequestDeploymentConfigsProductionBrowsersMap;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion?: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate?: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags?: ProjectsEditRequestDeploymentConfigsProductionCompatibilityFlagsList;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditRequestDeploymentConfigsProductionD1DatabasesMap;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditRequestDeploymentConfigsProductionDurableObjectNamespacesMap;
    /** Environment variables used for builds and Pages Functions. */
    envVars?: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen?: boolean;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditRequestDeploymentConfigsProductionHyperdriveBindingsMap;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditRequestDeploymentConfigsProductionKvNamespacesMap;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditRequestDeploymentConfigsProductionMtlsCertificatesMap;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditRequestDeploymentConfigsProductionQueueProducersMap;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditRequestDeploymentConfigsProductionR2BucketsMap;
    /** Services used for Pages Functions. */
    services?: ProjectsEditRequestDeploymentConfigsProductionServicesMap;
    /** The usage model for Pages Functions. */
    usageModel?: ProjectsEditRequestDeploymentConfigsProductionUsageModel | (string & {});
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditRequestDeploymentConfigsProductionVectorizeBindingsMap;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string;
}
export declare const ProjectsEditRequestDeploymentConfigsProduction: S.Schema<ProjectsEditRequestDeploymentConfigsProduction>;
export interface ProjectsEditRequestDeploymentConfigs {
    /** Configs for preview deploys. */
    preview?: ProjectsEditRequestDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production?: ProjectsEditRequestDeploymentConfigsProduction;
}
export declare const ProjectsEditRequestDeploymentConfigs: S.Schema<ProjectsEditRequestDeploymentConfigs>;
export type ProjectsEditRequestSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsEditRequestSourceConfigPathExcludesList: S.Schema<ProjectsEditRequestSourceConfigPathExcludesList>;
export type ProjectsEditRequestSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsEditRequestSourceConfigPathIncludesList: S.Schema<ProjectsEditRequestSourceConfigPathIncludesList>;
export type ProjectsEditRequestSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsEditRequestSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsEditRequestSourceConfigPreviewBranchExcludesList>;
export type ProjectsEditRequestSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsEditRequestSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsEditRequestSourceConfigPreviewBranchIncludesList>;
export type ProjectsEditRequestSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsEditRequestSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsEditRequestSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled?: boolean;
    /** The owner of the repository. */
    owner?: string;
    /** The owner ID of the repository. */
    ownerId?: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes?: ProjectsEditRequestSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes?: ProjectsEditRequestSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled?: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes?: ProjectsEditRequestSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes?: ProjectsEditRequestSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting?: ProjectsEditRequestSourceConfigPreviewDeploymentSetting | (string & {});
    /** The production branch of the repository. */
    productionBranch?: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled?: boolean;
    /** The ID of the repository. */
    repoId?: string;
    /** The name of the repository. */
    repoName?: string;
}
export declare const ProjectsEditRequestSourceConfig: S.Schema<ProjectsEditRequestSourceConfig>;
export type ProjectsEditRequestSourceType = "github" | "gitlab";
export declare const ProjectsEditRequestSourceType: any;
export interface ProjectsEditRequestSource {
    config: ProjectsEditRequestSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditRequestSourceType | (string & {});
}
export declare const ProjectsEditRequestSource: S.Schema<ProjectsEditRequestSource>;
export interface PatchProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateRequestBuildConfig;
    /** Configs for deployments in a project. */
    deploymentConfigs?: ProjectsEditRequestDeploymentConfigs;
    /** Name of the project. */
    name?: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch?: string;
    /** Configs for the project source control. */
    source?: ProjectsEditRequestSource;
}
export declare const PatchProjectRequest: S.Schema<PatchProjectRequest>;
export type ProjectsEditResponseCanonicalDeploymentAliasesList = Array<string>;
export declare const ProjectsEditResponseCanonicalDeploymentAliasesList: S.Schema<ProjectsEditResponseCanonicalDeploymentAliasesList>;
export type ProjectsEditResponseCanonicalDeploymentBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsEditResponseCanonicalDeploymentBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsEditResponseCanonicalDeploymentDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsEditResponseCanonicalDeploymentDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsEditResponseCanonicalDeploymentDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsEditResponseCanonicalDeploymentDeploymentTriggerType: any;
export interface ProjectsEditResponseCanonicalDeploymentDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsEditResponseCanonicalDeploymentDeploymentTriggerType;
}
export declare const ProjectsEditResponseCanonicalDeploymentDeploymentTrigger: S.Schema<ProjectsEditResponseCanonicalDeploymentDeploymentTrigger>;
export type ProjectsEditResponseCanonicalDeploymentEnvironment = "preview" | "production";
export declare const ProjectsEditResponseCanonicalDeploymentEnvironment: any;
export type ProjectsEditResponseCanonicalDeploymentLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsEditResponseCanonicalDeploymentLatestStageName: any;
export type ProjectsEditResponseCanonicalDeploymentLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsEditResponseCanonicalDeploymentLatestStageStatus: any;
export interface ProjectsEditResponseCanonicalDeploymentLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsEditResponseCanonicalDeploymentLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsEditResponseCanonicalDeploymentLatestStageStatus;
}
export declare const ProjectsEditResponseCanonicalDeploymentLatestStage: S.Schema<ProjectsEditResponseCanonicalDeploymentLatestStage>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsEditResponseCanonicalDeploymentSourceConfigPathExcludesList: S.Schema<ProjectsEditResponseCanonicalDeploymentSourceConfigPathExcludesList>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsEditResponseCanonicalDeploymentSourceConfigPathIncludesList: S.Schema<ProjectsEditResponseCanonicalDeploymentSourceConfigPathIncludesList>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList>;
export type ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsEditResponseCanonicalDeploymentSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsEditResponseCanonicalDeploymentSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsEditResponseCanonicalDeploymentSourceConfig: S.Schema<ProjectsEditResponseCanonicalDeploymentSourceConfig>;
export type ProjectsEditResponseCanonicalDeploymentSourceType = "github" | "gitlab";
export declare const ProjectsEditResponseCanonicalDeploymentSourceType: any;
export interface ProjectsEditResponseCanonicalDeploymentSource {
    config: ProjectsEditResponseCanonicalDeploymentSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditResponseCanonicalDeploymentSourceType;
}
export declare const ProjectsEditResponseCanonicalDeploymentSource: S.Schema<ProjectsEditResponseCanonicalDeploymentSource>;
export type ProjectsEditResponseCanonicalDeploymentStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsEditResponseCanonicalDeploymentStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsEditResponseCanonicalDeploymentStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsEditResponseCanonicalDeploymentStagesList: S.Schema<ProjectsEditResponseCanonicalDeploymentStagesList>;
export interface ProjectsEditResponseCanonicalDeployment {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsEditResponseCanonicalDeploymentAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsEditResponseCanonicalDeploymentDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsEditResponseCanonicalDeploymentEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsEditResponseCanonicalDeploymentLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsEditResponseCanonicalDeploymentSource;
    /** List of past stages. */
    stages: ProjectsEditResponseCanonicalDeploymentStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const ProjectsEditResponseCanonicalDeployment: S.Schema<ProjectsEditResponseCanonicalDeployment>;
export type ProjectsEditResponseDeploymentConfigsPreviewCompatibilityFlagsList = Array<string>;
export declare const ProjectsEditResponseDeploymentConfigsPreviewCompatibilityFlagsList: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewCompatibilityFlagsList>;
export type ProjectsEditResponseDeploymentConfigsPreviewUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsEditResponseDeploymentConfigsPreviewUsageModel: any;
export type ProjectsEditResponseDeploymentConfigsPreviewAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewAiBindingsMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewAiBindingsMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewBrowsersMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewBrowsersMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewD1DatabasesMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewD1DatabasesMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewKvNamespacesMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewKvNamespacesMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsEditResponseDeploymentConfigsPreviewLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsEditResponseDeploymentConfigsPreviewPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsEditResponseDeploymentConfigsPreviewQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewQueueProducersMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewQueueProducersMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewR2BucketsMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewR2BucketsMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewServicesMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewServicesMap>;
export type ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsMap: S.Schema<ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsMap>;
export interface ProjectsEditResponseDeploymentConfigsPreview {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsEditResponseDeploymentConfigsPreviewCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsEditResponseDeploymentConfigsPreviewUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditResponseDeploymentConfigsPreviewAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditResponseDeploymentConfigsPreviewAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditResponseDeploymentConfigsPreviewBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditResponseDeploymentConfigsPreviewD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditResponseDeploymentConfigsPreviewDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditResponseDeploymentConfigsPreviewHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditResponseDeploymentConfigsPreviewKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditResponseDeploymentConfigsPreviewMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditResponseDeploymentConfigsPreviewQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditResponseDeploymentConfigsPreviewR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsEditResponseDeploymentConfigsPreviewServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditResponseDeploymentConfigsPreviewVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsEditResponseDeploymentConfigsPreview: S.Schema<ProjectsEditResponseDeploymentConfigsPreview>;
export type ProjectsEditResponseDeploymentConfigsProductionCompatibilityFlagsList = Array<string>;
export declare const ProjectsEditResponseDeploymentConfigsProductionCompatibilityFlagsList: S.Schema<ProjectsEditResponseDeploymentConfigsProductionCompatibilityFlagsList>;
export type ProjectsEditResponseDeploymentConfigsProductionUsageModel = "standard" | "bundled" | "unbound";
export declare const ProjectsEditResponseDeploymentConfigsProductionUsageModel: any;
export type ProjectsEditResponseDeploymentConfigsProductionAiBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionAiBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue>;
export type ProjectsEditResponseDeploymentConfigsProductionAiBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAiBindingsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionAiBindingsMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionAiBindingsMap>;
export type ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue = ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue>;
export type ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewAnalyticsEngineDatasetsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap>;
export type ProjectsEditResponseDeploymentConfigsProductionBrowsersMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionBrowsersMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionBrowsersMap>;
export type ProjectsEditResponseDeploymentConfigsProductionD1DatabasesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionD1DatabasesMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionD1DatabasesMap>;
export type ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesValue = ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue>;
export type ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewDurableObjectNamespacesValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesMap>;
export type ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue>;
export type ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewHyperdriveBindingsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsMap>;
export type ProjectsEditResponseDeploymentConfigsProductionKvNamespacesMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionKvNamespacesMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionKvNamespacesMap>;
export type ProjectsEditResponseDeploymentConfigsProductionLimits = ProjectsCreateRequestDeploymentConfigsPreviewLimits;
export declare const ProjectsEditResponseDeploymentConfigsProductionLimits: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewLimits>;
export type ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesValue = ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue>;
export type ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewMtlsCertificatesValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesMap>;
export type ProjectsEditResponseDeploymentConfigsProductionPlacement = ProjectsCreateRequestDeploymentConfigsPreviewPlacement;
export declare const ProjectsEditResponseDeploymentConfigsProductionPlacement: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewPlacement>;
export type ProjectsEditResponseDeploymentConfigsProductionQueueProducersValue = ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionQueueProducersValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue>;
export type ProjectsEditResponseDeploymentConfigsProductionQueueProducersMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewQueueProducersValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionQueueProducersMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionQueueProducersMap>;
export type ProjectsEditResponseDeploymentConfigsProductionR2BucketsMap = {
    [key: string]: unknown | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionR2BucketsMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionR2BucketsMap>;
export type ProjectsEditResponseDeploymentConfigsProductionServicesValue = ProjectsCreateResponseDeploymentConfigsPreviewServicesValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionServicesValue: S.Schema<ProjectsCreateResponseDeploymentConfigsPreviewServicesValue>;
export type ProjectsEditResponseDeploymentConfigsProductionServicesMap = {
    [key: string]: ProjectsCreateResponseDeploymentConfigsPreviewServicesValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionServicesMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionServicesMap>;
export type ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsValue = ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue;
export declare const ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsValue: S.Schema<ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue>;
export type ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsMap = {
    [key: string]: ProjectsCreateRequestDeploymentConfigsPreviewVectorizeBindingsValue | undefined;
};
export declare const ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsMap: S.Schema<ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsMap>;
export interface ProjectsEditResponseDeploymentConfigsProduction {
    /** Whether to always use the latest compatibility date for Pages Functions. */
    alwaysUseLatestCompatibilityDate: boolean;
    /** The major version of the build image to use for Pages Functions. */
    buildImageMajorVersion: number;
    /** Compatibility date used for Pages Functions. */
    compatibilityDate: string;
    /** Compatibility flags used for Pages Functions. */
    compatibilityFlags: ProjectsEditResponseDeploymentConfigsProductionCompatibilityFlagsList;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Whether to fail open when the deployment config cannot be applied. */
    failOpen: boolean;
    /** The usage model for Pages Functions. */
    usageModel: ProjectsEditResponseDeploymentConfigsProductionUsageModel;
    /** Constellation bindings used for Pages Functions. */
    aiBindings?: ProjectsEditResponseDeploymentConfigsProductionAiBindingsMap | null;
    /** Analytics Engine bindings used for Pages Functions. */
    analyticsEngineDatasets?: ProjectsEditResponseDeploymentConfigsProductionAnalyticsEngineDatasetsMap | null;
    /** Browser bindings used for Pages Functions. */
    browsers?: ProjectsEditResponseDeploymentConfigsProductionBrowsersMap | null;
    /** D1 databases used for Pages Functions. */
    d1Databases?: ProjectsEditResponseDeploymentConfigsProductionD1DatabasesMap | null;
    /** Durable Object namespaces used for Pages Functions. */
    durableObjectNamespaces?: ProjectsEditResponseDeploymentConfigsProductionDurableObjectNamespacesMap | null;
    /** Hyperdrive bindings used for Pages Functions. */
    hyperdriveBindings?: ProjectsEditResponseDeploymentConfigsProductionHyperdriveBindingsMap | null;
    /** KV namespaces used for Pages Functions. */
    kvNamespaces?: ProjectsEditResponseDeploymentConfigsProductionKvNamespacesMap | null;
    /** Limits for Pages Functions. */
    limits?: ProjectsCreateRequestDeploymentConfigsPreviewLimits | null;
    /** mTLS bindings used for Pages Functions. */
    mtlsCertificates?: ProjectsEditResponseDeploymentConfigsProductionMtlsCertificatesMap | null;
    /** Placement setting used for Pages Functions. */
    placement?: ProjectsCreateRequestDeploymentConfigsPreviewPlacement | null;
    /** Queue Producer bindings used for Pages Functions. */
    queueProducers?: ProjectsEditResponseDeploymentConfigsProductionQueueProducersMap | null;
    /** R2 buckets used for Pages Functions. */
    r2Buckets?: ProjectsEditResponseDeploymentConfigsProductionR2BucketsMap | null;
    /** Services used for Pages Functions. */
    services?: ProjectsEditResponseDeploymentConfigsProductionServicesMap | null;
    /** Vectorize bindings used for Pages Functions. */
    vectorizeBindings?: ProjectsEditResponseDeploymentConfigsProductionVectorizeBindingsMap | null;
    /** Hash of the Wrangler configuration used for the deployment. */
    wranglerConfigHash?: string | null;
}
export declare const ProjectsEditResponseDeploymentConfigsProduction: S.Schema<ProjectsEditResponseDeploymentConfigsProduction>;
export interface ProjectsEditResponseDeploymentConfigs {
    /** Configs for preview deploys. */
    preview: ProjectsEditResponseDeploymentConfigsPreview;
    /** Configs for production deploys. */
    production: ProjectsEditResponseDeploymentConfigsProduction;
}
export declare const ProjectsEditResponseDeploymentConfigs: S.Schema<ProjectsEditResponseDeploymentConfigs>;
export type ProjectsEditResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsEditResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsEditResponseDomainsList = Array<string>;
export declare const ProjectsEditResponseDomainsList: S.Schema<ProjectsEditResponseDomainsList>;
export type ProjectsEditResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsEditResponseSourceConfigPathExcludesList: S.Schema<ProjectsEditResponseSourceConfigPathExcludesList>;
export type ProjectsEditResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsEditResponseSourceConfigPathIncludesList: S.Schema<ProjectsEditResponseSourceConfigPathIncludesList>;
export type ProjectsEditResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsEditResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsEditResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsEditResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsEditResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsEditResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsEditResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsEditResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsEditResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsEditResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsEditResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsEditResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsEditResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsEditResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsEditResponseSourceConfig: S.Schema<ProjectsEditResponseSourceConfig>;
export type ProjectsEditResponseSourceType = "github" | "gitlab";
export declare const ProjectsEditResponseSourceType: any;
export interface ProjectsEditResponseSource {
    config: ProjectsEditResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsEditResponseSourceType;
}
export declare const ProjectsEditResponseSource: S.Schema<ProjectsEditResponseSource>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchProjectResponse {
    /** ID of the project. */
    id: string;
    /** Most recent production deployment of the project. */
    canonicalDeployment: ProjectsEditResponseCanonicalDeployment;
    /** When the project was created. */
    createdOn: string;
    /** Configs for deployments in a project. */
    deploymentConfigs: ProjectsEditResponseDeploymentConfigs;
    /** Framework the project is using. */
    framework: string;
    /** Version of the framework the project is using. */
    frameworkVersion: string;
    /** Most recent deployment of the project. */
    latestDeployment: ProjectsEditResponseCanonicalDeployment;
    /** Name of the project. */
    name: string;
    /** Name of the preview script. */
    previewScriptName: string;
    /** Production branch of the project. Used to identify production deployments. */
    productionBranch: string;
    /** Name of the production script. */
    productionScriptName: string;
    /** Whether the project uses functions. */
    usesFunctions: boolean;
    /** Configs for the project build process. */
    buildConfig?: ProjectsCreateResponseCanonicalDeploymentBuildConfig | null;
    /** A list of associated custom domains for the project. */
    domains?: ProjectsEditResponseDomainsList | null;
    /** Configs for the project source control. */
    source?: ProjectsEditResponseSource | null;
    /** The Cloudflare subdomain associated with the project. */
    subdomain?: string | null;
}
export declare const PatchProjectResponse: S.Schema<PatchProjectResponse>;
export interface PatchProjectDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** The domain name. */
    domainName: string;
}
export declare const PatchProjectDomainRequest: S.Schema<PatchProjectDomainRequest>;
export type ProjectsDomainsEditResponseCertificateAuthority = "google" | "lets_encrypt";
export declare const ProjectsDomainsEditResponseCertificateAuthority: any;
export type ProjectsDomainsEditResponseStatus = "initializing" | "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsEditResponseStatus: any;
export type ProjectsDomainsEditResponseValidationDataMethod = "http" | "txt";
export declare const ProjectsDomainsEditResponseValidationDataMethod: any;
export type ProjectsDomainsEditResponseValidationDataStatus = "initializing" | "pending" | "active" | "deactivated" | "error";
export declare const ProjectsDomainsEditResponseValidationDataStatus: any;
export interface ProjectsDomainsEditResponseValidationData {
    method: ProjectsDomainsEditResponseValidationDataMethod;
    status: ProjectsDomainsEditResponseValidationDataStatus;
    errorMessage?: string | null;
    txtName?: string | null;
    txtValue?: string | null;
}
export declare const ProjectsDomainsEditResponseValidationData: S.Schema<ProjectsDomainsEditResponseValidationData>;
export type ProjectsDomainsEditResponseVerificationDataStatus = "pending" | "active" | "deactivated" | "blocked" | "error";
export declare const ProjectsDomainsEditResponseVerificationDataStatus: any;
export interface ProjectsDomainsEditResponseVerificationData {
    status: ProjectsDomainsEditResponseVerificationDataStatus;
    errorMessage?: string | null;
}
export declare const ProjectsDomainsEditResponseVerificationData: S.Schema<ProjectsDomainsEditResponseVerificationData>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchProjectDomainResponse {
    id: string;
    certificateAuthority: ProjectsDomainsEditResponseCertificateAuthority;
    createdOn: string;
    domainId: string;
    /** The domain name. */
    name: string;
    status: ProjectsDomainsEditResponseStatus;
    validationData: ProjectsDomainsEditResponseValidationData;
    verificationData: ProjectsDomainsEditResponseVerificationData;
    zoneTag: string;
}
export declare const PatchProjectDomainResponse: S.Schema<PatchProjectDomainResponse>;
export interface PurgeBuildCacheProjectRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
}
export declare const PurgeBuildCacheProjectRequest: S.Schema<PurgeBuildCacheProjectRequest>;
export type PurgeBuildCacheProjectResponse = unknown;
export declare const PurgeBuildCacheProjectResponse: S.Schema<PurgeBuildCacheProjectResponse>;
export interface RetryProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** Identifier. */
    deploymentId: string;
}
export declare const RetryProjectDeploymentRequest: S.Schema<RetryProjectDeploymentRequest>;
export type ProjectsDeploymentsRetryResponseAliasesList = Array<string>;
export declare const ProjectsDeploymentsRetryResponseAliasesList: S.Schema<ProjectsDeploymentsRetryResponseAliasesList>;
export type ProjectsDeploymentsRetryResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsDeploymentsRetryResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsDeploymentsRetryResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsDeploymentsRetryResponseDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsDeploymentsRetryResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsDeploymentsRetryResponseDeploymentTriggerType: any;
export interface ProjectsDeploymentsRetryResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsRetryResponseDeploymentTriggerType;
}
export declare const ProjectsDeploymentsRetryResponseDeploymentTrigger: S.Schema<ProjectsDeploymentsRetryResponseDeploymentTrigger>;
export type ProjectsDeploymentsRetryResponseEnvironment = "preview" | "production";
export declare const ProjectsDeploymentsRetryResponseEnvironment: any;
export type ProjectsDeploymentsRetryResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsDeploymentsRetryResponseLatestStageName: any;
export type ProjectsDeploymentsRetryResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsDeploymentsRetryResponseLatestStageStatus: any;
export interface ProjectsDeploymentsRetryResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsRetryResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsRetryResponseLatestStageStatus;
}
export declare const ProjectsDeploymentsRetryResponseLatestStage: S.Schema<ProjectsDeploymentsRetryResponseLatestStage>;
export type ProjectsDeploymentsRetryResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsDeploymentsRetryResponseSourceConfigPathExcludesList: S.Schema<ProjectsDeploymentsRetryResponseSourceConfigPathExcludesList>;
export type ProjectsDeploymentsRetryResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsDeploymentsRetryResponseSourceConfigPathIncludesList: S.Schema<ProjectsDeploymentsRetryResponseSourceConfigPathIncludesList>;
export type ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsDeploymentsRetryResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsDeploymentsRetryResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsDeploymentsRetryResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsRetryResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsRetryResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsRetryResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsRetryResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsDeploymentsRetryResponseSourceConfig: S.Schema<ProjectsDeploymentsRetryResponseSourceConfig>;
export type ProjectsDeploymentsRetryResponseSourceType = "github" | "gitlab";
export declare const ProjectsDeploymentsRetryResponseSourceType: any;
export interface ProjectsDeploymentsRetryResponseSource {
    config: ProjectsDeploymentsRetryResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsRetryResponseSourceType;
}
export declare const ProjectsDeploymentsRetryResponseSource: S.Schema<ProjectsDeploymentsRetryResponseSource>;
export type ProjectsDeploymentsRetryResponseStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsDeploymentsRetryResponseStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsDeploymentsRetryResponseStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsDeploymentsRetryResponseStagesList: S.Schema<ProjectsDeploymentsRetryResponseStagesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RetryProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsRetryResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsRetryResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsRetryResponseEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsRetryResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsRetryResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsRetryResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const RetryProjectDeploymentResponse: S.Schema<RetryProjectDeploymentResponse>;
export interface RollbackProjectDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the project. */
    projectName: string;
    /** Identifier. */
    deploymentId: string;
}
export declare const RollbackProjectDeploymentRequest: S.Schema<RollbackProjectDeploymentRequest>;
export type ProjectsDeploymentsRollbackResponseAliasesList = Array<string>;
export declare const ProjectsDeploymentsRollbackResponseAliasesList: S.Schema<ProjectsDeploymentsRollbackResponseAliasesList>;
export type ProjectsDeploymentsRollbackResponseBuildConfig = ProjectsCreateResponseCanonicalDeploymentBuildConfig;
export declare const ProjectsDeploymentsRollbackResponseBuildConfig: S.Schema<ProjectsCreateResponseCanonicalDeploymentBuildConfig>;
export type ProjectsDeploymentsRollbackResponseDeploymentTriggerMetadata = ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
export declare const ProjectsDeploymentsRollbackResponseDeploymentTriggerMetadata: S.Schema<ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata>;
export type ProjectsDeploymentsRollbackResponseDeploymentTriggerType = "github:push" | "ad_hoc" | "deploy_hook";
export declare const ProjectsDeploymentsRollbackResponseDeploymentTriggerType: any;
export interface ProjectsDeploymentsRollbackResponseDeploymentTrigger {
    /** Additional info about the trigger. */
    metadata: ProjectsCreateResponseCanonicalDeploymentDeploymentTriggerMetadata;
    /** What caused the deployment. */
    type: ProjectsDeploymentsRollbackResponseDeploymentTriggerType;
}
export declare const ProjectsDeploymentsRollbackResponseDeploymentTrigger: S.Schema<ProjectsDeploymentsRollbackResponseDeploymentTrigger>;
export type ProjectsDeploymentsRollbackResponseEnvironment = "preview" | "production";
export declare const ProjectsDeploymentsRollbackResponseEnvironment: any;
export type ProjectsDeploymentsRollbackResponseLatestStageName = "queued" | "initialize" | "clone_repo" | "build" | "deploy";
export declare const ProjectsDeploymentsRollbackResponseLatestStageName: any;
export type ProjectsDeploymentsRollbackResponseLatestStageStatus = "success" | "idle" | "active" | "failure" | "canceled";
export declare const ProjectsDeploymentsRollbackResponseLatestStageStatus: any;
export interface ProjectsDeploymentsRollbackResponseLatestStage {
    /** When the stage ended. */
    endedOn: string;
    /** The current build stage. */
    name: ProjectsDeploymentsRollbackResponseLatestStageName;
    /** When the stage started. */
    startedOn: string;
    /** State of the current stage. */
    status: ProjectsDeploymentsRollbackResponseLatestStageStatus;
}
export declare const ProjectsDeploymentsRollbackResponseLatestStage: S.Schema<ProjectsDeploymentsRollbackResponseLatestStage>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPathExcludesList = Array<string>;
export declare const ProjectsDeploymentsRollbackResponseSourceConfigPathExcludesList: S.Schema<ProjectsDeploymentsRollbackResponseSourceConfigPathExcludesList>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPathIncludesList = Array<string>;
export declare const ProjectsDeploymentsRollbackResponseSourceConfigPathIncludesList: S.Schema<ProjectsDeploymentsRollbackResponseSourceConfigPathIncludesList>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchExcludesList = Array<string>;
export declare const ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchExcludesList: S.Schema<ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchExcludesList>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchIncludesList = Array<string>;
export declare const ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchIncludesList: S.Schema<ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchIncludesList>;
export type ProjectsDeploymentsRollbackResponseSourceConfigPreviewDeploymentSetting = "all" | "none" | "custom";
export declare const ProjectsDeploymentsRollbackResponseSourceConfigPreviewDeploymentSetting: any;
export interface ProjectsDeploymentsRollbackResponseSourceConfig {
    /** Whether to enable automatic deployments when pushing to the source repository. */
    deploymentsEnabled: boolean;
    /** The owner of the repository. */
    owner: string;
    /** The owner ID of the repository. */
    ownerId: string;
    /** A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported. */
    pathExcludes: ProjectsDeploymentsRollbackResponseSourceConfigPathExcludesList;
    /** A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported. */
    pathIncludes: ProjectsDeploymentsRollbackResponseSourceConfigPathIncludesList;
    /** Whether to enable PR comments. */
    prCommentsEnabled: boolean;
    /** A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchExcludes: ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchExcludesList;
    /** A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`. */
    previewBranchIncludes: ProjectsDeploymentsRollbackResponseSourceConfigPreviewBranchIncludesList;
    /** Controls whether commits to preview branches trigger a preview deployment. */
    previewDeploymentSetting: ProjectsDeploymentsRollbackResponseSourceConfigPreviewDeploymentSetting;
    /** The production branch of the repository. */
    productionBranch: string;
    /** Whether to trigger a production deployment on commits to the production branch. */
    productionDeploymentsEnabled: boolean;
    /** The ID of the repository. */
    repoId: string;
    /** The name of the repository. */
    repoName: string;
}
export declare const ProjectsDeploymentsRollbackResponseSourceConfig: S.Schema<ProjectsDeploymentsRollbackResponseSourceConfig>;
export type ProjectsDeploymentsRollbackResponseSourceType = "github" | "gitlab";
export declare const ProjectsDeploymentsRollbackResponseSourceType: any;
export interface ProjectsDeploymentsRollbackResponseSource {
    config: ProjectsDeploymentsRollbackResponseSourceConfig;
    /** The source control management provider. */
    type: ProjectsDeploymentsRollbackResponseSourceType;
}
export declare const ProjectsDeploymentsRollbackResponseSource: S.Schema<ProjectsDeploymentsRollbackResponseSource>;
export type ProjectsDeploymentsRollbackResponseStagesItem = ProjectsCreateResponseCanonicalDeploymentStagesItem;
export declare const ProjectsDeploymentsRollbackResponseStagesItem: S.Schema<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export type ProjectsDeploymentsRollbackResponseStagesList = Array<ProjectsCreateResponseCanonicalDeploymentStagesItem>;
export declare const ProjectsDeploymentsRollbackResponseStagesList: S.Schema<ProjectsDeploymentsRollbackResponseStagesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RollbackProjectDeploymentResponse {
    /** Id of the deployment. */
    id: string;
    /** A list of alias URLs pointing to this deployment. */
    aliases: ProjectsDeploymentsRollbackResponseAliasesList;
    /** Configs for the project build process. */
    buildConfig: ProjectsCreateResponseCanonicalDeploymentBuildConfig;
    /** When the deployment was created. */
    createdOn: string;
    /** Info about what caused the deployment. */
    deploymentTrigger: ProjectsDeploymentsRollbackResponseDeploymentTrigger;
    /** Environment variables used for builds and Pages Functions. */
    envVars: UntypedBindingMap;
    /** Type of deploy. */
    environment: ProjectsDeploymentsRollbackResponseEnvironment;
    /** If the deployment has been skipped. */
    isSkipped: boolean;
    /** The status of the deployment. */
    latestStage: ProjectsDeploymentsRollbackResponseLatestStage;
    /** When the deployment was last modified. */
    modifiedOn: string;
    /** Id of the project. */
    projectId: string;
    /** Name of the project. */
    projectName: string;
    /** Short Id (8 character) of the deployment. */
    shortId: string;
    /** Configs for the project source control. */
    source: ProjectsDeploymentsRollbackResponseSource;
    /** List of past stages. */
    stages: ProjectsDeploymentsRollbackResponseStagesList;
    /** The live URL to view this deployment. */
    url: string;
    /** Whether the deployment uses functions. */
    usesFunctions?: boolean | null;
}
export declare const RollbackProjectDeploymentResponse: S.Schema<RollbackProjectDeploymentResponse>;
export type CreateProjectError = ProjectAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new project. */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, CloudflareOpContext>;
export type CreateProjectDeploymentError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Start a new deployment from production. The repository and account must have already been authorized on the Cloudflare Pages dashboard. */
export declare const createProjectDeployment: API.OperationMethod<CreateProjectDeploymentRequest, CreateProjectDeploymentResponse, CreateProjectDeploymentError, CloudflareOpContext>;
export type CreateProjectDomainError = ProjectNotFound | PagesDomainAlreadyExists | Forbidden | CloudflareOpError;
/** Add a new domain for the Pages project. */
export declare const createProjectDomain: API.OperationMethod<CreateProjectDomainRequest, CreateProjectDomainResponse, CreateProjectDomainError, CloudflareOpContext>;
export type DeleteProjectError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Delete a project by name. */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResponse, DeleteProjectError, CloudflareOpContext>;
export type DeleteProjectDeploymentError = DeploymentNotFound | ProjectNotFound | ActiveProductionDeployment | Forbidden | CloudflareOpError;
/** Delete a deployment. */
export declare const deleteProjectDeployment: API.OperationMethod<DeleteProjectDeploymentRequest, DeleteProjectDeploymentResponse, DeleteProjectDeploymentError, CloudflareOpContext>;
export type DeleteProjectDomainError = ProjectNotFound | PagesDomainNotFound | Forbidden | CloudflareOpError;
/** Delete a Pages project's domain. */
export declare const deleteProjectDomain: API.OperationMethod<DeleteProjectDomainRequest, DeleteProjectDomainResponse, DeleteProjectDomainError, CloudflareOpContext>;
export type GetProjectError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Fetch a project by name. */
export declare const getProject: API.OperationMethod<GetProjectRequest, GetProjectResponse, GetProjectError, CloudflareOpContext>;
export type GetProjectDeploymentError = DeploymentNotFound | ProjectNotFound | Forbidden | CloudflareOpError;
/** Fetch information about a deployment. */
export declare const getProjectDeployment: API.OperationMethod<GetProjectDeploymentRequest, GetProjectDeploymentResponse, GetProjectDeploymentError, CloudflareOpContext>;
export type GetProjectDeploymentHistoryLogError = CloudflareOpError;
/** Fetch deployment logs for a project. */
export declare const getProjectDeploymentHistoryLog: API.OperationMethod<GetProjectDeploymentHistoryLogRequest, GetProjectDeploymentHistoryLogResponse, GetProjectDeploymentHistoryLogError, CloudflareOpContext>;
export type GetProjectDomainError = ProjectNotFound | PagesDomainNotFound | Forbidden | CloudflareOpError;
/** Fetch a single domain. */
export declare const getProjectDomain: API.OperationMethod<GetProjectDomainRequest, GetProjectDomainResponse, GetProjectDomainError, CloudflareOpContext>;
export type ListProjectDeploymentsError = CloudflareOpError;
/** Fetch a list of project deployments. */
export declare const listProjectDeployments: API.PaginatedOperationMethod<ListProjectDeploymentsRequest, ListProjectDeploymentsResponse, ListProjectDeploymentsError, CloudflareOpContext, ProjectsDeploymentsListResultItem>;
export type ListProjectDomainsError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Fetch a list of all domains associated with a Pages project. */
export declare const listProjectDomains: API.PaginatedOperationMethod<ListProjectDomainsRequest, ListProjectDomainsResponse, ListProjectDomainsError, CloudflareOpContext, ProjectsDomainsListResultItem>;
export type ListProjectsError = Forbidden | CloudflareOpError;
/** Fetch a list of all user projects. */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, CloudflareOpContext, ProjectsListResultItem>;
export type PatchProjectError = ProjectNotFound | Forbidden | CloudflareOpError;
/** Set new attributes for an existing project. Modify environment variables. To delete an environment variable, set the key to null. */
export declare const patchProject: API.OperationMethod<PatchProjectRequest, PatchProjectResponse, PatchProjectError, CloudflareOpContext>;
export type PatchProjectDomainError = ProjectNotFound | PagesDomainNotFound | Forbidden | CloudflareOpError;
/** Retry the validation status of a single domain. */
export declare const patchProjectDomain: API.OperationMethod<PatchProjectDomainRequest, PatchProjectDomainResponse, PatchProjectDomainError, CloudflareOpContext>;
export type PurgeBuildCacheProjectError = CloudflareOpError;
/** Purge all cached build artifacts for a Pages project */
export declare const purgeBuildCacheProject: API.OperationMethod<PurgeBuildCacheProjectRequest, PurgeBuildCacheProjectResponse, PurgeBuildCacheProjectError, CloudflareOpContext>;
export type RetryProjectDeploymentError = CloudflareOpError;
/** Retry a previous deployment. */
export declare const retryProjectDeployment: API.OperationMethod<RetryProjectDeploymentRequest, RetryProjectDeploymentResponse, RetryProjectDeploymentError, CloudflareOpContext>;
export type RollbackProjectDeploymentError = CloudflareOpError;
/** Rollback the production deployment to a previous deployment. You can only rollback to succesful builds on production. */
export declare const rollbackProjectDeployment: API.OperationMethod<RollbackProjectDeploymentRequest, RollbackProjectDeploymentResponse, RollbackProjectDeploymentError, CloudflareOpContext>;
//# sourceMappingURL=pages.d.ts.map