import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CertificateAlreadyDeleted_base: S.Class<CertificateAlreadyDeleted, S.TaggedStruct<"CertificateAlreadyDeleted", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateAlreadyDeleted extends /*@__PURE__*/ CertificateAlreadyDeleted_base {
}
declare const CertificateAlreadyExists_base: S.Class<CertificateAlreadyExists, S.TaggedStruct<"CertificateAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateAlreadyExists extends /*@__PURE__*/ CertificateAlreadyExists_base {
}
declare const CertificateNotFound_base: S.Class<CertificateNotFound, S.TaggedStruct<"CertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateNotFound extends /*@__PURE__*/ CertificateNotFound_base {
}
declare const CertificatePendingDeletion_base: S.Class<CertificatePendingDeletion, S.TaggedStruct<"CertificatePendingDeletion", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificatePendingDeletion extends /*@__PURE__*/ CertificatePendingDeletion_base {
}
declare const CertificatePendingDeployment_base: S.Class<CertificatePendingDeployment, S.TaggedStruct<"CertificatePendingDeployment", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificatePendingDeployment extends /*@__PURE__*/ CertificatePendingDeployment_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameAssociationNotFound_base: S.Class<HostnameAssociationNotFound, S.TaggedStruct<"HostnameAssociationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameAssociationNotFound extends /*@__PURE__*/ HostnameAssociationNotFound_base {
}
declare const HostnameCertificateIdRequired_base: S.Class<HostnameCertificateIdRequired, S.TaggedStruct<"HostnameCertificateIdRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameCertificateIdRequired extends /*@__PURE__*/ HostnameCertificateIdRequired_base {
}
declare const HostnameCertificateInUse_base: S.Class<HostnameCertificateInUse, S.TaggedStruct<"HostnameCertificateInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameCertificateInUse extends /*@__PURE__*/ HostnameCertificateInUse_base {
}
declare const HostnameCertificateNotFound_base: S.Class<HostnameCertificateNotFound, S.TaggedStruct<"HostnameCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameCertificateNotFound extends /*@__PURE__*/ HostnameCertificateNotFound_base {
}
declare const InvalidCertificate_base: S.Class<InvalidCertificate, S.TaggedStruct<"InvalidCertificate", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCertificate extends /*@__PURE__*/ InvalidCertificate_base {
}
declare const InvalidCertificateId_base: S.Class<InvalidCertificateId, S.TaggedStruct<"InvalidCertificateId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCertificateId extends /*@__PURE__*/ InvalidCertificateId_base {
}
declare const InvalidHostnameConfig_base: S.Class<InvalidHostnameConfig, S.TaggedStruct<"InvalidHostnameConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidHostnameConfig extends /*@__PURE__*/ InvalidHostnameConfig_base {
}
declare const ZoneClientCertConflict_base: S.Class<ZoneClientCertConflict, S.TaggedStruct<"ZoneClientCertConflict", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneClientCertConflict extends /*@__PURE__*/ ZoneClientCertConflict_base {
}
export interface CreateHostnameCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname certificate. */
    certificate: string;
    /** The hostname certificate's private key. */
    privateKey: string;
}
export declare const CreateHostnameCertificateRequest: S.Schema<CreateHostnameCertificateRequest>;
export type HostnameCertificatesCreateResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export declare const HostnameCertificatesCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHostnameCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesCreateResponseStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const CreateHostnameCertificateResponse: S.Schema<CreateHostnameCertificateResponse>;
export interface CreateOriginTlsClientAuthRequest {
    /** Identifier. */
    zoneId: string;
    /** The zone's leaf certificate. */
    certificate: string;
    /** The zone's private key. */
    privateKey: string;
}
export declare const CreateOriginTlsClientAuthRequest: S.Schema<CreateOriginTlsClientAuthRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOriginTlsClientAuthResponse {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
    expiresOn?: string | null;
    issuer?: string | null;
    signature?: string | null;
    status?: string | null;
    uploadedOn?: string | null;
}
export declare const CreateOriginTlsClientAuthResponse: S.Schema<CreateOriginTlsClientAuthResponse>;
export interface CreateZoneCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The zone's leaf certificate. */
    certificate: string;
    /** The zone's private key. */
    privateKey: string;
}
export declare const CreateZoneCertificateRequest: S.Schema<CreateZoneCertificateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export declare const CreateZoneCertificateResponse: S.Schema<CreateZoneCertificateResponse>;
export interface DeleteHostnameCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificateId: string;
}
export declare const DeleteHostnameCertificateRequest: S.Schema<DeleteHostnameCertificateRequest>;
export type HostnameCertificatesDeleteResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export declare const HostnameCertificatesDeleteResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHostnameCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesDeleteResponseStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const DeleteHostnameCertificateResponse: S.Schema<DeleteHostnameCertificateResponse>;
export interface DeleteOriginTlsClientAuthRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificateId: string;
}
export declare const DeleteOriginTlsClientAuthRequest: S.Schema<DeleteOriginTlsClientAuthRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginTlsClientAuthResponse {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export declare const DeleteOriginTlsClientAuthResponse: S.Schema<DeleteOriginTlsClientAuthResponse>;
export interface DeleteZoneCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificateId: string;
}
export declare const DeleteZoneCertificateRequest: S.Schema<DeleteZoneCertificateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export declare const DeleteZoneCertificateResponse: S.Schema<DeleteZoneCertificateResponse>;
export interface GetHostnameRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname: string;
}
export declare const GetHostnameRequest: S.Schema<GetHostnameRequest>;
export type HostnamesGetResponseCertStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export declare const HostnamesGetResponseCertStatus: any;
export type HostnamesGetResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export declare const HostnamesGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameResponse {
    /** Identifier. */
    certId?: string | null;
    /** Status of the certificate or the association. */
    certStatus?: HostnamesGetResponseCertStatus | null;
    /** The time when the certificate was updated. */
    certUpdatedAt?: string | null;
    /** The time when the certificate was uploaded. */
    certUploadedOn?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The time when the certificate was created. */
    createdAt?: string | null;
    /** Indicates whether hostname-level authenticated origin pulls is enabled. A null value voids the association. */
    enabled?: boolean | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnamesGetResponseStatus | null;
    /** The time when the certificate was updated. */
    updatedAt?: string | null;
}
export declare const GetHostnameResponse: S.Schema<GetHostnameResponse>;
export interface GetHostnameCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificateId: string;
}
export declare const GetHostnameCertificateRequest: S.Schema<GetHostnameCertificateRequest>;
export type HostnameCertificatesGetResponseStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export declare const HostnameCertificatesGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHostnameCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesGetResponseStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const GetHostnameCertificateResponse: S.Schema<GetHostnameCertificateResponse>;
export interface GetOriginTlsClientAuthRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificateId: string;
}
export declare const GetOriginTlsClientAuthRequest: S.Schema<GetOriginTlsClientAuthRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginTlsClientAuthResponse {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
    expiresOn?: string | null;
    issuer?: string | null;
    signature?: string | null;
    status?: string | null;
    uploadedOn?: string | null;
}
export declare const GetOriginTlsClientAuthResponse: S.Schema<GetOriginTlsClientAuthResponse>;
export interface GetSettingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetSettingRequest: S.Schema<GetSettingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingResponse {
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
}
export declare const GetSettingResponse: S.Schema<GetSettingResponse>;
export interface GetZoneCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificateId: string;
}
export declare const GetZoneCertificateRequest: S.Schema<GetZoneCertificateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export declare const GetZoneCertificateResponse: S.Schema<GetZoneCertificateResponse>;
export interface ListHostnameCertificatesRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListHostnameCertificatesRequest: S.Schema<ListHostnameCertificatesRequest>;
export type HostnameCertificatesListResultItemStatus = "initializing" | "pending_deployment" | "pending_deletion" | "active" | "deleted" | "deployment_timed_out" | "deletion_timed_out";
export declare const HostnameCertificatesListResultItemStatus: any;
export interface HostnameCertificatesListResultItem {
    /** Identifier. */
    id?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** The date when the certificate expires. */
    expiresOn?: string | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** The serial number on the uploaded certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** Status of the certificate or the association. */
    status?: HostnameCertificatesListResultItemStatus | null;
    /** The time when the certificate was uploaded. */
    uploadedOn?: string | null;
}
export declare const HostnameCertificatesListResultItem: S.Schema<HostnameCertificatesListResultItem>;
export type HostnameCertificatesListResultList = Array<HostnameCertificatesListResultItem>;
export declare const HostnameCertificatesListResultList: S.Schema<HostnameCertificatesListResultList>;
export interface ListHostnameCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HostnameCertificatesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListHostnameCertificatesResponse: S.Schema<ListHostnameCertificatesResponse>;
export interface ListOriginTlsClientAuthsRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListOriginTlsClientAuthsRequest: S.Schema<ListOriginTlsClientAuthsRequest>;
export interface ListResultItem {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
    expiresOn?: string | null;
    issuer?: string | null;
    signature?: string | null;
    status?: string | null;
    uploadedOn?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListOriginTlsClientAuthsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOriginTlsClientAuthsResponse: S.Schema<ListOriginTlsClientAuthsResponse>;
export interface ListZoneCertificatesRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListZoneCertificatesRequest: S.Schema<ListZoneCertificatesRequest>;
export interface ListZoneCertificatesResultItem {
    /** Identifier. */
    id?: string | null;
    /** The zone's leaf certificate. */
    certificate?: string | null;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
    /** The zone's private key. */
    privateKey?: string | null;
}
export declare const ListZoneCertificatesResultItem: S.Schema<ListZoneCertificatesResultItem>;
export type ListZoneCertificatesResultList = Array<ListZoneCertificatesResultItem>;
export declare const ListZoneCertificatesResultList: S.Schema<ListZoneCertificatesResultList>;
export interface ListZoneCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListZoneCertificatesResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListZoneCertificatesResponse: S.Schema<ListZoneCertificatesResponse>;
export interface HostnamesUpdateRequestConfigItem {
    /** Certificate identifier tag. */
    certId?: string;
    /** Indicates whether hostname-level authenticated origin pulls is enabled. A null value voids the association. */
    enabled?: boolean | null;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname?: string;
}
export declare const HostnamesUpdateRequestConfigItem: S.Schema<HostnamesUpdateRequestConfigItem>;
export type HostnamesUpdateRequestConfigList = Array<HostnamesUpdateRequestConfigItem>;
export declare const HostnamesUpdateRequestConfigList: S.Schema<HostnamesUpdateRequestConfigList>;
export interface PutHostnameRequest {
    /** Identifier. */
    zoneId: string;
    config: HostnamesUpdateRequestConfigList;
}
export declare const PutHostnameRequest: S.Schema<PutHostnameRequest>;
export interface HostnamesUpdateResultItem {
    /** Identifier. */
    id?: string | null;
    /** Identifier. */
    certId?: string | null;
    /** The hostname certificate. */
    certificate?: string | null;
    /** Indicates whether hostname-level authenticated origin pulls is enabled. A null value voids the association. */
    enabled?: boolean | null;
    /** The hostname on the origin for which the client certificate uploaded will be used. */
    hostname?: string | null;
    /** The hostname certificate's private key. */
    privateKey?: string | null;
}
export declare const HostnamesUpdateResultItem: S.Schema<HostnamesUpdateResultItem>;
export type HostnamesUpdateResultList = Array<HostnamesUpdateResultItem>;
export declare const HostnamesUpdateResultList: S.Schema<HostnamesUpdateResultList>;
export interface PutHostnameResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HostnamesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const PutHostnameResponse: S.Schema<PutHostnameResponse>;
export interface PutSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled: boolean;
}
export declare const PutSettingRequest: S.Schema<PutSettingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingResponse {
    /** Indicates whether zone-level authenticated origin pulls is enabled. */
    enabled?: boolean | null;
}
export declare const PutSettingResponse: S.Schema<PutSettingResponse>;
export type CreateHostnameCertificateError = CertificateAlreadyExists | InvalidCertificate | Forbidden | CloudflareOpError;
/** Upload a certificate to be used for client authentication on a hostname. 10 hostname certificates per zone are allowed. */
export declare const createHostnameCertificate: API.OperationMethod<CreateHostnameCertificateRequest, CreateHostnameCertificateResponse, CreateHostnameCertificateError, CloudflareOpContext>;
export type CreateOriginTlsClientAuthError = CertificateAlreadyExists | InvalidCertificate | ZoneClientCertConflict | Forbidden | CloudflareOpError;
/** Upload your own certificate you want Cloudflare to use for edge-to-origin communication to override the shared certificate. Please note that it is important to keep only one certificate active. Also, make sure to enable zone-level authenticated origin pulls by making a PUT call to settings endpoint to see the uploaded certificate in use. */
export declare const createOriginTlsClientAuth: API.OperationMethod<CreateOriginTlsClientAuthRequest, CreateOriginTlsClientAuthResponse, CreateOriginTlsClientAuthError, CloudflareOpContext>;
export type CreateZoneCertificateError = CertificateAlreadyExists | InvalidCertificate | ZoneClientCertConflict | Forbidden | CloudflareOpError;
/** Upload your own certificate you want Cloudflare to use for edge-to-origin communication to override the shared certificate. Please note that it is important to keep only one certificate active. Also, make sure to enable zone-level authenticated origin pulls by making a PUT call to settings endpoint to see the uploaded certificate in use. */
export declare const createZoneCertificate: API.OperationMethod<CreateZoneCertificateRequest, CreateZoneCertificateResponse, CreateZoneCertificateError, CloudflareOpContext>;
export type DeleteHostnameCertificateError = HostnameCertificateNotFound | HostnameCertificateInUse | CertificatePendingDeletion | CertificatePendingDeployment | InvalidCertificateId | Forbidden | CloudflareOpError;
/** Removes a client certificate used for authenticated origin pulls on a specific hostname. Note: Before deleting the certificate, you must first invalidate the hostname for client authentication by sending a PUT request with `enabled` set to null. After invalidating the association, the certificate can be safely deleted. */
export declare const deleteHostnameCertificate: API.OperationMethod<DeleteHostnameCertificateRequest, DeleteHostnameCertificateResponse, DeleteHostnameCertificateError, CloudflareOpContext>;
export type DeleteOriginTlsClientAuthError = CertificateNotFound | Forbidden | CertificateAlreadyDeleted | CertificatePendingDeployment | ZoneClientCertConflict | CloudflareOpError;
/** Removes a client certificate used for zone-level authenticated origin pulls. */
export declare const deleteOriginTlsClientAuth: API.OperationMethod<DeleteOriginTlsClientAuthRequest, DeleteOriginTlsClientAuthResponse, DeleteOriginTlsClientAuthError, CloudflareOpContext>;
export type DeleteZoneCertificateError = CertificateNotFound | Forbidden | CertificateAlreadyDeleted | CertificatePendingDeployment | ZoneClientCertConflict | CloudflareOpError;
/** Removes a client certificate used for zone-level authenticated origin pulls. */
export declare const deleteZoneCertificate: API.OperationMethod<DeleteZoneCertificateRequest, DeleteZoneCertificateResponse, DeleteZoneCertificateError, CloudflareOpContext>;
export type GetHostnameError = HostnameAssociationNotFound | Forbidden | CloudflareOpError;
/** Retrieves the client certificate authentication status for a specific hostname, showing whether authenticated origin pulls are enabled. */
export declare const getHostname: API.OperationMethod<GetHostnameRequest, GetHostnameResponse, GetHostnameError, CloudflareOpContext>;
export type GetHostnameCertificateError = HostnameCertificateNotFound | Forbidden | CloudflareOpError;
/** Get the certificate by ID to be used for client authentication on a hostname. */
export declare const getHostnameCertificate: API.OperationMethod<GetHostnameCertificateRequest, GetHostnameCertificateResponse, GetHostnameCertificateError, CloudflareOpContext>;
export type GetOriginTlsClientAuthError = CertificateNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a specific client certificate used in zone-level authenticated origin pulls. */
export declare const getOriginTlsClientAuth: API.OperationMethod<GetOriginTlsClientAuthRequest, GetOriginTlsClientAuthResponse, GetOriginTlsClientAuthError, CloudflareOpContext>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Get whether zone-level authenticated origin pulls is enabled or not. It is false by default. */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetZoneCertificateError = CertificateNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a specific client certificate used in zone-level authenticated origin pulls. */
export declare const getZoneCertificate: API.OperationMethod<GetZoneCertificateRequest, GetZoneCertificateResponse, GetZoneCertificateError, CloudflareOpContext>;
export type ListHostnameCertificatesError = Forbidden | CloudflareOpError;
/** Lists all client certificates configured for per-hostname authenticated origin pulls on the zone. */
export declare const listHostnameCertificates: API.PaginatedOperationMethod<ListHostnameCertificatesRequest, ListHostnameCertificatesResponse, ListHostnameCertificatesError, CloudflareOpContext, HostnameCertificatesListResultItem>;
export type ListOriginTlsClientAuthsError = Forbidden | CloudflareOpError;
/** Lists all client certificates configured for zone-level authenticated origin pulls. */
export declare const listOriginTlsClientAuths: API.PaginatedOperationMethod<ListOriginTlsClientAuthsRequest, ListOriginTlsClientAuthsResponse, ListOriginTlsClientAuthsError, CloudflareOpContext, ListResultItem>;
export type ListZoneCertificatesError = Forbidden | CloudflareOpError;
/** Lists all client certificates configured for zone-level authenticated origin pulls. */
export declare const listZoneCertificates: API.PaginatedOperationMethod<ListZoneCertificatesRequest, ListZoneCertificatesResponse, ListZoneCertificatesError, CloudflareOpContext, ListZoneCertificatesResultItem>;
export type PutHostnameError = HostnameCertificateIdRequired | InvalidHostnameConfig | Forbidden | CloudflareOpError;
/** Associate a hostname to a certificate and enable, disable or invalidate the association. If disabled, client certificate will not be sent to the hostname even if activated at the zone level. 100 maximum associations on a single certificate are allowed. Note: Use a null value for parameter *enabled* to invalidate the association. */
export declare const putHostname: API.PaginatedOperationMethod<PutHostnameRequest, PutHostnameResponse, PutHostnameError, CloudflareOpContext, HostnamesUpdateResultItem>;
export type PutSettingError = Forbidden | CloudflareOpError;
/** Enable or disable zone-level authenticated origin pulls. 'enabled' should be set true either before/after the certificate is uploaded to see the certificate in use. */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
//# sourceMappingURL=origin_tls_client_auth.d.ts.map