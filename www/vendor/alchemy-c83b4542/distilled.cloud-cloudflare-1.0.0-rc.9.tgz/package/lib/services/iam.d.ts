import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidMember_base: S.Class<InvalidMember, S.TaggedStruct<"InvalidMember", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMember extends /*@__PURE__*/ InvalidMember_base {
}
declare const PolicyValidationFailed_base: S.Class<PolicyValidationFailed, S.TaggedStruct<"PolicyValidationFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PolicyValidationFailed extends /*@__PURE__*/ PolicyValidationFailed_base {
}
declare const ResourceGroupNotFound_base: S.Class<ResourceGroupNotFound, S.TaggedStruct<"ResourceGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceGroupNotFound extends /*@__PURE__*/ ResourceGroupNotFound_base {
}
declare const UserGroupMemberNotFound_base: S.Class<UserGroupMemberNotFound, S.TaggedStruct<"UserGroupMemberNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UserGroupMemberNotFound extends /*@__PURE__*/ UserGroupMemberNotFound_base {
}
declare const UserGroupNameInUse_base: S.Class<UserGroupNameInUse, S.TaggedStruct<"UserGroupNameInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UserGroupNameInUse extends /*@__PURE__*/ UserGroupNameInUse_base {
}
declare const UserGroupNotFound_base: S.Class<UserGroupNotFound, S.TaggedStruct<"UserGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UserGroupNotFound extends /*@__PURE__*/ UserGroupNotFound_base {
}
export interface BeginVerificationSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
}
export declare const BeginVerificationSsoRequest: S.Schema<BeginVerificationSsoRequest>;
export interface BeginVerificationSsoResponse {
}
export declare const BeginVerificationSsoResponse: S.Schema<BeginVerificationSsoResponse>;
export type OauthClientsCreateRequestGrantTypesItem = "authorization_code" | "refresh_token";
export declare const OauthClientsCreateRequestGrantTypesItem: any;
export type OauthClientsCreateRequestGrantTypesList = Array<OauthClientsCreateRequestGrantTypesItem | (string & {})>;
export declare const OauthClientsCreateRequestGrantTypesList: S.Schema<OauthClientsCreateRequestGrantTypesList>;
export type OauthClientsCreateRequestRedirectUrisList = Array<string>;
export declare const OauthClientsCreateRequestRedirectUrisList: S.Schema<OauthClientsCreateRequestRedirectUrisList>;
export type OauthClientsCreateRequestResponseTypesItem = "token" | "id_token" | "code";
export declare const OauthClientsCreateRequestResponseTypesItem: any;
export type OauthClientsCreateRequestResponseTypesList = Array<OauthClientsCreateRequestResponseTypesItem | (string & {})>;
export declare const OauthClientsCreateRequestResponseTypesList: S.Schema<OauthClientsCreateRequestResponseTypesList>;
export type OauthClientsCreateRequestScopesList = Array<string>;
export declare const OauthClientsCreateRequestScopesList: S.Schema<OauthClientsCreateRequestScopesList>;
export type OauthClientsCreateRequestTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export declare const OauthClientsCreateRequestTokenEndpointAuthMethod: any;
export type OauthClientsCreateRequestAllowedCorsOriginsList = Array<string>;
export declare const OauthClientsCreateRequestAllowedCorsOriginsList: S.Schema<OauthClientsCreateRequestAllowedCorsOriginsList>;
export type OauthClientsCreateRequestPostLogoutRedirectUrisList = Array<string>;
export declare const OauthClientsCreateRequestPostLogoutRedirectUrisList: S.Schema<OauthClientsCreateRequestPostLogoutRedirectUrisList>;
export interface CreateOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Human-readable name of the OAuth client. */
    clientName: string;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes: OauthClientsCreateRequestGrantTypesList;
    /** Array of allowed redirect URIs for the client. */
    redirectUris: OauthClientsCreateRequestRedirectUrisList;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes: OauthClientsCreateRequestResponseTypesList;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes: OauthClientsCreateRequestScopesList;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod: OauthClientsCreateRequestTokenEndpointAuthMethod | (string & {});
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsCreateRequestAllowedCorsOriginsList;
    /** URL of the home page of the client. */
    clientUri?: string;
    /** URL of the client's logo. */
    logoUri?: string;
    /** URL that points to a privacy policy document. */
    policyUri?: string;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsCreateRequestPostLogoutRedirectUrisList;
    /** URL that points to a terms of service document. */
    tosUri?: string;
}
export declare const CreateOauthClientRequest: S.Schema<CreateOauthClientRequest>;
export type OauthClientsCreateResponseVisibility = "public" | "private";
export declare const OauthClientsCreateResponseVisibility: any;
export type OauthClientsCreateResponseAllowedCorsOriginsList = Array<string>;
export declare const OauthClientsCreateResponseAllowedCorsOriginsList: S.Schema<OauthClientsCreateResponseAllowedCorsOriginsList>;
export type OauthClientsCreateResponseClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export declare const OauthClientsCreateResponseClientUriVerificationStatus: any;
export interface OauthClientsCreateResponseClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsCreateResponseClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export declare const OauthClientsCreateResponseClientUriVerification: S.Schema<OauthClientsCreateResponseClientUriVerification>;
export type OauthClientsCreateResponseGrantTypesItem = "authorization_code" | "refresh_token";
export declare const OauthClientsCreateResponseGrantTypesItem: any;
export type OauthClientsCreateResponseGrantTypesList = Array<OauthClientsCreateResponseGrantTypesItem>;
export declare const OauthClientsCreateResponseGrantTypesList: S.Schema<OauthClientsCreateResponseGrantTypesList>;
export type OauthClientsCreateResponsePostLogoutRedirectUrisList = Array<string>;
export declare const OauthClientsCreateResponsePostLogoutRedirectUrisList: S.Schema<OauthClientsCreateResponsePostLogoutRedirectUrisList>;
export type OauthClientsCreateResponseRedirectUrisList = Array<string>;
export declare const OauthClientsCreateResponseRedirectUrisList: S.Schema<OauthClientsCreateResponseRedirectUrisList>;
export type OauthClientsCreateResponseResponseTypesItem = "token" | "id_token" | "code";
export declare const OauthClientsCreateResponseResponseTypesItem: any;
export type OauthClientsCreateResponseResponseTypesList = Array<OauthClientsCreateResponseResponseTypesItem>;
export declare const OauthClientsCreateResponseResponseTypesList: S.Schema<OauthClientsCreateResponseResponseTypesList>;
export type OauthClientsCreateResponseScopesList = Array<string>;
export declare const OauthClientsCreateResponseScopesList: S.Schema<OauthClientsCreateResponseScopesList>;
export type OauthClientsCreateResponseTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export declare const OauthClientsCreateResponseTokenEndpointAuthMethod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOauthClientResponse {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsCreateResponseVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsCreateResponseAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** The client secret. This is the only time the secret is returned in a response. */
    clientSecret?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsCreateResponseClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsCreateResponseGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsCreateResponsePostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsCreateResponseRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsCreateResponseResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsCreateResponseScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsCreateResponseTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export declare const CreateOauthClientResponse: S.Schema<CreateOauthClientResponse>;
export interface ResourceGroupsCreateRequestScopeObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export declare const ResourceGroupsCreateRequestScopeObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type ResourceGroupsCreateRequestScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const ResourceGroupsCreateRequestScopeObjectsList: S.Schema<ResourceGroupsCreateRequestScopeObjectsList>;
export interface ResourceGroupsCreateRequestScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. The number of Scope objects should not be zero. */
    objects: ResourceGroupsCreateRequestScopeObjectsList;
}
export declare const ResourceGroupsCreateRequestScope: S.Schema<ResourceGroupsCreateRequestScope>;
export interface CreateResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Name of the resource group */
    name: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope: ResourceGroupsCreateRequestScope;
}
export declare const CreateResourceGroupRequest: S.Schema<CreateResourceGroupRequest>;
export type ResourceGroupsCreateResponseScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const ResourceGroupsCreateResponseScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type ResourceGroupsCreateResponseScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const ResourceGroupsCreateResponseScopeItemObjectsList: S.Schema<ResourceGroupsCreateResponseScopeItemObjectsList>;
export interface ResourceGroupsCreateResponseScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsCreateResponseScopeItemObjectsList;
}
export declare const ResourceGroupsCreateResponseScopeItem: S.Schema<ResourceGroupsCreateResponseScopeItem>;
export type ResourceGroupsCreateResponseScopeList = Array<ResourceGroupsCreateResponseScopeItem>;
export declare const ResourceGroupsCreateResponseScopeList: S.Schema<ResourceGroupsCreateResponseScopeList>;
export interface ResourceGroupsCreateResponseMeta {
    key?: string | null;
    value?: string | null;
}
export declare const ResourceGroupsCreateResponseMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateResourceGroupResponse {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: ResourceGroupsCreateResponseScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const CreateResourceGroupResponse: S.Schema<CreateResourceGroupResponse>;
export interface CreateSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Email domain of the new SSO connector */
    emailDomain: string;
    /** Begin the verification process after creation */
    beginVerification?: boolean;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean;
}
export declare const CreateSsoRequest: S.Schema<CreateSsoRequest>;
export type SsoCreateResponseVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export declare const SsoCreateResponseVerificationStatus: any;
export interface SsoCreateResponseVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoCreateResponseVerificationStatus | null;
}
export declare const SsoCreateResponseVerification: S.Schema<SsoCreateResponseVerification>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSsoResponse {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoCreateResponseVerification | null;
}
export declare const CreateSsoResponse: S.Schema<CreateSsoResponse>;
export type UserGroupsCreateRequestPoliciesItemAccess = "allow" | "deny";
export declare const UserGroupsCreateRequestPoliciesItemAccess: any;
export interface UserGroupsCreateRequestPoliciesItemPermissionGroupsItem {
    /** Permission Group identifier tag. */
    id: string;
}
export declare const UserGroupsCreateRequestPoliciesItemPermissionGroupsItem: S.Schema<UserGroupsCreateRequestPoliciesItemPermissionGroupsItem>;
export type UserGroupsCreateRequestPoliciesItemPermissionGroupsList = Array<UserGroupsCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const UserGroupsCreateRequestPoliciesItemPermissionGroupsList: S.Schema<UserGroupsCreateRequestPoliciesItemPermissionGroupsList>;
export interface UserGroupsCreateRequestPoliciesItemResourceGroupsItem {
    /** Resource Group identifier tag. */
    id: string;
}
export declare const UserGroupsCreateRequestPoliciesItemResourceGroupsItem: S.Schema<UserGroupsCreateRequestPoliciesItemResourceGroupsItem>;
export type UserGroupsCreateRequestPoliciesItemResourceGroupsList = Array<UserGroupsCreateRequestPoliciesItemResourceGroupsItem>;
export declare const UserGroupsCreateRequestPoliciesItemResourceGroupsList: S.Schema<UserGroupsCreateRequestPoliciesItemResourceGroupsList>;
export interface UserGroupsCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    access: UserGroupsCreateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: UserGroupsCreateRequestPoliciesItemPermissionGroupsList;
    /** A set of resource groups that are specified to the policy. */
    resourceGroups: UserGroupsCreateRequestPoliciesItemResourceGroupsList;
}
export declare const UserGroupsCreateRequestPoliciesItem: S.Schema<UserGroupsCreateRequestPoliciesItem>;
export type UserGroupsCreateRequestPoliciesList = Array<UserGroupsCreateRequestPoliciesItem>;
export declare const UserGroupsCreateRequestPoliciesList: S.Schema<UserGroupsCreateRequestPoliciesList>;
export interface CreateUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Name of the User group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsCreateRequestPoliciesList;
}
export declare const CreateUserGroupRequest: S.Schema<CreateUserGroupRequest>;
export type UserGroupsCreateResponsePoliciesItemAccess = "allow" | "deny";
export declare const UserGroupsCreateResponsePoliciesItemAccess: any;
export type UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsCreateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export interface UserGroupsCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export declare const UserGroupsCreateResponsePoliciesItemPermissionGroupsItem: S.Schema<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsCreateResponsePoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const UserGroupsCreateResponsePoliciesItemPermissionGroupsList: S.Schema<UserGroupsCreateResponsePoliciesItemPermissionGroupsList>;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItem>;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeList = Array<UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeList>;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export interface UserGroupsCreateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: UserGroupsCreateResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsItem: S.Schema<UserGroupsCreateResponsePoliciesItemResourceGroupsItem>;
export type UserGroupsCreateResponsePoliciesItemResourceGroupsList = Array<UserGroupsCreateResponsePoliciesItemResourceGroupsItem>;
export declare const UserGroupsCreateResponsePoliciesItemResourceGroupsList: S.Schema<UserGroupsCreateResponsePoliciesItemResourceGroupsList>;
export interface UserGroupsCreateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsCreateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsCreateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsCreateResponsePoliciesItemResourceGroupsList | null;
}
export declare const UserGroupsCreateResponsePoliciesItem: S.Schema<UserGroupsCreateResponsePoliciesItem>;
export type UserGroupsCreateResponsePoliciesList = Array<UserGroupsCreateResponsePoliciesItem>;
export declare const UserGroupsCreateResponsePoliciesList: S.Schema<UserGroupsCreateResponsePoliciesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateUserGroupResponse {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsCreateResponsePoliciesList | null;
}
export declare const CreateUserGroupResponse: S.Schema<CreateUserGroupResponse>;
export interface UserGroupsMembersCreateRequestMembersItem {
    /** The identifier of an existing account Member. */
    id: string;
}
export declare const UserGroupsMembersCreateRequestMembersItem: S.Schema<UserGroupsMembersCreateRequestMembersItem>;
export type UserGroupsMembersCreateRequestMembersList = Array<UserGroupsMembersCreateRequestMembersItem>;
export declare const UserGroupsMembersCreateRequestMembersList: S.Schema<UserGroupsMembersCreateRequestMembersList>;
export interface CreateUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    members: UserGroupsMembersCreateRequestMembersList;
}
export declare const CreateUserGroupMemberRequest: S.Schema<CreateUserGroupMemberRequest>;
export type UserGroupsMembersCreateResultItemStatus = "accepted" | "pending";
export declare const UserGroupsMembersCreateResultItemStatus: any;
export interface UserGroupsMembersCreateResultItem {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersCreateResultItemStatus | null;
}
export declare const UserGroupsMembersCreateResultItem: S.Schema<UserGroupsMembersCreateResultItem>;
export type UserGroupsMembersCreateResultList = Array<UserGroupsMembersCreateResultItem>;
export declare const UserGroupsMembersCreateResultList: S.Schema<UserGroupsMembersCreateResultList>;
export interface CreateUserGroupMemberResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsMembersCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateUserGroupMemberResponse: S.Schema<CreateUserGroupMemberResponse>;
export interface DeleteOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
export declare const DeleteOauthClientRequest: S.Schema<DeleteOauthClientRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOauthClientResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteOauthClientResponse: S.Schema<DeleteOauthClientResponse>;
export interface DeleteResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Resource Group identifier tag. */
    resourceGroupId: string;
}
export declare const DeleteResourceGroupRequest: S.Schema<DeleteResourceGroupRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteResourceGroupResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteResourceGroupResponse: S.Schema<DeleteResourceGroupResponse>;
export interface DeleteRotatedSecretOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
export declare const DeleteRotatedSecretOauthClientRequest: S.Schema<DeleteRotatedSecretOauthClientRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRotatedSecretOauthClientResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteRotatedSecretOauthClientResponse: S.Schema<DeleteRotatedSecretOauthClientResponse>;
export interface DeleteSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
}
export declare const DeleteSsoRequest: S.Schema<DeleteSsoRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSsoResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteSsoResponse: S.Schema<DeleteSsoResponse>;
export interface DeleteUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
}
export declare const DeleteUserGroupRequest: S.Schema<DeleteUserGroupRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteUserGroupResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteUserGroupResponse: S.Schema<DeleteUserGroupResponse>;
export interface DeleteUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** The identifier of an existing account Member. */
    memberId: string;
}
export declare const DeleteUserGroupMemberRequest: S.Schema<DeleteUserGroupMemberRequest>;
export type UserGroupsMembersDeleteResponseStatus = "accepted" | "pending";
export declare const UserGroupsMembersDeleteResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteUserGroupMemberResponse {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersDeleteResponseStatus | null;
}
export declare const DeleteUserGroupMemberResponse: S.Schema<DeleteUserGroupMemberResponse>;
export interface GetOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
export declare const GetOauthClientRequest: S.Schema<GetOauthClientRequest>;
export type OauthClientsGetResponseVisibility = "public" | "private";
export declare const OauthClientsGetResponseVisibility: any;
export type OauthClientsGetResponseAllowedCorsOriginsList = Array<string>;
export declare const OauthClientsGetResponseAllowedCorsOriginsList: S.Schema<OauthClientsGetResponseAllowedCorsOriginsList>;
export type OauthClientsGetResponseClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export declare const OauthClientsGetResponseClientUriVerificationStatus: any;
export interface OauthClientsGetResponseClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsGetResponseClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export declare const OauthClientsGetResponseClientUriVerification: S.Schema<OauthClientsGetResponseClientUriVerification>;
export type OauthClientsGetResponseGrantTypesItem = "authorization_code" | "refresh_token";
export declare const OauthClientsGetResponseGrantTypesItem: any;
export type OauthClientsGetResponseGrantTypesList = Array<OauthClientsGetResponseGrantTypesItem>;
export declare const OauthClientsGetResponseGrantTypesList: S.Schema<OauthClientsGetResponseGrantTypesList>;
export type OauthClientsGetResponsePostLogoutRedirectUrisList = Array<string>;
export declare const OauthClientsGetResponsePostLogoutRedirectUrisList: S.Schema<OauthClientsGetResponsePostLogoutRedirectUrisList>;
export type OauthClientsGetResponseRedirectUrisList = Array<string>;
export declare const OauthClientsGetResponseRedirectUrisList: S.Schema<OauthClientsGetResponseRedirectUrisList>;
export type OauthClientsGetResponseResponseTypesItem = "token" | "id_token" | "code";
export declare const OauthClientsGetResponseResponseTypesItem: any;
export type OauthClientsGetResponseResponseTypesList = Array<OauthClientsGetResponseResponseTypesItem>;
export declare const OauthClientsGetResponseResponseTypesList: S.Schema<OauthClientsGetResponseResponseTypesList>;
export type OauthClientsGetResponseScopesList = Array<string>;
export declare const OauthClientsGetResponseScopesList: S.Schema<OauthClientsGetResponseScopesList>;
export type OauthClientsGetResponseTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export declare const OauthClientsGetResponseTokenEndpointAuthMethod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOauthClientResponse {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsGetResponseVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsGetResponseAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsGetResponseClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsGetResponseGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsGetResponsePostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsGetResponseRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsGetResponseResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsGetResponseScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsGetResponseTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export declare const GetOauthClientResponse: S.Schema<GetOauthClientResponse>;
export interface GetPermissionGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Permission Group identifier tag. */
    permissionGroupId: string;
}
export declare const GetPermissionGroupRequest: S.Schema<GetPermissionGroupRequest>;
export type PermissionGroupsGetResponseMeta = ResourceGroupsCreateResponseMeta;
export declare const PermissionGroupsGetResponseMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPermissionGroupResponse {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export declare const GetPermissionGroupResponse: S.Schema<GetPermissionGroupResponse>;
export interface GetResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Resource Group identifier tag. */
    resourceGroupId: string;
}
export declare const GetResourceGroupRequest: S.Schema<GetResourceGroupRequest>;
export type ResourceGroupsGetResponseScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const ResourceGroupsGetResponseScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type ResourceGroupsGetResponseScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const ResourceGroupsGetResponseScopeItemObjectsList: S.Schema<ResourceGroupsGetResponseScopeItemObjectsList>;
export interface ResourceGroupsGetResponseScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsGetResponseScopeItemObjectsList;
}
export declare const ResourceGroupsGetResponseScopeItem: S.Schema<ResourceGroupsGetResponseScopeItem>;
export type ResourceGroupsGetResponseScopeList = Array<ResourceGroupsGetResponseScopeItem>;
export declare const ResourceGroupsGetResponseScopeList: S.Schema<ResourceGroupsGetResponseScopeList>;
export type ResourceGroupsGetResponseMeta = ResourceGroupsCreateResponseMeta;
export declare const ResourceGroupsGetResponseMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceGroupResponse {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: ResourceGroupsGetResponseScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const GetResourceGroupResponse: S.Schema<GetResourceGroupResponse>;
export interface GetSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
}
export declare const GetSsoRequest: S.Schema<GetSsoRequest>;
export type SsoGetResponseVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export declare const SsoGetResponseVerificationStatus: any;
export interface SsoGetResponseVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoGetResponseVerificationStatus | null;
}
export declare const SsoGetResponseVerification: S.Schema<SsoGetResponseVerification>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSsoResponse {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoGetResponseVerification | null;
}
export declare const GetSsoResponse: S.Schema<GetSsoResponse>;
export interface GetUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
}
export declare const GetUserGroupRequest: S.Schema<GetUserGroupRequest>;
export type UserGroupsGetResponsePoliciesItemAccess = "allow" | "deny";
export declare const UserGroupsGetResponsePoliciesItemAccess: any;
export type UserGroupsGetResponsePoliciesItemPermissionGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsGetResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export type UserGroupsGetResponsePoliciesItemPermissionGroupsItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export declare const UserGroupsGetResponsePoliciesItemPermissionGroupsItem: S.Schema<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsGetResponsePoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const UserGroupsGetResponsePoliciesItemPermissionGroupsList: S.Schema<UserGroupsGetResponsePoliciesItemPermissionGroupsList>;
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItem>;
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeList = Array<UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeList>;
export type UserGroupsGetResponsePoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export interface UserGroupsGetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: UserGroupsGetResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsItem: S.Schema<UserGroupsGetResponsePoliciesItemResourceGroupsItem>;
export type UserGroupsGetResponsePoliciesItemResourceGroupsList = Array<UserGroupsGetResponsePoliciesItemResourceGroupsItem>;
export declare const UserGroupsGetResponsePoliciesItemResourceGroupsList: S.Schema<UserGroupsGetResponsePoliciesItemResourceGroupsList>;
export interface UserGroupsGetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsGetResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsGetResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsGetResponsePoliciesItemResourceGroupsList | null;
}
export declare const UserGroupsGetResponsePoliciesItem: S.Schema<UserGroupsGetResponsePoliciesItem>;
export type UserGroupsGetResponsePoliciesList = Array<UserGroupsGetResponsePoliciesItem>;
export declare const UserGroupsGetResponsePoliciesList: S.Schema<UserGroupsGetResponsePoliciesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserGroupResponse {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsGetResponsePoliciesList | null;
}
export declare const GetUserGroupResponse: S.Schema<GetUserGroupResponse>;
export interface GetUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** The identifier of an existing account Member. */
    memberId: string;
}
export declare const GetUserGroupMemberRequest: S.Schema<GetUserGroupMemberRequest>;
export type UserGroupsMembersGetResponseStatus = "accepted" | "pending";
export declare const UserGroupsMembersGetResponseStatus: any;
export interface UserGroupsMembersGetResponseUser {
    /** User identifier tag. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** User's first name. */
    firstName?: string | null;
    /** User's last name. */
    lastName?: string | null;
}
export declare const UserGroupsMembersGetResponseUser: S.Schema<UserGroupsMembersGetResponseUser>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserGroupMemberResponse {
    /** Account member identifier. */
    id: string;
    /** When the member was added to the user group. */
    createdAt?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersGetResponseStatus | null;
    /** Details of the user associated with this membership. */
    user?: UserGroupsMembersGetResponseUser | null;
}
export declare const GetUserGroupMemberResponse: S.Schema<GetUserGroupMemberResponse>;
export interface ListOauthClientsRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const ListOauthClientsRequest: S.Schema<ListOauthClientsRequest>;
export type OauthClientsListResultItemVisibility = "public" | "private";
export declare const OauthClientsListResultItemVisibility: any;
export type OauthClientsListResultItemAllowedCorsOriginsList = Array<string>;
export declare const OauthClientsListResultItemAllowedCorsOriginsList: S.Schema<OauthClientsListResultItemAllowedCorsOriginsList>;
export type OauthClientsListResultItemClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export declare const OauthClientsListResultItemClientUriVerificationStatus: any;
export interface OauthClientsListResultItemClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsListResultItemClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export declare const OauthClientsListResultItemClientUriVerification: S.Schema<OauthClientsListResultItemClientUriVerification>;
export type OauthClientsListResultItemGrantTypesItem = "authorization_code" | "refresh_token";
export declare const OauthClientsListResultItemGrantTypesItem: any;
export type OauthClientsListResultItemGrantTypesList = Array<OauthClientsListResultItemGrantTypesItem>;
export declare const OauthClientsListResultItemGrantTypesList: S.Schema<OauthClientsListResultItemGrantTypesList>;
export type OauthClientsListResultItemPostLogoutRedirectUrisList = Array<string>;
export declare const OauthClientsListResultItemPostLogoutRedirectUrisList: S.Schema<OauthClientsListResultItemPostLogoutRedirectUrisList>;
export type OauthClientsListResultItemRedirectUrisList = Array<string>;
export declare const OauthClientsListResultItemRedirectUrisList: S.Schema<OauthClientsListResultItemRedirectUrisList>;
export type OauthClientsListResultItemResponseTypesItem = "token" | "id_token" | "code";
export declare const OauthClientsListResultItemResponseTypesItem: any;
export type OauthClientsListResultItemResponseTypesList = Array<OauthClientsListResultItemResponseTypesItem>;
export declare const OauthClientsListResultItemResponseTypesList: S.Schema<OauthClientsListResultItemResponseTypesList>;
export type OauthClientsListResultItemScopesList = Array<string>;
export declare const OauthClientsListResultItemScopesList: S.Schema<OauthClientsListResultItemScopesList>;
export type OauthClientsListResultItemTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export declare const OauthClientsListResultItemTokenEndpointAuthMethod: any;
export interface OauthClientsListResultItem {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsListResultItemVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsListResultItemAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsListResultItemClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsListResultItemGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsListResultItemPostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsListResultItemRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsListResultItemResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsListResultItemScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsListResultItemTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export declare const OauthClientsListResultItem: S.Schema<OauthClientsListResultItem>;
export type OauthClientsListResultList = Array<OauthClientsListResultItem>;
export declare const OauthClientsListResultList: S.Schema<OauthClientsListResultList>;
export interface ListOauthClientsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OauthClientsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOauthClientsResponse: S.Schema<ListOauthClientsResponse>;
export interface ListOauthScopesRequest {
}
export declare const ListOauthScopesRequest: S.Schema<ListOauthScopesRequest>;
export type OauthScopesListResultItemScopesList = Array<string>;
export declare const OauthScopesListResultItemScopesList: S.Schema<OauthScopesListResultItemScopesList>;
export interface OauthScopesListResultItem {
    /** The scope label to use in the scopes array when creating or updating an OAuth client. */
    id: string;
    /** Human-readable name of the OAuth scope. */
    name: string;
    /** Category for grouping scopes in the UI. */
    category?: string | null;
    /** The underlying resource scopes (Bach scopes) that define which resources this OAuth scope can act upon. */
    scopes?: OauthScopesListResultItemScopesList | null;
}
export declare const OauthScopesListResultItem: S.Schema<OauthScopesListResultItem>;
export type OauthScopesListResultList = Array<OauthScopesListResultItem>;
export declare const OauthScopesListResultList: S.Schema<OauthScopesListResultList>;
export interface ListOauthScopesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OauthScopesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOauthScopesResponse: S.Schema<ListOauthScopesResponse>;
export interface ListPermissionGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** ID of the permission group to be fetched. */
    id?: string;
    /** Label of the permission group to be fetched. */
    label?: string;
    /** Name of the permission group to be fetched. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListPermissionGroupsRequest: S.Schema<ListPermissionGroupsRequest>;
export type PermissionGroupsListResultItemMeta = ResourceGroupsCreateResponseMeta;
export declare const PermissionGroupsListResultItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export type PermissionGroupsListResultItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export declare const PermissionGroupsListResultItem: S.Schema<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type PermissionGroupsListResultList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const PermissionGroupsListResultList: S.Schema<PermissionGroupsListResultList>;
export interface ListPermissionGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PermissionGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPermissionGroupsResponse: S.Schema<ListPermissionGroupsResponse>;
export interface ListResourceGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** ID of the resource group to be fetched. */
    id?: string;
    /** Name of the resource group to be fetched. */
    name?: string;
}
export declare const ListResourceGroupsRequest: S.Schema<ListResourceGroupsRequest>;
export type ResourceGroupsListResultItemScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const ResourceGroupsListResultItemScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type ResourceGroupsListResultItemScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const ResourceGroupsListResultItemScopeItemObjectsList: S.Schema<ResourceGroupsListResultItemScopeItemObjectsList>;
export interface ResourceGroupsListResultItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsListResultItemScopeItemObjectsList;
}
export declare const ResourceGroupsListResultItemScopeItem: S.Schema<ResourceGroupsListResultItemScopeItem>;
export type ResourceGroupsListResultItemScopeList = Array<ResourceGroupsListResultItemScopeItem>;
export declare const ResourceGroupsListResultItemScopeList: S.Schema<ResourceGroupsListResultItemScopeList>;
export type ResourceGroupsListResultItemMeta = ResourceGroupsCreateResponseMeta;
export declare const ResourceGroupsListResultItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export interface ResourceGroupsListResultItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: ResourceGroupsListResultItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const ResourceGroupsListResultItem: S.Schema<ResourceGroupsListResultItem>;
export type ResourceGroupsListResultList = Array<ResourceGroupsListResultItem>;
export declare const ResourceGroupsListResultList: S.Schema<ResourceGroupsListResultList>;
export interface ListResourceGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ResourceGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListResourceGroupsResponse: S.Schema<ListResourceGroupsResponse>;
export interface ListSsosRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const ListSsosRequest: S.Schema<ListSsosRequest>;
export type SsoListResultItemVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export declare const SsoListResultItemVerificationStatus: any;
export interface SsoListResultItemVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoListResultItemVerificationStatus | null;
}
export declare const SsoListResultItemVerification: S.Schema<SsoListResultItemVerification>;
export interface SsoListResultItem {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoListResultItemVerification | null;
}
export declare const SsoListResultItem: S.Schema<SsoListResultItem>;
export type SsoListResultList = Array<SsoListResultItem>;
export declare const SsoListResultList: S.Schema<SsoListResultList>;
export interface ListSsosResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SsoListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSsosResponse: S.Schema<ListSsosResponse>;
export type UserGroupsMembersListRequestDirection = "asc" | "desc";
export declare const UserGroupsMembersListRequestDirection: any;
export interface ListUserGroupMembersRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** The sort order of returned user group members by email. */
    direction?: UserGroupsMembersListRequestDirection | (string & {});
    /** A string used for filtering members by partial email match. */
    fuzzyEmail?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListUserGroupMembersRequest: S.Schema<ListUserGroupMembersRequest>;
export type UserGroupsMembersListResultItemStatus = "accepted" | "pending";
export declare const UserGroupsMembersListResultItemStatus: any;
export interface UserGroupsMembersListResultItem {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersListResultItemStatus | null;
}
export declare const UserGroupsMembersListResultItem: S.Schema<UserGroupsMembersListResultItem>;
export type UserGroupsMembersListResultList = Array<UserGroupsMembersListResultItem>;
export declare const UserGroupsMembersListResultList: S.Schema<UserGroupsMembersListResultList>;
export interface ListUserGroupMembersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsMembersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListUserGroupMembersResponse: S.Schema<ListUserGroupMembersResponse>;
export type UserGroupsListRequestDirection = "asc" | "desc";
export declare const UserGroupsListRequestDirection: any;
export interface ListUserGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** ID of the user group to be fetched. */
    id?: string;
    /** The sort order of returned user groups by name (ascending or descending). */
    direction?: UserGroupsListRequestDirection | (string & {});
    /** A string used for searching for user groups containing that substring. */
    fuzzyName?: string;
    /** Name of the user group to be fetched. */
    name?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListUserGroupsRequest: S.Schema<ListUserGroupsRequest>;
export type UserGroupsListResultItemPoliciesItemAccess = "allow" | "deny";
export declare const UserGroupsListResultItemPoliciesItemAccess: any;
export type UserGroupsListResultItemPoliciesItemPermissionGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsListResultItemPoliciesItemPermissionGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export type UserGroupsListResultItemPoliciesItemPermissionGroupsItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export declare const UserGroupsListResultItemPoliciesItemPermissionGroupsItem: S.Schema<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsListResultItemPoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const UserGroupsListResultItemPoliciesItemPermissionGroupsList: S.Schema<UserGroupsListResultItemPoliciesItemPermissionGroupsList>;
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItem: S.Schema<UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItem>;
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeList = Array<UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeItem>;
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeList: S.Schema<UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeList>;
export type UserGroupsListResultItemPoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export interface UserGroupsListResultItemPoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: UserGroupsListResultItemPoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsItem: S.Schema<UserGroupsListResultItemPoliciesItemResourceGroupsItem>;
export type UserGroupsListResultItemPoliciesItemResourceGroupsList = Array<UserGroupsListResultItemPoliciesItemResourceGroupsItem>;
export declare const UserGroupsListResultItemPoliciesItemResourceGroupsList: S.Schema<UserGroupsListResultItemPoliciesItemResourceGroupsList>;
export interface UserGroupsListResultItemPoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsListResultItemPoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsListResultItemPoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsListResultItemPoliciesItemResourceGroupsList | null;
}
export declare const UserGroupsListResultItemPoliciesItem: S.Schema<UserGroupsListResultItemPoliciesItem>;
export type UserGroupsListResultItemPoliciesList = Array<UserGroupsListResultItemPoliciesItem>;
export declare const UserGroupsListResultItemPoliciesList: S.Schema<UserGroupsListResultItemPoliciesList>;
export interface UserGroupsListResultItem {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsListResultItemPoliciesList | null;
}
export declare const UserGroupsListResultItem: S.Schema<UserGroupsListResultItem>;
export type UserGroupsListResultList = Array<UserGroupsListResultItem>;
export declare const UserGroupsListResultList: S.Schema<UserGroupsListResultList>;
export interface ListUserGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListUserGroupsResponse: S.Schema<ListUserGroupsResponse>;
export type OauthClientsUpdateRequestAllowedCorsOriginsList = Array<string>;
export declare const OauthClientsUpdateRequestAllowedCorsOriginsList: S.Schema<OauthClientsUpdateRequestAllowedCorsOriginsList>;
export type OauthClientsUpdateRequestGrantTypesItem = "authorization_code" | "refresh_token";
export declare const OauthClientsUpdateRequestGrantTypesItem: any;
export type OauthClientsUpdateRequestGrantTypesList = Array<OauthClientsUpdateRequestGrantTypesItem | (string & {})>;
export declare const OauthClientsUpdateRequestGrantTypesList: S.Schema<OauthClientsUpdateRequestGrantTypesList>;
export type OauthClientsUpdateRequestPostLogoutRedirectUrisList = Array<string>;
export declare const OauthClientsUpdateRequestPostLogoutRedirectUrisList: S.Schema<OauthClientsUpdateRequestPostLogoutRedirectUrisList>;
export type OauthClientsUpdateRequestRedirectUrisList = Array<string>;
export declare const OauthClientsUpdateRequestRedirectUrisList: S.Schema<OauthClientsUpdateRequestRedirectUrisList>;
export type OauthClientsUpdateRequestResponseTypesItem = "token" | "id_token" | "code";
export declare const OauthClientsUpdateRequestResponseTypesItem: any;
export type OauthClientsUpdateRequestResponseTypesList = Array<OauthClientsUpdateRequestResponseTypesItem | (string & {})>;
export declare const OauthClientsUpdateRequestResponseTypesList: S.Schema<OauthClientsUpdateRequestResponseTypesList>;
export type OauthClientsUpdateRequestScopesList = Array<string>;
export declare const OauthClientsUpdateRequestScopesList: S.Schema<OauthClientsUpdateRequestScopesList>;
export type OauthClientsUpdateRequestTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export declare const OauthClientsUpdateRequestTokenEndpointAuthMethod: any;
export type OauthClientsUpdateRequestVisibility = "public";
export declare const OauthClientsUpdateRequestVisibility: any;
export interface PatchOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsUpdateRequestAllowedCorsOriginsList;
    /** Human-readable name of the OAuth client. */
    clientName?: string;
    /** URL of the home page of the client. */
    clientUri?: string;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsUpdateRequestGrantTypesList;
    /** URL of the client's logo. */
    logoUri?: string;
    /** URL that points to a privacy policy document. */
    policyUri?: string;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsUpdateRequestPostLogoutRedirectUrisList;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsUpdateRequestRedirectUrisList;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsUpdateRequestResponseTypesList;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsUpdateRequestScopesList;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsUpdateRequestTokenEndpointAuthMethod | (string & {});
    /** URL that points to a terms of service document. */
    tosUri?: string;
    /** Promote the OAuth client from private to public visibility. Only `public` is accepted; demotion to `private` is not supported. Promotion requires a non-empty client name, logo URI, verified client URI host, and at least one non-identity scope. */
    visibility?: OauthClientsUpdateRequestVisibility | (string & {});
}
export declare const PatchOauthClientRequest: S.Schema<PatchOauthClientRequest>;
export type OauthClientsUpdateResponseVisibility = "public" | "private";
export declare const OauthClientsUpdateResponseVisibility: any;
export type OauthClientsUpdateResponseAllowedCorsOriginsList = Array<string>;
export declare const OauthClientsUpdateResponseAllowedCorsOriginsList: S.Schema<OauthClientsUpdateResponseAllowedCorsOriginsList>;
export type OauthClientsUpdateResponseClientUriVerificationStatus = "pending" | "in_progress" | "verified" | "failed";
export declare const OauthClientsUpdateResponseClientUriVerificationStatus: any;
export interface OauthClientsUpdateResponseClientUriVerification {
    /** Current verification status for the client URI host. */
    status?: OauthClientsUpdateResponseClientUriVerificationStatus | null;
    /** Exact TXT record value that must be added to DNS to prove ownership of the client URI host. */
    text?: string | null;
}
export declare const OauthClientsUpdateResponseClientUriVerification: S.Schema<OauthClientsUpdateResponseClientUriVerification>;
export type OauthClientsUpdateResponseGrantTypesItem = "authorization_code" | "refresh_token";
export declare const OauthClientsUpdateResponseGrantTypesItem: any;
export type OauthClientsUpdateResponseGrantTypesList = Array<OauthClientsUpdateResponseGrantTypesItem>;
export declare const OauthClientsUpdateResponseGrantTypesList: S.Schema<OauthClientsUpdateResponseGrantTypesList>;
export type OauthClientsUpdateResponsePostLogoutRedirectUrisList = Array<string>;
export declare const OauthClientsUpdateResponsePostLogoutRedirectUrisList: S.Schema<OauthClientsUpdateResponsePostLogoutRedirectUrisList>;
export type OauthClientsUpdateResponseRedirectUrisList = Array<string>;
export declare const OauthClientsUpdateResponseRedirectUrisList: S.Schema<OauthClientsUpdateResponseRedirectUrisList>;
export type OauthClientsUpdateResponseResponseTypesItem = "token" | "id_token" | "code";
export declare const OauthClientsUpdateResponseResponseTypesItem: any;
export type OauthClientsUpdateResponseResponseTypesList = Array<OauthClientsUpdateResponseResponseTypesItem>;
export declare const OauthClientsUpdateResponseResponseTypesList: S.Schema<OauthClientsUpdateResponseResponseTypesList>;
export type OauthClientsUpdateResponseScopesList = Array<string>;
export declare const OauthClientsUpdateResponseScopesList: S.Schema<OauthClientsUpdateResponseScopesList>;
export type OauthClientsUpdateResponseTokenEndpointAuthMethod = "none" | "client_secret_basic" | "client_secret_post";
export declare const OauthClientsUpdateResponseTokenEndpointAuthMethod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOauthClientResponse {
    /** The unique identifier for an OAuth client. */
    clientId: string;
    /** Visibility of the OAuth client. */
    visibility: OauthClientsUpdateResponseVisibility;
    /** Array of allowed CORS origins. */
    allowedCorsOrigins?: OauthClientsUpdateResponseAllowedCorsOriginsList | null;
    /** Human-readable name of the OAuth client. */
    clientName?: string | null;
    /** URL of the home page of the client. */
    clientUri?: string | null;
    /** Client URI domain control verification state. */
    clientUriVerification?: OauthClientsUpdateResponseClientUriVerification | null;
    /** Timestamp when the OAuth client was created. */
    createdAt?: string | null;
    /** Array of OAuth grant types the client is allowed to use. `authorization_code` is required; `refresh_token` may be included optionally. */
    grantTypes?: OauthClientsUpdateResponseGrantTypesList | null;
    /** Indicates whether the client has a rotated secret that has not yet been deleted. */
    hasRotatedSecret?: boolean | null;
    /** URL of the client's logo. */
    logoUri?: string | null;
    /** URL that points to a privacy policy document. */
    policyUri?: string | null;
    /** Array of allowed post-logout redirect URIs. */
    postLogoutRedirectUris?: OauthClientsUpdateResponsePostLogoutRedirectUrisList | null;
    /** Timestamp when the OAuth client was promoted to public visibility. */
    promotedAt?: string | null;
    /** Array of allowed redirect URIs for the client. */
    redirectUris?: OauthClientsUpdateResponseRedirectUrisList | null;
    /** Array of OAuth response types the client is allowed to use. */
    responseTypes?: OauthClientsUpdateResponseResponseTypesList | null;
    /** Array of OAuth scopes the client is allowed to request. Colon-delimited scopes are not accepted. Dot-delimited scopes are validated against available OAuth API scopes; simple identity scopes are allowed. Protocol scopes `offline_access` and `openid` are added or removed automatically based on `grant_types` and `response_types`. */
    scopes?: OauthClientsUpdateResponseScopesList | null;
    /** The authentication method the client uses at the token endpoint. */
    tokenEndpointAuthMethod?: OauthClientsUpdateResponseTokenEndpointAuthMethod | null;
    /** URL that points to a terms of service document. */
    tosUri?: string | null;
    /** Timestamp when the OAuth client was last updated. */
    updatedAt?: string | null;
}
export declare const PatchOauthClientResponse: S.Schema<PatchOauthClientResponse>;
export interface PatchSsoRequest {
    /** Account identifier tag. */
    accountId: string;
    /** SSO Connector identifier tag. */
    ssoConnectorId: string;
    /** SSO Connector enabled state */
    enabled?: boolean;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean;
}
export declare const PatchSsoRequest: S.Schema<PatchSsoRequest>;
export type SsoUpdateResponseVerificationStatus = "awaiting" | "pending" | "failed" | "verified";
export declare const SsoUpdateResponseVerificationStatus: any;
export interface SsoUpdateResponseVerification {
    /** DNS verification code. Add this entire string to the DNS TXT record of the email domain to validate ownership. */
    code?: string | null;
    /** The status of the verification code from the verification process. */
    status?: SsoUpdateResponseVerificationStatus | null;
}
export declare const SsoUpdateResponseVerification: S.Schema<SsoUpdateResponseVerification>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSsoResponse {
    /** SSO Connector identifier tag. */
    id?: string | null;
    /** Timestamp for the creation of the SSO connector */
    createdOn?: string | null;
    emailDomain?: string | null;
    enabled?: boolean | null;
    /** Timestamp for the last update of the SSO connector */
    updatedOn?: string | null;
    /** Controls the display of FedRAMP language to the user during SSO login */
    useFedrampLanguage?: boolean | null;
    verification?: SsoUpdateResponseVerification | null;
}
export declare const PatchSsoResponse: S.Schema<PatchSsoResponse>;
export interface RotateSecretOauthClientRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The unique identifier for an OAuth client. */
    oauthClientId: string;
}
export declare const RotateSecretOauthClientRequest: S.Schema<RotateSecretOauthClientRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RotateSecretOauthClientResponse {
    /** The new client secret. */
    clientSecret?: string | null;
}
export declare const RotateSecretOauthClientResponse: S.Schema<RotateSecretOauthClientResponse>;
export type ResourceGroupsUpdateRequestScopeObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const ResourceGroupsUpdateRequestScopeObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type ResourceGroupsUpdateRequestScopeObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const ResourceGroupsUpdateRequestScopeObjectsList: S.Schema<ResourceGroupsUpdateRequestScopeObjectsList>;
export interface ResourceGroupsUpdateRequestScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. The number of Scope objects should not be zero. */
    objects: ResourceGroupsUpdateRequestScopeObjectsList;
}
export declare const ResourceGroupsUpdateRequestScope: S.Schema<ResourceGroupsUpdateRequestScope>;
export interface UpdateResourceGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Resource Group identifier tag. */
    resourceGroupId: string;
    /** Name of the resource group */
    name?: string;
    /** A scope is a combination of scope objects which provides additional context. */
    scope?: ResourceGroupsUpdateRequestScope;
}
export declare const UpdateResourceGroupRequest: S.Schema<UpdateResourceGroupRequest>;
export type ResourceGroupsUpdateResponseScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const ResourceGroupsUpdateResponseScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type ResourceGroupsUpdateResponseScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const ResourceGroupsUpdateResponseScopeItemObjectsList: S.Schema<ResourceGroupsUpdateResponseScopeItemObjectsList>;
export interface ResourceGroupsUpdateResponseScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: ResourceGroupsUpdateResponseScopeItemObjectsList;
}
export declare const ResourceGroupsUpdateResponseScopeItem: S.Schema<ResourceGroupsUpdateResponseScopeItem>;
export type ResourceGroupsUpdateResponseScopeList = Array<ResourceGroupsUpdateResponseScopeItem>;
export declare const ResourceGroupsUpdateResponseScopeList: S.Schema<ResourceGroupsUpdateResponseScopeList>;
export type ResourceGroupsUpdateResponseMeta = ResourceGroupsCreateResponseMeta;
export declare const ResourceGroupsUpdateResponseMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResourceGroupResponse {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: ResourceGroupsUpdateResponseScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const UpdateResourceGroupResponse: S.Schema<UpdateResourceGroupResponse>;
export type UserGroupsUpdateRequestPoliciesItemAccess = "allow" | "deny";
export declare const UserGroupsUpdateRequestPoliciesItemAccess: any;
export type UserGroupsUpdateRequestPoliciesItemPermissionGroupsItem = UserGroupsCreateRequestPoliciesItemPermissionGroupsItem;
export declare const UserGroupsUpdateRequestPoliciesItemPermissionGroupsItem: S.Schema<UserGroupsCreateRequestPoliciesItemPermissionGroupsItem>;
export type UserGroupsUpdateRequestPoliciesItemPermissionGroupsList = Array<UserGroupsCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const UserGroupsUpdateRequestPoliciesItemPermissionGroupsList: S.Schema<UserGroupsUpdateRequestPoliciesItemPermissionGroupsList>;
export type UserGroupsUpdateRequestPoliciesItemResourceGroupsItem = UserGroupsCreateRequestPoliciesItemResourceGroupsItem;
export declare const UserGroupsUpdateRequestPoliciesItemResourceGroupsItem: S.Schema<UserGroupsCreateRequestPoliciesItemResourceGroupsItem>;
export type UserGroupsUpdateRequestPoliciesItemResourceGroupsList = Array<UserGroupsCreateRequestPoliciesItemResourceGroupsItem>;
export declare const UserGroupsUpdateRequestPoliciesItemResourceGroupsList: S.Schema<UserGroupsUpdateRequestPoliciesItemResourceGroupsList>;
export interface UserGroupsUpdateRequestPoliciesItem {
    /** Policy identifier. */
    id?: string;
    /** Allow or deny operations against the resources. */
    access: UserGroupsUpdateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: UserGroupsUpdateRequestPoliciesItemPermissionGroupsList;
    /** A set of resource groups that are specified to the policy. */
    resourceGroups: UserGroupsUpdateRequestPoliciesItemResourceGroupsList;
}
export declare const UserGroupsUpdateRequestPoliciesItem: S.Schema<UserGroupsUpdateRequestPoliciesItem>;
export type UserGroupsUpdateRequestPoliciesList = Array<UserGroupsUpdateRequestPoliciesItem>;
export declare const UserGroupsUpdateRequestPoliciesList: S.Schema<UserGroupsUpdateRequestPoliciesList>;
export interface UpdateUserGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** Name of the User group. */
    name?: string;
    /** Policies attached to the User group */
    policies?: UserGroupsUpdateRequestPoliciesList;
}
export declare const UpdateUserGroupRequest: S.Schema<UpdateUserGroupRequest>;
export type UserGroupsUpdateResponsePoliciesItemAccess = "allow" | "deny";
export declare const UserGroupsUpdateResponsePoliciesItemAccess: any;
export type UserGroupsUpdateResponsePoliciesItemPermissionGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsUpdateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export type UserGroupsUpdateResponsePoliciesItemPermissionGroupsItem = UserGroupsCreateResponsePoliciesItemPermissionGroupsItem;
export declare const UserGroupsUpdateResponsePoliciesItemPermissionGroupsItem: S.Schema<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type UserGroupsUpdateResponsePoliciesItemPermissionGroupsList = Array<UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const UserGroupsUpdateResponsePoliciesItemPermissionGroupsList: S.Schema<UserGroupsUpdateResponsePoliciesItemPermissionGroupsList>;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem = ResourceGroupsCreateRequestScopeObjectsItem;
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<ResourceGroupsCreateRequestScopeObjectsItem>;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<ResourceGroupsCreateRequestScopeObjectsItem>;
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItem>;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeList = Array<UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeList>;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsItemMeta = ResourceGroupsCreateResponseMeta;
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsItemMeta: S.Schema<ResourceGroupsCreateResponseMeta>;
export interface UserGroupsUpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: UserGroupsUpdateResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: ResourceGroupsCreateResponseMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsItem: S.Schema<UserGroupsUpdateResponsePoliciesItemResourceGroupsItem>;
export type UserGroupsUpdateResponsePoliciesItemResourceGroupsList = Array<UserGroupsUpdateResponsePoliciesItemResourceGroupsItem>;
export declare const UserGroupsUpdateResponsePoliciesItemResourceGroupsList: S.Schema<UserGroupsUpdateResponsePoliciesItemResourceGroupsList>;
export interface UserGroupsUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UserGroupsUpdateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UserGroupsUpdateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UserGroupsUpdateResponsePoliciesItemResourceGroupsList | null;
}
export declare const UserGroupsUpdateResponsePoliciesItem: S.Schema<UserGroupsUpdateResponsePoliciesItem>;
export type UserGroupsUpdateResponsePoliciesList = Array<UserGroupsUpdateResponsePoliciesItem>;
export declare const UserGroupsUpdateResponsePoliciesList: S.Schema<UserGroupsUpdateResponsePoliciesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateUserGroupResponse {
    /** User Group identifier tag. */
    id: string;
    /** Timestamp for the creation of the user group */
    createdOn: string;
    /** Last time the user group was modified. */
    modifiedOn: string;
    /** Name of the user group. */
    name: string;
    /** Policies attached to the User group */
    policies?: UserGroupsUpdateResponsePoliciesList | null;
}
export declare const UpdateUserGroupResponse: S.Schema<UpdateUserGroupResponse>;
export type UserGroupsMembersUpdateRequestMembersItem = UserGroupsMembersCreateRequestMembersItem;
export declare const UserGroupsMembersUpdateRequestMembersItem: S.Schema<UserGroupsMembersCreateRequestMembersItem>;
export type UserGroupsMembersUpdateRequestMembersList = Array<UserGroupsMembersCreateRequestMembersItem>;
export declare const UserGroupsMembersUpdateRequestMembersList: S.Schema<UserGroupsMembersUpdateRequestMembersList>;
export interface UpdateUserGroupMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** User Group identifier tag. */
    userGroupId: string;
    /** Set/Replace members to a user group. */
    members: UserGroupsMembersUpdateRequestMembersList;
}
export declare const UpdateUserGroupMemberRequest: S.Schema<UpdateUserGroupMemberRequest>;
export type UserGroupsMembersUpdateResultItemStatus = "accepted" | "pending";
export declare const UserGroupsMembersUpdateResultItemStatus: any;
export interface UserGroupsMembersUpdateResultItem {
    /** Account member identifier. */
    id: string;
    /** The contact email address of the user. */
    email?: string | null;
    /** The member's status in the account. */
    status?: UserGroupsMembersUpdateResultItemStatus | null;
}
export declare const UserGroupsMembersUpdateResultItem: S.Schema<UserGroupsMembersUpdateResultItem>;
export type UserGroupsMembersUpdateResultList = Array<UserGroupsMembersUpdateResultItem>;
export declare const UserGroupsMembersUpdateResultList: S.Schema<UserGroupsMembersUpdateResultList>;
export interface UpdateUserGroupMemberResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UserGroupsMembersUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const UpdateUserGroupMemberResponse: S.Schema<UpdateUserGroupMemberResponse>;
export type BeginVerificationSsoError = CloudflareOpError;
/** Validates the user has added the DNS TXT record required for validating ownership of the domain they are trying to set up a connector for. */
export declare const beginVerificationSso: API.OperationMethod<BeginVerificationSsoRequest, BeginVerificationSsoResponse, BeginVerificationSsoError, CloudflareOpContext>;
export type CreateOauthClientError = CloudflareOpError;
/** Create a new OAuth client for an account. */
export declare const createOauthClient: API.OperationMethod<CreateOauthClientRequest, CreateOauthClientResponse, CreateOauthClientError, CloudflareOpContext>;
export type CreateResourceGroupError = CloudflareOpError;
/** Create a new Resource Group under the specified account. */
export declare const createResourceGroup: API.OperationMethod<CreateResourceGroupRequest, CreateResourceGroupResponse, CreateResourceGroupError, CloudflareOpContext>;
export type CreateSsoError = CloudflareOpError;
/** Creates a new SSO connector for logging into Cloudflare through an identity provider. */
export declare const createSso: API.OperationMethod<CreateSsoRequest, CreateSsoResponse, CreateSsoError, CloudflareOpContext>;
export type CreateUserGroupError = UserGroupNameInUse | CloudflareOpError;
/** Create a new user group under the specified account. */
export declare const createUserGroup: API.OperationMethod<CreateUserGroupRequest, CreateUserGroupResponse, CreateUserGroupError, CloudflareOpContext>;
export type CreateUserGroupMemberError = InvalidMember | UserGroupNotFound | CloudflareOpError;
/** Add members to a User Group. */
export declare const createUserGroupMember: API.PaginatedOperationMethod<CreateUserGroupMemberRequest, CreateUserGroupMemberResponse, CreateUserGroupMemberError, CloudflareOpContext, UserGroupsMembersCreateResultItem>;
export type DeleteOauthClientError = CloudflareOpError;
/** Delete an OAuth client. */
export declare const deleteOauthClient: API.OperationMethod<DeleteOauthClientRequest, DeleteOauthClientResponse, DeleteOauthClientError, CloudflareOpContext>;
export type DeleteResourceGroupError = ResourceGroupNotFound | CloudflareOpError;
/** Remove a resource group from an account. */
export declare const deleteResourceGroup: API.OperationMethod<DeleteResourceGroupRequest, DeleteResourceGroupResponse, DeleteResourceGroupError, CloudflareOpContext>;
export type DeleteRotatedSecretOauthClientError = CloudflareOpError;
/** Removes the old client secret after a rotation, keeping only the new one. Use this after you have updated your client configuration to use the new secret. The `has_rotated_secret` field on the client indicates whether there is an old secret to delete. */
export declare const deleteRotatedSecretOauthClient: API.OperationMethod<DeleteRotatedSecretOauthClientRequest, DeleteRotatedSecretOauthClientResponse, DeleteRotatedSecretOauthClientError, CloudflareOpContext>;
export type DeleteSsoError = CloudflareOpError;
/** Deletes an SSO connector from the account. */
export declare const deleteSso: API.OperationMethod<DeleteSsoRequest, DeleteSsoResponse, DeleteSsoError, CloudflareOpContext>;
export type DeleteUserGroupError = UserGroupNotFound | CloudflareOpError;
/** Remove a user group from an account. */
export declare const deleteUserGroup: API.OperationMethod<DeleteUserGroupRequest, DeleteUserGroupResponse, DeleteUserGroupError, CloudflareOpContext>;
export type DeleteUserGroupMemberError = InvalidMember | UserGroupMemberNotFound | UserGroupNotFound | CloudflareOpError;
/** Remove a member from User Group */
export declare const deleteUserGroupMember: API.OperationMethod<DeleteUserGroupMemberRequest, DeleteUserGroupMemberResponse, DeleteUserGroupMemberError, CloudflareOpContext>;
export type GetOauthClientError = CloudflareOpError;
/** Get details of a specific OAuth client. */
export declare const getOauthClient: API.OperationMethod<GetOauthClientRequest, GetOauthClientResponse, GetOauthClientError, CloudflareOpContext>;
export type GetPermissionGroupError = CloudflareOpError;
/** Get information about a specific permission group in an account. */
export declare const getPermissionGroup: API.OperationMethod<GetPermissionGroupRequest, GetPermissionGroupResponse, GetPermissionGroupError, CloudflareOpContext>;
export type GetResourceGroupError = ResourceGroupNotFound | Forbidden | CloudflareOpError;
/** Get information about a specific resource group in an account. */
export declare const getResourceGroup: API.OperationMethod<GetResourceGroupRequest, GetResourceGroupResponse, GetResourceGroupError, CloudflareOpContext>;
export type GetSsoError = CloudflareOpError;
/** Retrieves details for a specific SSO connector. */
export declare const getSso: API.OperationMethod<GetSsoRequest, GetSsoResponse, GetSsoError, CloudflareOpContext>;
export type GetUserGroupError = UserGroupNotFound | Forbidden | CloudflareOpError;
/** Get information about a specific user group in an account. */
export declare const getUserGroup: API.OperationMethod<GetUserGroupRequest, GetUserGroupResponse, GetUserGroupError, CloudflareOpContext>;
export type GetUserGroupMemberError = UserGroupMemberNotFound | UserGroupNotFound | Forbidden | CloudflareOpError;
/** Get details of a specific member in a user group. */
export declare const getUserGroupMember: API.OperationMethod<GetUserGroupMemberRequest, GetUserGroupMemberResponse, GetUserGroupMemberError, CloudflareOpContext>;
export type ListOauthClientsError = CloudflareOpError;
/** List all OAuth clients for an account. */
export declare const listOauthClients: API.PaginatedOperationMethod<ListOauthClientsRequest, ListOauthClientsResponse, ListOauthClientsError, CloudflareOpContext, OauthClientsListResultItem>;
export type ListOauthScopesError = CloudflareOpError;
/** List all available OAuth scopes. This endpoint requires authentication but has no authorization role requirements. */
export declare const listOauthScopes: API.PaginatedOperationMethod<ListOauthScopesRequest, ListOauthScopesResponse, ListOauthScopesError, CloudflareOpContext, OauthScopesListResultItem>;
export type ListPermissionGroupsError = CloudflareOpError;
/** List all the permissions groups for an account. */
export declare const listPermissionGroups: API.PaginatedOperationMethod<ListPermissionGroupsRequest, ListPermissionGroupsResponse, ListPermissionGroupsError, CloudflareOpContext, UserGroupsCreateResponsePoliciesItemPermissionGroupsItem>;
export type ListResourceGroupsError = CloudflareOpError;
/** List all the resource groups for an account. */
export declare const listResourceGroups: API.PaginatedOperationMethod<ListResourceGroupsRequest, ListResourceGroupsResponse, ListResourceGroupsError, CloudflareOpContext, ResourceGroupsListResultItem>;
export type ListSsosError = CloudflareOpError;
/** Lists all SSO connectors configured for the account. */
export declare const listSsos: API.PaginatedOperationMethod<ListSsosRequest, ListSsosResponse, ListSsosError, CloudflareOpContext, SsoListResultItem>;
export type ListUserGroupMembersError = UserGroupNotFound | PolicyValidationFailed | CloudflareOpError;
/** List all the members attached to a user group. */
export declare const listUserGroupMembers: API.PaginatedOperationMethod<ListUserGroupMembersRequest, ListUserGroupMembersResponse, ListUserGroupMembersError, CloudflareOpContext, UserGroupsMembersListResultItem>;
export type ListUserGroupsError = CloudflareOpError;
/** List all the user groups for an account. */
export declare const listUserGroups: API.PaginatedOperationMethod<ListUserGroupsRequest, ListUserGroupsResponse, ListUserGroupsError, CloudflareOpContext, UserGroupsListResultItem>;
export type PatchOauthClientError = CloudflareOpError;
/** Update an existing OAuth client. Only include fields you want to update. */
export declare const patchOauthClient: API.OperationMethod<PatchOauthClientRequest, PatchOauthClientResponse, PatchOauthClientError, CloudflareOpContext>;
export type PatchSsoError = CloudflareOpError;
/** Updates the state or configuration of an SSO connector. */
export declare const patchSso: API.OperationMethod<PatchSsoRequest, PatchSsoResponse, PatchSsoError, CloudflareOpContext>;
export type RotateSecretOauthClientError = CloudflareOpError;
/** Creates a second client secret so you can update your client configuration before deleting the old one. The `has_rotated_secret` field on the client will be set to `true`. */
export declare const rotateSecretOauthClient: API.OperationMethod<RotateSecretOauthClientRequest, RotateSecretOauthClientResponse, RotateSecretOauthClientError, CloudflareOpContext>;
export type UpdateResourceGroupError = ResourceGroupNotFound | CloudflareOpError;
/** Modify an existing resource group. */
export declare const updateResourceGroup: API.OperationMethod<UpdateResourceGroupRequest, UpdateResourceGroupResponse, UpdateResourceGroupError, CloudflareOpContext>;
export type UpdateUserGroupError = UserGroupNotFound | UserGroupNameInUse | CloudflareOpError;
/** Modify an existing user group. */
export declare const updateUserGroup: API.OperationMethod<UpdateUserGroupRequest, UpdateUserGroupResponse, UpdateUserGroupError, CloudflareOpContext>;
export type UpdateUserGroupMemberError = InvalidMember | UserGroupNotFound | CloudflareOpError;
/** Replace the set of members attached to a User Group. */
export declare const updateUserGroupMember: API.PaginatedOperationMethod<UpdateUserGroupMemberRequest, UpdateUserGroupMemberResponse, UpdateUserGroupMemberError, CloudflareOpContext, UserGroupsMembersUpdateResultItem>;
//# sourceMappingURL=iam.d.ts.map