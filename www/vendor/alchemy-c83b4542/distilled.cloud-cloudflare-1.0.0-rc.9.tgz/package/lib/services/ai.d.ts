import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccountNotFound_base: S.Class<AccountNotFound, S.TaggedStruct<"AccountNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AccountNotFound extends /*@__PURE__*/ AccountNotFound_base {
}
declare const ModelNotFound_base: S.Class<ModelNotFound, S.TaggedStruct<"ModelNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ModelNotFound extends /*@__PURE__*/ ModelNotFound_base {
}
declare const ModelNotSupported_base: S.Class<ModelNotSupported, S.TaggedStruct<"ModelNotSupported", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ModelNotSupported extends /*@__PURE__*/ ModelNotSupported_base {
}
declare const ModelSchemaNotFound_base: S.Class<ModelSchemaNotFound, S.TaggedStruct<"ModelSchemaNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ModelSchemaNotFound extends /*@__PURE__*/ ModelSchemaNotFound_base {
}
export interface CreateFinetuneRequest {
    accountId: string;
    model: string;
    name: string;
    description?: string;
    public?: boolean;
}
export declare const CreateFinetuneRequest: S.Schema<CreateFinetuneRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateFinetuneResponse {
    id: string;
    createdAt: string;
    model: string;
    modifiedAt: string;
    name: string;
    public: boolean;
    description?: string | null;
}
export declare const CreateFinetuneResponse: S.Schema<CreateFinetuneResponse>;
export interface CreateFinetuneAssetRequest {
    accountId: string;
    finetuneId: string;
}
export declare const CreateFinetuneAssetRequest: S.Schema<CreateFinetuneAssetRequest>;
export interface CreateFinetuneAssetResponse {
}
export declare const CreateFinetuneAssetResponse: S.Schema<CreateFinetuneAssetResponse>;
export interface GetModelSchemaRequest {
    accountId: string;
    /** Model Name */
    model: string;
}
export declare const GetModelSchemaRequest: S.Schema<GetModelSchemaRequest>;
export interface ModelsSchemaGetResponseInput {
    additionalProperties: boolean;
    description: string;
    type: string;
}
export declare const ModelsSchemaGetResponseInput: S.Schema<ModelsSchemaGetResponseInput>;
export type ModelsSchemaGetResponseOutput = ModelsSchemaGetResponseInput;
export declare const ModelsSchemaGetResponseOutput: S.Schema<ModelsSchemaGetResponseInput>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetModelSchemaResponse {
    input: ModelsSchemaGetResponseInput;
    output: ModelsSchemaGetResponseInput;
}
export declare const GetModelSchemaResponse: S.Schema<GetModelSchemaResponse>;
export interface ListAuthorsRequest {
    accountId: string;
}
export declare const ListAuthorsRequest: S.Schema<ListAuthorsRequest>;
export type AuthorsListResultList = Array<unknown>;
export declare const AuthorsListResultList: S.Schema<AuthorsListResultList>;
export interface ListAuthorsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AuthorsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAuthorsResponse: S.Schema<ListAuthorsResponse>;
export interface ListFinetunePublicsRequest {
    accountId: string;
    /** Pagination Limit */
    limit?: number;
    /** Pagination Offset */
    offset?: number;
    /** Order By Column Name */
    orderBy?: string;
}
export declare const ListFinetunePublicsRequest: S.Schema<ListFinetunePublicsRequest>;
export interface FinetunesPublicListResultItem {
    id: string;
    createdAt: string;
    model: string;
    modifiedAt: string;
    name: string;
    public: boolean;
    description?: string | null;
}
export declare const FinetunesPublicListResultItem: S.Schema<FinetunesPublicListResultItem>;
export type FinetunesPublicListResultList = Array<FinetunesPublicListResultItem>;
export declare const FinetunesPublicListResultList: S.Schema<FinetunesPublicListResultList>;
export interface ListFinetunePublicsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: FinetunesPublicListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListFinetunePublicsResponse: S.Schema<ListFinetunePublicsResponse>;
export interface ListFinetunesRequest {
    accountId: string;
}
export declare const ListFinetunesRequest: S.Schema<ListFinetunesRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListFinetunesResponse {
    id: string;
    createdAt: string;
    model: string;
    modifiedAt: string;
    name: string;
    description?: string | null;
}
export declare const ListFinetunesResponse: S.Schema<ListFinetunesResponse>;
export type ModelsListRequestFormat = "openrouter";
export declare const ModelsListRequestFormat: any;
export interface ListModelsRequest {
    accountId: string;
    /** Filter by Author */
    author?: string;
    /** If set, return models in the requested marketplace format instead of the default response. */
    format?: ModelsListRequestFormat | (string & {});
    /** Filter to hide experimental models */
    hideExperimental?: boolean;
    /** If true, include models whose planned_deprecation_date is in the past — but only within a three-month grace window after that date. Models whose planned_deprecation_date is more than three months in the past remain hidden regardless of this flag. Future planned-deprecation dates are always included regardless of this flag. Defaults to false, preserving the existing behavior of hiding all past-dated deprecations. */
    includeDeprecated?: boolean;
    page?: number;
    perPage?: number;
    /** Search */
    search?: string;
    /** Filter by Source Id */
    source?: number;
    /** Filter by Task Name */
    task?: string;
}
export declare const ListModelsRequest: S.Schema<ListModelsRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListModelsResponse {
}
export declare const ListModelsResponse: S.Schema<ListModelsResponse>;
export interface ListTasksRequest {
    accountId: string;
}
export declare const ListTasksRequest: S.Schema<ListTasksRequest>;
export type TasksListResultList = Array<unknown>;
export declare const TasksListResultList: S.Schema<TasksListResultList>;
export interface ListTasksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TasksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTasksResponse: S.Schema<ListTasksResponse>;
export type RunRequestTextTextEmbeddingsCase1List = Array<string>;
export declare const RunRequestTextTextEmbeddingsCase1List: S.Schema<RunRequestTextTextEmbeddingsCase1List>;
export type RunRequestTextTextEmbeddings = string | RunRequestTextTextEmbeddingsCase1List;
export declare const RunRequestTextTextEmbeddings: any;
export type RunRequestTextMultimodalEmbeddingsList = Array<string>;
export declare const RunRequestTextMultimodalEmbeddingsList: S.Schema<RunRequestTextMultimodalEmbeddingsList>;
export type RunRequestText = string | RunRequestTextTextEmbeddings | RunRequestTextMultimodalEmbeddingsList;
export declare const RunRequestText: any;
export type RunRequestImageTextToImageList = Array<number>;
export declare const RunRequestImageTextToImageList: S.Schema<RunRequestImageTextToImageList>;
export type RunRequestImage = string | RunRequestImageTextToImageList;
export declare const RunRequestImage: any;
export type RunRequestMaskList = Array<number>;
export declare const RunRequestMaskList: S.Schema<RunRequestMaskList>;
export type RunRequestAudioList = Array<number>;
export declare const RunRequestAudioList: S.Schema<RunRequestAudioList>;
export type RunRequestResponseFormatType = "json_object" | "json_schema";
export declare const RunRequestResponseFormatType: any;
export interface RunRequestResponseFormat {
    jsonSchema?: unknown;
    type?: RunRequestResponseFormatType | (string & {});
}
export declare const RunRequestResponseFormat: S.Schema<RunRequestResponseFormat>;
export interface RunRequestMessagesTextGenerationItemContentCase1Item {
    /** Text content */
    text?: string;
    /** Type of the content (text) */
    type?: string;
}
export declare const RunRequestMessagesTextGenerationItemContentCase1Item: S.Schema<RunRequestMessagesTextGenerationItemContentCase1Item>;
export type RunRequestMessagesTextGenerationItemContentCase1List = Array<RunRequestMessagesTextGenerationItemContentCase1Item>;
export declare const RunRequestMessagesTextGenerationItemContentCase1List: S.Schema<RunRequestMessagesTextGenerationItemContentCase1List>;
export type RunRequestMessagesTextGenerationItemContent = string | RunRequestMessagesTextGenerationItemContentCase1List;
export declare const RunRequestMessagesTextGenerationItemContent: any;
export interface RunRequestMessagesTextGenerationItem {
    /** The content of the message as a string. */
    content: RunRequestMessagesTextGenerationItemContent;
    /** The role of the message sender (e.g., 'user', 'assistant', 'system', 'tool'). */
    role: string;
}
export declare const RunRequestMessagesTextGenerationItem: S.Schema<RunRequestMessagesTextGenerationItem>;
export type RunRequestMessagesTextGenerationList = Array<RunRequestMessagesTextGenerationItem>;
export declare const RunRequestMessagesTextGenerationList: S.Schema<RunRequestMessagesTextGenerationList>;
export interface RunRequestMessagesImageTextToTextItemContentCase1ItemImageUrl {
    /** Image URI with data (e.g. data:image/jpeg;base64,/9j/...). */
    url: string;
}
export declare const RunRequestMessagesImageTextToTextItemContentCase1ItemImageUrl: S.Schema<RunRequestMessagesImageTextToTextItemContentCase1ItemImageUrl>;
export interface RunRequestMessagesImageTextToTextItemContentCase1Item {
    /** Type of the content part (e.g. 'text', 'image_url'). */
    type: string;
    /** Image URL object (when type is 'image_url'). */
    imageUrl?: RunRequestMessagesImageTextToTextItemContentCase1ItemImageUrl;
    /** Text content (when type is 'text'). */
    text?: string;
}
export declare const RunRequestMessagesImageTextToTextItemContentCase1Item: S.Schema<RunRequestMessagesImageTextToTextItemContentCase1Item>;
export type RunRequestMessagesImageTextToTextItemContentCase1List = Array<RunRequestMessagesImageTextToTextItemContentCase1Item>;
export declare const RunRequestMessagesImageTextToTextItemContentCase1List: S.Schema<RunRequestMessagesImageTextToTextItemContentCase1List>;
export type RunRequestMessagesImageTextToTextItemContent = string | RunRequestMessagesImageTextToTextItemContentCase1List;
export declare const RunRequestMessagesImageTextToTextItemContent: any;
export interface RunRequestMessagesImageTextToTextItem {
    /** The content of the message as a string. */
    content: RunRequestMessagesImageTextToTextItemContent;
    /** The role of the message sender (e.g., 'user', 'assistant', 'system', 'tool'). */
    role: string;
}
export declare const RunRequestMessagesImageTextToTextItem: S.Schema<RunRequestMessagesImageTextToTextItem>;
export type RunRequestMessagesImageTextToTextList = Array<RunRequestMessagesImageTextToTextItem>;
export declare const RunRequestMessagesImageTextToTextList: S.Schema<RunRequestMessagesImageTextToTextList>;
export type RunRequestMessages = RunRequestMessagesTextGenerationList | RunRequestMessagesImageTextToTextList;
export declare const RunRequestMessages: any;
export interface RunRequestFunctionsItem {
    code: string;
    name: string;
}
export declare const RunRequestFunctionsItem: S.Schema<RunRequestFunctionsItem>;
export type RunRequestFunctionsList = Array<RunRequestFunctionsItem>;
export declare const RunRequestFunctionsList: S.Schema<RunRequestFunctionsList>;
export interface RunRequestToolsItemCase0ParametersPropertiesValue {
    /** A description of the expected parameter. */
    description: string;
    /** The data type of the parameter. */
    type: string;
}
export declare const RunRequestToolsItemCase0ParametersPropertiesValue: S.Schema<RunRequestToolsItemCase0ParametersPropertiesValue>;
export type RunRequestToolsItemCase0ParametersPropertiesMap = {
    [key: string]: RunRequestToolsItemCase0ParametersPropertiesValue | undefined;
};
export declare const RunRequestToolsItemCase0ParametersPropertiesMap: S.Schema<RunRequestToolsItemCase0ParametersPropertiesMap>;
export type RunRequestToolsItemCase0ParametersRequiredList = Array<string>;
export declare const RunRequestToolsItemCase0ParametersRequiredList: S.Schema<RunRequestToolsItemCase0ParametersRequiredList>;
export interface RunRequestToolsItemCase0Parameters {
    /** Definitions of each parameter. */
    properties: RunRequestToolsItemCase0ParametersPropertiesMap;
    /** The type of the parameters object (usually 'object'). */
    type: string;
    /** List of required parameter names. */
    required?: RunRequestToolsItemCase0ParametersRequiredList;
}
export declare const RunRequestToolsItemCase0Parameters: S.Schema<RunRequestToolsItemCase0Parameters>;
export interface RunRequestToolsItemCase0 {
    /** A brief description of what the tool does. */
    description: string;
    /** The name of the tool. More descriptive the better. */
    name: string;
    /** Schema defining the parameters accepted by the tool. */
    parameters: RunRequestToolsItemCase0Parameters;
}
export declare const RunRequestToolsItemCase0: S.Schema<RunRequestToolsItemCase0>;
export type RunRequestToolsItemFunctionFunctionParametersPropertiesValue = RunRequestToolsItemCase0ParametersPropertiesValue;
export declare const RunRequestToolsItemFunctionFunctionParametersPropertiesValue: S.Schema<RunRequestToolsItemCase0ParametersPropertiesValue>;
export type RunRequestToolsItemFunctionFunctionParametersPropertiesMap = {
    [key: string]: RunRequestToolsItemCase0ParametersPropertiesValue | undefined;
};
export declare const RunRequestToolsItemFunctionFunctionParametersPropertiesMap: S.Schema<RunRequestToolsItemFunctionFunctionParametersPropertiesMap>;
export type RunRequestToolsItemFunctionFunctionParametersRequiredList = Array<string>;
export declare const RunRequestToolsItemFunctionFunctionParametersRequiredList: S.Schema<RunRequestToolsItemFunctionFunctionParametersRequiredList>;
export interface RunRequestToolsItemFunctionFunctionParameters {
    /** Definitions of each parameter. */
    properties: RunRequestToolsItemFunctionFunctionParametersPropertiesMap;
    /** The type of the parameters object (usually 'object'). */
    type: string;
    /** List of required parameter names. */
    required?: RunRequestToolsItemFunctionFunctionParametersRequiredList;
}
export declare const RunRequestToolsItemFunctionFunctionParameters: S.Schema<RunRequestToolsItemFunctionFunctionParameters>;
export interface RunRequestToolsItemFunctionFunction {
    /** A brief description of what the function does. */
    description: string;
    /** The name of the function. */
    name: string;
    /** Schema defining the parameters accepted by the function. */
    parameters: RunRequestToolsItemFunctionFunctionParameters;
}
export declare const RunRequestToolsItemFunctionFunction: S.Schema<RunRequestToolsItemFunctionFunction>;
export interface RunRequestToolsItemFunction {
    /** Details of the function tool. */
    function: RunRequestToolsItemFunctionFunction;
    /** Specifies the type of tool (e.g., 'function'). */
    type: string;
}
export declare const RunRequestToolsItemFunction: S.Schema<RunRequestToolsItemFunction>;
export type RunRequestToolsItem = RunRequestToolsItemCase0 | RunRequestToolsItemFunction;
export declare const RunRequestToolsItem: any;
export type RunRequestToolsList = Array<RunRequestToolsItem>;
export declare const RunRequestToolsList: S.Schema<RunRequestToolsList>;
export interface RunAiRequest {
    accountId: string;
    modelName: string;
    /** The text that you want to classify */
    text?: RunRequestText;
    /** A text description of the image you want to generate */
    prompt?: string;
    /** Controls how closely the generated image should adhere to the prompt; higher values make the image more aligned with the prompt */
    guidance?: number;
    /** The height of the generated image in pixels */
    height?: number;
    /** For use with img2img tasks. An array of integers that represent the image data constrained to 8-bit unsigned integer values */
    image?: RunRequestImage;
    /** For use with img2img tasks. A base64-encoded string of the input image */
    imageB64?: string;
    /** An array representing An array of integers that represent mask image data for inpainting constrained to 8-bit unsigned integer values */
    mask?: RunRequestMaskList;
    /** Text describing elements to avoid in the generated image */
    negativePrompt?: string;
    /** The number of diffusion steps; higher values can improve quality but take longer */
    numSteps?: number;
    /** Random seed for reproducibility of the image generation */
    seed?: number;
    /** A value between 0 and 1 indicating how strongly to apply the transformation during img2img tasks; lower values make the output closer to the input image */
    strength?: number;
    /** The width of the generated image in pixels */
    width?: number;
    /** The speech language (e.g., 'en' for English, 'fr' for French). Defaults to 'en' if not specified */
    lang?: string;
    /** An array of integers that represent the audio data constrained to 8-bit unsigned integer values */
    audio?: RunRequestAudioList;
    /** The language of the recorded audio */
    sourceLang?: string;
    /** The language to translate the transcription into. Currently only English is supported. */
    targetLang?: string;
    /** Decreases the likelihood of the model repeating the same lines verbatim. */
    frequencyPenalty?: number;
    /** Name of the LoRA (Low-Rank Adaptation) model to fine-tune the base model. */
    lora?: string;
    /** The maximum number of tokens to generate in the response. */
    maxTokens?: number;
    /** Increases the likelihood of the model introducing new topics. */
    presencePenalty?: number;
    /** If true, a chat template is not applied and you must adhere to the specific model's expected formatting. */
    raw?: boolean;
    /** Penalty for repeated tokens; higher values discourage repetition. */
    repetitionPenalty?: number;
    responseFormat?: RunRequestResponseFormat;
    /** If true, the response will be streamed back incrementally using SSE, Server Sent Events. */
    stream?: boolean;
    /** Controls the randomness of the output; higher values produce more random results. */
    temperature?: number;
    /** Limits the AI to choose from the top 'k' most probable words. Lower values make responses more focused; higher values introduce more variety and potential surprises. */
    topK?: number;
    /** Adjusts the creativity of the AI's responses by controlling how many possible words it considers. Lower values make outputs more predictable; higher values allow for more varied and creative responses. */
    topP?: number;
    /** An array of message objects representing the conversation history. */
    messages?: RunRequestMessages;
    functions?: RunRequestFunctionsList;
    /** A list of tools available for the assistant to use. */
    tools?: RunRequestToolsList;
    /** The text that you want the model to summarize */
    inputText?: string;
    /** The maximum length of the generated summary in tokens */
    maxLength?: number;
    /** Whether to ignore the EOS token and continue generating tokens after the EOS token is generated. */
    ignoreEos?: boolean;
}
export declare const RunAiRequest: S.Schema<RunAiRequest>;
export interface RunResultTextClassificationItem {
    /** The classification label assigned to the text (e.g., 'POSITIVE' or 'NEGATIVE') */
    label?: string | null;
    /** Confidence score indicating the likelihood that the text belongs to the specified label */
    score?: number | null;
}
export declare const RunResultTextClassificationItem: S.Schema<RunResultTextClassificationItem>;
export type RunResultTextClassificationList = Array<RunResultTextClassificationItem>;
export declare const RunResultTextClassificationList: S.Schema<RunResultTextClassificationList>;
export interface RunResultAudio {
    /** The generated audio in MP3 format, base64-encoded */
    audio?: string | null;
}
export declare const RunResultAudio: S.Schema<RunResultAudio>;
export type RunResultTextEmbeddingsDataItemList = Array<number>;
export declare const RunResultTextEmbeddingsDataItemList: S.Schema<RunResultTextEmbeddingsDataItemList>;
export type RunResultTextEmbeddingsDataList = Array<RunResultTextEmbeddingsDataItemList>;
export declare const RunResultTextEmbeddingsDataList: S.Schema<RunResultTextEmbeddingsDataList>;
export type RunResultTextEmbeddingsShapeList = Array<number>;
export declare const RunResultTextEmbeddingsShapeList: S.Schema<RunResultTextEmbeddingsShapeList>;
export interface RunResultTextEmbeddings {
    /** Embeddings of the requested text values */
    data?: RunResultTextEmbeddingsDataList | null;
    shape?: RunResultTextEmbeddingsShapeList | null;
}
export declare const RunResultTextEmbeddings: S.Schema<RunResultTextEmbeddings>;
export interface RunResultAutomaticSpeechRecognitionWordsItem {
    /** The ending second when the word completes */
    end?: number | null;
    /** The second this word begins in the recording */
    start?: number | null;
    word?: string | null;
}
export declare const RunResultAutomaticSpeechRecognitionWordsItem: S.Schema<RunResultAutomaticSpeechRecognitionWordsItem>;
export type RunResultAutomaticSpeechRecognitionWordsList = Array<RunResultAutomaticSpeechRecognitionWordsItem>;
export declare const RunResultAutomaticSpeechRecognitionWordsList: S.Schema<RunResultAutomaticSpeechRecognitionWordsList>;
export interface RunResultAutomaticSpeechRecognition {
    /** The transcription */
    text: string;
    vtt?: string | null;
    wordCount?: number | null;
    words?: RunResultAutomaticSpeechRecognitionWordsList | null;
}
export declare const RunResultAutomaticSpeechRecognition: S.Schema<RunResultAutomaticSpeechRecognition>;
export interface RunResultImageClassificationItem {
    /** The predicted category or class for the input image based on analysis */
    label?: string | null;
    /** A confidence value, between 0 and 1, indicating how certain the model is about the predicted label */
    score?: number | null;
}
export declare const RunResultImageClassificationItem: S.Schema<RunResultImageClassificationItem>;
export type RunResultImageClassificationList = Array<RunResultImageClassificationItem>;
export declare const RunResultImageClassificationList: S.Schema<RunResultImageClassificationList>;
export interface RunResultObjectDetectionItemBox {
    /** The x-coordinate of the bottom-right corner of the bounding box */
    xmax?: number | null;
    /** The x-coordinate of the top-left corner of the bounding box */
    xmin?: number | null;
    /** The y-coordinate of the bottom-right corner of the bounding box */
    ymax?: number | null;
    /** The y-coordinate of the top-left corner of the bounding box */
    ymin?: number | null;
}
export declare const RunResultObjectDetectionItemBox: S.Schema<RunResultObjectDetectionItemBox>;
export interface RunResultObjectDetectionItem {
    /** Coordinates defining the bounding box around the detected object */
    box?: RunResultObjectDetectionItemBox | null;
    /** The class label or name of the detected object */
    label?: string | null;
    /** Confidence score indicating the likelihood that the detection is correct */
    score?: number | null;
}
export declare const RunResultObjectDetectionItem: S.Schema<RunResultObjectDetectionItem>;
export type RunResultObjectDetectionList = Array<RunResultObjectDetectionItem>;
export declare const RunResultObjectDetectionList: S.Schema<RunResultObjectDetectionList>;
export interface RunResultCase8ToolCallsItem {
    /** The arguments passed to be passed to the tool call request */
    arguments?: unknown | null;
    /** The name of the tool to be called */
    name?: string | null;
}
export declare const RunResultCase8ToolCallsItem: S.Schema<RunResultCase8ToolCallsItem>;
export type RunResultCase8ToolCallsList = Array<RunResultCase8ToolCallsItem>;
export declare const RunResultCase8ToolCallsList: S.Schema<RunResultCase8ToolCallsList>;
export interface RunResultCase8Usage {
    /** Total number of tokens in output */
    completionTokens?: number | null;
    /** Total number of tokens in input */
    promptTokens?: number | null;
    /** Total number of input and output tokens */
    totalTokens?: number | null;
}
export declare const RunResultCase8Usage: S.Schema<RunResultCase8Usage>;
export interface RunResultCase8 {
    /** The generated text response from the model */
    response: string;
    /** An array of tool calls requests made during the response generation */
    toolCalls?: RunResultCase8ToolCallsList | null;
    /** Usage statistics for the inference request */
    usage?: RunResultCase8Usage | null;
}
export declare const RunResultCase8: S.Schema<RunResultCase8>;
export interface RunResultTranslation {
    /** The translated text in the target language */
    translatedText?: string | null;
}
export declare const RunResultTranslation: S.Schema<RunResultTranslation>;
export interface RunResultSummarization {
    /** The summarized version of the input text */
    summary?: string | null;
}
export declare const RunResultSummarization: S.Schema<RunResultSummarization>;
export interface RunResultImageToText {
    description?: string | null;
}
export declare const RunResultImageToText: S.Schema<RunResultImageToText>;
export type RunResultImageTextToText = RunResultImageToText;
export declare const RunResultImageTextToText: S.Schema<RunResultImageToText>;
export type RunResultMultimodalEmbeddingsDataItemList = Array<number>;
export declare const RunResultMultimodalEmbeddingsDataItemList: S.Schema<RunResultMultimodalEmbeddingsDataItemList>;
export type RunResultMultimodalEmbeddingsDataList = Array<RunResultMultimodalEmbeddingsDataItemList>;
export declare const RunResultMultimodalEmbeddingsDataList: S.Schema<RunResultMultimodalEmbeddingsDataList>;
export type RunResultMultimodalEmbeddingsShapeList = Array<number>;
export declare const RunResultMultimodalEmbeddingsShapeList: S.Schema<RunResultMultimodalEmbeddingsShapeList>;
export interface RunResultMultimodalEmbeddings {
    data?: RunResultMultimodalEmbeddingsDataList | null;
    shape?: RunResultMultimodalEmbeddingsShapeList | null;
}
export declare const RunResultMultimodalEmbeddings: S.Schema<RunResultMultimodalEmbeddings>;
export type RunResult = string | RunResultTextClassificationList | RunResultAudio | RunResultTextEmbeddings | RunResultAutomaticSpeechRecognition | RunResultImageClassificationList | RunResultObjectDetectionList | RunResultCase8 | RunResultTranslation | RunResultSummarization | RunResultImageToText | RunResultImageToText | RunResultMultimodalEmbeddings;
export declare const RunResult: any;
export type RunAiResponse = RunResult;
export declare const RunAiResponse: S.Schema<RunAiResponse>;
export interface SupportedToMarkdownRequest {
    accountId: string;
}
export declare const SupportedToMarkdownRequest: S.Schema<SupportedToMarkdownRequest>;
export interface ToMarkdownSupportedResultItem {
    extension: string;
    mimeType: string;
}
export declare const ToMarkdownSupportedResultItem: S.Schema<ToMarkdownSupportedResultItem>;
export type ToMarkdownSupportedResultList = Array<ToMarkdownSupportedResultItem>;
export declare const ToMarkdownSupportedResultList: S.Schema<ToMarkdownSupportedResultList>;
export interface SupportedToMarkdownResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ToMarkdownSupportedResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const SupportedToMarkdownResponse: S.Schema<SupportedToMarkdownResponse>;
export interface TransformToMarkdownRequest {
    accountId: string;
}
export declare const TransformToMarkdownRequest: S.Schema<TransformToMarkdownRequest>;
export interface ToMarkdownTransformResultItem {
    data: string;
    format: string;
    mimeType: string;
    name: string;
    tokens: string;
}
export declare const ToMarkdownTransformResultItem: S.Schema<ToMarkdownTransformResultItem>;
export type ToMarkdownTransformResultList = Array<ToMarkdownTransformResultItem>;
export declare const ToMarkdownTransformResultList: S.Schema<ToMarkdownTransformResultList>;
export type TransformToMarkdownResponse = ToMarkdownTransformResultList;
export declare const TransformToMarkdownResponse: S.Schema<TransformToMarkdownResponse>;
export type CreateFinetuneError = ModelNotSupported | AccountNotFound | CloudflareOpError;
/** Creates a new fine-tuning job for a Workers AI model using custom training data. */
export declare const createFinetune: API.OperationMethod<CreateFinetuneRequest, CreateFinetuneResponse, CreateFinetuneError, CloudflareOpContext>;
export type CreateFinetuneAssetError = ModelNotSupported | AccountNotFound | CloudflareOpError;
/** Uploads training data assets for a Workers AI fine-tuning job. */
export declare const createFinetuneAsset: API.OperationMethod<CreateFinetuneAssetRequest, CreateFinetuneAssetResponse, CreateFinetuneAssetError, CloudflareOpContext>;
export type GetModelSchemaError = ModelNotSupported | ModelSchemaNotFound | AccountNotFound | CloudflareOpError;
/** Retrieves the input and output JSON schema definition for a Workers AI model. */
export declare const getModelSchema: API.OperationMethod<GetModelSchemaRequest, GetModelSchemaResponse, GetModelSchemaError, CloudflareOpContext>;
export type ListAuthorsError = CloudflareOpError;
/** Searches Workers AI models by author or organization name. */
export declare const listAuthors: API.PaginatedOperationMethod<ListAuthorsRequest, ListAuthorsResponse, ListAuthorsError, CloudflareOpContext, unknown>;
export type ListFinetunePublicsError = CloudflareOpError;
/** Lists publicly available fine-tuned models that can be used with Workers AI. */
export declare const listFinetunePublics: API.PaginatedOperationMethod<ListFinetunePublicsRequest, ListFinetunePublicsResponse, ListFinetunePublicsError, CloudflareOpContext, FinetunesPublicListResultItem>;
export type ListFinetunesError = AccountNotFound | CloudflareOpError;
/** Lists all fine-tuning jobs created by the account, including status and metrics. */
export declare const listFinetunes: API.OperationMethod<ListFinetunesRequest, ListFinetunesResponse, ListFinetunesError, CloudflareOpContext>;
export type ListModelsError = CloudflareOpError;
/** Searches Workers AI models by name or description. */
export declare const listModels: API.OperationMethod<ListModelsRequest, ListModelsResponse, ListModelsError, CloudflareOpContext>;
export type ListTasksError = CloudflareOpError;
/** Searches Workers AI models by task type (e.g., text-generation, embeddings). */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest, ListTasksResponse, ListTasksError, CloudflareOpContext, unknown>;
export type RunAiError = ModelNotFound | CloudflareOpError;
/** This endpoint provides users with the capability to run specific AI models on-demand. By submitting the required input data, users can receive real-time predictions or results generated by the chosen AI model. The endpoint supports various AI model types, ensuring flexibility and adaptability for diverse use cases. Model specific inputs available in [Cloudflare Docs](https://developers.cloudflare.com/workers-ai/models/). */
export declare const runAi: API.OperationMethod<RunAiRequest, RunAiResponse, RunAiError, CloudflareOpContext>;
export type SupportedToMarkdownError = CloudflareOpError;
/** Lists all file formats supported for conversion to Markdown. */
export declare const supportedToMarkdown: API.PaginatedOperationMethod<SupportedToMarkdownRequest, SupportedToMarkdownResponse, SupportedToMarkdownError, CloudflareOpContext, ToMarkdownSupportedResultItem>;
export type TransformToMarkdownError = CloudflareOpError;
/** Converts uploaded files into Markdown format using Workers AI. */
export declare const transformToMarkdown: API.OperationMethod<TransformToMarkdownRequest, TransformToMarkdownResponse, TransformToMarkdownError, CloudflareOpContext>;
export declare const createAiToMarkdown: API.OperationMethod<TransformToMarkdownRequest, ToMarkdownTransformResultList, CloudflareOpError, CloudflareOpContext>;
export type CreateAiToMarkdownRequest = TransformToMarkdownRequest;
export type CreateAiToMarkdownResponse = TransformToMarkdownResponse;
export type CreateAiToMarkdownError = TransformToMarkdownError;
//# sourceMappingURL=ai.d.ts.map