import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidSinkConfig_base: S.Class<InvalidSinkConfig, S.TaggedStruct<"InvalidSinkConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSinkConfig extends /*@__PURE__*/ InvalidSinkConfig_base {
}
declare const InvalidSinkId_base: S.Class<InvalidSinkId, S.TaggedStruct<"InvalidSinkId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSinkId extends /*@__PURE__*/ InvalidSinkId_base {
}
declare const InvalidSql_base: S.Class<InvalidSql, S.TaggedStruct<"InvalidSql", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSql extends /*@__PURE__*/ InvalidSql_base {
}
declare const InvalidStreamId_base: S.Class<InvalidStreamId, S.TaggedStruct<"InvalidStreamId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStreamId extends /*@__PURE__*/ InvalidStreamId_base {
}
declare const InvalidStreamName_base: S.Class<InvalidStreamName, S.TaggedStruct<"InvalidStreamName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStreamName extends /*@__PURE__*/ InvalidStreamName_base {
}
declare const PipelineAlreadyExists_base: S.Class<PipelineAlreadyExists, S.TaggedStruct<"PipelineAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineAlreadyExists extends /*@__PURE__*/ PipelineAlreadyExists_base {
}
declare const PipelineNotExists_base: S.Class<PipelineNotExists, S.TaggedStruct<"PipelineNotExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PipelineNotExists extends /*@__PURE__*/ PipelineNotExists_base {
}
declare const SinkAlreadyExists_base: S.Class<SinkAlreadyExists, S.TaggedStruct<"SinkAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SinkAlreadyExists extends /*@__PURE__*/ SinkAlreadyExists_base {
}
declare const SinkAuthFailed_base: S.Class<SinkAuthFailed, S.TaggedStruct<"SinkAuthFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SinkAuthFailed extends /*@__PURE__*/ SinkAuthFailed_base {
}
declare const SinkInUse_base: S.Class<SinkInUse, S.TaggedStruct<"SinkInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SinkInUse extends /*@__PURE__*/ SinkInUse_base {
}
declare const SinkNotFound_base: S.Class<SinkNotFound, S.TaggedStruct<"SinkNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SinkNotFound extends /*@__PURE__*/ SinkNotFound_base {
}
declare const StreamAlreadyExists_base: S.Class<StreamAlreadyExists, S.TaggedStruct<"StreamAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StreamAlreadyExists extends /*@__PURE__*/ StreamAlreadyExists_base {
}
declare const StreamInUse_base: S.Class<StreamInUse, S.TaggedStruct<"StreamInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StreamInUse extends /*@__PURE__*/ StreamInUse_base {
}
declare const StreamNotFound_base: S.Class<StreamNotFound, S.TaggedStruct<"StreamNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StreamNotFound extends /*@__PURE__*/ StreamNotFound_base {
}
declare const TableNotFound_base: S.Class<TableNotFound, S.TaggedStruct<"TableNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TableNotFound extends /*@__PURE__*/ TableNotFound_base {
}
export interface CreateRequestDestinationBatch {
    /** Specifies rough maximum size of files. */
    maxBytes?: number;
    /** Specifies duration to wait to aggregate batches files. */
    maxDurationS?: number;
    /** Specifies rough maximum number of rows per file. */
    maxRows?: number;
}
export declare const CreateRequestDestinationBatch: S.Schema<CreateRequestDestinationBatch>;
export type CreateRequestDestinationCompressionType = "none" | "gzip" | "deflate";
export declare const CreateRequestDestinationCompressionType: any;
export interface CreateRequestDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type?: CreateRequestDestinationCompressionType | (string & {});
}
export declare const CreateRequestDestinationCompression: S.Schema<CreateRequestDestinationCompression>;
export interface CreateRequestDestinationCredentials {
    /** Specifies the R2 Bucket Access Key Id. */
    accessKeyId: string;
    /** Specifies the R2 Endpoint. */
    endpoint: string;
    /** Specifies the R2 Bucket Secret Access Key. */
    secretAccessKey: string;
}
export declare const CreateRequestDestinationCredentials: S.Schema<CreateRequestDestinationCredentials>;
export type CreateRequestDestinationFormat = "json";
export declare const CreateRequestDestinationFormat: any;
export interface CreateRequestDestinationPath {
    /** Specifies the R2 Bucket to store files. */
    bucket: string;
    /** Specifies the name pattern to for individual data files. */
    filename?: string;
    /** Specifies the name pattern for directory. */
    filepath?: string;
    /** Specifies the base directory within the bucket. */
    prefix?: string;
}
export declare const CreateRequestDestinationPath: S.Schema<CreateRequestDestinationPath>;
export type CreateRequestDestinationType = "r2";
export declare const CreateRequestDestinationType: any;
export interface CreateRequestDestination {
    batch: CreateRequestDestinationBatch;
    compression: CreateRequestDestinationCompression;
    credentials: CreateRequestDestinationCredentials;
    /** Specifies the format of data to deliver. */
    format: CreateRequestDestinationFormat | (string & {});
    path: CreateRequestDestinationPath;
    /** Specifies the type of destination. */
    type: CreateRequestDestinationType | (string & {});
}
export declare const CreateRequestDestination: S.Schema<CreateRequestDestination>;
export type CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export declare const CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat: any;
export type CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export declare const CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList: S.Schema<CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList>;
export interface CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList;
}
export declare const CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors: S.Schema<CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors>;
export interface CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean;
    cors?: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors;
}
export declare const CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource: S.Schema<CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource>;
export type CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export declare const CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat: any;
export interface CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export declare const CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource: S.Schema<CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource>;
export type CreateRequestSourceItem = CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | CreateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export declare const CreateRequestSourceItem: any;
export type CreateRequestSourceList = Array<CreateRequestSourceItem>;
export declare const CreateRequestSourceList: S.Schema<CreateRequestSourceList>;
export interface CreatePipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    destination: CreateRequestDestination;
    /** Defines the name of the pipeline. */
    name: string;
    source: CreateRequestSourceList;
}
export declare const CreatePipelineRequest: S.Schema<CreatePipelineRequest>;
export interface CreateResponseDestinationBatch {
    /** Specifies rough maximum size of files. */
    maxBytes: number;
    /** Specifies duration to wait to aggregate batches files. */
    maxDurationS: number;
    /** Specifies rough maximum number of rows per file. */
    maxRows: number;
}
export declare const CreateResponseDestinationBatch: S.Schema<CreateResponseDestinationBatch>;
export type CreateResponseDestinationCompressionType = "none" | "gzip" | "deflate";
export declare const CreateResponseDestinationCompressionType: any;
export interface CreateResponseDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: CreateResponseDestinationCompressionType;
}
export declare const CreateResponseDestinationCompression: S.Schema<CreateResponseDestinationCompression>;
export type CreateResponseDestinationFormat = "json";
export declare const CreateResponseDestinationFormat: any;
export interface CreateResponseDestinationPath {
    /** Specifies the R2 Bucket to store files. */
    bucket: string;
    /** Specifies the name pattern to for individual data files. */
    filename?: string | null;
    /** Specifies the name pattern for directory. */
    filepath?: string | null;
    /** Specifies the base directory within the bucket. */
    prefix?: string | null;
}
export declare const CreateResponseDestinationPath: S.Schema<CreateResponseDestinationPath>;
export type CreateResponseDestinationType = "r2";
export declare const CreateResponseDestinationType: any;
export interface CreateResponseDestination {
    batch: CreateResponseDestinationBatch;
    compression: CreateResponseDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: CreateResponseDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: CreateResponseDestinationType;
}
export declare const CreateResponseDestination: S.Schema<CreateResponseDestination>;
export type CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export declare const CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat: any;
export type CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export declare const CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList: S.Schema<CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList>;
export interface CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export declare const CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors: S.Schema<CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors>;
export interface CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export declare const CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource: S.Schema<CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource>;
export type CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export declare const CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat: any;
export interface CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export declare const CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource: S.Schema<CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource>;
export type CreateResponseSourceItem = CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | CreateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export declare const CreateResponseSourceItem: any;
export type CreateResponseSourceList = Array<CreateResponseSourceItem>;
export declare const CreateResponseSourceList: S.Schema<CreateResponseSourceList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePipelineResponse {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: CreateResponseDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: CreateResponseSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export declare const CreatePipelineResponse: S.Schema<CreatePipelineResponse>;
export type SinksCreateRequestType = "r2" | "r2_data_catalog";
export declare const SinksCreateRequestType: any;
export interface SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials {
    /** Cloudflare Account ID for the bucket */
    accessKeyId: string;
    /** Cloudflare Account ID for the bucket */
    secretAccessKey: string;
}
export declare const SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials>;
export type SinksCreateRequestConfigCloudflarePipelinesR2TableFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export declare const SinksCreateRequestConfigCloudflarePipelinesR2TableFileNamingStrategy: any;
export interface SinksCreateRequestConfigCloudflarePipelinesR2TableFileNaming {
    /** The prefix to use in file name. i.e prefix-<uuid>.parquet */
    prefix?: string;
    /** Filename generation strategy. */
    strategy?: SinksCreateRequestConfigCloudflarePipelinesR2TableFileNamingStrategy | (string & {});
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string;
}
export declare const SinksCreateRequestConfigCloudflarePipelinesR2TableFileNaming: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2TableFileNaming>;
export interface SinksCreateRequestConfigCloudflarePipelinesR2TablePartitioning {
    /** The pattern of the date string */
    timePattern?: string;
}
export declare const SinksCreateRequestConfigCloudflarePipelinesR2TablePartitioning: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2TablePartitioning>;
export interface SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy {
    /** Files will be rolled after reaching this number of bytes */
    fileSizeBytes?: number;
    /** Number of seconds of inactivity to wait before rolling over to a new file */
    inactivitySeconds?: number;
    /** Number of seconds to wait before rolling over to a new file */
    intervalSeconds?: number;
}
export declare const SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksCreateRequestConfigCloudflarePipelinesR2Table {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    credentials: SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksCreateRequestConfigCloudflarePipelinesR2TableFileNaming;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateRequestConfigCloudflarePipelinesR2TablePartitioning;
    /** Subpath within the bucket to write to */
    path?: string;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy;
}
export declare const SinksCreateRequestConfigCloudflarePipelinesR2Table: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2Table>;
export type SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTableRollingPolicy = SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy;
export declare const SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTableRollingPolicy: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTable {
    /** Authentication token */
    token: string;
    /** Cloudflare Account ID */
    accountId: string;
    /** The R2 Bucket that hosts this catalog */
    bucket: string;
    /** Table name */
    tableName: string;
    /** Table namespace */
    namespace?: string;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateRequestConfigCloudflarePipelinesR2TableRollingPolicy;
}
export declare const SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTable: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTable>;
export type SinksCreateRequestConfig = SinksCreateRequestConfigCloudflarePipelinesR2Table | SinksCreateRequestConfigCloudflarePipelinesR2DataCatalogTable;
export declare const SinksCreateRequestConfig: any;
export type SinksCreateRequestFormatJsonType = "json";
export declare const SinksCreateRequestFormatJsonType: any;
export type SinksCreateRequestFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksCreateRequestFormatJsonDecimalEncoding: any;
export type SinksCreateRequestFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksCreateRequestFormatJsonTimestampFormat: any;
export interface SinksCreateRequestFormatJson {
    type: SinksCreateRequestFormatJsonType;
    decimalEncoding?: SinksCreateRequestFormatJsonDecimalEncoding | (string & {});
    timestampFormat?: SinksCreateRequestFormatJsonTimestampFormat | (string & {});
    unstructured?: boolean;
}
export declare const SinksCreateRequestFormatJson: S.Schema<SinksCreateRequestFormatJson>;
export type SinksCreateRequestFormatParquetType = "parquet";
export declare const SinksCreateRequestFormatParquetType: any;
export type SinksCreateRequestFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksCreateRequestFormatParquetCompression: any;
export interface SinksCreateRequestFormatParquet {
    type: SinksCreateRequestFormatParquetType;
    compression?: SinksCreateRequestFormatParquetCompression | (string & {});
    rowGroupBytes?: number;
}
export declare const SinksCreateRequestFormatParquet: S.Schema<SinksCreateRequestFormatParquet>;
export type SinksCreateRequestFormat = SinksCreateRequestFormatJson | SinksCreateRequestFormatParquet;
export declare const SinksCreateRequestFormat: any;
export type SinksCreateRequestSchemaFieldsList = Array<unknown>;
export declare const SinksCreateRequestSchemaFieldsList: S.Schema<SinksCreateRequestSchemaFieldsList>;
export type SinksCreateRequestSchemaFormatJsonType = "json";
export declare const SinksCreateRequestSchemaFormatJsonType: any;
export type SinksCreateRequestSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksCreateRequestSchemaFormatJsonDecimalEncoding: any;
export type SinksCreateRequestSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksCreateRequestSchemaFormatJsonTimestampFormat: any;
export interface SinksCreateRequestSchemaFormatJson {
    type: SinksCreateRequestSchemaFormatJsonType;
    decimalEncoding?: SinksCreateRequestSchemaFormatJsonDecimalEncoding | (string & {});
    timestampFormat?: SinksCreateRequestSchemaFormatJsonTimestampFormat | (string & {});
    unstructured?: boolean;
}
export declare const SinksCreateRequestSchemaFormatJson: S.Schema<SinksCreateRequestSchemaFormatJson>;
export type SinksCreateRequestSchemaFormatParquetType = "parquet";
export declare const SinksCreateRequestSchemaFormatParquetType: any;
export type SinksCreateRequestSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksCreateRequestSchemaFormatParquetCompression: any;
export interface SinksCreateRequestSchemaFormatParquet {
    type: SinksCreateRequestSchemaFormatParquetType;
    compression?: SinksCreateRequestSchemaFormatParquetCompression | (string & {});
    rowGroupBytes?: number;
}
export declare const SinksCreateRequestSchemaFormatParquet: S.Schema<SinksCreateRequestSchemaFormatParquet>;
export type SinksCreateRequestSchemaFormat = SinksCreateRequestSchemaFormatJson | SinksCreateRequestSchemaFormatParquet;
export declare const SinksCreateRequestSchemaFormat: any;
export interface SinksCreateRequestSchema {
    fields?: SinksCreateRequestSchemaFieldsList;
    format?: SinksCreateRequestSchemaFormat;
    inferred?: boolean;
}
export declare const SinksCreateRequestSchema: S.Schema<SinksCreateRequestSchema>;
export interface CreateSinkRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksCreateRequestType | (string & {});
    /** Defines the configuration of the R2 Sink. */
    config?: SinksCreateRequestConfig;
    format?: SinksCreateRequestFormat;
    schema?: SinksCreateRequestSchema;
}
export declare const CreateSinkRequest: S.Schema<CreateSinkRequest>;
export type SinksCreateResponseType = "r2" | "r2_data_catalog";
export declare const SinksCreateResponseType: any;
export type SinksCreateResponseConfigCloudflarePipelinesR2TableCredentials = SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials;
export declare const SinksCreateResponseConfigCloudflarePipelinesR2TableCredentials: S.Schema<SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials>;
export type SinksCreateResponseConfigCloudflarePipelinesR2TableFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export declare const SinksCreateResponseConfigCloudflarePipelinesR2TableFileNamingStrategy: any;
export interface SinksCreateResponseConfigCloudflarePipelinesR2TableFileNaming {
    /** The prefix to use in file name. i.e prefix-<uuid>.parquet */
    prefix?: string | null;
    /** Filename generation strategy. */
    strategy?: SinksCreateResponseConfigCloudflarePipelinesR2TableFileNamingStrategy | null;
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string | null;
}
export declare const SinksCreateResponseConfigCloudflarePipelinesR2TableFileNaming: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableFileNaming>;
export interface SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning {
    /** The pattern of the date string */
    timePattern?: string | null;
}
export declare const SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning>;
export interface SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy {
    /** Files will be rolled after reaching this number of bytes */
    fileSizeBytes?: number | null;
    /** Number of seconds of inactivity to wait before rolling over to a new file */
    inactivitySeconds?: number | null;
    /** Number of seconds to wait before rolling over to a new file */
    intervalSeconds?: number | null;
}
export declare const SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksCreateResponseConfigCloudflarePipelinesR2Table {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    credentials: SinksCreateRequestConfigCloudflarePipelinesR2TableCredentials;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksCreateResponseConfigCloudflarePipelinesR2TableFileNaming | null;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string | null;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning | null;
    /** Subpath within the bucket to write to */
    path?: string | null;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export declare const SinksCreateResponseConfigCloudflarePipelinesR2Table: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2Table>;
export type SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTableRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export declare const SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTableRollingPolicy: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTable {
    /** Authentication token */
    token: string;
    /** Cloudflare Account ID */
    accountId: string;
    /** The R2 Bucket that hosts this catalog */
    bucket: string;
    /** Table name */
    tableName: string;
    /** Table namespace */
    namespace?: string | null;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export declare const SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTable: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTable>;
export type SinksCreateResponseConfig = SinksCreateResponseConfigCloudflarePipelinesR2Table | SinksCreateResponseConfigCloudflarePipelinesR2DataCatalogTable;
export declare const SinksCreateResponseConfig: any;
export type SinksCreateResponseFormatJsonType = "json";
export declare const SinksCreateResponseFormatJsonType: any;
export type SinksCreateResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksCreateResponseFormatJsonDecimalEncoding: any;
export type SinksCreateResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksCreateResponseFormatJsonTimestampFormat: any;
export interface SinksCreateResponseFormatJson {
    type: SinksCreateResponseFormatJsonType;
    decimalEncoding?: SinksCreateResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksCreateResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const SinksCreateResponseFormatJson: S.Schema<SinksCreateResponseFormatJson>;
export type SinksCreateResponseFormatParquetType = "parquet";
export declare const SinksCreateResponseFormatParquetType: any;
export type SinksCreateResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksCreateResponseFormatParquetCompression: any;
export interface SinksCreateResponseFormatParquet {
    type: SinksCreateResponseFormatParquetType;
    compression?: SinksCreateResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const SinksCreateResponseFormatParquet: S.Schema<SinksCreateResponseFormatParquet>;
export type SinksCreateResponseFormat = SinksCreateResponseFormatJson | SinksCreateResponseFormatParquet;
export declare const SinksCreateResponseFormat: any;
export type SinksCreateResponseSchemaFieldsList = Array<unknown>;
export declare const SinksCreateResponseSchemaFieldsList: S.Schema<SinksCreateResponseSchemaFieldsList>;
export type SinksCreateResponseSchemaFormatJsonType = "json";
export declare const SinksCreateResponseSchemaFormatJsonType: any;
export type SinksCreateResponseSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksCreateResponseSchemaFormatJsonDecimalEncoding: any;
export type SinksCreateResponseSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksCreateResponseSchemaFormatJsonTimestampFormat: any;
export interface SinksCreateResponseSchemaFormatJson {
    type: SinksCreateResponseSchemaFormatJsonType;
    decimalEncoding?: SinksCreateResponseSchemaFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksCreateResponseSchemaFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const SinksCreateResponseSchemaFormatJson: S.Schema<SinksCreateResponseSchemaFormatJson>;
export type SinksCreateResponseSchemaFormatParquetType = "parquet";
export declare const SinksCreateResponseSchemaFormatParquetType: any;
export type SinksCreateResponseSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksCreateResponseSchemaFormatParquetCompression: any;
export interface SinksCreateResponseSchemaFormatParquet {
    type: SinksCreateResponseSchemaFormatParquetType;
    compression?: SinksCreateResponseSchemaFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const SinksCreateResponseSchemaFormatParquet: S.Schema<SinksCreateResponseSchemaFormatParquet>;
export type SinksCreateResponseSchemaFormat = SinksCreateResponseSchemaFormatJson | SinksCreateResponseSchemaFormatParquet;
export declare const SinksCreateResponseSchemaFormat: any;
export interface SinksCreateResponseSchema {
    fields?: SinksCreateResponseSchemaFieldsList | null;
    format?: SinksCreateResponseSchemaFormat | null;
    inferred?: boolean | null;
}
export declare const SinksCreateResponseSchema: S.Schema<SinksCreateResponseSchema>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSinkResponse {
    /** Indicates a unique identifier for this sink. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksCreateResponseType;
    /** R2 Data Catalog Sink */
    config?: SinksCreateResponseConfig | null;
    format?: SinksCreateResponseFormat | null;
    schema?: SinksCreateResponseSchema | null;
}
export declare const CreateSinkResponse: S.Schema<CreateSinkResponse>;
export type StreamsCreateRequestFormatJsonType = "json";
export declare const StreamsCreateRequestFormatJsonType: any;
export type StreamsCreateRequestFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsCreateRequestFormatJsonDecimalEncoding: any;
export type StreamsCreateRequestFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsCreateRequestFormatJsonTimestampFormat: any;
export interface StreamsCreateRequestFormatJson {
    type: StreamsCreateRequestFormatJsonType;
    decimalEncoding?: StreamsCreateRequestFormatJsonDecimalEncoding | (string & {});
    timestampFormat?: StreamsCreateRequestFormatJsonTimestampFormat | (string & {});
    unstructured?: boolean;
}
export declare const StreamsCreateRequestFormatJson: S.Schema<StreamsCreateRequestFormatJson>;
export type StreamsCreateRequestFormatParquetType = "parquet";
export declare const StreamsCreateRequestFormatParquetType: any;
export type StreamsCreateRequestFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsCreateRequestFormatParquetCompression: any;
export interface StreamsCreateRequestFormatParquet {
    type: StreamsCreateRequestFormatParquetType;
    compression?: StreamsCreateRequestFormatParquetCompression | (string & {});
    rowGroupBytes?: number;
}
export declare const StreamsCreateRequestFormatParquet: S.Schema<StreamsCreateRequestFormatParquet>;
export type StreamsCreateRequestFormat = StreamsCreateRequestFormatJson | StreamsCreateRequestFormatParquet;
export declare const StreamsCreateRequestFormat: any;
export type StreamsCreateRequestHttpCorsOriginsList = Array<string>;
export declare const StreamsCreateRequestHttpCorsOriginsList: S.Schema<StreamsCreateRequestHttpCorsOriginsList>;
export interface StreamsCreateRequestHttpCors {
    origins?: StreamsCreateRequestHttpCorsOriginsList;
}
export declare const StreamsCreateRequestHttpCors: S.Schema<StreamsCreateRequestHttpCors>;
export interface StreamsCreateRequestHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsCreateRequestHttpCors;
}
export declare const StreamsCreateRequestHttp: S.Schema<StreamsCreateRequestHttp>;
export type StreamsCreateRequestSchemaFieldsList = Array<unknown>;
export declare const StreamsCreateRequestSchemaFieldsList: S.Schema<StreamsCreateRequestSchemaFieldsList>;
export type StreamsCreateRequestSchemaFormatJsonType = "json";
export declare const StreamsCreateRequestSchemaFormatJsonType: any;
export type StreamsCreateRequestSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsCreateRequestSchemaFormatJsonDecimalEncoding: any;
export type StreamsCreateRequestSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsCreateRequestSchemaFormatJsonTimestampFormat: any;
export interface StreamsCreateRequestSchemaFormatJson {
    type: StreamsCreateRequestSchemaFormatJsonType;
    decimalEncoding?: StreamsCreateRequestSchemaFormatJsonDecimalEncoding | (string & {});
    timestampFormat?: StreamsCreateRequestSchemaFormatJsonTimestampFormat | (string & {});
    unstructured?: boolean;
}
export declare const StreamsCreateRequestSchemaFormatJson: S.Schema<StreamsCreateRequestSchemaFormatJson>;
export type StreamsCreateRequestSchemaFormatParquetType = "parquet";
export declare const StreamsCreateRequestSchemaFormatParquetType: any;
export type StreamsCreateRequestSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsCreateRequestSchemaFormatParquetCompression: any;
export interface StreamsCreateRequestSchemaFormatParquet {
    type: StreamsCreateRequestSchemaFormatParquetType;
    compression?: StreamsCreateRequestSchemaFormatParquetCompression | (string & {});
    rowGroupBytes?: number;
}
export declare const StreamsCreateRequestSchemaFormatParquet: S.Schema<StreamsCreateRequestSchemaFormatParquet>;
export type StreamsCreateRequestSchemaFormat = StreamsCreateRequestSchemaFormatJson | StreamsCreateRequestSchemaFormatParquet;
export declare const StreamsCreateRequestSchemaFormat: any;
export interface StreamsCreateRequestSchema {
    fields?: StreamsCreateRequestSchemaFieldsList;
    format?: StreamsCreateRequestSchemaFormat;
    inferred?: boolean;
}
export declare const StreamsCreateRequestSchema: S.Schema<StreamsCreateRequestSchema>;
export interface StreamsCreateRequestWorkerBinding {
    /** Indicates that the worker binding is enabled. */
    enabled: boolean;
}
export declare const StreamsCreateRequestWorkerBinding: S.Schema<StreamsCreateRequestWorkerBinding>;
export interface CreateStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the name of the Stream. */
    name: string;
    format?: StreamsCreateRequestFormat;
    http?: StreamsCreateRequestHttp;
    schema?: StreamsCreateRequestSchema;
    workerBinding?: StreamsCreateRequestWorkerBinding;
}
export declare const CreateStreamRequest: S.Schema<CreateStreamRequest>;
export type StreamsCreateResponseHttpCorsOriginsList = Array<string>;
export declare const StreamsCreateResponseHttpCorsOriginsList: S.Schema<StreamsCreateResponseHttpCorsOriginsList>;
export interface StreamsCreateResponseHttpCors {
    origins?: StreamsCreateResponseHttpCorsOriginsList | null;
}
export declare const StreamsCreateResponseHttpCors: S.Schema<StreamsCreateResponseHttpCors>;
export interface StreamsCreateResponseHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsCreateResponseHttpCors | null;
}
export declare const StreamsCreateResponseHttp: S.Schema<StreamsCreateResponseHttp>;
export type StreamsCreateResponseWorkerBinding = StreamsCreateRequestWorkerBinding;
export declare const StreamsCreateResponseWorkerBinding: S.Schema<StreamsCreateRequestWorkerBinding>;
export type StreamsCreateResponseFormatJsonType = "json";
export declare const StreamsCreateResponseFormatJsonType: any;
export type StreamsCreateResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsCreateResponseFormatJsonDecimalEncoding: any;
export type StreamsCreateResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsCreateResponseFormatJsonTimestampFormat: any;
export interface StreamsCreateResponseFormatJson {
    type: StreamsCreateResponseFormatJsonType;
    decimalEncoding?: StreamsCreateResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsCreateResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsCreateResponseFormatJson: S.Schema<StreamsCreateResponseFormatJson>;
export type StreamsCreateResponseFormatParquetType = "parquet";
export declare const StreamsCreateResponseFormatParquetType: any;
export type StreamsCreateResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsCreateResponseFormatParquetCompression: any;
export interface StreamsCreateResponseFormatParquet {
    type: StreamsCreateResponseFormatParquetType;
    compression?: StreamsCreateResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsCreateResponseFormatParquet: S.Schema<StreamsCreateResponseFormatParquet>;
export type StreamsCreateResponseFormat = StreamsCreateResponseFormatJson | StreamsCreateResponseFormatParquet;
export declare const StreamsCreateResponseFormat: any;
export type StreamsCreateResponseSchemaFieldsList = Array<unknown>;
export declare const StreamsCreateResponseSchemaFieldsList: S.Schema<StreamsCreateResponseSchemaFieldsList>;
export type StreamsCreateResponseSchemaFormatJsonType = "json";
export declare const StreamsCreateResponseSchemaFormatJsonType: any;
export type StreamsCreateResponseSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsCreateResponseSchemaFormatJsonDecimalEncoding: any;
export type StreamsCreateResponseSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsCreateResponseSchemaFormatJsonTimestampFormat: any;
export interface StreamsCreateResponseSchemaFormatJson {
    type: StreamsCreateResponseSchemaFormatJsonType;
    decimalEncoding?: StreamsCreateResponseSchemaFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsCreateResponseSchemaFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsCreateResponseSchemaFormatJson: S.Schema<StreamsCreateResponseSchemaFormatJson>;
export type StreamsCreateResponseSchemaFormatParquetType = "parquet";
export declare const StreamsCreateResponseSchemaFormatParquetType: any;
export type StreamsCreateResponseSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsCreateResponseSchemaFormatParquetCompression: any;
export interface StreamsCreateResponseSchemaFormatParquet {
    type: StreamsCreateResponseSchemaFormatParquetType;
    compression?: StreamsCreateResponseSchemaFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsCreateResponseSchemaFormatParquet: S.Schema<StreamsCreateResponseSchemaFormatParquet>;
export type StreamsCreateResponseSchemaFormat = StreamsCreateResponseSchemaFormatJson | StreamsCreateResponseSchemaFormatParquet;
export declare const StreamsCreateResponseSchemaFormat: any;
export interface StreamsCreateResponseSchema {
    fields?: StreamsCreateResponseSchemaFieldsList | null;
    format?: StreamsCreateResponseSchemaFormat | null;
    inferred?: boolean | null;
}
export declare const StreamsCreateResponseSchema: S.Schema<StreamsCreateResponseSchema>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateStreamResponse {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsCreateResponseHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    format?: StreamsCreateResponseFormat | null;
    schema?: StreamsCreateResponseSchema | null;
}
export declare const CreateStreamResponse: S.Schema<CreateStreamResponse>;
export interface CreateV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
}
export declare const CreateV1PipelineRequest: S.Schema<CreateV1PipelineRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateV1PipelineResponse {
    /** Indicates a unique identifier for this pipeline. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Indicates the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
    /** Indicates the current status of the Pipeline. */
    status: string;
}
export declare const CreateV1PipelineResponse: S.Schema<CreateV1PipelineResponse>;
export interface DeletePipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the pipeline. */
    pipelineName: string;
}
export declare const DeletePipelineRequest: S.Schema<DeletePipelineRequest>;
export interface DeletePipelineResponse {
}
export declare const DeletePipelineResponse: S.Schema<DeletePipelineResponse>;
export interface DeleteSinkRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the publid ID of the sink. */
    sinkId: string;
    /** Deprecated: Delete sink forcefully, including deleting any dependent pipelines. */
    force?: string;
}
export declare const DeleteSinkRequest: S.Schema<DeleteSinkRequest>;
export type DeleteSinkResponse = unknown;
export declare const DeleteSinkResponse: S.Schema<DeleteSinkResponse>;
export interface DeleteStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the stream. */
    streamId: string;
    /** Deprecated: Delete stream forcefully, including deleting any dependent pipelines. */
    force?: string;
}
export declare const DeleteStreamRequest: S.Schema<DeleteStreamRequest>;
export type DeleteStreamResponse = unknown;
export declare const DeleteStreamResponse: S.Schema<DeleteStreamResponse>;
export interface DeleteV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the pipeline. */
    pipelineId: string;
}
export declare const DeleteV1PipelineRequest: S.Schema<DeleteV1PipelineRequest>;
export type DeleteV1PipelineResponse = unknown;
export declare const DeleteV1PipelineResponse: S.Schema<DeleteV1PipelineResponse>;
export interface GetPipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the pipeline. */
    pipelineName: string;
}
export declare const GetPipelineRequest: S.Schema<GetPipelineRequest>;
export type GetResponseDestinationBatch = CreateResponseDestinationBatch;
export declare const GetResponseDestinationBatch: S.Schema<CreateResponseDestinationBatch>;
export type GetResponseDestinationCompressionType = "none" | "gzip" | "deflate";
export declare const GetResponseDestinationCompressionType: any;
export interface GetResponseDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: GetResponseDestinationCompressionType;
}
export declare const GetResponseDestinationCompression: S.Schema<GetResponseDestinationCompression>;
export type GetResponseDestinationFormat = "json";
export declare const GetResponseDestinationFormat: any;
export type GetResponseDestinationPath = CreateResponseDestinationPath;
export declare const GetResponseDestinationPath: S.Schema<CreateResponseDestinationPath>;
export type GetResponseDestinationType = "r2";
export declare const GetResponseDestinationType: any;
export interface GetResponseDestination {
    batch: CreateResponseDestinationBatch;
    compression: GetResponseDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: GetResponseDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: GetResponseDestinationType;
}
export declare const GetResponseDestination: S.Schema<GetResponseDestination>;
export type GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export declare const GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat: any;
export type GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export declare const GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList: S.Schema<GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList>;
export interface GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export declare const GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors: S.Schema<GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors>;
export interface GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export declare const GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource: S.Schema<GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource>;
export type GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export declare const GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat: any;
export interface GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export declare const GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource: S.Schema<GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource>;
export type GetResponseSourceItem = GetResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | GetResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export declare const GetResponseSourceItem: any;
export type GetResponseSourceList = Array<GetResponseSourceItem>;
export declare const GetResponseSourceList: S.Schema<GetResponseSourceList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPipelineResponse {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: GetResponseDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: GetResponseSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export declare const GetPipelineResponse: S.Schema<GetPipelineResponse>;
export interface GetSinkRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the publid ID of the sink. */
    sinkId: string;
}
export declare const GetSinkRequest: S.Schema<GetSinkRequest>;
export type SinksGetResponseType = "r2" | "r2_data_catalog";
export declare const SinksGetResponseType: any;
export type SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export declare const SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNamingStrategy: any;
export interface SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNaming {
    /** The prefix to use in file name. i.e prefix-<uuid>.parquet */
    prefix?: string | null;
    /** Filename generation strategy. */
    strategy?: SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNamingStrategy | null;
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string | null;
}
export declare const SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNaming: S.Schema<SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNaming>;
export type SinksGetResponseConfigCloudflarePipelinesR2TablePublicPartitioning = SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning;
export declare const SinksGetResponseConfigCloudflarePipelinesR2TablePublicPartitioning: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning>;
export type SinksGetResponseConfigCloudflarePipelinesR2TablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export declare const SinksGetResponseConfigCloudflarePipelinesR2TablePublicRollingPolicy: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksGetResponseConfigCloudflarePipelinesR2TablePublic {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksGetResponseConfigCloudflarePipelinesR2TablePublicFileNaming | null;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string | null;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning | null;
    /** Subpath within the bucket to write to */
    path?: string | null;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export declare const SinksGetResponseConfigCloudflarePipelinesR2TablePublic: S.Schema<SinksGetResponseConfigCloudflarePipelinesR2TablePublic>;
export type SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export declare const SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublicRollingPolicy: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic {
    /** Cloudflare Account ID */
    accountId: string;
    /** The R2 Bucket that hosts this catalog */
    bucket: string;
    /** Table name */
    tableName: string;
    /** Table namespace */
    namespace?: string | null;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export declare const SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic: S.Schema<SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic>;
export type SinksGetResponseConfig = SinksGetResponseConfigCloudflarePipelinesR2TablePublic | SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic;
export declare const SinksGetResponseConfig: any;
export type SinksGetResponseFormatJsonType = "json";
export declare const SinksGetResponseFormatJsonType: any;
export type SinksGetResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksGetResponseFormatJsonDecimalEncoding: any;
export type SinksGetResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksGetResponseFormatJsonTimestampFormat: any;
export interface SinksGetResponseFormatJson {
    type: SinksGetResponseFormatJsonType;
    decimalEncoding?: SinksGetResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksGetResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const SinksGetResponseFormatJson: S.Schema<SinksGetResponseFormatJson>;
export type SinksGetResponseFormatParquetType = "parquet";
export declare const SinksGetResponseFormatParquetType: any;
export type SinksGetResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksGetResponseFormatParquetCompression: any;
export interface SinksGetResponseFormatParquet {
    type: SinksGetResponseFormatParquetType;
    compression?: SinksGetResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const SinksGetResponseFormatParquet: S.Schema<SinksGetResponseFormatParquet>;
export type SinksGetResponseFormat = SinksGetResponseFormatJson | SinksGetResponseFormatParquet;
export declare const SinksGetResponseFormat: any;
export type SinksGetResponseSchemaFieldsList = Array<unknown>;
export declare const SinksGetResponseSchemaFieldsList: S.Schema<SinksGetResponseSchemaFieldsList>;
export type SinksGetResponseSchemaFormatJsonType = "json";
export declare const SinksGetResponseSchemaFormatJsonType: any;
export type SinksGetResponseSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksGetResponseSchemaFormatJsonDecimalEncoding: any;
export type SinksGetResponseSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksGetResponseSchemaFormatJsonTimestampFormat: any;
export interface SinksGetResponseSchemaFormatJson {
    type: SinksGetResponseSchemaFormatJsonType;
    decimalEncoding?: SinksGetResponseSchemaFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksGetResponseSchemaFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const SinksGetResponseSchemaFormatJson: S.Schema<SinksGetResponseSchemaFormatJson>;
export type SinksGetResponseSchemaFormatParquetType = "parquet";
export declare const SinksGetResponseSchemaFormatParquetType: any;
export type SinksGetResponseSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksGetResponseSchemaFormatParquetCompression: any;
export interface SinksGetResponseSchemaFormatParquet {
    type: SinksGetResponseSchemaFormatParquetType;
    compression?: SinksGetResponseSchemaFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const SinksGetResponseSchemaFormatParquet: S.Schema<SinksGetResponseSchemaFormatParquet>;
export type SinksGetResponseSchemaFormat = SinksGetResponseSchemaFormatJson | SinksGetResponseSchemaFormatParquet;
export declare const SinksGetResponseSchemaFormat: any;
export interface SinksGetResponseSchema {
    fields?: SinksGetResponseSchemaFieldsList | null;
    format?: SinksGetResponseSchemaFormat | null;
    inferred?: boolean | null;
}
export declare const SinksGetResponseSchema: S.Schema<SinksGetResponseSchema>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSinkResponse {
    /** Indicates a unique identifier for this sink. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksGetResponseType;
    /** Defines the configuration of the R2 Sink. */
    config?: SinksGetResponseConfig | null;
    format?: SinksGetResponseFormat | null;
    schema?: SinksGetResponseSchema | null;
}
export declare const GetSinkResponse: S.Schema<GetSinkResponse>;
export interface GetStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the stream. */
    streamId: string;
}
export declare const GetStreamRequest: S.Schema<GetStreamRequest>;
export type StreamsGetResponseHttpCorsOriginsList = Array<string>;
export declare const StreamsGetResponseHttpCorsOriginsList: S.Schema<StreamsGetResponseHttpCorsOriginsList>;
export interface StreamsGetResponseHttpCors {
    origins?: StreamsGetResponseHttpCorsOriginsList | null;
}
export declare const StreamsGetResponseHttpCors: S.Schema<StreamsGetResponseHttpCors>;
export interface StreamsGetResponseHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsGetResponseHttpCors | null;
}
export declare const StreamsGetResponseHttp: S.Schema<StreamsGetResponseHttp>;
export type StreamsGetResponseWorkerBinding = StreamsCreateRequestWorkerBinding;
export declare const StreamsGetResponseWorkerBinding: S.Schema<StreamsCreateRequestWorkerBinding>;
export type StreamsGetResponseFormatJsonType = "json";
export declare const StreamsGetResponseFormatJsonType: any;
export type StreamsGetResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsGetResponseFormatJsonDecimalEncoding: any;
export type StreamsGetResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsGetResponseFormatJsonTimestampFormat: any;
export interface StreamsGetResponseFormatJson {
    type: StreamsGetResponseFormatJsonType;
    decimalEncoding?: StreamsGetResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsGetResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsGetResponseFormatJson: S.Schema<StreamsGetResponseFormatJson>;
export type StreamsGetResponseFormatParquetType = "parquet";
export declare const StreamsGetResponseFormatParquetType: any;
export type StreamsGetResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsGetResponseFormatParquetCompression: any;
export interface StreamsGetResponseFormatParquet {
    type: StreamsGetResponseFormatParquetType;
    compression?: StreamsGetResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsGetResponseFormatParquet: S.Schema<StreamsGetResponseFormatParquet>;
export type StreamsGetResponseFormat = StreamsGetResponseFormatJson | StreamsGetResponseFormatParquet;
export declare const StreamsGetResponseFormat: any;
export type StreamsGetResponseSchemaFieldsList = Array<unknown>;
export declare const StreamsGetResponseSchemaFieldsList: S.Schema<StreamsGetResponseSchemaFieldsList>;
export type StreamsGetResponseSchemaFormatJsonType = "json";
export declare const StreamsGetResponseSchemaFormatJsonType: any;
export type StreamsGetResponseSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsGetResponseSchemaFormatJsonDecimalEncoding: any;
export type StreamsGetResponseSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsGetResponseSchemaFormatJsonTimestampFormat: any;
export interface StreamsGetResponseSchemaFormatJson {
    type: StreamsGetResponseSchemaFormatJsonType;
    decimalEncoding?: StreamsGetResponseSchemaFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsGetResponseSchemaFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsGetResponseSchemaFormatJson: S.Schema<StreamsGetResponseSchemaFormatJson>;
export type StreamsGetResponseSchemaFormatParquetType = "parquet";
export declare const StreamsGetResponseSchemaFormatParquetType: any;
export type StreamsGetResponseSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsGetResponseSchemaFormatParquetCompression: any;
export interface StreamsGetResponseSchemaFormatParquet {
    type: StreamsGetResponseSchemaFormatParquetType;
    compression?: StreamsGetResponseSchemaFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsGetResponseSchemaFormatParquet: S.Schema<StreamsGetResponseSchemaFormatParquet>;
export type StreamsGetResponseSchemaFormat = StreamsGetResponseSchemaFormatJson | StreamsGetResponseSchemaFormatParquet;
export declare const StreamsGetResponseSchemaFormat: any;
export interface StreamsGetResponseSchema {
    fields?: StreamsGetResponseSchemaFieldsList | null;
    format?: StreamsGetResponseSchemaFormat | null;
    inferred?: boolean | null;
}
export declare const StreamsGetResponseSchema: S.Schema<StreamsGetResponseSchema>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStreamResponse {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsGetResponseHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    format?: StreamsGetResponseFormat | null;
    schema?: StreamsGetResponseSchema | null;
}
export declare const GetStreamResponse: S.Schema<GetStreamResponse>;
export interface GetV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the pipeline. */
    pipelineId: string;
}
export declare const GetV1PipelineRequest: S.Schema<GetV1PipelineRequest>;
export type GetV1ResponseTablesItemType = "stream" | "sink";
export declare const GetV1ResponseTablesItemType: any;
export interface GetV1ResponseTablesItem {
    /** Unique identifier for the connection (stream or sink). */
    id: string;
    /** Latest available version of the connection. */
    latest: number;
    /** Name of the connection. */
    name: string;
    /** Type of the connection. */
    type: GetV1ResponseTablesItemType;
    /** Current version of the connection used by this pipeline. */
    version: number;
}
export declare const GetV1ResponseTablesItem: S.Schema<GetV1ResponseTablesItem>;
export type GetV1ResponseTablesList = Array<GetV1ResponseTablesItem>;
export declare const GetV1ResponseTablesList: S.Schema<GetV1ResponseTablesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetV1PipelineResponse {
    /** Indicates a unique identifier for this pipeline. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Indicates the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
    /** Indicates the current status of the Pipeline. */
    status: string;
    /** List of streams and sinks used by this pipeline. */
    tables: GetV1ResponseTablesList;
    /** Indicates the reason for the failure of the Pipeline. */
    failureReason?: string | null;
}
export declare const GetV1PipelineResponse: S.Schema<GetV1PipelineResponse>;
export interface ListPipelinesRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies which page to retrieve. */
    page?: string;
    /** Specifies the number of pipelines per page. */
    perPage?: string;
    /** Specifies the prefix of pipeline name to search. */
    search?: string;
}
export declare const ListPipelinesRequest: S.Schema<ListPipelinesRequest>;
export type ListResponseResultsItemDestinationBatch = CreateResponseDestinationBatch;
export declare const ListResponseResultsItemDestinationBatch: S.Schema<CreateResponseDestinationBatch>;
export type ListResponseResultsItemDestinationCompressionType = "none" | "gzip" | "deflate";
export declare const ListResponseResultsItemDestinationCompressionType: any;
export interface ListResponseResultsItemDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: ListResponseResultsItemDestinationCompressionType;
}
export declare const ListResponseResultsItemDestinationCompression: S.Schema<ListResponseResultsItemDestinationCompression>;
export type ListResponseResultsItemDestinationFormat = "json";
export declare const ListResponseResultsItemDestinationFormat: any;
export type ListResponseResultsItemDestinationPath = CreateResponseDestinationPath;
export declare const ListResponseResultsItemDestinationPath: S.Schema<CreateResponseDestinationPath>;
export type ListResponseResultsItemDestinationType = "r2";
export declare const ListResponseResultsItemDestinationType: any;
export interface ListResponseResultsItemDestination {
    batch: CreateResponseDestinationBatch;
    compression: ListResponseResultsItemDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: ListResponseResultsItemDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: ListResponseResultsItemDestinationType;
}
export declare const ListResponseResultsItemDestination: S.Schema<ListResponseResultsItemDestination>;
export type ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export declare const ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat: any;
export type ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export declare const ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList: S.Schema<ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList>;
export interface ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export declare const ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors: S.Schema<ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors>;
export interface ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export declare const ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource: S.Schema<ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource>;
export type ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export declare const ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat: any;
export interface ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export declare const ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSource: S.Schema<ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSource>;
export type ListResponseResultsItemSourceItem = ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | ListResponseResultsItemSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export declare const ListResponseResultsItemSourceItem: any;
export type ListResponseResultsItemSourceList = Array<ListResponseResultsItemSourceItem>;
export declare const ListResponseResultsItemSourceList: S.Schema<ListResponseResultsItemSourceList>;
export interface ListResponseResultsItem {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: ListResponseResultsItemDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: ListResponseResultsItemSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export declare const ListResponseResultsItem: S.Schema<ListResponseResultsItem>;
export type ListResponseResultsList = Array<ListResponseResultsItem>;
export declare const ListResponseResultsList: S.Schema<ListResponseResultsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListPipelinesResponse {
    results: ListResponseResultsList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPipelinesResponse: S.Schema<ListPipelinesResponse>;
export interface ListSinksRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Filters sinks by name (case-insensitive substring). */
    name?: string;
    page?: number;
    perPage?: number;
    pipelineId?: string;
}
export declare const ListSinksRequest: S.Schema<ListSinksRequest>;
export type SinksListResultItemType = "r2" | "r2_data_catalog";
export declare const SinksListResultItemType: any;
export type SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNamingStrategy = "serial" | "uuid" | "uuid_v7" | "ulid";
export declare const SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNamingStrategy: any;
export interface SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNaming {
    /** The prefix to use in file name. i.e prefix-<uuid>.parquet */
    prefix?: string | null;
    /** Filename generation strategy. */
    strategy?: SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNamingStrategy | null;
    /** This will overwrite the default file suffix. i.e .parquet, use with caution */
    suffix?: string | null;
}
export declare const SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNaming: S.Schema<SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNaming>;
export type SinksListResultItemConfigCloudflarePipelinesR2TablePublicPartitioning = SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning;
export declare const SinksListResultItemConfigCloudflarePipelinesR2TablePublicPartitioning: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning>;
export type SinksListResultItemConfigCloudflarePipelinesR2TablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export declare const SinksListResultItemConfigCloudflarePipelinesR2TablePublicRollingPolicy: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy>;
export interface SinksListResultItemConfigCloudflarePipelinesR2TablePublic {
    /** Cloudflare Account ID for the bucket */
    accountId: string;
    /** R2 Bucket to write to */
    bucket: string;
    /** Controls filename prefix/suffix and strategy. */
    fileNaming?: SinksListResultItemConfigCloudflarePipelinesR2TablePublicFileNaming | null;
    /** Jurisdiction this bucket is hosted in */
    jurisdiction?: string | null;
    /** Data-layout partitioning for sinks. */
    partitioning?: SinksCreateResponseConfigCloudflarePipelinesR2TablePartitioning | null;
    /** Subpath within the bucket to write to */
    path?: string | null;
    /** Rolling policy for file sinks (when & why to close a file and open a new one). */
    rollingPolicy?: SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy | null;
}
export declare const SinksListResultItemConfigCloudflarePipelinesR2TablePublic: S.Schema<SinksListResultItemConfigCloudflarePipelinesR2TablePublic>;
export type SinksListResultItemConfigCloudflarePipelinesR2DataCatalogTablePublicRollingPolicy = SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy;
export declare const SinksListResultItemConfigCloudflarePipelinesR2DataCatalogTablePublicRollingPolicy: S.Schema<SinksCreateResponseConfigCloudflarePipelinesR2TableRollingPolicy>;
export type SinksListResultItemConfigCloudflarePipelinesR2DataCatalogTablePublic = SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic;
export declare const SinksListResultItemConfigCloudflarePipelinesR2DataCatalogTablePublic: S.Schema<SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic>;
export type SinksListResultItemConfig = SinksListResultItemConfigCloudflarePipelinesR2TablePublic | SinksGetResponseConfigCloudflarePipelinesR2DataCatalogTablePublic;
export declare const SinksListResultItemConfig: any;
export type SinksListResultItemFormatJsonType = "json";
export declare const SinksListResultItemFormatJsonType: any;
export type SinksListResultItemFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksListResultItemFormatJsonDecimalEncoding: any;
export type SinksListResultItemFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksListResultItemFormatJsonTimestampFormat: any;
export interface SinksListResultItemFormatJson {
    type: SinksListResultItemFormatJsonType;
    decimalEncoding?: SinksListResultItemFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksListResultItemFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const SinksListResultItemFormatJson: S.Schema<SinksListResultItemFormatJson>;
export type SinksListResultItemFormatParquetType = "parquet";
export declare const SinksListResultItemFormatParquetType: any;
export type SinksListResultItemFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksListResultItemFormatParquetCompression: any;
export interface SinksListResultItemFormatParquet {
    type: SinksListResultItemFormatParquetType;
    compression?: SinksListResultItemFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const SinksListResultItemFormatParquet: S.Schema<SinksListResultItemFormatParquet>;
export type SinksListResultItemFormat = SinksListResultItemFormatJson | SinksListResultItemFormatParquet;
export declare const SinksListResultItemFormat: any;
export type SinksListResultItemSchemaFieldsList = Array<unknown>;
export declare const SinksListResultItemSchemaFieldsList: S.Schema<SinksListResultItemSchemaFieldsList>;
export type SinksListResultItemSchemaFormatJsonType = "json";
export declare const SinksListResultItemSchemaFormatJsonType: any;
export type SinksListResultItemSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const SinksListResultItemSchemaFormatJsonDecimalEncoding: any;
export type SinksListResultItemSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const SinksListResultItemSchemaFormatJsonTimestampFormat: any;
export interface SinksListResultItemSchemaFormatJson {
    type: SinksListResultItemSchemaFormatJsonType;
    decimalEncoding?: SinksListResultItemSchemaFormatJsonDecimalEncoding | null;
    timestampFormat?: SinksListResultItemSchemaFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const SinksListResultItemSchemaFormatJson: S.Schema<SinksListResultItemSchemaFormatJson>;
export type SinksListResultItemSchemaFormatParquetType = "parquet";
export declare const SinksListResultItemSchemaFormatParquetType: any;
export type SinksListResultItemSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const SinksListResultItemSchemaFormatParquetCompression: any;
export interface SinksListResultItemSchemaFormatParquet {
    type: SinksListResultItemSchemaFormatParquetType;
    compression?: SinksListResultItemSchemaFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const SinksListResultItemSchemaFormatParquet: S.Schema<SinksListResultItemSchemaFormatParquet>;
export type SinksListResultItemSchemaFormat = SinksListResultItemSchemaFormatJson | SinksListResultItemSchemaFormatParquet;
export declare const SinksListResultItemSchemaFormat: any;
export interface SinksListResultItemSchema {
    fields?: SinksListResultItemSchemaFieldsList | null;
    format?: SinksListResultItemSchemaFormat | null;
    inferred?: boolean | null;
}
export declare const SinksListResultItemSchema: S.Schema<SinksListResultItemSchema>;
export interface SinksListResultItem {
    /** Indicates a unique identifier for this sink. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Defines the name of the Sink. */
    name: string;
    /** Specifies the type of sink. */
    type: SinksListResultItemType;
    /** Defines the configuration of the R2 Sink. */
    config?: SinksListResultItemConfig | null;
    format?: SinksListResultItemFormat | null;
    schema?: SinksListResultItemSchema | null;
}
export declare const SinksListResultItem: S.Schema<SinksListResultItem>;
export type SinksListResultList = Array<SinksListResultItem>;
export declare const SinksListResultList: S.Schema<SinksListResultList>;
export interface ListSinksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SinksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSinksResponse: S.Schema<ListSinksResponse>;
export interface ListStreamsRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Filters streams by name (case-insensitive substring). */
    name?: string;
    page?: number;
    perPage?: number;
    /** Specifies the public ID of the pipeline. */
    pipelineId?: string;
}
export declare const ListStreamsRequest: S.Schema<ListStreamsRequest>;
export type StreamsListResultItemHttpCorsOriginsList = Array<string>;
export declare const StreamsListResultItemHttpCorsOriginsList: S.Schema<StreamsListResultItemHttpCorsOriginsList>;
export interface StreamsListResultItemHttpCors {
    origins?: StreamsListResultItemHttpCorsOriginsList | null;
}
export declare const StreamsListResultItemHttpCors: S.Schema<StreamsListResultItemHttpCors>;
export interface StreamsListResultItemHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsListResultItemHttpCors | null;
}
export declare const StreamsListResultItemHttp: S.Schema<StreamsListResultItemHttp>;
export type StreamsListResultItemWorkerBinding = StreamsCreateRequestWorkerBinding;
export declare const StreamsListResultItemWorkerBinding: S.Schema<StreamsCreateRequestWorkerBinding>;
export type StreamsListResultItemFormatJsonType = "json";
export declare const StreamsListResultItemFormatJsonType: any;
export type StreamsListResultItemFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsListResultItemFormatJsonDecimalEncoding: any;
export type StreamsListResultItemFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsListResultItemFormatJsonTimestampFormat: any;
export interface StreamsListResultItemFormatJson {
    type: StreamsListResultItemFormatJsonType;
    decimalEncoding?: StreamsListResultItemFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsListResultItemFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsListResultItemFormatJson: S.Schema<StreamsListResultItemFormatJson>;
export type StreamsListResultItemFormatParquetType = "parquet";
export declare const StreamsListResultItemFormatParquetType: any;
export type StreamsListResultItemFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsListResultItemFormatParquetCompression: any;
export interface StreamsListResultItemFormatParquet {
    type: StreamsListResultItemFormatParquetType;
    compression?: StreamsListResultItemFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsListResultItemFormatParquet: S.Schema<StreamsListResultItemFormatParquet>;
export type StreamsListResultItemFormat = StreamsListResultItemFormatJson | StreamsListResultItemFormatParquet;
export declare const StreamsListResultItemFormat: any;
export type StreamsListResultItemSchemaFieldsList = Array<unknown>;
export declare const StreamsListResultItemSchemaFieldsList: S.Schema<StreamsListResultItemSchemaFieldsList>;
export type StreamsListResultItemSchemaFormatJsonType = "json";
export declare const StreamsListResultItemSchemaFormatJsonType: any;
export type StreamsListResultItemSchemaFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsListResultItemSchemaFormatJsonDecimalEncoding: any;
export type StreamsListResultItemSchemaFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsListResultItemSchemaFormatJsonTimestampFormat: any;
export interface StreamsListResultItemSchemaFormatJson {
    type: StreamsListResultItemSchemaFormatJsonType;
    decimalEncoding?: StreamsListResultItemSchemaFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsListResultItemSchemaFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsListResultItemSchemaFormatJson: S.Schema<StreamsListResultItemSchemaFormatJson>;
export type StreamsListResultItemSchemaFormatParquetType = "parquet";
export declare const StreamsListResultItemSchemaFormatParquetType: any;
export type StreamsListResultItemSchemaFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsListResultItemSchemaFormatParquetCompression: any;
export interface StreamsListResultItemSchemaFormatParquet {
    type: StreamsListResultItemSchemaFormatParquetType;
    compression?: StreamsListResultItemSchemaFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsListResultItemSchemaFormatParquet: S.Schema<StreamsListResultItemSchemaFormatParquet>;
export type StreamsListResultItemSchemaFormat = StreamsListResultItemSchemaFormatJson | StreamsListResultItemSchemaFormatParquet;
export declare const StreamsListResultItemSchemaFormat: any;
export interface StreamsListResultItemSchema {
    fields?: StreamsListResultItemSchemaFieldsList | null;
    format?: StreamsListResultItemSchemaFormat | null;
    inferred?: boolean | null;
}
export declare const StreamsListResultItemSchema: S.Schema<StreamsListResultItemSchema>;
export interface StreamsListResultItem {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsListResultItemHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    format?: StreamsListResultItemFormat | null;
    schema?: StreamsListResultItemSchema | null;
}
export declare const StreamsListResultItem: S.Schema<StreamsListResultItem>;
export type StreamsListResultList = Array<StreamsListResultItem>;
export declare const StreamsListResultList: S.Schema<StreamsListResultList>;
export interface ListStreamsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StreamsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListStreamsResponse: S.Schema<ListStreamsResponse>;
export interface ListV1PipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Filters pipelines by name (case-insensitive substring). */
    name?: string;
    page?: number;
    perPage?: number;
}
export declare const ListV1PipelineRequest: S.Schema<ListV1PipelineRequest>;
export interface ListV1ResultItem {
    /** Indicates a unique identifier for this pipeline. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    /** Indicates the name of the Pipeline. */
    name: string;
    /** Specifies SQL for the Pipeline processing flow. */
    sql: string;
    /** Indicates the current status of the Pipeline. */
    status: string;
}
export declare const ListV1ResultItem: S.Schema<ListV1ResultItem>;
export type ListV1ResultList = Array<ListV1ResultItem>;
export declare const ListV1ResultList: S.Schema<ListV1ResultList>;
export interface ListV1PipelineResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListV1ResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListV1PipelineResponse: S.Schema<ListV1PipelineResponse>;
export type StreamsUpdateRequestHttpCorsOriginsList = Array<string>;
export declare const StreamsUpdateRequestHttpCorsOriginsList: S.Schema<StreamsUpdateRequestHttpCorsOriginsList>;
export interface StreamsUpdateRequestHttpCors {
    origins?: StreamsUpdateRequestHttpCorsOriginsList;
}
export declare const StreamsUpdateRequestHttpCors: S.Schema<StreamsUpdateRequestHttpCors>;
export interface StreamsUpdateRequestHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsUpdateRequestHttpCors;
}
export declare const StreamsUpdateRequestHttp: S.Schema<StreamsUpdateRequestHttp>;
export type StreamsUpdateRequestWorkerBinding = StreamsCreateRequestWorkerBinding;
export declare const StreamsUpdateRequestWorkerBinding: S.Schema<StreamsCreateRequestWorkerBinding>;
export interface PatchStreamRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies the public ID of the stream. */
    streamId: string;
    http?: StreamsUpdateRequestHttp;
    workerBinding?: StreamsCreateRequestWorkerBinding;
}
export declare const PatchStreamRequest: S.Schema<PatchStreamRequest>;
export type StreamsUpdateResponseHttpCorsOriginsList = Array<string>;
export declare const StreamsUpdateResponseHttpCorsOriginsList: S.Schema<StreamsUpdateResponseHttpCorsOriginsList>;
export interface StreamsUpdateResponseHttpCors {
    origins?: StreamsUpdateResponseHttpCorsOriginsList | null;
}
export declare const StreamsUpdateResponseHttpCors: S.Schema<StreamsUpdateResponseHttpCors>;
export interface StreamsUpdateResponseHttp {
    /** Indicates that authentication is required for the HTTP endpoint. */
    authentication: boolean;
    /** Indicates that the HTTP endpoint is enabled. */
    enabled: boolean;
    /** Specifies the CORS options for the HTTP endpoint. */
    cors?: StreamsUpdateResponseHttpCors | null;
}
export declare const StreamsUpdateResponseHttp: S.Schema<StreamsUpdateResponseHttp>;
export type StreamsUpdateResponseWorkerBinding = StreamsCreateRequestWorkerBinding;
export declare const StreamsUpdateResponseWorkerBinding: S.Schema<StreamsCreateRequestWorkerBinding>;
export type StreamsUpdateResponseFormatJsonType = "json";
export declare const StreamsUpdateResponseFormatJsonType: any;
export type StreamsUpdateResponseFormatJsonDecimalEncoding = "number" | "string" | "bytes";
export declare const StreamsUpdateResponseFormatJsonDecimalEncoding: any;
export type StreamsUpdateResponseFormatJsonTimestampFormat = "rfc3339" | "unix_millis";
export declare const StreamsUpdateResponseFormatJsonTimestampFormat: any;
export interface StreamsUpdateResponseFormatJson {
    type: StreamsUpdateResponseFormatJsonType;
    decimalEncoding?: StreamsUpdateResponseFormatJsonDecimalEncoding | null;
    timestampFormat?: StreamsUpdateResponseFormatJsonTimestampFormat | null;
    unstructured?: boolean | null;
}
export declare const StreamsUpdateResponseFormatJson: S.Schema<StreamsUpdateResponseFormatJson>;
export type StreamsUpdateResponseFormatParquetType = "parquet";
export declare const StreamsUpdateResponseFormatParquetType: any;
export type StreamsUpdateResponseFormatParquetCompression = "uncompressed" | "snappy" | "gzip" | "zstd" | "lz4";
export declare const StreamsUpdateResponseFormatParquetCompression: any;
export interface StreamsUpdateResponseFormatParquet {
    type: StreamsUpdateResponseFormatParquetType;
    compression?: StreamsUpdateResponseFormatParquetCompression | null;
    rowGroupBytes?: number | null;
}
export declare const StreamsUpdateResponseFormatParquet: S.Schema<StreamsUpdateResponseFormatParquet>;
export type StreamsUpdateResponseFormat = StreamsUpdateResponseFormatJson | StreamsUpdateResponseFormatParquet;
export declare const StreamsUpdateResponseFormat: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchStreamResponse {
    /** Indicates a unique identifier for this stream. */
    id: string;
    createdAt: string;
    http: StreamsUpdateResponseHttp;
    modifiedAt: string;
    /** Indicates the name of the Stream. */
    name: string;
    /** Indicates the current version of this stream. */
    version: number;
    workerBinding: StreamsCreateRequestWorkerBinding;
    /** Indicates the endpoint URL of this stream. */
    endpoint?: string | null;
    format?: StreamsUpdateResponseFormat | null;
}
export declare const PatchStreamResponse: S.Schema<PatchStreamResponse>;
export type UpdateRequestDestinationBatch = CreateRequestDestinationBatch;
export declare const UpdateRequestDestinationBatch: S.Schema<CreateRequestDestinationBatch>;
export type UpdateRequestDestinationCompressionType = "none" | "gzip" | "deflate";
export declare const UpdateRequestDestinationCompressionType: any;
export interface UpdateRequestDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type?: UpdateRequestDestinationCompressionType | (string & {});
}
export declare const UpdateRequestDestinationCompression: S.Schema<UpdateRequestDestinationCompression>;
export type UpdateRequestDestinationFormat = "json";
export declare const UpdateRequestDestinationFormat: any;
export type UpdateRequestDestinationPath = CreateRequestDestinationPath;
export declare const UpdateRequestDestinationPath: S.Schema<CreateRequestDestinationPath>;
export type UpdateRequestDestinationType = "r2";
export declare const UpdateRequestDestinationType: any;
export type UpdateRequestDestinationCredentials = CreateRequestDestinationCredentials;
export declare const UpdateRequestDestinationCredentials: S.Schema<CreateRequestDestinationCredentials>;
export interface UpdateRequestDestination {
    batch: CreateRequestDestinationBatch;
    compression: UpdateRequestDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: UpdateRequestDestinationFormat | (string & {});
    path: CreateRequestDestinationPath;
    /** Specifies the type of destination. */
    type: UpdateRequestDestinationType | (string & {});
    credentials?: CreateRequestDestinationCredentials;
}
export declare const UpdateRequestDestination: S.Schema<UpdateRequestDestination>;
export type UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export declare const UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat: any;
export type UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export declare const UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList: S.Schema<UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList>;
export interface UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList;
}
export declare const UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors: S.Schema<UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors>;
export interface UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean;
    cors?: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors;
}
export declare const UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource: S.Schema<UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource>;
export type UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export declare const UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat: any;
export interface UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export declare const UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource: S.Schema<UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource>;
export type UpdateRequestSourceItem = UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | UpdateRequestSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export declare const UpdateRequestSourceItem: any;
export type UpdateRequestSourceList = Array<UpdateRequestSourceItem>;
export declare const UpdateRequestSourceList: S.Schema<UpdateRequestSourceList>;
export interface UpdatePipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Defines the name of the pipeline. */
    pipelineName: string;
    destination: UpdateRequestDestination;
    /** Defines the name of the pipeline. */
    name: string;
    source: UpdateRequestSourceList;
}
export declare const UpdatePipelineRequest: S.Schema<UpdatePipelineRequest>;
export type UpdateResponseDestinationBatch = CreateResponseDestinationBatch;
export declare const UpdateResponseDestinationBatch: S.Schema<CreateResponseDestinationBatch>;
export type UpdateResponseDestinationCompressionType = "none" | "gzip" | "deflate";
export declare const UpdateResponseDestinationCompressionType: any;
export interface UpdateResponseDestinationCompression {
    /** Specifies the desired compression algorithm and format. */
    type: UpdateResponseDestinationCompressionType;
}
export declare const UpdateResponseDestinationCompression: S.Schema<UpdateResponseDestinationCompression>;
export type UpdateResponseDestinationFormat = "json";
export declare const UpdateResponseDestinationFormat: any;
export type UpdateResponseDestinationPath = CreateResponseDestinationPath;
export declare const UpdateResponseDestinationPath: S.Schema<CreateResponseDestinationPath>;
export type UpdateResponseDestinationType = "r2";
export declare const UpdateResponseDestinationType: any;
export interface UpdateResponseDestination {
    batch: CreateResponseDestinationBatch;
    compression: UpdateResponseDestinationCompression;
    /** Specifies the format of data to deliver. */
    format: UpdateResponseDestinationFormat;
    path: CreateResponseDestinationPath;
    /** Specifies the type of destination. */
    type: UpdateResponseDestinationType;
}
export declare const UpdateResponseDestination: S.Schema<UpdateResponseDestination>;
export type UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat = "json";
export declare const UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat: any;
export type UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList = Array<string>;
export declare const UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList: S.Schema<UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList>;
export interface UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors {
    /** Specifies allowed origins to allow Cross Origin HTTP Requests. */
    origins?: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCorsOriginsList | null;
}
export declare const UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors: S.Schema<UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors>;
export interface UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource {
    /** Specifies the format of source data. */
    format: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceFormat;
    type: string;
    /** Specifies whether authentication is required to send to this pipeline via HTTP. */
    authentication?: boolean | null;
    cors?: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSourceCors | null;
}
export declare const UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource: S.Schema<UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource>;
export type UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat = "json";
export declare const UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat: any;
export interface UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource {
    /** Specifies the format of source data. */
    format: UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSourceFormat;
    type: string;
}
export declare const UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource: S.Schema<UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource>;
export type UpdateResponseSourceItem = UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesHTTPSource | UpdateResponseSourceItemCloudflarePipelinesWorkersPipelinesBindingSource;
export declare const UpdateResponseSourceItem: any;
export type UpdateResponseSourceList = Array<UpdateResponseSourceItem>;
export declare const UpdateResponseSourceList: S.Schema<UpdateResponseSourceList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePipelineResponse {
    /** Specifies the pipeline identifier. */
    id: string;
    destination: UpdateResponseDestination;
    /** Indicates the endpoint URL to send traffic. */
    endpoint: string;
    /** Defines the name of the pipeline. */
    name: string;
    source: UpdateResponseSourceList;
    /** Indicates the version number of last saved configuration. */
    version: number;
}
export declare const UpdatePipelineResponse: S.Schema<UpdatePipelineResponse>;
export interface ValidateSqlPipelineRequest {
    /** Specifies the public ID of the account. */
    accountId: string;
    /** Specifies SQL to validate. */
    sql: string;
}
export declare const ValidateSqlPipelineRequest: S.Schema<ValidateSqlPipelineRequest>;
export interface ValidateSqlResponseTablesValue {
    id: string;
    name: string;
    type: string;
    version: number;
}
export declare const ValidateSqlResponseTablesValue: S.Schema<ValidateSqlResponseTablesValue>;
export type ValidateSqlResponseTablesMap = {
    [key: string]: ValidateSqlResponseTablesValue | undefined;
};
export declare const ValidateSqlResponseTablesMap: S.Schema<ValidateSqlResponseTablesMap>;
export interface ValidateSqlResponseGraphEdgesItem {
    destId: number;
    edgeType: string;
    keyType: string;
    srcId: number;
    valueType: string;
}
export declare const ValidateSqlResponseGraphEdgesItem: S.Schema<ValidateSqlResponseGraphEdgesItem>;
export type ValidateSqlResponseGraphEdgesList = Array<ValidateSqlResponseGraphEdgesItem>;
export declare const ValidateSqlResponseGraphEdgesList: S.Schema<ValidateSqlResponseGraphEdgesList>;
export interface ValidateSqlResponseGraphNodesItem {
    description: string;
    nodeId: number;
    operator: string;
    parallelism: number;
}
export declare const ValidateSqlResponseGraphNodesItem: S.Schema<ValidateSqlResponseGraphNodesItem>;
export type ValidateSqlResponseGraphNodesList = Array<ValidateSqlResponseGraphNodesItem>;
export declare const ValidateSqlResponseGraphNodesList: S.Schema<ValidateSqlResponseGraphNodesList>;
export interface ValidateSqlResponseGraph {
    edges: ValidateSqlResponseGraphEdgesList;
    nodes: ValidateSqlResponseGraphNodesList;
}
export declare const ValidateSqlResponseGraph: S.Schema<ValidateSqlResponseGraph>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidateSqlPipelineResponse {
    /** Indicates tables involved in the processing. */
    tables: ValidateSqlResponseTablesMap;
    graph?: ValidateSqlResponseGraph | null;
}
export declare const ValidateSqlPipelineResponse: S.Schema<ValidateSqlPipelineResponse>;
export type CreatePipelineError = CloudflareOpError;
/** [DEPRECATED] Create a new pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const createPipeline: API.OperationMethod<CreatePipelineRequest, CreatePipelineResponse, CreatePipelineError, CloudflareOpContext>;
export type CreateSinkError = SinkAuthFailed | InvalidSinkConfig | SinkAlreadyExists | CloudflareOpError;
/** Create a new Sink. */
export declare const createSink: API.OperationMethod<CreateSinkRequest, CreateSinkResponse, CreateSinkError, CloudflareOpContext>;
export type CreateStreamError = InvalidStreamName | StreamAlreadyExists | CloudflareOpError;
/** Create a new Stream. */
export declare const createStream: API.OperationMethod<CreateStreamRequest, CreateStreamResponse, CreateStreamError, CloudflareOpContext>;
export type CreateV1PipelineError = TableNotFound | InvalidSql | PipelineAlreadyExists | CloudflareOpError;
/** Create a new Pipeline. */
export declare const createV1Pipeline: API.OperationMethod<CreateV1PipelineRequest, CreateV1PipelineResponse, CreateV1PipelineError, CloudflareOpContext>;
export type DeletePipelineError = PipelineNotExists | CloudflareOpError;
/** [DEPRECATED] Delete a pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const deletePipeline: API.OperationMethod<DeletePipelineRequest, DeletePipelineResponse, DeletePipelineError, CloudflareOpContext>;
export type DeleteSinkError = SinkNotFound | InvalidSinkId | SinkInUse | CloudflareOpError;
/** Delete Pipeline in Account. */
export declare const deleteSink: API.OperationMethod<DeleteSinkRequest, DeleteSinkResponse, DeleteSinkError, CloudflareOpContext>;
export type DeleteStreamError = PipelineNotExists | StreamNotFound | InvalidStreamId | StreamInUse | CloudflareOpError;
/** Delete Stream in Account. */
export declare const deleteStream: API.OperationMethod<DeleteStreamRequest, DeleteStreamResponse, DeleteStreamError, CloudflareOpContext>;
export type DeleteV1PipelineError = PipelineNotExists | CloudflareOpError;
/** Delete Pipeline in Account. */
export declare const deleteV1Pipeline: API.OperationMethod<DeleteV1PipelineRequest, DeleteV1PipelineResponse, DeleteV1PipelineError, CloudflareOpContext>;
export type GetPipelineError = PipelineNotExists | CloudflareOpError;
/** [DEPRECATED] Get configuration of a pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const getPipeline: API.OperationMethod<GetPipelineRequest, GetPipelineResponse, GetPipelineError, CloudflareOpContext>;
export type GetSinkError = SinkNotFound | InvalidSinkId | CloudflareOpError;
/** Get Sink Details. */
export declare const getSink: API.OperationMethod<GetSinkRequest, GetSinkResponse, GetSinkError, CloudflareOpContext>;
export type GetStreamError = StreamNotFound | InvalidStreamId | CloudflareOpError;
/** Get Stream Details. */
export declare const getStream: API.OperationMethod<GetStreamRequest, GetStreamResponse, GetStreamError, CloudflareOpContext>;
export type GetV1PipelineError = PipelineNotExists | CloudflareOpError;
/** Get Pipelines Details. */
export declare const getV1Pipeline: API.OperationMethod<GetV1PipelineRequest, GetV1PipelineResponse, GetV1PipelineError, CloudflareOpContext>;
export type ListPipelinesError = CloudflareOpError;
/** [DEPRECATED] List, filter, and paginate pipelines in an account. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesRequest, ListPipelinesResponse, ListPipelinesError, CloudflareOpContext, ListResponseResultsItem>;
export type ListSinksError = CloudflareOpError;
/** List/Filter Sinks in Account. */
export declare const listSinks: API.PaginatedOperationMethod<ListSinksRequest, ListSinksResponse, ListSinksError, CloudflareOpContext, SinksListResultItem>;
export type ListStreamsError = CloudflareOpError;
/** List/Filter Streams in Account. */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest, ListStreamsResponse, ListStreamsError, CloudflareOpContext, StreamsListResultItem>;
export type ListV1PipelineError = CloudflareOpError;
/** List/Filter Pipelines in Account. */
export declare const listV1Pipeline: API.PaginatedOperationMethod<ListV1PipelineRequest, ListV1PipelineResponse, ListV1PipelineError, CloudflareOpContext, ListV1ResultItem>;
export type PatchStreamError = StreamNotFound | CloudflareOpError;
/** Update a Stream. */
export declare const patchStream: API.OperationMethod<PatchStreamRequest, PatchStreamResponse, PatchStreamError, CloudflareOpContext>;
export type UpdatePipelineError = PipelineNotExists | CloudflareOpError;
/** [DEPRECATED] Update an existing pipeline. Use the new /pipelines/v1/pipelines endpoint instead. */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineRequest, UpdatePipelineResponse, UpdatePipelineError, CloudflareOpContext>;
export type ValidateSqlPipelineError = TableNotFound | InvalidSql | CloudflareOpError;
/** Validate Arroyo SQL. */
export declare const validateSqlPipeline: API.OperationMethod<ValidateSqlPipelineRequest, ValidateSqlPipelineResponse, ValidateSqlPipelineError, CloudflareOpContext>;
//# sourceMappingURL=pipelines.d.ts.map