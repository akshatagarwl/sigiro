import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** IP prefix in CIDR notation to bind. */
    cidr: string;
    /** The ID of the parent IP prefix that contains the CIDR. */
    prefixId: string;
    /** Region key from managed regions (e.g., "us", "eu"). */
    regionKey: string;
}
export declare const CreateRegionalServicePrefixBindingRequest: S.Schema<CreateRegionalServicePrefixBindingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRegionalServicePrefixBindingResponse {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export declare const CreateRegionalServicePrefixBindingResponse: S.Schema<CreateRegionalServicePrefixBindingResponse>;
export interface DeleteRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Unique identifier for the prefix binding. */
    bindingId: string;
}
export declare const DeleteRegionalServicePrefixBindingRequest: S.Schema<DeleteRegionalServicePrefixBindingRequest>;
export interface DeleteRegionalServicePrefixBindingResponse {
}
export declare const DeleteRegionalServicePrefixBindingResponse: S.Schema<DeleteRegionalServicePrefixBindingResponse>;
export interface GetRegionRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** UUID of the region (custom or managed) or region_key of a managed region. */
    regionId: string;
}
export declare const GetRegionRequest: S.Schema<GetRegionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionResponse {
    id: string;
    createdOn: string;
    modifiedOn: string;
    name: string;
    regionKey: string;
    version: number;
    versionCreatedOn: string;
}
export declare const GetRegionResponse: S.Schema<GetRegionResponse>;
export interface GetRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Unique identifier for the prefix binding. */
    bindingId: string;
}
export declare const GetRegionalServicePrefixBindingRequest: S.Schema<GetRegionalServicePrefixBindingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionalServicePrefixBindingResponse {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export declare const GetRegionalServicePrefixBindingResponse: S.Schema<GetRegionalServicePrefixBindingResponse>;
export interface ListRegionalServicePrefixBindingsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Opaque token for cursor-based pagination. Omit for the first page. Pass the value from a previous response to fetch the next page. */
    cursor?: string;
    perPage?: number;
}
export declare const ListRegionalServicePrefixBindingsRequest: S.Schema<ListRegionalServicePrefixBindingsRequest>;
export interface RegionalServicesPrefixBindingsListResultItem {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export declare const RegionalServicesPrefixBindingsListResultItem: S.Schema<RegionalServicesPrefixBindingsListResultItem>;
export type RegionalServicesPrefixBindingsListResultList = Array<RegionalServicesPrefixBindingsListResultItem>;
export declare const RegionalServicesPrefixBindingsListResultList: S.Schema<RegionalServicesPrefixBindingsListResultList>;
export interface ListRegionalServicePrefixBindingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RegionalServicesPrefixBindingsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRegionalServicePrefixBindingsResponse: S.Schema<ListRegionalServicePrefixBindingsResponse>;
export type RegionsListRequestType = "managed" | "custom";
export declare const RegionsListRequestType: any;
export interface ListRegionsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Opaque token for cursor-based pagination. Omit for the first page. Pass the value from a previous response to fetch the next page. */
    cursor?: string;
    perPage?: number;
    /** Filter regions by type. Omit to return all regions. */
    type?: RegionsListRequestType | (string & {});
}
export declare const ListRegionsRequest: S.Schema<ListRegionsRequest>;
export interface RegionsListResultItem {
    id: string;
    createdOn: string;
    modifiedOn: string;
    name: string;
    regionKey: string;
    version: number;
    versionCreatedOn: string;
}
export declare const RegionsListResultItem: S.Schema<RegionsListResultItem>;
export type RegionsListResultList = Array<RegionsListResultItem>;
export declare const RegionsListResultList: S.Schema<RegionsListResultList>;
export interface ListRegionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RegionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRegionsResponse: S.Schema<ListRegionsResponse>;
export interface PatchRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Unique identifier for the prefix binding. */
    bindingId: string;
    /** New region key to assign (e.g., "us", "eu", "cfcanary"). */
    regionKey: string;
}
export declare const PatchRegionalServicePrefixBindingRequest: S.Schema<PatchRegionalServicePrefixBindingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRegionalServicePrefixBindingResponse {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export declare const PatchRegionalServicePrefixBindingResponse: S.Schema<PatchRegionalServicePrefixBindingResponse>;
export type CreateRegionalServicePrefixBindingError = CloudflareOpError;
/** Create a DLS prefix binding */
export declare const createRegionalServicePrefixBinding: API.OperationMethod<CreateRegionalServicePrefixBindingRequest, CreateRegionalServicePrefixBindingResponse, CreateRegionalServicePrefixBindingError, CloudflareOpContext>;
export type DeleteRegionalServicePrefixBindingError = CloudflareOpError;
/** Delete a DLS prefix binding */
export declare const deleteRegionalServicePrefixBinding: API.OperationMethod<DeleteRegionalServicePrefixBindingRequest, DeleteRegionalServicePrefixBindingResponse, DeleteRegionalServicePrefixBindingError, CloudflareOpContext>;
export type GetRegionError = CloudflareOpError;
/** Get a DLS region */
export declare const getRegion: API.OperationMethod<GetRegionRequest, GetRegionResponse, GetRegionError, CloudflareOpContext>;
export type GetRegionalServicePrefixBindingError = CloudflareOpError;
/** Get a DLS prefix binding */
export declare const getRegionalServicePrefixBinding: API.OperationMethod<GetRegionalServicePrefixBindingRequest, GetRegionalServicePrefixBindingResponse, GetRegionalServicePrefixBindingError, CloudflareOpContext>;
export type ListRegionalServicePrefixBindingsError = CloudflareOpError;
/** List DLS prefix bindings for an account */
export declare const listRegionalServicePrefixBindings: API.PaginatedOperationMethod<ListRegionalServicePrefixBindingsRequest, ListRegionalServicePrefixBindingsResponse, ListRegionalServicePrefixBindingsError, CloudflareOpContext, RegionalServicesPrefixBindingsListResultItem>;
export type ListRegionsError = CloudflareOpError;
/** List DLS regions for an account */
export declare const listRegions: API.PaginatedOperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, CloudflareOpContext, RegionsListResultItem>;
export type PatchRegionalServicePrefixBindingError = CloudflareOpError;
/** Update a DLS prefix binding */
export declare const patchRegionalServicePrefixBinding: API.OperationMethod<PatchRegionalServicePrefixBindingRequest, PatchRegionalServicePrefixBindingResponse, PatchRegionalServicePrefixBindingError, CloudflareOpContext>;
//# sourceMappingURL=dls.d.ts.map