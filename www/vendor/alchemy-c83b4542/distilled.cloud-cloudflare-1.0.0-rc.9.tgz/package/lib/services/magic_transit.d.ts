import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AppNotFound_base: S.Class<AppNotFound, S.TaggedStruct<"AppNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AppNotFound extends /*@__PURE__*/ AppNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const GreTunnelNotFound_base: S.Class<GreTunnelNotFound, S.TaggedStruct<"GreTunnelNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class GreTunnelNotFound extends /*@__PURE__*/ GreTunnelNotFound_base {
}
declare const IpsecTunnelNotFound_base: S.Class<IpsecTunnelNotFound, S.TaggedStruct<"IpsecTunnelNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IpsecTunnelNotFound extends /*@__PURE__*/ IpsecTunnelNotFound_base {
}
declare const MagicTransitNotOnboarded_base: S.Class<MagicTransitNotOnboarded, S.TaggedStruct<"MagicTransitNotOnboarded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MagicTransitNotOnboarded extends /*@__PURE__*/ MagicTransitNotOnboarded_base {
}
declare const MagicWanUnauthorized_base: S.Class<MagicWanUnauthorized, S.TaggedStruct<"MagicWanUnauthorized", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MagicWanUnauthorized extends /*@__PURE__*/ MagicWanUnauthorized_base {
}
declare const RouteNotFound_base: S.Class<RouteNotFound, S.TaggedStruct<"RouteNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RouteNotFound extends /*@__PURE__*/ RouteNotFound_base {
}
declare const SiteAclNotFound_base: S.Class<SiteAclNotFound, S.TaggedStruct<"SiteAclNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SiteAclNotFound extends /*@__PURE__*/ SiteAclNotFound_base {
}
declare const SiteLanNotFound_base: S.Class<SiteLanNotFound, S.TaggedStruct<"SiteLanNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SiteLanNotFound extends /*@__PURE__*/ SiteLanNotFound_base {
}
declare const SiteNotFound_base: S.Class<SiteNotFound, S.TaggedStruct<"SiteNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SiteNotFound extends /*@__PURE__*/ SiteNotFound_base {
}
declare const SiteWanNotFound_base: S.Class<SiteWanNotFound, S.TaggedStruct<"SiteWanNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SiteWanNotFound extends /*@__PURE__*/ SiteWanNotFound_base {
}
export interface BulkPutCfInterconnectsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const BulkPutCfInterconnectsRequest: S.Schema<BulkPutCfInterconnectsRequest>;
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre {
    /** The IP address assigned to the Cloudflare side of the GRE tunnel created as part of the Interconnect. */
    cloudflareEndpoint?: string | null;
}
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre>;
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckRate = "low" | "mid" | "high";
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckRate: any;
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget {
    /** The effective health check target. If 'saved' is empty, then this field will be populated with the calculated default value on GET requests. Ignored in POST, PUT, and PATCH requests. */
    effective?: string | null;
    /** The saved health check target. Setting the value to the empty string indicates that the calculated default value will be used. */
    saved?: string | null;
}
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTarget: any;
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckType = "reply" | "request";
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckType: any;
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheck {
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckType | null;
}
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheck: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheck>;
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItem {
    /** Identifier */
    id?: string | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the interconnect. */
    description?: string | null;
    /** The configuration specific to GRE interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null;
    healthCheck?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheck | null;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress?: string | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null;
}
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsItem: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItem>;
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsList = Array<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItem>;
export declare const CfInterconnectsBulkUpdateResponseModifiedInterconnectsList: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutCfInterconnectsResponse {
    modified?: boolean | null;
    modifiedInterconnects?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsList | null;
}
export declare const BulkPutCfInterconnectsResponse: S.Schema<BulkPutCfInterconnectsResponse>;
export interface BulkPutGreTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const BulkPutGreTunnelsRequest: S.Schema<BulkPutGreTunnelsRequest>;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpExtraPrefixesList: S.Schema<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpExtraPrefixesList>;
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgp: S.Schema<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgp>;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatusState: any;
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatus {
    state: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatus: S.Schema<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatus>;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckDirection: any;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckRate: any;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTarget: any;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckType = "reply" | "request";
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckType: any;
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckType | null;
}
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheck: S.Schema<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheck>;
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgp | null;
    bgpStatus?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the GRE tunnel. */
    description?: string | null;
    healthCheck?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null;
}
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsItem: S.Schema<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItem>;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsList = Array<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItem>;
export declare const GreTunnelsBulkUpdateResponseModifiedGreTunnelsList: S.Schema<GreTunnelsBulkUpdateResponseModifiedGreTunnelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutGreTunnelsResponse {
    modified?: boolean | null;
    modifiedGreTunnels?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsList | null;
}
export declare const BulkPutGreTunnelsResponse: S.Schema<BulkPutGreTunnelsResponse>;
export interface BulkPutIpsecTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const BulkPutIpsecTunnelsRequest: S.Schema<BulkPutIpsecTunnelsRequest>;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpExtraPrefixesList: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpExtraPrefixesList>;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgp: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgp>;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatusState: any;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatus {
    state: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatus: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatus>;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities {
    /** A custom IKE ID of type FQDN that may be used to identity the IPsec tunnel. The */
    fqdnId?: string | null;
}
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities>;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckDirection: any;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckRate: any;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTarget: any;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckType: any;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckType | null;
}
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheck: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheck>;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata {
    /** The date and time the tunnel was last modified. */
    lastGeneratedOn?: string | null;
}
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgp | null;
    bgpStatus?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null;
    healthCheck?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null;
}
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItem: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItem>;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsList = Array<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItem>;
export declare const IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsList: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutIpsecTunnelsResponse {
    modified?: boolean | null;
    modifiedIpsecTunnels?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsList | null;
}
export declare const BulkPutIpsecTunnelsResponse: S.Schema<BulkPutIpsecTunnelsResponse>;
export type RoutesBulkUpdateRequestRoutesItemScopeColoNamesList = Array<string>;
export declare const RoutesBulkUpdateRequestRoutesItemScopeColoNamesList: S.Schema<RoutesBulkUpdateRequestRoutesItemScopeColoNamesList>;
export type RoutesBulkUpdateRequestRoutesItemScopeColoRegionsList = Array<string>;
export declare const RoutesBulkUpdateRequestRoutesItemScopeColoRegionsList: S.Schema<RoutesBulkUpdateRequestRoutesItemScopeColoRegionsList>;
export interface RoutesBulkUpdateRequestRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesBulkUpdateRequestRoutesItemScopeColoNamesList;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesBulkUpdateRequestRoutesItemScopeColoRegionsList;
}
export declare const RoutesBulkUpdateRequestRoutesItemScope: S.Schema<RoutesBulkUpdateRequestRoutesItemScope>;
export interface RoutesBulkUpdateRequestRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** An optional human provided description of the static route. */
    description?: string;
    /** Used only for ECMP routes. */
    scope?: RoutesBulkUpdateRequestRoutesItemScope;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number;
}
export declare const RoutesBulkUpdateRequestRoutesItem: S.Schema<RoutesBulkUpdateRequestRoutesItem>;
export type RoutesBulkUpdateRequestRoutesList = Array<RoutesBulkUpdateRequestRoutesItem>;
export declare const RoutesBulkUpdateRequestRoutesList: S.Schema<RoutesBulkUpdateRequestRoutesList>;
export interface BulkPutRoutesRequest {
    /** Identifier */
    accountId: string;
    routes: RoutesBulkUpdateRequestRoutesList;
}
export declare const BulkPutRoutesRequest: S.Schema<BulkPutRoutesRequest>;
export type RoutesBulkUpdateResponseModifiedRoutesItemScopeColoNamesList = Array<string>;
export declare const RoutesBulkUpdateResponseModifiedRoutesItemScopeColoNamesList: S.Schema<RoutesBulkUpdateResponseModifiedRoutesItemScopeColoNamesList>;
export type RoutesBulkUpdateResponseModifiedRoutesItemScopeColoRegionsList = Array<string>;
export declare const RoutesBulkUpdateResponseModifiedRoutesItemScopeColoRegionsList: S.Schema<RoutesBulkUpdateResponseModifiedRoutesItemScopeColoRegionsList>;
export interface RoutesBulkUpdateResponseModifiedRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesBulkUpdateResponseModifiedRoutesItemScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesBulkUpdateResponseModifiedRoutesItemScopeColoRegionsList | null;
}
export declare const RoutesBulkUpdateResponseModifiedRoutesItemScope: S.Schema<RoutesBulkUpdateResponseModifiedRoutesItemScope>;
export interface RoutesBulkUpdateResponseModifiedRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesBulkUpdateResponseModifiedRoutesItemScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const RoutesBulkUpdateResponseModifiedRoutesItem: S.Schema<RoutesBulkUpdateResponseModifiedRoutesItem>;
export type RoutesBulkUpdateResponseModifiedRoutesList = Array<RoutesBulkUpdateResponseModifiedRoutesItem>;
export declare const RoutesBulkUpdateResponseModifiedRoutesList: S.Schema<RoutesBulkUpdateResponseModifiedRoutesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutRoutesResponse {
    modified?: boolean | null;
    modifiedRoutes?: RoutesBulkUpdateResponseModifiedRoutesList | null;
}
export declare const BulkPutRoutesResponse: S.Schema<BulkPutRoutesResponse>;
export type AppsCreateRequestHostnamesList = Array<string>;
export declare const AppsCreateRequestHostnamesList: S.Schema<AppsCreateRequestHostnamesList>;
export type AppsCreateRequestIpSubnetsList = Array<string>;
export declare const AppsCreateRequestIpSubnetsList: S.Schema<AppsCreateRequestIpSubnetsList>;
export type AppsCreateRequestSourceSubnetsList = Array<string>;
export declare const AppsCreateRequestSourceSubnetsList: S.Schema<AppsCreateRequestSourceSubnetsList>;
export interface CreateAppRequest {
    /** Identifier */
    accountId: string;
    /** Display name for the app. */
    name: string;
    /** Category of the app. */
    type: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsCreateRequestHostnamesList;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsCreateRequestIpSubnetsList;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsCreateRequestSourceSubnetsList;
}
export declare const CreateAppRequest: S.Schema<CreateAppRequest>;
export type AppsCreateResponseHostnamesList = Array<string>;
export declare const AppsCreateResponseHostnamesList: S.Schema<AppsCreateResponseHostnamesList>;
export type AppsCreateResponseIpSubnetsList = Array<string>;
export declare const AppsCreateResponseIpSubnetsList: S.Schema<AppsCreateResponseIpSubnetsList>;
export type AppsCreateResponseSourceSubnetsList = Array<string>;
export declare const AppsCreateResponseSourceSubnetsList: S.Schema<AppsCreateResponseSourceSubnetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsCreateResponseHostnamesList | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsCreateResponseIpSubnetsList | null;
    /** Display name for the app. */
    name?: string | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsCreateResponseSourceSubnetsList | null;
    /** Category of the app. */
    type?: string | null;
}
export declare const CreateAppResponse: S.Schema<CreateAppResponse>;
export interface Cf1SitesCreateRequestBodyItemLocation {
    /** Latitude of the CF1 Site. */
    lat?: number;
    /** Longitude of the CF1 Site. */
    long?: number;
    /** Name of nearest town, city, or village. */
    name?: string;
}
export declare const Cf1SitesCreateRequestBodyItemLocation: S.Schema<Cf1SitesCreateRequestBodyItemLocation>;
export interface Cf1SitesCreateRequestBodyItem {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string;
    createdOn?: string;
    /** A human-provided description of the CF1 Site. */
    description?: string;
    location?: Cf1SitesCreateRequestBodyItemLocation;
    modifiedOn?: string;
}
export declare const Cf1SitesCreateRequestBodyItem: S.Schema<Cf1SitesCreateRequestBodyItem>;
export type Cf1SitesCreateRequestBodyList = Array<Cf1SitesCreateRequestBodyItem>;
export declare const Cf1SitesCreateRequestBodyList: S.Schema<Cf1SitesCreateRequestBodyList>;
export interface CreateCf1SiteRequest {
    /** Identifier */
    accountId: string;
    body: Cf1SitesCreateRequestBodyList;
}
export declare const CreateCf1SiteRequest: S.Schema<CreateCf1SiteRequest>;
export interface Cf1SitesCreateResultItemLocation {
    /** Latitude of the CF1 Site. */
    lat?: number | null;
    /** Longitude of the CF1 Site. */
    long?: number | null;
    /** Name of nearest town, city, or village. */
    name?: string | null;
}
export declare const Cf1SitesCreateResultItemLocation: S.Schema<Cf1SitesCreateResultItemLocation>;
export interface Cf1SitesCreateResultItem {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null;
    createdOn?: string | null;
    /** A human-provided description of the CF1 Site. */
    description?: string | null;
    location?: Cf1SitesCreateResultItemLocation | null;
    modifiedOn?: string | null;
}
export declare const Cf1SitesCreateResultItem: S.Schema<Cf1SitesCreateResultItem>;
export type Cf1SitesCreateResultList = Array<Cf1SitesCreateResultItem>;
export declare const Cf1SitesCreateResultList: S.Schema<Cf1SitesCreateResultList>;
export interface CreateCf1SiteResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateCf1SiteResponse: S.Schema<CreateCf1SiteResponse>;
export type Cf1SitesRampsCreateRequestBodyItemType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export declare const Cf1SitesRampsCreateRequestBodyItemType: any;
export interface Cf1SitesRampsCreateRequestBodyItem {
    /** Identifier of the source network resource to associate as a ramp. */
    sourceRampId: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsCreateRequestBodyItemType | (string & {});
}
export declare const Cf1SitesRampsCreateRequestBodyItem: S.Schema<Cf1SitesRampsCreateRequestBodyItem>;
export type Cf1SitesRampsCreateRequestBodyList = Array<Cf1SitesRampsCreateRequestBodyItem>;
export declare const Cf1SitesRampsCreateRequestBodyList: S.Schema<Cf1SitesRampsCreateRequestBodyList>;
export interface CreateCf1SiteRampRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    body: Cf1SitesRampsCreateRequestBodyList;
}
export declare const CreateCf1SiteRampRequest: S.Schema<CreateCf1SiteRampRequest>;
export type Cf1SitesRampsCreateResultItemType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export declare const Cf1SitesRampsCreateResultItemType: any;
export interface Cf1SitesRampsCreateResultItemGre {
    /** URL reference to the source network resource that this ramp is managed by. */
    managedBy?: string | null;
}
export declare const Cf1SitesRampsCreateResultItemGre: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsCreateResultItemGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsCreateResultItemGreInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsCreateResultItemIpsec = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsCreateResultItemIpsec: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsCreateResultItemMconn = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsCreateResultItemMconn: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsCreateResultItemMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsCreateResultItemMplsInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export interface Cf1SitesRampsCreateResultItem {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsCreateResultItemType;
    /** A human-provided description of the ramp. */
    description?: string | null;
    gre?: Cf1SitesRampsCreateResultItemGre | null;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null;
    mconn?: Cf1SitesRampsCreateResultItemGre | null;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
}
export declare const Cf1SitesRampsCreateResultItem: S.Schema<Cf1SitesRampsCreateResultItem>;
export type Cf1SitesRampsCreateResultList = Array<Cf1SitesRampsCreateResultItem>;
export declare const Cf1SitesRampsCreateResultList: S.Schema<Cf1SitesRampsCreateResultList>;
export interface CreateCf1SiteRampResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesRampsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateCf1SiteRampResponse: S.Schema<CreateCf1SiteRampResponse>;
export interface ConnectorsCreateRequestDevice {
    id?: string;
    /** When true, create and provision a new licence key for the connector. */
    provisionLicense?: boolean;
    serialNumber?: string;
}
export declare const ConnectorsCreateRequestDevice: S.Schema<ConnectorsCreateRequestDevice>;
export type ConnectorsCreateRequestInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsCreateRequestInterruptWindowDaysOfWeekItem: any;
export type ConnectorsCreateRequestInterruptWindowDaysOfWeekList = Array<ConnectorsCreateRequestInterruptWindowDaysOfWeekItem | (string & {})>;
export declare const ConnectorsCreateRequestInterruptWindowDaysOfWeekList: S.Schema<ConnectorsCreateRequestInterruptWindowDaysOfWeekList>;
export type ConnectorsCreateRequestInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsCreateRequestInterruptWindowEmbargoDatesList: S.Schema<ConnectorsCreateRequestInterruptWindowEmbargoDatesList>;
export interface CreateConnectorRequest {
    /** Account identifier */
    accountId: string;
    /** Exactly one of id, serial_number, or provision_license must be provided. */
    device: ConnectorsCreateRequestDevice;
    activated?: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek?: ConnectorsCreateRequestInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours?: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates?: ConnectorsCreateRequestInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay?: number;
    notes?: string;
    primary?: boolean;
    siteId?: string;
    timezone?: string;
}
export declare const CreateConnectorRequest: S.Schema<CreateConnectorRequest>;
export type ConnectorsCreateResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsCreateResponseInterruptWindowDaysOfWeekItem: any;
export type ConnectorsCreateResponseInterruptWindowDaysOfWeekList = Array<ConnectorsCreateResponseInterruptWindowDaysOfWeekItem>;
export declare const ConnectorsCreateResponseInterruptWindowDaysOfWeekList: S.Schema<ConnectorsCreateResponseInterruptWindowDaysOfWeekList>;
export type ConnectorsCreateResponseInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsCreateResponseInterruptWindowEmbargoDatesList: S.Schema<ConnectorsCreateResponseInterruptWindowEmbargoDatesList>;
export type ConnectorsCreateResponseDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsCreateResponseDeviceType: any;
export interface ConnectorsCreateResponseDevice {
    id: string;
    serialNumber?: string | null;
    type?: ConnectorsCreateResponseDeviceType | null;
}
export declare const ConnectorsCreateResponseDevice: S.Schema<ConnectorsCreateResponseDevice>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsCreateResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsCreateResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    primary: boolean;
    timezone: string;
    device?: ConnectorsCreateResponseDevice | null;
    lastHeartbeat?: string | null;
    lastSeenVersion?: string | null;
    licenseKey?: string | null;
    siteId?: string | null;
}
export declare const CreateConnectorResponse: S.Schema<CreateConnectorResponse>;
export type GreTunnelsCreateRequestBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsCreateRequestBgpExtraPrefixesList: S.Schema<GreTunnelsCreateRequestBgpExtraPrefixesList>;
export interface GreTunnelsCreateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsCreateRequestBgpExtraPrefixesList;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export declare const GreTunnelsCreateRequestBgp: S.Schema<GreTunnelsCreateRequestBgp>;
export type GreTunnelsCreateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsCreateRequestHealthCheckDirection: any;
export type GreTunnelsCreateRequestHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsCreateRequestHealthCheckRate: any;
export interface GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget {
    /** The effective health check target. If 'saved' is empty, then this field will be populated with the calculated default value on GET requests. Ignored in POST, PUT, and PATCH requests. */
    effective?: string;
    /** The saved health check target. Setting the value to the empty string indicates that the calculated default value will be used. */
    saved?: string;
}
export declare const GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget: S.Schema<GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsCreateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsCreateRequestHealthCheckTarget: any;
export type GreTunnelsCreateRequestHealthCheckType = "reply" | "request";
export declare const GreTunnelsCreateRequestHealthCheckType: any;
export interface GreTunnelsCreateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsCreateRequestHealthCheckDirection | (string & {});
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsCreateRequestHealthCheckRate | (string & {});
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsCreateRequestHealthCheckTarget;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsCreateRequestHealthCheckType | (string & {});
}
export declare const GreTunnelsCreateRequestHealthCheck: S.Schema<GreTunnelsCreateRequestHealthCheck>;
export interface CreateGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean;
    bgp?: GreTunnelsCreateRequestBgp;
    /** An optional description of the GRE tunnel. */
    description?: string;
    healthCheck?: GreTunnelsCreateRequestHealthCheck;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number;
    xMagicNewHcTarget?: boolean;
}
export declare const CreateGreTunnelRequest: S.Schema<CreateGreTunnelRequest>;
export type GreTunnelsCreateResponseBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsCreateResponseBgpExtraPrefixesList: S.Schema<GreTunnelsCreateResponseBgpExtraPrefixesList>;
export interface GreTunnelsCreateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsCreateResponseBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const GreTunnelsCreateResponseBgp: S.Schema<GreTunnelsCreateResponseBgp>;
export type GreTunnelsCreateResponseBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const GreTunnelsCreateResponseBgpStatusState: any;
export interface GreTunnelsCreateResponseBgpStatus {
    state: GreTunnelsCreateResponseBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const GreTunnelsCreateResponseBgpStatus: S.Schema<GreTunnelsCreateResponseBgpStatus>;
export type GreTunnelsCreateResponseHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsCreateResponseHealthCheckDirection: any;
export type GreTunnelsCreateResponseHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsCreateResponseHealthCheckRate: any;
export type GreTunnelsCreateResponseHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsCreateResponseHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsCreateResponseHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsCreateResponseHealthCheckTarget: any;
export type GreTunnelsCreateResponseHealthCheckType = "reply" | "request";
export declare const GreTunnelsCreateResponseHealthCheckType: any;
export interface GreTunnelsCreateResponseHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsCreateResponseHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsCreateResponseHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsCreateResponseHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsCreateResponseHealthCheckType | null;
}
export declare const GreTunnelsCreateResponseHealthCheck: S.Schema<GreTunnelsCreateResponseHealthCheck>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateGreTunnelResponse {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: GreTunnelsCreateResponseBgp | null;
    bgpStatus?: GreTunnelsCreateResponseBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the GRE tunnel. */
    description?: string | null;
    healthCheck?: GreTunnelsCreateResponseHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null;
}
export declare const CreateGreTunnelResponse: S.Schema<CreateGreTunnelResponse>;
export type IpsecTunnelsCreateRequestBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsCreateRequestBgpExtraPrefixesList: S.Schema<IpsecTunnelsCreateRequestBgpExtraPrefixesList>;
export interface IpsecTunnelsCreateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsCreateRequestBgpExtraPrefixesList;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export declare const IpsecTunnelsCreateRequestBgp: S.Schema<IpsecTunnelsCreateRequestBgp>;
export interface IpsecTunnelsCreateRequestCustomRemoteIdentities {
    /** A custom IKE ID of type FQDN that may be used to identity the IPsec tunnel. The */
    fqdnId?: string;
}
export declare const IpsecTunnelsCreateRequestCustomRemoteIdentities: S.Schema<IpsecTunnelsCreateRequestCustomRemoteIdentities>;
export type IpsecTunnelsCreateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsCreateRequestHealthCheckDirection: any;
export type IpsecTunnelsCreateRequestHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsCreateRequestHealthCheckRate: any;
export type IpsecTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget: S.Schema<GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsCreateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsCreateRequestHealthCheckTarget: any;
export type IpsecTunnelsCreateRequestHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsCreateRequestHealthCheckType: any;
export interface IpsecTunnelsCreateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsCreateRequestHealthCheckDirection | (string & {});
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsCreateRequestHealthCheckRate | (string & {});
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsCreateRequestHealthCheckTarget;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsCreateRequestHealthCheckType | (string & {});
}
export declare const IpsecTunnelsCreateRequestHealthCheck: S.Schema<IpsecTunnelsCreateRequestHealthCheck>;
export interface CreateIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean;
    bgp?: IpsecTunnelsCreateRequestBgp;
    customRemoteIdentities?: IpsecTunnelsCreateRequestCustomRemoteIdentities;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string;
    /** An optional description forthe IPsec tunnel. */
    description?: string;
    healthCheck?: IpsecTunnelsCreateRequestHealthCheck;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk?: string;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean;
    xMagicNewHcTarget?: boolean;
}
export declare const CreateIpsecTunnelRequest: S.Schema<CreateIpsecTunnelRequest>;
export type IpsecTunnelsCreateResponseBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsCreateResponseBgpExtraPrefixesList: S.Schema<IpsecTunnelsCreateResponseBgpExtraPrefixesList>;
export interface IpsecTunnelsCreateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsCreateResponseBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const IpsecTunnelsCreateResponseBgp: S.Schema<IpsecTunnelsCreateResponseBgp>;
export type IpsecTunnelsCreateResponseBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const IpsecTunnelsCreateResponseBgpStatusState: any;
export interface IpsecTunnelsCreateResponseBgpStatus {
    state: IpsecTunnelsCreateResponseBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const IpsecTunnelsCreateResponseBgpStatus: S.Schema<IpsecTunnelsCreateResponseBgpStatus>;
export type IpsecTunnelsCreateResponseCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export declare const IpsecTunnelsCreateResponseCustomRemoteIdentities: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities>;
export type IpsecTunnelsCreateResponseHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsCreateResponseHealthCheckDirection: any;
export type IpsecTunnelsCreateResponseHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsCreateResponseHealthCheckRate: any;
export type IpsecTunnelsCreateResponseHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsCreateResponseHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsCreateResponseHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsCreateResponseHealthCheckTarget: any;
export type IpsecTunnelsCreateResponseHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsCreateResponseHealthCheckType: any;
export interface IpsecTunnelsCreateResponseHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsCreateResponseHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsCreateResponseHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsCreateResponseHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsCreateResponseHealthCheckType | null;
}
export declare const IpsecTunnelsCreateResponseHealthCheck: S.Schema<IpsecTunnelsCreateResponseHealthCheck>;
export type IpsecTunnelsCreateResponsePskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsCreateResponsePskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIpsecTunnelResponse {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: IpsecTunnelsCreateResponseBgp | null;
    bgpStatus?: IpsecTunnelsCreateResponseBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null;
    healthCheck?: IpsecTunnelsCreateResponseHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null;
}
export declare const CreateIpsecTunnelResponse: S.Schema<CreateIpsecTunnelResponse>;
export type PcapsCreateRequestSystem = "magic-transit";
export declare const PcapsCreateRequestSystem: any;
export type PcapsCreateRequestType = "simple" | "full";
export declare const PcapsCreateRequestType: any;
export interface PcapsCreateRequestFilterV1MagicVisibilityPCAPsPCAPsRequestSimple {
    /** The destination IP address of the packet. */
    destinationAddress?: string;
    /** The destination port of the packet. */
    destinationPort?: number;
    /** The protocol number of the packet. */
    protocol?: number;
    /** The source IP address of the packet. */
    sourceAddress?: string;
    /** The source port of the packet. */
    sourcePort?: number;
}
export declare const PcapsCreateRequestFilterV1MagicVisibilityPCAPsPCAPsRequestSimple: S.Schema<PcapsCreateRequestFilterV1MagicVisibilityPCAPsPCAPsRequestSimple>;
export interface CreatePcapRequest {
    /** Identifier. */
    accountId: string;
    /** The limit of packets contained in a packet capture. */
    packetLimit?: number;
    /** The system used to collect packet captures. */
    system: PcapsCreateRequestSystem | (string & {});
    /** The packet capture duration in seconds. */
    timeLimit: number;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type: PcapsCreateRequestType | (string & {});
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateRequestFilterV1MagicVisibilityPCAPsPCAPsRequestSimple;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number;
}
export declare const CreatePcapRequest: S.Schema<CreatePcapRequest>;
export interface PcapsCreateResultPCAPFilterV1 {
    /** The destination IP address of the packet. */
    destinationAddress?: string | null;
    /** The destination port of the packet. */
    destinationPort?: number | null;
    /** The protocol number of the packet. */
    protocol?: number | null;
    /** The source IP address of the packet. */
    sourceAddress?: string | null;
    /** The source port of the packet. */
    sourcePort?: number | null;
}
export declare const PcapsCreateResultPCAPFilterV1: S.Schema<PcapsCreateResultPCAPFilterV1>;
export type PcapsCreateResultPCAPStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export declare const PcapsCreateResultPCAPStatus: any;
export type PcapsCreateResultPCAPSystem = "magic-transit";
export declare const PcapsCreateResultPCAPSystem: any;
export type PcapsCreateResultPCAPType = "simple" | "full";
export declare const PcapsCreateResultPCAPType: any;
export interface PcapsCreateResultPCAP {
    /** The ID for the packet capture. */
    id?: string | null;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | null;
    /** The status of the packet capture request. */
    status?: PcapsCreateResultPCAPStatus | null;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null;
    /** The system used to collect packet captures. */
    system?: PcapsCreateResultPCAPSystem | null;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsCreateResultPCAPType | null;
}
export declare const PcapsCreateResultPCAP: S.Schema<PcapsCreateResultPCAP>;
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export declare const PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullStatus: any;
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullSystem = "magic-transit";
export declare const PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullSystem: any;
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullType = "simple" | "full";
export declare const PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullType: any;
export interface PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFull {
    /** The ID for the packet capture. */
    id?: string | null;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | null;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | null;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | null;
    /** An error message that describes why the packet capture failed. This field only applies to `full` packet captures. */
    errorMessage?: string | null;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null;
    /** The number of packets captured. */
    packetsCaptured?: number | null;
    /** The status of the packet capture request. */
    status?: PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullStatus | null;
    /** The RFC 3339 timestamp when stopping the packet capture was requested. This field only applies to `full` packet captures. */
    stopRequested?: string | null;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null;
    /** The system used to collect packet captures. */
    system?: PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullSystem | null;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullType | null;
}
export declare const PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFull: S.Schema<PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFull>;
export type PcapsCreateResult = PcapsCreateResultPCAP | PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFull;
export declare const PcapsCreateResult: any;
export type CreatePcapResponse = PcapsCreateResult;
export declare const CreatePcapResponse: S.Schema<CreatePcapResponse>;
export interface CreatePcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
}
export declare const CreatePcapOwnershipRequest: S.Schema<CreatePcapOwnershipRequest>;
export type PcapsOwnershipCreateResponseStatus = "pending" | "success" | "failed";
export declare const PcapsOwnershipCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePcapOwnershipResponse {
    /** The bucket ID associated with the packet captures API. */
    id: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    filename: string;
    /** The status of the ownership challenge. Can be pending, success or failed. */
    status: PcapsOwnershipCreateResponseStatus;
    /** The RFC 3339 timestamp when the bucket was added to packet captures API. */
    submitted: string;
    /** The RFC 3339 timestamp when the bucket was validated. */
    validated?: string | null;
}
export declare const CreatePcapOwnershipResponse: S.Schema<CreatePcapOwnershipResponse>;
export type RoutesCreateRequestScopeColoNamesList = Array<string>;
export declare const RoutesCreateRequestScopeColoNamesList: S.Schema<RoutesCreateRequestScopeColoNamesList>;
export type RoutesCreateRequestScopeColoRegionsList = Array<string>;
export declare const RoutesCreateRequestScopeColoRegionsList: S.Schema<RoutesCreateRequestScopeColoRegionsList>;
export interface RoutesCreateRequestScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesCreateRequestScopeColoNamesList;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesCreateRequestScopeColoRegionsList;
}
export declare const RoutesCreateRequestScope: S.Schema<RoutesCreateRequestScope>;
export interface CreateRouteRequest {
    /** Identifier */
    accountId: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** An optional human provided description of the static route. */
    description?: string;
    /** Used only for ECMP routes. */
    scope?: RoutesCreateRequestScope;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number;
}
export declare const CreateRouteRequest: S.Schema<CreateRouteRequest>;
export type RoutesCreateResponseScopeColoNamesList = Array<string>;
export declare const RoutesCreateResponseScopeColoNamesList: S.Schema<RoutesCreateResponseScopeColoNamesList>;
export type RoutesCreateResponseScopeColoRegionsList = Array<string>;
export declare const RoutesCreateResponseScopeColoRegionsList: S.Schema<RoutesCreateResponseScopeColoRegionsList>;
export interface RoutesCreateResponseScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesCreateResponseScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesCreateResponseScopeColoRegionsList | null;
}
export declare const RoutesCreateResponseScope: S.Schema<RoutesCreateResponseScope>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRouteResponse {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesCreateResponseScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const CreateRouteResponse: S.Schema<CreateRouteResponse>;
export interface SitesCreateRequestLocation {
    /** Latitude */
    lat?: string;
    /** Longitude */
    lon?: string;
}
export declare const SitesCreateRequestLocation: S.Schema<SitesCreateRequestLocation>;
export interface CreateSiteRequest {
    /** Identifier */
    accountId: string;
    /** The name of the site. */
    name: string;
    /** Magic Connector identifier tag. */
    connectorId?: string;
    description?: string;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateRequestLocation;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string;
}
export declare const CreateSiteRequest: S.Schema<CreateSiteRequest>;
export interface SitesCreateResponseLocation {
    /** Latitude */
    lat?: string | null;
    /** Longitude */
    lon?: string | null;
}
export declare const SitesCreateResponseLocation: S.Schema<SitesCreateResponseLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSiteResponse {
    /** Identifier */
    id?: string | null;
    /** Magic Connector identifier tag. */
    connectorId?: string | null;
    description?: string | null;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null;
    /** The name of the site. */
    name?: string | null;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null;
}
export declare const CreateSiteResponse: S.Schema<CreateSiteResponse>;
export type SitesAclsCreateRequestLan1PortRangesList = Array<string>;
export declare const SitesAclsCreateRequestLan1PortRangesList: S.Schema<SitesAclsCreateRequestLan1PortRangesList>;
export type SitesAclsCreateRequestLan1PortsList = Array<number>;
export declare const SitesAclsCreateRequestLan1PortsList: S.Schema<SitesAclsCreateRequestLan1PortsList>;
export type SitesAclsCreateRequestLan1SubnetsList = Array<string>;
export declare const SitesAclsCreateRequestLan1SubnetsList: S.Schema<SitesAclsCreateRequestLan1SubnetsList>;
export interface SitesAclsCreateRequestLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsCreateRequestLan1PortRangesList;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsCreateRequestLan1PortsList;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsCreateRequestLan1SubnetsList;
}
export declare const SitesAclsCreateRequestLan1: S.Schema<SitesAclsCreateRequestLan1>;
export type SitesAclsCreateRequestProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsCreateRequestProtocolsItem: any;
export type SitesAclsCreateRequestProtocolsList = Array<SitesAclsCreateRequestProtocolsItem | (string & {})>;
export declare const SitesAclsCreateRequestProtocolsList: S.Schema<SitesAclsCreateRequestProtocolsList>;
export interface CreateSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    lan_1: SitesAclsCreateRequestLan1;
    lan_2: SitesAclsCreateRequestLan1;
    /** The name of the ACL. */
    name: string;
    /** Description for the ACL. */
    description?: string;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean;
    protocols?: SitesAclsCreateRequestProtocolsList;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean;
}
export declare const CreateSiteAclRequest: S.Schema<CreateSiteAclRequest>;
export type SitesAclsCreateResponseLan1PortRangesList = Array<string>;
export declare const SitesAclsCreateResponseLan1PortRangesList: S.Schema<SitesAclsCreateResponseLan1PortRangesList>;
export type SitesAclsCreateResponseLan1PortsList = Array<number>;
export declare const SitesAclsCreateResponseLan1PortsList: S.Schema<SitesAclsCreateResponseLan1PortsList>;
export type SitesAclsCreateResponseLan1SubnetsList = Array<string>;
export declare const SitesAclsCreateResponseLan1SubnetsList: S.Schema<SitesAclsCreateResponseLan1SubnetsList>;
export interface SitesAclsCreateResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsCreateResponseLan1PortRangesList | null;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsCreateResponseLan1PortsList | null;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsCreateResponseLan1SubnetsList | null;
}
export declare const SitesAclsCreateResponseLan1: S.Schema<SitesAclsCreateResponseLan1>;
export type SitesAclsCreateResponseProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsCreateResponseProtocolsItem: any;
export type SitesAclsCreateResponseProtocolsList = Array<SitesAclsCreateResponseProtocolsItem>;
export declare const SitesAclsCreateResponseProtocolsList: S.Schema<SitesAclsCreateResponseProtocolsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSiteAclResponse {
    /** Identifier */
    id?: string | null;
    /** Description for the ACL. */
    description?: string | null;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null;
    lan_1?: SitesAclsCreateResponseLan1 | null;
    lan_2?: SitesAclsCreateResponseLan1 | null;
    /** The name of the ACL. */
    name?: string | null;
    protocols?: SitesAclsCreateResponseProtocolsList | null;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null;
}
export declare const CreateSiteAclResponse: S.Schema<CreateSiteAclResponse>;
export interface SitesLansCreateRequestNat {
    /** A valid CIDR notation representing an IP range. */
    staticPrefix?: string;
}
export declare const SitesLansCreateRequestNat: S.Schema<SitesLansCreateRequestNat>;
export interface SitesLansCreateRequestRoutedSubnetsItem {
    /** A valid IPv4 address. */
    nextHop: string;
    /** A valid CIDR notation representing an IP range. */
    prefix: string;
    nat?: SitesLansCreateRequestNat;
}
export declare const SitesLansCreateRequestRoutedSubnetsItem: S.Schema<SitesLansCreateRequestRoutedSubnetsItem>;
export type SitesLansCreateRequestRoutedSubnetsList = Array<SitesLansCreateRequestRoutedSubnetsItem>;
export declare const SitesLansCreateRequestRoutedSubnetsList: S.Schema<SitesLansCreateRequestRoutedSubnetsList>;
export type SitesLansCreateRequestStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansCreateRequestStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansCreateRequestStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansCreateRequestStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansCreateRequestStaticAddressingDhcpRelayServerAddressesList;
}
export declare const SitesLansCreateRequestStaticAddressingDhcpRelay: S.Schema<SitesLansCreateRequestStaticAddressingDhcpRelay>;
export type SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItemType | (string & {});
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansCreateRequestStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansCreateRequestStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansCreateRequestStaticAddressingDhcpServerDnsServersList>;
export type SitesLansCreateRequestStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansCreateRequestStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansCreateRequestStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansCreateRequestStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsList;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string;
    /** A valid IPv4 address. */
    dnsServer?: string;
    dnsServers?: SitesLansCreateRequestStaticAddressingDhcpServerDnsServersList;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansCreateRequestStaticAddressingDhcpServerReservationsMap;
}
export declare const SitesLansCreateRequestStaticAddressingDhcpServer: S.Schema<SitesLansCreateRequestStaticAddressingDhcpServer>;
export interface SitesLansCreateRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansCreateRequestStaticAddressingDhcpRelay;
    dhcpServer?: SitesLansCreateRequestStaticAddressingDhcpServer;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string;
}
export declare const SitesLansCreateRequestStaticAddressing: S.Schema<SitesLansCreateRequestStaticAddressing>;
export interface CreateSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    bondId?: number;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean;
    name?: string;
    nat?: SitesLansCreateRequestNat;
    physport?: number;
    routedSubnets?: SitesLansCreateRequestRoutedSubnetsList;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansCreateRequestStaticAddressing;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number;
}
export declare const CreateSiteLanRequest: S.Schema<CreateSiteLanRequest>;
export interface SitesLansCreateResultItemNat {
    /** A valid CIDR notation representing an IP range. */
    staticPrefix?: string | null;
}
export declare const SitesLansCreateResultItemNat: S.Schema<SitesLansCreateResultItemNat>;
export interface SitesLansCreateResultItemRoutedSubnetsItem {
    /** A valid IPv4 address. */
    nextHop: string;
    /** A valid CIDR notation representing an IP range. */
    prefix: string;
    nat?: SitesLansCreateResultItemNat | null;
}
export declare const SitesLansCreateResultItemRoutedSubnetsItem: S.Schema<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansCreateResultItemRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export declare const SitesLansCreateResultItemRoutedSubnetsList: S.Schema<SitesLansCreateResultItemRoutedSubnetsList>;
export type SitesLansCreateResultItemStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansCreateResultItemStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansCreateResultItemStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansCreateResultItemStaticAddressingDhcpRelayServerAddressesList | null;
}
export declare const SitesLansCreateResultItemStaticAddressingDhcpRelay: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpRelay>;
export type SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansCreateResultItemStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansCreateResultItemStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpServerDnsServersList>;
export type SitesLansCreateResultItemStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansCreateResultItemStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansCreateResultItemStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsList | null;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null;
    /** A valid IPv4 address. */
    dnsServer?: string | null;
    dnsServers?: SitesLansCreateResultItemStaticAddressingDhcpServerDnsServersList | null;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansCreateResultItemStaticAddressingDhcpServerReservationsMap | null;
}
export declare const SitesLansCreateResultItemStaticAddressingDhcpServer: S.Schema<SitesLansCreateResultItemStaticAddressingDhcpServer>;
export interface SitesLansCreateResultItemStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansCreateResultItemStaticAddressingDhcpRelay | null;
    dhcpServer?: SitesLansCreateResultItemStaticAddressingDhcpServer | null;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null;
}
export declare const SitesLansCreateResultItemStaticAddressing: S.Schema<SitesLansCreateResultItemStaticAddressing>;
export interface SitesLansCreateResultItem {
    /** Identifier */
    id?: string | null;
    bondId?: number | null;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null;
    name?: string | null;
    nat?: SitesLansCreateResultItemNat | null;
    physport?: number | null;
    routedSubnets?: SitesLansCreateResultItemRoutedSubnetsList | null;
    /** Identifier */
    siteId?: string | null;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const SitesLansCreateResultItem: S.Schema<SitesLansCreateResultItem>;
export type SitesLansCreateResultList = Array<SitesLansCreateResultItem>;
export declare const SitesLansCreateResultList: S.Schema<SitesLansCreateResultList>;
export interface CreateSiteLanResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesLansCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateSiteLanResponse: S.Schema<CreateSiteLanResponse>;
export type CreateSitesAppConfigurationRequestPreferredWansList = Array<string>;
export declare const CreateSitesAppConfigurationRequestPreferredWansList: S.Schema<CreateSitesAppConfigurationRequestPreferredWansList>;
export interface CreateSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Magic account app ID. */
    accountAppId?: string;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: CreateSitesAppConfigurationRequestPreferredWansList;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number;
    /** Managed app ID. */
    managedAppId?: string;
}
export declare const CreateSitesAppConfigurationRequest: S.Schema<CreateSitesAppConfigurationRequest>;
export type CreateSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export declare const CreateSitesAppConfigurationResultAccountAppPreferredWansList: S.Schema<CreateSitesAppConfigurationResultAccountAppPreferredWansList>;
export interface CreateSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: CreateSitesAppConfigurationResultAccountAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const CreateSitesAppConfigurationResultAccountApp: S.Schema<CreateSitesAppConfigurationResultAccountApp>;
export type CreateSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export declare const CreateSitesAppConfigurationResultManagedAppPreferredWansList: S.Schema<CreateSitesAppConfigurationResultManagedAppPreferredWansList>;
export interface CreateSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: CreateSitesAppConfigurationResultManagedAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const CreateSitesAppConfigurationResultManagedApp: S.Schema<CreateSitesAppConfigurationResultManagedApp>;
export type CreateSitesAppConfigurationResult = CreateSitesAppConfigurationResultAccountApp | CreateSitesAppConfigurationResultManagedApp;
export declare const CreateSitesAppConfigurationResult: any;
export type CreateSitesAppConfigurationResponse = CreateSitesAppConfigurationResult;
export declare const CreateSitesAppConfigurationResponse: S.Schema<CreateSitesAppConfigurationResponse>;
export interface SitesWansCreateRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    /** A valid IPv4 address. */
    gatewayAddress: string;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string;
}
export declare const SitesWansCreateRequestStaticAddressing: S.Schema<SitesWansCreateRequestStaticAddressing>;
export interface CreateSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    physport: number;
    name?: string;
    priority?: number;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateRequestStaticAddressing;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number;
}
export declare const CreateSiteWanRequest: S.Schema<CreateSiteWanRequest>;
export type SitesWansCreateResultItemHealthCheckRate = "low" | "mid" | "high";
export declare const SitesWansCreateResultItemHealthCheckRate: any;
export interface SitesWansCreateResultItemStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    /** A valid IPv4 address. */
    gatewayAddress: string;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
}
export declare const SitesWansCreateResultItemStaticAddressing: S.Schema<SitesWansCreateResultItemStaticAddressing>;
export interface SitesWansCreateResultItem {
    /** Identifier */
    id?: string | null;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansCreateResultItemHealthCheckRate | null;
    name?: string | null;
    physport?: number | null;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const SitesWansCreateResultItem: S.Schema<SitesWansCreateResultItem>;
export type SitesWansCreateResultList = Array<SitesWansCreateResultItem>;
export declare const SitesWansCreateResultList: S.Schema<SitesWansCreateResultList>;
export interface CreateSiteWanResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesWansCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateSiteWanResponse: S.Schema<CreateSiteWanResponse>;
export interface DeleteAppRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    accountAppId: string;
}
export declare const DeleteAppRequest: S.Schema<DeleteAppRequest>;
export type AppsDeleteResponseHostnamesList = Array<string>;
export declare const AppsDeleteResponseHostnamesList: S.Schema<AppsDeleteResponseHostnamesList>;
export type AppsDeleteResponseIpSubnetsList = Array<string>;
export declare const AppsDeleteResponseIpSubnetsList: S.Schema<AppsDeleteResponseIpSubnetsList>;
export type AppsDeleteResponseSourceSubnetsList = Array<string>;
export declare const AppsDeleteResponseSourceSubnetsList: S.Schema<AppsDeleteResponseSourceSubnetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsDeleteResponseHostnamesList | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsDeleteResponseIpSubnetsList | null;
    /** Display name for the app. */
    name?: string | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsDeleteResponseSourceSubnetsList | null;
    /** Category of the app. */
    type?: string | null;
}
export declare const DeleteAppResponse: S.Schema<DeleteAppResponse>;
export interface DeleteCf1SiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
}
export declare const DeleteCf1SiteRequest: S.Schema<DeleteCf1SiteRequest>;
export type Cf1SitesDeleteResponseLocation = Cf1SitesCreateResultItemLocation;
export declare const Cf1SitesDeleteResponseLocation: S.Schema<Cf1SitesCreateResultItemLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCf1SiteResponse {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null;
    createdOn?: string | null;
    /** A human-provided description of the CF1 Site. */
    description?: string | null;
    location?: Cf1SitesCreateResultItemLocation | null;
    modifiedOn?: string | null;
}
export declare const DeleteCf1SiteResponse: S.Schema<DeleteCf1SiteResponse>;
export interface DeleteCf1SiteRampRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    /** Identifier */
    rampId: string;
}
export declare const DeleteCf1SiteRampRequest: S.Schema<DeleteCf1SiteRampRequest>;
export type Cf1SitesRampsDeleteResponseType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export declare const Cf1SitesRampsDeleteResponseType: any;
export type Cf1SitesRampsDeleteResponseGre = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsDeleteResponseGre: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsDeleteResponseGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsDeleteResponseGreInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsDeleteResponseIpsec = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsDeleteResponseIpsec: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsDeleteResponseMconn = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsDeleteResponseMconn: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsDeleteResponseMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsDeleteResponseMplsInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCf1SiteRampResponse {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsDeleteResponseType;
    /** A human-provided description of the ramp. */
    description?: string | null;
    gre?: Cf1SitesRampsCreateResultItemGre | null;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null;
    mconn?: Cf1SitesRampsCreateResultItemGre | null;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
}
export declare const DeleteCf1SiteRampResponse: S.Schema<DeleteCf1SiteRampResponse>;
export interface DeleteConnectorRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
}
export declare const DeleteConnectorRequest: S.Schema<DeleteConnectorRequest>;
export type ConnectorsDeleteResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsDeleteResponseInterruptWindowDaysOfWeekItem: any;
export type ConnectorsDeleteResponseInterruptWindowDaysOfWeekList = Array<ConnectorsDeleteResponseInterruptWindowDaysOfWeekItem>;
export declare const ConnectorsDeleteResponseInterruptWindowDaysOfWeekList: S.Schema<ConnectorsDeleteResponseInterruptWindowDaysOfWeekList>;
export type ConnectorsDeleteResponseInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsDeleteResponseInterruptWindowEmbargoDatesList: S.Schema<ConnectorsDeleteResponseInterruptWindowEmbargoDatesList>;
export type ConnectorsDeleteResponseDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsDeleteResponseDeviceType: any;
export interface ConnectorsDeleteResponseDevice {
    id: string;
    serialNumber?: string | null;
    type?: ConnectorsDeleteResponseDeviceType | null;
}
export declare const ConnectorsDeleteResponseDevice: S.Schema<ConnectorsDeleteResponseDevice>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsDeleteResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsDeleteResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    primary: boolean;
    timezone: string;
    device?: ConnectorsDeleteResponseDevice | null;
    lastHeartbeat?: string | null;
    lastSeenVersion?: string | null;
    licenseKey?: string | null;
    siteId?: string | null;
}
export declare const DeleteConnectorResponse: S.Schema<DeleteConnectorResponse>;
export interface DeleteGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    greTunnelId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const DeleteGreTunnelRequest: S.Schema<DeleteGreTunnelRequest>;
export type GreTunnelsDeleteResponseDeletedGreTunnelBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsDeleteResponseDeletedGreTunnelBgpExtraPrefixesList: S.Schema<GreTunnelsDeleteResponseDeletedGreTunnelBgpExtraPrefixesList>;
export interface GreTunnelsDeleteResponseDeletedGreTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsDeleteResponseDeletedGreTunnelBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const GreTunnelsDeleteResponseDeletedGreTunnelBgp: S.Schema<GreTunnelsDeleteResponseDeletedGreTunnelBgp>;
export type GreTunnelsDeleteResponseDeletedGreTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const GreTunnelsDeleteResponseDeletedGreTunnelBgpStatusState: any;
export interface GreTunnelsDeleteResponseDeletedGreTunnelBgpStatus {
    state: GreTunnelsDeleteResponseDeletedGreTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const GreTunnelsDeleteResponseDeletedGreTunnelBgpStatus: S.Schema<GreTunnelsDeleteResponseDeletedGreTunnelBgpStatus>;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckDirection: any;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckRate: any;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTarget: any;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckType = "reply" | "request";
export declare const GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckType: any;
export interface GreTunnelsDeleteResponseDeletedGreTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckType | null;
}
export declare const GreTunnelsDeleteResponseDeletedGreTunnelHealthCheck: S.Schema<GreTunnelsDeleteResponseDeletedGreTunnelHealthCheck>;
export interface GreTunnelsDeleteResponseDeletedGreTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: GreTunnelsDeleteResponseDeletedGreTunnelBgp | null;
    bgpStatus?: GreTunnelsDeleteResponseDeletedGreTunnelBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the GRE tunnel. */
    description?: string | null;
    healthCheck?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null;
}
export declare const GreTunnelsDeleteResponseDeletedGreTunnel: S.Schema<GreTunnelsDeleteResponseDeletedGreTunnel>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteGreTunnelResponse {
    deleted?: boolean | null;
    deletedGreTunnel?: GreTunnelsDeleteResponseDeletedGreTunnel | null;
}
export declare const DeleteGreTunnelResponse: S.Schema<DeleteGreTunnelResponse>;
export interface DeleteIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const DeleteIpsecTunnelRequest: S.Schema<DeleteIpsecTunnelRequest>;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpExtraPrefixesList: S.Schema<IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpExtraPrefixesList>;
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgp: S.Schema<IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgp>;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatusState: any;
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatus {
    state: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatus: S.Schema<IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatus>;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelCustomRemoteIdentities: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities>;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckDirection: any;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckRate: any;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTarget: any;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckType: any;
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckType | null;
}
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheck: S.Schema<IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheck>;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnelPskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgp | null;
    bgpStatus?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null;
    healthCheck?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null;
}
export declare const IpsecTunnelsDeleteResponseDeletedIpsecTunnel: S.Schema<IpsecTunnelsDeleteResponseDeletedIpsecTunnel>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteIpsecTunnelResponse {
    deleted?: boolean | null;
    deletedIpsecTunnel?: IpsecTunnelsDeleteResponseDeletedIpsecTunnel | null;
}
export declare const DeleteIpsecTunnelResponse: S.Schema<DeleteIpsecTunnelResponse>;
export interface DeletePcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    ownershipId: string;
}
export declare const DeletePcapOwnershipRequest: S.Schema<DeletePcapOwnershipRequest>;
export interface DeletePcapOwnershipResponse {
}
export declare const DeletePcapOwnershipResponse: S.Schema<DeletePcapOwnershipResponse>;
export interface DeleteRouteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    routeId: string;
}
export declare const DeleteRouteRequest: S.Schema<DeleteRouteRequest>;
export type RoutesDeleteResponseDeletedRouteScopeColoNamesList = Array<string>;
export declare const RoutesDeleteResponseDeletedRouteScopeColoNamesList: S.Schema<RoutesDeleteResponseDeletedRouteScopeColoNamesList>;
export type RoutesDeleteResponseDeletedRouteScopeColoRegionsList = Array<string>;
export declare const RoutesDeleteResponseDeletedRouteScopeColoRegionsList: S.Schema<RoutesDeleteResponseDeletedRouteScopeColoRegionsList>;
export interface RoutesDeleteResponseDeletedRouteScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesDeleteResponseDeletedRouteScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesDeleteResponseDeletedRouteScopeColoRegionsList | null;
}
export declare const RoutesDeleteResponseDeletedRouteScope: S.Schema<RoutesDeleteResponseDeletedRouteScope>;
export interface RoutesDeleteResponseDeletedRoute {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesDeleteResponseDeletedRouteScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const RoutesDeleteResponseDeletedRoute: S.Schema<RoutesDeleteResponseDeletedRoute>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRouteResponse {
    deleted?: boolean | null;
    deletedRoute?: RoutesDeleteResponseDeletedRoute | null;
}
export declare const DeleteRouteResponse: S.Schema<DeleteRouteResponse>;
export interface DeleteSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export declare const DeleteSiteRequest: S.Schema<DeleteSiteRequest>;
export type SitesDeleteResponseLocation = SitesCreateResponseLocation;
export declare const SitesDeleteResponseLocation: S.Schema<SitesCreateResponseLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteResponse {
    /** Identifier */
    id?: string | null;
    /** Magic Connector identifier tag. */
    connectorId?: string | null;
    description?: string | null;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null;
    /** The name of the site. */
    name?: string | null;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null;
}
export declare const DeleteSiteResponse: S.Schema<DeleteSiteResponse>;
export interface DeleteSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
}
export declare const DeleteSiteAclRequest: S.Schema<DeleteSiteAclRequest>;
export type SitesAclsDeleteResponseLan1PortRangesList = Array<string>;
export declare const SitesAclsDeleteResponseLan1PortRangesList: S.Schema<SitesAclsDeleteResponseLan1PortRangesList>;
export type SitesAclsDeleteResponseLan1PortsList = Array<number>;
export declare const SitesAclsDeleteResponseLan1PortsList: S.Schema<SitesAclsDeleteResponseLan1PortsList>;
export type SitesAclsDeleteResponseLan1SubnetsList = Array<string>;
export declare const SitesAclsDeleteResponseLan1SubnetsList: S.Schema<SitesAclsDeleteResponseLan1SubnetsList>;
export interface SitesAclsDeleteResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsDeleteResponseLan1PortRangesList | null;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsDeleteResponseLan1PortsList | null;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsDeleteResponseLan1SubnetsList | null;
}
export declare const SitesAclsDeleteResponseLan1: S.Schema<SitesAclsDeleteResponseLan1>;
export type SitesAclsDeleteResponseProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsDeleteResponseProtocolsItem: any;
export type SitesAclsDeleteResponseProtocolsList = Array<SitesAclsDeleteResponseProtocolsItem>;
export declare const SitesAclsDeleteResponseProtocolsList: S.Schema<SitesAclsDeleteResponseProtocolsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteAclResponse {
    /** Identifier */
    id?: string | null;
    /** Description for the ACL. */
    description?: string | null;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null;
    lan_1?: SitesAclsDeleteResponseLan1 | null;
    lan_2?: SitesAclsDeleteResponseLan1 | null;
    /** The name of the ACL. */
    name?: string | null;
    protocols?: SitesAclsDeleteResponseProtocolsList | null;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null;
}
export declare const DeleteSiteAclResponse: S.Schema<DeleteSiteAclResponse>;
export interface DeleteSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
}
export declare const DeleteSiteLanRequest: S.Schema<DeleteSiteLanRequest>;
export type SitesLansDeleteResponseNat = SitesLansCreateResultItemNat;
export declare const SitesLansDeleteResponseNat: S.Schema<SitesLansCreateResultItemNat>;
export type SitesLansDeleteResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export declare const SitesLansDeleteResponseRoutedSubnetsItem: S.Schema<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansDeleteResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export declare const SitesLansDeleteResponseRoutedSubnetsList: S.Schema<SitesLansDeleteResponseRoutedSubnetsList>;
export type SitesLansDeleteResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansDeleteResponseStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansDeleteResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansDeleteResponseStaticAddressingDhcpRelayServerAddressesList | null;
}
export declare const SitesLansDeleteResponseStaticAddressingDhcpRelay: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpRelay>;
export type SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansDeleteResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansDeleteResponseStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpServerDnsServersList>;
export type SitesLansDeleteResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansDeleteResponseStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansDeleteResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsList | null;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null;
    /** A valid IPv4 address. */
    dnsServer?: string | null;
    dnsServers?: SitesLansDeleteResponseStaticAddressingDhcpServerDnsServersList | null;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansDeleteResponseStaticAddressingDhcpServerReservationsMap | null;
}
export declare const SitesLansDeleteResponseStaticAddressingDhcpServer: S.Schema<SitesLansDeleteResponseStaticAddressingDhcpServer>;
export interface SitesLansDeleteResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansDeleteResponseStaticAddressingDhcpRelay | null;
    dhcpServer?: SitesLansDeleteResponseStaticAddressingDhcpServer | null;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null;
}
export declare const SitesLansDeleteResponseStaticAddressing: S.Schema<SitesLansDeleteResponseStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteLanResponse {
    /** Identifier */
    id?: string | null;
    bondId?: number | null;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null;
    name?: string | null;
    nat?: SitesLansCreateResultItemNat | null;
    physport?: number | null;
    routedSubnets?: SitesLansDeleteResponseRoutedSubnetsList | null;
    /** Identifier */
    siteId?: string | null;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansDeleteResponseStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const DeleteSiteLanResponse: S.Schema<DeleteSiteLanResponse>;
export interface DeleteSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    appConfigId: string;
}
export declare const DeleteSitesAppConfigurationRequest: S.Schema<DeleteSitesAppConfigurationRequest>;
export type DeleteSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export declare const DeleteSitesAppConfigurationResultAccountAppPreferredWansList: S.Schema<DeleteSitesAppConfigurationResultAccountAppPreferredWansList>;
export interface DeleteSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: DeleteSitesAppConfigurationResultAccountAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const DeleteSitesAppConfigurationResultAccountApp: S.Schema<DeleteSitesAppConfigurationResultAccountApp>;
export type DeleteSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export declare const DeleteSitesAppConfigurationResultManagedAppPreferredWansList: S.Schema<DeleteSitesAppConfigurationResultManagedAppPreferredWansList>;
export interface DeleteSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: DeleteSitesAppConfigurationResultManagedAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const DeleteSitesAppConfigurationResultManagedApp: S.Schema<DeleteSitesAppConfigurationResultManagedApp>;
export type DeleteSitesAppConfigurationResult = DeleteSitesAppConfigurationResultAccountApp | DeleteSitesAppConfigurationResultManagedApp;
export declare const DeleteSitesAppConfigurationResult: any;
export type DeleteSitesAppConfigurationResponse = DeleteSitesAppConfigurationResult;
export declare const DeleteSitesAppConfigurationResponse: S.Schema<DeleteSitesAppConfigurationResponse>;
export interface DeleteSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
}
export declare const DeleteSiteWanRequest: S.Schema<DeleteSiteWanRequest>;
export type SitesWansDeleteResponseHealthCheckRate = "low" | "mid" | "high";
export declare const SitesWansDeleteResponseHealthCheckRate: any;
export type SitesWansDeleteResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
export declare const SitesWansDeleteResponseStaticAddressing: S.Schema<SitesWansCreateResultItemStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteWanResponse {
    /** Identifier */
    id?: string | null;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansDeleteResponseHealthCheckRate | null;
    name?: string | null;
    physport?: number | null;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const DeleteSiteWanResponse: S.Schema<DeleteSiteWanResponse>;
export type EditSitesAppConfigurationRequestPreferredWansList = Array<string>;
export declare const EditSitesAppConfigurationRequestPreferredWansList: S.Schema<EditSitesAppConfigurationRequestPreferredWansList>;
export interface EditSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    appConfigId: string;
    /** Magic account app ID. */
    accountAppId?: string;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean;
    /** Managed app ID. */
    managedAppId?: string;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: EditSitesAppConfigurationRequestPreferredWansList;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number;
}
export declare const EditSitesAppConfigurationRequest: S.Schema<EditSitesAppConfigurationRequest>;
export type EditSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export declare const EditSitesAppConfigurationResultAccountAppPreferredWansList: S.Schema<EditSitesAppConfigurationResultAccountAppPreferredWansList>;
export interface EditSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: EditSitesAppConfigurationResultAccountAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const EditSitesAppConfigurationResultAccountApp: S.Schema<EditSitesAppConfigurationResultAccountApp>;
export type EditSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export declare const EditSitesAppConfigurationResultManagedAppPreferredWansList: S.Schema<EditSitesAppConfigurationResultManagedAppPreferredWansList>;
export interface EditSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: EditSitesAppConfigurationResultManagedAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const EditSitesAppConfigurationResultManagedApp: S.Schema<EditSitesAppConfigurationResultManagedApp>;
export type EditSitesAppConfigurationResult = EditSitesAppConfigurationResultAccountApp | EditSitesAppConfigurationResultManagedApp;
export declare const EditSitesAppConfigurationResult: any;
export type EditSitesAppConfigurationResponse = EditSitesAppConfigurationResult;
export declare const EditSitesAppConfigurationResponse: S.Schema<EditSitesAppConfigurationResponse>;
export interface EmptyRouteRequest {
    /** Identifier */
    accountId: string;
}
export declare const EmptyRouteRequest: S.Schema<EmptyRouteRequest>;
export type RoutesEmptyResponseDeletedRoutesItemScopeColoNamesList = Array<string>;
export declare const RoutesEmptyResponseDeletedRoutesItemScopeColoNamesList: S.Schema<RoutesEmptyResponseDeletedRoutesItemScopeColoNamesList>;
export type RoutesEmptyResponseDeletedRoutesItemScopeColoRegionsList = Array<string>;
export declare const RoutesEmptyResponseDeletedRoutesItemScopeColoRegionsList: S.Schema<RoutesEmptyResponseDeletedRoutesItemScopeColoRegionsList>;
export interface RoutesEmptyResponseDeletedRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesEmptyResponseDeletedRoutesItemScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesEmptyResponseDeletedRoutesItemScopeColoRegionsList | null;
}
export declare const RoutesEmptyResponseDeletedRoutesItemScope: S.Schema<RoutesEmptyResponseDeletedRoutesItemScope>;
export interface RoutesEmptyResponseDeletedRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesEmptyResponseDeletedRoutesItemScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const RoutesEmptyResponseDeletedRoutesItem: S.Schema<RoutesEmptyResponseDeletedRoutesItem>;
export type RoutesEmptyResponseDeletedRoutesList = Array<RoutesEmptyResponseDeletedRoutesItem>;
export declare const RoutesEmptyResponseDeletedRoutesList: S.Schema<RoutesEmptyResponseDeletedRoutesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EmptyRouteResponse {
    deleted?: boolean | null;
    deletedRoutes?: RoutesEmptyResponseDeletedRoutesList | null;
}
export declare const EmptyRouteResponse: S.Schema<EmptyRouteResponse>;
export interface GetCf1SiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
}
export declare const GetCf1SiteRequest: S.Schema<GetCf1SiteRequest>;
export type Cf1SitesGetResponseLocation = Cf1SitesCreateResultItemLocation;
export declare const Cf1SitesGetResponseLocation: S.Schema<Cf1SitesCreateResultItemLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCf1SiteResponse {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null;
    createdOn?: string | null;
    /** A human-provided description of the CF1 Site. */
    description?: string | null;
    location?: Cf1SitesCreateResultItemLocation | null;
    modifiedOn?: string | null;
}
export declare const GetCf1SiteResponse: S.Schema<GetCf1SiteResponse>;
export interface GetCf1SiteRampRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    /** Identifier */
    rampId: string;
}
export declare const GetCf1SiteRampRequest: S.Schema<GetCf1SiteRampRequest>;
export type Cf1SitesRampsGetResponseType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export declare const Cf1SitesRampsGetResponseType: any;
export type Cf1SitesRampsGetResponseGre = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsGetResponseGre: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsGetResponseGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsGetResponseGreInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsGetResponseIpsec = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsGetResponseIpsec: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsGetResponseMconn = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsGetResponseMconn: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsGetResponseMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsGetResponseMplsInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCf1SiteRampResponse {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsGetResponseType;
    /** A human-provided description of the ramp. */
    description?: string | null;
    gre?: Cf1SitesRampsCreateResultItemGre | null;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null;
    mconn?: Cf1SitesRampsCreateResultItemGre | null;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
}
export declare const GetCf1SiteRampResponse: S.Schema<GetCf1SiteRampResponse>;
export interface GetCfInterconnectRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cfInterconnectId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const GetCfInterconnectRequest: S.Schema<GetCfInterconnectRequest>;
export type CfInterconnectsGetResponseInterconnectGre = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre;
export declare const CfInterconnectsGetResponseInterconnectGre: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre>;
export type CfInterconnectsGetResponseInterconnectHealthCheckRate = "low" | "mid" | "high";
export declare const CfInterconnectsGetResponseInterconnectHealthCheckRate: any;
export type CfInterconnectsGetResponseInterconnectHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsGetResponseInterconnectHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type CfInterconnectsGetResponseInterconnectHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsGetResponseInterconnectHealthCheckTarget: any;
export type CfInterconnectsGetResponseInterconnectHealthCheckType = "reply" | "request";
export declare const CfInterconnectsGetResponseInterconnectHealthCheckType: any;
export interface CfInterconnectsGetResponseInterconnectHealthCheck {
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsGetResponseInterconnectHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsGetResponseInterconnectHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsGetResponseInterconnectHealthCheckType | null;
}
export declare const CfInterconnectsGetResponseInterconnectHealthCheck: S.Schema<CfInterconnectsGetResponseInterconnectHealthCheck>;
export interface CfInterconnectsGetResponseInterconnect {
    /** Identifier */
    id?: string | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the interconnect. */
    description?: string | null;
    /** The configuration specific to GRE interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null;
    healthCheck?: CfInterconnectsGetResponseInterconnectHealthCheck | null;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress?: string | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null;
}
export declare const CfInterconnectsGetResponseInterconnect: S.Schema<CfInterconnectsGetResponseInterconnect>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCfInterconnectResponse {
    interconnect?: CfInterconnectsGetResponseInterconnect | null;
}
export declare const GetCfInterconnectResponse: S.Schema<GetCfInterconnectResponse>;
export interface GetConnectorRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
}
export declare const GetConnectorRequest: S.Schema<GetConnectorRequest>;
export type ConnectorsGetResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsGetResponseInterruptWindowDaysOfWeekItem: any;
export type ConnectorsGetResponseInterruptWindowDaysOfWeekList = Array<ConnectorsGetResponseInterruptWindowDaysOfWeekItem>;
export declare const ConnectorsGetResponseInterruptWindowDaysOfWeekList: S.Schema<ConnectorsGetResponseInterruptWindowDaysOfWeekList>;
export type ConnectorsGetResponseInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsGetResponseInterruptWindowEmbargoDatesList: S.Schema<ConnectorsGetResponseInterruptWindowEmbargoDatesList>;
export type ConnectorsGetResponseDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsGetResponseDeviceType: any;
export interface ConnectorsGetResponseDevice {
    id: string;
    serialNumber?: string | null;
    type?: ConnectorsGetResponseDeviceType | null;
}
export declare const ConnectorsGetResponseDevice: S.Schema<ConnectorsGetResponseDevice>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsGetResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsGetResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    primary: boolean;
    timezone: string;
    device?: ConnectorsGetResponseDevice | null;
    lastHeartbeat?: string | null;
    lastSeenVersion?: string | null;
    licenseKey?: string | null;
    siteId?: string | null;
}
export declare const GetConnectorResponse: S.Schema<GetConnectorResponse>;
export interface GetConnectorEventRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    eventT: number;
    eventN: number;
}
export declare const GetConnectorEventRequest: S.Schema<GetConnectorEventRequest>;
export type ConnectorsEventsGetResponseEInitK = "Init";
export declare const ConnectorsEventsGetResponseEInitK: any;
export interface ConnectorsEventsGetResponseEInit {
    /** Initialized process */
    k: ConnectorsEventsGetResponseEInitK;
}
export declare const ConnectorsEventsGetResponseEInit: S.Schema<ConnectorsEventsGetResponseEInit>;
export type ConnectorsEventsGetResponseELeaveK = "Leave";
export declare const ConnectorsEventsGetResponseELeaveK: any;
export interface ConnectorsEventsGetResponseELeave {
    /** Stopped process */
    k: ConnectorsEventsGetResponseELeaveK;
}
export declare const ConnectorsEventsGetResponseELeave: S.Schema<ConnectorsEventsGetResponseELeave>;
export type ConnectorsEventsGetResponseEStartAttestationK = "StartAttestation";
export declare const ConnectorsEventsGetResponseEStartAttestationK: any;
export interface ConnectorsEventsGetResponseEStartAttestation {
    /** Started attestation */
    k: ConnectorsEventsGetResponseEStartAttestationK;
}
export declare const ConnectorsEventsGetResponseEStartAttestation: S.Schema<ConnectorsEventsGetResponseEStartAttestation>;
export type ConnectorsEventsGetResponseEFinishAttestationSuccessK = "FinishAttestationSuccess";
export declare const ConnectorsEventsGetResponseEFinishAttestationSuccessK: any;
export interface ConnectorsEventsGetResponseEFinishAttestationSuccess {
    /** Finished attestation */
    k: ConnectorsEventsGetResponseEFinishAttestationSuccessK;
}
export declare const ConnectorsEventsGetResponseEFinishAttestationSuccess: S.Schema<ConnectorsEventsGetResponseEFinishAttestationSuccess>;
export type ConnectorsEventsGetResponseEFinishAttestationFailureK = "FinishAttestationFailure";
export declare const ConnectorsEventsGetResponseEFinishAttestationFailureK: any;
export interface ConnectorsEventsGetResponseEFinishAttestationFailure {
    /** Failed attestation */
    k: ConnectorsEventsGetResponseEFinishAttestationFailureK;
}
export declare const ConnectorsEventsGetResponseEFinishAttestationFailure: S.Schema<ConnectorsEventsGetResponseEFinishAttestationFailure>;
export type ConnectorsEventsGetResponseEStartRotateCryptKeyK = "StartRotateCryptKey";
export declare const ConnectorsEventsGetResponseEStartRotateCryptKeyK: any;
export interface ConnectorsEventsGetResponseEStartRotateCryptKey {
    /** Started crypt key rotation */
    k: ConnectorsEventsGetResponseEStartRotateCryptKeyK;
}
export declare const ConnectorsEventsGetResponseEStartRotateCryptKey: S.Schema<ConnectorsEventsGetResponseEStartRotateCryptKey>;
export type ConnectorsEventsGetResponseEFinishRotateCryptKeySuccessK = "FinishRotateCryptKeySuccess";
export declare const ConnectorsEventsGetResponseEFinishRotateCryptKeySuccessK: any;
export interface ConnectorsEventsGetResponseEFinishRotateCryptKeySuccess {
    /** Finished crypt key rotation */
    k: ConnectorsEventsGetResponseEFinishRotateCryptKeySuccessK;
}
export declare const ConnectorsEventsGetResponseEFinishRotateCryptKeySuccess: S.Schema<ConnectorsEventsGetResponseEFinishRotateCryptKeySuccess>;
export type ConnectorsEventsGetResponseEFinishRotateCryptKeyFailureK = "FinishRotateCryptKeyFailure";
export declare const ConnectorsEventsGetResponseEFinishRotateCryptKeyFailureK: any;
export interface ConnectorsEventsGetResponseEFinishRotateCryptKeyFailure {
    /** Failed crypt key rotation */
    k: ConnectorsEventsGetResponseEFinishRotateCryptKeyFailureK;
}
export declare const ConnectorsEventsGetResponseEFinishRotateCryptKeyFailure: S.Schema<ConnectorsEventsGetResponseEFinishRotateCryptKeyFailure>;
export type ConnectorsEventsGetResponseEStartRotatePkiK = "StartRotatePki";
export declare const ConnectorsEventsGetResponseEStartRotatePkiK: any;
export interface ConnectorsEventsGetResponseEStartRotatePki {
    /** Started PKI rotation */
    k: ConnectorsEventsGetResponseEStartRotatePkiK;
}
export declare const ConnectorsEventsGetResponseEStartRotatePki: S.Schema<ConnectorsEventsGetResponseEStartRotatePki>;
export type ConnectorsEventsGetResponseEFinishRotatePkiSuccessK = "FinishRotatePkiSuccess";
export declare const ConnectorsEventsGetResponseEFinishRotatePkiSuccessK: any;
export interface ConnectorsEventsGetResponseEFinishRotatePkiSuccess {
    /** Finished PKI rotation */
    k: ConnectorsEventsGetResponseEFinishRotatePkiSuccessK;
}
export declare const ConnectorsEventsGetResponseEFinishRotatePkiSuccess: S.Schema<ConnectorsEventsGetResponseEFinishRotatePkiSuccess>;
export type ConnectorsEventsGetResponseEFinishRotatePkiFailureK = "FinishRotatePkiFailure";
export declare const ConnectorsEventsGetResponseEFinishRotatePkiFailureK: any;
export interface ConnectorsEventsGetResponseEFinishRotatePkiFailure {
    /** Failed PKI rotation */
    k: ConnectorsEventsGetResponseEFinishRotatePkiFailureK;
}
export declare const ConnectorsEventsGetResponseEFinishRotatePkiFailure: S.Schema<ConnectorsEventsGetResponseEFinishRotatePkiFailure>;
export type ConnectorsEventsGetResponseEStartUpgradeK = "StartUpgrade";
export declare const ConnectorsEventsGetResponseEStartUpgradeK: any;
export interface ConnectorsEventsGetResponseEStartUpgrade {
    /** Started upgrade */
    k: ConnectorsEventsGetResponseEStartUpgradeK;
    /** Location of upgrade bundle */
    url: string;
}
export declare const ConnectorsEventsGetResponseEStartUpgrade: S.Schema<ConnectorsEventsGetResponseEStartUpgrade>;
export type ConnectorsEventsGetResponseEFinishUpgradeSuccessK = "FinishUpgradeSuccess";
export declare const ConnectorsEventsGetResponseEFinishUpgradeSuccessK: any;
export interface ConnectorsEventsGetResponseEFinishUpgradeSuccess {
    /** Finished upgrade */
    k: ConnectorsEventsGetResponseEFinishUpgradeSuccessK;
}
export declare const ConnectorsEventsGetResponseEFinishUpgradeSuccess: S.Schema<ConnectorsEventsGetResponseEFinishUpgradeSuccess>;
export type ConnectorsEventsGetResponseEFinishUpgradeFailureK = "FinishUpgradeFailure";
export declare const ConnectorsEventsGetResponseEFinishUpgradeFailureK: any;
export interface ConnectorsEventsGetResponseEFinishUpgradeFailure {
    /** Failed upgrade */
    k: ConnectorsEventsGetResponseEFinishUpgradeFailureK;
}
export declare const ConnectorsEventsGetResponseEFinishUpgradeFailure: S.Schema<ConnectorsEventsGetResponseEFinishUpgradeFailure>;
export type ConnectorsEventsGetResponseEReconcileK = "Reconcile";
export declare const ConnectorsEventsGetResponseEReconcileK: any;
export interface ConnectorsEventsGetResponseEReconcile {
    /** Reconciled */
    k: ConnectorsEventsGetResponseEReconcileK;
}
export declare const ConnectorsEventsGetResponseEReconcile: S.Schema<ConnectorsEventsGetResponseEReconcile>;
export type ConnectorsEventsGetResponseEConfigureCloudflaredTunnelK = "ConfigureCloudflaredTunnel";
export declare const ConnectorsEventsGetResponseEConfigureCloudflaredTunnelK: any;
export interface ConnectorsEventsGetResponseEConfigureCloudflaredTunnel {
    /** Configured Cloudflared tunnel */
    k: ConnectorsEventsGetResponseEConfigureCloudflaredTunnelK;
}
export declare const ConnectorsEventsGetResponseEConfigureCloudflaredTunnel: S.Schema<ConnectorsEventsGetResponseEConfigureCloudflaredTunnel>;
export type ConnectorsEventsGetResponseERekeyInstallBothK = "RekeyInstallBoth";
export declare const ConnectorsEventsGetResponseERekeyInstallBothK: any;
export interface ConnectorsEventsGetResponseERekeyInstallBoth {
    /** Installed initial inbound and outbound keys */
    k: ConnectorsEventsGetResponseERekeyInstallBothK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsGetResponseERekeyInstallBoth: S.Schema<ConnectorsEventsGetResponseERekeyInstallBoth>;
export type ConnectorsEventsGetResponseERekeyStartK = "RekeyStart";
export declare const ConnectorsEventsGetResponseERekeyStartK: any;
export interface ConnectorsEventsGetResponseERekeyStart {
    /** Installed new inbound key, kept old outbound */
    k: ConnectorsEventsGetResponseERekeyStartK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsGetResponseERekeyStart: S.Schema<ConnectorsEventsGetResponseERekeyStart>;
export type ConnectorsEventsGetResponseERekeyAdvanceK = "RekeyAdvance";
export declare const ConnectorsEventsGetResponseERekeyAdvanceK: any;
export interface ConnectorsEventsGetResponseERekeyAdvance {
    /** Confirmed traffic on new inbound key, swapped outbound to new */
    k: ConnectorsEventsGetResponseERekeyAdvanceK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsGetResponseERekeyAdvance: S.Schema<ConnectorsEventsGetResponseERekeyAdvance>;
export type ConnectorsEventsGetResponseERekeyCompleteK = "RekeyComplete";
export declare const ConnectorsEventsGetResponseERekeyCompleteK: any;
export interface ConnectorsEventsGetResponseERekeyComplete {
    /** Deleted old keys */
    k: ConnectorsEventsGetResponseERekeyCompleteK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsGetResponseERekeyComplete: S.Schema<ConnectorsEventsGetResponseERekeyComplete>;
export type ConnectorsEventsGetResponseERekeyResetK = "RekeyReset";
export declare const ConnectorsEventsGetResponseERekeyResetK: any;
export interface ConnectorsEventsGetResponseERekeyReset {
    /** Deleted all keys after receiving an unexpected key */
    k: ConnectorsEventsGetResponseERekeyResetK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsGetResponseERekeyReset: S.Schema<ConnectorsEventsGetResponseERekeyReset>;
export type ConnectorsEventsGetResponseE = ConnectorsEventsGetResponseEInit | ConnectorsEventsGetResponseELeave | ConnectorsEventsGetResponseEStartAttestation | ConnectorsEventsGetResponseEFinishAttestationSuccess | ConnectorsEventsGetResponseEFinishAttestationFailure | ConnectorsEventsGetResponseEStartRotateCryptKey | ConnectorsEventsGetResponseEFinishRotateCryptKeySuccess | ConnectorsEventsGetResponseEFinishRotateCryptKeyFailure | ConnectorsEventsGetResponseEStartRotatePki | ConnectorsEventsGetResponseEFinishRotatePkiSuccess | ConnectorsEventsGetResponseEFinishRotatePkiFailure | ConnectorsEventsGetResponseEStartUpgrade | ConnectorsEventsGetResponseEFinishUpgradeSuccess | ConnectorsEventsGetResponseEFinishUpgradeFailure | ConnectorsEventsGetResponseEReconcile | ConnectorsEventsGetResponseEConfigureCloudflaredTunnel | ConnectorsEventsGetResponseERekeyInstallBoth | ConnectorsEventsGetResponseERekeyStart | ConnectorsEventsGetResponseERekeyAdvance | ConnectorsEventsGetResponseERekeyComplete | ConnectorsEventsGetResponseERekeyReset;
export declare const ConnectorsEventsGetResponseE: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectorEventResponse {
    e: ConnectorsEventsGetResponseE;
    /** Sequence number, used to order events with the same timestamp */
    n: number;
    /** Time the Event was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v?: string | null;
}
export declare const GetConnectorEventResponse: S.Schema<GetConnectorEventResponse>;
export interface GetConnectorSnapshotRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    snapshotT: number;
}
export declare const GetConnectorSnapshotRequest: S.Schema<GetConnectorSnapshotRequest>;
export interface ConnectorsSnapshotsGetResponseBondsItem {
    /** Name of the network interface */
    name: string;
    /** Current status of the network interface */
    status: string;
}
export declare const ConnectorsSnapshotsGetResponseBondsItem: S.Schema<ConnectorsSnapshotsGetResponseBondsItem>;
export type ConnectorsSnapshotsGetResponseBondsList = Array<ConnectorsSnapshotsGetResponseBondsItem>;
export declare const ConnectorsSnapshotsGetResponseBondsList: S.Schema<ConnectorsSnapshotsGetResponseBondsList>;
export interface ConnectorsSnapshotsGetResponseDhcpLeasesItem {
    /** Client ID of the device the IP Address was leased to */
    clientId: string;
    /** Expiry time of the DHCP lease (seconds since the Unix epoch) */
    expiryTime: number;
    /** Hostname of the device the IP Address was leased to */
    hostname: string;
    /** Name of the network interface */
    interfaceName: string;
    /** IP Address that was leased */
    ipAddress: string;
    /** MAC Address of the device the IP Address was leased to */
    macAddress: string;
}
export declare const ConnectorsSnapshotsGetResponseDhcpLeasesItem: S.Schema<ConnectorsSnapshotsGetResponseDhcpLeasesItem>;
export type ConnectorsSnapshotsGetResponseDhcpLeasesList = Array<ConnectorsSnapshotsGetResponseDhcpLeasesItem>;
export declare const ConnectorsSnapshotsGetResponseDhcpLeasesList: S.Schema<ConnectorsSnapshotsGetResponseDhcpLeasesList>;
export interface ConnectorsSnapshotsGetResponseDisksItem {
    /** I/Os currently in progress */
    inProgress: number;
    /** Device major number */
    major: number;
    /** Reads merged */
    merged: number;
    /** Device minor number */
    minor: number;
    /** Device name */
    name: string;
    /** Reads completed successfully */
    reads: number;
    /** Sectors read successfully */
    sectorsRead: number;
    /** Sectors written successfully */
    sectorsWritten: number;
    /** Time spent doing I/Os (milliseconds) */
    timeInProgressMs: number;
    /** Time spent reading (milliseconds) */
    timeReadingMs: number;
    /** Time spent writing (milliseconds) */
    timeWritingMs: number;
    /** Weighted time spent doing I/Os (milliseconds) */
    weightedTimeInProgressMs: number;
    /** Writes completed */
    writes: number;
    /** Writes merged */
    writesMerged: number;
    /** Discards completed successfully */
    discards?: number | null;
    /** Discards merged */
    discardsMerged?: number | null;
    /** Flushes completed successfully */
    flushes?: number | null;
    /** Sectors discarded */
    sectorsDiscarded?: number | null;
    /** Time spent discarding (milliseconds) */
    timeDiscardingMs?: number | null;
    /** Time spent flushing (milliseconds) */
    timeFlushingMs?: number | null;
}
export declare const ConnectorsSnapshotsGetResponseDisksItem: S.Schema<ConnectorsSnapshotsGetResponseDisksItem>;
export type ConnectorsSnapshotsGetResponseDisksList = Array<ConnectorsSnapshotsGetResponseDisksItem>;
export declare const ConnectorsSnapshotsGetResponseDisksList: S.Schema<ConnectorsSnapshotsGetResponseDisksList>;
export interface ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem {
    /** Name of the network interface */
    interfaceName: string;
    /** IP address of the network interface */
    ipAddress: string;
}
export declare const ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem: S.Schema<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem>;
export type ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesList = Array<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem>;
export declare const ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesList: S.Schema<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesList>;
export interface ConnectorsSnapshotsGetResponseInterfacesItem {
    /** Name of the network interface */
    name: string;
    /** UP/DOWN state of the network interface */
    operstate: string;
    ipAddresses?: ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesList | null;
    /** Speed of the network interface (bits per second) */
    speed?: number | null;
}
export declare const ConnectorsSnapshotsGetResponseInterfacesItem: S.Schema<ConnectorsSnapshotsGetResponseInterfacesItem>;
export type ConnectorsSnapshotsGetResponseInterfacesList = Array<ConnectorsSnapshotsGetResponseInterfacesItem>;
export declare const ConnectorsSnapshotsGetResponseInterfacesList: S.Schema<ConnectorsSnapshotsGetResponseInterfacesList>;
export interface ConnectorsSnapshotsGetResponseMountsItem {
    /** File system on disk (EXT4, NTFS, etc.) */
    fileSystem: string;
    /** Kind of disk (HDD, SSD, etc.) */
    kind: string;
    /** Path where disk is mounted */
    mountPoint: string;
    /** Name of the disk mount */
    name: string;
    /** Available disk size (bytes) */
    availableBytes?: number | null;
    /** Available inodes on filesystem */
    availableInodes?: number | null;
    /** Determines whether the disk is read-only */
    isReadOnly?: boolean | null;
    /** Determines whether the disk is removable */
    isRemovable?: boolean | null;
    /** Total disk size (bytes) */
    totalBytes?: number | null;
    /** Total inodes on filesystem */
    totalInodes?: number | null;
}
export declare const ConnectorsSnapshotsGetResponseMountsItem: S.Schema<ConnectorsSnapshotsGetResponseMountsItem>;
export type ConnectorsSnapshotsGetResponseMountsList = Array<ConnectorsSnapshotsGetResponseMountsItem>;
export declare const ConnectorsSnapshotsGetResponseMountsList: S.Schema<ConnectorsSnapshotsGetResponseMountsList>;
export interface ConnectorsSnapshotsGetResponseNetdevsItem {
    /** Name of the network device */
    name: string;
    /** Total bytes received */
    recvBytes: number;
    /** Compressed packets received */
    recvCompressed: number;
    /** Packets dropped */
    recvDrop: number;
    /** Bad packets received */
    recvErrs: number;
    /** FIFO overruns */
    recvFifo: number;
    /** Frame alignment errors */
    recvFrame: number;
    /** Multicast packets received */
    recvMulticast: number;
    /** Total packets received */
    recvPackets: number;
    /** Total bytes transmitted */
    sentBytes: number;
    /** Number of packets not sent due to carrier errors */
    sentCarrier: number;
    /** Number of collisions */
    sentColls: number;
    /** Number of compressed packets transmitted */
    sentCompressed: number;
    /** Number of packets dropped during transmission */
    sentDrop: number;
    /** Number of transmission errors */
    sentErrs: number;
    /** FIFO overruns */
    sentFifo: number;
    /** Total packets transmitted */
    sentPackets: number;
}
export declare const ConnectorsSnapshotsGetResponseNetdevsItem: S.Schema<ConnectorsSnapshotsGetResponseNetdevsItem>;
export type ConnectorsSnapshotsGetResponseNetdevsList = Array<ConnectorsSnapshotsGetResponseNetdevsItem>;
export declare const ConnectorsSnapshotsGetResponseNetdevsList: S.Schema<ConnectorsSnapshotsGetResponseNetdevsList>;
export interface ConnectorsSnapshotsGetResponseThermalsItem {
    /** Sensor identifier for the component */
    label: string;
    /** Critical failure temperature of the component (degrees Celsius) */
    criticalCelcius?: number | null;
    /** Current temperature of the component (degrees Celsius) */
    currentCelcius?: number | null;
    /** Maximum temperature of the component (degrees Celsius) */
    maxCelcius?: number | null;
}
export declare const ConnectorsSnapshotsGetResponseThermalsItem: S.Schema<ConnectorsSnapshotsGetResponseThermalsItem>;
export type ConnectorsSnapshotsGetResponseThermalsList = Array<ConnectorsSnapshotsGetResponseThermalsItem>;
export declare const ConnectorsSnapshotsGetResponseThermalsList: S.Schema<ConnectorsSnapshotsGetResponseThermalsList>;
export interface ConnectorsSnapshotsGetResponseTunnelsItem {
    /** Name of tunnel health state (unknown, healthy, degraded, down) */
    healthState: string;
    /** Numeric value associated with tunnel state (0 = unknown, 1 = healthy, 2 = degraded, 3 = down) */
    healthValue: number;
    /** The tunnel interface name (i.e. xfrm1, xfrm3.99, etc.) */
    interfaceName: string;
    /** Tunnel identifier */
    tunnelId: string;
    /** Public socket address returned by the NAT detector */
    natdResult?: string | null;
    /** Numeric NAT detector state (0 = detected, 1 = missing result, 2 = stale result) */
    natdState?: number | null;
    /** Target socket address probed by the NAT detector, using the detector source port */
    natdTarget?: string | null;
    /** MTU as measured between the two ends of the tunnel */
    probedMtu?: number | null;
    /** Number of recent healthy pings for this tunnel */
    recentHealthyPings?: number | null;
    /** Number of recent unhealthy pings for this tunnel */
    recentUnhealthyPings?: number | null;
}
export declare const ConnectorsSnapshotsGetResponseTunnelsItem: S.Schema<ConnectorsSnapshotsGetResponseTunnelsItem>;
export type ConnectorsSnapshotsGetResponseTunnelsList = Array<ConnectorsSnapshotsGetResponseTunnelsItem>;
export declare const ConnectorsSnapshotsGetResponseTunnelsList: S.Schema<ConnectorsSnapshotsGetResponseTunnelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectorSnapshotResponse {
    /** Count of failures to reclaim space */
    countReclaimFailures: number;
    /** Count of reclaimed paths */
    countReclaimedPaths: number;
    /** Count of failed snapshot recordings */
    countRecordFailed: number;
    /** Count of failed snapshot transmissions */
    countTransmitFailures: number;
    /** Time the Snapshot was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v: string;
    bonds?: ConnectorsSnapshotsGetResponseBondsList | null;
    /** Count of processors/cores */
    cpuCount?: number | null;
    /** Percentage of time over a 10 second window that tasks were stalled */
    cpu_pressure_10s?: number | null;
    /** Percentage of time over a 5 minute window that tasks were stalled */
    cpu_pressure_300s?: number | null;
    /** Percentage of time over a 1 minute window that tasks were stalled */
    cpu_pressure_60s?: number | null;
    /** Total stall time (microseconds) */
    cpuPressureTotalUs?: number | null;
    /** Time spent running a virtual CPU or guest OS (milliseconds) */
    cpuTimeGuestMs?: number | null;
    /** Time spent running a niced guest (milliseconds) */
    cpuTimeGuestNiceMs?: number | null;
    /** Time spent in idle state (milliseconds) */
    cpuTimeIdleMs?: number | null;
    /** Time spent wait for I/O to complete (milliseconds) */
    cpuTimeIowaitMs?: number | null;
    /** Time spent servicing interrupts (milliseconds) */
    cpuTimeIrqMs?: number | null;
    /** Time spent in low-priority user mode (milliseconds) */
    cpuTimeNiceMs?: number | null;
    /** Time spent servicing softirqs (milliseconds) */
    cpuTimeSoftirqMs?: number | null;
    /** Time stolen (milliseconds) */
    cpuTimeStealMs?: number | null;
    /** Time spent in system mode (milliseconds) */
    cpuTimeSystemMs?: number | null;
    /** Time spent in user mode (milliseconds) */
    cpuTimeUserMs?: number | null;
    /** Number of network operations applied during state transition */
    delta?: number | null;
    dhcpLeases?: ConnectorsSnapshotsGetResponseDhcpLeasesList | null;
    disks?: ConnectorsSnapshotsGetResponseDisksList | null;
    /** Simulated number of network operations applied during state transition */
    epsilon?: number | null;
    /** Name of high availability state */
    haState?: string | null;
    /** Numeric value associated with high availability state (0 = disabled, 1 = active, 2 = standby, 3 = stopped, 4 = fault) */
    haValue?: number | null;
    interfaces?: ConnectorsSnapshotsGetResponseInterfacesList | null;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    io_pressure_full_10s?: number | null;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    io_pressure_full_300s?: number | null;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    io_pressure_full_60s?: number | null;
    /** Total stall time (microseconds) */
    ioPressureFullTotalUs?: number | null;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    io_pressure_some_10s?: number | null;
    /** Percentage of time over a 3 minute window that some tasks were stalled */
    io_pressure_some_300s?: number | null;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    io_pressure_some_60s?: number | null;
    /** Total stall time (microseconds) */
    ioPressureSomeTotalUs?: number | null;
    /** Boot time (seconds since Unix epoch) */
    kernelBtime?: number | null;
    /** Number of context switches that the system underwent */
    kernelCtxt?: number | null;
    /** Number of forks since boot */
    kernelProcesses?: number | null;
    /** Number of processes blocked waiting for I/O */
    kernelProcessesBlocked?: number | null;
    /** Number of processes in runnable state */
    kernelProcessesRunning?: number | null;
    /** The fifteen-minute load average */
    load_average_15m?: number | null;
    /** The one-minute load average */
    load_average_1m?: number | null;
    /** The five-minute load average */
    load_average_5m?: number | null;
    /** Number of currently runnable kernel scheduling entities */
    loadAverageCur?: number | null;
    /** Number of kernel scheduling entities that currently exist on the system */
    loadAverageMax?: number | null;
    /** Memory that has been used more recently */
    memoryActiveBytes?: number | null;
    /** Non-file backed huge pages mapped into user-space page tables */
    memoryAnonHugepagesBytes?: number | null;
    /** Non-file backed pages mapped into user-space page tables */
    memoryAnonPagesBytes?: number | null;
    /** Estimate of how much memory is available for starting new applications */
    memoryAvailableBytes?: number | null;
    /** Memory used for block device bounce buffers */
    memoryBounceBytes?: number | null;
    /** Relatively temporary storage for raw disk blocks */
    memoryBuffersBytes?: number | null;
    /** In-memory cache for files read from the disk */
    memoryCachedBytes?: number | null;
    /** Free CMA (Contiguous Memory Allocator) pages */
    memoryCmaFreeBytes?: number | null;
    /** Total CMA (Contiguous Memory Allocator) pages */
    memoryCmaTotalBytes?: number | null;
    /** Total amount of memory currently available to be allocated on the system */
    memoryCommitLimitBytes?: number | null;
    /** Amount of memory presently allocated on the system */
    memoryCommittedAsBytes?: number | null;
    /** Memory which is waiting to get written back to the disk */
    memoryDirtyBytes?: number | null;
    /** The sum of LowFree and HighFree */
    memoryFreeBytes?: number | null;
    /** Amount of free highmem */
    memoryHighFreeBytes?: number | null;
    /** Total amount of highmem */
    memoryHighTotalBytes?: number | null;
    /** The number of huge pages in the pool that are not yet allocated */
    memoryHugepagesFree?: number | null;
    /** Number of huge pages for which a commitment has been made, but no allocation has yet been made */
    memoryHugepagesRsvd?: number | null;
    /** Number of huge pages in the pool above the threshold */
    memoryHugepagesSurp?: number | null;
    /** The size of the pool of huge pages */
    memoryHugepagesTotal?: number | null;
    /** The size of huge pages */
    memoryHugepagesizeBytes?: number | null;
    /** Memory which has been less recently used */
    memoryInactiveBytes?: number | null;
    /** Kernel allocations that the kernel will attempt to reclaim under memory pressure */
    memoryKReclaimableBytes?: number | null;
    /** Amount of memory allocated to kernel stacks */
    memoryKernelStackBytes?: number | null;
    /** Amount of free lowmem */
    memoryLowFreeBytes?: number | null;
    /** Total amount of lowmem */
    memoryLowTotalBytes?: number | null;
    /** Files which have been mapped into memory */
    memoryMappedBytes?: number | null;
    /** Amount of memory dedicated to the lowest level of page tables */
    memoryPageTablesBytes?: number | null;
    /** Memory allocated to the per-cpu alloctor used to back per-cpu allocations */
    memoryPerCpuBytes?: number | null;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    memory_pressure_full_10s?: number | null;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    memory_pressure_full_300s?: number | null;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    memory_pressure_full_60s?: number | null;
    /** Total stall time (microseconds) */
    memoryPressureFullTotalUs?: number | null;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    memory_pressure_some_10s?: number | null;
    /** Percentage of time over a 5 minute window that some tasks were stalled */
    memory_pressure_some_300s?: number | null;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    memory_pressure_some_60s?: number | null;
    /** Total stall time (microseconds) */
    memoryPressureSomeTotalUs?: number | null;
    /** Part of slab that can be reclaimed on memory pressure */
    memorySReclaimableBytes?: number | null;
    /** Part of slab that cannot be reclaimed on memory pressure */
    memorySUnreclaimBytes?: number | null;
    /** Amount of memory dedicated to the lowest level of page tables */
    memorySecondaryPageTablesBytes?: number | null;
    /** Amount of memory consumed by tmpfs */
    memoryShmemBytes?: number | null;
    /** Memory used by shmem and tmpfs, allocated with huge pages */
    memoryShmemHugepagesBytes?: number | null;
    /** Shared memory mapped into user space with huge pages */
    memoryShmemPmdMappedBytes?: number | null;
    /** In-kernel data structures cache */
    memorySlabBytes?: number | null;
    /** Memory swapped out and back in while still in swap file */
    memorySwapCachedBytes?: number | null;
    /** Amount of swap space that is currently unused */
    memorySwapFreeBytes?: number | null;
    /** Total amount of swap space available */
    memorySwapTotalBytes?: number | null;
    /** Total usable RAM */
    memoryTotalBytes?: number | null;
    /** Largest contiguous block of vmalloc area which is free */
    memoryVmallocChunkBytes?: number | null;
    /** Total size of vmalloc memory area */
    memoryVmallocTotalBytes?: number | null;
    /** Amount of vmalloc area which is used */
    memoryVmallocUsedBytes?: number | null;
    /** Memory which is actively being written back to the disk */
    memoryWritebackBytes?: number | null;
    /** Memory used by FUSE for temporary writeback buffers */
    memoryWritebackTmpBytes?: number | null;
    /** Memory consumed by the zswap backend, compressed */
    memoryZSwapBytes?: number | null;
    /** Amount of anonymous memory stored in zswap, uncompressed */
    memoryZSwappedBytes?: number | null;
    mounts?: ConnectorsSnapshotsGetResponseMountsList | null;
    netdevs?: ConnectorsSnapshotsGetResponseNetdevsList | null;
    /** Platform identifier */
    platform?: string | null;
    /** Number of ICMP Address Mask Reply messages received */
    snmpIcmpInAddrMaskReps?: number | null;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInAddrMasks?: number | null;
    /** Number of ICMP messages received with bad checksums */
    snmpIcmpInCsumErrors?: number | null;
    /** Number of ICMP Destination Unreachable messages received */
    snmpIcmpInDestUnreachs?: number | null;
    /** Number of ICMP Echo Reply messages received */
    snmpIcmpInEchoReps?: number | null;
    /** Number of ICMP Echo (request) messages received */
    snmpIcmpInEchos?: number | null;
    /** Number of ICMP messages received with ICMP-specific errors */
    snmpIcmpInErrors?: number | null;
    /** Number of ICMP messages received */
    snmpIcmpInMsgs?: number | null;
    /** Number of ICMP Parameter Problem messages received */
    snmpIcmpInParmProbs?: number | null;
    /** Number of ICMP Redirect messages received */
    snmpIcmpInRedirects?: number | null;
    /** Number of ICMP Source Quench messages received */
    snmpIcmpInSrcQuenchs?: number | null;
    /** Number of ICMP Time Exceeded messages received */
    snmpIcmpInTimeExcds?: number | null;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInTimestampReps?: number | null;
    /** Number of ICMP Timestamp (request) messages received */
    snmpIcmpInTimestamps?: number | null;
    /** Number of ICMP Address Mask Reply messages sent */
    snmpIcmpOutAddrMaskReps?: number | null;
    /** Number of ICMP Address Mask Request messages sent */
    snmpIcmpOutAddrMasks?: number | null;
    /** Number of ICMP Destination Unreachable messages sent */
    snmpIcmpOutDestUnreachs?: number | null;
    /** Number of ICMP Echo Reply messages sent */
    snmpIcmpOutEchoReps?: number | null;
    /** Number of ICMP Echo (request) messages sent */
    snmpIcmpOutEchos?: number | null;
    /** Number of ICMP messages which this entity did not send due to ICMP-specific errors */
    snmpIcmpOutErrors?: number | null;
    /** Number of ICMP messages attempted to send */
    snmpIcmpOutMsgs?: number | null;
    /** Number of ICMP Parameter Problem messages sent */
    snmpIcmpOutParmProbs?: number | null;
    /** Number of ICMP Redirect messages sent */
    snmpIcmpOutRedirects?: number | null;
    /** Number of ICMP Source Quench messages sent */
    snmpIcmpOutSrcQuenchs?: number | null;
    /** Number of ICMP Time Exceeded messages sent */
    snmpIcmpOutTimeExcds?: number | null;
    /** Number of ICMP Timestamp Reply messages sent */
    snmpIcmpOutTimestampReps?: number | null;
    /** Number of ICMP Timestamp (request) messages sent */
    snmpIcmpOutTimestamps?: number | null;
    /** Default value of the Time-To-Live field of the IP header */
    snmpIpDefaultTtl?: number | null;
    /** Number of datagrams forwarded to their final destination */
    snmpIpForwDatagrams?: number | null;
    /** Set when acting as an IP gateway */
    snmpIpForwardingEnabled?: boolean | null;
    /** Number of datagrams generated by fragmentation */
    snmpIpFragCreates?: number | null;
    /** Number of datagrams discarded because fragmentation failed */
    snmpIpFragFails?: number | null;
    /** Number of datagrams successfully fragmented */
    snmpIpFragOks?: number | null;
    /** Number of input datagrams discarded due to errors in the IP address */
    snmpIpInAddrErrors?: number | null;
    /** Number of input datagrams successfully delivered to IP user-protocols */
    snmpIpInDelivers?: number | null;
    /** Number of input datagrams otherwise discarded */
    snmpIpInDiscards?: number | null;
    /** Number of input datagrams discarded due to errors in the IP header */
    snmpIpInHdrErrors?: number | null;
    /** Number of input datagrams received from interfaces */
    snmpIpInReceives?: number | null;
    /** Number of input datagrams discarded due unknown or unsupported protocol */
    snmpIpInUnknownProtos?: number | null;
    /** Number of output datagrams otherwise discarded */
    snmpIpOutDiscards?: number | null;
    /** Number of output datagrams discarded because no route matched */
    snmpIpOutNoRoutes?: number | null;
    /** Number of datagrams supplied for transmission */
    snmpIpOutRequests?: number | null;
    /** Number of failures detected by the reassembly algorithm */
    snmpIpReasmFails?: number | null;
    /** Number of datagrams successfully reassembled */
    snmpIpReasmOks?: number | null;
    /** Number of fragments received which needed to be reassembled */
    snmpIpReasmReqds?: number | null;
    /** Number of seconds fragments are held while awaiting reassembly */
    snmpIpReasmTimeout?: number | null;
    /** Number of times TCP transitions to SYN-SENT from CLOSED */
    snmpTcpActiveOpens?: number | null;
    /** Number of times TCP transitions to CLOSED from SYN-SENT or SYN-RCVD, plus transitions to LISTEN from SYN-RCVD */
    snmpTcpAttemptFails?: number | null;
    /** Number of TCP connections in ESTABLISHED or CLOSE-WAIT */
    snmpTcpCurrEstab?: number | null;
    /** Number of times TCP transitions to CLOSED from ESTABLISHED or CLOSE-WAIT */
    snmpTcpEstabResets?: number | null;
    /** Number of TCP segments received with checksum errors */
    snmpTcpInCsumErrors?: number | null;
    /** Number of TCP segments received in error */
    snmpTcpInErrs?: number | null;
    /** Number of TCP segments received */
    snmpTcpInSegs?: number | null;
    /** Limit on the total number of TCP connections */
    snmpTcpMaxConn?: number | null;
    /** Number of TCP segments sent with RST flag */
    snmpTcpOutRsts?: number | null;
    /** Number of TCP segments sent */
    snmpTcpOutSegs?: number | null;
    /** Number of times TCP transitions to SYN-RCVD from LISTEN */
    snmpTcpPassiveOpens?: number | null;
    /** Number of TCP segments retransmitted */
    snmpTcpRetransSegs?: number | null;
    /** Maximum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMax?: number | null;
    /** Minimum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMin?: number | null;
    /** Number of UDP datagrams delivered to UDP applications */
    snmpUdpInDatagrams?: number | null;
    /** Number of UDP datagrams failed to be delivered for reasons other than lack of application at the destination port */
    snmpUdpInErrors?: number | null;
    /** Number of UDP datagrams received for which there was not application at the destination port */
    snmpUdpNoPorts?: number | null;
    /** Number of UDP datagrams sent */
    snmpUdpOutDatagrams?: number | null;
    /** Boottime of the system (seconds since the Unix epoch) */
    systemBootTimeS?: number | null;
    thermals?: ConnectorsSnapshotsGetResponseThermalsList | null;
    tunnels?: ConnectorsSnapshotsGetResponseTunnelsList | null;
    /** Sum of how much time each core has spent idle */
    uptimeIdleMs?: number | null;
    /** Uptime of the system, including time spent in suspend */
    uptimeTotalMs?: number | null;
}
export declare const GetConnectorSnapshotResponse: S.Schema<GetConnectorSnapshotResponse>;
export interface GetGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    greTunnelId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const GetGreTunnelRequest: S.Schema<GetGreTunnelRequest>;
export type GreTunnelsGetResponseGreTunnelBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsGetResponseGreTunnelBgpExtraPrefixesList: S.Schema<GreTunnelsGetResponseGreTunnelBgpExtraPrefixesList>;
export interface GreTunnelsGetResponseGreTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsGetResponseGreTunnelBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const GreTunnelsGetResponseGreTunnelBgp: S.Schema<GreTunnelsGetResponseGreTunnelBgp>;
export type GreTunnelsGetResponseGreTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const GreTunnelsGetResponseGreTunnelBgpStatusState: any;
export interface GreTunnelsGetResponseGreTunnelBgpStatus {
    state: GreTunnelsGetResponseGreTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const GreTunnelsGetResponseGreTunnelBgpStatus: S.Schema<GreTunnelsGetResponseGreTunnelBgpStatus>;
export type GreTunnelsGetResponseGreTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsGetResponseGreTunnelHealthCheckDirection: any;
export type GreTunnelsGetResponseGreTunnelHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsGetResponseGreTunnelHealthCheckRate: any;
export type GreTunnelsGetResponseGreTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsGetResponseGreTunnelHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsGetResponseGreTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsGetResponseGreTunnelHealthCheckTarget: any;
export type GreTunnelsGetResponseGreTunnelHealthCheckType = "reply" | "request";
export declare const GreTunnelsGetResponseGreTunnelHealthCheckType: any;
export interface GreTunnelsGetResponseGreTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsGetResponseGreTunnelHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsGetResponseGreTunnelHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsGetResponseGreTunnelHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsGetResponseGreTunnelHealthCheckType | null;
}
export declare const GreTunnelsGetResponseGreTunnelHealthCheck: S.Schema<GreTunnelsGetResponseGreTunnelHealthCheck>;
export interface GreTunnelsGetResponseGreTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: GreTunnelsGetResponseGreTunnelBgp | null;
    bgpStatus?: GreTunnelsGetResponseGreTunnelBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the GRE tunnel. */
    description?: string | null;
    healthCheck?: GreTunnelsGetResponseGreTunnelHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null;
}
export declare const GreTunnelsGetResponseGreTunnel: S.Schema<GreTunnelsGetResponseGreTunnel>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetGreTunnelResponse {
    greTunnel?: GreTunnelsGetResponseGreTunnel | null;
}
export declare const GetGreTunnelResponse: S.Schema<GetGreTunnelResponse>;
export interface GetIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const GetIpsecTunnelRequest: S.Schema<GetIpsecTunnelRequest>;
export type IpsecTunnelsGetResponseIpsecTunnelBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsGetResponseIpsecTunnelBgpExtraPrefixesList: S.Schema<IpsecTunnelsGetResponseIpsecTunnelBgpExtraPrefixesList>;
export interface IpsecTunnelsGetResponseIpsecTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsGetResponseIpsecTunnelBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const IpsecTunnelsGetResponseIpsecTunnelBgp: S.Schema<IpsecTunnelsGetResponseIpsecTunnelBgp>;
export type IpsecTunnelsGetResponseIpsecTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const IpsecTunnelsGetResponseIpsecTunnelBgpStatusState: any;
export interface IpsecTunnelsGetResponseIpsecTunnelBgpStatus {
    state: IpsecTunnelsGetResponseIpsecTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const IpsecTunnelsGetResponseIpsecTunnelBgpStatus: S.Schema<IpsecTunnelsGetResponseIpsecTunnelBgpStatus>;
export type IpsecTunnelsGetResponseIpsecTunnelCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export declare const IpsecTunnelsGetResponseIpsecTunnelCustomRemoteIdentities: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities>;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsGetResponseIpsecTunnelHealthCheckDirection: any;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsGetResponseIpsecTunnelHealthCheckRate: any;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsGetResponseIpsecTunnelHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsGetResponseIpsecTunnelHealthCheckTarget: any;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsGetResponseIpsecTunnelHealthCheckType: any;
export interface IpsecTunnelsGetResponseIpsecTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckType | null;
}
export declare const IpsecTunnelsGetResponseIpsecTunnelHealthCheck: S.Schema<IpsecTunnelsGetResponseIpsecTunnelHealthCheck>;
export type IpsecTunnelsGetResponseIpsecTunnelPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsGetResponseIpsecTunnelPskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
export interface IpsecTunnelsGetResponseIpsecTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: IpsecTunnelsGetResponseIpsecTunnelBgp | null;
    bgpStatus?: IpsecTunnelsGetResponseIpsecTunnelBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null;
    healthCheck?: IpsecTunnelsGetResponseIpsecTunnelHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null;
}
export declare const IpsecTunnelsGetResponseIpsecTunnel: S.Schema<IpsecTunnelsGetResponseIpsecTunnel>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIpsecTunnelResponse {
    ipsecTunnel?: IpsecTunnelsGetResponseIpsecTunnel | null;
}
export declare const GetIpsecTunnelResponse: S.Schema<GetIpsecTunnelResponse>;
export interface GetPcapRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    pcapId: string;
}
export declare const GetPcapRequest: S.Schema<GetPcapRequest>;
export type PcapsGetResultPCAPFilterV1 = PcapsCreateResultPCAPFilterV1;
export declare const PcapsGetResultPCAPFilterV1: S.Schema<PcapsCreateResultPCAPFilterV1>;
export type PcapsGetResultPCAPStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export declare const PcapsGetResultPCAPStatus: any;
export type PcapsGetResultPCAPSystem = "magic-transit";
export declare const PcapsGetResultPCAPSystem: any;
export type PcapsGetResultPCAPType = "simple" | "full";
export declare const PcapsGetResultPCAPType: any;
export interface PcapsGetResultPCAP {
    /** The ID for the packet capture. */
    id?: string | null;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | null;
    /** The status of the packet capture request. */
    status?: PcapsGetResultPCAPStatus | null;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null;
    /** The system used to collect packet captures. */
    system?: PcapsGetResultPCAPSystem | null;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsGetResultPCAPType | null;
}
export declare const PcapsGetResultPCAP: S.Schema<PcapsGetResultPCAP>;
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export declare const PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullStatus: any;
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullSystem = "magic-transit";
export declare const PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullSystem: any;
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullType = "simple" | "full";
export declare const PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullType: any;
export interface PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFull {
    /** The ID for the packet capture. */
    id?: string | null;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | null;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | null;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | null;
    /** An error message that describes why the packet capture failed. This field only applies to `full` packet captures. */
    errorMessage?: string | null;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null;
    /** The number of packets captured. */
    packetsCaptured?: number | null;
    /** The status of the packet capture request. */
    status?: PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullStatus | null;
    /** The RFC 3339 timestamp when stopping the packet capture was requested. This field only applies to `full` packet captures. */
    stopRequested?: string | null;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null;
    /** The system used to collect packet captures. */
    system?: PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullSystem | null;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullType | null;
}
export declare const PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFull: S.Schema<PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFull>;
export type PcapsGetResult = PcapsGetResultPCAP | PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFull;
export declare const PcapsGetResult: any;
export type GetPcapResponse = PcapsGetResult;
export declare const GetPcapResponse: S.Schema<GetPcapResponse>;
export interface GetPcapDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    pcapId: string;
}
export declare const GetPcapDownloadRequest: S.Schema<GetPcapDownloadRequest>;
export interface GetPcapDownloadResponse {
}
export declare const GetPcapDownloadResponse: S.Schema<GetPcapDownloadResponse>;
export interface GetPcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetPcapOwnershipRequest: S.Schema<GetPcapOwnershipRequest>;
export type PcapsOwnershipGetResultItemStatus = "pending" | "success" | "failed";
export declare const PcapsOwnershipGetResultItemStatus: any;
export interface PcapsOwnershipGetResultItem {
    /** The bucket ID associated with the packet captures API. */
    id: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    filename: string;
    /** The status of the ownership challenge. Can be pending, success or failed. */
    status: PcapsOwnershipGetResultItemStatus;
    /** The RFC 3339 timestamp when the bucket was added to packet captures API. */
    submitted: string;
    /** The RFC 3339 timestamp when the bucket was validated. */
    validated?: string | null;
}
export declare const PcapsOwnershipGetResultItem: S.Schema<PcapsOwnershipGetResultItem>;
export type PcapsOwnershipGetResultList = Array<PcapsOwnershipGetResultItem>;
export declare const PcapsOwnershipGetResultList: S.Schema<PcapsOwnershipGetResultList>;
export interface GetPcapOwnershipResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PcapsOwnershipGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetPcapOwnershipResponse: S.Schema<GetPcapOwnershipResponse>;
export interface GetRouteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    routeId: string;
}
export declare const GetRouteRequest: S.Schema<GetRouteRequest>;
export type RoutesGetResponseRouteScopeColoNamesList = Array<string>;
export declare const RoutesGetResponseRouteScopeColoNamesList: S.Schema<RoutesGetResponseRouteScopeColoNamesList>;
export type RoutesGetResponseRouteScopeColoRegionsList = Array<string>;
export declare const RoutesGetResponseRouteScopeColoRegionsList: S.Schema<RoutesGetResponseRouteScopeColoRegionsList>;
export interface RoutesGetResponseRouteScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesGetResponseRouteScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesGetResponseRouteScopeColoRegionsList | null;
}
export declare const RoutesGetResponseRouteScope: S.Schema<RoutesGetResponseRouteScope>;
export interface RoutesGetResponseRoute {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesGetResponseRouteScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const RoutesGetResponseRoute: S.Schema<RoutesGetResponseRoute>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRouteResponse {
    route?: RoutesGetResponseRoute | null;
}
export declare const GetRouteResponse: S.Schema<GetRouteResponse>;
export interface GetSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const GetSiteRequest: S.Schema<GetSiteRequest>;
export type SitesGetResponseLocation = SitesCreateResponseLocation;
export declare const SitesGetResponseLocation: S.Schema<SitesCreateResponseLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteResponse {
    /** Identifier */
    id?: string | null;
    /** Magic Connector identifier tag. */
    connectorId?: string | null;
    description?: string | null;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null;
    /** The name of the site. */
    name?: string | null;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null;
}
export declare const GetSiteResponse: S.Schema<GetSiteResponse>;
export interface GetSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
}
export declare const GetSiteAclRequest: S.Schema<GetSiteAclRequest>;
export type SitesAclsGetResponseLan1PortRangesList = Array<string>;
export declare const SitesAclsGetResponseLan1PortRangesList: S.Schema<SitesAclsGetResponseLan1PortRangesList>;
export type SitesAclsGetResponseLan1PortsList = Array<number>;
export declare const SitesAclsGetResponseLan1PortsList: S.Schema<SitesAclsGetResponseLan1PortsList>;
export type SitesAclsGetResponseLan1SubnetsList = Array<string>;
export declare const SitesAclsGetResponseLan1SubnetsList: S.Schema<SitesAclsGetResponseLan1SubnetsList>;
export interface SitesAclsGetResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsGetResponseLan1PortRangesList | null;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsGetResponseLan1PortsList | null;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsGetResponseLan1SubnetsList | null;
}
export declare const SitesAclsGetResponseLan1: S.Schema<SitesAclsGetResponseLan1>;
export type SitesAclsGetResponseProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsGetResponseProtocolsItem: any;
export type SitesAclsGetResponseProtocolsList = Array<SitesAclsGetResponseProtocolsItem>;
export declare const SitesAclsGetResponseProtocolsList: S.Schema<SitesAclsGetResponseProtocolsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteAclResponse {
    /** Identifier */
    id?: string | null;
    /** Description for the ACL. */
    description?: string | null;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null;
    lan_1?: SitesAclsGetResponseLan1 | null;
    lan_2?: SitesAclsGetResponseLan1 | null;
    /** The name of the ACL. */
    name?: string | null;
    protocols?: SitesAclsGetResponseProtocolsList | null;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null;
}
export declare const GetSiteAclResponse: S.Schema<GetSiteAclResponse>;
export interface GetSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
}
export declare const GetSiteLanRequest: S.Schema<GetSiteLanRequest>;
export type SitesLansGetResponseNat = SitesLansCreateResultItemNat;
export declare const SitesLansGetResponseNat: S.Schema<SitesLansCreateResultItemNat>;
export type SitesLansGetResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export declare const SitesLansGetResponseRoutedSubnetsItem: S.Schema<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansGetResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export declare const SitesLansGetResponseRoutedSubnetsList: S.Schema<SitesLansGetResponseRoutedSubnetsList>;
export type SitesLansGetResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansGetResponseStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansGetResponseStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansGetResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansGetResponseStaticAddressingDhcpRelayServerAddressesList | null;
}
export declare const SitesLansGetResponseStaticAddressingDhcpRelay: S.Schema<SitesLansGetResponseStaticAddressingDhcpRelay>;
export type SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansGetResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansGetResponseStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansGetResponseStaticAddressingDhcpServerDnsServersList>;
export type SitesLansGetResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansGetResponseStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansGetResponseStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansGetResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsList | null;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null;
    /** A valid IPv4 address. */
    dnsServer?: string | null;
    dnsServers?: SitesLansGetResponseStaticAddressingDhcpServerDnsServersList | null;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansGetResponseStaticAddressingDhcpServerReservationsMap | null;
}
export declare const SitesLansGetResponseStaticAddressingDhcpServer: S.Schema<SitesLansGetResponseStaticAddressingDhcpServer>;
export interface SitesLansGetResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansGetResponseStaticAddressingDhcpRelay | null;
    dhcpServer?: SitesLansGetResponseStaticAddressingDhcpServer | null;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null;
}
export declare const SitesLansGetResponseStaticAddressing: S.Schema<SitesLansGetResponseStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteLanResponse {
    /** Identifier */
    id?: string | null;
    bondId?: number | null;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null;
    name?: string | null;
    nat?: SitesLansCreateResultItemNat | null;
    physport?: number | null;
    routedSubnets?: SitesLansGetResponseRoutedSubnetsList | null;
    /** Identifier */
    siteId?: string | null;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansGetResponseStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const GetSiteLanResponse: S.Schema<GetSiteLanResponse>;
export interface GetSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
}
export declare const GetSiteWanRequest: S.Schema<GetSiteWanRequest>;
export type SitesWansGetResponseHealthCheckRate = "low" | "mid" | "high";
export declare const SitesWansGetResponseHealthCheckRate: any;
export type SitesWansGetResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
export declare const SitesWansGetResponseStaticAddressing: S.Schema<SitesWansCreateResultItemStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteWanResponse {
    /** Identifier */
    id?: string | null;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansGetResponseHealthCheckRate | null;
    name?: string | null;
    physport?: number | null;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const GetSiteWanResponse: S.Schema<GetSiteWanResponse>;
export interface ListAppsRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListAppsRequest: S.Schema<ListAppsRequest>;
export type AppsListResultItemMagicAccountAppHostnamesList = Array<string>;
export declare const AppsListResultItemMagicAccountAppHostnamesList: S.Schema<AppsListResultItemMagicAccountAppHostnamesList>;
export type AppsListResultItemMagicAccountAppIpSubnetsList = Array<string>;
export declare const AppsListResultItemMagicAccountAppIpSubnetsList: S.Schema<AppsListResultItemMagicAccountAppIpSubnetsList>;
export type AppsListResultItemMagicAccountAppSourceSubnetsList = Array<string>;
export declare const AppsListResultItemMagicAccountAppSourceSubnetsList: S.Schema<AppsListResultItemMagicAccountAppSourceSubnetsList>;
export interface AppsListResultItemMagicAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsListResultItemMagicAccountAppHostnamesList | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsListResultItemMagicAccountAppIpSubnetsList | null;
    /** Display name for the app. */
    name?: string | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsListResultItemMagicAccountAppSourceSubnetsList | null;
    /** Category of the app. */
    type?: string | null;
}
export declare const AppsListResultItemMagicAccountApp: S.Schema<AppsListResultItemMagicAccountApp>;
export type AppsListResultItemMagicManagedAppHostnamesList = Array<string>;
export declare const AppsListResultItemMagicManagedAppHostnamesList: S.Schema<AppsListResultItemMagicManagedAppHostnamesList>;
export type AppsListResultItemMagicManagedAppIpSubnetsList = Array<string>;
export declare const AppsListResultItemMagicManagedAppIpSubnetsList: S.Schema<AppsListResultItemMagicManagedAppIpSubnetsList>;
export type AppsListResultItemMagicManagedAppSourceSubnetsList = Array<string>;
export declare const AppsListResultItemMagicManagedAppSourceSubnetsList: S.Schema<AppsListResultItemMagicManagedAppSourceSubnetsList>;
export interface AppsListResultItemMagicManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsListResultItemMagicManagedAppHostnamesList | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsListResultItemMagicManagedAppIpSubnetsList | null;
    /** Display name for the app. */
    name?: string | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsListResultItemMagicManagedAppSourceSubnetsList | null;
    /** Category of the app. */
    type?: string | null;
}
export declare const AppsListResultItemMagicManagedApp: S.Schema<AppsListResultItemMagicManagedApp>;
export type AppsListResultItem = AppsListResultItemMagicAccountApp | AppsListResultItemMagicManagedApp;
export declare const AppsListResultItem: any;
export type AppsListResultList = Array<AppsListResultItem>;
export declare const AppsListResultList: S.Schema<AppsListResultList>;
export interface ListAppsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAppsResponse: S.Schema<ListAppsResponse>;
export interface ListCf1SiteRampsRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
}
export declare const ListCf1SiteRampsRequest: S.Schema<ListCf1SiteRampsRequest>;
export type Cf1SitesRampsListResultItemType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export declare const Cf1SitesRampsListResultItemType: any;
export type Cf1SitesRampsListResultItemGre = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsListResultItemGre: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsListResultItemGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsListResultItemGreInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsListResultItemIpsec = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsListResultItemIpsec: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsListResultItemMconn = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsListResultItemMconn: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export type Cf1SitesRampsListResultItemMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
export declare const Cf1SitesRampsListResultItemMplsInterconnect: S.Schema<Cf1SitesRampsCreateResultItemGre>;
export interface Cf1SitesRampsListResultItem {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsListResultItemType;
    /** A human-provided description of the ramp. */
    description?: string | null;
    gre?: Cf1SitesRampsCreateResultItemGre | null;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null;
    mconn?: Cf1SitesRampsCreateResultItemGre | null;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null;
}
export declare const Cf1SitesRampsListResultItem: S.Schema<Cf1SitesRampsListResultItem>;
export type Cf1SitesRampsListResultList = Array<Cf1SitesRampsListResultItem>;
export declare const Cf1SitesRampsListResultList: S.Schema<Cf1SitesRampsListResultList>;
export interface ListCf1SiteRampsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesRampsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCf1SiteRampsResponse: S.Schema<ListCf1SiteRampsResponse>;
export interface ListCf1SitesRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListCf1SitesRequest: S.Schema<ListCf1SitesRequest>;
export type Cf1SitesListResultItemLocation = Cf1SitesCreateResultItemLocation;
export declare const Cf1SitesListResultItemLocation: S.Schema<Cf1SitesCreateResultItemLocation>;
export type Cf1SitesListResultItem = Cf1SitesCreateResultItem;
export declare const Cf1SitesListResultItem: S.Schema<Cf1SitesCreateResultItem>;
export type Cf1SitesListResultList = Array<Cf1SitesCreateResultItem>;
export declare const Cf1SitesListResultList: S.Schema<Cf1SitesListResultList>;
export interface ListCf1SitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCf1SitesResponse: S.Schema<ListCf1SitesResponse>;
export interface ListCfInterconnectsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const ListCfInterconnectsRequest: S.Schema<ListCfInterconnectsRequest>;
export type CfInterconnectsListResponseInterconnectsItemGre = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre;
export declare const CfInterconnectsListResponseInterconnectsItemGre: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre>;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckRate = "low" | "mid" | "high";
export declare const CfInterconnectsListResponseInterconnectsItemHealthCheckRate: any;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsListResponseInterconnectsItemHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsListResponseInterconnectsItemHealthCheckTarget: any;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckType = "reply" | "request";
export declare const CfInterconnectsListResponseInterconnectsItemHealthCheckType: any;
export interface CfInterconnectsListResponseInterconnectsItemHealthCheck {
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsListResponseInterconnectsItemHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsListResponseInterconnectsItemHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsListResponseInterconnectsItemHealthCheckType | null;
}
export declare const CfInterconnectsListResponseInterconnectsItemHealthCheck: S.Schema<CfInterconnectsListResponseInterconnectsItemHealthCheck>;
export interface CfInterconnectsListResponseInterconnectsItem {
    /** Identifier */
    id?: string | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the interconnect. */
    description?: string | null;
    /** The configuration specific to GRE interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null;
    healthCheck?: CfInterconnectsListResponseInterconnectsItemHealthCheck | null;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress?: string | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null;
}
export declare const CfInterconnectsListResponseInterconnectsItem: S.Schema<CfInterconnectsListResponseInterconnectsItem>;
export type CfInterconnectsListResponseInterconnectsList = Array<CfInterconnectsListResponseInterconnectsItem>;
export declare const CfInterconnectsListResponseInterconnectsList: S.Schema<CfInterconnectsListResponseInterconnectsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListCfInterconnectsResponse {
    interconnects?: CfInterconnectsListResponseInterconnectsList | null;
}
export declare const ListCfInterconnectsResponse: S.Schema<ListCfInterconnectsResponse>;
export interface ListConnectorEventLatestsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
}
export declare const ListConnectorEventLatestsRequest: S.Schema<ListConnectorEventLatestsRequest>;
export type ConnectorsEventsLatestListResponseItemsItemEInitK = "Init";
export declare const ConnectorsEventsLatestListResponseItemsItemEInitK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEInit {
    /** Initialized process */
    k: ConnectorsEventsLatestListResponseItemsItemEInitK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEInit: S.Schema<ConnectorsEventsLatestListResponseItemsItemEInit>;
export type ConnectorsEventsLatestListResponseItemsItemELeaveK = "Leave";
export declare const ConnectorsEventsLatestListResponseItemsItemELeaveK: any;
export interface ConnectorsEventsLatestListResponseItemsItemELeave {
    /** Stopped process */
    k: ConnectorsEventsLatestListResponseItemsItemELeaveK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemELeave: S.Schema<ConnectorsEventsLatestListResponseItemsItemELeave>;
export type ConnectorsEventsLatestListResponseItemsItemEStartAttestationK = "StartAttestation";
export declare const ConnectorsEventsLatestListResponseItemsItemEStartAttestationK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEStartAttestation {
    /** Started attestation */
    k: ConnectorsEventsLatestListResponseItemsItemEStartAttestationK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEStartAttestation: S.Schema<ConnectorsEventsLatestListResponseItemsItemEStartAttestation>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccessK = "FinishAttestationSuccess";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccessK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccess {
    /** Finished attestation */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccessK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccess: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccess>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailureK = "FinishAttestationFailure";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailureK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailure {
    /** Failed attestation */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailureK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailure: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailure>;
export type ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKeyK = "StartRotateCryptKey";
export declare const ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKeyK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKey {
    /** Started crypt key rotation */
    k: ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKeyK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKey: S.Schema<ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKey>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccessK = "FinishRotateCryptKeySuccess";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccessK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccess {
    /** Finished crypt key rotation */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccessK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccess: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccess>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailureK = "FinishRotateCryptKeyFailure";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailureK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailure {
    /** Failed crypt key rotation */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailureK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailure: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailure>;
export type ConnectorsEventsLatestListResponseItemsItemEStartRotatePkiK = "StartRotatePki";
export declare const ConnectorsEventsLatestListResponseItemsItemEStartRotatePkiK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEStartRotatePki {
    /** Started PKI rotation */
    k: ConnectorsEventsLatestListResponseItemsItemEStartRotatePkiK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEStartRotatePki: S.Schema<ConnectorsEventsLatestListResponseItemsItemEStartRotatePki>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccessK = "FinishRotatePkiSuccess";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccessK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccess {
    /** Finished PKI rotation */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccessK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccess: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccess>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailureK = "FinishRotatePkiFailure";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailureK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailure {
    /** Failed PKI rotation */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailureK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailure: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailure>;
export type ConnectorsEventsLatestListResponseItemsItemEStartUpgradeK = "StartUpgrade";
export declare const ConnectorsEventsLatestListResponseItemsItemEStartUpgradeK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEStartUpgrade {
    /** Started upgrade */
    k: ConnectorsEventsLatestListResponseItemsItemEStartUpgradeK;
    /** Location of upgrade bundle */
    url: string;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEStartUpgrade: S.Schema<ConnectorsEventsLatestListResponseItemsItemEStartUpgrade>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccessK = "FinishUpgradeSuccess";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccessK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccess {
    /** Finished upgrade */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccessK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccess: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccess>;
export type ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailureK = "FinishUpgradeFailure";
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailureK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailure {
    /** Failed upgrade */
    k: ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailureK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailure: S.Schema<ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailure>;
export type ConnectorsEventsLatestListResponseItemsItemEReconcileK = "Reconcile";
export declare const ConnectorsEventsLatestListResponseItemsItemEReconcileK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEReconcile {
    /** Reconciled */
    k: ConnectorsEventsLatestListResponseItemsItemEReconcileK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEReconcile: S.Schema<ConnectorsEventsLatestListResponseItemsItemEReconcile>;
export type ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnelK = "ConfigureCloudflaredTunnel";
export declare const ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnelK: any;
export interface ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnel {
    /** Configured Cloudflared tunnel */
    k: ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnelK;
}
export declare const ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnel: S.Schema<ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnel>;
export type ConnectorsEventsLatestListResponseItemsItemERekeyInstallBothK = "RekeyInstallBoth";
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyInstallBothK: any;
export interface ConnectorsEventsLatestListResponseItemsItemERekeyInstallBoth {
    /** Installed initial inbound and outbound keys */
    k: ConnectorsEventsLatestListResponseItemsItemERekeyInstallBothK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyInstallBoth: S.Schema<ConnectorsEventsLatestListResponseItemsItemERekeyInstallBoth>;
export type ConnectorsEventsLatestListResponseItemsItemERekeyStartK = "RekeyStart";
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyStartK: any;
export interface ConnectorsEventsLatestListResponseItemsItemERekeyStart {
    /** Installed new inbound key, kept old outbound */
    k: ConnectorsEventsLatestListResponseItemsItemERekeyStartK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyStart: S.Schema<ConnectorsEventsLatestListResponseItemsItemERekeyStart>;
export type ConnectorsEventsLatestListResponseItemsItemERekeyAdvanceK = "RekeyAdvance";
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyAdvanceK: any;
export interface ConnectorsEventsLatestListResponseItemsItemERekeyAdvance {
    /** Confirmed traffic on new inbound key, swapped outbound to new */
    k: ConnectorsEventsLatestListResponseItemsItemERekeyAdvanceK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyAdvance: S.Schema<ConnectorsEventsLatestListResponseItemsItemERekeyAdvance>;
export type ConnectorsEventsLatestListResponseItemsItemERekeyCompleteK = "RekeyComplete";
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyCompleteK: any;
export interface ConnectorsEventsLatestListResponseItemsItemERekeyComplete {
    /** Deleted old keys */
    k: ConnectorsEventsLatestListResponseItemsItemERekeyCompleteK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyComplete: S.Schema<ConnectorsEventsLatestListResponseItemsItemERekeyComplete>;
export type ConnectorsEventsLatestListResponseItemsItemERekeyResetK = "RekeyReset";
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyResetK: any;
export interface ConnectorsEventsLatestListResponseItemsItemERekeyReset {
    /** Deleted all keys after receiving an unexpected key */
    k: ConnectorsEventsLatestListResponseItemsItemERekeyResetK;
    /** Tunnel identifier */
    tunnelId: string;
}
export declare const ConnectorsEventsLatestListResponseItemsItemERekeyReset: S.Schema<ConnectorsEventsLatestListResponseItemsItemERekeyReset>;
export type ConnectorsEventsLatestListResponseItemsItemE = ConnectorsEventsLatestListResponseItemsItemEInit | ConnectorsEventsLatestListResponseItemsItemELeave | ConnectorsEventsLatestListResponseItemsItemEStartAttestation | ConnectorsEventsLatestListResponseItemsItemEFinishAttestationSuccess | ConnectorsEventsLatestListResponseItemsItemEFinishAttestationFailure | ConnectorsEventsLatestListResponseItemsItemEStartRotateCryptKey | ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeySuccess | ConnectorsEventsLatestListResponseItemsItemEFinishRotateCryptKeyFailure | ConnectorsEventsLatestListResponseItemsItemEStartRotatePki | ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiSuccess | ConnectorsEventsLatestListResponseItemsItemEFinishRotatePkiFailure | ConnectorsEventsLatestListResponseItemsItemEStartUpgrade | ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeSuccess | ConnectorsEventsLatestListResponseItemsItemEFinishUpgradeFailure | ConnectorsEventsLatestListResponseItemsItemEReconcile | ConnectorsEventsLatestListResponseItemsItemEConfigureCloudflaredTunnel | ConnectorsEventsLatestListResponseItemsItemERekeyInstallBoth | ConnectorsEventsLatestListResponseItemsItemERekeyStart | ConnectorsEventsLatestListResponseItemsItemERekeyAdvance | ConnectorsEventsLatestListResponseItemsItemERekeyComplete | ConnectorsEventsLatestListResponseItemsItemERekeyReset;
export declare const ConnectorsEventsLatestListResponseItemsItemE: any;
export interface ConnectorsEventsLatestListResponseItemsItem {
    e: ConnectorsEventsLatestListResponseItemsItemE;
    /** Sequence number, used to order events with the same timestamp */
    n: number;
    /** Time the Event was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v?: string | null;
}
export declare const ConnectorsEventsLatestListResponseItemsItem: S.Schema<ConnectorsEventsLatestListResponseItemsItem>;
export type ConnectorsEventsLatestListResponseItemsList = Array<ConnectorsEventsLatestListResponseItemsItem>;
export declare const ConnectorsEventsLatestListResponseItemsList: S.Schema<ConnectorsEventsLatestListResponseItemsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorEventLatestsResponse {
    count: number;
    items: ConnectorsEventsLatestListResponseItemsList;
}
export declare const ListConnectorEventLatestsResponse: S.Schema<ListConnectorEventLatestsResponse>;
export interface ListConnectorEventsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    from: number;
    to: number;
    cursor?: string;
    /** Filter by event kind */
    k?: string;
    limit?: number;
}
export declare const ListConnectorEventsRequest: S.Schema<ListConnectorEventsRequest>;
export interface ConnectorsEventsListResponseItemsItem {
    /** Time the Event was collected (seconds since the Unix epoch) */
    a: number;
    /** Kind */
    k: string;
    /** Sequence number, used to order events with the same timestamp */
    n: number;
    /** Time the Event was recorded (seconds since the Unix epoch) */
    t: number;
}
export declare const ConnectorsEventsListResponseItemsItem: S.Schema<ConnectorsEventsListResponseItemsItem>;
export type ConnectorsEventsListResponseItemsList = Array<ConnectorsEventsListResponseItemsItem>;
export declare const ConnectorsEventsListResponseItemsList: S.Schema<ConnectorsEventsListResponseItemsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorEventsResponse {
    count: number;
    items: ConnectorsEventsListResponseItemsList;
    cursor?: string | null;
}
export declare const ListConnectorEventsResponse: S.Schema<ListConnectorEventsResponse>;
export type ConnectorsListRequestDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsListRequestDeviceType: any;
export interface ListConnectorsRequest {
    /** Account identifier */
    accountId: string;
    /** Filter connectors by device type. */
    deviceType?: ConnectorsListRequestDeviceType | (string & {});
}
export declare const ListConnectorsRequest: S.Schema<ListConnectorsRequest>;
export type ConnectorsListResultItemInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsListResultItemInterruptWindowDaysOfWeekItem: any;
export type ConnectorsListResultItemInterruptWindowDaysOfWeekList = Array<ConnectorsListResultItemInterruptWindowDaysOfWeekItem>;
export declare const ConnectorsListResultItemInterruptWindowDaysOfWeekList: S.Schema<ConnectorsListResultItemInterruptWindowDaysOfWeekList>;
export type ConnectorsListResultItemInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsListResultItemInterruptWindowEmbargoDatesList: S.Schema<ConnectorsListResultItemInterruptWindowEmbargoDatesList>;
export type ConnectorsListResultItemDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsListResultItemDeviceType: any;
export interface ConnectorsListResultItemDevice {
    id: string;
    serialNumber?: string | null;
    type?: ConnectorsListResultItemDeviceType | null;
}
export declare const ConnectorsListResultItemDevice: S.Schema<ConnectorsListResultItemDevice>;
export interface ConnectorsListResultItem {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsListResultItemInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsListResultItemInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    primary: boolean;
    timezone: string;
    device?: ConnectorsListResultItemDevice | null;
    lastHeartbeat?: string | null;
    lastSeenVersion?: string | null;
    licenseKey?: string | null;
    siteId?: string | null;
}
export declare const ConnectorsListResultItem: S.Schema<ConnectorsListResultItem>;
export type ConnectorsListResultList = Array<ConnectorsListResultItem>;
export declare const ConnectorsListResultList: S.Schema<ConnectorsListResultList>;
export interface ListConnectorsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConnectorsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListConnectorsResponse: S.Schema<ListConnectorsResponse>;
export interface ListConnectorSnapshotLatestsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
}
export declare const ListConnectorSnapshotLatestsRequest: S.Schema<ListConnectorSnapshotLatestsRequest>;
export type ConnectorsSnapshotsLatestListResponseItemsItemBondsItem = ConnectorsSnapshotsGetResponseBondsItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemBondsItem: S.Schema<ConnectorsSnapshotsGetResponseBondsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemBondsList = Array<ConnectorsSnapshotsGetResponseBondsItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemBondsList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemBondsList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesItem = ConnectorsSnapshotsGetResponseDhcpLeasesItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesItem: S.Schema<ConnectorsSnapshotsGetResponseDhcpLeasesItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesList = Array<ConnectorsSnapshotsGetResponseDhcpLeasesItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemDisksItem = ConnectorsSnapshotsGetResponseDisksItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemDisksItem: S.Schema<ConnectorsSnapshotsGetResponseDisksItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemDisksList = Array<ConnectorsSnapshotsGetResponseDisksItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemDisksList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemDisksList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesItem = ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesItem: S.Schema<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesList = Array<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesList>;
export interface ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItem {
    /** Name of the network interface */
    name: string;
    /** UP/DOWN state of the network interface */
    operstate: string;
    ipAddresses?: ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesList | null;
    /** Speed of the network interface (bits per second) */
    speed?: number | null;
}
export declare const ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItem: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemInterfacesList = Array<ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemInterfacesList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemInterfacesList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemMountsItem = ConnectorsSnapshotsGetResponseMountsItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemMountsItem: S.Schema<ConnectorsSnapshotsGetResponseMountsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemMountsList = Array<ConnectorsSnapshotsGetResponseMountsItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemMountsList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemMountsList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemNetdevsItem = ConnectorsSnapshotsGetResponseNetdevsItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemNetdevsItem: S.Schema<ConnectorsSnapshotsGetResponseNetdevsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemNetdevsList = Array<ConnectorsSnapshotsGetResponseNetdevsItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemNetdevsList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemNetdevsList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemThermalsItem = ConnectorsSnapshotsGetResponseThermalsItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemThermalsItem: S.Schema<ConnectorsSnapshotsGetResponseThermalsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemThermalsList = Array<ConnectorsSnapshotsGetResponseThermalsItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemThermalsList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemThermalsList>;
export type ConnectorsSnapshotsLatestListResponseItemsItemTunnelsItem = ConnectorsSnapshotsGetResponseTunnelsItem;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemTunnelsItem: S.Schema<ConnectorsSnapshotsGetResponseTunnelsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemTunnelsList = Array<ConnectorsSnapshotsGetResponseTunnelsItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsItemTunnelsList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItemTunnelsList>;
export interface ConnectorsSnapshotsLatestListResponseItemsItem {
    /** Count of failures to reclaim space */
    countReclaimFailures: number;
    /** Count of reclaimed paths */
    countReclaimedPaths: number;
    /** Count of failed snapshot recordings */
    countRecordFailed: number;
    /** Count of failed snapshot transmissions */
    countTransmitFailures: number;
    /** Time the Snapshot was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v: string;
    bonds?: ConnectorsSnapshotsLatestListResponseItemsItemBondsList | null;
    /** Count of processors/cores */
    cpuCount?: number | null;
    /** Percentage of time over a 10 second window that tasks were stalled */
    cpu_pressure_10s?: number | null;
    /** Percentage of time over a 5 minute window that tasks were stalled */
    cpu_pressure_300s?: number | null;
    /** Percentage of time over a 1 minute window that tasks were stalled */
    cpu_pressure_60s?: number | null;
    /** Total stall time (microseconds) */
    cpuPressureTotalUs?: number | null;
    /** Time spent running a virtual CPU or guest OS (milliseconds) */
    cpuTimeGuestMs?: number | null;
    /** Time spent running a niced guest (milliseconds) */
    cpuTimeGuestNiceMs?: number | null;
    /** Time spent in idle state (milliseconds) */
    cpuTimeIdleMs?: number | null;
    /** Time spent wait for I/O to complete (milliseconds) */
    cpuTimeIowaitMs?: number | null;
    /** Time spent servicing interrupts (milliseconds) */
    cpuTimeIrqMs?: number | null;
    /** Time spent in low-priority user mode (milliseconds) */
    cpuTimeNiceMs?: number | null;
    /** Time spent servicing softirqs (milliseconds) */
    cpuTimeSoftirqMs?: number | null;
    /** Time stolen (milliseconds) */
    cpuTimeStealMs?: number | null;
    /** Time spent in system mode (milliseconds) */
    cpuTimeSystemMs?: number | null;
    /** Time spent in user mode (milliseconds) */
    cpuTimeUserMs?: number | null;
    /** Number of network operations applied during state transition */
    delta?: number | null;
    dhcpLeases?: ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesList | null;
    disks?: ConnectorsSnapshotsLatestListResponseItemsItemDisksList | null;
    /** Simulated number of network operations applied during state transition */
    epsilon?: number | null;
    /** Name of high availability state */
    haState?: string | null;
    /** Numeric value associated with high availability state (0 = disabled, 1 = active, 2 = standby, 3 = stopped, 4 = fault) */
    haValue?: number | null;
    interfaces?: ConnectorsSnapshotsLatestListResponseItemsItemInterfacesList | null;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    io_pressure_full_10s?: number | null;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    io_pressure_full_300s?: number | null;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    io_pressure_full_60s?: number | null;
    /** Total stall time (microseconds) */
    ioPressureFullTotalUs?: number | null;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    io_pressure_some_10s?: number | null;
    /** Percentage of time over a 3 minute window that some tasks were stalled */
    io_pressure_some_300s?: number | null;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    io_pressure_some_60s?: number | null;
    /** Total stall time (microseconds) */
    ioPressureSomeTotalUs?: number | null;
    /** Boot time (seconds since Unix epoch) */
    kernelBtime?: number | null;
    /** Number of context switches that the system underwent */
    kernelCtxt?: number | null;
    /** Number of forks since boot */
    kernelProcesses?: number | null;
    /** Number of processes blocked waiting for I/O */
    kernelProcessesBlocked?: number | null;
    /** Number of processes in runnable state */
    kernelProcessesRunning?: number | null;
    /** The fifteen-minute load average */
    load_average_15m?: number | null;
    /** The one-minute load average */
    load_average_1m?: number | null;
    /** The five-minute load average */
    load_average_5m?: number | null;
    /** Number of currently runnable kernel scheduling entities */
    loadAverageCur?: number | null;
    /** Number of kernel scheduling entities that currently exist on the system */
    loadAverageMax?: number | null;
    /** Memory that has been used more recently */
    memoryActiveBytes?: number | null;
    /** Non-file backed huge pages mapped into user-space page tables */
    memoryAnonHugepagesBytes?: number | null;
    /** Non-file backed pages mapped into user-space page tables */
    memoryAnonPagesBytes?: number | null;
    /** Estimate of how much memory is available for starting new applications */
    memoryAvailableBytes?: number | null;
    /** Memory used for block device bounce buffers */
    memoryBounceBytes?: number | null;
    /** Relatively temporary storage for raw disk blocks */
    memoryBuffersBytes?: number | null;
    /** In-memory cache for files read from the disk */
    memoryCachedBytes?: number | null;
    /** Free CMA (Contiguous Memory Allocator) pages */
    memoryCmaFreeBytes?: number | null;
    /** Total CMA (Contiguous Memory Allocator) pages */
    memoryCmaTotalBytes?: number | null;
    /** Total amount of memory currently available to be allocated on the system */
    memoryCommitLimitBytes?: number | null;
    /** Amount of memory presently allocated on the system */
    memoryCommittedAsBytes?: number | null;
    /** Memory which is waiting to get written back to the disk */
    memoryDirtyBytes?: number | null;
    /** The sum of LowFree and HighFree */
    memoryFreeBytes?: number | null;
    /** Amount of free highmem */
    memoryHighFreeBytes?: number | null;
    /** Total amount of highmem */
    memoryHighTotalBytes?: number | null;
    /** The number of huge pages in the pool that are not yet allocated */
    memoryHugepagesFree?: number | null;
    /** Number of huge pages for which a commitment has been made, but no allocation has yet been made */
    memoryHugepagesRsvd?: number | null;
    /** Number of huge pages in the pool above the threshold */
    memoryHugepagesSurp?: number | null;
    /** The size of the pool of huge pages */
    memoryHugepagesTotal?: number | null;
    /** The size of huge pages */
    memoryHugepagesizeBytes?: number | null;
    /** Memory which has been less recently used */
    memoryInactiveBytes?: number | null;
    /** Kernel allocations that the kernel will attempt to reclaim under memory pressure */
    memoryKReclaimableBytes?: number | null;
    /** Amount of memory allocated to kernel stacks */
    memoryKernelStackBytes?: number | null;
    /** Amount of free lowmem */
    memoryLowFreeBytes?: number | null;
    /** Total amount of lowmem */
    memoryLowTotalBytes?: number | null;
    /** Files which have been mapped into memory */
    memoryMappedBytes?: number | null;
    /** Amount of memory dedicated to the lowest level of page tables */
    memoryPageTablesBytes?: number | null;
    /** Memory allocated to the per-cpu alloctor used to back per-cpu allocations */
    memoryPerCpuBytes?: number | null;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    memory_pressure_full_10s?: number | null;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    memory_pressure_full_300s?: number | null;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    memory_pressure_full_60s?: number | null;
    /** Total stall time (microseconds) */
    memoryPressureFullTotalUs?: number | null;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    memory_pressure_some_10s?: number | null;
    /** Percentage of time over a 5 minute window that some tasks were stalled */
    memory_pressure_some_300s?: number | null;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    memory_pressure_some_60s?: number | null;
    /** Total stall time (microseconds) */
    memoryPressureSomeTotalUs?: number | null;
    /** Part of slab that can be reclaimed on memory pressure */
    memorySReclaimableBytes?: number | null;
    /** Part of slab that cannot be reclaimed on memory pressure */
    memorySUnreclaimBytes?: number | null;
    /** Amount of memory dedicated to the lowest level of page tables */
    memorySecondaryPageTablesBytes?: number | null;
    /** Amount of memory consumed by tmpfs */
    memoryShmemBytes?: number | null;
    /** Memory used by shmem and tmpfs, allocated with huge pages */
    memoryShmemHugepagesBytes?: number | null;
    /** Shared memory mapped into user space with huge pages */
    memoryShmemPmdMappedBytes?: number | null;
    /** In-kernel data structures cache */
    memorySlabBytes?: number | null;
    /** Memory swapped out and back in while still in swap file */
    memorySwapCachedBytes?: number | null;
    /** Amount of swap space that is currently unused */
    memorySwapFreeBytes?: number | null;
    /** Total amount of swap space available */
    memorySwapTotalBytes?: number | null;
    /** Total usable RAM */
    memoryTotalBytes?: number | null;
    /** Largest contiguous block of vmalloc area which is free */
    memoryVmallocChunkBytes?: number | null;
    /** Total size of vmalloc memory area */
    memoryVmallocTotalBytes?: number | null;
    /** Amount of vmalloc area which is used */
    memoryVmallocUsedBytes?: number | null;
    /** Memory which is actively being written back to the disk */
    memoryWritebackBytes?: number | null;
    /** Memory used by FUSE for temporary writeback buffers */
    memoryWritebackTmpBytes?: number | null;
    /** Memory consumed by the zswap backend, compressed */
    memoryZSwapBytes?: number | null;
    /** Amount of anonymous memory stored in zswap, uncompressed */
    memoryZSwappedBytes?: number | null;
    mounts?: ConnectorsSnapshotsLatestListResponseItemsItemMountsList | null;
    netdevs?: ConnectorsSnapshotsLatestListResponseItemsItemNetdevsList | null;
    /** Platform identifier */
    platform?: string | null;
    /** Number of ICMP Address Mask Reply messages received */
    snmpIcmpInAddrMaskReps?: number | null;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInAddrMasks?: number | null;
    /** Number of ICMP messages received with bad checksums */
    snmpIcmpInCsumErrors?: number | null;
    /** Number of ICMP Destination Unreachable messages received */
    snmpIcmpInDestUnreachs?: number | null;
    /** Number of ICMP Echo Reply messages received */
    snmpIcmpInEchoReps?: number | null;
    /** Number of ICMP Echo (request) messages received */
    snmpIcmpInEchos?: number | null;
    /** Number of ICMP messages received with ICMP-specific errors */
    snmpIcmpInErrors?: number | null;
    /** Number of ICMP messages received */
    snmpIcmpInMsgs?: number | null;
    /** Number of ICMP Parameter Problem messages received */
    snmpIcmpInParmProbs?: number | null;
    /** Number of ICMP Redirect messages received */
    snmpIcmpInRedirects?: number | null;
    /** Number of ICMP Source Quench messages received */
    snmpIcmpInSrcQuenchs?: number | null;
    /** Number of ICMP Time Exceeded messages received */
    snmpIcmpInTimeExcds?: number | null;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInTimestampReps?: number | null;
    /** Number of ICMP Timestamp (request) messages received */
    snmpIcmpInTimestamps?: number | null;
    /** Number of ICMP Address Mask Reply messages sent */
    snmpIcmpOutAddrMaskReps?: number | null;
    /** Number of ICMP Address Mask Request messages sent */
    snmpIcmpOutAddrMasks?: number | null;
    /** Number of ICMP Destination Unreachable messages sent */
    snmpIcmpOutDestUnreachs?: number | null;
    /** Number of ICMP Echo Reply messages sent */
    snmpIcmpOutEchoReps?: number | null;
    /** Number of ICMP Echo (request) messages sent */
    snmpIcmpOutEchos?: number | null;
    /** Number of ICMP messages which this entity did not send due to ICMP-specific errors */
    snmpIcmpOutErrors?: number | null;
    /** Number of ICMP messages attempted to send */
    snmpIcmpOutMsgs?: number | null;
    /** Number of ICMP Parameter Problem messages sent */
    snmpIcmpOutParmProbs?: number | null;
    /** Number of ICMP Redirect messages sent */
    snmpIcmpOutRedirects?: number | null;
    /** Number of ICMP Source Quench messages sent */
    snmpIcmpOutSrcQuenchs?: number | null;
    /** Number of ICMP Time Exceeded messages sent */
    snmpIcmpOutTimeExcds?: number | null;
    /** Number of ICMP Timestamp Reply messages sent */
    snmpIcmpOutTimestampReps?: number | null;
    /** Number of ICMP Timestamp (request) messages sent */
    snmpIcmpOutTimestamps?: number | null;
    /** Default value of the Time-To-Live field of the IP header */
    snmpIpDefaultTtl?: number | null;
    /** Number of datagrams forwarded to their final destination */
    snmpIpForwDatagrams?: number | null;
    /** Set when acting as an IP gateway */
    snmpIpForwardingEnabled?: boolean | null;
    /** Number of datagrams generated by fragmentation */
    snmpIpFragCreates?: number | null;
    /** Number of datagrams discarded because fragmentation failed */
    snmpIpFragFails?: number | null;
    /** Number of datagrams successfully fragmented */
    snmpIpFragOks?: number | null;
    /** Number of input datagrams discarded due to errors in the IP address */
    snmpIpInAddrErrors?: number | null;
    /** Number of input datagrams successfully delivered to IP user-protocols */
    snmpIpInDelivers?: number | null;
    /** Number of input datagrams otherwise discarded */
    snmpIpInDiscards?: number | null;
    /** Number of input datagrams discarded due to errors in the IP header */
    snmpIpInHdrErrors?: number | null;
    /** Number of input datagrams received from interfaces */
    snmpIpInReceives?: number | null;
    /** Number of input datagrams discarded due unknown or unsupported protocol */
    snmpIpInUnknownProtos?: number | null;
    /** Number of output datagrams otherwise discarded */
    snmpIpOutDiscards?: number | null;
    /** Number of output datagrams discarded because no route matched */
    snmpIpOutNoRoutes?: number | null;
    /** Number of datagrams supplied for transmission */
    snmpIpOutRequests?: number | null;
    /** Number of failures detected by the reassembly algorithm */
    snmpIpReasmFails?: number | null;
    /** Number of datagrams successfully reassembled */
    snmpIpReasmOks?: number | null;
    /** Number of fragments received which needed to be reassembled */
    snmpIpReasmReqds?: number | null;
    /** Number of seconds fragments are held while awaiting reassembly */
    snmpIpReasmTimeout?: number | null;
    /** Number of times TCP transitions to SYN-SENT from CLOSED */
    snmpTcpActiveOpens?: number | null;
    /** Number of times TCP transitions to CLOSED from SYN-SENT or SYN-RCVD, plus transitions to LISTEN from SYN-RCVD */
    snmpTcpAttemptFails?: number | null;
    /** Number of TCP connections in ESTABLISHED or CLOSE-WAIT */
    snmpTcpCurrEstab?: number | null;
    /** Number of times TCP transitions to CLOSED from ESTABLISHED or CLOSE-WAIT */
    snmpTcpEstabResets?: number | null;
    /** Number of TCP segments received with checksum errors */
    snmpTcpInCsumErrors?: number | null;
    /** Number of TCP segments received in error */
    snmpTcpInErrs?: number | null;
    /** Number of TCP segments received */
    snmpTcpInSegs?: number | null;
    /** Limit on the total number of TCP connections */
    snmpTcpMaxConn?: number | null;
    /** Number of TCP segments sent with RST flag */
    snmpTcpOutRsts?: number | null;
    /** Number of TCP segments sent */
    snmpTcpOutSegs?: number | null;
    /** Number of times TCP transitions to SYN-RCVD from LISTEN */
    snmpTcpPassiveOpens?: number | null;
    /** Number of TCP segments retransmitted */
    snmpTcpRetransSegs?: number | null;
    /** Maximum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMax?: number | null;
    /** Minimum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMin?: number | null;
    /** Number of UDP datagrams delivered to UDP applications */
    snmpUdpInDatagrams?: number | null;
    /** Number of UDP datagrams failed to be delivered for reasons other than lack of application at the destination port */
    snmpUdpInErrors?: number | null;
    /** Number of UDP datagrams received for which there was not application at the destination port */
    snmpUdpNoPorts?: number | null;
    /** Number of UDP datagrams sent */
    snmpUdpOutDatagrams?: number | null;
    /** Boottime of the system (seconds since the Unix epoch) */
    systemBootTimeS?: number | null;
    thermals?: ConnectorsSnapshotsLatestListResponseItemsItemThermalsList | null;
    tunnels?: ConnectorsSnapshotsLatestListResponseItemsItemTunnelsList | null;
    /** Sum of how much time each core has spent idle */
    uptimeIdleMs?: number | null;
    /** Uptime of the system, including time spent in suspend */
    uptimeTotalMs?: number | null;
}
export declare const ConnectorsSnapshotsLatestListResponseItemsItem: S.Schema<ConnectorsSnapshotsLatestListResponseItemsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsList = Array<ConnectorsSnapshotsLatestListResponseItemsItem>;
export declare const ConnectorsSnapshotsLatestListResponseItemsList: S.Schema<ConnectorsSnapshotsLatestListResponseItemsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorSnapshotLatestsResponse {
    count: number;
    items: ConnectorsSnapshotsLatestListResponseItemsList;
}
export declare const ListConnectorSnapshotLatestsResponse: S.Schema<ListConnectorSnapshotLatestsResponse>;
export interface ListConnectorSnapshotsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    from: number;
    to: number;
    cursor?: string;
    limit?: number;
}
export declare const ListConnectorSnapshotsRequest: S.Schema<ListConnectorSnapshotsRequest>;
export interface ConnectorsSnapshotsListResponseItemsItem {
    /** Time the Snapshot was collected (seconds since the Unix epoch) */
    a: number;
    /** Time the Snapshot was recorded (seconds since the Unix epoch) */
    t: number;
}
export declare const ConnectorsSnapshotsListResponseItemsItem: S.Schema<ConnectorsSnapshotsListResponseItemsItem>;
export type ConnectorsSnapshotsListResponseItemsList = Array<ConnectorsSnapshotsListResponseItemsItem>;
export declare const ConnectorsSnapshotsListResponseItemsList: S.Schema<ConnectorsSnapshotsListResponseItemsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorSnapshotsResponse {
    count: number;
    items: ConnectorsSnapshotsListResponseItemsList;
    cursor?: string | null;
}
export declare const ListConnectorSnapshotsResponse: S.Schema<ListConnectorSnapshotsResponse>;
export interface ListGreTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const ListGreTunnelsRequest: S.Schema<ListGreTunnelsRequest>;
export type GreTunnelsListResponseGreTunnelsItemBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsListResponseGreTunnelsItemBgpExtraPrefixesList: S.Schema<GreTunnelsListResponseGreTunnelsItemBgpExtraPrefixesList>;
export interface GreTunnelsListResponseGreTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsListResponseGreTunnelsItemBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const GreTunnelsListResponseGreTunnelsItemBgp: S.Schema<GreTunnelsListResponseGreTunnelsItemBgp>;
export type GreTunnelsListResponseGreTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const GreTunnelsListResponseGreTunnelsItemBgpStatusState: any;
export interface GreTunnelsListResponseGreTunnelsItemBgpStatus {
    state: GreTunnelsListResponseGreTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const GreTunnelsListResponseGreTunnelsItemBgpStatus: S.Schema<GreTunnelsListResponseGreTunnelsItemBgpStatus>;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsListResponseGreTunnelsItemHealthCheckDirection: any;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsListResponseGreTunnelsItemHealthCheckRate: any;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsListResponseGreTunnelsItemHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsListResponseGreTunnelsItemHealthCheckTarget: any;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckType = "reply" | "request";
export declare const GreTunnelsListResponseGreTunnelsItemHealthCheckType: any;
export interface GreTunnelsListResponseGreTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsListResponseGreTunnelsItemHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsListResponseGreTunnelsItemHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsListResponseGreTunnelsItemHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsListResponseGreTunnelsItemHealthCheckType | null;
}
export declare const GreTunnelsListResponseGreTunnelsItemHealthCheck: S.Schema<GreTunnelsListResponseGreTunnelsItemHealthCheck>;
export interface GreTunnelsListResponseGreTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: GreTunnelsListResponseGreTunnelsItemBgp | null;
    bgpStatus?: GreTunnelsListResponseGreTunnelsItemBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the GRE tunnel. */
    description?: string | null;
    healthCheck?: GreTunnelsListResponseGreTunnelsItemHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null;
}
export declare const GreTunnelsListResponseGreTunnelsItem: S.Schema<GreTunnelsListResponseGreTunnelsItem>;
export type GreTunnelsListResponseGreTunnelsList = Array<GreTunnelsListResponseGreTunnelsItem>;
export declare const GreTunnelsListResponseGreTunnelsList: S.Schema<GreTunnelsListResponseGreTunnelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListGreTunnelsResponse {
    greTunnels?: GreTunnelsListResponseGreTunnelsList | null;
}
export declare const ListGreTunnelsResponse: S.Schema<ListGreTunnelsResponse>;
export interface ListIpsecTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean;
}
export declare const ListIpsecTunnelsRequest: S.Schema<ListIpsecTunnelsRequest>;
export type IpsecTunnelsListResponseIpsecTunnelsItemBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsListResponseIpsecTunnelsItemBgpExtraPrefixesList: S.Schema<IpsecTunnelsListResponseIpsecTunnelsItemBgpExtraPrefixesList>;
export interface IpsecTunnelsListResponseIpsecTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsListResponseIpsecTunnelsItemBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const IpsecTunnelsListResponseIpsecTunnelsItemBgp: S.Schema<IpsecTunnelsListResponseIpsecTunnelsItemBgp>;
export type IpsecTunnelsListResponseIpsecTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const IpsecTunnelsListResponseIpsecTunnelsItemBgpStatusState: any;
export interface IpsecTunnelsListResponseIpsecTunnelsItemBgpStatus {
    state: IpsecTunnelsListResponseIpsecTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const IpsecTunnelsListResponseIpsecTunnelsItemBgpStatus: S.Schema<IpsecTunnelsListResponseIpsecTunnelsItemBgpStatus>;
export type IpsecTunnelsListResponseIpsecTunnelsItemCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export declare const IpsecTunnelsListResponseIpsecTunnelsItemCustomRemoteIdentities: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities>;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckDirection: any;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckRate: any;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTarget: any;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckType: any;
export interface IpsecTunnelsListResponseIpsecTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckType | null;
}
export declare const IpsecTunnelsListResponseIpsecTunnelsItemHealthCheck: S.Schema<IpsecTunnelsListResponseIpsecTunnelsItemHealthCheck>;
export type IpsecTunnelsListResponseIpsecTunnelsItemPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsListResponseIpsecTunnelsItemPskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
export interface IpsecTunnelsListResponseIpsecTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: IpsecTunnelsListResponseIpsecTunnelsItemBgp | null;
    bgpStatus?: IpsecTunnelsListResponseIpsecTunnelsItemBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null;
    healthCheck?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null;
}
export declare const IpsecTunnelsListResponseIpsecTunnelsItem: S.Schema<IpsecTunnelsListResponseIpsecTunnelsItem>;
export type IpsecTunnelsListResponseIpsecTunnelsList = Array<IpsecTunnelsListResponseIpsecTunnelsItem>;
export declare const IpsecTunnelsListResponseIpsecTunnelsList: S.Schema<IpsecTunnelsListResponseIpsecTunnelsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListIpsecTunnelsResponse {
    ipsecTunnels?: IpsecTunnelsListResponseIpsecTunnelsList | null;
}
export declare const ListIpsecTunnelsResponse: S.Schema<ListIpsecTunnelsResponse>;
export interface ListPcapsRequest {
    /** Identifier. */
    accountId: string;
}
export declare const ListPcapsRequest: S.Schema<ListPcapsRequest>;
export type PcapsListResultItemPCAPFilterV1 = PcapsCreateResultPCAPFilterV1;
export declare const PcapsListResultItemPCAPFilterV1: S.Schema<PcapsCreateResultPCAPFilterV1>;
export type PcapsListResultItemPCAPStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export declare const PcapsListResultItemPCAPStatus: any;
export type PcapsListResultItemPCAPSystem = "magic-transit";
export declare const PcapsListResultItemPCAPSystem: any;
export type PcapsListResultItemPCAPType = "simple" | "full";
export declare const PcapsListResultItemPCAPType: any;
export interface PcapsListResultItemPCAP {
    /** The ID for the packet capture. */
    id?: string | null;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | null;
    /** The status of the packet capture request. */
    status?: PcapsListResultItemPCAPStatus | null;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null;
    /** The system used to collect packet captures. */
    system?: PcapsListResultItemPCAPSystem | null;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsListResultItemPCAPType | null;
}
export declare const PcapsListResultItemPCAP: S.Schema<PcapsListResultItemPCAP>;
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export declare const PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullStatus: any;
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullSystem = "magic-transit";
export declare const PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullSystem: any;
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullType = "simple" | "full";
export declare const PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullType: any;
export interface PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFull {
    /** The ID for the packet capture. */
    id?: string | null;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | null;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | null;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | null;
    /** An error message that describes why the packet capture failed. This field only applies to `full` packet captures. */
    errorMessage?: string | null;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null;
    /** The number of packets captured. */
    packetsCaptured?: number | null;
    /** The status of the packet capture request. */
    status?: PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullStatus | null;
    /** The RFC 3339 timestamp when stopping the packet capture was requested. This field only applies to `full` packet captures. */
    stopRequested?: string | null;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null;
    /** The system used to collect packet captures. */
    system?: PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullSystem | null;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullType | null;
}
export declare const PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFull: S.Schema<PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFull>;
export type PcapsListResultItem = PcapsListResultItemPCAP | PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFull;
export declare const PcapsListResultItem: any;
export type PcapsListResultList = Array<PcapsListResultItem>;
export declare const PcapsListResultList: S.Schema<PcapsListResultList>;
export interface ListPcapsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PcapsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPcapsResponse: S.Schema<ListPcapsResponse>;
export interface ListRoutesRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListRoutesRequest: S.Schema<ListRoutesRequest>;
export type RoutesListResponseRoutesItemScopeColoNamesList = Array<string>;
export declare const RoutesListResponseRoutesItemScopeColoNamesList: S.Schema<RoutesListResponseRoutesItemScopeColoNamesList>;
export type RoutesListResponseRoutesItemScopeColoRegionsList = Array<string>;
export declare const RoutesListResponseRoutesItemScopeColoRegionsList: S.Schema<RoutesListResponseRoutesItemScopeColoRegionsList>;
export interface RoutesListResponseRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesListResponseRoutesItemScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesListResponseRoutesItemScopeColoRegionsList | null;
}
export declare const RoutesListResponseRoutesItemScope: S.Schema<RoutesListResponseRoutesItemScope>;
export interface RoutesListResponseRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesListResponseRoutesItemScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const RoutesListResponseRoutesItem: S.Schema<RoutesListResponseRoutesItem>;
export type RoutesListResponseRoutesList = Array<RoutesListResponseRoutesItem>;
export declare const RoutesListResponseRoutesList: S.Schema<RoutesListResponseRoutesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListRoutesResponse {
    routes?: RoutesListResponseRoutesList | null;
}
export declare const ListRoutesResponse: S.Schema<ListRoutesResponse>;
export interface ListSiteAclsRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export declare const ListSiteAclsRequest: S.Schema<ListSiteAclsRequest>;
export type SitesAclsListResultItemLan1PortRangesList = Array<string>;
export declare const SitesAclsListResultItemLan1PortRangesList: S.Schema<SitesAclsListResultItemLan1PortRangesList>;
export type SitesAclsListResultItemLan1PortsList = Array<number>;
export declare const SitesAclsListResultItemLan1PortsList: S.Schema<SitesAclsListResultItemLan1PortsList>;
export type SitesAclsListResultItemLan1SubnetsList = Array<string>;
export declare const SitesAclsListResultItemLan1SubnetsList: S.Schema<SitesAclsListResultItemLan1SubnetsList>;
export interface SitesAclsListResultItemLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsListResultItemLan1PortRangesList | null;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsListResultItemLan1PortsList | null;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsListResultItemLan1SubnetsList | null;
}
export declare const SitesAclsListResultItemLan1: S.Schema<SitesAclsListResultItemLan1>;
export type SitesAclsListResultItemProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsListResultItemProtocolsItem: any;
export type SitesAclsListResultItemProtocolsList = Array<SitesAclsListResultItemProtocolsItem>;
export declare const SitesAclsListResultItemProtocolsList: S.Schema<SitesAclsListResultItemProtocolsList>;
export interface SitesAclsListResultItem {
    /** Identifier */
    id?: string | null;
    /** Description for the ACL. */
    description?: string | null;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null;
    lan_1?: SitesAclsListResultItemLan1 | null;
    lan_2?: SitesAclsListResultItemLan1 | null;
    /** The name of the ACL. */
    name?: string | null;
    protocols?: SitesAclsListResultItemProtocolsList | null;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null;
}
export declare const SitesAclsListResultItem: S.Schema<SitesAclsListResultItem>;
export type SitesAclsListResultList = Array<SitesAclsListResultItem>;
export declare const SitesAclsListResultList: S.Schema<SitesAclsListResultList>;
export interface ListSiteAclsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesAclsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSiteAclsResponse: S.Schema<ListSiteAclsResponse>;
export interface ListSiteLansRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export declare const ListSiteLansRequest: S.Schema<ListSiteLansRequest>;
export type SitesLansListResultItemNat = SitesLansCreateResultItemNat;
export declare const SitesLansListResultItemNat: S.Schema<SitesLansCreateResultItemNat>;
export type SitesLansListResultItemRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export declare const SitesLansListResultItemRoutedSubnetsItem: S.Schema<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansListResultItemRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export declare const SitesLansListResultItemRoutedSubnetsList: S.Schema<SitesLansListResultItemRoutedSubnetsList>;
export type SitesLansListResultItemStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansListResultItemStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansListResultItemStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansListResultItemStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansListResultItemStaticAddressingDhcpRelayServerAddressesList | null;
}
export declare const SitesLansListResultItemStaticAddressingDhcpRelay: S.Schema<SitesLansListResultItemStaticAddressingDhcpRelay>;
export type SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansListResultItemStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansListResultItemStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansListResultItemStaticAddressingDhcpServerDnsServersList>;
export type SitesLansListResultItemStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansListResultItemStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansListResultItemStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansListResultItemStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsList | null;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null;
    /** A valid IPv4 address. */
    dnsServer?: string | null;
    dnsServers?: SitesLansListResultItemStaticAddressingDhcpServerDnsServersList | null;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansListResultItemStaticAddressingDhcpServerReservationsMap | null;
}
export declare const SitesLansListResultItemStaticAddressingDhcpServer: S.Schema<SitesLansListResultItemStaticAddressingDhcpServer>;
export interface SitesLansListResultItemStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansListResultItemStaticAddressingDhcpRelay | null;
    dhcpServer?: SitesLansListResultItemStaticAddressingDhcpServer | null;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null;
}
export declare const SitesLansListResultItemStaticAddressing: S.Schema<SitesLansListResultItemStaticAddressing>;
export interface SitesLansListResultItem {
    /** Identifier */
    id?: string | null;
    bondId?: number | null;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null;
    name?: string | null;
    nat?: SitesLansCreateResultItemNat | null;
    physport?: number | null;
    routedSubnets?: SitesLansListResultItemRoutedSubnetsList | null;
    /** Identifier */
    siteId?: string | null;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansListResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const SitesLansListResultItem: S.Schema<SitesLansListResultItem>;
export type SitesLansListResultList = Array<SitesLansListResultItem>;
export declare const SitesLansListResultList: S.Schema<SitesLansListResultList>;
export interface ListSiteLansResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesLansListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSiteLansResponse: S.Schema<ListSiteLansResponse>;
export interface ListSitesRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    connectorid?: string;
}
export declare const ListSitesRequest: S.Schema<ListSitesRequest>;
export type SitesListResultItemLocation = SitesCreateResponseLocation;
export declare const SitesListResultItemLocation: S.Schema<SitesCreateResponseLocation>;
export interface SitesListResultItem {
    /** Identifier */
    id?: string | null;
    /** Magic Connector identifier tag. */
    connectorId?: string | null;
    description?: string | null;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null;
    /** The name of the site. */
    name?: string | null;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null;
}
export declare const SitesListResultItem: S.Schema<SitesListResultItem>;
export type SitesListResultList = Array<SitesListResultItem>;
export declare const SitesListResultList: S.Schema<SitesListResultList>;
export interface ListSitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSitesResponse: S.Schema<ListSitesResponse>;
export interface ListSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export declare const ListSitesAppConfigurationRequest: S.Schema<ListSitesAppConfigurationRequest>;
export type ListSitesAppConfigurationResultItemAccountAppPreferredWansList = Array<string>;
export declare const ListSitesAppConfigurationResultItemAccountAppPreferredWansList: S.Schema<ListSitesAppConfigurationResultItemAccountAppPreferredWansList>;
export interface ListSitesAppConfigurationResultItemAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: ListSitesAppConfigurationResultItemAccountAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const ListSitesAppConfigurationResultItemAccountApp: S.Schema<ListSitesAppConfigurationResultItemAccountApp>;
export type ListSitesAppConfigurationResultItemManagedAppPreferredWansList = Array<string>;
export declare const ListSitesAppConfigurationResultItemManagedAppPreferredWansList: S.Schema<ListSitesAppConfigurationResultItemManagedAppPreferredWansList>;
export interface ListSitesAppConfigurationResultItemManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: ListSitesAppConfigurationResultItemManagedAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const ListSitesAppConfigurationResultItemManagedApp: S.Schema<ListSitesAppConfigurationResultItemManagedApp>;
export type ListSitesAppConfigurationResultItem = ListSitesAppConfigurationResultItemAccountApp | ListSitesAppConfigurationResultItemManagedApp;
export declare const ListSitesAppConfigurationResultItem: any;
export type ListSitesAppConfigurationResultList = Array<ListSitesAppConfigurationResultItem>;
export declare const ListSitesAppConfigurationResultList: S.Schema<ListSitesAppConfigurationResultList>;
export type ListSitesAppConfigurationResponse = ListSitesAppConfigurationResultList;
export declare const ListSitesAppConfigurationResponse: S.Schema<ListSitesAppConfigurationResponse>;
export interface ListSiteWansRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export declare const ListSiteWansRequest: S.Schema<ListSiteWansRequest>;
export type SitesWansListResultItemHealthCheckRate = "low" | "mid" | "high";
export declare const SitesWansListResultItemHealthCheckRate: any;
export type SitesWansListResultItemStaticAddressing = SitesWansCreateResultItemStaticAddressing;
export declare const SitesWansListResultItemStaticAddressing: S.Schema<SitesWansCreateResultItemStaticAddressing>;
export interface SitesWansListResultItem {
    /** Identifier */
    id?: string | null;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansListResultItemHealthCheckRate | null;
    name?: string | null;
    physport?: number | null;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const SitesWansListResultItem: S.Schema<SitesWansListResultItem>;
export type SitesWansListResultList = Array<SitesWansListResultItem>;
export declare const SitesWansListResultList: S.Schema<SitesWansListResultList>;
export interface ListSiteWansResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesWansListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSiteWansResponse: S.Schema<ListSiteWansResponse>;
export type AppsEditRequestHostnamesList = Array<string>;
export declare const AppsEditRequestHostnamesList: S.Schema<AppsEditRequestHostnamesList>;
export type AppsEditRequestIpSubnetsList = Array<string>;
export declare const AppsEditRequestIpSubnetsList: S.Schema<AppsEditRequestIpSubnetsList>;
export type AppsEditRequestSourceSubnetsList = Array<string>;
export declare const AppsEditRequestSourceSubnetsList: S.Schema<AppsEditRequestSourceSubnetsList>;
export interface PatchAppRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsEditRequestHostnamesList;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsEditRequestIpSubnetsList;
    /** Display name for the app. */
    name?: string;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsEditRequestSourceSubnetsList;
    /** Category of the app. */
    type?: string;
}
export declare const PatchAppRequest: S.Schema<PatchAppRequest>;
export type AppsEditResponseHostnamesList = Array<string>;
export declare const AppsEditResponseHostnamesList: S.Schema<AppsEditResponseHostnamesList>;
export type AppsEditResponseIpSubnetsList = Array<string>;
export declare const AppsEditResponseIpSubnetsList: S.Schema<AppsEditResponseIpSubnetsList>;
export type AppsEditResponseSourceSubnetsList = Array<string>;
export declare const AppsEditResponseSourceSubnetsList: S.Schema<AppsEditResponseSourceSubnetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsEditResponseHostnamesList | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsEditResponseIpSubnetsList | null;
    /** Display name for the app. */
    name?: string | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsEditResponseSourceSubnetsList | null;
    /** Category of the app. */
    type?: string | null;
}
export declare const PatchAppResponse: S.Schema<PatchAppResponse>;
export type Cf1SitesUpdateRequestLocation = Cf1SitesCreateRequestBodyItemLocation;
export declare const Cf1SitesUpdateRequestLocation: S.Schema<Cf1SitesCreateRequestBodyItemLocation>;
export interface PatchCf1SiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    /** A human-provided description of the CF1 Site. */
    description?: string;
    location?: Cf1SitesCreateRequestBodyItemLocation;
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name?: string;
}
export declare const PatchCf1SiteRequest: S.Schema<PatchCf1SiteRequest>;
export type Cf1SitesUpdateResponseLocation = Cf1SitesCreateResultItemLocation;
export declare const Cf1SitesUpdateResponseLocation: S.Schema<Cf1SitesCreateResultItemLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCf1SiteResponse {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null;
    createdOn?: string | null;
    /** A human-provided description of the CF1 Site. */
    description?: string | null;
    location?: Cf1SitesCreateResultItemLocation | null;
    modifiedOn?: string | null;
}
export declare const PatchCf1SiteResponse: S.Schema<PatchCf1SiteResponse>;
export type ConnectorsEditRequestInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsEditRequestInterruptWindowDaysOfWeekItem: any;
export type ConnectorsEditRequestInterruptWindowDaysOfWeekList = Array<ConnectorsEditRequestInterruptWindowDaysOfWeekItem | (string & {})>;
export declare const ConnectorsEditRequestInterruptWindowDaysOfWeekList: S.Schema<ConnectorsEditRequestInterruptWindowDaysOfWeekList>;
export type ConnectorsEditRequestInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsEditRequestInterruptWindowEmbargoDatesList: S.Schema<ConnectorsEditRequestInterruptWindowEmbargoDatesList>;
export interface PatchConnectorRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    activated?: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek?: ConnectorsEditRequestInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours?: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates?: ConnectorsEditRequestInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay?: number;
    notes?: string;
    primary?: boolean;
    /** When true, regenerate license key for the connector. */
    provisionLicense?: boolean;
    siteId?: string;
    timezone?: string;
}
export declare const PatchConnectorRequest: S.Schema<PatchConnectorRequest>;
export type ConnectorsEditResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsEditResponseInterruptWindowDaysOfWeekItem: any;
export type ConnectorsEditResponseInterruptWindowDaysOfWeekList = Array<ConnectorsEditResponseInterruptWindowDaysOfWeekItem>;
export declare const ConnectorsEditResponseInterruptWindowDaysOfWeekList: S.Schema<ConnectorsEditResponseInterruptWindowDaysOfWeekList>;
export type ConnectorsEditResponseInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsEditResponseInterruptWindowEmbargoDatesList: S.Schema<ConnectorsEditResponseInterruptWindowEmbargoDatesList>;
export type ConnectorsEditResponseDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsEditResponseDeviceType: any;
export interface ConnectorsEditResponseDevice {
    id: string;
    serialNumber?: string | null;
    type?: ConnectorsEditResponseDeviceType | null;
}
export declare const ConnectorsEditResponseDevice: S.Schema<ConnectorsEditResponseDevice>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsEditResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsEditResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    primary: boolean;
    timezone: string;
    device?: ConnectorsEditResponseDevice | null;
    lastHeartbeat?: string | null;
    lastSeenVersion?: string | null;
    licenseKey?: string | null;
    siteId?: string | null;
}
export declare const PatchConnectorResponse: S.Schema<PatchConnectorResponse>;
export type SitesEditRequestLocation = SitesCreateRequestLocation;
export declare const SitesEditRequestLocation: S.Schema<SitesCreateRequestLocation>;
export interface PatchSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Magic Connector identifier tag. */
    connectorId?: string;
    description?: string;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateRequestLocation;
    /** The name of the site. */
    name?: string;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string;
}
export declare const PatchSiteRequest: S.Schema<PatchSiteRequest>;
export type SitesEditResponseLocation = SitesCreateResponseLocation;
export declare const SitesEditResponseLocation: S.Schema<SitesCreateResponseLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteResponse {
    /** Identifier */
    id?: string | null;
    /** Magic Connector identifier tag. */
    connectorId?: string | null;
    description?: string | null;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null;
    /** The name of the site. */
    name?: string | null;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null;
}
export declare const PatchSiteResponse: S.Schema<PatchSiteResponse>;
export type SitesAclsEditRequestLan1PortRangesList = Array<string>;
export declare const SitesAclsEditRequestLan1PortRangesList: S.Schema<SitesAclsEditRequestLan1PortRangesList>;
export type SitesAclsEditRequestLan1PortsList = Array<number>;
export declare const SitesAclsEditRequestLan1PortsList: S.Schema<SitesAclsEditRequestLan1PortsList>;
export type SitesAclsEditRequestLan1SubnetsList = Array<string>;
export declare const SitesAclsEditRequestLan1SubnetsList: S.Schema<SitesAclsEditRequestLan1SubnetsList>;
export interface SitesAclsEditRequestLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsEditRequestLan1PortRangesList;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsEditRequestLan1PortsList;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsEditRequestLan1SubnetsList;
}
export declare const SitesAclsEditRequestLan1: S.Schema<SitesAclsEditRequestLan1>;
export type SitesAclsEditRequestProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsEditRequestProtocolsItem: any;
export type SitesAclsEditRequestProtocolsList = Array<SitesAclsEditRequestProtocolsItem | (string & {})>;
export declare const SitesAclsEditRequestProtocolsList: S.Schema<SitesAclsEditRequestProtocolsList>;
export interface PatchSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
    /** Description for the ACL. */
    description?: string;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean;
    lan_1?: SitesAclsEditRequestLan1;
    lan_2?: SitesAclsEditRequestLan1;
    /** The name of the ACL. */
    name?: string;
    protocols?: SitesAclsEditRequestProtocolsList;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean;
}
export declare const PatchSiteAclRequest: S.Schema<PatchSiteAclRequest>;
export type SitesAclsEditResponseLan1PortRangesList = Array<string>;
export declare const SitesAclsEditResponseLan1PortRangesList: S.Schema<SitesAclsEditResponseLan1PortRangesList>;
export type SitesAclsEditResponseLan1PortsList = Array<number>;
export declare const SitesAclsEditResponseLan1PortsList: S.Schema<SitesAclsEditResponseLan1PortsList>;
export type SitesAclsEditResponseLan1SubnetsList = Array<string>;
export declare const SitesAclsEditResponseLan1SubnetsList: S.Schema<SitesAclsEditResponseLan1SubnetsList>;
export interface SitesAclsEditResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsEditResponseLan1PortRangesList | null;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsEditResponseLan1PortsList | null;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsEditResponseLan1SubnetsList | null;
}
export declare const SitesAclsEditResponseLan1: S.Schema<SitesAclsEditResponseLan1>;
export type SitesAclsEditResponseProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsEditResponseProtocolsItem: any;
export type SitesAclsEditResponseProtocolsList = Array<SitesAclsEditResponseProtocolsItem>;
export declare const SitesAclsEditResponseProtocolsList: S.Schema<SitesAclsEditResponseProtocolsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteAclResponse {
    /** Identifier */
    id?: string | null;
    /** Description for the ACL. */
    description?: string | null;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null;
    lan_1?: SitesAclsEditResponseLan1 | null;
    lan_2?: SitesAclsEditResponseLan1 | null;
    /** The name of the ACL. */
    name?: string | null;
    protocols?: SitesAclsEditResponseProtocolsList | null;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null;
}
export declare const PatchSiteAclResponse: S.Schema<PatchSiteAclResponse>;
export type SitesLansEditRequestNat = SitesLansCreateRequestNat;
export declare const SitesLansEditRequestNat: S.Schema<SitesLansCreateRequestNat>;
export type SitesLansEditRequestRoutedSubnetsItem = SitesLansCreateRequestRoutedSubnetsItem;
export declare const SitesLansEditRequestRoutedSubnetsItem: S.Schema<SitesLansCreateRequestRoutedSubnetsItem>;
export type SitesLansEditRequestRoutedSubnetsList = Array<SitesLansCreateRequestRoutedSubnetsItem>;
export declare const SitesLansEditRequestRoutedSubnetsList: S.Schema<SitesLansEditRequestRoutedSubnetsList>;
export type SitesLansEditRequestStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansEditRequestStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansEditRequestStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansEditRequestStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansEditRequestStaticAddressingDhcpRelayServerAddressesList;
}
export declare const SitesLansEditRequestStaticAddressingDhcpRelay: S.Schema<SitesLansEditRequestStaticAddressingDhcpRelay>;
export type SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItemType | (string & {});
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansEditRequestStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansEditRequestStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansEditRequestStaticAddressingDhcpServerDnsServersList>;
export type SitesLansEditRequestStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansEditRequestStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansEditRequestStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansEditRequestStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsList;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string;
    /** A valid IPv4 address. */
    dnsServer?: string;
    dnsServers?: SitesLansEditRequestStaticAddressingDhcpServerDnsServersList;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansEditRequestStaticAddressingDhcpServerReservationsMap;
}
export declare const SitesLansEditRequestStaticAddressingDhcpServer: S.Schema<SitesLansEditRequestStaticAddressingDhcpServer>;
export interface SitesLansEditRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansEditRequestStaticAddressingDhcpRelay;
    dhcpServer?: SitesLansEditRequestStaticAddressingDhcpServer;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string;
}
export declare const SitesLansEditRequestStaticAddressing: S.Schema<SitesLansEditRequestStaticAddressing>;
export interface PatchSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
    bondId?: number;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean;
    name?: string;
    nat?: SitesLansCreateRequestNat;
    physport?: number;
    routedSubnets?: SitesLansEditRequestRoutedSubnetsList;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansEditRequestStaticAddressing;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number;
}
export declare const PatchSiteLanRequest: S.Schema<PatchSiteLanRequest>;
export type SitesLansEditResponseNat = SitesLansCreateResultItemNat;
export declare const SitesLansEditResponseNat: S.Schema<SitesLansCreateResultItemNat>;
export type SitesLansEditResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export declare const SitesLansEditResponseRoutedSubnetsItem: S.Schema<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansEditResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export declare const SitesLansEditResponseRoutedSubnetsList: S.Schema<SitesLansEditResponseRoutedSubnetsList>;
export type SitesLansEditResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansEditResponseStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansEditResponseStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansEditResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansEditResponseStaticAddressingDhcpRelayServerAddressesList | null;
}
export declare const SitesLansEditResponseStaticAddressingDhcpRelay: S.Schema<SitesLansEditResponseStaticAddressingDhcpRelay>;
export type SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansEditResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansEditResponseStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansEditResponseStaticAddressingDhcpServerDnsServersList>;
export type SitesLansEditResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansEditResponseStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansEditResponseStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansEditResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsList | null;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null;
    /** A valid IPv4 address. */
    dnsServer?: string | null;
    dnsServers?: SitesLansEditResponseStaticAddressingDhcpServerDnsServersList | null;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansEditResponseStaticAddressingDhcpServerReservationsMap | null;
}
export declare const SitesLansEditResponseStaticAddressingDhcpServer: S.Schema<SitesLansEditResponseStaticAddressingDhcpServer>;
export interface SitesLansEditResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansEditResponseStaticAddressingDhcpRelay | null;
    dhcpServer?: SitesLansEditResponseStaticAddressingDhcpServer | null;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null;
}
export declare const SitesLansEditResponseStaticAddressing: S.Schema<SitesLansEditResponseStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteLanResponse {
    /** Identifier */
    id?: string | null;
    bondId?: number | null;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null;
    name?: string | null;
    nat?: SitesLansCreateResultItemNat | null;
    physport?: number | null;
    routedSubnets?: SitesLansEditResponseRoutedSubnetsList | null;
    /** Identifier */
    siteId?: string | null;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansEditResponseStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const PatchSiteLanResponse: S.Schema<PatchSiteLanResponse>;
export type SitesWansEditRequestStaticAddressing = SitesWansCreateRequestStaticAddressing;
export declare const SitesWansEditRequestStaticAddressing: S.Schema<SitesWansCreateRequestStaticAddressing>;
export interface PatchSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
    name?: string;
    physport?: number;
    priority?: number;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateRequestStaticAddressing;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number;
}
export declare const PatchSiteWanRequest: S.Schema<PatchSiteWanRequest>;
export type SitesWansEditResponseHealthCheckRate = "low" | "mid" | "high";
export declare const SitesWansEditResponseHealthCheckRate: any;
export type SitesWansEditResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
export declare const SitesWansEditResponseStaticAddressing: S.Schema<SitesWansCreateResultItemStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteWanResponse {
    /** Identifier */
    id?: string | null;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansEditResponseHealthCheckRate | null;
    name?: string | null;
    physport?: number | null;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const PatchSiteWanResponse: S.Schema<PatchSiteWanResponse>;
export interface PskGenerateIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
}
export declare const PskGenerateIpsecTunnelRequest: S.Schema<PskGenerateIpsecTunnelRequest>;
export type IpsecTunnelsPskGenerateResponsePskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsPskGenerateResponsePskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PskGenerateIpsecTunnelResponse {
    /** Identifier */
    ipsecTunnelId?: string | null;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
}
export declare const PskGenerateIpsecTunnelResponse: S.Schema<PskGenerateIpsecTunnelResponse>;
export interface IpsecTunnelsPskSetRequestPsksItem {
    /** The ID of the IPsec tunnel. */
    id: string;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk: string;
}
export declare const IpsecTunnelsPskSetRequestPsksItem: S.Schema<IpsecTunnelsPskSetRequestPsksItem>;
export type IpsecTunnelsPskSetRequestPsksList = Array<IpsecTunnelsPskSetRequestPsksItem>;
export declare const IpsecTunnelsPskSetRequestPsksList: S.Schema<IpsecTunnelsPskSetRequestPsksList>;
export interface PskSetIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** If `true`, only run validation without persisting changes. */
    validateOnly?: boolean;
    /** List of tunnel ID and PSK pairs. */
    psks: IpsecTunnelsPskSetRequestPsksList;
}
export declare const PskSetIpsecTunnelRequest: S.Schema<PskSetIpsecTunnelRequest>;
export type IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValuePskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValuePskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
export interface IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValue {
    /** The IKE identifier used for this tunnel on the Cloudflare edge. */
    ipsecId: string;
    /** Identifier */
    ipsecTunnelId: string;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk: string;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
}
export declare const IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValue: S.Schema<IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValue>;
export type IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksMap = {
    [key: string]: IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValue | undefined;
};
export declare const IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksMap: S.Schema<IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksMap>;
export type IpsecTunnelsPskSetResponseUnappliedPsksMap = {
    [key: string]: string | undefined;
};
export declare const IpsecTunnelsPskSetResponseUnappliedPsksMap: S.Schema<IpsecTunnelsPskSetResponseUnappliedPsksMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PskSetIpsecTunnelResponse {
    /** Map of tunnel IDs to successfully applied PSK details. */
    successfullyAppliedPsks?: IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksMap | null;
    /** Map of tunnel IDs to failure reasons for PSKs that could not be applied. */
    unappliedPsks?: IpsecTunnelsPskSetResponseUnappliedPsksMap | null;
}
export declare const PskSetIpsecTunnelResponse: S.Schema<PskSetIpsecTunnelResponse>;
export interface CfInterconnectsUpdateRequestGre {
    /** The IP address assigned to the Cloudflare side of the GRE tunnel created as part of the Interconnect. */
    cloudflareEndpoint?: string;
}
export declare const CfInterconnectsUpdateRequestGre: S.Schema<CfInterconnectsUpdateRequestGre>;
export type CfInterconnectsUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export declare const CfInterconnectsUpdateRequestHealthCheckRate: any;
export type CfInterconnectsUpdateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsUpdateRequestHealthCheckTargetMagicHealthCheckTarget: S.Schema<GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget>;
export type CfInterconnectsUpdateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsUpdateRequestHealthCheckTarget: any;
export type CfInterconnectsUpdateRequestHealthCheckType = "reply" | "request";
export declare const CfInterconnectsUpdateRequestHealthCheckType: any;
export interface CfInterconnectsUpdateRequestHealthCheck {
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsUpdateRequestHealthCheckRate | (string & {});
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsUpdateRequestHealthCheckTarget;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsUpdateRequestHealthCheckType | (string & {});
}
export declare const CfInterconnectsUpdateRequestHealthCheck: S.Schema<CfInterconnectsUpdateRequestHealthCheck>;
export interface PutCfInterconnectRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cfInterconnectId: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean;
    /** An optional description of the interconnect. */
    description?: string;
    /** The configuration specific to GRE interconnects. */
    gre?: CfInterconnectsUpdateRequestGre;
    healthCheck?: CfInterconnectsUpdateRequestHealthCheck;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress?: string;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string;
    xMagicNewHcTarget?: boolean;
}
export declare const PutCfInterconnectRequest: S.Schema<PutCfInterconnectRequest>;
export type CfInterconnectsUpdateResponseModifiedInterconnectGre = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre;
export declare const CfInterconnectsUpdateResponseModifiedInterconnectGre: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre>;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckRate = "low" | "mid" | "high";
export declare const CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckRate: any;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTarget: any;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckType = "reply" | "request";
export declare const CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckType: any;
export interface CfInterconnectsUpdateResponseModifiedInterconnectHealthCheck {
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckType | null;
}
export declare const CfInterconnectsUpdateResponseModifiedInterconnectHealthCheck: S.Schema<CfInterconnectsUpdateResponseModifiedInterconnectHealthCheck>;
export interface CfInterconnectsUpdateResponseModifiedInterconnect {
    /** Identifier */
    id?: string | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the interconnect. */
    description?: string | null;
    /** The configuration specific to GRE interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null;
    healthCheck?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheck | null;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress?: string | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null;
}
export declare const CfInterconnectsUpdateResponseModifiedInterconnect: S.Schema<CfInterconnectsUpdateResponseModifiedInterconnect>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCfInterconnectResponse {
    modified?: boolean | null;
    modifiedInterconnect?: CfInterconnectsUpdateResponseModifiedInterconnect | null;
}
export declare const PutCfInterconnectResponse: S.Schema<PutCfInterconnectResponse>;
export interface StopPcapRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    pcapId: string;
}
export declare const StopPcapRequest: S.Schema<StopPcapRequest>;
export interface StopPcapResponse {
}
export declare const StopPcapResponse: S.Schema<StopPcapResponse>;
export type AppsUpdateRequestHostnamesList = Array<string>;
export declare const AppsUpdateRequestHostnamesList: S.Schema<AppsUpdateRequestHostnamesList>;
export type AppsUpdateRequestIpSubnetsList = Array<string>;
export declare const AppsUpdateRequestIpSubnetsList: S.Schema<AppsUpdateRequestIpSubnetsList>;
export type AppsUpdateRequestSourceSubnetsList = Array<string>;
export declare const AppsUpdateRequestSourceSubnetsList: S.Schema<AppsUpdateRequestSourceSubnetsList>;
export interface UpdateAppRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsUpdateRequestHostnamesList;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsUpdateRequestIpSubnetsList;
    /** Display name for the app. */
    name?: string;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsUpdateRequestSourceSubnetsList;
    /** Category of the app. */
    type?: string;
}
export declare const UpdateAppRequest: S.Schema<UpdateAppRequest>;
export type AppsUpdateResponseHostnamesList = Array<string>;
export declare const AppsUpdateResponseHostnamesList: S.Schema<AppsUpdateResponseHostnamesList>;
export type AppsUpdateResponseIpSubnetsList = Array<string>;
export declare const AppsUpdateResponseIpSubnetsList: S.Schema<AppsUpdateResponseIpSubnetsList>;
export type AppsUpdateResponseSourceSubnetsList = Array<string>;
export declare const AppsUpdateResponseSourceSubnetsList: S.Schema<AppsUpdateResponseSourceSubnetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsUpdateResponseHostnamesList | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsUpdateResponseIpSubnetsList | null;
    /** Display name for the app. */
    name?: string | null;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsUpdateResponseSourceSubnetsList | null;
    /** Category of the app. */
    type?: string | null;
}
export declare const UpdateAppResponse: S.Schema<UpdateAppResponse>;
export type ConnectorsUpdateRequestInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsUpdateRequestInterruptWindowDaysOfWeekItem: any;
export type ConnectorsUpdateRequestInterruptWindowDaysOfWeekList = Array<ConnectorsUpdateRequestInterruptWindowDaysOfWeekItem | (string & {})>;
export declare const ConnectorsUpdateRequestInterruptWindowDaysOfWeekList: S.Schema<ConnectorsUpdateRequestInterruptWindowDaysOfWeekList>;
export type ConnectorsUpdateRequestInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsUpdateRequestInterruptWindowEmbargoDatesList: S.Schema<ConnectorsUpdateRequestInterruptWindowEmbargoDatesList>;
export interface UpdateConnectorRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    activated?: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek?: ConnectorsUpdateRequestInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours?: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates?: ConnectorsUpdateRequestInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay?: number;
    notes?: string;
    primary?: boolean;
    /** When true, regenerate license key for the connector. */
    provisionLicense?: boolean;
    siteId?: string;
    timezone?: string;
}
export declare const UpdateConnectorRequest: S.Schema<UpdateConnectorRequest>;
export type ConnectorsUpdateResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export declare const ConnectorsUpdateResponseInterruptWindowDaysOfWeekItem: any;
export type ConnectorsUpdateResponseInterruptWindowDaysOfWeekList = Array<ConnectorsUpdateResponseInterruptWindowDaysOfWeekItem>;
export declare const ConnectorsUpdateResponseInterruptWindowDaysOfWeekList: S.Schema<ConnectorsUpdateResponseInterruptWindowDaysOfWeekList>;
export type ConnectorsUpdateResponseInterruptWindowEmbargoDatesList = Array<string>;
export declare const ConnectorsUpdateResponseInterruptWindowEmbargoDatesList: S.Schema<ConnectorsUpdateResponseInterruptWindowEmbargoDatesList>;
export type ConnectorsUpdateResponseDeviceType = "MANAGED" | "LICENSED";
export declare const ConnectorsUpdateResponseDeviceType: any;
export interface ConnectorsUpdateResponseDevice {
    id: string;
    serialNumber?: string | null;
    type?: ConnectorsUpdateResponseDeviceType | null;
}
export declare const ConnectorsUpdateResponseDevice: S.Schema<ConnectorsUpdateResponseDevice>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsUpdateResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsUpdateResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    primary: boolean;
    timezone: string;
    device?: ConnectorsUpdateResponseDevice | null;
    lastHeartbeat?: string | null;
    lastSeenVersion?: string | null;
    licenseKey?: string | null;
    siteId?: string | null;
}
export declare const UpdateConnectorResponse: S.Schema<UpdateConnectorResponse>;
export type GreTunnelsUpdateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsUpdateRequestHealthCheckDirection: any;
export type GreTunnelsUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsUpdateRequestHealthCheckRate: any;
export type GreTunnelsUpdateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsUpdateRequestHealthCheckTargetMagicHealthCheckTarget: S.Schema<GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsUpdateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsUpdateRequestHealthCheckTarget: any;
export type GreTunnelsUpdateRequestHealthCheckType = "reply" | "request";
export declare const GreTunnelsUpdateRequestHealthCheckType: any;
export interface GreTunnelsUpdateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsUpdateRequestHealthCheckDirection | (string & {});
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsUpdateRequestHealthCheckRate | (string & {});
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsUpdateRequestHealthCheckTarget;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsUpdateRequestHealthCheckType | (string & {});
}
export declare const GreTunnelsUpdateRequestHealthCheck: S.Schema<GreTunnelsUpdateRequestHealthCheck>;
export interface UpdateGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    greTunnelId: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean;
    /** An optional description of the GRE tunnel. */
    description?: string;
    healthCheck?: GreTunnelsUpdateRequestHealthCheck;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number;
    xMagicNewHcTarget?: boolean;
}
export declare const UpdateGreTunnelRequest: S.Schema<UpdateGreTunnelRequest>;
export type GreTunnelsUpdateResponseModifiedGreTunnelBgpExtraPrefixesList = Array<string>;
export declare const GreTunnelsUpdateResponseModifiedGreTunnelBgpExtraPrefixesList: S.Schema<GreTunnelsUpdateResponseModifiedGreTunnelBgpExtraPrefixesList>;
export interface GreTunnelsUpdateResponseModifiedGreTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: GreTunnelsUpdateResponseModifiedGreTunnelBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const GreTunnelsUpdateResponseModifiedGreTunnelBgp: S.Schema<GreTunnelsUpdateResponseModifiedGreTunnelBgp>;
export type GreTunnelsUpdateResponseModifiedGreTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const GreTunnelsUpdateResponseModifiedGreTunnelBgpStatusState: any;
export interface GreTunnelsUpdateResponseModifiedGreTunnelBgpStatus {
    state: GreTunnelsUpdateResponseModifiedGreTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const GreTunnelsUpdateResponseModifiedGreTunnelBgpStatus: S.Schema<GreTunnelsUpdateResponseModifiedGreTunnelBgpStatus>;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckDirection: any;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckRate = "low" | "mid" | "high";
export declare const GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckRate: any;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTarget: any;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckType = "reply" | "request";
export declare const GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckType: any;
export interface GreTunnelsUpdateResponseModifiedGreTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckType | null;
}
export declare const GreTunnelsUpdateResponseModifiedGreTunnelHealthCheck: S.Schema<GreTunnelsUpdateResponseModifiedGreTunnelHealthCheck>;
export interface GreTunnelsUpdateResponseModifiedGreTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: GreTunnelsUpdateResponseModifiedGreTunnelBgp | null;
    bgpStatus?: GreTunnelsUpdateResponseModifiedGreTunnelBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    /** An optional description of the GRE tunnel. */
    description?: string | null;
    healthCheck?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null;
}
export declare const GreTunnelsUpdateResponseModifiedGreTunnel: S.Schema<GreTunnelsUpdateResponseModifiedGreTunnel>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateGreTunnelResponse {
    modified?: boolean | null;
    modifiedGreTunnel?: GreTunnelsUpdateResponseModifiedGreTunnel | null;
}
export declare const UpdateGreTunnelResponse: S.Schema<UpdateGreTunnelResponse>;
export type IpsecTunnelsUpdateRequestBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsUpdateRequestBgpExtraPrefixesList: S.Schema<IpsecTunnelsUpdateRequestBgpExtraPrefixesList>;
export interface IpsecTunnelsUpdateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsUpdateRequestBgpExtraPrefixesList;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export declare const IpsecTunnelsUpdateRequestBgp: S.Schema<IpsecTunnelsUpdateRequestBgp>;
export type IpsecTunnelsUpdateRequestCustomRemoteIdentities = IpsecTunnelsCreateRequestCustomRemoteIdentities;
export declare const IpsecTunnelsUpdateRequestCustomRemoteIdentities: S.Schema<IpsecTunnelsCreateRequestCustomRemoteIdentities>;
export type IpsecTunnelsUpdateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsUpdateRequestHealthCheckDirection: any;
export type IpsecTunnelsUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsUpdateRequestHealthCheckRate: any;
export type IpsecTunnelsUpdateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsUpdateRequestHealthCheckTargetMagicHealthCheckTarget: S.Schema<GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsUpdateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsUpdateRequestHealthCheckTarget: any;
export type IpsecTunnelsUpdateRequestHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsUpdateRequestHealthCheckType: any;
export interface IpsecTunnelsUpdateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsUpdateRequestHealthCheckDirection | (string & {});
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsUpdateRequestHealthCheckRate | (string & {});
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsUpdateRequestHealthCheckTarget;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsUpdateRequestHealthCheckType | (string & {});
}
export declare const IpsecTunnelsUpdateRequestHealthCheck: S.Schema<IpsecTunnelsUpdateRequestHealthCheck>;
export interface UpdateIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean;
    bgp?: IpsecTunnelsUpdateRequestBgp;
    customRemoteIdentities?: IpsecTunnelsCreateRequestCustomRemoteIdentities;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string;
    /** An optional description forthe IPsec tunnel. */
    description?: string;
    healthCheck?: IpsecTunnelsUpdateRequestHealthCheck;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk?: string;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean;
    xMagicNewHcTarget?: boolean;
}
export declare const UpdateIpsecTunnelRequest: S.Schema<UpdateIpsecTunnelRequest>;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpExtraPrefixesList = Array<string>;
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpExtraPrefixesList: S.Schema<IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpExtraPrefixesList>;
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. */
    extraPrefixes?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpExtraPrefixesList | null;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgp: S.Schema<IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgp>;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatusState: any;
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatus {
    state: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null;
    cfSpeakerIp?: string | null;
    cfSpeakerPort?: number | null;
    customerSpeakerIp?: string | null;
    customerSpeakerPort?: number | null;
}
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatus: S.Schema<IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatus>;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelCustomRemoteIdentities: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities>;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckDirection: any;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckRate = "low" | "mid" | "high";
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckRate: any;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTargetMagicHealthCheckTarget: S.Schema<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget>;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTarget: any;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckType = "reply" | "request";
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckType: any;
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckDirection | null;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckRate | null;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTarget | null;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckType | null;
}
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheck: S.Schema<IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheck>;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnelPskMetadata: S.Schema<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata>;
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0–10.255.255.255, 172.16.0.0–172.31.255.255, 192.168.0.0–192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null;
    bgp?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgp | null;
    bgpStatus?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatus | null;
    /** The date and time the tunnel was created. */
    createdOn?: string | null;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null;
    healthCheck?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheck | null;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null;
}
export declare const IpsecTunnelsUpdateResponseModifiedIpsecTunnel: S.Schema<IpsecTunnelsUpdateResponseModifiedIpsecTunnel>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateIpsecTunnelResponse {
    modified?: boolean | null;
    modifiedIpsecTunnel?: IpsecTunnelsUpdateResponseModifiedIpsecTunnel | null;
}
export declare const UpdateIpsecTunnelResponse: S.Schema<UpdateIpsecTunnelResponse>;
export type RoutesUpdateRequestScopeColoNamesList = Array<string>;
export declare const RoutesUpdateRequestScopeColoNamesList: S.Schema<RoutesUpdateRequestScopeColoNamesList>;
export type RoutesUpdateRequestScopeColoRegionsList = Array<string>;
export declare const RoutesUpdateRequestScopeColoRegionsList: S.Schema<RoutesUpdateRequestScopeColoRegionsList>;
export interface RoutesUpdateRequestScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesUpdateRequestScopeColoNamesList;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesUpdateRequestScopeColoRegionsList;
}
export declare const RoutesUpdateRequestScope: S.Schema<RoutesUpdateRequestScope>;
export interface UpdateRouteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    routeId: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** An optional human provided description of the static route. */
    description?: string;
    /** Used only for ECMP routes. */
    scope?: RoutesUpdateRequestScope;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number;
}
export declare const UpdateRouteRequest: S.Schema<UpdateRouteRequest>;
export type RoutesUpdateResponseModifiedRouteScopeColoNamesList = Array<string>;
export declare const RoutesUpdateResponseModifiedRouteScopeColoNamesList: S.Schema<RoutesUpdateResponseModifiedRouteScopeColoNamesList>;
export type RoutesUpdateResponseModifiedRouteScopeColoRegionsList = Array<string>;
export declare const RoutesUpdateResponseModifiedRouteScopeColoRegionsList: S.Schema<RoutesUpdateResponseModifiedRouteScopeColoRegionsList>;
export interface RoutesUpdateResponseModifiedRouteScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesUpdateResponseModifiedRouteScopeColoNamesList | null;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesUpdateResponseModifiedRouteScopeColoRegionsList | null;
}
export declare const RoutesUpdateResponseModifiedRouteScope: S.Schema<RoutesUpdateResponseModifiedRouteScope>;
export interface RoutesUpdateResponseModifiedRoute {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null;
    /** An optional human provided description of the static route. */
    description?: string | null;
    /** When the route was last modified. */
    modifiedOn?: string | null;
    /** Used only for ECMP routes. */
    scope?: RoutesUpdateResponseModifiedRouteScope | null;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null;
}
export declare const RoutesUpdateResponseModifiedRoute: S.Schema<RoutesUpdateResponseModifiedRoute>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRouteResponse {
    modified?: boolean | null;
    modifiedRoute?: RoutesUpdateResponseModifiedRoute | null;
}
export declare const UpdateRouteResponse: S.Schema<UpdateRouteResponse>;
export type SitesUpdateRequestLocation = SitesCreateRequestLocation;
export declare const SitesUpdateRequestLocation: S.Schema<SitesCreateRequestLocation>;
export interface UpdateSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Magic Connector identifier tag. */
    connectorId?: string;
    description?: string;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateRequestLocation;
    /** The name of the site. */
    name?: string;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string;
}
export declare const UpdateSiteRequest: S.Schema<UpdateSiteRequest>;
export type SitesUpdateResponseLocation = SitesCreateResponseLocation;
export declare const SitesUpdateResponseLocation: S.Schema<SitesCreateResponseLocation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteResponse {
    /** Identifier */
    id?: string | null;
    /** Magic Connector identifier tag. */
    connectorId?: string | null;
    description?: string | null;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null;
    /** The name of the site. */
    name?: string | null;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null;
}
export declare const UpdateSiteResponse: S.Schema<UpdateSiteResponse>;
export type SitesAclsUpdateRequestLan1PortRangesList = Array<string>;
export declare const SitesAclsUpdateRequestLan1PortRangesList: S.Schema<SitesAclsUpdateRequestLan1PortRangesList>;
export type SitesAclsUpdateRequestLan1PortsList = Array<number>;
export declare const SitesAclsUpdateRequestLan1PortsList: S.Schema<SitesAclsUpdateRequestLan1PortsList>;
export type SitesAclsUpdateRequestLan1SubnetsList = Array<string>;
export declare const SitesAclsUpdateRequestLan1SubnetsList: S.Schema<SitesAclsUpdateRequestLan1SubnetsList>;
export interface SitesAclsUpdateRequestLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsUpdateRequestLan1PortRangesList;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsUpdateRequestLan1PortsList;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsUpdateRequestLan1SubnetsList;
}
export declare const SitesAclsUpdateRequestLan1: S.Schema<SitesAclsUpdateRequestLan1>;
export type SitesAclsUpdateRequestProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsUpdateRequestProtocolsItem: any;
export type SitesAclsUpdateRequestProtocolsList = Array<SitesAclsUpdateRequestProtocolsItem | (string & {})>;
export declare const SitesAclsUpdateRequestProtocolsList: S.Schema<SitesAclsUpdateRequestProtocolsList>;
export interface UpdateSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
    /** Description for the ACL. */
    description?: string;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean;
    lan_1?: SitesAclsUpdateRequestLan1;
    lan_2?: SitesAclsUpdateRequestLan1;
    /** The name of the ACL. */
    name?: string;
    protocols?: SitesAclsUpdateRequestProtocolsList;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean;
}
export declare const UpdateSiteAclRequest: S.Schema<UpdateSiteAclRequest>;
export type SitesAclsUpdateResponseLan1PortRangesList = Array<string>;
export declare const SitesAclsUpdateResponseLan1PortRangesList: S.Schema<SitesAclsUpdateResponseLan1PortRangesList>;
export type SitesAclsUpdateResponseLan1PortsList = Array<number>;
export declare const SitesAclsUpdateResponseLan1PortsList: S.Schema<SitesAclsUpdateResponseLan1PortsList>;
export type SitesAclsUpdateResponseLan1SubnetsList = Array<string>;
export declare const SitesAclsUpdateResponseLan1SubnetsList: S.Schema<SitesAclsUpdateResponseLan1SubnetsList>;
export interface SitesAclsUpdateResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsUpdateResponseLan1PortRangesList | null;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsUpdateResponseLan1PortsList | null;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsUpdateResponseLan1SubnetsList | null;
}
export declare const SitesAclsUpdateResponseLan1: S.Schema<SitesAclsUpdateResponseLan1>;
export type SitesAclsUpdateResponseProtocolsItem = "tcp" | "udp" | "icmp";
export declare const SitesAclsUpdateResponseProtocolsItem: any;
export type SitesAclsUpdateResponseProtocolsList = Array<SitesAclsUpdateResponseProtocolsItem>;
export declare const SitesAclsUpdateResponseProtocolsList: S.Schema<SitesAclsUpdateResponseProtocolsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteAclResponse {
    /** Identifier */
    id?: string | null;
    /** Description for the ACL. */
    description?: string | null;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null;
    lan_1?: SitesAclsUpdateResponseLan1 | null;
    lan_2?: SitesAclsUpdateResponseLan1 | null;
    /** The name of the ACL. */
    name?: string | null;
    protocols?: SitesAclsUpdateResponseProtocolsList | null;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null;
}
export declare const UpdateSiteAclResponse: S.Schema<UpdateSiteAclResponse>;
export type SitesLansUpdateRequestNat = SitesLansCreateRequestNat;
export declare const SitesLansUpdateRequestNat: S.Schema<SitesLansCreateRequestNat>;
export type SitesLansUpdateRequestRoutedSubnetsItem = SitesLansCreateRequestRoutedSubnetsItem;
export declare const SitesLansUpdateRequestRoutedSubnetsItem: S.Schema<SitesLansCreateRequestRoutedSubnetsItem>;
export type SitesLansUpdateRequestRoutedSubnetsList = Array<SitesLansCreateRequestRoutedSubnetsItem>;
export declare const SitesLansUpdateRequestRoutedSubnetsList: S.Schema<SitesLansUpdateRequestRoutedSubnetsList>;
export type SitesLansUpdateRequestStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansUpdateRequestStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansUpdateRequestStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansUpdateRequestStaticAddressingDhcpRelayServerAddressesList;
}
export declare const SitesLansUpdateRequestStaticAddressingDhcpRelay: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpRelay>;
export type SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItemType | (string & {});
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansUpdateRequestStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansUpdateRequestStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpServerDnsServersList>;
export type SitesLansUpdateRequestStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansUpdateRequestStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansUpdateRequestStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsList;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string;
    /** A valid IPv4 address. */
    dnsServer?: string;
    dnsServers?: SitesLansUpdateRequestStaticAddressingDhcpServerDnsServersList;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansUpdateRequestStaticAddressingDhcpServerReservationsMap;
}
export declare const SitesLansUpdateRequestStaticAddressingDhcpServer: S.Schema<SitesLansUpdateRequestStaticAddressingDhcpServer>;
export interface SitesLansUpdateRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansUpdateRequestStaticAddressingDhcpRelay;
    dhcpServer?: SitesLansUpdateRequestStaticAddressingDhcpServer;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string;
}
export declare const SitesLansUpdateRequestStaticAddressing: S.Schema<SitesLansUpdateRequestStaticAddressing>;
export interface UpdateSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
    bondId?: number;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean;
    name?: string;
    nat?: SitesLansCreateRequestNat;
    physport?: number;
    routedSubnets?: SitesLansUpdateRequestRoutedSubnetsList;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansUpdateRequestStaticAddressing;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number;
}
export declare const UpdateSiteLanRequest: S.Schema<UpdateSiteLanRequest>;
export type SitesLansUpdateResponseNat = SitesLansCreateResultItemNat;
export declare const SitesLansUpdateResponseNat: S.Schema<SitesLansCreateResultItemNat>;
export type SitesLansUpdateResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export declare const SitesLansUpdateResponseRoutedSubnetsItem: S.Schema<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansUpdateResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export declare const SitesLansUpdateResponseRoutedSubnetsList: S.Schema<SitesLansUpdateResponseRoutedSubnetsList>;
export type SitesLansUpdateResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export declare const SitesLansUpdateResponseStaticAddressingDhcpRelayServerAddressesList: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpRelayServerAddressesList>;
export interface SitesLansUpdateResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansUpdateResponseStaticAddressingDhcpRelayServerAddressesList | null;
}
export declare const SitesLansUpdateResponseStaticAddressingDhcpRelay: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpRelay>;
export type SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export declare const SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItemType: any;
export interface SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export declare const SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItem: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export declare const SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsList: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsList>;
export type SitesLansUpdateResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export declare const SitesLansUpdateResponseStaticAddressingDhcpServerDnsServersList: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpServerDnsServersList>;
export type SitesLansUpdateResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export declare const SitesLansUpdateResponseStaticAddressingDhcpServerReservationsMap: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpServerReservationsMap>;
export interface SitesLansUpdateResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsList | null;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null;
    /** A valid IPv4 address. */
    dnsServer?: string | null;
    dnsServers?: SitesLansUpdateResponseStaticAddressingDhcpServerDnsServersList | null;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansUpdateResponseStaticAddressingDhcpServerReservationsMap | null;
}
export declare const SitesLansUpdateResponseStaticAddressingDhcpServer: S.Schema<SitesLansUpdateResponseStaticAddressingDhcpServer>;
export interface SitesLansUpdateResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansUpdateResponseStaticAddressingDhcpRelay | null;
    dhcpServer?: SitesLansUpdateResponseStaticAddressingDhcpServer | null;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null;
}
export declare const SitesLansUpdateResponseStaticAddressing: S.Schema<SitesLansUpdateResponseStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteLanResponse {
    /** Identifier */
    id?: string | null;
    bondId?: number | null;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null;
    name?: string | null;
    nat?: SitesLansCreateResultItemNat | null;
    physport?: number | null;
    routedSubnets?: SitesLansUpdateResponseRoutedSubnetsList | null;
    /** Identifier */
    siteId?: string | null;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansUpdateResponseStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const UpdateSiteLanResponse: S.Schema<UpdateSiteLanResponse>;
export type UpdateSitesAppConfigurationRequestPreferredWansList = Array<string>;
export declare const UpdateSitesAppConfigurationRequestPreferredWansList: S.Schema<UpdateSitesAppConfigurationRequestPreferredWansList>;
export interface UpdateSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    appConfigId: string;
    /** Magic account app ID. */
    accountAppId?: string;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean;
    /** Managed app ID. */
    managedAppId?: string;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: UpdateSitesAppConfigurationRequestPreferredWansList;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number;
}
export declare const UpdateSitesAppConfigurationRequest: S.Schema<UpdateSitesAppConfigurationRequest>;
export type UpdateSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export declare const UpdateSitesAppConfigurationResultAccountAppPreferredWansList: S.Schema<UpdateSitesAppConfigurationResultAccountAppPreferredWansList>;
export interface UpdateSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: UpdateSitesAppConfigurationResultAccountAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const UpdateSitesAppConfigurationResultAccountApp: S.Schema<UpdateSitesAppConfigurationResultAccountApp>;
export type UpdateSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export declare const UpdateSitesAppConfigurationResultManagedAppPreferredWansList: S.Schema<UpdateSitesAppConfigurationResultManagedAppPreferredWansList>;
export interface UpdateSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: UpdateSitesAppConfigurationResultManagedAppPreferredWansList | null;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
}
export declare const UpdateSitesAppConfigurationResultManagedApp: S.Schema<UpdateSitesAppConfigurationResultManagedApp>;
export type UpdateSitesAppConfigurationResult = UpdateSitesAppConfigurationResultAccountApp | UpdateSitesAppConfigurationResultManagedApp;
export declare const UpdateSitesAppConfigurationResult: any;
export type UpdateSitesAppConfigurationResponse = UpdateSitesAppConfigurationResult;
export declare const UpdateSitesAppConfigurationResponse: S.Schema<UpdateSitesAppConfigurationResponse>;
export type SitesWansUpdateRequestStaticAddressing = SitesWansCreateRequestStaticAddressing;
export declare const SitesWansUpdateRequestStaticAddressing: S.Schema<SitesWansCreateRequestStaticAddressing>;
export interface UpdateSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
    name?: string;
    physport?: number;
    priority?: number;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateRequestStaticAddressing;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number;
}
export declare const UpdateSiteWanRequest: S.Schema<UpdateSiteWanRequest>;
export type SitesWansUpdateResponseHealthCheckRate = "low" | "mid" | "high";
export declare const SitesWansUpdateResponseHealthCheckRate: any;
export type SitesWansUpdateResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
export declare const SitesWansUpdateResponseStaticAddressing: S.Schema<SitesWansCreateResultItemStaticAddressing>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteWanResponse {
    /** Identifier */
    id?: string | null;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansUpdateResponseHealthCheckRate | null;
    name?: string | null;
    physport?: number | null;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null;
    /** Identifier */
    siteId?: string | null;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null;
}
export declare const UpdateSiteWanResponse: S.Schema<UpdateSiteWanResponse>;
export interface ValidatePcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    ownershipChallenge: string;
}
export declare const ValidatePcapOwnershipRequest: S.Schema<ValidatePcapOwnershipRequest>;
export type PcapsOwnershipValidateResponseStatus = "pending" | "success" | "failed";
export declare const PcapsOwnershipValidateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidatePcapOwnershipResponse {
    /** The bucket ID associated with the packet captures API. */
    id: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    filename: string;
    /** The status of the ownership challenge. Can be pending, success or failed. */
    status: PcapsOwnershipValidateResponseStatus;
    /** The RFC 3339 timestamp when the bucket was added to packet captures API. */
    submitted: string;
    /** The RFC 3339 timestamp when the bucket was validated. */
    validated?: string | null;
}
export declare const ValidatePcapOwnershipResponse: S.Schema<ValidatePcapOwnershipResponse>;
export type BulkPutCfInterconnectsError = CloudflareOpError;
/** Updates multiple interconnects associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const bulkPutCfInterconnects: API.OperationMethod<BulkPutCfInterconnectsRequest, BulkPutCfInterconnectsResponse, BulkPutCfInterconnectsError, CloudflareOpContext>;
export type BulkPutGreTunnelsError = CloudflareOpError;
/** Updates multiple GRE tunnels. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const bulkPutGreTunnels: API.OperationMethod<BulkPutGreTunnelsRequest, BulkPutGreTunnelsResponse, BulkPutGreTunnelsError, CloudflareOpContext>;
export type BulkPutIpsecTunnelsError = CloudflareOpError;
/** Update multiple IPsec tunnels associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const bulkPutIpsecTunnels: API.OperationMethod<BulkPutIpsecTunnelsRequest, BulkPutIpsecTunnelsResponse, BulkPutIpsecTunnelsError, CloudflareOpContext>;
export type BulkPutRoutesError = CloudflareOpError;
/** Update multiple Magic static routes. Use `?validate_only=true` as an optional query parameter to run validation only without persisting changes. Only fields for a route that need to be changed need be provided. */
export declare const bulkPutRoutes: API.OperationMethod<BulkPutRoutesRequest, BulkPutRoutesResponse, BulkPutRoutesError, CloudflareOpContext>;
export type CreateAppError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Creates a new App for an account */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, CloudflareOpContext>;
export type CreateCf1SiteError = CloudflareOpError;
/** Creates new CF1 Sites for an account. Each site must have a unique name within the account. */
export declare const createCf1Site: API.PaginatedOperationMethod<CreateCf1SiteRequest, CreateCf1SiteResponse, CreateCf1SiteError, CloudflareOpContext, Cf1SitesCreateResultItem>;
export type CreateCf1SiteRampError = CloudflareOpError;
/** Creates ramps (network connections) for a CF1 Site. */
export declare const createCf1SiteRamp: API.PaginatedOperationMethod<CreateCf1SiteRampRequest, CreateCf1SiteRampResponse, CreateCf1SiteRampError, CloudflareOpContext, Cf1SitesRampsCreateResultItem>;
export type CreateConnectorError = CloudflareOpError;
/** Add a connector to your account */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, CloudflareOpContext>;
export type CreateGreTunnelError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Creates a new GRE tunnel. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const createGreTunnel: API.OperationMethod<CreateGreTunnelRequest, CreateGreTunnelResponse, CreateGreTunnelError, CloudflareOpContext>;
export type CreateIpsecTunnelError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Creates a new IPsec tunnel associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const createIpsecTunnel: API.OperationMethod<CreateIpsecTunnelRequest, CreateIpsecTunnelResponse, CreateIpsecTunnelError, CloudflareOpContext>;
export type CreatePcapError = CloudflareOpError;
/** Create new PCAP request for account. */
export declare const createPcap: API.OperationMethod<CreatePcapRequest, CreatePcapResponse, CreatePcapError, CloudflareOpContext>;
export type CreatePcapOwnershipError = CloudflareOpError;
/** Adds an AWS or GCP bucket to use with full packet captures. */
export declare const createPcapOwnership: API.OperationMethod<CreatePcapOwnershipRequest, CreatePcapOwnershipResponse, CreatePcapOwnershipError, CloudflareOpContext>;
export type CreateRouteError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Creates a new Magic static route. Use `?validate_only=true` as an optional query parameter to run validation only without persisting changes. */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResponse, CreateRouteError, CloudflareOpContext>;
export type CreateSiteError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Creates a new Site */
export declare const createSite: API.OperationMethod<CreateSiteRequest, CreateSiteResponse, CreateSiteError, CloudflareOpContext>;
export type CreateSiteAclError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Creates a new Site ACL. */
export declare const createSiteAcl: API.OperationMethod<CreateSiteAclRequest, CreateSiteAclResponse, CreateSiteAclError, CloudflareOpContext>;
export type CreateSiteLanError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Creates a new Site LAN. If the site is in high availability mode, static_addressing is required along with secondary and virtual address. */
export declare const createSiteLan: API.PaginatedOperationMethod<CreateSiteLanRequest, CreateSiteLanResponse, CreateSiteLanError, CloudflareOpContext, SitesLansCreateResultItem>;
export type CreateSitesAppConfigurationError = CloudflareOpError;
/** Creates a new App Config for a site */
export declare const createSitesAppConfiguration: API.OperationMethod<CreateSitesAppConfigurationRequest, CreateSitesAppConfigurationResponse, CreateSitesAppConfigurationError, CloudflareOpContext>;
export type CreateSiteWanError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Creates a new Site WAN. */
export declare const createSiteWan: API.PaginatedOperationMethod<CreateSiteWanRequest, CreateSiteWanResponse, CreateSiteWanError, CloudflareOpContext, SitesWansCreateResultItem>;
export type DeleteAppError = AppNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Deletes specific Account App. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, CloudflareOpContext>;
export type DeleteCf1SiteError = CloudflareOpError;
/** Deletes a specific CF1 Site for an account. */
export declare const deleteCf1Site: API.OperationMethod<DeleteCf1SiteRequest, DeleteCf1SiteResponse, DeleteCf1SiteError, CloudflareOpContext>;
export type DeleteCf1SiteRampError = CloudflareOpError;
/** Deletes a specific ramp from a CF1 Site. */
export declare const deleteCf1SiteRamp: API.OperationMethod<DeleteCf1SiteRampRequest, DeleteCf1SiteRampResponse, DeleteCf1SiteRampError, CloudflareOpContext>;
export type DeleteConnectorError = CloudflareOpError;
/** Remove a connector from your account */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, CloudflareOpContext>;
export type DeleteGreTunnelError = GreTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Disables and removes a specific static GRE tunnel. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const deleteGreTunnel: API.OperationMethod<DeleteGreTunnelRequest, DeleteGreTunnelResponse, DeleteGreTunnelError, CloudflareOpContext>;
export type DeleteIpsecTunnelError = IpsecTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Disables and removes a specific static IPsec Tunnel associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const deleteIpsecTunnel: API.OperationMethod<DeleteIpsecTunnelRequest, DeleteIpsecTunnelResponse, DeleteIpsecTunnelError, CloudflareOpContext>;
export type DeletePcapOwnershipError = CloudflareOpError;
/** Deletes buckets added to the packet captures API. */
export declare const deletePcapOwnership: API.OperationMethod<DeletePcapOwnershipRequest, DeletePcapOwnershipResponse, DeletePcapOwnershipError, CloudflareOpContext>;
export type DeleteRouteError = RouteNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Disable and remove a specific Magic static route. */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, CloudflareOpContext>;
export type DeleteSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Remove a specific Site. */
export declare const deleteSite: API.OperationMethod<DeleteSiteRequest, DeleteSiteResponse, DeleteSiteError, CloudflareOpContext>;
export type DeleteSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Remove a specific Site ACL. */
export declare const deleteSiteAcl: API.OperationMethod<DeleteSiteAclRequest, DeleteSiteAclResponse, DeleteSiteAclError, CloudflareOpContext>;
export type DeleteSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Remove a specific Site LAN. */
export declare const deleteSiteLan: API.OperationMethod<DeleteSiteLanRequest, DeleteSiteLanResponse, DeleteSiteLanError, CloudflareOpContext>;
export type DeleteSitesAppConfigurationError = CloudflareOpError;
/** Deletes specific App Config associated with a site. */
export declare const deleteSitesAppConfiguration: API.OperationMethod<DeleteSitesAppConfigurationRequest, DeleteSitesAppConfigurationResponse, DeleteSitesAppConfigurationError, CloudflareOpContext>;
export type DeleteSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Remove a specific Site WAN. */
export declare const deleteSiteWan: API.OperationMethod<DeleteSiteWanRequest, DeleteSiteWanResponse, DeleteSiteWanError, CloudflareOpContext>;
export type EditSitesAppConfigurationError = CloudflareOpError;
/** Updates an App Config for a site */
export declare const editSitesAppConfiguration: API.OperationMethod<EditSitesAppConfigurationRequest, EditSitesAppConfigurationResponse, EditSitesAppConfigurationError, CloudflareOpContext>;
export type EmptyRouteError = CloudflareOpError;
/** Delete multiple Magic static routes. */
export declare const emptyRoute: API.OperationMethod<EmptyRouteRequest, EmptyRouteResponse, EmptyRouteError, CloudflareOpContext>;
export type GetCf1SiteError = CloudflareOpError;
/** Gets a specific CF1 Site for an account. */
export declare const getCf1Site: API.OperationMethod<GetCf1SiteRequest, GetCf1SiteResponse, GetCf1SiteError, CloudflareOpContext>;
export type GetCf1SiteRampError = CloudflareOpError;
/** Gets a specific ramp for a CF1 Site. */
export declare const getCf1SiteRamp: API.OperationMethod<GetCf1SiteRampRequest, GetCf1SiteRampResponse, GetCf1SiteRampError, CloudflareOpContext>;
export type GetCfInterconnectError = CloudflareOpError;
/** Lists details for a specific interconnect. */
export declare const getCfInterconnect: API.OperationMethod<GetCfInterconnectRequest, GetCfInterconnectResponse, GetCfInterconnectError, CloudflareOpContext>;
export type GetConnectorError = CloudflareOpError;
/** Fetch Connector */
export declare const getConnector: API.OperationMethod<GetConnectorRequest, GetConnectorResponse, GetConnectorError, CloudflareOpContext>;
export type GetConnectorEventError = CloudflareOpError;
/** Get Event */
export declare const getConnectorEvent: API.OperationMethod<GetConnectorEventRequest, GetConnectorEventResponse, GetConnectorEventError, CloudflareOpContext>;
export type GetConnectorSnapshotError = CloudflareOpError;
/** Get Snapshot */
export declare const getConnectorSnapshot: API.OperationMethod<GetConnectorSnapshotRequest, GetConnectorSnapshotResponse, GetConnectorSnapshotError, CloudflareOpContext>;
export type GetGreTunnelError = GreTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists informtion for a specific GRE tunnel. */
export declare const getGreTunnel: API.OperationMethod<GetGreTunnelRequest, GetGreTunnelResponse, GetGreTunnelError, CloudflareOpContext>;
export type GetIpsecTunnelError = IpsecTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists details for a specific IPsec tunnel. */
export declare const getIpsecTunnel: API.OperationMethod<GetIpsecTunnelRequest, GetIpsecTunnelResponse, GetIpsecTunnelError, CloudflareOpContext>;
export type GetPcapError = CloudflareOpError;
/** Get information for a PCAP request by id. */
export declare const getPcap: API.OperationMethod<GetPcapRequest, GetPcapResponse, GetPcapError, CloudflareOpContext>;
export type GetPcapDownloadError = CloudflareOpError;
/** Download PCAP information into a file. Response is a binary PCAP file. */
export declare const getPcapDownload: API.OperationMethod<GetPcapDownloadRequest, GetPcapDownloadResponse, GetPcapDownloadError, CloudflareOpContext>;
export type GetPcapOwnershipError = CloudflareOpError;
/** List all buckets configured for use with PCAPs API. */
export declare const getPcapOwnership: API.PaginatedOperationMethod<GetPcapOwnershipRequest, GetPcapOwnershipResponse, GetPcapOwnershipError, CloudflareOpContext, PcapsOwnershipGetResultItem>;
export type GetRouteError = RouteNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Get a specific Magic static route. */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResponse, GetRouteError, CloudflareOpContext>;
export type GetSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Get a specific Site. */
export declare const getSite: API.OperationMethod<GetSiteRequest, GetSiteResponse, GetSiteError, CloudflareOpContext>;
export type GetSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Get a specific Site ACL. */
export declare const getSiteAcl: API.OperationMethod<GetSiteAclRequest, GetSiteAclResponse, GetSiteAclError, CloudflareOpContext>;
export type GetSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Get a specific Site LAN. */
export declare const getSiteLan: API.OperationMethod<GetSiteLanRequest, GetSiteLanResponse, GetSiteLanError, CloudflareOpContext>;
export type GetSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Get a specific Site WAN. */
export declare const getSiteWan: API.OperationMethod<GetSiteWanRequest, GetSiteWanResponse, GetSiteWanError, CloudflareOpContext>;
export type ListAppsError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Lists Apps associated with an account. */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, CloudflareOpContext, AppsListResultItem>;
export type ListCf1SiteRampsError = CloudflareOpError;
/** Lists ramps (network connections) associated with a CF1 Site. Ramps represent GRE tunnels, IPsec tunnels, interconnects, or MCONN links. */
export declare const listCf1SiteRamps: API.PaginatedOperationMethod<ListCf1SiteRampsRequest, ListCf1SiteRampsResponse, ListCf1SiteRampsError, CloudflareOpContext, Cf1SitesRampsListResultItem>;
export type ListCf1SitesError = CloudflareOpError;
/** Lists CF1 Sites associated with an account. A CF1 Site represents a physical customer network location with optional geographic coordinates. */
export declare const listCf1Sites: API.PaginatedOperationMethod<ListCf1SitesRequest, ListCf1SitesResponse, ListCf1SitesError, CloudflareOpContext, Cf1SitesCreateResultItem>;
export type ListCfInterconnectsError = CloudflareOpError;
/** Lists interconnects associated with an account. */
export declare const listCfInterconnects: API.OperationMethod<ListCfInterconnectsRequest, ListCfInterconnectsResponse, ListCfInterconnectsError, CloudflareOpContext>;
export type ListConnectorEventLatestsError = CloudflareOpError;
/** Get latest Events */
export declare const listConnectorEventLatests: API.OperationMethod<ListConnectorEventLatestsRequest, ListConnectorEventLatestsResponse, ListConnectorEventLatestsError, CloudflareOpContext>;
export type ListConnectorEventsError = CloudflareOpError;
/** List Events */
export declare const listConnectorEvents: API.OperationMethod<ListConnectorEventsRequest, ListConnectorEventsResponse, ListConnectorEventsError, CloudflareOpContext>;
export type ListConnectorsError = CloudflareOpError;
/** List Connectors */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, CloudflareOpContext, ConnectorsListResultItem>;
export type ListConnectorSnapshotLatestsError = CloudflareOpError;
/** Get latest Snapshots */
export declare const listConnectorSnapshotLatests: API.OperationMethod<ListConnectorSnapshotLatestsRequest, ListConnectorSnapshotLatestsResponse, ListConnectorSnapshotLatestsError, CloudflareOpContext>;
export type ListConnectorSnapshotsError = CloudflareOpError;
/** List Snapshots */
export declare const listConnectorSnapshots: API.OperationMethod<ListConnectorSnapshotsRequest, ListConnectorSnapshotsResponse, ListConnectorSnapshotsError, CloudflareOpContext>;
export type ListGreTunnelsError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists GRE tunnels associated with an account. */
export declare const listGreTunnels: API.OperationMethod<ListGreTunnelsRequest, ListGreTunnelsResponse, ListGreTunnelsError, CloudflareOpContext>;
export type ListIpsecTunnelsError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists IPsec tunnels associated with an account. */
export declare const listIpsecTunnels: API.OperationMethod<ListIpsecTunnelsRequest, ListIpsecTunnelsResponse, ListIpsecTunnelsError, CloudflareOpContext>;
export type ListPcapsError = CloudflareOpError;
/** Lists all packet capture requests for an account. */
export declare const listPcaps: API.PaginatedOperationMethod<ListPcapsRequest, ListPcapsResponse, ListPcapsError, CloudflareOpContext, PcapsListResultItem>;
export type ListRoutesError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** List all Magic static routes. */
export declare const listRoutes: API.OperationMethod<ListRoutesRequest, ListRoutesResponse, ListRoutesError, CloudflareOpContext>;
export type ListSiteAclsError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Lists Site ACLs associated with an account. */
export declare const listSiteAcls: API.PaginatedOperationMethod<ListSiteAclsRequest, ListSiteAclsResponse, ListSiteAclsError, CloudflareOpContext, SitesAclsListResultItem>;
export type ListSiteLansError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Lists Site LANs associated with an account. */
export declare const listSiteLans: API.PaginatedOperationMethod<ListSiteLansRequest, ListSiteLansResponse, ListSiteLansError, CloudflareOpContext, SitesLansListResultItem>;
export type ListSitesError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Lists Sites associated with an account. Use connectorid query param to return sites where connectorid matches either site.ConnectorID or site.SecondaryConnectorID. */
export declare const listSites: API.PaginatedOperationMethod<ListSitesRequest, ListSitesResponse, ListSitesError, CloudflareOpContext, SitesListResultItem>;
export type ListSitesAppConfigurationError = CloudflareOpError;
/** Lists App Configs associated with a site. */
export declare const listSitesAppConfiguration: API.OperationMethod<ListSitesAppConfigurationRequest, ListSitesAppConfigurationResponse, ListSitesAppConfigurationError, CloudflareOpContext>;
export type ListSiteWansError = MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Lists Site WANs associated with an account. */
export declare const listSiteWans: API.PaginatedOperationMethod<ListSiteWansRequest, ListSiteWansResponse, ListSiteWansError, CloudflareOpContext, SitesWansListResultItem>;
export type PatchAppError = AppNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Updates an Account App */
export declare const patchApp: API.OperationMethod<PatchAppRequest, PatchAppResponse, PatchAppError, CloudflareOpContext>;
export type PatchCf1SiteError = CloudflareOpError;
/** Partially updates a specific CF1 Site for an account. Only the fields included in the request body are modified; omitted fields retain their existing values. */
export declare const patchCf1Site: API.OperationMethod<PatchCf1SiteRequest, PatchCf1SiteResponse, PatchCf1SiteError, CloudflareOpContext>;
export type PatchConnectorError = CloudflareOpError;
/** Edit Connector to update specific properties or Re-provision License Key */
export declare const patchConnector: API.OperationMethod<PatchConnectorRequest, PatchConnectorResponse, PatchConnectorError, CloudflareOpContext>;
export type PatchSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Patch a specific Site. */
export declare const patchSite: API.OperationMethod<PatchSiteRequest, PatchSiteResponse, PatchSiteError, CloudflareOpContext>;
export type PatchSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Patch a specific Site ACL. */
export declare const patchSiteAcl: API.OperationMethod<PatchSiteAclRequest, PatchSiteAclResponse, PatchSiteAclError, CloudflareOpContext>;
export type PatchSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Patch a specific Site LAN. */
export declare const patchSiteLan: API.OperationMethod<PatchSiteLanRequest, PatchSiteLanResponse, PatchSiteLanError, CloudflareOpContext>;
export type PatchSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Patch a specific Site WAN. */
export declare const patchSiteWan: API.OperationMethod<PatchSiteWanRequest, PatchSiteWanResponse, PatchSiteWanError, CloudflareOpContext>;
export type PskGenerateIpsecTunnelError = CloudflareOpError;
/** Generates a Pre-Shared Key for a specific IPsec tunnel used in the IKE session. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. After a PSK is generated, the PSK is immediately persisted to Cloudflare's edge and cannot be retrieved later. Store the PSK in a safe place. */
export declare const pskGenerateIpsecTunnel: API.OperationMethod<PskGenerateIpsecTunnelRequest, PskGenerateIpsecTunnelResponse, PskGenerateIpsecTunnelError, CloudflareOpContext>;
export type PskSetIpsecTunnelError = CloudflareOpError;
/** Sets Pre-Shared Keys for multiple IPsec tunnels associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. After PSKs are applied, they are immediately persisted to Cloudflare's edge and cannot be retrieved later. Store the PSKs in a safe place. */
export declare const pskSetIpsecTunnel: API.OperationMethod<PskSetIpsecTunnelRequest, PskSetIpsecTunnelResponse, PskSetIpsecTunnelError, CloudflareOpContext>;
export type PutCfInterconnectError = CloudflareOpError;
/** Updates a specific interconnect associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const putCfInterconnect: API.OperationMethod<PutCfInterconnectRequest, PutCfInterconnectResponse, PutCfInterconnectError, CloudflareOpContext>;
export type StopPcapError = CloudflareOpError;
/** Stop full PCAP. */
export declare const stopPcap: API.OperationMethod<StopPcapRequest, StopPcapResponse, StopPcapError, CloudflareOpContext>;
export type UpdateAppError = AppNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Updates an Account App */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResponse, UpdateAppError, CloudflareOpContext>;
export type UpdateConnectorError = CloudflareOpError;
/** Replace Connector or Re-provision License Key */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest, UpdateConnectorResponse, UpdateConnectorError, CloudflareOpContext>;
export type UpdateGreTunnelError = GreTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Updates a specific GRE tunnel. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const updateGreTunnel: API.OperationMethod<UpdateGreTunnelRequest, UpdateGreTunnelResponse, UpdateGreTunnelError, CloudflareOpContext>;
export type UpdateIpsecTunnelError = IpsecTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Updates a specific IPsec tunnel associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const updateIpsecTunnel: API.OperationMethod<UpdateIpsecTunnelRequest, UpdateIpsecTunnelResponse, UpdateIpsecTunnelError, CloudflareOpContext>;
export type UpdateRouteError = RouteNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Update a specific Magic static route. Use `?validate_only=true` as an optional query parameter to run validation only without persisting changes. */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResponse, UpdateRouteError, CloudflareOpContext>;
export type UpdateSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Update a specific Site. */
export declare const updateSite: API.OperationMethod<UpdateSiteRequest, UpdateSiteResponse, UpdateSiteError, CloudflareOpContext>;
export type UpdateSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Update a specific Site ACL. */
export declare const updateSiteAcl: API.OperationMethod<UpdateSiteAclRequest, UpdateSiteAclResponse, UpdateSiteAclError, CloudflareOpContext>;
export type UpdateSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Update a specific Site LAN. */
export declare const updateSiteLan: API.OperationMethod<UpdateSiteLanRequest, UpdateSiteLanResponse, UpdateSiteLanError, CloudflareOpContext>;
export type UpdateSitesAppConfigurationError = CloudflareOpError;
/** Updates an App Config for a site */
export declare const updateSitesAppConfiguration: API.OperationMethod<UpdateSitesAppConfigurationRequest, UpdateSitesAppConfigurationResponse, UpdateSitesAppConfigurationError, CloudflareOpContext>;
export type UpdateSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | CloudflareOpError;
/** Update a specific Site WAN. */
export declare const updateSiteWan: API.OperationMethod<UpdateSiteWanRequest, UpdateSiteWanResponse, UpdateSiteWanError, CloudflareOpContext>;
export type ValidatePcapOwnershipError = CloudflareOpError;
/** Validates buckets added to the packet captures API. */
export declare const validatePcapOwnership: API.OperationMethod<ValidatePcapOwnershipRequest, ValidatePcapOwnershipResponse, ValidatePcapOwnershipError, CloudflareOpContext>;
//# sourceMappingURL=magic_transit.d.ts.map