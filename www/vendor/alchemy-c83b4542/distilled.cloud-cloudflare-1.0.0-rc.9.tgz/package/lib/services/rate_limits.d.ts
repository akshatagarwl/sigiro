import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type CreateRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const CreateRequestActionMode: any;
export interface CreateRequestActionResponse {
    /** The response body to return. The value must conform to the configured content type. */
    body?: string;
    /** The content type of the body. Must be one of the following: `text/plain`, `text/xml`, or `application/json`. */
    contentType?: string;
}
export declare const CreateRequestActionResponse: S.Schema<CreateRequestActionResponse>;
export interface CreateRequestAction {
    /** The action to perform. */
    mode?: CreateRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number;
}
export declare const CreateRequestAction: S.Schema<CreateRequestAction>;
export type CreateRequestMatchHeadersItemOp = "eq" | "ne";
export declare const CreateRequestMatchHeadersItemOp: any;
export interface CreateRequestMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: CreateRequestMatchHeadersItemOp | (string & {});
    /** The value of the response header, which must match exactly. */
    value?: string;
}
export declare const CreateRequestMatchHeadersItem: S.Schema<CreateRequestMatchHeadersItem>;
export type CreateRequestMatchHeadersList = Array<CreateRequestMatchHeadersItem>;
export declare const CreateRequestMatchHeadersList: S.Schema<CreateRequestMatchHeadersList>;
export type CreateRequestMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const CreateRequestMatchRequestMethodsItem: any;
export type CreateRequestMatchRequestMethodsList = Array<CreateRequestMatchRequestMethodsItem | (string & {})>;
export declare const CreateRequestMatchRequestMethodsList: S.Schema<CreateRequestMatchRequestMethodsList>;
export type CreateRequestMatchRequestSchemesList = Array<string>;
export declare const CreateRequestMatchRequestSchemesList: S.Schema<CreateRequestMatchRequestSchemesList>;
export interface CreateRequestMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: CreateRequestMatchRequestMethodsList;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: CreateRequestMatchRequestSchemesList;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string;
}
export declare const CreateRequestMatchRequest: S.Schema<CreateRequestMatchRequest>;
export interface CreateRequestMatchResponse {
    /** When true, only the uncached traffic served from your origin servers will count towards rate limiting. In this case, any cached traffic served by Cloudflare will not count towards rate limiting. This field is optional. */
    originTraffic?: boolean;
}
export declare const CreateRequestMatchResponse: S.Schema<CreateRequestMatchResponse>;
export interface CreateRequestMatch {
    headers?: CreateRequestMatchHeadersList;
    request?: CreateRequestMatchRequest;
    response?: CreateRequestMatchResponse;
}
export declare const CreateRequestMatch: S.Schema<CreateRequestMatch>;
export interface CreateRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: CreateRequestAction;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match: CreateRequestMatch;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period: number;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold: number;
}
export declare const CreateRateLimitRequest: S.Schema<CreateRateLimitRequest>;
export type CreateResponseActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const CreateResponseActionMode: any;
export interface CreateResponseActionResponse {
    /** The response body to return. The value must conform to the configured content type. */
    body?: string | null;
    /** The content type of the body. Must be one of the following: `text/plain`, `text/xml`, or `application/json`. */
    contentType?: string | null;
}
export declare const CreateResponseActionResponse: S.Schema<CreateResponseActionResponse>;
export interface CreateResponseAction {
    /** The action to perform. */
    mode?: CreateResponseActionMode | null;
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateResponseActionResponse | null;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number | null;
}
export declare const CreateResponseAction: S.Schema<CreateResponseAction>;
export type CreateResponseBypassItemName = "url";
export declare const CreateResponseBypassItemName: any;
export interface CreateResponseBypassItem {
    name?: CreateResponseBypassItemName | null;
    /** The URL to bypass. */
    value?: string | null;
}
export declare const CreateResponseBypassItem: S.Schema<CreateResponseBypassItem>;
export type CreateResponseBypassList = Array<CreateResponseBypassItem>;
export declare const CreateResponseBypassList: S.Schema<CreateResponseBypassList>;
export type CreateResponseMatchHeadersItemOp = "eq" | "ne";
export declare const CreateResponseMatchHeadersItemOp: any;
export interface CreateResponseMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string | null;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: CreateResponseMatchHeadersItemOp | null;
    /** The value of the response header, which must match exactly. */
    value?: string | null;
}
export declare const CreateResponseMatchHeadersItem: S.Schema<CreateResponseMatchHeadersItem>;
export type CreateResponseMatchHeadersList = Array<CreateResponseMatchHeadersItem>;
export declare const CreateResponseMatchHeadersList: S.Schema<CreateResponseMatchHeadersList>;
export type CreateResponseMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const CreateResponseMatchRequestMethodsItem: any;
export type CreateResponseMatchRequestMethodsList = Array<CreateResponseMatchRequestMethodsItem>;
export declare const CreateResponseMatchRequestMethodsList: S.Schema<CreateResponseMatchRequestMethodsList>;
export type CreateResponseMatchRequestSchemesList = Array<string>;
export declare const CreateResponseMatchRequestSchemesList: S.Schema<CreateResponseMatchRequestSchemesList>;
export interface CreateResponseMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: CreateResponseMatchRequestMethodsList | null;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: CreateResponseMatchRequestSchemesList | null;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string | null;
}
export declare const CreateResponseMatchRequest: S.Schema<CreateResponseMatchRequest>;
export interface CreateResponseMatchResponse {
    /** When true, only the uncached traffic served from your origin servers will count towards rate limiting. In this case, any cached traffic served by Cloudflare will not count towards rate limiting. This field is optional. */
    originTraffic?: boolean | null;
}
export declare const CreateResponseMatchResponse: S.Schema<CreateResponseMatchResponse>;
export interface CreateResponseMatch {
    headers?: CreateResponseMatchHeadersList | null;
    request?: CreateResponseMatchRequest | null;
    response?: CreateResponseMatchResponse | null;
}
export declare const CreateResponseMatch: S.Schema<CreateResponseMatch>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRateLimitResponse {
    /** The unique identifier of the rate limit. */
    id?: string | null;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action?: CreateResponseAction | null;
    /** Criteria specifying when the current rate limit should be bypassed. You can specify that the rate limit should not apply to one or more URLs. */
    bypass?: CreateResponseBypassList | null;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string | null;
    /** When true, indicates that the rate limit is currently disabled. */
    disabled?: boolean | null;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match?: CreateResponseMatch | null;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period?: number | null;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold?: number | null;
}
export declare const CreateRateLimitResponse: S.Schema<CreateRateLimitResponse>;
export interface DeleteRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique identifier of the rate limit. */
    rateLimitId: string;
}
export declare const DeleteRateLimitRequest: S.Schema<DeleteRateLimitRequest>;
export type DeleteResponseActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const DeleteResponseActionMode: any;
export type DeleteResponseActionResponse = CreateResponseActionResponse;
export declare const DeleteResponseActionResponse: S.Schema<CreateResponseActionResponse>;
export interface DeleteResponseAction {
    /** The action to perform. */
    mode?: DeleteResponseActionMode | null;
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateResponseActionResponse | null;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number | null;
}
export declare const DeleteResponseAction: S.Schema<DeleteResponseAction>;
export type DeleteResponseBypassItemName = "url";
export declare const DeleteResponseBypassItemName: any;
export interface DeleteResponseBypassItem {
    name?: DeleteResponseBypassItemName | null;
    /** The URL to bypass. */
    value?: string | null;
}
export declare const DeleteResponseBypassItem: S.Schema<DeleteResponseBypassItem>;
export type DeleteResponseBypassList = Array<DeleteResponseBypassItem>;
export declare const DeleteResponseBypassList: S.Schema<DeleteResponseBypassList>;
export type DeleteResponseMatchHeadersItemOp = "eq" | "ne";
export declare const DeleteResponseMatchHeadersItemOp: any;
export interface DeleteResponseMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string | null;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: DeleteResponseMatchHeadersItemOp | null;
    /** The value of the response header, which must match exactly. */
    value?: string | null;
}
export declare const DeleteResponseMatchHeadersItem: S.Schema<DeleteResponseMatchHeadersItem>;
export type DeleteResponseMatchHeadersList = Array<DeleteResponseMatchHeadersItem>;
export declare const DeleteResponseMatchHeadersList: S.Schema<DeleteResponseMatchHeadersList>;
export type DeleteResponseMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const DeleteResponseMatchRequestMethodsItem: any;
export type DeleteResponseMatchRequestMethodsList = Array<DeleteResponseMatchRequestMethodsItem>;
export declare const DeleteResponseMatchRequestMethodsList: S.Schema<DeleteResponseMatchRequestMethodsList>;
export type DeleteResponseMatchRequestSchemesList = Array<string>;
export declare const DeleteResponseMatchRequestSchemesList: S.Schema<DeleteResponseMatchRequestSchemesList>;
export interface DeleteResponseMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: DeleteResponseMatchRequestMethodsList | null;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: DeleteResponseMatchRequestSchemesList | null;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string | null;
}
export declare const DeleteResponseMatchRequest: S.Schema<DeleteResponseMatchRequest>;
export type DeleteResponseMatchResponse = CreateResponseMatchResponse;
export declare const DeleteResponseMatchResponse: S.Schema<CreateResponseMatchResponse>;
export interface DeleteResponseMatch {
    headers?: DeleteResponseMatchHeadersList | null;
    request?: DeleteResponseMatchRequest | null;
    response?: CreateResponseMatchResponse | null;
}
export declare const DeleteResponseMatch: S.Schema<DeleteResponseMatch>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRateLimitResponse {
    /** The unique identifier of the rate limit. */
    id?: string | null;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action?: DeleteResponseAction | null;
    /** Criteria specifying when the current rate limit should be bypassed. You can specify that the rate limit should not apply to one or more URLs. */
    bypass?: DeleteResponseBypassList | null;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string | null;
    /** When true, indicates that the rate limit is currently disabled. */
    disabled?: boolean | null;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match?: DeleteResponseMatch | null;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period?: number | null;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold?: number | null;
}
export declare const DeleteRateLimitResponse: S.Schema<DeleteRateLimitResponse>;
export type EditRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const EditRequestActionMode: any;
export type EditRequestActionResponse = CreateRequestActionResponse;
export declare const EditRequestActionResponse: S.Schema<CreateRequestActionResponse>;
export interface EditRequestAction {
    /** The action to perform. */
    mode?: EditRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number;
}
export declare const EditRequestAction: S.Schema<EditRequestAction>;
export type EditRequestMatchHeadersItemOp = "eq" | "ne";
export declare const EditRequestMatchHeadersItemOp: any;
export interface EditRequestMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: EditRequestMatchHeadersItemOp | (string & {});
    /** The value of the response header, which must match exactly. */
    value?: string;
}
export declare const EditRequestMatchHeadersItem: S.Schema<EditRequestMatchHeadersItem>;
export type EditRequestMatchHeadersList = Array<EditRequestMatchHeadersItem>;
export declare const EditRequestMatchHeadersList: S.Schema<EditRequestMatchHeadersList>;
export type EditRequestMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const EditRequestMatchRequestMethodsItem: any;
export type EditRequestMatchRequestMethodsList = Array<EditRequestMatchRequestMethodsItem | (string & {})>;
export declare const EditRequestMatchRequestMethodsList: S.Schema<EditRequestMatchRequestMethodsList>;
export type EditRequestMatchRequestSchemesList = Array<string>;
export declare const EditRequestMatchRequestSchemesList: S.Schema<EditRequestMatchRequestSchemesList>;
export interface EditRequestMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: EditRequestMatchRequestMethodsList;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: EditRequestMatchRequestSchemesList;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string;
}
export declare const EditRequestMatchRequest: S.Schema<EditRequestMatchRequest>;
export type EditRequestMatchResponse = CreateRequestMatchResponse;
export declare const EditRequestMatchResponse: S.Schema<CreateRequestMatchResponse>;
export interface EditRequestMatch {
    headers?: EditRequestMatchHeadersList;
    request?: EditRequestMatchRequest;
    response?: CreateRequestMatchResponse;
}
export declare const EditRequestMatch: S.Schema<EditRequestMatch>;
export interface EditRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique identifier of the rate limit. */
    rateLimitId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: EditRequestAction;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match: EditRequestMatch;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period: number;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold: number;
}
export declare const EditRateLimitRequest: S.Schema<EditRateLimitRequest>;
export type EditResponseActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const EditResponseActionMode: any;
export type EditResponseActionResponse = CreateResponseActionResponse;
export declare const EditResponseActionResponse: S.Schema<CreateResponseActionResponse>;
export interface EditResponseAction {
    /** The action to perform. */
    mode?: EditResponseActionMode | null;
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateResponseActionResponse | null;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number | null;
}
export declare const EditResponseAction: S.Schema<EditResponseAction>;
export type EditResponseBypassItemName = "url";
export declare const EditResponseBypassItemName: any;
export interface EditResponseBypassItem {
    name?: EditResponseBypassItemName | null;
    /** The URL to bypass. */
    value?: string | null;
}
export declare const EditResponseBypassItem: S.Schema<EditResponseBypassItem>;
export type EditResponseBypassList = Array<EditResponseBypassItem>;
export declare const EditResponseBypassList: S.Schema<EditResponseBypassList>;
export type EditResponseMatchHeadersItemOp = "eq" | "ne";
export declare const EditResponseMatchHeadersItemOp: any;
export interface EditResponseMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string | null;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: EditResponseMatchHeadersItemOp | null;
    /** The value of the response header, which must match exactly. */
    value?: string | null;
}
export declare const EditResponseMatchHeadersItem: S.Schema<EditResponseMatchHeadersItem>;
export type EditResponseMatchHeadersList = Array<EditResponseMatchHeadersItem>;
export declare const EditResponseMatchHeadersList: S.Schema<EditResponseMatchHeadersList>;
export type EditResponseMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const EditResponseMatchRequestMethodsItem: any;
export type EditResponseMatchRequestMethodsList = Array<EditResponseMatchRequestMethodsItem>;
export declare const EditResponseMatchRequestMethodsList: S.Schema<EditResponseMatchRequestMethodsList>;
export type EditResponseMatchRequestSchemesList = Array<string>;
export declare const EditResponseMatchRequestSchemesList: S.Schema<EditResponseMatchRequestSchemesList>;
export interface EditResponseMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: EditResponseMatchRequestMethodsList | null;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: EditResponseMatchRequestSchemesList | null;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string | null;
}
export declare const EditResponseMatchRequest: S.Schema<EditResponseMatchRequest>;
export type EditResponseMatchResponse = CreateResponseMatchResponse;
export declare const EditResponseMatchResponse: S.Schema<CreateResponseMatchResponse>;
export interface EditResponseMatch {
    headers?: EditResponseMatchHeadersList | null;
    request?: EditResponseMatchRequest | null;
    response?: CreateResponseMatchResponse | null;
}
export declare const EditResponseMatch: S.Schema<EditResponseMatch>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditRateLimitResponse {
    /** The unique identifier of the rate limit. */
    id?: string | null;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action?: EditResponseAction | null;
    /** Criteria specifying when the current rate limit should be bypassed. You can specify that the rate limit should not apply to one or more URLs. */
    bypass?: EditResponseBypassList | null;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string | null;
    /** When true, indicates that the rate limit is currently disabled. */
    disabled?: boolean | null;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match?: EditResponseMatch | null;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period?: number | null;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold?: number | null;
}
export declare const EditRateLimitResponse: S.Schema<EditRateLimitResponse>;
export interface GetRateLimitRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the unique identifier of the rate limit. */
    rateLimitId: string;
}
export declare const GetRateLimitRequest: S.Schema<GetRateLimitRequest>;
export type GetResponseActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const GetResponseActionMode: any;
export type GetResponseActionResponse = CreateResponseActionResponse;
export declare const GetResponseActionResponse: S.Schema<CreateResponseActionResponse>;
export interface GetResponseAction {
    /** The action to perform. */
    mode?: GetResponseActionMode | null;
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateResponseActionResponse | null;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number | null;
}
export declare const GetResponseAction: S.Schema<GetResponseAction>;
export type GetResponseBypassItemName = "url";
export declare const GetResponseBypassItemName: any;
export interface GetResponseBypassItem {
    name?: GetResponseBypassItemName | null;
    /** The URL to bypass. */
    value?: string | null;
}
export declare const GetResponseBypassItem: S.Schema<GetResponseBypassItem>;
export type GetResponseBypassList = Array<GetResponseBypassItem>;
export declare const GetResponseBypassList: S.Schema<GetResponseBypassList>;
export type GetResponseMatchHeadersItemOp = "eq" | "ne";
export declare const GetResponseMatchHeadersItemOp: any;
export interface GetResponseMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string | null;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: GetResponseMatchHeadersItemOp | null;
    /** The value of the response header, which must match exactly. */
    value?: string | null;
}
export declare const GetResponseMatchHeadersItem: S.Schema<GetResponseMatchHeadersItem>;
export type GetResponseMatchHeadersList = Array<GetResponseMatchHeadersItem>;
export declare const GetResponseMatchHeadersList: S.Schema<GetResponseMatchHeadersList>;
export type GetResponseMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const GetResponseMatchRequestMethodsItem: any;
export type GetResponseMatchRequestMethodsList = Array<GetResponseMatchRequestMethodsItem>;
export declare const GetResponseMatchRequestMethodsList: S.Schema<GetResponseMatchRequestMethodsList>;
export type GetResponseMatchRequestSchemesList = Array<string>;
export declare const GetResponseMatchRequestSchemesList: S.Schema<GetResponseMatchRequestSchemesList>;
export interface GetResponseMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: GetResponseMatchRequestMethodsList | null;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: GetResponseMatchRequestSchemesList | null;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string | null;
}
export declare const GetResponseMatchRequest: S.Schema<GetResponseMatchRequest>;
export type GetResponseMatchResponse = CreateResponseMatchResponse;
export declare const GetResponseMatchResponse: S.Schema<CreateResponseMatchResponse>;
export interface GetResponseMatch {
    headers?: GetResponseMatchHeadersList | null;
    request?: GetResponseMatchRequest | null;
    response?: CreateResponseMatchResponse | null;
}
export declare const GetResponseMatch: S.Schema<GetResponseMatch>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRateLimitResponse {
    /** The unique identifier of the rate limit. */
    id?: string | null;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action?: GetResponseAction | null;
    /** Criteria specifying when the current rate limit should be bypassed. You can specify that the rate limit should not apply to one or more URLs. */
    bypass?: GetResponseBypassList | null;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string | null;
    /** When true, indicates that the rate limit is currently disabled. */
    disabled?: boolean | null;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match?: GetResponseMatch | null;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period?: number | null;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold?: number | null;
}
export declare const GetRateLimitResponse: S.Schema<GetRateLimitResponse>;
export interface ListRateLimitsRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines the page number of paginated results. */
    page?: number;
    /** Defines the maximum number of results per page. You can only set the value to `1` or to a multiple of 5 such as `5`, `10`, `15`, or `20`. */
    perPage?: number;
}
export declare const ListRateLimitsRequest: S.Schema<ListRateLimitsRequest>;
export type ListResultItemActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const ListResultItemActionMode: any;
export type ListResultItemActionResponse = CreateResponseActionResponse;
export declare const ListResultItemActionResponse: S.Schema<CreateResponseActionResponse>;
export interface ListResultItemAction {
    /** The action to perform. */
    mode?: ListResultItemActionMode | null;
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: CreateResponseActionResponse | null;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number | null;
}
export declare const ListResultItemAction: S.Schema<ListResultItemAction>;
export type ListResultItemBypassItemName = "url";
export declare const ListResultItemBypassItemName: any;
export interface ListResultItemBypassItem {
    name?: ListResultItemBypassItemName | null;
    /** The URL to bypass. */
    value?: string | null;
}
export declare const ListResultItemBypassItem: S.Schema<ListResultItemBypassItem>;
export type ListResultItemBypassList = Array<ListResultItemBypassItem>;
export declare const ListResultItemBypassList: S.Schema<ListResultItemBypassList>;
export type ListResultItemMatchHeadersItemOp = "eq" | "ne";
export declare const ListResultItemMatchHeadersItemOp: any;
export interface ListResultItemMatchHeadersItem {
    /** The name of the response header to match. */
    name?: string | null;
    /** The operator used when matching: `eq` means "equal" and `ne` means "not equal". */
    op?: ListResultItemMatchHeadersItemOp | null;
    /** The value of the response header, which must match exactly. */
    value?: string | null;
}
export declare const ListResultItemMatchHeadersItem: S.Schema<ListResultItemMatchHeadersItem>;
export type ListResultItemMatchHeadersList = Array<ListResultItemMatchHeadersItem>;
export declare const ListResultItemMatchHeadersList: S.Schema<ListResultItemMatchHeadersList>;
export type ListResultItemMatchRequestMethodsItem = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "_ALL_";
export declare const ListResultItemMatchRequestMethodsItem: any;
export type ListResultItemMatchRequestMethodsList = Array<ListResultItemMatchRequestMethodsItem>;
export declare const ListResultItemMatchRequestMethodsList: S.Schema<ListResultItemMatchRequestMethodsList>;
export type ListResultItemMatchRequestSchemesList = Array<string>;
export declare const ListResultItemMatchRequestSchemesList: S.Schema<ListResultItemMatchRequestSchemesList>;
export interface ListResultItemMatchRequest {
    /** The HTTP methods to match. You can specify a subset (for example, `['POST','PUT']`) or all methods (`['_ALL_']`). This field is optional when creating a rate limit. */
    methods?: ListResultItemMatchRequestMethodsList | null;
    /** The HTTP schemes to match. You can specify one scheme (`['HTTPS']`), both schemes (`['HTTP','HTTPS']`), or all schemes (`['_ALL_']`). This field is optional. */
    schemes?: ListResultItemMatchRequestSchemesList | null;
    /** The URL pattern to match, composed of a host and a path such as `example.org/path*`. Normalization is applied before the pattern is matched. `*` wildcards are expanded to match applicable traffic. Query strings are not matched. Set the value to `*` to match all traffic to your zone. */
    url?: string | null;
}
export declare const ListResultItemMatchRequest: S.Schema<ListResultItemMatchRequest>;
export type ListResultItemMatchResponse = CreateResponseMatchResponse;
export declare const ListResultItemMatchResponse: S.Schema<CreateResponseMatchResponse>;
export interface ListResultItemMatch {
    headers?: ListResultItemMatchHeadersList | null;
    request?: ListResultItemMatchRequest | null;
    response?: CreateResponseMatchResponse | null;
}
export declare const ListResultItemMatch: S.Schema<ListResultItemMatch>;
export interface ListResultItem {
    /** The unique identifier of the rate limit. */
    id?: string | null;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action?: ListResultItemAction | null;
    /** Criteria specifying when the current rate limit should be bypassed. You can specify that the rate limit should not apply to one or more URLs. */
    bypass?: ListResultItemBypassList | null;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string | null;
    /** When true, indicates that the rate limit is currently disabled. */
    disabled?: boolean | null;
    /** Determines which traffic the rate limit counts towards the threshold. */
    match?: ListResultItemMatch | null;
    /** The time in seconds (an integer value) to count matching traffic. If the count exceeds the configured threshold within this period, Cloudflare will perform the configured action. */
    period?: number | null;
    /** The threshold that will trigger the configured mitigation action. Configure this value along with the `period` property to establish a threshold per period. */
    threshold?: number | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListRateLimitsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRateLimitsResponse: S.Schema<ListRateLimitsResponse>;
export type CreateRateLimitError = CloudflareOpError;
/** Creates a new rate limit for a zone. Refer to the object definition for a list of required attributes. */
export declare const createRateLimit: API.OperationMethod<CreateRateLimitRequest, CreateRateLimitResponse, CreateRateLimitError, CloudflareOpContext>;
export type DeleteRateLimitError = CloudflareOpError;
/** Deletes an existing rate limit. */
export declare const deleteRateLimit: API.OperationMethod<DeleteRateLimitRequest, DeleteRateLimitResponse, DeleteRateLimitError, CloudflareOpContext>;
export type EditRateLimitError = CloudflareOpError;
/** Updates an existing rate limit. */
export declare const editRateLimit: API.OperationMethod<EditRateLimitRequest, EditRateLimitResponse, EditRateLimitError, CloudflareOpContext>;
export type GetRateLimitError = CloudflareOpError;
/** Fetches the details of a rate limit. */
export declare const getRateLimit: API.OperationMethod<GetRateLimitRequest, GetRateLimitResponse, GetRateLimitError, CloudflareOpContext>;
export type ListRateLimitsError = CloudflareOpError;
/** Fetches the rate limits for a zone. */
export declare const listRateLimits: API.PaginatedOperationMethod<ListRateLimitsRequest, ListRateLimitsResponse, ListRateLimitsError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=rate_limits.d.ts.map