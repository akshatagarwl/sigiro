import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SnippetInUse_base: S.Class<SnippetInUse, S.TaggedStruct<"SnippetInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SnippetInUse extends /*@__PURE__*/ SnippetInUse_base {
}
declare const SnippetNotFound_base: S.Class<SnippetNotFound, S.TaggedStruct<"SnippetNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SnippetNotFound extends /*@__PURE__*/ SnippetNotFound_base {
}
declare const SnippetRulesNotFound_base: S.Class<SnippetRulesNotFound, S.TaggedStruct<"SnippetRulesNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SnippetRulesNotFound extends /*@__PURE__*/ SnippetRulesNotFound_base {
}
export interface DeleteRuleRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export type DeleteRuleResponse = unknown;
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface DeleteSnippetRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
}
export declare const DeleteSnippetRequest: S.Schema<DeleteSnippetRequest>;
export type DeleteSnippetResponse = unknown;
export declare const DeleteSnippetResponse: S.Schema<DeleteSnippetResponse>;
export interface GetContentRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
}
export declare const GetContentRequest: S.Schema<GetContentRequest>;
export interface GetContentResponse {
}
export declare const GetContentResponse: S.Schema<GetContentResponse>;
export interface GetSnippetRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
}
export declare const GetSnippetRequest: S.Schema<GetSnippetRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSnippetResponse {
    /** Indicates when the snippet was created. */
    createdOn: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Indicates when the snippet was last modified. */
    modifiedOn?: string | null;
}
export declare const GetSnippetResponse: S.Schema<GetSnippetResponse>;
export interface ListRulesRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export type ListRulesResponse = unknown;
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export interface ListSnippetsRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Specifies the current page number. */
    page?: number;
    /** Specifies how many results to return per page. */
    perPage?: number;
}
export declare const ListSnippetsRequest: S.Schema<ListSnippetsRequest>;
export interface ListResultItem {
    /** Indicates when the snippet was created. */
    createdOn: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Indicates when the snippet was last modified. */
    modifiedOn?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListSnippetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSnippetsResponse: S.Schema<ListSnippetsResponse>;
export interface RulesUpdateRequestRulesItem {
    /** Define the expression that determines which traffic matches the rule. */
    expression: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Provide an informative description of the rule. */
    description?: string;
    /** Indicate whether to execute the rule. */
    enabled?: boolean;
}
export declare const RulesUpdateRequestRulesItem: S.Schema<RulesUpdateRequestRulesItem>;
export type RulesUpdateRequestRulesList = Array<RulesUpdateRequestRulesItem>;
export declare const RulesUpdateRequestRulesList: S.Schema<RulesUpdateRequestRulesList>;
export interface PutRuleRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Lists snippet rules. */
    rules: RulesUpdateRequestRulesList;
}
export declare const PutRuleRequest: S.Schema<PutRuleRequest>;
export type PutRuleResponse = unknown;
export declare const PutRuleResponse: S.Schema<PutRuleResponse>;
export interface PutSnippetRequest {
    /** Use this field to specify the unique ID of the zone. */
    zoneId: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Snippet metadata ({ mainModule }), JSON-encoded as the multipart `metadata` part. */
    metadata: unknown;
    /** Snippet module file(s), appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export declare const PutSnippetRequest: S.Schema<PutSnippetRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSnippetResponse {
    /** Indicates when the snippet was created. */
    createdOn: string;
    /** Identify the snippet. */
    snippetName: string;
    /** Indicates when the snippet was last modified. */
    modifiedOn?: string | null;
}
export declare const PutSnippetResponse: S.Schema<PutSnippetResponse>;
export type DeleteRuleError = SnippetRulesNotFound | Forbidden | CloudflareOpError;
/** Deletes all snippet rules belonging to the zone. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DeleteSnippetError = SnippetNotFound | SnippetInUse | CloudflareOpError;
/** Deletes a snippet belonging to the zone. */
export declare const deleteSnippet: API.OperationMethod<DeleteSnippetRequest, DeleteSnippetResponse, DeleteSnippetError, CloudflareOpContext>;
export type GetContentError = CloudflareOpError;
/** Fetches the content of a snippet belonging to the zone. */
export declare const getContent: API.OperationMethod<GetContentRequest, GetContentResponse, GetContentError, CloudflareOpContext>;
export type GetSnippetError = SnippetNotFound | CloudflareOpError;
/** Fetches a snippet belonging to the zone. */
export declare const getSnippet: API.OperationMethod<GetSnippetRequest, GetSnippetResponse, GetSnippetError, CloudflareOpContext>;
export type ListRulesError = SnippetRulesNotFound | Forbidden | CloudflareOpError;
/** Fetches all snippet rules belonging to the zone. */
export declare const listRules: API.OperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext>;
export type ListSnippetsError = Forbidden | CloudflareOpError;
/** Fetches all snippets belonging to the zone. */
export declare const listSnippets: API.PaginatedOperationMethod<ListSnippetsRequest, ListSnippetsResponse, ListSnippetsError, CloudflareOpContext, ListResultItem>;
export type PutRuleError = CloudflareOpError;
/** Updates all snippet rules belonging to the zone. */
export declare const putRule: API.OperationMethod<PutRuleRequest, PutRuleResponse, PutRuleError, CloudflareOpContext>;
export type PutSnippetError = CloudflareOpError;
/** Creates or updates a snippet belonging to the zone. */
export declare const putSnippet: API.OperationMethod<PutSnippetRequest, PutSnippetResponse, PutSnippetError, CloudflareOpContext>;
//# sourceMappingURL=snippets.d.ts.map