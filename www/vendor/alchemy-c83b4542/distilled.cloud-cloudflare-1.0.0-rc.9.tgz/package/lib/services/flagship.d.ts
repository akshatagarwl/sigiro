import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const FlagshipAppNotFound_base: S.Class<FlagshipAppNotFound, S.TaggedStruct<"FlagshipAppNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FlagshipAppNotFound extends /*@__PURE__*/ FlagshipAppNotFound_base {
}
declare const FlagshipFlagAlreadyExists_base: S.Class<FlagshipFlagAlreadyExists, S.TaggedStruct<"FlagshipFlagAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FlagshipFlagAlreadyExists extends /*@__PURE__*/ FlagshipFlagAlreadyExists_base {
}
declare const FlagshipFlagNotFound_base: S.Class<FlagshipFlagNotFound, S.TaggedStruct<"FlagshipFlagNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FlagshipFlagNotFound extends /*@__PURE__*/ FlagshipFlagNotFound_base {
}
export interface CreateAppRequest {
    /** Cloudflare account ID. */
    accountId: string;
    name: string;
}
export declare const CreateAppRequest: S.Schema<CreateAppRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAppResponse {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `edge-gateway` for gateway-authenticated changes. */
    updatedBy: string;
}
export declare const CreateAppResponse: S.Schema<CreateAppResponse>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase0: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase0>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItem = AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsCreateRequestRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsCreateRequestRulesItemConditionsItemCase1 {
    clauses: AppsFlagsCreateRequestRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateRequestRulesItemConditionsItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsCreateRequestRulesItemConditionsItemCase1: S.Schema<AppsFlagsCreateRequestRulesItemConditionsItemCase1>;
export type AppsFlagsCreateRequestRulesItemConditionsItem = AppsFlagsCreateRequestRulesItemConditionsItemCase0 | AppsFlagsCreateRequestRulesItemConditionsItemCase1;
export declare const AppsFlagsCreateRequestRulesItemConditionsItem: any;
export type AppsFlagsCreateRequestRulesItemConditionsList = Array<AppsFlagsCreateRequestRulesItemConditionsItem>;
export declare const AppsFlagsCreateRequestRulesItemConditionsList: S.Schema<AppsFlagsCreateRequestRulesItemConditionsList>;
export interface AppsFlagsCreateRequestRulesItemRollout {
    /** Percentage of matching traffic (0–100) served this variation. For multi-way splits, use cumulative upper bounds across rules (e.g. 30, 70, 100). */
    percentage: number;
    /** Context attribute used for sticky bucketing. Defaults to `targetingKey`. If absent at evaluation time, bucketing is random per request. */
    attribute?: string;
}
export declare const AppsFlagsCreateRequestRulesItemRollout: S.Schema<AppsFlagsCreateRequestRulesItemRollout>;
export interface AppsFlagsCreateRequestRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsCreateRequestRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateRequestRulesItemRollout;
}
export declare const AppsFlagsCreateRequestRulesItem: S.Schema<AppsFlagsCreateRequestRulesItem>;
export type AppsFlagsCreateRequestRulesList = Array<AppsFlagsCreateRequestRulesItem>;
export declare const AppsFlagsCreateRequestRulesList: S.Schema<AppsFlagsCreateRequestRulesList>;
export type UntypedVariationsMap = {
    [key: string]: unknown | undefined;
};
export declare const UntypedVariationsMap: S.Schema<UntypedVariationsMap>;
export type AppsFlagsCreateRequestType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsCreateRequestType: any;
export interface CreateAppFlagRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsCreateRequestRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsCreateRequestType | (string & {});
}
export declare const CreateAppFlagRequest: S.Schema<CreateAppFlagRequest>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase0: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase0>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItem = AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsCreateResponseRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsCreateResponseRulesItemConditionsItemCase1 {
    clauses: AppsFlagsCreateResponseRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsCreateResponseRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsCreateResponseRulesItemConditionsItemCase1: S.Schema<AppsFlagsCreateResponseRulesItemConditionsItemCase1>;
export type AppsFlagsCreateResponseRulesItemConditionsItem = AppsFlagsCreateResponseRulesItemConditionsItemCase0 | AppsFlagsCreateResponseRulesItemConditionsItemCase1;
export declare const AppsFlagsCreateResponseRulesItemConditionsItem: any;
export type AppsFlagsCreateResponseRulesItemConditionsList = Array<AppsFlagsCreateResponseRulesItemConditionsItem>;
export declare const AppsFlagsCreateResponseRulesItemConditionsList: S.Schema<AppsFlagsCreateResponseRulesItemConditionsList>;
export interface AppsFlagsCreateResponseRulesItemRollout {
    /** Percentage of matching traffic (0–100) served this variation. For multi-way splits, use cumulative upper bounds across rules (e.g. 30, 70, 100). */
    percentage: number;
    /** Context attribute used for sticky bucketing. Defaults to `targetingKey`. If absent at evaluation time, bucketing is random per request. */
    attribute?: string | null;
}
export declare const AppsFlagsCreateResponseRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsCreateResponseRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsCreateResponseRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsCreateResponseRulesItem: S.Schema<AppsFlagsCreateResponseRulesItem>;
export type AppsFlagsCreateResponseRulesList = Array<AppsFlagsCreateResponseRulesItem>;
export declare const AppsFlagsCreateResponseRulesList: S.Schema<AppsFlagsCreateResponseRulesList>;
export type AppsFlagsCreateResponseType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsCreateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAppFlagResponse {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsCreateResponseRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsCreateResponseType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const CreateAppFlagResponse: S.Schema<CreateAppFlagResponse>;
export interface DeleteAppRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
}
export declare const DeleteAppRequest: S.Schema<DeleteAppRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppResponse {
    id: string;
}
export declare const DeleteAppResponse: S.Schema<DeleteAppResponse>;
export interface DeleteAppFlagRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** Flag key (slug). */
    flagKey: string;
}
export declare const DeleteAppFlagRequest: S.Schema<DeleteAppFlagRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppFlagResponse {
    key: string;
}
export declare const DeleteAppFlagResponse: S.Schema<DeleteAppFlagResponse>;
export interface GetAppRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
}
export declare const GetAppRequest: S.Schema<GetAppRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAppResponse {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `edge-gateway` for gateway-authenticated changes. */
    updatedBy: string;
}
export declare const GetAppResponse: S.Schema<GetAppResponse>;
export interface GetAppEvaluateRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** The flag key to evaluate. */
    flagKey: string;
    /** Context targeting key (per OpenFeature spec); used for percentage rollout bucketing. */
    targetingKey?: string;
}
export declare const GetAppEvaluateRequest: S.Schema<GetAppEvaluateRequest>;
export type AppsEvaluateGetResponseReason = "TARGETING_MATCH" | "DEFAULT" | "DISABLED" | "SPLIT";
export declare const AppsEvaluateGetResponseReason: any;
export type AppsEvaluateGetResponseValueCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsEvaluateGetResponseValueCase3Map: S.Schema<AppsEvaluateGetResponseValueCase3Map>;
export type AppsEvaluateGetResponseValueCase4List = Array<unknown>;
export declare const AppsEvaluateGetResponseValueCase4List: S.Schema<AppsEvaluateGetResponseValueCase4List>;
export type AppsEvaluateGetResponseValue = string | number | boolean | AppsEvaluateGetResponseValueCase3Map | AppsEvaluateGetResponseValueCase4List;
export declare const AppsEvaluateGetResponseValue: any;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAppEvaluateResponse {
    flagKey: string;
    reason: AppsEvaluateGetResponseReason;
    variant: string;
    value?: AppsEvaluateGetResponseValue | null;
}
export declare const GetAppEvaluateResponse: S.Schema<GetAppEvaluateResponse>;
export interface GetAppFlagRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** Flag key (slug). */
    flagKey: string;
}
export declare const GetAppFlagRequest: S.Schema<GetAppFlagRequest>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase0: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase0>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItem = AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsGetResponseRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsGetResponseRulesItemConditionsItemCase1 {
    clauses: AppsFlagsGetResponseRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsGetResponseRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsGetResponseRulesItemConditionsItemCase1: S.Schema<AppsFlagsGetResponseRulesItemConditionsItemCase1>;
export type AppsFlagsGetResponseRulesItemConditionsItem = AppsFlagsGetResponseRulesItemConditionsItemCase0 | AppsFlagsGetResponseRulesItemConditionsItemCase1;
export declare const AppsFlagsGetResponseRulesItemConditionsItem: any;
export type AppsFlagsGetResponseRulesItemConditionsList = Array<AppsFlagsGetResponseRulesItemConditionsItem>;
export declare const AppsFlagsGetResponseRulesItemConditionsList: S.Schema<AppsFlagsGetResponseRulesItemConditionsList>;
export type AppsFlagsGetResponseRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export declare const AppsFlagsGetResponseRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsGetResponseRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsGetResponseRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsGetResponseRulesItem: S.Schema<AppsFlagsGetResponseRulesItem>;
export type AppsFlagsGetResponseRulesList = Array<AppsFlagsGetResponseRulesItem>;
export declare const AppsFlagsGetResponseRulesList: S.Schema<AppsFlagsGetResponseRulesList>;
export type AppsFlagsGetResponseType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsGetResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAppFlagResponse {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsGetResponseRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsGetResponseType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const GetAppFlagResponse: S.Schema<GetAppFlagResponse>;
export interface ListAppFlagChangelogsRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** Flag key (slug). */
    flagKey: string;
    /** Pagination cursor from a previous response. */
    cursor?: string;
    /** Max items to return (1–200). */
    limit?: string;
}
export declare const ListAppFlagChangelogsRequest: S.Schema<ListAppFlagChangelogsRequest>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItem = AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase0 | AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItemCase1;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItem: any;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsList>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsChangelogListResultItemCase0AfterRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsChangelogListResultItemCase0AfterRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesItem: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesItem>;
export type AppsFlagsChangelogListResultItemCase0AfterRulesList = Array<AppsFlagsChangelogListResultItemCase0AfterRulesItem>;
export declare const AppsFlagsChangelogListResultItemCase0AfterRulesList: S.Schema<AppsFlagsChangelogListResultItemCase0AfterRulesList>;
export type AppsFlagsChangelogListResultItemCase0AfterType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsChangelogListResultItemCase0AfterType: any;
export interface AppsFlagsChangelogListResultItemCase0After {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsChangelogListResultItemCase0AfterRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsChangelogListResultItemCase0AfterType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const AppsFlagsChangelogListResultItemCase0After: S.Schema<AppsFlagsChangelogListResultItemCase0After>;
export type AppsFlagsChangelogListResultItemCase0Event = "create";
export declare const AppsFlagsChangelogListResultItemCase0Event: any;
export interface AppsFlagsChangelogListResultItemCase0 {
    after: AppsFlagsChangelogListResultItemCase0After;
    event: AppsFlagsChangelogListResultItemCase0Event;
    flagKey: string;
}
export declare const AppsFlagsChangelogListResultItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItem = AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase0 | AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItemCase1;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItem: any;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsList>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsChangelogListResultItemCase1AfterRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsChangelogListResultItemCase1AfterRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesItem: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesItem>;
export type AppsFlagsChangelogListResultItemCase1AfterRulesList = Array<AppsFlagsChangelogListResultItemCase1AfterRulesItem>;
export declare const AppsFlagsChangelogListResultItemCase1AfterRulesList: S.Schema<AppsFlagsChangelogListResultItemCase1AfterRulesList>;
export type AppsFlagsChangelogListResultItemCase1AfterType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsChangelogListResultItemCase1AfterType: any;
export interface AppsFlagsChangelogListResultItemCase1After {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsChangelogListResultItemCase1AfterRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsChangelogListResultItemCase1AfterType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const AppsFlagsChangelogListResultItemCase1After: S.Schema<AppsFlagsChangelogListResultItemCase1After>;
export type AppsFlagsChangelogListResultItemCase1Event = "delete";
export declare const AppsFlagsChangelogListResultItemCase1Event: any;
export interface AppsFlagsChangelogListResultItemCase1 {
    after: AppsFlagsChangelogListResultItemCase1After;
    event: AppsFlagsChangelogListResultItemCase1Event;
    flagKey: string;
}
export declare const AppsFlagsChangelogListResultItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1 {
    clauses: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItem = AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase0 | AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItemCase1;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItem: any;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsList>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsChangelogListResultItemCase2AfterRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsChangelogListResultItemCase2AfterRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesItem: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesItem>;
export type AppsFlagsChangelogListResultItemCase2AfterRulesList = Array<AppsFlagsChangelogListResultItemCase2AfterRulesItem>;
export declare const AppsFlagsChangelogListResultItemCase2AfterRulesList: S.Schema<AppsFlagsChangelogListResultItemCase2AfterRulesList>;
export type AppsFlagsChangelogListResultItemCase2AfterType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsChangelogListResultItemCase2AfterType: any;
export interface AppsFlagsChangelogListResultItemCase2After {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsChangelogListResultItemCase2AfterRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsChangelogListResultItemCase2AfterType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const AppsFlagsChangelogListResultItemCase2After: S.Schema<AppsFlagsChangelogListResultItemCase2After>;
export type AppsFlagsChangelogListResultItemCase2DiffValueFromCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsChangelogListResultItemCase2DiffValueFromCase3Map: S.Schema<AppsFlagsChangelogListResultItemCase2DiffValueFromCase3Map>;
export type AppsFlagsChangelogListResultItemCase2DiffValueFromCase4List = Array<unknown>;
export declare const AppsFlagsChangelogListResultItemCase2DiffValueFromCase4List: S.Schema<AppsFlagsChangelogListResultItemCase2DiffValueFromCase4List>;
export type AppsFlagsChangelogListResultItemCase2DiffValueFrom = string | number | boolean | AppsFlagsChangelogListResultItemCase2DiffValueFromCase3Map | AppsFlagsChangelogListResultItemCase2DiffValueFromCase4List;
export declare const AppsFlagsChangelogListResultItemCase2DiffValueFrom: any;
export type AppsFlagsChangelogListResultItemCase2DiffValueToCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsChangelogListResultItemCase2DiffValueToCase3Map: S.Schema<AppsFlagsChangelogListResultItemCase2DiffValueToCase3Map>;
export type AppsFlagsChangelogListResultItemCase2DiffValueToCase4List = Array<unknown>;
export declare const AppsFlagsChangelogListResultItemCase2DiffValueToCase4List: S.Schema<AppsFlagsChangelogListResultItemCase2DiffValueToCase4List>;
export type AppsFlagsChangelogListResultItemCase2DiffValueTo = string | number | boolean | AppsFlagsChangelogListResultItemCase2DiffValueToCase3Map | AppsFlagsChangelogListResultItemCase2DiffValueToCase4List;
export declare const AppsFlagsChangelogListResultItemCase2DiffValueTo: any;
export interface AppsFlagsChangelogListResultItemCase2DiffValue {
    from?: AppsFlagsChangelogListResultItemCase2DiffValueFrom | null;
    to?: AppsFlagsChangelogListResultItemCase2DiffValueTo | null;
}
export declare const AppsFlagsChangelogListResultItemCase2DiffValue: S.Schema<AppsFlagsChangelogListResultItemCase2DiffValue>;
export type AppsFlagsChangelogListResultItemCase2DiffMap = {
    [key: string]: AppsFlagsChangelogListResultItemCase2DiffValue | undefined;
};
export declare const AppsFlagsChangelogListResultItemCase2DiffMap: S.Schema<AppsFlagsChangelogListResultItemCase2DiffMap>;
export type AppsFlagsChangelogListResultItemCase2Event = "update";
export declare const AppsFlagsChangelogListResultItemCase2Event: any;
export interface AppsFlagsChangelogListResultItemCase2 {
    after: AppsFlagsChangelogListResultItemCase2After;
    diff: AppsFlagsChangelogListResultItemCase2DiffMap;
    event: AppsFlagsChangelogListResultItemCase2Event;
    flagKey: string;
}
export declare const AppsFlagsChangelogListResultItemCase2: S.Schema<AppsFlagsChangelogListResultItemCase2>;
export type AppsFlagsChangelogListResultItem = AppsFlagsChangelogListResultItemCase0 | AppsFlagsChangelogListResultItemCase1 | AppsFlagsChangelogListResultItemCase2;
export declare const AppsFlagsChangelogListResultItem: any;
export type AppsFlagsChangelogListResultList = Array<AppsFlagsChangelogListResultItem>;
export declare const AppsFlagsChangelogListResultList: S.Schema<AppsFlagsChangelogListResultList>;
export interface ListAppFlagChangelogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsFlagsChangelogListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAppFlagChangelogsResponse: S.Schema<ListAppFlagChangelogsResponse>;
export interface ListAppFlagsRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** Pagination cursor from a previous response. */
    cursor?: string;
    /** Max items to return (1–200). */
    limit?: string;
}
export declare const ListAppFlagsRequest: S.Schema<ListAppFlagsRequest>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase0: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase0>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItem = AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsListResultItemRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsListResultItemRulesItemConditionsItemCase1 {
    clauses: AppsFlagsListResultItemRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsListResultItemRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsListResultItemRulesItemConditionsItemCase1: S.Schema<AppsFlagsListResultItemRulesItemConditionsItemCase1>;
export type AppsFlagsListResultItemRulesItemConditionsItem = AppsFlagsListResultItemRulesItemConditionsItemCase0 | AppsFlagsListResultItemRulesItemConditionsItemCase1;
export declare const AppsFlagsListResultItemRulesItemConditionsItem: any;
export type AppsFlagsListResultItemRulesItemConditionsList = Array<AppsFlagsListResultItemRulesItemConditionsItem>;
export declare const AppsFlagsListResultItemRulesItemConditionsList: S.Schema<AppsFlagsListResultItemRulesItemConditionsList>;
export type AppsFlagsListResultItemRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export declare const AppsFlagsListResultItemRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsListResultItemRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsListResultItemRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsListResultItemRulesItem: S.Schema<AppsFlagsListResultItemRulesItem>;
export type AppsFlagsListResultItemRulesList = Array<AppsFlagsListResultItemRulesItem>;
export declare const AppsFlagsListResultItemRulesList: S.Schema<AppsFlagsListResultItemRulesList>;
export type AppsFlagsListResultItemType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsListResultItemType: any;
export interface AppsFlagsListResultItem {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsListResultItemRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsListResultItemType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const AppsFlagsListResultItem: S.Schema<AppsFlagsListResultItem>;
export type AppsFlagsListResultList = Array<AppsFlagsListResultItem>;
export declare const AppsFlagsListResultList: S.Schema<AppsFlagsListResultList>;
export interface ListAppFlagsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsFlagsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAppFlagsResponse: S.Schema<ListAppFlagsResponse>;
export interface ListAppsRequest {
    /** Cloudflare account ID. */
    accountId: string;
}
export declare const ListAppsRequest: S.Schema<ListAppsRequest>;
export interface AppsListResultItem {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `edge-gateway` for gateway-authenticated changes. */
    updatedBy: string;
}
export declare const AppsListResultItem: S.Schema<AppsListResultItem>;
export type AppsListResultList = Array<AppsListResultItem>;
export declare const AppsListResultList: S.Schema<AppsListResultList>;
export interface ListAppsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAppsResponse: S.Schema<ListAppsResponse>;
export interface UpdateAppRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    name?: string;
}
export declare const UpdateAppRequest: S.Schema<UpdateAppRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAppResponse {
    id: string;
    createdAt: string;
    name: string;
    updatedAt: string;
    /** Email of the actor who last modified the app, or `edge-gateway` for gateway-authenticated changes. */
    updatedBy: string;
}
export declare const UpdateAppResponse: S.Schema<UpdateAppResponse>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase0: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase0>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator | (string & {});
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsUpdateRequestRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateRequestRulesItemConditionsItemCase1 {
    clauses: AppsFlagsUpdateRequestRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateRequestRulesItemConditionsItemCase1LogicalOperator | (string & {});
}
export declare const AppsFlagsUpdateRequestRulesItemConditionsItemCase1: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsItemCase1>;
export type AppsFlagsUpdateRequestRulesItemConditionsItem = AppsFlagsUpdateRequestRulesItemConditionsItemCase0 | AppsFlagsUpdateRequestRulesItemConditionsItemCase1;
export declare const AppsFlagsUpdateRequestRulesItemConditionsItem: any;
export type AppsFlagsUpdateRequestRulesItemConditionsList = Array<AppsFlagsUpdateRequestRulesItemConditionsItem>;
export declare const AppsFlagsUpdateRequestRulesItemConditionsList: S.Schema<AppsFlagsUpdateRequestRulesItemConditionsList>;
export type AppsFlagsUpdateRequestRulesItemRollout = AppsFlagsCreateRequestRulesItemRollout;
export declare const AppsFlagsUpdateRequestRulesItemRollout: S.Schema<AppsFlagsCreateRequestRulesItemRollout>;
export interface AppsFlagsUpdateRequestRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsUpdateRequestRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateRequestRulesItemRollout;
}
export declare const AppsFlagsUpdateRequestRulesItem: S.Schema<AppsFlagsUpdateRequestRulesItem>;
export type AppsFlagsUpdateRequestRulesList = Array<AppsFlagsUpdateRequestRulesItem>;
export declare const AppsFlagsUpdateRequestRulesList: S.Schema<AppsFlagsUpdateRequestRulesList>;
export type AppsFlagsUpdateRequestType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsUpdateRequestType: any;
export interface UpdateAppFlagRequest {
    /** Cloudflare account ID. */
    accountId: string;
    /** App identifier. */
    appId: string;
    /** Flag key (slug). */
    flagKey: string;
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsUpdateRequestRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsUpdateRequestType | (string & {});
}
export declare const UpdateAppFlagRequest: S.Schema<UpdateAppFlagRequest>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase0Operator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase0: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase0>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator = "equals" | "not_equals" | "greater_than" | "less_than" | "greater_than_or_equals" | "less_than_or_equals" | "contains" | "starts_with" | "ends_with" | "in" | "not_in";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 {
    attribute: string;
    operator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0Operator;
    /** Value to compare against the context attribute. Must be an array for `in` and `not_in`; numeric and ISO-8601 datetime strings are accepted by the ordering operators. */
    value: unknown;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List = Array<unknown>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses = string | number | boolean | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase3Map | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesCase4List;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses: any;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1Clauses;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem: any;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesItem>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1LogicalOperator;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItemCase1;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItem: any;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesList = Array<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesItem>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesList: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesList>;
export type AppsFlagsUpdateResponseRulesItemConditionsItemCase1LogicalOperator = "AND" | "OR";
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1LogicalOperator: any;
export interface AppsFlagsUpdateResponseRulesItemConditionsItemCase1 {
    clauses: AppsFlagsUpdateResponseRulesItemConditionsItemCase1ClausesList;
    logicalOperator: AppsFlagsUpdateResponseRulesItemConditionsItemCase1LogicalOperator;
}
export declare const AppsFlagsUpdateResponseRulesItemConditionsItemCase1: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsItemCase1>;
export type AppsFlagsUpdateResponseRulesItemConditionsItem = AppsFlagsUpdateResponseRulesItemConditionsItemCase0 | AppsFlagsUpdateResponseRulesItemConditionsItemCase1;
export declare const AppsFlagsUpdateResponseRulesItemConditionsItem: any;
export type AppsFlagsUpdateResponseRulesItemConditionsList = Array<AppsFlagsUpdateResponseRulesItemConditionsItem>;
export declare const AppsFlagsUpdateResponseRulesItemConditionsList: S.Schema<AppsFlagsUpdateResponseRulesItemConditionsList>;
export type AppsFlagsUpdateResponseRulesItemRollout = AppsFlagsCreateResponseRulesItemRollout;
export declare const AppsFlagsUpdateResponseRulesItemRollout: S.Schema<AppsFlagsCreateResponseRulesItemRollout>;
export interface AppsFlagsUpdateResponseRulesItem {
    /** Conditions the context must satisfy for this rule to match. An empty array matches all contexts. */
    conditions: AppsFlagsUpdateResponseRulesItemConditionsList;
    /** Evaluation order; lower numbers are evaluated first. Must be unique across the flag's rules. */
    priority: number;
    /** Variation served when this rule matches. Must be a key in `variations`. */
    serveVariation: string;
    rollout?: AppsFlagsCreateResponseRulesItemRollout | null;
}
export declare const AppsFlagsUpdateResponseRulesItem: S.Schema<AppsFlagsUpdateResponseRulesItem>;
export type AppsFlagsUpdateResponseRulesList = Array<AppsFlagsUpdateResponseRulesItem>;
export declare const AppsFlagsUpdateResponseRulesList: S.Schema<AppsFlagsUpdateResponseRulesList>;
export type AppsFlagsUpdateResponseType = "boolean" | "string" | "number" | "json";
export declare const AppsFlagsUpdateResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAppFlagResponse {
    /** Variation served when no rule matches or the flag is disabled. Must be a key in `variations`. */
    defaultVariation: string;
    /** When false, the flag bypasses all rules and always serves `default_variation`. */
    enabled: boolean;
    /** Unique identifier for the flag within an app. Used in all evaluation and SDK calls. */
    key: string;
    /** Targeting rules evaluated in ascending `priority`; the first matching rule wins. An empty array means the flag always serves `default_variation`. */
    rules: AppsFlagsUpdateResponseRulesList;
    /** Map of variation name to value. All values must be the same type (boolean, string, number, or JSON object/array). Each serialized value must be 10KB or smaller. */
    variations: UntypedVariationsMap;
    description?: string | null;
    /** Value type of the flag's variations. Inferred from the variation values on write, so it may be omitted in requests. */
    type?: AppsFlagsUpdateResponseType | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export declare const UpdateAppFlagResponse: S.Schema<UpdateAppFlagResponse>;
export type CreateAppError = CloudflareOpError;
/** Creates an app. The returned `id` is used in all subsequent flag, changelog, and evaluation requests. */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, CloudflareOpContext>;
export type CreateAppFlagError = FlagshipFlagAlreadyExists | FlagshipAppNotFound | CloudflareOpError;
/** Creates a flag. Returns 409 if the key already exists. `type` is inferred from variation values and may be omitted. */
export declare const createAppFlag: API.OperationMethod<CreateAppFlagRequest, CreateAppFlagResponse, CreateAppFlagError, CloudflareOpContext>;
export type DeleteAppError = FlagshipAppNotFound | CloudflareOpError;
/** Deletes an app and all its flags and changelog history. Returns 409 if any Worker still references this app via a Flagship binding. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, CloudflareOpContext>;
export type DeleteAppFlagError = FlagshipFlagNotFound | FlagshipAppNotFound | CloudflareOpError;
/** Permanently deletes a flag. Subsequent evaluations fall back to the caller-supplied default. Cannot be undone. */
export declare const deleteAppFlag: API.OperationMethod<DeleteAppFlagRequest, DeleteAppFlagResponse, DeleteAppFlagError, CloudflareOpContext>;
export type GetAppError = FlagshipAppNotFound | CloudflareOpError;
/** Returns an app's name and audit fields. Flag definitions are not included. */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResponse, GetAppError, CloudflareOpContext>;
export type GetAppEvaluateError = CloudflareOpError;
/** Evaluates a flag against the provided context. Pass context attributes as query parameters; boolean and numeric strings are coerced automatically. For low-latency in-Worker evaluation, prefer the Flagship binding over this endpoint. */
export declare const getAppEvaluate: API.OperationMethod<GetAppEvaluateRequest, GetAppEvaluateResponse, GetAppEvaluateError, CloudflareOpContext>;
export type GetAppFlagError = FlagshipFlagNotFound | FlagshipAppNotFound | CloudflareOpError;
/** Returns the full flag definition including rules, variations, and audit fields. */
export declare const getAppFlag: API.OperationMethod<GetAppFlagRequest, GetAppFlagResponse, GetAppFlagError, CloudflareOpContext>;
export type ListAppFlagChangelogsError = CloudflareOpError;
/** Returns the audit history for a flag, newest first. Each entry includes the event type and full flag state after the change; `update` entries include a field-level diff. Capped at 200 entries per flag. */
export declare const listAppFlagChangelogs: API.PaginatedOperationMethod<ListAppFlagChangelogsRequest, ListAppFlagChangelogsResponse, ListAppFlagChangelogsError, CloudflareOpContext, AppsFlagsChangelogListResultItem>;
export type ListAppFlagsError = FlagshipAppNotFound | CloudflareOpError;
/** Lists an app's flags ordered by key. Pass `cursor` from `result_info` to page forward; a null cursor indicates the last page. */
export declare const listAppFlags: API.PaginatedOperationMethod<ListAppFlagsRequest, ListAppFlagsResponse, ListAppFlagsError, CloudflareOpContext, AppsFlagsListResultItem>;
export type ListAppsError = CloudflareOpError;
/** Lists all apps in the account. Returns identity and audit fields only — flag definitions are not included. */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, CloudflareOpContext, AppsListResultItem>;
export type UpdateAppError = FlagshipAppNotFound | CloudflareOpError;
/** Updates an app. Only `name` is mutable. */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResponse, UpdateAppError, CloudflareOpContext>;
export type UpdateAppFlagError = FlagshipFlagNotFound | FlagshipAppNotFound | CloudflareOpError;
/** Replaces the entire flag definition. Omitted fields are dropped, not preserved — read before writing. Each update appends a changelog entry. */
export declare const updateAppFlag: API.OperationMethod<UpdateAppFlagRequest, UpdateAppFlagResponse, UpdateAppFlagError, CloudflareOpContext>;
//# sourceMappingURL=flagship.d.ts.map