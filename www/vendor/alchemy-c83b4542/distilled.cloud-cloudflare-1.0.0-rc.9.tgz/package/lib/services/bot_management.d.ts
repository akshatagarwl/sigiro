import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateFeedbackRequestRequestsByAttribute {
    metric: string;
    requests: number;
}
export declare const CreateFeedbackRequestRequestsByAttribute: S.Schema<CreateFeedbackRequestRequestsByAttribute>;
export type CreateFeedbackRequestType = "false_positive" | "false_negative";
export declare const CreateFeedbackRequestType: any;
export interface CreateFeedbackRequest {
    /** Identifier. */
    zoneId: string;
    description: string;
    /** Wirefilter expression describing the traffic being reported. */
    expression: string;
    firstRequestSeenAt: string;
    lastRequestSeenAt: string;
    requests: number;
    /** Top attributes contributing to the feedback sample. Keys include topASNs, topCountries, topHosts, topIPs, topJA3Hashes, topJA4s, topPaths, topUserAgents. */
    requestsByAttribute: CreateFeedbackRequestRequestsByAttribute;
    /** Map of bot scores (1-99) to request counts. Sum must equal `requests`. */
    requestsByScore: unknown;
    /** Map of score source to request counts. Sum must equal `requests`. */
    requestsByScoreSrc: unknown;
    /** Type of feedback report. */
    type: CreateFeedbackRequestType | (string & {});
    subtype?: string;
}
export declare const CreateFeedbackRequest: S.Schema<CreateFeedbackRequest>;
export interface CreateFeedbackResponse {
}
export declare const CreateFeedbackResponse: S.Schema<CreateFeedbackResponse>;
export interface GetBotManagementRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetBotManagementRequest: S.Schema<GetBotManagementRequest>;
export type GetResultBotFightModeConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const GetResultBotFightModeConfigurationAiBotsProtection: any;
export type GetResultBotFightModeConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const GetResultBotFightModeConfigurationCfRobotsVariant: any;
export type GetResultBotFightModeConfigurationContentBotsProtection = "block" | "disabled";
export declare const GetResultBotFightModeConfigurationContentBotsProtection: any;
export type GetResultBotFightModeConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const GetResultBotFightModeConfigurationCrawlerProtection: any;
export interface GetResultBotFightModeConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | null;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | null;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | null;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | null;
    /** Indicates that the zone's session score tracking is disabled. */
    suppressSessionScore?: boolean | null;
}
export declare const GetResultBotFightModeConfigurationStaleZoneConfiguration: S.Schema<GetResultBotFightModeConfigurationStaleZoneConfiguration>;
export interface GetResultBotFightModeConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultBotFightModeConfigurationAiBotsProtection | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultBotFightModeConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultBotFightModeConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultBotFightModeConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultBotFightModeConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const GetResultBotFightModeConfiguration: S.Schema<GetResultBotFightModeConfiguration>;
export type GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection: any;
export type GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant: any;
export type GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection = "block" | "disabled";
export declare const GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection: any;
export type GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection: any;
export type GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export declare const GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated: any;
export type GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots = "allow" | "block";
export declare const GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots: any;
export interface GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null;
}
export declare const GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration: S.Schema<GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration>;
export interface GetResultSuperBotFightModeDefinitelyConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const GetResultSuperBotFightModeDefinitelyConfiguration: S.Schema<GetResultSuperBotFightModeDefinitelyConfiguration>;
export type GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection: any;
export type GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant: any;
export type GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection = "block" | "disabled";
export declare const GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection: any;
export type GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection: any;
export type GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export declare const GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated: any;
export type GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export declare const GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated: any;
export type GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots = "allow" | "block";
export declare const GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots: any;
export interface GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null;
}
export declare const GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration: S.Schema<GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration>;
export interface GetResultSuperBotFightModeLikelyConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const GetResultSuperBotFightModeLikelyConfiguration: S.Schema<GetResultSuperBotFightModeLikelyConfiguration>;
export type GetResultSubscriptionConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const GetResultSubscriptionConfigurationAiBotsProtection: any;
export type GetResultSubscriptionConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const GetResultSubscriptionConfigurationCfRobotsVariant: any;
export type GetResultSubscriptionConfigurationContentBotsProtection = "block" | "disabled";
export declare const GetResultSubscriptionConfigurationContentBotsProtection: any;
export type GetResultSubscriptionConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const GetResultSubscriptionConfigurationCrawlerProtection: any;
export interface GetResultSubscriptionConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null;
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | null;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | null;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | null;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | null;
}
export declare const GetResultSubscriptionConfigurationStaleZoneConfiguration: S.Schema<GetResultSubscriptionConfigurationStaleZoneConfiguration>;
export interface GetResultSubscriptionConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSubscriptionConfigurationAiBotsProtection | null;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | null;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSubscriptionConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSubscriptionConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSubscriptionConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSubscriptionConfigurationStaleZoneConfiguration | null;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const GetResultSubscriptionConfiguration: S.Schema<GetResultSubscriptionConfiguration>;
export type GetResult = GetResultBotFightModeConfiguration | GetResultSuperBotFightModeDefinitelyConfiguration | GetResultSuperBotFightModeLikelyConfiguration | GetResultSubscriptionConfiguration;
export declare const GetResult: any;
export type GetBotManagementResponse = GetResult;
export declare const GetBotManagementResponse: S.Schema<GetBotManagementResponse>;
export interface ListFeedbackRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListFeedbackRequest: S.Schema<ListFeedbackRequest>;
export type ListFeedbackResponseRequestsByAttribute = CreateFeedbackRequestRequestsByAttribute;
export declare const ListFeedbackResponseRequestsByAttribute: S.Schema<CreateFeedbackRequestRequestsByAttribute>;
export type ListFeedbackResponseType = "false_positive" | "false_negative";
export declare const ListFeedbackResponseType: any;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListFeedbackResponse {
    description: string;
    /** Wirefilter expression describing the traffic being reported. */
    expression: string;
    firstRequestSeenAt: string;
    lastRequestSeenAt: string;
    requests: number;
    /** Top attributes contributing to the feedback sample. Keys include topASNs, topCountries, topHosts, topIPs, topJA3Hashes, topJA4s, topPaths, topUserAgents. */
    requestsByAttribute: CreateFeedbackRequestRequestsByAttribute;
    /** Map of bot scores (1-99) to request counts. Sum must equal `requests`. */
    requestsByScore: unknown;
    /** Map of score source to request counts. Sum must equal `requests`. */
    requestsByScoreSrc: unknown;
    /** Type of feedback report. */
    type: ListFeedbackResponseType;
    createdAt?: string | null;
    subtype?: string | null;
}
export declare const ListFeedbackResponse: S.Schema<ListFeedbackResponse>;
export type UpdateRequestAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const UpdateRequestAiBotsProtection: any;
export type UpdateRequestCfRobotsVariant = "off" | "policy_only";
export declare const UpdateRequestCfRobotsVariant: any;
export type UpdateRequestContentBotsProtection = "block" | "disabled";
export declare const UpdateRequestContentBotsProtection: any;
export type UpdateRequestCrawlerProtection = "enabled" | "disabled";
export declare const UpdateRequestCrawlerProtection: any;
export interface UpdateRequestStaleZoneConfigurationBotFightModeConfiguration {
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string;
    /** Indicates that the zone's session score tracking is disabled. */
    suppressSessionScore?: boolean;
}
export declare const UpdateRequestStaleZoneConfigurationBotFightModeConfiguration: S.Schema<UpdateRequestStaleZoneConfigurationBotFightModeConfiguration>;
export interface UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string;
}
export declare const UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration: S.Schema<UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration>;
export interface UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean;
}
export declare const UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration: S.Schema<UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration>;
export interface UpdateRequestStaleZoneConfigurationSubscriptionConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean;
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string;
}
export declare const UpdateRequestStaleZoneConfigurationSubscriptionConfiguration: S.Schema<UpdateRequestStaleZoneConfigurationSubscriptionConfiguration>;
export type UpdateRequestStaleZoneConfiguration = UpdateRequestStaleZoneConfigurationBotFightModeConfiguration | UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration | UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration | UpdateRequestStaleZoneConfigurationSubscriptionConfiguration;
export declare const UpdateRequestStaleZoneConfiguration: any;
export type UpdateRequestSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export declare const UpdateRequestSbfmDefinitelyAutomated: any;
export type UpdateRequestSbfmVerifiedBots = "allow" | "block";
export declare const UpdateRequestSbfmVerifiedBots: any;
export type UpdateRequestSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export declare const UpdateRequestSbfmLikelyAutomated: any;
export interface PutBotManagementRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateRequestAiBotsProtection | (string & {});
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateRequestCfRobotsVariant | (string & {});
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateRequestContentBotsProtection | (string & {});
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateRequestCrawlerProtection | (string & {});
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: UpdateRequestStaleZoneConfiguration;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateRequestSbfmDefinitelyAutomated | (string & {});
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. */
    sbfmStaticResourceProtection?: boolean;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateRequestSbfmVerifiedBots | (string & {});
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: UpdateRequestSbfmLikelyAutomated | (string & {});
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean;
}
export declare const PutBotManagementRequest: S.Schema<PutBotManagementRequest>;
export type UpdateResultBotFightModeConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const UpdateResultBotFightModeConfigurationAiBotsProtection: any;
export type UpdateResultBotFightModeConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const UpdateResultBotFightModeConfigurationCfRobotsVariant: any;
export type UpdateResultBotFightModeConfigurationContentBotsProtection = "block" | "disabled";
export declare const UpdateResultBotFightModeConfigurationContentBotsProtection: any;
export type UpdateResultBotFightModeConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const UpdateResultBotFightModeConfigurationCrawlerProtection: any;
export type UpdateResultBotFightModeConfigurationStaleZoneConfiguration = GetResultBotFightModeConfigurationStaleZoneConfiguration;
export declare const UpdateResultBotFightModeConfigurationStaleZoneConfiguration: S.Schema<GetResultBotFightModeConfigurationStaleZoneConfiguration>;
export interface UpdateResultBotFightModeConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultBotFightModeConfigurationAiBotsProtection | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultBotFightModeConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultBotFightModeConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultBotFightModeConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultBotFightModeConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const UpdateResultBotFightModeConfiguration: S.Schema<UpdateResultBotFightModeConfiguration>;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection: any;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant: any;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection = "block" | "disabled";
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection: any;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection: any;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated: any;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots = "allow" | "block";
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots: any;
export type UpdateResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration = GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration;
export declare const UpdateResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration: S.Schema<GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration>;
export interface UpdateResultSuperBotFightModeDefinitelyConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const UpdateResultSuperBotFightModeDefinitelyConfiguration: S.Schema<UpdateResultSuperBotFightModeDefinitelyConfiguration>;
export type UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection = "block" | "disabled";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots = "allow" | "block";
export declare const UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots: any;
export type UpdateResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration = GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration;
export declare const UpdateResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration: S.Schema<GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration>;
export interface UpdateResultSuperBotFightModeLikelyConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated | null;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. */
    sbfmStaticResourceProtection?: boolean | null;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const UpdateResultSuperBotFightModeLikelyConfiguration: S.Schema<UpdateResultSuperBotFightModeLikelyConfiguration>;
export type UpdateResultSubscriptionConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export declare const UpdateResultSubscriptionConfigurationAiBotsProtection: any;
export type UpdateResultSubscriptionConfigurationCfRobotsVariant = "off" | "policy_only";
export declare const UpdateResultSubscriptionConfigurationCfRobotsVariant: any;
export type UpdateResultSubscriptionConfigurationContentBotsProtection = "block" | "disabled";
export declare const UpdateResultSubscriptionConfigurationContentBotsProtection: any;
export type UpdateResultSubscriptionConfigurationCrawlerProtection = "enabled" | "disabled";
export declare const UpdateResultSubscriptionConfigurationCrawlerProtection: any;
export type UpdateResultSubscriptionConfigurationStaleZoneConfiguration = GetResultSubscriptionConfigurationStaleZoneConfiguration;
export declare const UpdateResultSubscriptionConfigurationStaleZoneConfiguration: S.Schema<GetResultSubscriptionConfigurationStaleZoneConfiguration>;
export interface UpdateResultSubscriptionConfiguration {
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSubscriptionConfigurationAiBotsProtection | null;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | null;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | null;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSubscriptionConfigurationCfRobotsVariant | null;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSubscriptionConfigurationContentBotsProtection | null;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSubscriptionConfigurationCrawlerProtection | null;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSubscriptionConfigurationStaleZoneConfiguration | null;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | null;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null;
}
export declare const UpdateResultSubscriptionConfiguration: S.Schema<UpdateResultSubscriptionConfiguration>;
export type UpdateResult = UpdateResultBotFightModeConfiguration | UpdateResultSuperBotFightModeDefinitelyConfiguration | UpdateResultSuperBotFightModeLikelyConfiguration | UpdateResultSubscriptionConfiguration;
export declare const UpdateResult: any;
export type PutBotManagementResponse = UpdateResult;
export declare const PutBotManagementResponse: S.Schema<PutBotManagementResponse>;
export type CreateFeedbackError = CloudflareOpError;
/** Submit a feedback report for the specified zone. Use `type` to indicate whether the report is a false positive (good traffic flagged as bot) or a false negative (bot traffic missed). Furthermore, you can also use `expression` as a wirefilter to identify the affected traffic sample. See more accepted API fields and expression types at https://developers.cloudflare.com/bots/concepts/feedback-loop/#api-fields and https://developers.cloudflare.com/bots/concepts/feedback-loop/#expression-fields, respectively. */
export declare const createFeedback: API.OperationMethod<CreateFeedbackRequest, CreateFeedbackResponse, CreateFeedbackError, CloudflareOpContext>;
export type GetBotManagementError = Forbidden | CloudflareOpError;
/** Retrieve a zone's Bot Management Config */
export declare const getBotManagement: API.OperationMethod<GetBotManagementRequest, GetBotManagementResponse, GetBotManagementError, CloudflareOpContext>;
export type ListFeedbackError = CloudflareOpError;
/** Returns all feedback reports previously submitted for the specified zone. Feedback reports help improve detection by sharing samples of traffic that were misclassified as bots or humans. */
export declare const listFeedback: API.OperationMethod<ListFeedbackRequest, ListFeedbackResponse, ListFeedbackError, CloudflareOpContext>;
export type PutBotManagementError = Forbidden | CloudflareOpError;
/** Updates the Bot Management configuration for a zone. This API is used to update: - **Bot Fight Mode** - **Super Bot Fight Mode** - **Bot Management for Enterprise** See [Bot Plans](https://developers.cloudflare.com/bots/plans/) for more information on the different plans \ If you recently upgraded or downgraded your plan, refer to the following examples to clean up old configurations. Copy and paste the example body to remove old zone configurations based on your current plan. #### Clean up configuration for Bot Fight Mode plan ```json { "sbfm_likely_automated": "allow", "sbfm_definitely_automated": "allow", "sbfm_verified_bots": "allow", "sbfm_static_resource_protection": false, "optimize_wordpress": false, "suppress_session_score": false } ``` #### Clean up configuration for SBFM Pro plan ```json { "sbfm_likely_automated": "allow", "fight_mode": false } ``` #### Clean up configuration for SBFM Biz plan ```json { "fight_mode": false } ``` #### Clean up configuration for BM Enterprise Subscription plan It is strongly recommended that you ensure you have [custom rules](https://developers.cloudflare.com/waf/custom-rules/) in place to protect your zone before disabling the SBFM rules. Without these protections, your zone is vulnerable to attacks. ```json { "sbfm_likely_automated": "allow", "sbfm_definitely_automated": "allow", "sbfm_verified_bots": "allow", "sbfm_static_resource_protection": false, "optimize_wordpress": false, "fight_mode": false } ``` */
export declare const putBotManagement: API.OperationMethod<PutBotManagementRequest, PutBotManagementResponse, PutBotManagementError, CloudflareOpContext>;
//# sourceMappingURL=bot_management.d.ts.map