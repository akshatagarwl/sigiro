import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const EndpointHealthcheckNotFound_base: S.Class<EndpointHealthcheckNotFound, S.TaggedStruct<"EndpointHealthcheckNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EndpointHealthcheckNotFound extends /*@__PURE__*/ EndpointHealthcheckNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidHealthcheckEndpoint_base: S.Class<InvalidHealthcheckEndpoint, S.TaggedStruct<"InvalidHealthcheckEndpoint", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidHealthcheckEndpoint extends /*@__PURE__*/ InvalidHealthcheckEndpoint_base {
}
export type EndpointHealthchecksCreateRequestCheckType = "icmp";
export declare const EndpointHealthchecksCreateRequestCheckType: any;
export interface CreateEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** type of check to perform */
    checkType: EndpointHealthchecksCreateRequestCheckType | (string & {});
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** Optional name associated with this check */
    name?: string;
}
export declare const CreateEndpointHealthcheckRequest: S.Schema<CreateEndpointHealthcheckRequest>;
export type EndpointHealthchecksCreateResponseCheckType = "icmp";
export declare const EndpointHealthchecksCreateResponseCheckType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEndpointHealthcheckResponse {
    /** type of check to perform */
    checkType: EndpointHealthchecksCreateResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export declare const CreateEndpointHealthcheckResponse: S.Schema<CreateEndpointHealthcheckResponse>;
export type TraceroutesCreateRequestTargetsList = Array<string>;
export declare const TraceroutesCreateRequestTargetsList: S.Schema<TraceroutesCreateRequestTargetsList>;
export type TraceroutesCreateRequestColosList = Array<string>;
export declare const TraceroutesCreateRequestColosList: S.Schema<TraceroutesCreateRequestColosList>;
export type TraceroutesCreateRequestOptionsPacketType = "icmp" | "tcp" | "udp" | "gre" | "gre+icmp";
export declare const TraceroutesCreateRequestOptionsPacketType: any;
export interface TraceroutesCreateRequestOptions {
    /** Max TTL. */
    maxTtl?: number;
    /** Type of packet sent. */
    packetType?: TraceroutesCreateRequestOptionsPacketType | (string & {});
    /** Number of packets sent at each TTL. */
    packetsPerTtl?: number;
    /** For UDP and TCP, specifies the destination port. For ICMP, specifies the initial ICMP sequence value. Default value 0 will choose the best value to use for each protocol. */
    port?: number;
    /** Set the time (in seconds) to wait for a response to a probe. */
    waitTime?: number;
}
export declare const TraceroutesCreateRequestOptions: S.Schema<TraceroutesCreateRequestOptions>;
export interface CreateTracerouteRequest {
    /** Identifier */
    accountId: string;
    targets: TraceroutesCreateRequestTargetsList;
    /** If no source colo names specified, all colos will be used. China colos are unavailable for traceroutes. */
    colos?: TraceroutesCreateRequestColosList;
    options?: TraceroutesCreateRequestOptions;
}
export declare const CreateTracerouteRequest: S.Schema<CreateTracerouteRequest>;
export interface TraceroutesCreateResultItemColosItemColo {
    /** Source colo city. */
    city?: string | null;
    /** Source colo name. */
    name?: string | null;
}
export declare const TraceroutesCreateResultItemColosItemColo: S.Schema<TraceroutesCreateResultItemColosItemColo>;
export type TraceroutesCreateResultItemColosItemError = "" | "Could not gather traceroute data: Code 1" | "Could not gather traceroute data: Code 2" | "Could not gather traceroute data: Code 3" | "Could not gather traceroute data: Code 4";
export declare const TraceroutesCreateResultItemColosItemError: any;
export type TraceroutesCreateResultItemColosItemHopsItemNodesItemLabelsList = Array<string>;
export declare const TraceroutesCreateResultItemColosItemHopsItemNodesItemLabelsList: S.Schema<TraceroutesCreateResultItemColosItemHopsItemNodesItemLabelsList>;
export interface TraceroutesCreateResultItemColosItemHopsItemNodesItem {
    /** AS number associated with the node object. */
    asn?: string | null;
    /** IP address of the node. */
    ip?: string | null;
    /** Field appears if there is an additional annotation printed when the probe returns. Field also appears when running a GRE+ICMP traceroute to denote which traceroute a node comes from. */
    labels?: TraceroutesCreateResultItemColosItemHopsItemNodesItemLabelsList | null;
    /** Maximum RTT in ms. */
    maxRttMs?: number | null;
    /** Mean RTT in ms. */
    meanRttMs?: number | null;
    /** Minimum RTT in ms. */
    minRttMs?: number | null;
    /** Host name of the address, this may be the same as the IP address. */
    name?: string | null;
    /** Number of packets with a response from this node. */
    packetCount?: number | null;
    /** Standard deviation of the RTTs in ms. */
    stdDevRttMs?: number | null;
}
export declare const TraceroutesCreateResultItemColosItemHopsItemNodesItem: S.Schema<TraceroutesCreateResultItemColosItemHopsItemNodesItem>;
export type TraceroutesCreateResultItemColosItemHopsItemNodesList = Array<TraceroutesCreateResultItemColosItemHopsItemNodesItem>;
export declare const TraceroutesCreateResultItemColosItemHopsItemNodesList: S.Schema<TraceroutesCreateResultItemColosItemHopsItemNodesList>;
export interface TraceroutesCreateResultItemColosItemHopsItem {
    /** An array of node objects. */
    nodes?: TraceroutesCreateResultItemColosItemHopsItemNodesList | null;
    /** Number of packets where no response was received. */
    packetsLost?: number | null;
    /** Number of packets sent with specified TTL. */
    packetsSent?: number | null;
    /** The time to live (TTL). */
    packetsTtl?: number | null;
}
export declare const TraceroutesCreateResultItemColosItemHopsItem: S.Schema<TraceroutesCreateResultItemColosItemHopsItem>;
export type TraceroutesCreateResultItemColosItemHopsList = Array<TraceroutesCreateResultItemColosItemHopsItem>;
export declare const TraceroutesCreateResultItemColosItemHopsList: S.Schema<TraceroutesCreateResultItemColosItemHopsList>;
export interface TraceroutesCreateResultItemColosItem {
    colo?: TraceroutesCreateResultItemColosItemColo | null;
    /** Errors resulting from collecting traceroute from colo to target. */
    error?: TraceroutesCreateResultItemColosItemError | null;
    hops?: TraceroutesCreateResultItemColosItemHopsList | null;
    /** Aggregated statistics from all hops about the target. */
    targetSummary?: unknown | null;
    /** Total time of traceroute in ms. */
    tracerouteTimeMs?: number | null;
}
export declare const TraceroutesCreateResultItemColosItem: S.Schema<TraceroutesCreateResultItemColosItem>;
export type TraceroutesCreateResultItemColosList = Array<TraceroutesCreateResultItemColosItem>;
export declare const TraceroutesCreateResultItemColosList: S.Schema<TraceroutesCreateResultItemColosList>;
export interface TraceroutesCreateResultItem {
    colos?: TraceroutesCreateResultItemColosList | null;
    /** The target hostname, IPv6, or IPv6 address. */
    target?: string | null;
}
export declare const TraceroutesCreateResultItem: S.Schema<TraceroutesCreateResultItem>;
export type TraceroutesCreateResultList = Array<TraceroutesCreateResultItem>;
export declare const TraceroutesCreateResultList: S.Schema<TraceroutesCreateResultList>;
export interface CreateTracerouteResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TraceroutesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateTracerouteResponse: S.Schema<CreateTracerouteResponse>;
export interface DeleteEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** UUID. */
    id: string;
}
export declare const DeleteEndpointHealthcheckRequest: S.Schema<DeleteEndpointHealthcheckRequest>;
export interface DeleteEndpointHealthcheckResponse {
}
export declare const DeleteEndpointHealthcheckResponse: S.Schema<DeleteEndpointHealthcheckResponse>;
export interface GetEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** UUID. */
    id: string;
}
export declare const GetEndpointHealthcheckRequest: S.Schema<GetEndpointHealthcheckRequest>;
export type EndpointHealthchecksGetResponseCheckType = "icmp";
export declare const EndpointHealthchecksGetResponseCheckType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEndpointHealthcheckResponse {
    /** type of check to perform */
    checkType: EndpointHealthchecksGetResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export declare const GetEndpointHealthcheckResponse: S.Schema<GetEndpointHealthcheckResponse>;
export interface ListEndpointHealthchecksRequest {
    /** Identifier */
    accountId: string;
}
export declare const ListEndpointHealthchecksRequest: S.Schema<ListEndpointHealthchecksRequest>;
export type EndpointHealthchecksListResponseCheckType = "icmp";
export declare const EndpointHealthchecksListResponseCheckType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListEndpointHealthchecksItem {
    /** type of check to perform */
    checkType: EndpointHealthchecksListResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export declare const ListEndpointHealthchecksItem: S.Schema<ListEndpointHealthchecksItem>;
export type ListEndpointHealthchecksItemsList = Array<ListEndpointHealthchecksItem>;
export declare const ListEndpointHealthchecksItemsList: S.Schema<ListEndpointHealthchecksItemsList>;
export type ListEndpointHealthchecksResponse = ListEndpointHealthchecksItemsList;
export declare const ListEndpointHealthchecksResponse: S.Schema<ListEndpointHealthchecksResponse>;
export type EndpointHealthchecksUpdateRequestCheckType = "icmp";
export declare const EndpointHealthchecksUpdateRequestCheckType: any;
export interface UpdateEndpointHealthcheckRequest {
    /** Identifier */
    accountId: string;
    /** UUID. */
    id: string;
    /** type of check to perform */
    checkType: EndpointHealthchecksUpdateRequestCheckType | (string & {});
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** Optional name associated with this check */
    name?: string;
}
export declare const UpdateEndpointHealthcheckRequest: S.Schema<UpdateEndpointHealthcheckRequest>;
export type EndpointHealthchecksUpdateResponseCheckType = "icmp";
export declare const EndpointHealthchecksUpdateResponseCheckType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateEndpointHealthcheckResponse {
    /** type of check to perform */
    checkType: EndpointHealthchecksUpdateResponseCheckType;
    /** the IP address of the host to perform checks against */
    endpoint: string;
    /** UUID. */
    id?: string | null;
    /** Optional name associated with this check */
    name?: string | null;
}
export declare const UpdateEndpointHealthcheckResponse: S.Schema<UpdateEndpointHealthcheckResponse>;
export type CreateEndpointHealthcheckError = InvalidHealthcheckEndpoint | Forbidden | CloudflareOpError;
/** Create Endpoint Health Check. */
export declare const createEndpointHealthcheck: API.OperationMethod<CreateEndpointHealthcheckRequest, CreateEndpointHealthcheckResponse, CreateEndpointHealthcheckError, CloudflareOpContext>;
export type CreateTracerouteError = CloudflareOpError;
/** Run traceroutes from Cloudflare colos. */
export declare const createTraceroute: API.PaginatedOperationMethod<CreateTracerouteRequest, CreateTracerouteResponse, CreateTracerouteError, CloudflareOpContext, TraceroutesCreateResultItem>;
export type DeleteEndpointHealthcheckError = EndpointHealthcheckNotFound | Forbidden | CloudflareOpError;
/** Delete Endpoint Health Check. */
export declare const deleteEndpointHealthcheck: API.OperationMethod<DeleteEndpointHealthcheckRequest, DeleteEndpointHealthcheckResponse, DeleteEndpointHealthcheckError, CloudflareOpContext>;
export type GetEndpointHealthcheckError = EndpointHealthcheckNotFound | Forbidden | CloudflareOpError;
/** Get a single Endpoint Health Check. */
export declare const getEndpointHealthcheck: API.OperationMethod<GetEndpointHealthcheckRequest, GetEndpointHealthcheckResponse, GetEndpointHealthcheckError, CloudflareOpContext>;
export type ListEndpointHealthchecksError = Forbidden | CloudflareOpError;
/** List Endpoint Health Checks. */
export declare const listEndpointHealthchecks: API.OperationMethod<ListEndpointHealthchecksRequest, ListEndpointHealthchecksResponse, ListEndpointHealthchecksError, CloudflareOpContext>;
export type UpdateEndpointHealthcheckError = EndpointHealthcheckNotFound | InvalidHealthcheckEndpoint | Forbidden | CloudflareOpError;
/** Update a Endpoint Health Check. */
export declare const updateEndpointHealthcheck: API.OperationMethod<UpdateEndpointHealthcheckRequest, UpdateEndpointHealthcheckResponse, UpdateEndpointHealthcheckError, CloudflareOpContext>;
//# sourceMappingURL=diagnostics.d.ts.map