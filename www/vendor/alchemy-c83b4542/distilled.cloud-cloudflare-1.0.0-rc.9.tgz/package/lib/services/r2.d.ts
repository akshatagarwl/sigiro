import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const BucketAlreadyExists_base: S.Class<BucketAlreadyExists, S.TaggedStruct<"BucketAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BucketAlreadyExists extends /*@__PURE__*/ BucketAlreadyExists_base {
}
declare const BucketNotEmpty_base: S.Class<BucketNotEmpty, S.TaggedStruct<"BucketNotEmpty", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BucketNotEmpty extends /*@__PURE__*/ BucketNotEmpty_base {
}
declare const BucketNotFound_base: S.Class<BucketNotFound, S.TaggedStruct<"BucketNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BucketNotFound extends /*@__PURE__*/ BucketNotFound_base {
}
declare const CustomDomainInUse_base: S.Class<CustomDomainInUse, S.TaggedStruct<"CustomDomainInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CustomDomainInUse extends /*@__PURE__*/ CustomDomainInUse_base {
}
declare const DomainNotFound_base: S.Class<DomainNotFound, S.TaggedStruct<"DomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DomainNotFound extends /*@__PURE__*/ DomainNotFound_base {
}
declare const EventNotificationConfigNotFound_base: S.Class<EventNotificationConfigNotFound, S.TaggedStruct<"EventNotificationConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EventNotificationConfigNotFound extends /*@__PURE__*/ EventNotificationConfigNotFound_base {
}
declare const EventNotificationRuleConflict_base: S.Class<EventNotificationRuleConflict, S.TaggedStruct<"EventNotificationRuleConflict", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EventNotificationRuleConflict extends /*@__PURE__*/ EventNotificationRuleConflict_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidBucketName_base: S.Class<InvalidBucketName, S.TaggedStruct<"InvalidBucketName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBucketName extends /*@__PURE__*/ InvalidBucketName_base {
}
declare const InvalidEventNotificationConfig_base: S.Class<InvalidEventNotificationConfig, S.TaggedStruct<"InvalidEventNotificationConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidEventNotificationConfig extends /*@__PURE__*/ InvalidEventNotificationConfig_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidUpstreamCredentials_base: S.Class<InvalidUpstreamCredentials, S.TaggedStruct<"InvalidUpstreamCredentials", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidUpstreamCredentials extends /*@__PURE__*/ InvalidUpstreamCredentials_base {
}
declare const NoCorsConfiguration_base: S.Class<NoCorsConfiguration, S.TaggedStruct<"NoCorsConfiguration", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoCorsConfiguration extends /*@__PURE__*/ NoCorsConfiguration_base {
}
declare const NoEventNotificationConfig_base: S.Class<NoEventNotificationConfig, S.TaggedStruct<"NoEventNotificationConfig", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoEventNotificationConfig extends /*@__PURE__*/ NoEventNotificationConfig_base {
}
declare const NoRoute_base: S.Class<NoRoute, S.TaggedStruct<"NoRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoRoute extends /*@__PURE__*/ NoRoute_base {
}
declare const NoSuchBucket_base: S.Class<NoSuchBucket, S.TaggedStruct<"NoSuchBucket", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchBucket extends /*@__PURE__*/ NoSuchBucket_base {
}
declare const NoSuchKey_base: S.Class<NoSuchKey, S.TaggedStruct<"NoSuchKey", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchKey extends /*@__PURE__*/ NoSuchKey_base {
}
declare const QueueNotFound_base: S.Class<QueueNotFound, S.TaggedStruct<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
export interface AbortAllSuperSlurperJobRequest {
    accountId: string;
}
export declare const AbortAllSuperSlurperJobRequest: S.Schema<AbortAllSuperSlurperJobRequest>;
export type AbortAllSuperSlurperJobResponse = string;
export declare const AbortAllSuperSlurperJobResponse: S.Schema<AbortAllSuperSlurperJobResponse>;
export interface AbortSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export declare const AbortSuperSlurperJobRequest: S.Schema<AbortSuperSlurperJobRequest>;
export type AbortSuperSlurperJobResponse = string;
export declare const AbortSuperSlurperJobResponse: S.Schema<AbortSuperSlurperJobResponse>;
export type BucketsCreateRequestLocationHint = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export declare const BucketsCreateRequestLocationHint: any;
export type BucketsCreateRequestStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsCreateRequestStorageClass: any;
export type BucketsCreateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsCreateRequestCfR2Jurisdiction: any;
export interface CreateBucketRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    name: string;
    /** Location of the bucket. */
    locationHint?: BucketsCreateRequestLocationHint | (string & {});
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsCreateRequestStorageClass | (string & {});
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsCreateRequestCfR2Jurisdiction | (string & {});
}
export declare const CreateBucketRequest: S.Schema<CreateBucketRequest>;
export type BucketsCreateResponseJurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsCreateResponseJurisdiction: any;
export type BucketsCreateResponseLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export declare const BucketsCreateResponseLocation: any;
export type BucketsCreateResponseStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsCreateResponseStorageClass: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBucketResponse {
    /** Creation timestamp. */
    creationDate?: string | null;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsCreateResponseJurisdiction | null;
    /** Location of the bucket. */
    location?: BucketsCreateResponseLocation | null;
    /** Name of the bucket. */
    name?: string | null;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsCreateResponseStorageClass | null;
}
export declare const CreateBucketResponse: S.Schema<CreateBucketResponse>;
export type BucketsDomainsCustomCreateRequestCiphersList = Array<string>;
export declare const BucketsDomainsCustomCreateRequestCiphersList: S.Schema<BucketsDomainsCustomCreateRequestCiphersList>;
export type BucketsDomainsCustomCreateRequestMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export declare const BucketsDomainsCustomCreateRequestMinTLS: any;
export type BucketsDomainsCustomCreateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsCustomCreateRequestCfR2Jurisdiction: any;
export interface CreateBucketDomainCustomRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain to be added. */
    domain: string;
    /** Whether to enable public bucket access at the custom domain. If undefined, the domain will be enabled. */
    enabled: boolean;
    /** Zone ID of the custom domain. */
    zoneId: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomCreateRequestCiphersList;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomCreateRequestMinTLS | (string & {});
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsCustomCreateRequestCfR2Jurisdiction | (string & {});
}
export declare const CreateBucketDomainCustomRequest: S.Schema<CreateBucketDomainCustomRequest>;
export type BucketsDomainsCustomCreateResponseCiphersList = Array<string>;
export declare const BucketsDomainsCustomCreateResponseCiphersList: S.Schema<BucketsDomainsCustomCreateResponseCiphersList>;
export type BucketsDomainsCustomCreateResponseMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export declare const BucketsDomainsCustomCreateResponseMinTLS: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBucketDomainCustomResponse {
    /** Domain name of the affected custom domain. */
    domain: string;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled: boolean;
    /** Zone ID of the custom domain. */
    zoneId: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomCreateResponseCiphersList | null;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomCreateResponseMinTLS | null;
}
export declare const CreateBucketDomainCustomResponse: S.Schema<CreateBucketDomainCustomResponse>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret {
    accessKeyId: string;
    secretAccessKey: string;
}
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret>;
export type SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaVendor = "s3";
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaVendor: any;
export type SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaKeysList: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaKeysList>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchema {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaVendor;
    /** Custom S3-compatible endpoint that must use https://. */
    endpoint?: string;
    keys?: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaKeysList;
    pathPrefix?: string;
    region?: string;
}
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchema: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchema>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret {
    clientEmail: string;
    privateKey: string;
}
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret>;
export type SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaVendor = "gcs";
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaVendor: any;
export type SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaKeysList: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaKeysList>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchema {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaVendor;
    keys?: SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaKeysList;
    pathPrefix?: string;
}
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchema: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchema>;
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaSecret: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret>;
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaVendor = "r2";
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaVendor: any;
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaJurisdiction: any;
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaKeysList: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaKeysList>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchema {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaVendor;
    jurisdiction?: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaJurisdiction | (string & {});
    keys?: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaKeysList;
    pathPrefix?: string;
}
export declare const SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchema: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchema>;
export type SuperSlurperJobsCreateRequestSource = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchema | SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchema | SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchema;
export declare const SuperSlurperJobsCreateRequestSource: any;
export type SuperSlurperJobsCreateRequestTargetSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export declare const SuperSlurperJobsCreateRequestTargetSecret: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret>;
export type SuperSlurperJobsCreateRequestTargetJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperJobsCreateRequestTargetJurisdiction: any;
export interface SuperSlurperJobsCreateRequestTarget {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaVendor;
    jurisdiction?: SuperSlurperJobsCreateRequestTargetJurisdiction | (string & {});
}
export declare const SuperSlurperJobsCreateRequestTarget: S.Schema<SuperSlurperJobsCreateRequestTarget>;
export interface CreateSuperSlurperJobRequest {
    accountId: string;
    overwrite?: boolean;
    source?: SuperSlurperJobsCreateRequestSource;
    target?: SuperSlurperJobsCreateRequestTarget;
}
export declare const CreateSuperSlurperJobRequest: S.Schema<CreateSuperSlurperJobRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSuperSlurperJobResponse {
    id?: string | null;
}
export declare const CreateSuperSlurperJobResponse: S.Schema<CreateSuperSlurperJobResponse>;
export type TemporaryCredentialsCreateRequestPermission = "admin-read-write" | "admin-read-only" | "object-read-write" | "object-read-only";
export declare const TemporaryCredentialsCreateRequestPermission: any;
export type TemporaryCredentialsCreateRequestObjectsList = Array<string>;
export declare const TemporaryCredentialsCreateRequestObjectsList: S.Schema<TemporaryCredentialsCreateRequestObjectsList>;
export type TemporaryCredentialsCreateRequestPrefixesList = Array<string>;
export declare const TemporaryCredentialsCreateRequestPrefixesList: S.Schema<TemporaryCredentialsCreateRequestPrefixesList>;
export interface CreateTemporaryCredentialRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the R2 bucket. */
    bucket: string;
    /** The parent access key id to use for signing. */
    parentAccessKeyId: string;
    /** Permissions allowed on the credentials. */
    permission: TemporaryCredentialsCreateRequestPermission | (string & {});
    /** How long the credentials will live for in seconds. */
    ttlSeconds: number;
    /** Optional object paths to scope the credentials to. */
    objects?: TemporaryCredentialsCreateRequestObjectsList;
    /** Optional prefix paths to scope the credentials to. */
    prefixes?: TemporaryCredentialsCreateRequestPrefixesList;
}
export declare const CreateTemporaryCredentialRequest: S.Schema<CreateTemporaryCredentialRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTemporaryCredentialResponse {
    /** ID for new access key. */
    accessKeyId?: string | null;
    /** Secret access key. */
    secretAccessKey?: string | null;
    /** Security token. */
    sessionToken?: string | null;
}
export declare const CreateTemporaryCredentialResponse: S.Schema<CreateTemporaryCredentialResponse>;
export type BucketsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDeleteRequestCfR2Jurisdiction: any;
export interface DeleteBucketRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDeleteRequestCfR2Jurisdiction | (string & {});
}
export declare const DeleteBucketRequest: S.Schema<DeleteBucketRequest>;
export type DeleteBucketResponse = unknown;
export declare const DeleteBucketResponse: S.Schema<DeleteBucketResponse>;
export type BucketsCorsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsCorsDeleteRequestCfR2Jurisdiction: any;
export interface DeleteBucketCorsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsCorsDeleteRequestCfR2Jurisdiction | (string & {});
}
export declare const DeleteBucketCorsRequest: S.Schema<DeleteBucketCorsRequest>;
export type DeleteBucketCorsResponse = unknown;
export declare const DeleteBucketCorsResponse: S.Schema<DeleteBucketCorsResponse>;
export type BucketsDomainsCustomDeleteRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsCustomDeleteRequestCfR2Jurisdiction: any;
export interface DeleteBucketDomainCustomRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain. */
    domain: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsCustomDeleteRequestCfR2Jurisdiction | (string & {});
}
export declare const DeleteBucketDomainCustomRequest: S.Schema<DeleteBucketDomainCustomRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBucketDomainCustomResponse {
    /** Name of the removed custom domain. */
    domain: string;
}
export declare const DeleteBucketDomainCustomResponse: S.Schema<DeleteBucketDomainCustomResponse>;
export type BucketsEventNotificationsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsEventNotificationsDeleteRequestCfR2Jurisdiction: any;
export interface DeleteBucketEventNotificationRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Queue ID. */
    queueId: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsEventNotificationsDeleteRequestCfR2Jurisdiction | (string & {});
}
export declare const DeleteBucketEventNotificationRequest: S.Schema<DeleteBucketEventNotificationRequest>;
export type DeleteBucketEventNotificationResponse = unknown;
export declare const DeleteBucketEventNotificationResponse: S.Schema<DeleteBucketEventNotificationResponse>;
export type BucketsObjectsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsObjectsDeleteRequestCfR2Jurisdiction: any;
export interface DeleteBucketObjectRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    cfR2Jurisdiction?: BucketsObjectsDeleteRequestCfR2Jurisdiction | (string & {});
    /** The key (name) of the object to delete. May contain slashes for path-like keys. */
    objectName: string;
}
export declare const DeleteBucketObjectRequest: S.Schema<DeleteBucketObjectRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBucketObjectResponse {
    /** The key (name) of the deleted object. */
    key?: string | null;
}
export declare const DeleteBucketObjectResponse: S.Schema<DeleteBucketObjectResponse>;
export type BucketsSippyDeleteRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsSippyDeleteRequestCfR2Jurisdiction: any;
export interface DeleteBucketSippyRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsSippyDeleteRequestCfR2Jurisdiction | (string & {});
}
export declare const DeleteBucketSippyRequest: S.Schema<DeleteBucketSippyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBucketSippyResponse {
    enabled?: boolean | null;
}
export declare const DeleteBucketSippyResponse: S.Schema<DeleteBucketSippyResponse>;
export type DeleteObjectsKeyList = Array<string>;
export declare const DeleteObjectsKeyList: S.Schema<DeleteObjectsKeyList>;
export interface DeleteObjectsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the R2 bucket. */
    bucketName: string;
    prefix?: string;
    body?: DeleteObjectsKeyList;
    cfR2Jurisdiction?: string;
}
export declare const DeleteObjectsRequest: S.Schema<DeleteObjectsRequest>;
export type DeleteObjectsResponse = unknown;
export declare const DeleteObjectsResponse: S.Schema<DeleteObjectsResponse>;
export type BucketsGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsGetRequestCfR2Jurisdiction: any;
export interface GetBucketRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketRequest: S.Schema<GetBucketRequest>;
export type BucketsGetResponseJurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsGetResponseJurisdiction: any;
export type BucketsGetResponseLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export declare const BucketsGetResponseLocation: any;
export type BucketsGetResponseStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsGetResponseStorageClass: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketResponse {
    /** Creation timestamp. */
    creationDate?: string | null;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsGetResponseJurisdiction | null;
    /** Location of the bucket. */
    location?: BucketsGetResponseLocation | null;
    /** Name of the bucket. */
    name?: string | null;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsGetResponseStorageClass | null;
}
export declare const GetBucketResponse: S.Schema<GetBucketResponse>;
export type BucketsCorsGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsCorsGetRequestCfR2Jurisdiction: any;
export interface GetBucketCorsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsCorsGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketCorsRequest: S.Schema<GetBucketCorsRequest>;
export type BucketsCorsGetResponseRulesItemAllowedMethodsItem = "GET" | "PUT" | "POST" | "DELETE" | "HEAD";
export declare const BucketsCorsGetResponseRulesItemAllowedMethodsItem: any;
export type BucketsCorsGetResponseRulesItemAllowedMethodsList = Array<BucketsCorsGetResponseRulesItemAllowedMethodsItem>;
export declare const BucketsCorsGetResponseRulesItemAllowedMethodsList: S.Schema<BucketsCorsGetResponseRulesItemAllowedMethodsList>;
export type BucketsCorsGetResponseRulesItemAllowedOriginsList = Array<string>;
export declare const BucketsCorsGetResponseRulesItemAllowedOriginsList: S.Schema<BucketsCorsGetResponseRulesItemAllowedOriginsList>;
export type BucketsCorsGetResponseRulesItemAllowedHeadersList = Array<string>;
export declare const BucketsCorsGetResponseRulesItemAllowedHeadersList: S.Schema<BucketsCorsGetResponseRulesItemAllowedHeadersList>;
export interface BucketsCorsGetResponseRulesItemAllowed {
    /** Specifies the value for the Access-Control-Allow-Methods header R2 sets when requesting objects in a bucket from a browser. */
    methods: BucketsCorsGetResponseRulesItemAllowedMethodsList;
    /** Specifies the value for the Access-Control-Allow-Origin header R2 sets when requesting objects in a bucket from a browser. */
    origins: BucketsCorsGetResponseRulesItemAllowedOriginsList;
    /** Specifies the value for the Access-Control-Allow-Headers header R2 sets when requesting objects in this bucket from a browser. Cross-origin requests that include custom headers (e.g. x-user-id) should specify these headers as AllowedHeaders. */
    headers?: BucketsCorsGetResponseRulesItemAllowedHeadersList | null;
}
export declare const BucketsCorsGetResponseRulesItemAllowed: S.Schema<BucketsCorsGetResponseRulesItemAllowed>;
export type BucketsCorsGetResponseRulesItemExposeHeadersList = Array<string>;
export declare const BucketsCorsGetResponseRulesItemExposeHeadersList: S.Schema<BucketsCorsGetResponseRulesItemExposeHeadersList>;
export interface BucketsCorsGetResponseRulesItem {
    /** Object specifying allowed origins, methods and headers for this CORS rule. */
    allowed: BucketsCorsGetResponseRulesItemAllowed;
    /** Identifier for this rule. */
    id?: string | null;
    /** Specifies the headers that can be exposed back, and accessed by, the JavaScript making the cross-origin request. If you need to access headers beyond the safelisted response headers, such as Content-Encoding or cf-cache-status, you must specify it here. */
    exposeHeaders?: BucketsCorsGetResponseRulesItemExposeHeadersList | null;
    /** Specifies the amount of time (in seconds) browsers are allowed to cache CORS preflight responses. Browsers may limit this to 2 hours or less, even if the maximum value (86400) is specified. */
    maxAgeSeconds?: number | null;
}
export declare const BucketsCorsGetResponseRulesItem: S.Schema<BucketsCorsGetResponseRulesItem>;
export type BucketsCorsGetResponseRulesList = Array<BucketsCorsGetResponseRulesItem>;
export declare const BucketsCorsGetResponseRulesList: S.Schema<BucketsCorsGetResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketCorsResponse {
    rules?: BucketsCorsGetResponseRulesList | null;
}
export declare const GetBucketCorsResponse: S.Schema<GetBucketCorsResponse>;
export type BucketsDomainsCustomGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsCustomGetRequestCfR2Jurisdiction: any;
export interface GetBucketDomainCustomRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain. */
    domain: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsCustomGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketDomainCustomRequest: S.Schema<GetBucketDomainCustomRequest>;
export type BucketsDomainsCustomGetResponseStatusOwnership = "pending" | "active" | "deactivated" | "blocked" | "error" | "unknown";
export declare const BucketsDomainsCustomGetResponseStatusOwnership: any;
export type BucketsDomainsCustomGetResponseStatusSsl = "initializing" | "pending" | "active" | "deactivated" | "error" | "unknown";
export declare const BucketsDomainsCustomGetResponseStatusSsl: any;
export interface BucketsDomainsCustomGetResponseStatus {
    /** Ownership status of the domain. */
    ownership: BucketsDomainsCustomGetResponseStatusOwnership;
    /** SSL certificate status. */
    ssl: BucketsDomainsCustomGetResponseStatusSsl;
}
export declare const BucketsDomainsCustomGetResponseStatus: S.Schema<BucketsDomainsCustomGetResponseStatus>;
export type BucketsDomainsCustomGetResponseCiphersList = Array<string>;
export declare const BucketsDomainsCustomGetResponseCiphersList: S.Schema<BucketsDomainsCustomGetResponseCiphersList>;
export type BucketsDomainsCustomGetResponseMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export declare const BucketsDomainsCustomGetResponseMinTLS: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketDomainCustomResponse {
    /** Domain name of the custom domain to be added. */
    domain: string;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled: boolean;
    status: BucketsDomainsCustomGetResponseStatus;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomGetResponseCiphersList | null;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomGetResponseMinTLS | null;
    /** Zone ID of the custom domain resides in. */
    zoneId?: string | null;
    /** Zone that the custom domain resides in. */
    zoneName?: string | null;
}
export declare const GetBucketDomainCustomResponse: S.Schema<GetBucketDomainCustomResponse>;
export type BucketsEventNotificationsGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsEventNotificationsGetRequestCfR2Jurisdiction: any;
export interface GetBucketEventNotificationRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Queue ID. */
    queueId: string;
    /** The bucket jurisdiction. */
    jurisdiction?: BucketsEventNotificationsGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketEventNotificationRequest: S.Schema<GetBucketEventNotificationRequest>;
export type BucketsEventNotificationsGetResponseRulesItemActionsItem = "PutObject" | "CopyObject" | "DeleteObject" | "CompleteMultipartUpload" | "LifecycleDeletion";
export declare const BucketsEventNotificationsGetResponseRulesItemActionsItem: any;
export type BucketsEventNotificationsGetResponseRulesItemActionsList = Array<BucketsEventNotificationsGetResponseRulesItemActionsItem>;
export declare const BucketsEventNotificationsGetResponseRulesItemActionsList: S.Schema<BucketsEventNotificationsGetResponseRulesItemActionsList>;
export interface BucketsEventNotificationsGetResponseRulesItem {
    /** Array of R2 object actions that will trigger notifications. */
    actions: BucketsEventNotificationsGetResponseRulesItemActionsList;
    /** Timestamp when the rule was created. */
    createdAt?: string | null;
    /** A description that can be used to identify the event notification rule after creation. */
    description?: string | null;
    /** Notifications will be sent only for objects with this prefix. */
    prefix?: string | null;
    /** Rule ID. */
    ruleId?: string | null;
    /** Notifications will be sent only for objects with this suffix. */
    suffix?: string | null;
}
export declare const BucketsEventNotificationsGetResponseRulesItem: S.Schema<BucketsEventNotificationsGetResponseRulesItem>;
export type BucketsEventNotificationsGetResponseRulesList = Array<BucketsEventNotificationsGetResponseRulesItem>;
export declare const BucketsEventNotificationsGetResponseRulesList: S.Schema<BucketsEventNotificationsGetResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketEventNotificationResponse {
    /** Queue ID. */
    queueId?: string | null;
    /** Name of the queue. */
    queueName?: string | null;
    rules?: BucketsEventNotificationsGetResponseRulesList | null;
}
export declare const GetBucketEventNotificationResponse: S.Schema<GetBucketEventNotificationResponse>;
export type BucketsLifecycleGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsLifecycleGetRequestCfR2Jurisdiction: any;
export interface GetBucketLifecycleRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsLifecycleGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketLifecycleRequest: S.Schema<GetBucketLifecycleRequest>;
export interface BucketsLifecycleGetResponseRulesItemConditions {
    /** Transitions will only apply to objects/uploads in the bucket that start with the given prefix, an empty prefix can be provided to scope rule to all objects/uploads. */
    prefix: string;
}
export declare const BucketsLifecycleGetResponseRulesItemConditions: S.Schema<BucketsLifecycleGetResponseRulesItemConditions>;
export type BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionConditionType = "Age";
export declare const BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionConditionType: any;
export interface BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionCondition {
    maxAge: number;
    type: BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionConditionType;
}
export declare const BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionCondition: S.Schema<BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionCondition>;
export interface BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionCondition | null;
}
export declare const BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransition: S.Schema<BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransition>;
export type BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType = "Age";
export declare const BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType: any;
export interface BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType;
}
export declare const BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition: S.Schema<BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition>;
export type BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType = "Date";
export declare const BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType: any;
export interface BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType;
}
export declare const BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition: S.Schema<BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition>;
export type BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionCondition = BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition | BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition;
export declare const BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionCondition: any;
export interface BucketsLifecycleGetResponseRulesItemDeleteObjectsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionCondition | null;
}
export declare const BucketsLifecycleGetResponseRulesItemDeleteObjectsTransition: S.Schema<BucketsLifecycleGetResponseRulesItemDeleteObjectsTransition>;
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType = "Age";
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType: any;
export interface BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType;
}
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition: S.Schema<BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition>;
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType = "Date";
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType: any;
export interface BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType;
}
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition: S.Schema<BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition>;
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemCondition = BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition | BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition;
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemCondition: any;
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemStorageClass = "InfrequentAccess";
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemStorageClass: any;
export interface BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItem {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemCondition;
    storageClass: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemStorageClass;
}
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItem: S.Schema<BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItem>;
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsList = Array<BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItem>;
export declare const BucketsLifecycleGetResponseRulesItemStorageClassTransitionsList: S.Schema<BucketsLifecycleGetResponseRulesItemStorageClassTransitionsList>;
export interface BucketsLifecycleGetResponseRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Conditions that apply to all transitions of this rule. */
    conditions: BucketsLifecycleGetResponseRulesItemConditions;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Transition to abort ongoing multipart uploads. */
    abortMultipartUploadsTransition?: BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransition | null;
    /** Transition to delete objects. */
    deleteObjectsTransition?: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransition | null;
    /** Transitions to change the storage class of objects. */
    storageClassTransitions?: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsList | null;
}
export declare const BucketsLifecycleGetResponseRulesItem: S.Schema<BucketsLifecycleGetResponseRulesItem>;
export type BucketsLifecycleGetResponseRulesList = Array<BucketsLifecycleGetResponseRulesItem>;
export declare const BucketsLifecycleGetResponseRulesList: S.Schema<BucketsLifecycleGetResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketLifecycleResponse {
    rules?: BucketsLifecycleGetResponseRulesList | null;
}
export declare const GetBucketLifecycleResponse: S.Schema<GetBucketLifecycleResponse>;
export type BucketsLocksGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsLocksGetRequestCfR2Jurisdiction: any;
export interface GetBucketLockRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsLocksGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketLockRequest: S.Schema<GetBucketLockRequest>;
export type BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeConditionType = "Age";
export declare const BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeConditionType: any;
export interface BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeCondition {
    maxAgeSeconds: number;
    type: BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeConditionType;
}
export declare const BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeCondition: S.Schema<BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeCondition>;
export type BucketsLocksGetResponseRulesItemConditionR2LockRuleDateConditionType = "Date";
export declare const BucketsLocksGetResponseRulesItemConditionR2LockRuleDateConditionType: any;
export interface BucketsLocksGetResponseRulesItemConditionR2LockRuleDateCondition {
    date: string;
    type: BucketsLocksGetResponseRulesItemConditionR2LockRuleDateConditionType;
}
export declare const BucketsLocksGetResponseRulesItemConditionR2LockRuleDateCondition: S.Schema<BucketsLocksGetResponseRulesItemConditionR2LockRuleDateCondition>;
export type BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteConditionType = "Indefinite";
export declare const BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteConditionType: any;
export interface BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteCondition {
    type: BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteConditionType;
}
export declare const BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteCondition: S.Schema<BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteCondition>;
export type BucketsLocksGetResponseRulesItemCondition = BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeCondition | BucketsLocksGetResponseRulesItemConditionR2LockRuleDateCondition | BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteCondition;
export declare const BucketsLocksGetResponseRulesItemCondition: any;
export interface BucketsLocksGetResponseRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Condition to apply a lock rule to an object for how long in seconds. */
    condition: BucketsLocksGetResponseRulesItemCondition;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Rule will only apply to objects/uploads in the bucket that start with the given prefix, an empty prefix can be provided to scope rule to all objects/uploads. */
    prefix?: string | null;
}
export declare const BucketsLocksGetResponseRulesItem: S.Schema<BucketsLocksGetResponseRulesItem>;
export type BucketsLocksGetResponseRulesList = Array<BucketsLocksGetResponseRulesItem>;
export declare const BucketsLocksGetResponseRulesList: S.Schema<BucketsLocksGetResponseRulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketLockResponse {
    rules?: BucketsLocksGetResponseRulesList | null;
}
export declare const GetBucketLockResponse: S.Schema<GetBucketLockResponse>;
export type BucketsObjectsGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsObjectsGetRequestCfR2Jurisdiction: any;
export interface GetBucketObjectRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    cfR2Jurisdiction?: BucketsObjectsGetRequestCfR2Jurisdiction | (string & {});
    /** Returns the object only if it has been modified since the specified time. */
    ifModifiedSince?: string;
    /** Returns the object only if its ETag does not match the given value. */
    ifNoneMatch?: string;
    /** The key (name) of the object to retrieve. May contain slashes for path-like keys. */
    objectName: string;
}
export declare const GetBucketObjectRequest: S.Schema<GetBucketObjectRequest>;
export type GetBucketObjectResponseCfR2StorageClass = "Standard" | "InfrequentAccess";
export declare const GetBucketObjectResponseCfR2StorageClass: any;
export interface GetBucketObjectResponse {
    /** Raw object body as an Effect Stream. */
    body: T.BinaryResponseBody;
    /** Entity tag of the object (raw hex digest). */
    etag?: string;
    /** MIME type of the object. */
    contentType?: string;
    /** Object size in bytes. */
    contentLength?: number;
    /** Content encoding of the object (e.g. `gzip`). */
    contentEncoding?: string;
    /** Content disposition header for the object. */
    contentDisposition?: string;
    /** Content language of the object. */
    contentLanguage?: string;
    /** Byte range returned (set when the request used `Range`). */
    contentRange?: string;
    /** Cache-Control directives associated with the object. */
    cacheControl?: string;
    /** Expiration date of the object. */
    expires?: string;
    /** When the object was last modified (RFC 7231 date). */
    lastModified?: string;
    /** Storage class of the object (`Standard` or `InfrequentAccess`). */
    cfR2StorageClass?: GetBucketObjectResponseCfR2StorageClass;
}
export declare const GetBucketObjectResponse: S.Schema<GetBucketObjectResponse>;
export type BucketsSippyGetRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsSippyGetRequestCfR2Jurisdiction: any;
export interface GetBucketSippyRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsSippyGetRequestCfR2Jurisdiction | (string & {});
}
export declare const GetBucketSippyRequest: S.Schema<GetBucketSippyRequest>;
export type BucketsSippyGetResponseDestinationProvider = "r2";
export declare const BucketsSippyGetResponseDestinationProvider: any;
export interface BucketsSippyGetResponseDestination {
    /** ID of the Cloudflare API token used when writing objects to this */
    accessKeyId?: string | null;
    account?: string | null;
    /** Name of the bucket on the provider. */
    bucket?: string | null;
    provider?: BucketsSippyGetResponseDestinationProvider | null;
}
export declare const BucketsSippyGetResponseDestination: S.Schema<BucketsSippyGetResponseDestination>;
export type BucketsSippyGetResponseSourceProvider = "aws" | "gcs" | "s3";
export declare const BucketsSippyGetResponseSourceProvider: any;
export interface BucketsSippyGetResponseSource {
    /** Name of the bucket on the provider (AWS, GCS only). */
    bucket?: string | null;
    /** S3-compatible URL (Generic S3-compatible providers only). */
    bucketUrl?: string | null;
    provider?: BucketsSippyGetResponseSourceProvider | null;
    /** Region where the bucket resides (AWS only). */
    region?: string | null;
}
export declare const BucketsSippyGetResponseSource: S.Schema<BucketsSippyGetResponseSource>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketSippyResponse {
    /** Details about the configured destination bucket. */
    destination?: BucketsSippyGetResponseDestination | null;
    /** State of Sippy for this bucket. */
    enabled?: boolean | null;
    /** Details about the configured source bucket. */
    source?: BucketsSippyGetResponseSource | null;
}
export declare const GetBucketSippyResponse: S.Schema<GetBucketSippyResponse>;
export interface GetSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export declare const GetSuperSlurperJobRequest: S.Schema<GetSuperSlurperJobRequest>;
export type SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaKeysList: S.Schema<SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaKeysList>;
export type SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaVendor = "s3";
export declare const SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaVendor: any;
export interface SuperSlurperJobsGetResponseSourceS3SourceResponseSchema {
    bucket?: string | null;
    endpoint?: string | null;
    keys?: SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaKeysList | null;
    pathPrefix?: string | null;
    vendor?: SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsGetResponseSourceS3SourceResponseSchema: S.Schema<SuperSlurperJobsGetResponseSourceS3SourceResponseSchema>;
export type SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaKeysList: S.Schema<SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaKeysList>;
export type SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaVendor = "gcs";
export declare const SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaVendor: any;
export interface SuperSlurperJobsGetResponseSourceGcsSourceResponseSchema {
    bucket?: string | null;
    keys?: SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaKeysList | null;
    pathPrefix?: string | null;
    vendor?: SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsGetResponseSourceGcsSourceResponseSchema: S.Schema<SuperSlurperJobsGetResponseSourceGcsSourceResponseSchema>;
export type SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaJurisdiction: any;
export type SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaKeysList: S.Schema<SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaKeysList>;
export type SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaVendor = "r2";
export declare const SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaVendor: any;
export interface SuperSlurperJobsGetResponseSourceR2SourceResponseSchema {
    bucket?: string | null;
    jurisdiction?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaJurisdiction | null;
    keys?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaKeysList | null;
    pathPrefix?: string | null;
    vendor?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsGetResponseSourceR2SourceResponseSchema: S.Schema<SuperSlurperJobsGetResponseSourceR2SourceResponseSchema>;
export type SuperSlurperJobsGetResponseSource = SuperSlurperJobsGetResponseSourceS3SourceResponseSchema | SuperSlurperJobsGetResponseSourceGcsSourceResponseSchema | SuperSlurperJobsGetResponseSourceR2SourceResponseSchema;
export declare const SuperSlurperJobsGetResponseSource: any;
export type SuperSlurperJobsGetResponseStatus = "running" | "paused" | "aborted" | "completed";
export declare const SuperSlurperJobsGetResponseStatus: any;
export type SuperSlurperJobsGetResponseTargetJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperJobsGetResponseTargetJurisdiction: any;
export interface SuperSlurperJobsGetResponseTarget {
    bucket?: string | null;
    jurisdiction?: SuperSlurperJobsGetResponseTargetJurisdiction | null;
    vendor?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsGetResponseTarget: S.Schema<SuperSlurperJobsGetResponseTarget>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSuperSlurperJobResponse {
    id?: string | null;
    createdAt?: string | null;
    finishedAt?: string | null;
    overwrite?: boolean | null;
    source?: SuperSlurperJobsGetResponseSource | null;
    status?: SuperSlurperJobsGetResponseStatus | null;
    target?: SuperSlurperJobsGetResponseTarget | null;
}
export declare const GetSuperSlurperJobResponse: S.Schema<GetSuperSlurperJobResponse>;
export type BucketsDomainsCustomListRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsCustomListRequestCfR2Jurisdiction: any;
export interface ListBucketDomainCustomsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsCustomListRequestCfR2Jurisdiction | (string & {});
}
export declare const ListBucketDomainCustomsRequest: S.Schema<ListBucketDomainCustomsRequest>;
export type BucketsDomainsCustomListResponseDomainsItemStatusOwnership = "pending" | "active" | "deactivated" | "blocked" | "error" | "unknown";
export declare const BucketsDomainsCustomListResponseDomainsItemStatusOwnership: any;
export type BucketsDomainsCustomListResponseDomainsItemStatusSsl = "initializing" | "pending" | "active" | "deactivated" | "error" | "unknown";
export declare const BucketsDomainsCustomListResponseDomainsItemStatusSsl: any;
export interface BucketsDomainsCustomListResponseDomainsItemStatus {
    /** Ownership status of the domain. */
    ownership: BucketsDomainsCustomListResponseDomainsItemStatusOwnership;
    /** SSL certificate status. */
    ssl: BucketsDomainsCustomListResponseDomainsItemStatusSsl;
}
export declare const BucketsDomainsCustomListResponseDomainsItemStatus: S.Schema<BucketsDomainsCustomListResponseDomainsItemStatus>;
export type BucketsDomainsCustomListResponseDomainsItemCiphersList = Array<string>;
export declare const BucketsDomainsCustomListResponseDomainsItemCiphersList: S.Schema<BucketsDomainsCustomListResponseDomainsItemCiphersList>;
export type BucketsDomainsCustomListResponseDomainsItemMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export declare const BucketsDomainsCustomListResponseDomainsItemMinTLS: any;
export interface BucketsDomainsCustomListResponseDomainsItem {
    /** Domain name of the custom domain to be added. */
    domain: string;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled: boolean;
    status: BucketsDomainsCustomListResponseDomainsItemStatus;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomListResponseDomainsItemCiphersList | null;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomListResponseDomainsItemMinTLS | null;
    /** Zone ID of the custom domain resides in. */
    zoneId?: string | null;
    /** Zone that the custom domain resides in. */
    zoneName?: string | null;
}
export declare const BucketsDomainsCustomListResponseDomainsItem: S.Schema<BucketsDomainsCustomListResponseDomainsItem>;
export type BucketsDomainsCustomListResponseDomainsList = Array<BucketsDomainsCustomListResponseDomainsItem>;
export declare const BucketsDomainsCustomListResponseDomainsList: S.Schema<BucketsDomainsCustomListResponseDomainsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketDomainCustomsResponse {
    domains: BucketsDomainsCustomListResponseDomainsList;
}
export declare const ListBucketDomainCustomsResponse: S.Schema<ListBucketDomainCustomsResponse>;
export type BucketsDomainsManagedListRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsManagedListRequestCfR2Jurisdiction: any;
export interface ListBucketDomainManagedsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsManagedListRequestCfR2Jurisdiction | (string & {});
}
export declare const ListBucketDomainManagedsRequest: S.Schema<ListBucketDomainManagedsRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketDomainManagedsResponse {
    /** Bucket ID. */
    bucketId: string;
    /** Domain name of the bucket's r2.dev domain. */
    domain: string;
    /** Whether this bucket is publicly accessible at the r2.dev domain. */
    enabled: boolean;
}
export declare const ListBucketDomainManagedsResponse: S.Schema<ListBucketDomainManagedsResponse>;
export type BucketsEventNotificationsListRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsEventNotificationsListRequestCfR2Jurisdiction: any;
export interface ListBucketEventNotificationsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsEventNotificationsListRequestCfR2Jurisdiction | (string & {});
}
export declare const ListBucketEventNotificationsRequest: S.Schema<ListBucketEventNotificationsRequest>;
export type BucketsEventNotificationsListResponseQueuesItemRulesItemActionsItem = "PutObject" | "CopyObject" | "DeleteObject" | "CompleteMultipartUpload" | "LifecycleDeletion";
export declare const BucketsEventNotificationsListResponseQueuesItemRulesItemActionsItem: any;
export type BucketsEventNotificationsListResponseQueuesItemRulesItemActionsList = Array<BucketsEventNotificationsListResponseQueuesItemRulesItemActionsItem>;
export declare const BucketsEventNotificationsListResponseQueuesItemRulesItemActionsList: S.Schema<BucketsEventNotificationsListResponseQueuesItemRulesItemActionsList>;
export interface BucketsEventNotificationsListResponseQueuesItemRulesItem {
    /** Array of R2 object actions that will trigger notifications. */
    actions: BucketsEventNotificationsListResponseQueuesItemRulesItemActionsList;
    /** Timestamp when the rule was created. */
    createdAt?: string | null;
    /** A description that can be used to identify the event notification rule after creation. */
    description?: string | null;
    /** Notifications will be sent only for objects with this prefix. */
    prefix?: string | null;
    /** Rule ID. */
    ruleId?: string | null;
    /** Notifications will be sent only for objects with this suffix. */
    suffix?: string | null;
}
export declare const BucketsEventNotificationsListResponseQueuesItemRulesItem: S.Schema<BucketsEventNotificationsListResponseQueuesItemRulesItem>;
export type BucketsEventNotificationsListResponseQueuesItemRulesList = Array<BucketsEventNotificationsListResponseQueuesItemRulesItem>;
export declare const BucketsEventNotificationsListResponseQueuesItemRulesList: S.Schema<BucketsEventNotificationsListResponseQueuesItemRulesList>;
export interface BucketsEventNotificationsListResponseQueuesItem {
    /** Queue ID. */
    queueId?: string | null;
    /** Name of the queue. */
    queueName?: string | null;
    rules?: BucketsEventNotificationsListResponseQueuesItemRulesList | null;
}
export declare const BucketsEventNotificationsListResponseQueuesItem: S.Schema<BucketsEventNotificationsListResponseQueuesItem>;
export type BucketsEventNotificationsListResponseQueuesList = Array<BucketsEventNotificationsListResponseQueuesItem>;
export declare const BucketsEventNotificationsListResponseQueuesList: S.Schema<BucketsEventNotificationsListResponseQueuesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketEventNotificationsResponse {
    /** Name of the bucket. */
    bucketName?: string | null;
    /** List of queues associated with the bucket. */
    queues?: BucketsEventNotificationsListResponseQueuesList | null;
}
export declare const ListBucketEventNotificationsResponse: S.Schema<ListBucketEventNotificationsResponse>;
export interface ListBucketMetricsRequest {
    /** Account ID. */
    accountId: string;
}
export declare const ListBucketMetricsRequest: S.Schema<ListBucketMetricsRequest>;
export interface BucketsMetricsListResponseInfrequentAccessPublished {
    /** Amount of. */
    metadataSize?: number | null;
    /** Number of objects stored. */
    objects?: number | null;
    /** Amount of storage used by object data. */
    payloadSize?: number | null;
}
export declare const BucketsMetricsListResponseInfrequentAccessPublished: S.Schema<BucketsMetricsListResponseInfrequentAccessPublished>;
export type BucketsMetricsListResponseInfrequentAccessUploaded = BucketsMetricsListResponseInfrequentAccessPublished;
export declare const BucketsMetricsListResponseInfrequentAccessUploaded: S.Schema<BucketsMetricsListResponseInfrequentAccessPublished>;
export interface BucketsMetricsListResponseInfrequentAccess {
    /** Metrics on number of objects/amount of storage used. */
    published?: BucketsMetricsListResponseInfrequentAccessPublished | null;
    /** Metrics on number of objects/amount of storage used. */
    uploaded?: BucketsMetricsListResponseInfrequentAccessPublished | null;
}
export declare const BucketsMetricsListResponseInfrequentAccess: S.Schema<BucketsMetricsListResponseInfrequentAccess>;
export type BucketsMetricsListResponseStandardPublished = BucketsMetricsListResponseInfrequentAccessPublished;
export declare const BucketsMetricsListResponseStandardPublished: S.Schema<BucketsMetricsListResponseInfrequentAccessPublished>;
export type BucketsMetricsListResponseStandardUploaded = BucketsMetricsListResponseInfrequentAccessPublished;
export declare const BucketsMetricsListResponseStandardUploaded: S.Schema<BucketsMetricsListResponseInfrequentAccessPublished>;
export type BucketsMetricsListResponseStandard = BucketsMetricsListResponseInfrequentAccess;
export declare const BucketsMetricsListResponseStandard: S.Schema<BucketsMetricsListResponseInfrequentAccess>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketMetricsResponse {
    /** Metrics based on what state they are in(uploaded or published). */
    infrequentAccess?: BucketsMetricsListResponseInfrequentAccess | null;
    /** Metrics based on what state they are in(uploaded or published). */
    standard?: BucketsMetricsListResponseInfrequentAccess | null;
}
export declare const ListBucketMetricsResponse: S.Schema<ListBucketMetricsResponse>;
export type BucketsObjectsListRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsObjectsListRequestCfR2Jurisdiction: any;
export interface ListBucketObjectsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Pagination cursor received from a previous List Objects call. Used to retrieve the next page of results. */
    cursor?: string;
    /** A single character used to group keys. All keys that contain the delimiter between the prefix and the first occurrence of the delimiter after the prefix are grouped under a single result element. */
    delimiter?: string;
    /** Maximum number of objects to return per page. */
    perPage?: number;
    /** Restricts results to only those objects whose keys begin with the specified prefix. */
    prefix?: string;
    /** Returns objects with keys that come after the specified key in lexicographic order. */
    startAfter?: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    cfR2Jurisdiction?: BucketsObjectsListRequestCfR2Jurisdiction | (string & {});
}
export declare const ListBucketObjectsRequest: S.Schema<ListBucketObjectsRequest>;
export type BucketsObjectsListResultItemCustomMetadataMap = {
    [key: string]: string | undefined;
};
export declare const BucketsObjectsListResultItemCustomMetadataMap: S.Schema<BucketsObjectsListResultItemCustomMetadataMap>;
export interface BucketsObjectsListResultItemHttpMetadata {
    /** Specifies caching behavior for the object. */
    cacheControl?: string | null;
    /** The date and time at which the object's cache entry expires. */
    cacheExpiry?: string | null;
    /** Specifies presentational information for the object. */
    contentDisposition?: string | null;
    /** Specifies the content encoding applied to the object. */
    contentEncoding?: string | null;
    /** The language of the object content. */
    contentLanguage?: string | null;
    /** The MIME type of the object. */
    contentType?: string | null;
}
export declare const BucketsObjectsListResultItemHttpMetadata: S.Schema<BucketsObjectsListResultItemHttpMetadata>;
export type BucketsObjectsListResultItemStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsObjectsListResultItemStorageClass: any;
export interface BucketsObjectsListResultItem {
    /** Custom metadata key-value pairs associated with the object. */
    customMetadata?: BucketsObjectsListResultItemCustomMetadataMap | null;
    /** The entity tag for the object. In JSON list/get responses this is the raw */
    etag?: string | null;
    /** HTTP metadata associated with an R2 object. */
    httpMetadata?: BucketsObjectsListResultItemHttpMetadata | null;
    /** The object key (name). */
    key?: string | null;
    /** The date and time the object was last modified. */
    lastModified?: string | null;
    /** The size of the object in bytes. */
    size?: number | null;
    /** Whether the object is encrypted with a customer-supplied encryption key. */
    ssec?: boolean | null;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsObjectsListResultItemStorageClass | null;
}
export declare const BucketsObjectsListResultItem: S.Schema<BucketsObjectsListResultItem>;
export type BucketsObjectsListResultList = Array<BucketsObjectsListResultItem>;
export declare const BucketsObjectsListResultList: S.Schema<BucketsObjectsListResultList>;
export interface ListBucketObjectsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BucketsObjectsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListBucketObjectsResponse: S.Schema<ListBucketObjectsResponse>;
export type BucketsListRequestDirection = "asc" | "desc";
export declare const BucketsListRequestDirection: any;
export type BucketsListRequestOrder = "name";
export declare const BucketsListRequestOrder: any;
export type BucketsListRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsListRequestCfR2Jurisdiction: any;
export interface ListBucketsRequest {
    /** Account ID. */
    accountId: string;
    /** Pagination cursor received during the last List Buckets call. R2 buckets are paginated using cursors instead of page numbers. */
    cursor?: string;
    /** Direction to order buckets. */
    direction?: BucketsListRequestDirection | (string & {});
    /** Bucket names to filter by. Only buckets with this phrase in their name will be returned. */
    nameContains?: string;
    /** Field to order buckets by. */
    order?: BucketsListRequestOrder | (string & {});
    /** Maximum number of buckets to return in a single call. */
    perPage?: number;
    /** Bucket name to start searching after. Buckets are ordered lexicographically. */
    startAfter?: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsListRequestCfR2Jurisdiction | (string & {});
}
export declare const ListBucketsRequest: S.Schema<ListBucketsRequest>;
export type BucketsListResponseBucketsItemJurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsListResponseBucketsItemJurisdiction: any;
export type BucketsListResponseBucketsItemLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export declare const BucketsListResponseBucketsItemLocation: any;
export type BucketsListResponseBucketsItemStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsListResponseBucketsItemStorageClass: any;
export interface BucketsListResponseBucketsItem {
    /** Creation timestamp. */
    creationDate?: string | null;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsListResponseBucketsItemJurisdiction | null;
    /** Location of the bucket. */
    location?: BucketsListResponseBucketsItemLocation | null;
    /** Name of the bucket. */
    name?: string | null;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsListResponseBucketsItemStorageClass | null;
}
export declare const BucketsListResponseBucketsItem: S.Schema<BucketsListResponseBucketsItem>;
export type BucketsListResponseBucketsList = Array<BucketsListResponseBucketsItem>;
export declare const BucketsListResponseBucketsList: S.Schema<BucketsListResponseBucketsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketsResponse {
    buckets?: BucketsListResponseBucketsList | null;
}
export declare const ListBucketsResponse: S.Schema<ListBucketsResponse>;
export interface ListSuperSlurperJobLogsRequest {
    accountId: string;
    jobId: string;
    limit?: number;
    offset?: number;
}
export declare const ListSuperSlurperJobLogsRequest: S.Schema<ListSuperSlurperJobLogsRequest>;
export type SuperSlurperJobsLogsListResultItemLogType = "migrationStart" | "migrationComplete" | "migrationAbort" | "migrationError" | "migrationPause" | "migrationResume" | "migrationErrorFailedContinuation" | "importErrorRetryExhaustion" | "importSkippedStorageClass" | "importSkippedOversized" | "importSkippedEmptyObject" | "importSkippedUnsupportedContentType" | "importSkippedExcludedContentType" | "importSkippedInvalidMedia" | "importSkippedRequiresRetrieval";
export declare const SuperSlurperJobsLogsListResultItemLogType: any;
export interface SuperSlurperJobsLogsListResultItem {
    createdAt?: string | null;
    job?: string | null;
    logType?: SuperSlurperJobsLogsListResultItemLogType | null;
    message?: string | null;
    objectKey?: string | null;
}
export declare const SuperSlurperJobsLogsListResultItem: S.Schema<SuperSlurperJobsLogsListResultItem>;
export type SuperSlurperJobsLogsListResultList = Array<SuperSlurperJobsLogsListResultItem>;
export declare const SuperSlurperJobsLogsListResultList: S.Schema<SuperSlurperJobsLogsListResultList>;
export interface ListSuperSlurperJobLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SuperSlurperJobsLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSuperSlurperJobLogsResponse: S.Schema<ListSuperSlurperJobLogsResponse>;
export interface ListSuperSlurperJobsRequest {
    accountId: string;
    limit?: number;
    offset?: number;
}
export declare const ListSuperSlurperJobsRequest: S.Schema<ListSuperSlurperJobsRequest>;
export type SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaKeysList: S.Schema<SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaKeysList>;
export type SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaVendor = "s3";
export declare const SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaVendor: any;
export interface SuperSlurperJobsListResultItemSourceS3SourceResponseSchema {
    bucket?: string | null;
    endpoint?: string | null;
    keys?: SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaKeysList | null;
    pathPrefix?: string | null;
    vendor?: SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsListResultItemSourceS3SourceResponseSchema: S.Schema<SuperSlurperJobsListResultItemSourceS3SourceResponseSchema>;
export type SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaKeysList: S.Schema<SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaKeysList>;
export type SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaVendor = "gcs";
export declare const SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaVendor: any;
export interface SuperSlurperJobsListResultItemSourceGcsSourceResponseSchema {
    bucket?: string | null;
    keys?: SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaKeysList | null;
    pathPrefix?: string | null;
    vendor?: SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsListResultItemSourceGcsSourceResponseSchema: S.Schema<SuperSlurperJobsListResultItemSourceGcsSourceResponseSchema>;
export type SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaJurisdiction: any;
export type SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaKeysList = Array<string>;
export declare const SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaKeysList: S.Schema<SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaKeysList>;
export type SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaVendor = "r2";
export declare const SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaVendor: any;
export interface SuperSlurperJobsListResultItemSourceR2SourceResponseSchema {
    bucket?: string | null;
    jurisdiction?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaJurisdiction | null;
    keys?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaKeysList | null;
    pathPrefix?: string | null;
    vendor?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsListResultItemSourceR2SourceResponseSchema: S.Schema<SuperSlurperJobsListResultItemSourceR2SourceResponseSchema>;
export type SuperSlurperJobsListResultItemSource = SuperSlurperJobsListResultItemSourceS3SourceResponseSchema | SuperSlurperJobsListResultItemSourceGcsSourceResponseSchema | SuperSlurperJobsListResultItemSourceR2SourceResponseSchema;
export declare const SuperSlurperJobsListResultItemSource: any;
export type SuperSlurperJobsListResultItemStatus = "running" | "paused" | "aborted" | "completed";
export declare const SuperSlurperJobsListResultItemStatus: any;
export type SuperSlurperJobsListResultItemTargetJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperJobsListResultItemTargetJurisdiction: any;
export interface SuperSlurperJobsListResultItemTarget {
    bucket?: string | null;
    jurisdiction?: SuperSlurperJobsListResultItemTargetJurisdiction | null;
    vendor?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaVendor | null;
}
export declare const SuperSlurperJobsListResultItemTarget: S.Schema<SuperSlurperJobsListResultItemTarget>;
export interface SuperSlurperJobsListResultItem {
    id?: string | null;
    createdAt?: string | null;
    finishedAt?: string | null;
    overwrite?: boolean | null;
    source?: SuperSlurperJobsListResultItemSource | null;
    status?: SuperSlurperJobsListResultItemStatus | null;
    target?: SuperSlurperJobsListResultItemTarget | null;
}
export declare const SuperSlurperJobsListResultItem: S.Schema<SuperSlurperJobsListResultItem>;
export type SuperSlurperJobsListResultList = Array<SuperSlurperJobsListResultItem>;
export declare const SuperSlurperJobsListResultList: S.Schema<SuperSlurperJobsListResultList>;
export interface ListSuperSlurperJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SuperSlurperJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSuperSlurperJobsResponse: S.Schema<ListSuperSlurperJobsResponse>;
export type BucketsEditRequestCfR2StorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsEditRequestCfR2StorageClass: any;
export type BucketsEditRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsEditRequestCfR2Jurisdiction: any;
export interface PatchBucketRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass: BucketsEditRequestCfR2StorageClass | (string & {});
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsEditRequestCfR2Jurisdiction | (string & {});
}
export declare const PatchBucketRequest: S.Schema<PatchBucketRequest>;
export type BucketsEditResponseJurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsEditResponseJurisdiction: any;
export type BucketsEditResponseLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export declare const BucketsEditResponseLocation: any;
export type BucketsEditResponseStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsEditResponseStorageClass: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchBucketResponse {
    /** Creation timestamp. */
    creationDate?: string | null;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsEditResponseJurisdiction | null;
    /** Location of the bucket. */
    location?: BucketsEditResponseLocation | null;
    /** Name of the bucket. */
    name?: string | null;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsEditResponseStorageClass | null;
}
export declare const PatchBucketResponse: S.Schema<PatchBucketResponse>;
export interface PauseSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export declare const PauseSuperSlurperJobRequest: S.Schema<PauseSuperSlurperJobRequest>;
export type PauseSuperSlurperJobResponse = string;
export declare const PauseSuperSlurperJobResponse: S.Schema<PauseSuperSlurperJobResponse>;
export interface ProgressSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export declare const ProgressSuperSlurperJobRequest: S.Schema<ProgressSuperSlurperJobRequest>;
export type SuperSlurperJobsProgressResponseStatus = "running" | "paused" | "aborted" | "completed";
export declare const SuperSlurperJobsProgressResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ProgressSuperSlurperJobResponse {
    id?: string | null;
    createdAt?: string | null;
    failedObjects?: number | null;
    objects?: number | null;
    skippedObjects?: number | null;
    status?: SuperSlurperJobsProgressResponseStatus | null;
    transferredObjects?: number | null;
}
export declare const ProgressSuperSlurperJobResponse: S.Schema<ProgressSuperSlurperJobResponse>;
export type BucketsCorsUpdateRequestRulesItemAllowedMethodsItem = "GET" | "PUT" | "POST" | "DELETE" | "HEAD";
export declare const BucketsCorsUpdateRequestRulesItemAllowedMethodsItem: any;
export type BucketsCorsUpdateRequestRulesItemAllowedMethodsList = Array<BucketsCorsUpdateRequestRulesItemAllowedMethodsItem | (string & {})>;
export declare const BucketsCorsUpdateRequestRulesItemAllowedMethodsList: S.Schema<BucketsCorsUpdateRequestRulesItemAllowedMethodsList>;
export type BucketsCorsUpdateRequestRulesItemAllowedOriginsList = Array<string>;
export declare const BucketsCorsUpdateRequestRulesItemAllowedOriginsList: S.Schema<BucketsCorsUpdateRequestRulesItemAllowedOriginsList>;
export type BucketsCorsUpdateRequestRulesItemAllowedHeadersList = Array<string>;
export declare const BucketsCorsUpdateRequestRulesItemAllowedHeadersList: S.Schema<BucketsCorsUpdateRequestRulesItemAllowedHeadersList>;
export interface BucketsCorsUpdateRequestRulesItemAllowed {
    /** Specifies the value for the Access-Control-Allow-Methods header R2 sets when requesting objects in a bucket from a browser. */
    methods: BucketsCorsUpdateRequestRulesItemAllowedMethodsList;
    /** Specifies the value for the Access-Control-Allow-Origin header R2 sets when requesting objects in a bucket from a browser. */
    origins: BucketsCorsUpdateRequestRulesItemAllowedOriginsList;
    /** Specifies the value for the Access-Control-Allow-Headers header R2 sets when requesting objects in this bucket from a browser. Cross-origin requests that include custom headers (e.g. x-user-id) should specify these headers as AllowedHeaders. */
    headers?: BucketsCorsUpdateRequestRulesItemAllowedHeadersList;
}
export declare const BucketsCorsUpdateRequestRulesItemAllowed: S.Schema<BucketsCorsUpdateRequestRulesItemAllowed>;
export type BucketsCorsUpdateRequestRulesItemExposeHeadersList = Array<string>;
export declare const BucketsCorsUpdateRequestRulesItemExposeHeadersList: S.Schema<BucketsCorsUpdateRequestRulesItemExposeHeadersList>;
export interface BucketsCorsUpdateRequestRulesItem {
    /** Object specifying allowed origins, methods and headers for this CORS rule. */
    allowed: BucketsCorsUpdateRequestRulesItemAllowed;
    /** Identifier for this rule. */
    id?: string;
    /** Specifies the headers that can be exposed back, and accessed by, the JavaScript making the cross-origin request. If you need to access headers beyond the safelisted response headers, such as Content-Encoding or cf-cache-status, you must specify it here. */
    exposeHeaders?: BucketsCorsUpdateRequestRulesItemExposeHeadersList;
    /** Specifies the amount of time (in seconds) browsers are allowed to cache CORS preflight responses. Browsers may limit this to 2 hours or less, even if the maximum value (86400) is specified. */
    maxAgeSeconds?: number;
}
export declare const BucketsCorsUpdateRequestRulesItem: S.Schema<BucketsCorsUpdateRequestRulesItem>;
export type BucketsCorsUpdateRequestRulesList = Array<BucketsCorsUpdateRequestRulesItem>;
export declare const BucketsCorsUpdateRequestRulesList: S.Schema<BucketsCorsUpdateRequestRulesList>;
export type BucketsCorsUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsCorsUpdateRequestCfR2Jurisdiction: any;
export interface PutBucketCorsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    rules?: BucketsCorsUpdateRequestRulesList;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsCorsUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const PutBucketCorsRequest: S.Schema<PutBucketCorsRequest>;
export type PutBucketCorsResponse = unknown;
export declare const PutBucketCorsResponse: S.Schema<PutBucketCorsResponse>;
export type BucketsDomainsManagedUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsManagedUpdateRequestCfR2Jurisdiction: any;
export interface PutBucketDomainManagedRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Whether to enable public bucket access at the r2.dev domain. */
    enabled: boolean;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsManagedUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const PutBucketDomainManagedRequest: S.Schema<PutBucketDomainManagedRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutBucketDomainManagedResponse {
    /** Bucket ID. */
    bucketId: string;
    /** Domain name of the bucket's r2.dev domain. */
    domain: string;
    /** Whether this bucket is publicly accessible at the r2.dev domain. */
    enabled: boolean;
}
export declare const PutBucketDomainManagedResponse: S.Schema<PutBucketDomainManagedResponse>;
export type BucketsEventNotificationsUpdateRequestRulesItemActionsItem = "PutObject" | "CopyObject" | "DeleteObject" | "CompleteMultipartUpload" | "LifecycleDeletion";
export declare const BucketsEventNotificationsUpdateRequestRulesItemActionsItem: any;
export type BucketsEventNotificationsUpdateRequestRulesItemActionsList = Array<BucketsEventNotificationsUpdateRequestRulesItemActionsItem | (string & {})>;
export declare const BucketsEventNotificationsUpdateRequestRulesItemActionsList: S.Schema<BucketsEventNotificationsUpdateRequestRulesItemActionsList>;
export interface BucketsEventNotificationsUpdateRequestRulesItem {
    /** Array of R2 object actions that will trigger notifications. */
    actions: BucketsEventNotificationsUpdateRequestRulesItemActionsList;
    /** A description that can be used to identify the event notification rule after creation. */
    description?: string;
    /** Notifications will be sent only for objects with this prefix. */
    prefix?: string;
    /** Notifications will be sent only for objects with this suffix. */
    suffix?: string;
}
export declare const BucketsEventNotificationsUpdateRequestRulesItem: S.Schema<BucketsEventNotificationsUpdateRequestRulesItem>;
export type BucketsEventNotificationsUpdateRequestRulesList = Array<BucketsEventNotificationsUpdateRequestRulesItem>;
export declare const BucketsEventNotificationsUpdateRequestRulesList: S.Schema<BucketsEventNotificationsUpdateRequestRulesList>;
export type BucketsEventNotificationsUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsEventNotificationsUpdateRequestCfR2Jurisdiction: any;
export interface PutBucketEventNotificationRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Queue ID. */
    queueId: string;
    /** Array of rules to drive notifications. */
    rules: BucketsEventNotificationsUpdateRequestRulesList;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsEventNotificationsUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const PutBucketEventNotificationRequest: S.Schema<PutBucketEventNotificationRequest>;
export type PutBucketEventNotificationResponse = unknown;
export declare const PutBucketEventNotificationResponse: S.Schema<PutBucketEventNotificationResponse>;
export type BucketsLifecycleUpdateRequestRulesItemConditions = BucketsLifecycleGetResponseRulesItemConditions;
export declare const BucketsLifecycleUpdateRequestRulesItemConditions: S.Schema<BucketsLifecycleGetResponseRulesItemConditions>;
export type BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionConditionType = "Age";
export declare const BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionConditionType: any;
export interface BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionCondition {
    maxAge: number;
    type: BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionConditionType | (string & {});
}
export declare const BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionCondition: S.Schema<BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionCondition>;
export interface BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionCondition;
}
export declare const BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransition: S.Schema<BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransition>;
export type BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType = "Age";
export declare const BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType: any;
export interface BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType;
}
export declare const BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition: S.Schema<BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition>;
export type BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType = "Date";
export declare const BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType: any;
export interface BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType;
}
export declare const BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition: S.Schema<BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition>;
export type BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionCondition = BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition | BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition;
export declare const BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionCondition: any;
export interface BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionCondition;
}
export declare const BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransition: S.Schema<BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransition>;
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType = "Age";
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType: any;
export interface BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType;
}
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition: S.Schema<BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition>;
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType = "Date";
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType: any;
export interface BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType;
}
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition: S.Schema<BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition>;
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemCondition = BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition | BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition;
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemCondition: any;
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemStorageClass = "InfrequentAccess";
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemStorageClass: any;
export interface BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItem {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemCondition;
    storageClass: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemStorageClass | (string & {});
}
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItem: S.Schema<BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItem>;
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsList = Array<BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItem>;
export declare const BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsList: S.Schema<BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsList>;
export interface BucketsLifecycleUpdateRequestRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Conditions that apply to all transitions of this rule. */
    conditions: BucketsLifecycleGetResponseRulesItemConditions;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Transition to abort ongoing multipart uploads. */
    abortMultipartUploadsTransition?: BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransition;
    /** Transition to delete objects. */
    deleteObjectsTransition?: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransition;
    /** Transitions to change the storage class of objects. */
    storageClassTransitions?: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsList;
}
export declare const BucketsLifecycleUpdateRequestRulesItem: S.Schema<BucketsLifecycleUpdateRequestRulesItem>;
export type BucketsLifecycleUpdateRequestRulesList = Array<BucketsLifecycleUpdateRequestRulesItem>;
export declare const BucketsLifecycleUpdateRequestRulesList: S.Schema<BucketsLifecycleUpdateRequestRulesList>;
export type BucketsLifecycleUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsLifecycleUpdateRequestCfR2Jurisdiction: any;
export interface PutBucketLifecycleRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    rules?: BucketsLifecycleUpdateRequestRulesList;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsLifecycleUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const PutBucketLifecycleRequest: S.Schema<PutBucketLifecycleRequest>;
export type PutBucketLifecycleResponse = unknown;
export declare const PutBucketLifecycleResponse: S.Schema<PutBucketLifecycleResponse>;
export type BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeConditionType = "Age";
export declare const BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeConditionType: any;
export interface BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeCondition {
    maxAgeSeconds: number;
    type: BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeConditionType;
}
export declare const BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeCondition: S.Schema<BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeCondition>;
export type BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateConditionType = "Date";
export declare const BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateConditionType: any;
export interface BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateCondition {
    date: string;
    type: BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateConditionType;
}
export declare const BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateCondition: S.Schema<BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateCondition>;
export type BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteConditionType = "Indefinite";
export declare const BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteConditionType: any;
export interface BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteCondition {
    type: BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteConditionType;
}
export declare const BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteCondition: S.Schema<BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteCondition>;
export type BucketsLocksUpdateRequestRulesItemCondition = BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeCondition | BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateCondition | BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteCondition;
export declare const BucketsLocksUpdateRequestRulesItemCondition: any;
export interface BucketsLocksUpdateRequestRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Condition to apply a lock rule to an object for how long in seconds. */
    condition: BucketsLocksUpdateRequestRulesItemCondition;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Rule will only apply to objects/uploads in the bucket that start with the given prefix, an empty prefix can be provided to scope rule to all objects/uploads. */
    prefix?: string;
}
export declare const BucketsLocksUpdateRequestRulesItem: S.Schema<BucketsLocksUpdateRequestRulesItem>;
export type BucketsLocksUpdateRequestRulesList = Array<BucketsLocksUpdateRequestRulesItem>;
export declare const BucketsLocksUpdateRequestRulesList: S.Schema<BucketsLocksUpdateRequestRulesList>;
export type BucketsLocksUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsLocksUpdateRequestCfR2Jurisdiction: any;
export interface PutBucketLockRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    rules?: BucketsLocksUpdateRequestRulesList;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsLocksUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const PutBucketLockRequest: S.Schema<PutBucketLockRequest>;
export type PutBucketLockResponse = unknown;
export declare const PutBucketLockResponse: S.Schema<PutBucketLockResponse>;
export type BucketsSippyUpdateRequestDestinationR2EnableSippyAwsProvider = "r2";
export declare const BucketsSippyUpdateRequestDestinationR2EnableSippyAwsProvider: any;
export interface BucketsSippyUpdateRequestDestinationR2EnableSippyAws {
    /** ID of a Cloudflare API token. */
    accessKeyId?: string;
    provider?: BucketsSippyUpdateRequestDestinationR2EnableSippyAwsProvider | (string & {});
    /** Value of a Cloudflare API token. */
    secretAccessKey?: string;
}
export declare const BucketsSippyUpdateRequestDestinationR2EnableSippyAws: S.Schema<BucketsSippyUpdateRequestDestinationR2EnableSippyAws>;
export type BucketsSippyUpdateRequestDestinationR2EnableSippyGcs = BucketsSippyUpdateRequestDestinationR2EnableSippyAws;
export declare const BucketsSippyUpdateRequestDestinationR2EnableSippyGcs: S.Schema<BucketsSippyUpdateRequestDestinationR2EnableSippyAws>;
export type BucketsSippyUpdateRequestDestination = BucketsSippyUpdateRequestDestinationR2EnableSippyAws | BucketsSippyUpdateRequestDestinationR2EnableSippyAws;
export declare const BucketsSippyUpdateRequestDestination: any;
export type BucketsSippyUpdateRequestSourceR2EnableSippyAwsProvider = "aws";
export declare const BucketsSippyUpdateRequestSourceR2EnableSippyAwsProvider: any;
export interface BucketsSippyUpdateRequestSourceR2EnableSippyAws {
    /** Access Key ID of an IAM credential (ideally scoped to a single S3 bucket). */
    accessKeyId?: string;
    /** Name of the AWS S3 bucket. */
    bucket?: string;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyAwsProvider | (string & {});
    /** Name of the AWS availability zone. */
    region?: string;
    /** Secret Access Key of an IAM credential (ideally scoped to a single S3 bucket). */
    secretAccessKey?: string;
}
export declare const BucketsSippyUpdateRequestSourceR2EnableSippyAws: S.Schema<BucketsSippyUpdateRequestSourceR2EnableSippyAws>;
export type BucketsSippyUpdateRequestSourceR2EnableSippyGcsProvider = "gcs";
export declare const BucketsSippyUpdateRequestSourceR2EnableSippyGcsProvider: any;
export interface BucketsSippyUpdateRequestSourceR2EnableSippyGcs {
    /** Name of the GCS bucket. */
    bucket?: string;
    /** Client email of an IAM credential (ideally scoped to a single GCS bucket). */
    clientEmail?: string;
    /** Private Key of an IAM credential (ideally scoped to a single GCS bucket). */
    privateKey?: string;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyGcsProvider | (string & {});
}
export declare const BucketsSippyUpdateRequestSourceR2EnableSippyGcs: S.Schema<BucketsSippyUpdateRequestSourceR2EnableSippyGcs>;
export type BucketsSippyUpdateRequestSourceR2EnableSippyS3Provider = "s3";
export declare const BucketsSippyUpdateRequestSourceR2EnableSippyS3Provider: any;
export interface BucketsSippyUpdateRequestSourceR2EnableSippyS3 {
    /** Access Key ID of an IAM credential (ideally scoped to a single S3 bucket). */
    accessKeyId?: string;
    /** URL to the S3-compatible API of the bucket. */
    bucketUrl?: string;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyS3Provider | (string & {});
    /** Secret Access Key of an IAM credential (ideally scoped to a single S3 bucket). */
    secretAccessKey?: string;
}
export declare const BucketsSippyUpdateRequestSourceR2EnableSippyS3: S.Schema<BucketsSippyUpdateRequestSourceR2EnableSippyS3>;
export type BucketsSippyUpdateRequestSource = BucketsSippyUpdateRequestSourceR2EnableSippyAws | BucketsSippyUpdateRequestSourceR2EnableSippyGcs | BucketsSippyUpdateRequestSourceR2EnableSippyS3;
export declare const BucketsSippyUpdateRequestSource: any;
export type BucketsSippyUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsSippyUpdateRequestCfR2Jurisdiction: any;
export interface PutBucketSippyRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** R2 bucket to copy objects to. */
    destination?: BucketsSippyUpdateRequestDestination;
    /** AWS S3 bucket to copy objects from. */
    source?: BucketsSippyUpdateRequestSource;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsSippyUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const PutBucketSippyRequest: S.Schema<PutBucketSippyRequest>;
export type BucketsSippyUpdateResponseDestinationProvider = "r2";
export declare const BucketsSippyUpdateResponseDestinationProvider: any;
export interface BucketsSippyUpdateResponseDestination {
    /** ID of the Cloudflare API token used when writing objects to this */
    accessKeyId?: string | null;
    account?: string | null;
    /** Name of the bucket on the provider. */
    bucket?: string | null;
    provider?: BucketsSippyUpdateResponseDestinationProvider | null;
}
export declare const BucketsSippyUpdateResponseDestination: S.Schema<BucketsSippyUpdateResponseDestination>;
export type BucketsSippyUpdateResponseSourceProvider = "aws" | "gcs" | "s3";
export declare const BucketsSippyUpdateResponseSourceProvider: any;
export interface BucketsSippyUpdateResponseSource {
    /** Name of the bucket on the provider (AWS, GCS only). */
    bucket?: string | null;
    /** S3-compatible URL (Generic S3-compatible providers only). */
    bucketUrl?: string | null;
    provider?: BucketsSippyUpdateResponseSourceProvider | null;
    /** Region where the bucket resides (AWS only). */
    region?: string | null;
}
export declare const BucketsSippyUpdateResponseSource: S.Schema<BucketsSippyUpdateResponseSource>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutBucketSippyResponse {
    /** Details about the configured destination bucket. */
    destination?: BucketsSippyUpdateResponseDestination | null;
    /** State of Sippy for this bucket. */
    enabled?: boolean | null;
    /** Details about the configured source bucket. */
    source?: BucketsSippyUpdateResponseSource | null;
}
export declare const PutBucketSippyResponse: S.Schema<PutBucketSippyResponse>;
export interface ResumeSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export declare const ResumeSuperSlurperJobRequest: S.Schema<ResumeSuperSlurperJobRequest>;
export type ResumeSuperSlurperJobResponse = string;
export declare const ResumeSuperSlurperJobResponse: S.Schema<ResumeSuperSlurperJobResponse>;
export type SuperSlurperConnectivityPrecheckSourceRequestSecretR2SlurperS3SourceSchema = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export declare const SuperSlurperConnectivityPrecheckSourceRequestSecretR2SlurperS3SourceSchema: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret>;
export type SuperSlurperConnectivityPrecheckSourceRequestSecretR2SlurperGcsSourceSchema = SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret;
export declare const SuperSlurperConnectivityPrecheckSourceRequestSecretR2SlurperGcsSourceSchema: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret>;
export type SuperSlurperConnectivityPrecheckSourceRequestSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret | SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret;
export declare const SuperSlurperConnectivityPrecheckSourceRequestSecret: any;
export type SuperSlurperConnectivityPrecheckSourceRequestVendorEnum = "s3" | "gcs";
export declare const SuperSlurperConnectivityPrecheckSourceRequestVendorEnum: any;
export type SuperSlurperConnectivityPrecheckSourceRequestVendorR2SlurperR2SourceSchema = "r2";
export declare const SuperSlurperConnectivityPrecheckSourceRequestVendorR2SlurperR2SourceSchema: any;
export type SuperSlurperConnectivityPrecheckSourceRequestVendor = SuperSlurperConnectivityPrecheckSourceRequestVendorEnum | (string & {}) | SuperSlurperConnectivityPrecheckSourceRequestVendorR2SlurperR2SourceSchema | (string & {});
export declare const SuperSlurperConnectivityPrecheckSourceRequestVendor: any;
export type SuperSlurperConnectivityPrecheckSourceRequestKeysList = Array<string>;
export declare const SuperSlurperConnectivityPrecheckSourceRequestKeysList: S.Schema<SuperSlurperConnectivityPrecheckSourceRequestKeysList>;
export type SuperSlurperConnectivityPrecheckSourceRequestJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperConnectivityPrecheckSourceRequestJurisdiction: any;
export interface SourceSuperSlurperConnectivityPrecheckRequest {
    accountId: string;
    bucket: string;
    secret: SuperSlurperConnectivityPrecheckSourceRequestSecret;
    vendor: SuperSlurperConnectivityPrecheckSourceRequestVendor;
    /** Custom S3-compatible endpoint that must use https://. */
    endpoint?: string;
    keys?: SuperSlurperConnectivityPrecheckSourceRequestKeysList;
    pathPrefix?: string;
    region?: string;
    jurisdiction?: SuperSlurperConnectivityPrecheckSourceRequestJurisdiction | (string & {});
}
export declare const SourceSuperSlurperConnectivityPrecheckRequest: S.Schema<SourceSuperSlurperConnectivityPrecheckRequest>;
export type SuperSlurperConnectivityPrecheckSourceResponseConnectivityStatus = "success" | "error";
export declare const SuperSlurperConnectivityPrecheckSourceResponseConnectivityStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SourceSuperSlurperConnectivityPrecheckResponse {
    connectivityStatus?: SuperSlurperConnectivityPrecheckSourceResponseConnectivityStatus | null;
}
export declare const SourceSuperSlurperConnectivityPrecheckResponse: S.Schema<SourceSuperSlurperConnectivityPrecheckResponse>;
export type SuperSlurperConnectivityPrecheckTargetRequestSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export declare const SuperSlurperConnectivityPrecheckTargetRequestSecret: S.Schema<SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret>;
export type SuperSlurperConnectivityPrecheckTargetRequestVendor = "r2";
export declare const SuperSlurperConnectivityPrecheckTargetRequestVendor: any;
export type SuperSlurperConnectivityPrecheckTargetRequestJurisdiction = "default" | "eu" | "fedramp";
export declare const SuperSlurperConnectivityPrecheckTargetRequestJurisdiction: any;
export interface TargetSuperSlurperConnectivityPrecheckRequest {
    accountId: string;
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperConnectivityPrecheckTargetRequestVendor | (string & {});
    jurisdiction?: SuperSlurperConnectivityPrecheckTargetRequestJurisdiction | (string & {});
}
export declare const TargetSuperSlurperConnectivityPrecheckRequest: S.Schema<TargetSuperSlurperConnectivityPrecheckRequest>;
export type SuperSlurperConnectivityPrecheckTargetResponseConnectivityStatus = "success" | "error";
export declare const SuperSlurperConnectivityPrecheckTargetResponseConnectivityStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TargetSuperSlurperConnectivityPrecheckResponse {
    connectivityStatus?: SuperSlurperConnectivityPrecheckTargetResponseConnectivityStatus | null;
}
export declare const TargetSuperSlurperConnectivityPrecheckResponse: S.Schema<TargetSuperSlurperConnectivityPrecheckResponse>;
export type BucketsDomainsCustomUpdateRequestCiphersList = Array<string>;
export declare const BucketsDomainsCustomUpdateRequestCiphersList: S.Schema<BucketsDomainsCustomUpdateRequestCiphersList>;
export type BucketsDomainsCustomUpdateRequestMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export declare const BucketsDomainsCustomUpdateRequestMinTLS: any;
export type BucketsDomainsCustomUpdateRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsDomainsCustomUpdateRequestCfR2Jurisdiction: any;
export interface UpdateBucketDomainCustomRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain. */
    domain: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomUpdateRequestCiphersList;
    /** Whether to enable public bucket access at the specified custom domain. */
    enabled?: boolean;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to previous value. */
    minTLS?: BucketsDomainsCustomUpdateRequestMinTLS | (string & {});
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsDomainsCustomUpdateRequestCfR2Jurisdiction | (string & {});
}
export declare const UpdateBucketDomainCustomRequest: S.Schema<UpdateBucketDomainCustomRequest>;
export type BucketsDomainsCustomUpdateResponseCiphersList = Array<string>;
export declare const BucketsDomainsCustomUpdateResponseCiphersList: S.Schema<BucketsDomainsCustomUpdateResponseCiphersList>;
export type BucketsDomainsCustomUpdateResponseMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export declare const BucketsDomainsCustomUpdateResponseMinTLS: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateBucketDomainCustomResponse {
    /** Domain name of the affected custom domain. */
    domain: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomUpdateResponseCiphersList | null;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled?: boolean | null;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomUpdateResponseMinTLS | null;
}
export declare const UpdateBucketDomainCustomResponse: S.Schema<UpdateBucketDomainCustomResponse>;
export type BucketsObjectsUploadRequestCfR2Jurisdiction = "default" | "eu" | "fedramp";
export declare const BucketsObjectsUploadRequestCfR2Jurisdiction: any;
export type BucketsObjectsUploadRequestCfR2StorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsObjectsUploadRequestCfR2StorageClass: any;
export interface UploadBucketObjectRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    cfR2Jurisdiction?: BucketsObjectsUploadRequestCfR2Jurisdiction | (string & {});
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    cfR2StorageClass?: BucketsObjectsUploadRequestCfR2StorageClass | (string & {});
    /** The key (name) to assign to the object. May contain slashes for path-like keys. */
    objectName: string;
    /** The object content — sent verbatim as the request body. */
    body?: Blob | Uint8Array | ArrayBuffer | string;
    /** MIME type stored with the object. */
    contentType?: string;
    /** Content disposition of the object. */
    contentDisposition?: string;
    /** Content encoding of the object. */
    contentEncoding?: string;
    /** Content language of the object. */
    contentLanguage?: string;
    /** Content length of the object in bytes. */
    contentLength?: string;
    /** Cache control directives for the object. */
    cacheControl?: string;
    /** Expiration date of the object. */
    expires?: string;
    /** Storage class for the object. */
    cf_r2_storage_class?: string;
}
export declare const UploadBucketObjectRequest: S.Schema<UploadBucketObjectRequest>;
export type BucketsObjectsUploadResponseStorageClass = "Standard" | "InfrequentAccess";
export declare const BucketsObjectsUploadResponseStorageClass: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UploadBucketObjectResponse {
    /** The entity tag for the uploaded object. */
    etag?: string | null;
    /** The key (name) of the uploaded object. */
    key?: string | null;
    /** The size of the uploaded object in bytes (as a string). */
    size?: string | null;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsObjectsUploadResponseStorageClass | null;
    /** The date and time the object was uploaded. */
    uploaded?: string | null;
    /** The version UUID of the uploaded object. */
    version?: string | null;
}
export declare const UploadBucketObjectResponse: S.Schema<UploadBucketObjectResponse>;
export type AbortAllSuperSlurperJobError = CloudflareOpError;
/** Cancels all running R2 Super Slurper migration jobs for the account. Any objects in the middle of a transfer will finish, but no new objects will start transferring. */
export declare const abortAllSuperSlurperJob: API.OperationMethod<AbortAllSuperSlurperJobRequest, AbortAllSuperSlurperJobResponse, AbortAllSuperSlurperJobError, CloudflareOpContext>;
export type AbortSuperSlurperJobError = CloudflareOpError;
/** Cancels a specific R2 Super Slurper migration job. Any objects in the middle of a transfer will finish, but no new objects will start transferring. */
export declare const abortSuperSlurperJob: API.OperationMethod<AbortSuperSlurperJobRequest, AbortSuperSlurperJobResponse, AbortSuperSlurperJobError, CloudflareOpContext>;
export type CreateBucketError = InvalidBucketName | BucketAlreadyExists | InvalidRoute | CloudflareOpError;
/** Creates a new R2 bucket. */
export declare const createBucket: API.OperationMethod<CreateBucketRequest, CreateBucketResponse, CreateBucketError, CloudflareOpContext>;
export type CreateBucketDomainCustomError = NoSuchBucket | InvalidBucketName | CustomDomainInUse | CloudflareOpError;
/** Register a new custom domain for an existing R2 bucket. */
export declare const createBucketDomainCustom: API.OperationMethod<CreateBucketDomainCustomRequest, CreateBucketDomainCustomResponse, CreateBucketDomainCustomError, CloudflareOpContext>;
export type CreateSuperSlurperJobError = CloudflareOpError;
/** Creates a new R2 Super Slurper migration job to transfer objects from a source bucket (e.g. S3, GCS, R2) to R2. */
export declare const createSuperSlurperJob: API.OperationMethod<CreateSuperSlurperJobRequest, CreateSuperSlurperJobResponse, CreateSuperSlurperJobError, CloudflareOpContext>;
export type CreateTemporaryCredentialError = CloudflareOpError;
/** Creates temporary access credentials on a bucket that can be optionally scoped to prefixes or objects. */
export declare const createTemporaryCredential: API.OperationMethod<CreateTemporaryCredentialRequest, CreateTemporaryCredentialResponse, CreateTemporaryCredentialError, CloudflareOpContext>;
export type DeleteBucketError = NoSuchBucket | BucketNotEmpty | InvalidRoute | NoRoute | CloudflareOpError;
/** Deletes an existing R2 bucket. */
export declare const deleteBucket: API.OperationMethod<DeleteBucketRequest, DeleteBucketResponse, DeleteBucketError, CloudflareOpContext>;
export type DeleteBucketCorsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Delete the CORS policy for a bucket. */
export declare const deleteBucketCors: API.OperationMethod<DeleteBucketCorsRequest, DeleteBucketCorsResponse, DeleteBucketCorsError, CloudflareOpContext>;
export type DeleteBucketDomainCustomError = DomainNotFound | NoSuchBucket | CloudflareOpError;
/** Remove custom domain registration from an existing R2 bucket. */
export declare const deleteBucketDomainCustom: API.OperationMethod<DeleteBucketDomainCustomRequest, DeleteBucketDomainCustomResponse, DeleteBucketDomainCustomError, CloudflareOpContext>;
export type DeleteBucketEventNotificationError = BucketNotFound | EventNotificationConfigNotFound | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Delete an event notification rule. **If no body is provided, all rules for specified queue will be deleted**. */
export declare const deleteBucketEventNotification: API.OperationMethod<DeleteBucketEventNotificationRequest, DeleteBucketEventNotificationResponse, DeleteBucketEventNotificationError, CloudflareOpContext>;
export type DeleteBucketObjectError = NoSuchBucket | NoSuchKey | CloudflareOpError;
/** Deletes an object from an R2 bucket. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const deleteBucketObject: API.OperationMethod<DeleteBucketObjectRequest, DeleteBucketObjectResponse, DeleteBucketObjectError, CloudflareOpContext>;
export type DeleteBucketSippyError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Disables Sippy on this bucket. */
export declare const deleteBucketSippy: API.OperationMethod<DeleteBucketSippyRequest, DeleteBucketSippyResponse, DeleteBucketSippyError, CloudflareOpContext>;
export type DeleteObjectsError = NoSuchBucket | InvalidRoute | NoRoute | CloudflareOpError;
export declare const deleteObjects: API.OperationMethod<DeleteObjectsRequest, DeleteObjectsResponse, DeleteObjectsError, CloudflareOpContext>;
export type GetBucketError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Gets properties of an existing R2 bucket. */
export declare const getBucket: API.OperationMethod<GetBucketRequest, GetBucketResponse, GetBucketError, CloudflareOpContext>;
export type GetBucketCorsError = NoSuchBucket | InvalidRoute | NoCorsConfiguration | CloudflareOpError;
/** Get the CORS policy for a bucket. */
export declare const getBucketCors: API.OperationMethod<GetBucketCorsRequest, GetBucketCorsResponse, GetBucketCorsError, CloudflareOpContext>;
export type GetBucketDomainCustomError = DomainNotFound | NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get the configuration for a custom domain on an existing R2 bucket. */
export declare const getBucketDomainCustom: API.OperationMethod<GetBucketDomainCustomRequest, GetBucketDomainCustomResponse, GetBucketDomainCustomError, CloudflareOpContext>;
export type GetBucketEventNotificationError = BucketNotFound | NoEventNotificationConfig | EventNotificationConfigNotFound | QueueNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Get a single event notification rule. */
export declare const getBucketEventNotification: API.OperationMethod<GetBucketEventNotificationRequest, GetBucketEventNotificationResponse, GetBucketEventNotificationError, CloudflareOpContext>;
export type GetBucketLifecycleError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get object lifecycle rules for a bucket. */
export declare const getBucketLifecycle: API.OperationMethod<GetBucketLifecycleRequest, GetBucketLifecycleResponse, GetBucketLifecycleError, CloudflareOpContext>;
export type GetBucketLockError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get lock rules for a bucket. */
export declare const getBucketLock: API.OperationMethod<GetBucketLockRequest, GetBucketLockResponse, GetBucketLockError, CloudflareOpContext>;
export type GetBucketObjectError = NoSuchBucket | InvalidRoute | NoSuchKey | CloudflareOpError;
/** Retrieves an object from an R2 bucket. Returns the object body along with metadata headers. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const getBucketObject: API.OperationMethod<GetBucketObjectRequest, GetBucketObjectResponse, GetBucketObjectError, CloudflareOpContext>;
export type GetBucketSippyError = NoSuchBucket | InvalidRoute | Forbidden | CloudflareOpError;
/** Gets configuration for Sippy for an existing R2 bucket. */
export declare const getBucketSippy: API.OperationMethod<GetBucketSippyRequest, GetBucketSippyResponse, GetBucketSippyError, CloudflareOpContext>;
export type GetSuperSlurperJobError = CloudflareOpError;
/** Retrieves detailed status and configuration for a specific R2 Super Slurper migration job. */
export declare const getSuperSlurperJob: API.OperationMethod<GetSuperSlurperJobRequest, GetSuperSlurperJobResponse, GetSuperSlurperJobError, CloudflareOpContext>;
export type ListBucketDomainCustomsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Gets a list of all custom domains registered with an existing R2 bucket. */
export declare const listBucketDomainCustoms: API.OperationMethod<ListBucketDomainCustomsRequest, ListBucketDomainCustomsResponse, ListBucketDomainCustomsError, CloudflareOpContext>;
export type ListBucketDomainManagedsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Gets state of public access over the bucket's R2-managed (r2.dev) domain. */
export declare const listBucketDomainManageds: API.OperationMethod<ListBucketDomainManagedsRequest, ListBucketDomainManagedsResponse, ListBucketDomainManagedsError, CloudflareOpContext>;
export type ListBucketEventNotificationsError = NoSuchBucket | InvalidRoute | NoEventNotificationConfig | BucketNotFound | CloudflareOpError;
/** List all event notification rules for a bucket. */
export declare const listBucketEventNotifications: API.OperationMethod<ListBucketEventNotificationsRequest, ListBucketEventNotificationsResponse, ListBucketEventNotificationsError, CloudflareOpContext>;
export type ListBucketMetricsError = InvalidRoute | CloudflareOpError;
/** Get Storage/Object Count Metrics across all buckets in your account. Note that Account-Level Metrics may not immediately reflect the latest data. */
export declare const listBucketMetrics: API.OperationMethod<ListBucketMetricsRequest, ListBucketMetricsResponse, ListBucketMetricsError, CloudflareOpContext>;
export type ListBucketObjectsError = NoSuchBucket | CloudflareOpError;
/** Lists objects in an R2 bucket. Returns object metadata including key, size, etag, last modified date, HTTP metadata, and custom metadata. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const listBucketObjects: API.PaginatedOperationMethod<ListBucketObjectsRequest, ListBucketObjectsResponse, ListBucketObjectsError, CloudflareOpContext, BucketsObjectsListResultItem>;
export type ListBucketsError = InvalidRoute | CloudflareOpError;
/** Lists all R2 buckets on your account. */
export declare const listBuckets: API.OperationMethod<ListBucketsRequest, ListBucketsResponse, ListBucketsError, CloudflareOpContext>;
export type ListSuperSlurperJobLogsError = CloudflareOpError;
/** Gets log entries for an R2 Super Slurper migration job, showing migration status changes, errors, etc. */
export declare const listSuperSlurperJobLogs: API.PaginatedOperationMethod<ListSuperSlurperJobLogsRequest, ListSuperSlurperJobLogsResponse, ListSuperSlurperJobLogsError, CloudflareOpContext, SuperSlurperJobsLogsListResultItem>;
export type ListSuperSlurperJobsError = CloudflareOpError;
/** Lists all R2 Super Slurper migration jobs for the account with their status. */
export declare const listSuperSlurperJobs: API.PaginatedOperationMethod<ListSuperSlurperJobsRequest, ListSuperSlurperJobsResponse, ListSuperSlurperJobsError, CloudflareOpContext, SuperSlurperJobsListResultItem>;
export type PatchBucketError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Updates properties of an existing R2 bucket. */
export declare const patchBucket: API.OperationMethod<PatchBucketRequest, PatchBucketResponse, PatchBucketError, CloudflareOpContext>;
export type PauseSuperSlurperJobError = CloudflareOpError;
/** Pauses a running R2 Super Slurper migration job. The job can be resumed later to continue transferring. */
export declare const pauseSuperSlurperJob: API.OperationMethod<PauseSuperSlurperJobRequest, PauseSuperSlurperJobResponse, PauseSuperSlurperJobError, CloudflareOpContext>;
export type ProgressSuperSlurperJobError = CloudflareOpError;
/** Retrieves current progress metrics for an R2 Super Slurper migration job */
export declare const progressSuperSlurperJob: API.OperationMethod<ProgressSuperSlurperJobRequest, ProgressSuperSlurperJobResponse, ProgressSuperSlurperJobError, CloudflareOpContext>;
export type PutBucketCorsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Set the CORS policy for a bucket. */
export declare const putBucketCors: API.OperationMethod<PutBucketCorsRequest, PutBucketCorsResponse, PutBucketCorsError, CloudflareOpContext>;
export type PutBucketDomainManagedError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Updates state of public access over the bucket's R2-managed (r2.dev) domain. */
export declare const putBucketDomainManaged: API.OperationMethod<PutBucketDomainManagedRequest, PutBucketDomainManagedResponse, PutBucketDomainManagedError, CloudflareOpContext>;
export type PutBucketEventNotificationError = BucketNotFound | InvalidEventNotificationConfig | EventNotificationRuleConflict | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Create event notification rule. */
export declare const putBucketEventNotification: API.OperationMethod<PutBucketEventNotificationRequest, PutBucketEventNotificationResponse, PutBucketEventNotificationError, CloudflareOpContext>;
export type PutBucketLifecycleError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Set the object lifecycle rules for a bucket. */
export declare const putBucketLifecycle: API.OperationMethod<PutBucketLifecycleRequest, PutBucketLifecycleResponse, PutBucketLifecycleError, CloudflareOpContext>;
export type PutBucketLockError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Set lock rules for a bucket. */
export declare const putBucketLock: API.OperationMethod<PutBucketLockRequest, PutBucketLockResponse, PutBucketLockError, CloudflareOpContext>;
export type PutBucketSippyError = InvalidUpstreamCredentials | InvalidRoute | CloudflareOpError;
/** Sets configuration for Sippy for an existing R2 bucket. */
export declare const putBucketSippy: API.OperationMethod<PutBucketSippyRequest, PutBucketSippyResponse, PutBucketSippyError, CloudflareOpContext>;
export type ResumeSuperSlurperJobError = CloudflareOpError;
/** Resumes a paused R2 Super Slurper migration job, continuing the transfer from where it stopped. */
export declare const resumeSuperSlurperJob: API.OperationMethod<ResumeSuperSlurperJobRequest, ResumeSuperSlurperJobResponse, ResumeSuperSlurperJobError, CloudflareOpContext>;
export type SourceSuperSlurperConnectivityPrecheckError = CloudflareOpError;
/** Check whether tokens are valid against the source bucket */
export declare const sourceSuperSlurperConnectivityPrecheck: API.OperationMethod<SourceSuperSlurperConnectivityPrecheckRequest, SourceSuperSlurperConnectivityPrecheckResponse, SourceSuperSlurperConnectivityPrecheckError, CloudflareOpContext>;
export type TargetSuperSlurperConnectivityPrecheckError = CloudflareOpError;
/** Check whether tokens are valid against the target bucket */
export declare const targetSuperSlurperConnectivityPrecheck: API.OperationMethod<TargetSuperSlurperConnectivityPrecheckRequest, TargetSuperSlurperConnectivityPrecheckResponse, TargetSuperSlurperConnectivityPrecheckError, CloudflareOpContext>;
export type UpdateBucketDomainCustomError = NoSuchBucket | CloudflareOpError;
/** Edit the configuration for a custom domain on an existing R2 bucket. */
export declare const updateBucketDomainCustom: API.OperationMethod<UpdateBucketDomainCustomRequest, UpdateBucketDomainCustomResponse, UpdateBucketDomainCustomError, CloudflareOpContext>;
export type UploadBucketObjectError = NoSuchBucket | CloudflareOpError;
/** Uploads an object to an R2 bucket. The object body is provided as the request body. Returns metadata about the uploaded object. The maximum upload size for this endpoint is 300 MB. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const uploadBucketObject: API.OperationMethod<UploadBucketObjectRequest, UploadBucketObjectResponse, UploadBucketObjectError, CloudflareOpContext>;
export declare const deleteObject: API.OperationMethod<DeleteBucketObjectRequest, DeleteBucketObjectResponse, DeleteBucketObjectError, CloudflareOpContext>;
export type DeleteObjectRequest = DeleteBucketObjectRequest;
export type DeleteObjectResponse = DeleteBucketObjectResponse;
export type DeleteObjectError = DeleteBucketObjectError;
export declare const getObject: API.OperationMethod<GetBucketObjectRequest, GetBucketObjectResponse, GetBucketObjectError, CloudflareOpContext>;
export type GetObjectRequest = GetBucketObjectRequest;
export type GetObjectResponse = GetBucketObjectResponse;
export type GetObjectError = GetBucketObjectError;
export declare const listObjects: API.PaginatedOperationMethod<ListBucketObjectsRequest, ListBucketObjectsResponse, ListBucketObjectsError, CloudflareOpContext, BucketsObjectsListResultItem>;
export type ListObjectsRequest = ListBucketObjectsRequest;
export type ListObjectsResponse = ListBucketObjectsResponse;
export type ListObjectsError = ListBucketObjectsError;
export declare const putObject: API.OperationMethod<UploadBucketObjectRequest, UploadBucketObjectResponse, UploadBucketObjectError, CloudflareOpContext>;
export type PutObjectRequest = UploadBucketObjectRequest;
export type PutObjectResponse = UploadBucketObjectResponse;
export type PutObjectError = UploadBucketObjectError;
//# sourceMappingURL=r2.d.ts.map