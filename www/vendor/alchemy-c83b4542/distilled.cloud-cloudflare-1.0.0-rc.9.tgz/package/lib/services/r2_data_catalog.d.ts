import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidCredential_base: S.Class<InvalidCredential, S.TaggedStruct<"InvalidCredential", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCredential extends /*@__PURE__*/ InvalidCredential_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const NoSuchBucket_base: S.Class<NoSuchBucket, S.TaggedStruct<"NoSuchBucket", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoSuchBucket extends /*@__PURE__*/ NoSuchBucket_base {
}
declare const TableNotFound_base: S.Class<TableNotFound, S.TaggedStruct<"TableNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TableNotFound extends /*@__PURE__*/ TableNotFound_base {
}
declare const WarehouseInactive_base: S.Class<WarehouseInactive, S.TaggedStruct<"WarehouseInactive", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WarehouseInactive extends /*@__PURE__*/ WarehouseInactive_base {
}
declare const WarehouseNotFound_base: S.Class<WarehouseNotFound, S.TaggedStruct<"WarehouseNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WarehouseNotFound extends /*@__PURE__*/ WarehouseNotFound_base {
}
export interface CreateCredentialRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Provides the Cloudflare API token for accessing R2. */
    token: string;
}
export declare const CreateCredentialRequest: S.Schema<CreateCredentialRequest>;
export type CreateCredentialResponse = unknown;
export declare const CreateCredentialResponse: S.Schema<CreateCredentialResponse>;
export interface DisableR2DataCatalogRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export declare const DisableR2DataCatalogRequest: S.Schema<DisableR2DataCatalogRequest>;
export interface DisableR2DataCatalogResponse {
}
export declare const DisableR2DataCatalogResponse: S.Schema<DisableR2DataCatalogResponse>;
export interface EnableR2DataCatalogRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export declare const EnableR2DataCatalogRequest: S.Schema<EnableR2DataCatalogRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EnableR2DataCatalogResponse {
    /** Use this to uniquely identify the activated catalog. */
    id: string;
    /** Specifies the name of the activated catalog. */
    name: string;
}
export declare const EnableR2DataCatalogResponse: S.Schema<EnableR2DataCatalogResponse>;
export interface GetMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export declare const GetMaintenanceConfigRequest: S.Schema<GetMaintenanceConfigRequest>;
export type MaintenanceConfigsGetResponseCredentialStatus = "present" | "absent";
export declare const MaintenanceConfigsGetResponseCredentialStatus: any;
export type MaintenanceConfigsGetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export declare const MaintenanceConfigsGetResponseMaintenanceConfigCompactionState: any;
export type MaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const MaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb: any;
export interface MaintenanceConfigsGetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsGetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: MaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb;
}
export declare const MaintenanceConfigsGetResponseMaintenanceConfigCompaction: S.Schema<MaintenanceConfigsGetResponseMaintenanceConfigCompaction>;
export type MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export declare const MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState: any;
export interface MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState;
}
export declare const MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration: S.Schema<MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration>;
export interface MaintenanceConfigsGetResponseMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: MaintenanceConfigsGetResponseMaintenanceConfigCompaction | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: MaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration | null;
}
export declare const MaintenanceConfigsGetResponseMaintenanceConfig: S.Schema<MaintenanceConfigsGetResponseMaintenanceConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMaintenanceConfigResponse {
    /** Shows the credential configuration status. */
    credentialStatus: MaintenanceConfigsGetResponseCredentialStatus;
    /** Configures maintenance for the catalog. */
    maintenanceConfig: MaintenanceConfigsGetResponseMaintenanceConfig;
}
export declare const GetMaintenanceConfigResponse: S.Schema<GetMaintenanceConfigResponse>;
export interface GetNamespaceTableMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    tableName: string;
}
export declare const GetNamespaceTableMaintenanceConfigRequest: S.Schema<GetNamespaceTableMaintenanceConfigRequest>;
export type NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export declare const NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionState: any;
export type NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb: any;
export interface NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompactionTargetSizeMb;
}
export declare const NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompaction: S.Schema<NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompaction>;
export type NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export declare const NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState: any;
export interface NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpirationState;
}
export declare const NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration: S.Schema<NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration>;
export interface NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfig {
    /** Configures compaction settings for table optimization. */
    compaction?: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigCompaction | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfigSnapshotExpiration | null;
}
export declare const NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfig: S.Schema<NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceTableMaintenanceConfigResponse {
    /** Configures maintenance for the table. */
    maintenanceConfig: NamespacesTablesMaintenanceConfigsGetResponseMaintenanceConfig;
}
export declare const GetNamespaceTableMaintenanceConfigResponse: S.Schema<GetNamespaceTableMaintenanceConfigResponse>;
export interface GetR2DataCatalogRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
}
export declare const GetR2DataCatalogRequest: S.Schema<GetR2DataCatalogRequest>;
export type GetResponseStatus = "active" | "inactive";
export declare const GetResponseStatus: any;
export type GetResponseCredentialStatus = "present" | "absent";
export declare const GetResponseCredentialStatus: any;
export type GetResponseMaintenanceConfigCompactionState = "enabled" | "disabled";
export declare const GetResponseMaintenanceConfigCompactionState: any;
export type GetResponseMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const GetResponseMaintenanceConfigCompactionTargetSizeMb: any;
export interface GetResponseMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: GetResponseMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: GetResponseMaintenanceConfigCompactionTargetSizeMb;
}
export declare const GetResponseMaintenanceConfigCompaction: S.Schema<GetResponseMaintenanceConfigCompaction>;
export type GetResponseMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export declare const GetResponseMaintenanceConfigSnapshotExpirationState: any;
export interface GetResponseMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: GetResponseMaintenanceConfigSnapshotExpirationState;
}
export declare const GetResponseMaintenanceConfigSnapshotExpiration: S.Schema<GetResponseMaintenanceConfigSnapshotExpiration>;
export interface GetResponseMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: GetResponseMaintenanceConfigCompaction | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: GetResponseMaintenanceConfigSnapshotExpiration | null;
}
export declare const GetResponseMaintenanceConfig: S.Schema<GetResponseMaintenanceConfig>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetR2DataCatalogResponse {
    /** Use this to uniquely identify the catalog. */
    id: string;
    /** Specifies the associated R2 bucket name. */
    bucket: string;
    /** Specifies the catalog name (generated from account and bucket name). */
    name: string;
    /** Indicates the status of the catalog. */
    status: GetResponseStatus;
    /** Shows the credential configuration status. */
    credentialStatus?: GetResponseCredentialStatus | null;
    /** Configures maintenance for the catalog. */
    maintenanceConfig?: GetResponseMaintenanceConfig | null;
}
export declare const GetR2DataCatalogResponse: S.Schema<GetR2DataCatalogResponse>;
export interface ListNamespacesRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Maximum number of namespaces to return per page. */
    pageSize?: number;
    /** Opaque pagination token from a previous response. */
    pageToken?: string;
    /** Parent namespace to filter by. Only returns direct children of this namespace. */
    parent?: string;
    /** Whether to include additional metadata (timestamps). */
    returnDetails?: boolean;
    /** Whether to include namespace UUIDs in the response. */
    returnUuids?: boolean;
}
export declare const ListNamespacesRequest: S.Schema<ListNamespacesRequest>;
export type NamespacesListResponseNamespacesItemList = Array<string>;
export declare const NamespacesListResponseNamespacesItemList: S.Schema<NamespacesListResponseNamespacesItemList>;
export type NamespacesListResponseNamespacesList = Array<NamespacesListResponseNamespacesItemList>;
export declare const NamespacesListResponseNamespacesList: S.Schema<NamespacesListResponseNamespacesList>;
export type NamespacesListResponseDetailsItemNamespaceList = Array<string>;
export declare const NamespacesListResponseDetailsItemNamespaceList: S.Schema<NamespacesListResponseDetailsItemNamespaceList>;
export interface NamespacesListResponseDetailsItem {
    /** Specifies the hierarchical namespace parts as an array of strings. */
    namespace: NamespacesListResponseDetailsItemNamespaceList;
    /** Contains the UUID that persists across renames. */
    namespaceUuid: string;
    /** Indicates the creation timestamp in ISO 8601 format. */
    createdAt?: string | null;
    /** Shows the last update timestamp in ISO 8601 format. Null if never updated. */
    updatedAt?: string | null;
}
export declare const NamespacesListResponseDetailsItem: S.Schema<NamespacesListResponseDetailsItem>;
export type NamespacesListResponseDetailsList = Array<NamespacesListResponseDetailsItem>;
export declare const NamespacesListResponseDetailsList: S.Schema<NamespacesListResponseDetailsList>;
export type NamespacesListResponseNamespaceUuidsList = Array<string>;
export declare const NamespacesListResponseNamespaceUuidsList: S.Schema<NamespacesListResponseNamespaceUuidsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListNamespacesResponse {
    /** Lists namespaces in the catalog. */
    namespaces: NamespacesListResponseNamespacesList;
    /** Contains detailed metadata for each namespace when return_details is true. */
    details?: NamespacesListResponseDetailsList | null;
    /** Contains UUIDs for each namespace when return_uuids is true. */
    namespaceUuids?: NamespacesListResponseNamespaceUuidsList | null;
    /** Use this opaque token to fetch the next page of results. */
    nextPageToken?: string | null;
}
export declare const ListNamespacesResponse: S.Schema<ListNamespacesResponse>;
export interface ListNamespaceTablesRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    /** Maximum number of tables to return per page. */
    pageSize?: number;
    /** Opaque pagination token from a previous response. */
    pageToken?: string;
    /** Whether to include additional metadata (timestamps, locations). */
    returnDetails?: boolean;
    /** Whether to include table UUIDs in the response. */
    returnUuids?: boolean;
}
export declare const ListNamespaceTablesRequest: S.Schema<ListNamespaceTablesRequest>;
export type NamespacesTablesListResponseIdentifiersItemNamespaceList = Array<string>;
export declare const NamespacesTablesListResponseIdentifiersItemNamespaceList: S.Schema<NamespacesTablesListResponseIdentifiersItemNamespaceList>;
export interface NamespacesTablesListResponseIdentifiersItem {
    /** Specifies the table name. */
    name: string;
    /** Specifies the hierarchical namespace parts as an array of strings. */
    namespace: NamespacesTablesListResponseIdentifiersItemNamespaceList;
}
export declare const NamespacesTablesListResponseIdentifiersItem: S.Schema<NamespacesTablesListResponseIdentifiersItem>;
export type NamespacesTablesListResponseIdentifiersList = Array<NamespacesTablesListResponseIdentifiersItem>;
export declare const NamespacesTablesListResponseIdentifiersList: S.Schema<NamespacesTablesListResponseIdentifiersList>;
export type NamespacesTablesListResponseDetailsItemIdentifierNamespaceList = Array<string>;
export declare const NamespacesTablesListResponseDetailsItemIdentifierNamespaceList: S.Schema<NamespacesTablesListResponseDetailsItemIdentifierNamespaceList>;
export interface NamespacesTablesListResponseDetailsItemIdentifier {
    /** Specifies the table name. */
    name: string;
    /** Specifies the hierarchical namespace parts as an array of strings. */
    namespace: NamespacesTablesListResponseDetailsItemIdentifierNamespaceList;
}
export declare const NamespacesTablesListResponseDetailsItemIdentifier: S.Schema<NamespacesTablesListResponseDetailsItemIdentifier>;
export interface NamespacesTablesListResponseDetailsItem {
    /** Specifies a unique table identifier within a catalog. */
    identifier: NamespacesTablesListResponseDetailsItemIdentifier;
    /** Contains the UUID that persists across renames. */
    tableUuid: string;
    /** Indicates the creation timestamp in ISO 8601 format. */
    createdAt?: string | null;
    /** Specifies the base S3 URI for table storage location. */
    location?: string | null;
    /** Contains the S3 URI to table metadata file. Null for staged tables. */
    metadataLocation?: string | null;
    /** Shows the last update timestamp in ISO 8601 format. Null if never updated. */
    updatedAt?: string | null;
}
export declare const NamespacesTablesListResponseDetailsItem: S.Schema<NamespacesTablesListResponseDetailsItem>;
export type NamespacesTablesListResponseDetailsList = Array<NamespacesTablesListResponseDetailsItem>;
export declare const NamespacesTablesListResponseDetailsList: S.Schema<NamespacesTablesListResponseDetailsList>;
export type NamespacesTablesListResponseTableUuidsList = Array<string>;
export declare const NamespacesTablesListResponseTableUuidsList: S.Schema<NamespacesTablesListResponseTableUuidsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListNamespaceTablesResponse {
    /** Lists tables in the namespace. */
    identifiers: NamespacesTablesListResponseIdentifiersList;
    /** Contains detailed metadata for each table when return_details is true. */
    details?: NamespacesTablesListResponseDetailsList | null;
    /** Use this opaque token to fetch the next page of results. */
    nextPageToken?: string | null;
    /** Contains UUIDs for each table when return_uuids is true. */
    tableUuids?: NamespacesTablesListResponseTableUuidsList | null;
}
export declare const ListNamespaceTablesResponse: S.Schema<ListNamespaceTablesResponse>;
export interface ListR2DataCatalogsRequest {
    /** Use this to identify the account. */
    accountId: string;
}
export declare const ListR2DataCatalogsRequest: S.Schema<ListR2DataCatalogsRequest>;
export type ListResponseWarehousesItemStatus = "active" | "inactive";
export declare const ListResponseWarehousesItemStatus: any;
export type ListResponseWarehousesItemCredentialStatus = "present" | "absent";
export declare const ListResponseWarehousesItemCredentialStatus: any;
export type ListResponseWarehousesItemMaintenanceConfigCompactionState = "enabled" | "disabled";
export declare const ListResponseWarehousesItemMaintenanceConfigCompactionState: any;
export type ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb: any;
export interface ListResponseWarehousesItemMaintenanceConfigCompaction {
    /** Specifies the state of maintenance operations. */
    state: ListResponseWarehousesItemMaintenanceConfigCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: ListResponseWarehousesItemMaintenanceConfigCompactionTargetSizeMb;
}
export declare const ListResponseWarehousesItemMaintenanceConfigCompaction: S.Schema<ListResponseWarehousesItemMaintenanceConfigCompaction>;
export type ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState = "enabled" | "disabled";
export declare const ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState: any;
export interface ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: ListResponseWarehousesItemMaintenanceConfigSnapshotExpirationState;
}
export declare const ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration: S.Schema<ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration>;
export interface ListResponseWarehousesItemMaintenanceConfig {
    /** Configures compaction for catalog maintenance. */
    compaction?: ListResponseWarehousesItemMaintenanceConfigCompaction | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: ListResponseWarehousesItemMaintenanceConfigSnapshotExpiration | null;
}
export declare const ListResponseWarehousesItemMaintenanceConfig: S.Schema<ListResponseWarehousesItemMaintenanceConfig>;
export interface ListResponseWarehousesItem {
    /** Use this to uniquely identify the catalog. */
    id: string;
    /** Specifies the associated R2 bucket name. */
    bucket: string;
    /** Specifies the catalog name (generated from account and bucket name). */
    name: string;
    /** Indicates the status of the catalog. */
    status: ListResponseWarehousesItemStatus;
    /** Shows the credential configuration status. */
    credentialStatus?: ListResponseWarehousesItemCredentialStatus | null;
    /** Configures maintenance for the catalog. */
    maintenanceConfig?: ListResponseWarehousesItemMaintenanceConfig | null;
}
export declare const ListResponseWarehousesItem: S.Schema<ListResponseWarehousesItem>;
export type ListResponseWarehousesList = Array<ListResponseWarehousesItem>;
export declare const ListResponseWarehousesList: S.Schema<ListResponseWarehousesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListR2DataCatalogsResponse {
    /** Lists catalogs in the account. */
    warehouses: ListResponseWarehousesList;
}
export declare const ListR2DataCatalogsResponse: S.Schema<ListR2DataCatalogsResponse>;
export type MaintenanceConfigsUpdateRequestCompactionState = "enabled" | "disabled";
export declare const MaintenanceConfigsUpdateRequestCompactionState: any;
export type MaintenanceConfigsUpdateRequestCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const MaintenanceConfigsUpdateRequestCompactionTargetSizeMb: any;
export interface MaintenanceConfigsUpdateRequestCompaction {
    /** Updates the state optionally. */
    state?: MaintenanceConfigsUpdateRequestCompactionState | (string & {});
    /** Updates the target file size optionally. */
    targetSizeMb?: MaintenanceConfigsUpdateRequestCompactionTargetSizeMb | (string & {});
}
export declare const MaintenanceConfigsUpdateRequestCompaction: S.Schema<MaintenanceConfigsUpdateRequestCompaction>;
export type MaintenanceConfigsUpdateRequestSnapshotExpirationState = "enabled" | "disabled";
export declare const MaintenanceConfigsUpdateRequestSnapshotExpirationState: any;
export interface MaintenanceConfigsUpdateRequestSnapshotExpiration {
    /** Updates the maximum age for snapshots optionally. */
    maxSnapshotAge?: string;
    /** Updates the minimum number of snapshots to retain optionally. */
    minSnapshotsToKeep?: number;
    /** Updates the state optionally. */
    state?: MaintenanceConfigsUpdateRequestSnapshotExpirationState | (string & {});
}
export declare const MaintenanceConfigsUpdateRequestSnapshotExpiration: S.Schema<MaintenanceConfigsUpdateRequestSnapshotExpiration>;
export interface UpdateMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    /** Updates compaction configuration (all fields optional). */
    compaction?: MaintenanceConfigsUpdateRequestCompaction;
    /** Updates snapshot expiration configuration (all fields optional). */
    snapshotExpiration?: MaintenanceConfigsUpdateRequestSnapshotExpiration;
}
export declare const UpdateMaintenanceConfigRequest: S.Schema<UpdateMaintenanceConfigRequest>;
export type MaintenanceConfigsUpdateResponseCompactionState = "enabled" | "disabled";
export declare const MaintenanceConfigsUpdateResponseCompactionState: any;
export type MaintenanceConfigsUpdateResponseCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const MaintenanceConfigsUpdateResponseCompactionTargetSizeMb: any;
export interface MaintenanceConfigsUpdateResponseCompaction {
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsUpdateResponseCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: MaintenanceConfigsUpdateResponseCompactionTargetSizeMb;
}
export declare const MaintenanceConfigsUpdateResponseCompaction: S.Schema<MaintenanceConfigsUpdateResponseCompaction>;
export type MaintenanceConfigsUpdateResponseSnapshotExpirationState = "enabled" | "disabled";
export declare const MaintenanceConfigsUpdateResponseSnapshotExpirationState: any;
export interface MaintenanceConfigsUpdateResponseSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: MaintenanceConfigsUpdateResponseSnapshotExpirationState;
}
export declare const MaintenanceConfigsUpdateResponseSnapshotExpiration: S.Schema<MaintenanceConfigsUpdateResponseSnapshotExpiration>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMaintenanceConfigResponse {
    /** Configures compaction for catalog maintenance. */
    compaction?: MaintenanceConfigsUpdateResponseCompaction | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: MaintenanceConfigsUpdateResponseSnapshotExpiration | null;
}
export declare const UpdateMaintenanceConfigResponse: S.Schema<UpdateMaintenanceConfigResponse>;
export type NamespacesTablesMaintenanceConfigsUpdateRequestCompactionState = "enabled" | "disabled";
export declare const NamespacesTablesMaintenanceConfigsUpdateRequestCompactionState: any;
export type NamespacesTablesMaintenanceConfigsUpdateRequestCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const NamespacesTablesMaintenanceConfigsUpdateRequestCompactionTargetSizeMb: any;
export interface NamespacesTablesMaintenanceConfigsUpdateRequestCompaction {
    /** Updates the state optionally. */
    state?: NamespacesTablesMaintenanceConfigsUpdateRequestCompactionState | (string & {});
    /** Updates the target file size optionally. */
    targetSizeMb?: NamespacesTablesMaintenanceConfigsUpdateRequestCompactionTargetSizeMb | (string & {});
}
export declare const NamespacesTablesMaintenanceConfigsUpdateRequestCompaction: S.Schema<NamespacesTablesMaintenanceConfigsUpdateRequestCompaction>;
export type NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpirationState = "enabled" | "disabled";
export declare const NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpirationState: any;
export interface NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpiration {
    /** Updates the maximum age for snapshots optionally. */
    maxSnapshotAge?: string;
    /** Updates the minimum number of snapshots to retain optionally. */
    minSnapshotsToKeep?: number;
    /** Updates the state optionally. */
    state?: NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpirationState | (string & {});
}
export declare const NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpiration: S.Schema<NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpiration>;
export interface UpdateNamespaceTableMaintenanceConfigRequest {
    /** Use this to identify the account. */
    accountId: string;
    /** Specifies the R2 bucket name. */
    bucketName: string;
    namespace: string;
    tableName: string;
    /** Updates compaction configuration (all fields optional). */
    compaction?: NamespacesTablesMaintenanceConfigsUpdateRequestCompaction;
    /** Updates snapshot expiration configuration (all fields optional). */
    snapshotExpiration?: NamespacesTablesMaintenanceConfigsUpdateRequestSnapshotExpiration;
}
export declare const UpdateNamespaceTableMaintenanceConfigRequest: S.Schema<UpdateNamespaceTableMaintenanceConfigRequest>;
export type NamespacesTablesMaintenanceConfigsUpdateResponseCompactionState = "enabled" | "disabled";
export declare const NamespacesTablesMaintenanceConfigsUpdateResponseCompactionState: any;
export type NamespacesTablesMaintenanceConfigsUpdateResponseCompactionTargetSizeMb = "64" | "128" | "256" | "512";
export declare const NamespacesTablesMaintenanceConfigsUpdateResponseCompactionTargetSizeMb: any;
export interface NamespacesTablesMaintenanceConfigsUpdateResponseCompaction {
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsUpdateResponseCompactionState;
    /** Sets the target file size for compaction in megabytes. Defaults to "128". */
    targetSizeMb: NamespacesTablesMaintenanceConfigsUpdateResponseCompactionTargetSizeMb;
}
export declare const NamespacesTablesMaintenanceConfigsUpdateResponseCompaction: S.Schema<NamespacesTablesMaintenanceConfigsUpdateResponseCompaction>;
export type NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpirationState = "enabled" | "disabled";
export declare const NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpirationState: any;
export interface NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpiration {
    /** Specifies the maximum age for snapshots. The system deletes snapshots older than this age. */
    maxSnapshotAge: string;
    /** Specifies the minimum number of snapshots to retain. Defaults to 100. */
    minSnapshotsToKeep: number;
    /** Specifies the state of maintenance operations. */
    state: NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpirationState;
}
export declare const NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpiration: S.Schema<NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpiration>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceTableMaintenanceConfigResponse {
    /** Configures compaction settings for table optimization. */
    compaction?: NamespacesTablesMaintenanceConfigsUpdateResponseCompaction | null;
    /** Configures snapshot expiration settings. */
    snapshotExpiration?: NamespacesTablesMaintenanceConfigsUpdateResponseSnapshotExpiration | null;
}
export declare const UpdateNamespaceTableMaintenanceConfigResponse: S.Schema<UpdateNamespaceTableMaintenanceConfigResponse>;
export type CreateCredentialError = InvalidRoute | InvalidCredential | CloudflareOpError;
/** Store authentication credentials for a catalog. These credentials are used to authenticate with R2 storage when performing catalog operations. */
export declare const createCredential: API.OperationMethod<CreateCredentialRequest, CreateCredentialResponse, CreateCredentialError, CloudflareOpContext>;
export type DisableR2DataCatalogError = NoSuchBucket | InvalidRoute | WarehouseNotFound | Forbidden | CloudflareOpError;
/** Disable an R2 bucket as a catalog. This operation deactivates the catalog but preserves existing metadata and data files. The catalog can be re-enabled later. */
export declare const disableR2DataCatalog: API.OperationMethod<DisableR2DataCatalogRequest, DisableR2DataCatalogResponse, DisableR2DataCatalogError, CloudflareOpContext>;
export type EnableR2DataCatalogError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Enable an R2 bucket as an Apache Iceberg catalog. This operation creates the necessary catalog infrastructure and activates the bucket for storing Iceberg metadata and data files. */
export declare const enableR2DataCatalog: API.OperationMethod<EnableR2DataCatalogRequest, EnableR2DataCatalogResponse, EnableR2DataCatalogError, CloudflareOpContext>;
export type GetMaintenanceConfigError = InvalidRoute | WarehouseInactive | WarehouseNotFound | CloudflareOpError;
/** Retrieve the maintenance configuration for a specific catalog, including compaction settings and credential status. */
export declare const getMaintenanceConfig: API.OperationMethod<GetMaintenanceConfigRequest, GetMaintenanceConfigResponse, GetMaintenanceConfigError, CloudflareOpContext>;
export type GetNamespaceTableMaintenanceConfigError = TableNotFound | InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Retrieve the maintenance configuration for a specific table, including compaction settings. */
export declare const getNamespaceTableMaintenanceConfig: API.OperationMethod<GetNamespaceTableMaintenanceConfigRequest, GetNamespaceTableMaintenanceConfigResponse, GetNamespaceTableMaintenanceConfigError, CloudflareOpContext>;
export type GetR2DataCatalogError = NoSuchBucket | InvalidRoute | WarehouseNotFound | Forbidden | CloudflareOpError;
/** Retrieve detailed information about a specific R2 catalog by bucket name. Returns catalog status, maintenance configuration, and credential status. */
export declare const getR2DataCatalog: API.OperationMethod<GetR2DataCatalogRequest, GetR2DataCatalogResponse, GetR2DataCatalogError, CloudflareOpContext>;
export type ListNamespacesError = InvalidRoute | WarehouseInactive | WarehouseNotFound | CloudflareOpError;
/** Returns a list of namespaces in the specified R2 catalog. Supports hierarchical filtering and pagination for efficient traversal of large namespace hierarchies. */
export declare const listNamespaces: API.OperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext>;
export type ListNamespaceTablesError = InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Returns a list of tables in the specified namespace within an R2 catalog. Supports pagination for efficient traversal of large table collections. */
export declare const listNamespaceTables: API.OperationMethod<ListNamespaceTablesRequest, ListNamespaceTablesResponse, ListNamespaceTablesError, CloudflareOpContext>;
export type ListR2DataCatalogsError = InvalidRoute | CloudflareOpError;
/** Returns a list of R2 buckets that have been enabled as Apache Iceberg catalogs for the specified account. Each catalog represents an R2 bucket configured to store Iceberg metadata and data files. */
export declare const listR2DataCatalogs: API.OperationMethod<ListR2DataCatalogsRequest, ListR2DataCatalogsResponse, ListR2DataCatalogsError, CloudflareOpContext>;
export type UpdateMaintenanceConfigError = InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Update the maintenance configuration for a catalog. This allows you to enable or disable compaction and adjust target file sizes for optimization. */
export declare const updateMaintenanceConfig: API.OperationMethod<UpdateMaintenanceConfigRequest, UpdateMaintenanceConfigResponse, UpdateMaintenanceConfigError, CloudflareOpContext>;
export type UpdateNamespaceTableMaintenanceConfigError = TableNotFound | InvalidRoute | WarehouseInactive | CloudflareOpError;
/** Update the maintenance configuration for a specific table. This allows you to enable or disable compaction and adjust target file sizes for optimization. */
export declare const updateNamespaceTableMaintenanceConfig: API.OperationMethod<UpdateNamespaceTableMaintenanceConfigRequest, UpdateNamespaceTableMaintenanceConfigResponse, UpdateNamespaceTableMaintenanceConfigError, CloudflareOpContext>;
//# sourceMappingURL=r2_data_catalog.d.ts.map