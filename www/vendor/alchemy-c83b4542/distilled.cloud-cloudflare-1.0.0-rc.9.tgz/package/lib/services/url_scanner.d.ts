import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type ScansBulkCreateRequestBodyItemCustomHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ScansBulkCreateRequestBodyItemCustomHeadersMap: S.Schema<ScansBulkCreateRequestBodyItemCustomHeadersMap>;
export type ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem = "desktop" | "mobile" | "tablet";
export declare const ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem: any;
export type ScansBulkCreateRequestBodyItemScreenshotsResolutionsList = Array<ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem | (string & {})>;
export declare const ScansBulkCreateRequestBodyItemScreenshotsResolutionsList: S.Schema<ScansBulkCreateRequestBodyItemScreenshotsResolutionsList>;
export type ScansBulkCreateRequestBodyItemVisibility = "Public" | "Unlisted";
export declare const ScansBulkCreateRequestBodyItemVisibility: any;
export interface ScansBulkCreateRequestBodyItem {
    url: string;
    /** Enable agent readiness checks. */
    agentReadiness?: boolean;
    customagent?: string;
    /** Set custom headers. */
    customHeaders?: ScansBulkCreateRequestBodyItemCustomHeadersMap;
    referer?: string;
    /** Take multiple screenshots targeting different device types. */
    screenshotsResolutions?: ScansBulkCreateRequestBodyItemScreenshotsResolutionsList;
    /** The option `Public` means it will be included in listings like recent scans and search results. `Unlisted` means it will not be included in the aforementioned listings, users will need to have the scan's ID to access it. A a scan will be automatically marked as unlisted if it fails, if it contains potential PII or other sensitive material. */
    visibility?: ScansBulkCreateRequestBodyItemVisibility | (string & {});
}
export declare const ScansBulkCreateRequestBodyItem: S.Schema<ScansBulkCreateRequestBodyItem>;
export type ScansBulkCreateRequestBodyList = Array<ScansBulkCreateRequestBodyItem>;
export declare const ScansBulkCreateRequestBodyList: S.Schema<ScansBulkCreateRequestBodyList>;
export interface BulkCreateScansRequest {
    /** Account ID. */
    accountId: string;
    /** List of urls to scan (up to a 100). */
    body?: ScansBulkCreateRequestBodyList;
}
export declare const BulkCreateScansRequest: S.Schema<BulkCreateScansRequest>;
export type BulkCreateScansResponse = string;
export declare const BulkCreateScansResponse: S.Schema<BulkCreateScansResponse>;
export type ScansCreateRequestCountry = "AF" | "AL" | "DZ" | "AD" | "AO" | "AG" | "AR" | "AM" | "AU" | "AT" | "AZ" | "BH" | "BD" | "BB" | "BY" | "BE" | "BZ" | "BJ" | "BM" | "BT" | "BO" | "BA" | "BW" | "BR" | "BN" | "BG" | "BF" | "BI" | "KH" | "CM" | "CA" | "CV" | "KY" | "CF" | "TD" | "CL" | "CN" | "CO" | "KM" | "CG" | "CR" | "CI" | "HR" | "CU" | "CY" | "CZ" | "CD" | "DK" | "DJ" | "DM" | "DO" | "EC" | "EG" | "SV" | "GQ" | "ER" | "EE" | "SZ" | "ET" | "FJ" | "FI" | "FR" | "GA" | "GE" | "DE" | "GH" | "GR" | "GL" | "GD" | "GT" | "GN" | "GW" | "GY" | "HT" | "HN" | "HU" | "IS" | "IN" | "ID" | "IR" | "IQ" | "IE" | "IL" | "IT" | "JM" | "JP" | "JO" | "KZ" | "KE" | "KI" | "KW" | "KG" | "LA" | "LV" | "LB" | "LS" | "LR" | "LY" | "LI" | "LT" | "LU" | "MO" | "MG" | "MW" | "MY" | "MV" | "ML" | "MR" | "MU" | "MX" | "FM" | "MD" | "MC" | "MN" | "MS" | "MA" | "MZ" | "MM" | "NA" | "NR" | "NP" | "NL" | "NZ" | "NI" | "NE" | "NG" | "KP" | "MK" | "NO" | "OM" | "PK" | "PS" | "PA" | "PG" | "PY" | "PE" | "PH" | "PL" | "PT" | "QA" | "RO" | "RU" | "RW" | "SH" | "KN" | "LC" | "VC" | "WS" | "SM" | "ST" | "SA" | "SN" | "RS" | "SC" | "SL" | "SK" | "SI" | "SB" | "SO" | "ZA" | "KR" | "SS" | "ES" | "LK" | "SD" | "SR" | "SE" | "CH" | "SY" | "TW" | "TJ" | "TZ" | "TH" | "BS" | "GM" | "TL" | "TG" | "TO" | "TT" | "TN" | "TR" | "TM" | "UG" | "UA" | "AE" | "GB" | "US" | "UY" | "UZ" | "VU" | "VE" | "VN" | "YE" | "ZM" | "ZW";
export declare const ScansCreateRequestCountry: any;
export type ScansCreateRequestCustomHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ScansCreateRequestCustomHeadersMap: S.Schema<ScansCreateRequestCustomHeadersMap>;
export type ScansCreateRequestScreenshotsResolutionsItem = "desktop" | "mobile" | "tablet";
export declare const ScansCreateRequestScreenshotsResolutionsItem: any;
export type ScansCreateRequestScreenshotsResolutionsList = Array<ScansCreateRequestScreenshotsResolutionsItem | (string & {})>;
export declare const ScansCreateRequestScreenshotsResolutionsList: S.Schema<ScansCreateRequestScreenshotsResolutionsList>;
export type ScansCreateRequestVisibility = "Public" | "Unlisted";
export declare const ScansCreateRequestVisibility: any;
export interface CreateScanRequest {
    /** Account ID. */
    accountId: string;
    url: string;
    /** Enable agent readiness checks. */
    agentReadiness?: boolean;
    /** Country to geo egress from */
    country?: ScansCreateRequestCountry | (string & {});
    customagent?: string;
    /** Set custom headers. */
    customHeaders?: ScansCreateRequestCustomHeadersMap;
    referer?: string;
    /** Take multiple screenshots targeting different device types. */
    screenshotsResolutions?: ScansCreateRequestScreenshotsResolutionsList;
    /** The option `Public` means it will be included in listings like recent scans and search results. `Unlisted` means it will not be included in the aforementioned listings, users will need to have the scan's ID to access it. A a scan will be automatically marked as unlisted if it fails, if it contains potential PII or other sensitive material. */
    visibility?: ScansCreateRequestVisibility | (string & {});
}
export declare const CreateScanRequest: S.Schema<CreateScanRequest>;
export type CreateScanResponse = string;
export declare const CreateScanResponse: S.Schema<CreateScanResponse>;
export interface DomScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export declare const DomScanRequest: S.Schema<DomScanRequest>;
export interface DomScanResponse {
}
export declare const DomScanResponse: S.Schema<DomScanResponse>;
export interface GetResponsRequest {
    /** Account ID. */
    accountId: string;
    /** Response hash. */
    responseId: string;
}
export declare const GetResponsRequest: S.Schema<GetResponsRequest>;
export interface GetResponsResponse {
}
export declare const GetResponsResponse: S.Schema<GetResponsResponse>;
export interface GetScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export declare const GetScanRequest: S.Schema<GetScanRequest>;
export interface ScansGetResponseDataConsoleItemMessage {
    level: string;
    source: string;
    text: string;
    url: string;
}
export declare const ScansGetResponseDataConsoleItemMessage: S.Schema<ScansGetResponseDataConsoleItemMessage>;
export interface ScansGetResponseDataConsoleItem {
    message: ScansGetResponseDataConsoleItemMessage;
}
export declare const ScansGetResponseDataConsoleItem: S.Schema<ScansGetResponseDataConsoleItem>;
export type ScansGetResponseDataConsoleList = Array<ScansGetResponseDataConsoleItem>;
export declare const ScansGetResponseDataConsoleList: S.Schema<ScansGetResponseDataConsoleList>;
export interface ScansGetResponseDataCookiesItem {
    domain: string;
    expires: number;
    httpOnly: boolean;
    name: string;
    path: string;
    priority: string;
    sameParty: boolean;
    secure: boolean;
    session: boolean;
    size: number;
    sourcePort: number;
    sourceScheme: string;
    value: string;
}
export declare const ScansGetResponseDataCookiesItem: S.Schema<ScansGetResponseDataCookiesItem>;
export type ScansGetResponseDataCookiesList = Array<ScansGetResponseDataCookiesItem>;
export declare const ScansGetResponseDataCookiesList: S.Schema<ScansGetResponseDataCookiesList>;
export interface ScansGetResponseDataGlobalsItem {
    prop: string;
    type: string;
}
export declare const ScansGetResponseDataGlobalsItem: S.Schema<ScansGetResponseDataGlobalsItem>;
export type ScansGetResponseDataGlobalsList = Array<ScansGetResponseDataGlobalsItem>;
export declare const ScansGetResponseDataGlobalsList: S.Schema<ScansGetResponseDataGlobalsList>;
export interface ScansGetResponseDataLinksItem {
    href: string;
    text: string;
}
export declare const ScansGetResponseDataLinksItem: S.Schema<ScansGetResponseDataLinksItem>;
export type ScansGetResponseDataLinksList = Array<ScansGetResponseDataLinksItem>;
export declare const ScansGetResponseDataLinksList: S.Schema<ScansGetResponseDataLinksList>;
export interface ScansGetResponseDataPerformanceItem {
    duration: number;
    entryType: string;
    name: string;
    startTime: number;
}
export declare const ScansGetResponseDataPerformanceItem: S.Schema<ScansGetResponseDataPerformanceItem>;
export type ScansGetResponseDataPerformanceList = Array<ScansGetResponseDataPerformanceItem>;
export declare const ScansGetResponseDataPerformanceList: S.Schema<ScansGetResponseDataPerformanceList>;
export interface ScansGetResponseDataRequestsItemRequestInitiator {
    host: string;
    type: string;
    url: string;
}
export declare const ScansGetResponseDataRequestsItemRequestInitiator: S.Schema<ScansGetResponseDataRequestsItemRequestInitiator>;
export interface ScansGetResponseDataRequestsItemRequestRequest {
    initialPriority: string;
    isSameSite: boolean;
    method: string;
    mixedContentType: string;
    referrerPolicy: string;
    url: string;
    headers?: unknown | null;
}
export declare const ScansGetResponseDataRequestsItemRequestRequest: S.Schema<ScansGetResponseDataRequestsItemRequestRequest>;
export interface ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem {
    name: string;
    value: string;
}
export declare const ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem: S.Schema<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export type ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export declare const ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList: S.Schema<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList>;
export interface ScansGetResponseDataRequestsItemRequestRedirectResponse {
    charset: string;
    mimeType: string;
    protocol: string;
    remoteIPAddress: string;
    remotePort: number;
    securityHeaders: ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList;
    securityState: string;
    status: number;
    statusText: string;
    url: string;
    headers?: unknown | null;
}
export declare const ScansGetResponseDataRequestsItemRequestRedirectResponse: S.Schema<ScansGetResponseDataRequestsItemRequestRedirectResponse>;
export interface ScansGetResponseDataRequestsItemRequest {
    documentURL: string;
    hasUserGesture: boolean;
    initiator: ScansGetResponseDataRequestsItemRequestInitiator;
    redirectHasExtraInfo: boolean;
    request: ScansGetResponseDataRequestsItemRequestRequest;
    requestId: string;
    type: string;
    wallTime: number;
    frameId?: string | null;
    loaderId?: string | null;
    primaryRequest?: boolean | null;
    redirectResponse?: ScansGetResponseDataRequestsItemRequestRedirectResponse | null;
}
export declare const ScansGetResponseDataRequestsItemRequest: S.Schema<ScansGetResponseDataRequestsItemRequest>;
export interface ScansGetResponseDataRequestsItemResponseAsn {
    asn: string;
    country: string;
    description: string;
    ip: string;
    name: string;
    org: string;
}
export declare const ScansGetResponseDataRequestsItemResponseAsn: S.Schema<ScansGetResponseDataRequestsItemResponseAsn>;
export type ScansGetResponseDataRequestsItemResponseGeoipLlList = Array<number>;
export declare const ScansGetResponseDataRequestsItemResponseGeoipLlList: S.Schema<ScansGetResponseDataRequestsItemResponseGeoipLlList>;
export interface ScansGetResponseDataRequestsItemResponseGeoip {
    city: string;
    country: string;
    countryName: string;
    geonameId: string;
    ll: ScansGetResponseDataRequestsItemResponseGeoipLlList;
    region: string;
}
export declare const ScansGetResponseDataRequestsItemResponseGeoip: S.Schema<ScansGetResponseDataRequestsItemResponseGeoip>;
export type ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList = Array<string>;
export declare const ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList: S.Schema<ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList>;
export interface ScansGetResponseDataRequestsItemResponseResponseSecurityDetails {
    certificateId: number;
    certificateTransparencyCompliance: string;
    cipher: string;
    encryptedClientHello: boolean;
    issuer: string;
    keyExchange: string;
    keyExchangeGroup: string;
    protocol: string;
    sanList: ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList;
    serverSignatureAlgorithm: number;
    subjectName: string;
    validFrom: number;
    validTo: number;
}
export declare const ScansGetResponseDataRequestsItemResponseResponseSecurityDetails: S.Schema<ScansGetResponseDataRequestsItemResponseResponseSecurityDetails>;
export type ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export declare const ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersItem: S.Schema<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export type ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export declare const ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList: S.Schema<ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList>;
export interface ScansGetResponseDataRequestsItemResponseResponse {
    charset: string;
    mimeType: string;
    protocol: string;
    remoteIPAddress: string;
    remotePort: number;
    securityDetails: ScansGetResponseDataRequestsItemResponseResponseSecurityDetails;
    securityHeaders: ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList;
    securityState: string;
    status: number;
    statusText: string;
    url: string;
    headers?: unknown | null;
}
export declare const ScansGetResponseDataRequestsItemResponseResponse: S.Schema<ScansGetResponseDataRequestsItemResponseResponse>;
export interface ScansGetResponseDataRequestsItemResponse {
    asn: ScansGetResponseDataRequestsItemResponseAsn;
    dataLength: number;
    encodedDataLength: number;
    geoip: ScansGetResponseDataRequestsItemResponseGeoip;
    hasExtraInfo: boolean;
    requestId: string;
    response: ScansGetResponseDataRequestsItemResponseResponse;
    size: number;
    type: string;
    contentAvailable?: boolean | null;
    hash?: string | null;
}
export declare const ScansGetResponseDataRequestsItemResponse: S.Schema<ScansGetResponseDataRequestsItemResponse>;
export interface ScansGetResponseDataRequestsItemRequestsItemInitiator {
    type: string;
}
export declare const ScansGetResponseDataRequestsItemRequestsItemInitiator: S.Schema<ScansGetResponseDataRequestsItemRequestsItemInitiator>;
export interface ScansGetResponseDataRequestsItemRequestsItemRequestHeaders {
    name: string;
}
export declare const ScansGetResponseDataRequestsItemRequestsItemRequestHeaders: S.Schema<ScansGetResponseDataRequestsItemRequestsItemRequestHeaders>;
export interface ScansGetResponseDataRequestsItemRequestsItemRequest {
    headers: ScansGetResponseDataRequestsItemRequestsItemRequestHeaders;
    initialPriority: string;
    isSameSite: boolean;
    method: string;
    mixedContentType: string;
    referrerPolicy: string;
    url: string;
}
export declare const ScansGetResponseDataRequestsItemRequestsItemRequest: S.Schema<ScansGetResponseDataRequestsItemRequestsItemRequest>;
export interface ScansGetResponseDataRequestsItemRequestsItem {
    documentURL: string;
    frameId: string;
    hasUserGesture: boolean;
    initiator: ScansGetResponseDataRequestsItemRequestsItemInitiator;
    loaderId: string;
    redirectHasExtraInfo: boolean;
    request: ScansGetResponseDataRequestsItemRequestsItemRequest;
    requestId: string;
    type: string;
    wallTime: number;
}
export declare const ScansGetResponseDataRequestsItemRequestsItem: S.Schema<ScansGetResponseDataRequestsItemRequestsItem>;
export type ScansGetResponseDataRequestsItemRequestsList = Array<ScansGetResponseDataRequestsItemRequestsItem>;
export declare const ScansGetResponseDataRequestsItemRequestsList: S.Schema<ScansGetResponseDataRequestsItemRequestsList>;
export interface ScansGetResponseDataRequestsItem {
    request: ScansGetResponseDataRequestsItemRequest;
    response: ScansGetResponseDataRequestsItemResponse;
    requests?: ScansGetResponseDataRequestsItemRequestsList | null;
}
export declare const ScansGetResponseDataRequestsItem: S.Schema<ScansGetResponseDataRequestsItem>;
export type ScansGetResponseDataRequestsList = Array<ScansGetResponseDataRequestsItem>;
export declare const ScansGetResponseDataRequestsList: S.Schema<ScansGetResponseDataRequestsList>;
export interface ScansGetResponseData {
    console: ScansGetResponseDataConsoleList;
    cookies: ScansGetResponseDataCookiesList;
    globals: ScansGetResponseDataGlobalsList;
    links: ScansGetResponseDataLinksList;
    performance: ScansGetResponseDataPerformanceList;
    requests: ScansGetResponseDataRequestsList;
}
export declare const ScansGetResponseData: S.Schema<ScansGetResponseData>;
export type ScansGetResponseListsAsnsList = Array<string>;
export declare const ScansGetResponseListsAsnsList: S.Schema<ScansGetResponseListsAsnsList>;
export interface ScansGetResponseListsCertificatesItem {
    issuer: string;
    subjectName: string;
    validFrom: number;
    validTo: number;
}
export declare const ScansGetResponseListsCertificatesItem: S.Schema<ScansGetResponseListsCertificatesItem>;
export type ScansGetResponseListsCertificatesList = Array<ScansGetResponseListsCertificatesItem>;
export declare const ScansGetResponseListsCertificatesList: S.Schema<ScansGetResponseListsCertificatesList>;
export type ScansGetResponseListsContinentsList = Array<string>;
export declare const ScansGetResponseListsContinentsList: S.Schema<ScansGetResponseListsContinentsList>;
export type ScansGetResponseListsCountriesList = Array<string>;
export declare const ScansGetResponseListsCountriesList: S.Schema<ScansGetResponseListsCountriesList>;
export type ScansGetResponseListsDomainsList = Array<string>;
export declare const ScansGetResponseListsDomainsList: S.Schema<ScansGetResponseListsDomainsList>;
export type ScansGetResponseListsHashesList = Array<string>;
export declare const ScansGetResponseListsHashesList: S.Schema<ScansGetResponseListsHashesList>;
export type ScansGetResponseListsIpsList = Array<string>;
export declare const ScansGetResponseListsIpsList: S.Schema<ScansGetResponseListsIpsList>;
export type ScansGetResponseListsLinkDomainsList = Array<string>;
export declare const ScansGetResponseListsLinkDomainsList: S.Schema<ScansGetResponseListsLinkDomainsList>;
export type ScansGetResponseListsServersList = Array<string>;
export declare const ScansGetResponseListsServersList: S.Schema<ScansGetResponseListsServersList>;
export type ScansGetResponseListsUrlsList = Array<string>;
export declare const ScansGetResponseListsUrlsList: S.Schema<ScansGetResponseListsUrlsList>;
export interface ScansGetResponseLists {
    asns: ScansGetResponseListsAsnsList;
    certificates: ScansGetResponseListsCertificatesList;
    continents: ScansGetResponseListsContinentsList;
    countries: ScansGetResponseListsCountriesList;
    domains: ScansGetResponseListsDomainsList;
    hashes: ScansGetResponseListsHashesList;
    ips: ScansGetResponseListsIpsList;
    linkDomains: ScansGetResponseListsLinkDomainsList;
    servers: ScansGetResponseListsServersList;
    urls: ScansGetResponseListsUrlsList;
}
export declare const ScansGetResponseLists: S.Schema<ScansGetResponseLists>;
export interface ScansGetResponseMetaProcessorsAsnDataItem {
    asn: string;
    country: string;
    description: string;
    ip: string;
    name: string;
}
export declare const ScansGetResponseMetaProcessorsAsnDataItem: S.Schema<ScansGetResponseMetaProcessorsAsnDataItem>;
export type ScansGetResponseMetaProcessorsAsnDataList = Array<ScansGetResponseMetaProcessorsAsnDataItem>;
export declare const ScansGetResponseMetaProcessorsAsnDataList: S.Schema<ScansGetResponseMetaProcessorsAsnDataList>;
export interface ScansGetResponseMetaProcessorsAsn {
    data: ScansGetResponseMetaProcessorsAsnDataList;
}
export declare const ScansGetResponseMetaProcessorsAsn: S.Schema<ScansGetResponseMetaProcessorsAsn>;
export interface ScansGetResponseMetaProcessorsDnsDataItem {
    address: string;
    dnssecValid: boolean;
    name: string;
    type: string;
}
export declare const ScansGetResponseMetaProcessorsDnsDataItem: S.Schema<ScansGetResponseMetaProcessorsDnsDataItem>;
export type ScansGetResponseMetaProcessorsDnsDataList = Array<ScansGetResponseMetaProcessorsDnsDataItem>;
export declare const ScansGetResponseMetaProcessorsDnsDataList: S.Schema<ScansGetResponseMetaProcessorsDnsDataList>;
export interface ScansGetResponseMetaProcessorsDns {
    data: ScansGetResponseMetaProcessorsDnsDataList;
}
export declare const ScansGetResponseMetaProcessorsDns: S.Schema<ScansGetResponseMetaProcessorsDns>;
export interface ScansGetResponseMetaProcessorsDomainCategoriesDataItem {
    inherited: unknown;
    isPrimary: boolean;
    name: string;
}
export declare const ScansGetResponseMetaProcessorsDomainCategoriesDataItem: S.Schema<ScansGetResponseMetaProcessorsDomainCategoriesDataItem>;
export type ScansGetResponseMetaProcessorsDomainCategoriesDataList = Array<ScansGetResponseMetaProcessorsDomainCategoriesDataItem>;
export declare const ScansGetResponseMetaProcessorsDomainCategoriesDataList: S.Schema<ScansGetResponseMetaProcessorsDomainCategoriesDataList>;
export interface ScansGetResponseMetaProcessorsDomainCategories {
    data: ScansGetResponseMetaProcessorsDomainCategoriesDataList;
}
export declare const ScansGetResponseMetaProcessorsDomainCategories: S.Schema<ScansGetResponseMetaProcessorsDomainCategories>;
export type ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList = Array<number>;
export declare const ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList: S.Schema<ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList>;
export interface ScansGetResponseMetaProcessorsGeoipDataItemGeoip {
    city: string;
    country: string;
    countryName: string;
    ll: ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList;
    region: string;
}
export declare const ScansGetResponseMetaProcessorsGeoipDataItemGeoip: S.Schema<ScansGetResponseMetaProcessorsGeoipDataItemGeoip>;
export interface ScansGetResponseMetaProcessorsGeoipDataItem {
    geoip: ScansGetResponseMetaProcessorsGeoipDataItemGeoip;
    ip: string;
}
export declare const ScansGetResponseMetaProcessorsGeoipDataItem: S.Schema<ScansGetResponseMetaProcessorsGeoipDataItem>;
export type ScansGetResponseMetaProcessorsGeoipDataList = Array<ScansGetResponseMetaProcessorsGeoipDataItem>;
export declare const ScansGetResponseMetaProcessorsGeoipDataList: S.Schema<ScansGetResponseMetaProcessorsGeoipDataList>;
export interface ScansGetResponseMetaProcessorsGeoip {
    data: ScansGetResponseMetaProcessorsGeoipDataList;
}
export declare const ScansGetResponseMetaProcessorsGeoip: S.Schema<ScansGetResponseMetaProcessorsGeoip>;
export type ScansGetResponseMetaProcessorsPhishingDataList = Array<string>;
export declare const ScansGetResponseMetaProcessorsPhishingDataList: S.Schema<ScansGetResponseMetaProcessorsPhishingDataList>;
export interface ScansGetResponseMetaProcessorsPhishing {
    data: ScansGetResponseMetaProcessorsPhishingDataList;
}
export declare const ScansGetResponseMetaProcessorsPhishing: S.Schema<ScansGetResponseMetaProcessorsPhishing>;
export interface ScansGetResponseMetaProcessorsRadarRankDataItem {
    bucket: string;
    hostname: string;
    rank?: number | null;
}
export declare const ScansGetResponseMetaProcessorsRadarRankDataItem: S.Schema<ScansGetResponseMetaProcessorsRadarRankDataItem>;
export type ScansGetResponseMetaProcessorsRadarRankDataList = Array<ScansGetResponseMetaProcessorsRadarRankDataItem>;
export declare const ScansGetResponseMetaProcessorsRadarRankDataList: S.Schema<ScansGetResponseMetaProcessorsRadarRankDataList>;
export interface ScansGetResponseMetaProcessorsRadarRank {
    data: ScansGetResponseMetaProcessorsRadarRankDataList;
}
export declare const ScansGetResponseMetaProcessorsRadarRank: S.Schema<ScansGetResponseMetaProcessorsRadarRank>;
export interface ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem {
    name: string;
    priority: number;
}
export declare const ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem: S.Schema<ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem>;
export type ScansGetResponseMetaProcessorsWappaDataItemCategoriesList = Array<ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem>;
export declare const ScansGetResponseMetaProcessorsWappaDataItemCategoriesList: S.Schema<ScansGetResponseMetaProcessorsWappaDataItemCategoriesList>;
export interface ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem {
    confidence: number;
    name: string;
    pattern: string;
    patternType: string;
}
export declare const ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem: S.Schema<ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem>;
export type ScansGetResponseMetaProcessorsWappaDataItemConfidenceList = Array<ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem>;
export declare const ScansGetResponseMetaProcessorsWappaDataItemConfidenceList: S.Schema<ScansGetResponseMetaProcessorsWappaDataItemConfidenceList>;
export interface ScansGetResponseMetaProcessorsWappaDataItem {
    app: string;
    categories: ScansGetResponseMetaProcessorsWappaDataItemCategoriesList;
    confidence: ScansGetResponseMetaProcessorsWappaDataItemConfidenceList;
    confidenceTotal: number;
    icon: string;
    website: string;
}
export declare const ScansGetResponseMetaProcessorsWappaDataItem: S.Schema<ScansGetResponseMetaProcessorsWappaDataItem>;
export type ScansGetResponseMetaProcessorsWappaDataList = Array<ScansGetResponseMetaProcessorsWappaDataItem>;
export declare const ScansGetResponseMetaProcessorsWappaDataList: S.Schema<ScansGetResponseMetaProcessorsWappaDataList>;
export interface ScansGetResponseMetaProcessorsWappa {
    data: ScansGetResponseMetaProcessorsWappaDataList;
}
export declare const ScansGetResponseMetaProcessorsWappa: S.Schema<ScansGetResponseMetaProcessorsWappa>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding {
    outcome: string;
    summary: string;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest {
    method: string;
    url: string;
    headers?: unknown | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse {
    status: number;
    statusText: string;
    bodyPreview?: string | null;
    bodySize?: number | null;
    headers?: unknown | null;
    redirectedTo?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem {
    action: string;
    label: string;
    finding?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding | null;
    request?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest | null;
    response?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl {
    contentSignals: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals;
    robotsTxtAiRules: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules;
    webBotAuth: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2 {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402 {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce {
    acp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp;
    ap2: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2;
    mpp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp;
    ucp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp;
    x402: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility {
    markdownNegotiation: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability {
    linkHeaders: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders;
    robotsTxt: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt;
    sitemap: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemFinding: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemRequest: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemResponse: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp {
    status: string;
    details?: unknown | null;
    durationMs?: number | null;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList | null;
    message?: string | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery {
    a2aAgentCard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard;
    agentSkills: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills;
    apiCatalog: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog;
    mcpServerCard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard;
    oauthDiscovery: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery;
    oauthProtectedResource: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource;
    webMcp: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecks {
    botAccessControl: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl;
    commerce: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce;
    contentAccessibility: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility;
    discoverability: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability;
    discovery: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessChecks: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessChecks>;
export type ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList = Array<string>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList>;
export type ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList = Array<string>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem {
    check: string;
    description: string;
    prompt: string;
    skillUrl: string;
    specUrls: ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList = Array<ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem>;
export declare const ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList>;
export interface ScansGetResponseMetaProcessorsAgentReadinessNextLevel {
    name: string;
    requirements: ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList;
    target: number;
}
export declare const ScansGetResponseMetaProcessorsAgentReadinessNextLevel: S.Schema<ScansGetResponseMetaProcessorsAgentReadinessNextLevel>;
export interface ScansGetResponseMetaProcessorsAgentReadiness {
    checks: ScansGetResponseMetaProcessorsAgentReadinessChecks;
    level: number;
    levelName: string;
    commerceSignals?: ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList | null;
    isCommerce?: boolean | null;
    nextLevel?: ScansGetResponseMetaProcessorsAgentReadinessNextLevel | null;
}
export declare const ScansGetResponseMetaProcessorsAgentReadiness: S.Schema<ScansGetResponseMetaProcessorsAgentReadiness>;
export type ScansGetResponseMetaProcessorsPhishingV2DataList = Array<string>;
export declare const ScansGetResponseMetaProcessorsPhishingV2DataList: S.Schema<ScansGetResponseMetaProcessorsPhishingV2DataList>;
export interface ScansGetResponseMetaProcessorsPhishingV2 {
    data: ScansGetResponseMetaProcessorsPhishingV2DataList;
}
export declare const ScansGetResponseMetaProcessorsPhishingV2: S.Schema<ScansGetResponseMetaProcessorsPhishingV2>;
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeAllowList = Array<string>;
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeAllowList: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeAllowList>;
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeDisallowList = Array<string>;
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeDisallowList: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeDisallowList>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeContentSignal {
    aiInput?: string | null;
    aiTrain?: string | null;
    search?: string | null;
}
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeContentSignal: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeContentSignal>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShape {
    allow: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeAllowList;
    disallow: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeDisallowList;
    contentSignal?: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShapeContentSignal | null;
    crawlDelay?: number | null;
}
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShape: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShape>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRules {
    "": ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesShape;
}
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItemRules: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItemRules>;
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList = Array<string>;
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItem {
    rules: ScansGetResponseMetaProcessorsRobotsTxtDataItemRules;
    sitemaps: ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList;
    hash?: string | null;
}
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataItem: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataItem>;
export type ScansGetResponseMetaProcessorsRobotsTxtDataList = Array<ScansGetResponseMetaProcessorsRobotsTxtDataItem>;
export declare const ScansGetResponseMetaProcessorsRobotsTxtDataList: S.Schema<ScansGetResponseMetaProcessorsRobotsTxtDataList>;
export interface ScansGetResponseMetaProcessorsRobotsTxt {
    data: ScansGetResponseMetaProcessorsRobotsTxtDataList;
}
export declare const ScansGetResponseMetaProcessorsRobotsTxt: S.Schema<ScansGetResponseMetaProcessorsRobotsTxt>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem {
    id: number;
    name: string;
    superCategoryId: number;
}
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentItem: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksItem: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited {
    content: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList;
    from: string;
    risks: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList;
}
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksItem: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItem {
    content: ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList;
    inherited: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited;
    name: string;
    risks: ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList;
}
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataItem: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItem>;
export declare const ScansGetResponseMetaProcessorsUrlCategoriesDataList: S.Schema<ScansGetResponseMetaProcessorsUrlCategoriesDataList>;
export interface ScansGetResponseMetaProcessorsUrlCategories {
    data: ScansGetResponseMetaProcessorsUrlCategoriesDataList;
}
export declare const ScansGetResponseMetaProcessorsUrlCategories: S.Schema<ScansGetResponseMetaProcessorsUrlCategories>;
export interface ScansGetResponseMetaProcessors {
    asn: ScansGetResponseMetaProcessorsAsn;
    dns: ScansGetResponseMetaProcessorsDns;
    domainCategories: ScansGetResponseMetaProcessorsDomainCategories;
    geoip: ScansGetResponseMetaProcessorsGeoip;
    phishing: ScansGetResponseMetaProcessorsPhishing;
    radarRank: ScansGetResponseMetaProcessorsRadarRank;
    wappa: ScansGetResponseMetaProcessorsWappa;
    agentReadiness?: ScansGetResponseMetaProcessorsAgentReadiness | null;
    phishingV2?: ScansGetResponseMetaProcessorsPhishingV2 | null;
    robotsTxt?: ScansGetResponseMetaProcessorsRobotsTxt | null;
    urlCategories?: ScansGetResponseMetaProcessorsUrlCategories | null;
}
export declare const ScansGetResponseMetaProcessors: S.Schema<ScansGetResponseMetaProcessors>;
export interface ScansGetResponseMeta {
    processors: ScansGetResponseMetaProcessors;
}
export declare const ScansGetResponseMeta: S.Schema<ScansGetResponseMeta>;
export interface ScansGetResponsePageScreenshot {
    dhash: string;
    mm3Hash: number;
    name: string;
    phash: string;
}
export declare const ScansGetResponsePageScreenshot: S.Schema<ScansGetResponsePageScreenshot>;
export interface ScansGetResponsePage {
    apexDomain: string;
    asn: string;
    asnname: string;
    city: string;
    country: string;
    domain: string;
    ip: string;
    mimeType: string;
    server: string;
    status: string;
    title: string;
    tlsAgeDays: number;
    tlsIssuer: string;
    tlsValidDays: number;
    tlsValidFrom: string;
    url: string;
    screenshot?: ScansGetResponsePageScreenshot | null;
}
export declare const ScansGetResponsePage: S.Schema<ScansGetResponsePage>;
export interface ScansGetResponseScanner {
    colo: string;
    country: string;
}
export declare const ScansGetResponseScanner: S.Schema<ScansGetResponseScanner>;
export type ScansGetResponseStatsDomainStatsItemCountriesList = Array<string>;
export declare const ScansGetResponseStatsDomainStatsItemCountriesList: S.Schema<ScansGetResponseStatsDomainStatsItemCountriesList>;
export type ScansGetResponseStatsDomainStatsItemInitiatorsList = Array<string>;
export declare const ScansGetResponseStatsDomainStatsItemInitiatorsList: S.Schema<ScansGetResponseStatsDomainStatsItemInitiatorsList>;
export type ScansGetResponseStatsDomainStatsItemIpsList = Array<string>;
export declare const ScansGetResponseStatsDomainStatsItemIpsList: S.Schema<ScansGetResponseStatsDomainStatsItemIpsList>;
export interface ScansGetResponseStatsDomainStatsItem {
    count: number;
    countries: ScansGetResponseStatsDomainStatsItemCountriesList;
    domain: string;
    encodedSize: number;
    index: number;
    initiators: ScansGetResponseStatsDomainStatsItemInitiatorsList;
    ips: ScansGetResponseStatsDomainStatsItemIpsList;
    redirects: number;
    size: number;
}
export declare const ScansGetResponseStatsDomainStatsItem: S.Schema<ScansGetResponseStatsDomainStatsItem>;
export type ScansGetResponseStatsDomainStatsList = Array<ScansGetResponseStatsDomainStatsItem>;
export declare const ScansGetResponseStatsDomainStatsList: S.Schema<ScansGetResponseStatsDomainStatsList>;
export type ScansGetResponseStatsIpStatsItemAsn = ScansGetResponseDataRequestsItemResponseAsn;
export declare const ScansGetResponseStatsIpStatsItemAsn: S.Schema<ScansGetResponseDataRequestsItemResponseAsn>;
export type ScansGetResponseStatsIpStatsItemCountriesList = Array<string>;
export declare const ScansGetResponseStatsIpStatsItemCountriesList: S.Schema<ScansGetResponseStatsIpStatsItemCountriesList>;
export type ScansGetResponseStatsIpStatsItemDomainsList = Array<string>;
export declare const ScansGetResponseStatsIpStatsItemDomainsList: S.Schema<ScansGetResponseStatsIpStatsItemDomainsList>;
export type ScansGetResponseStatsIpStatsItemGeoipLlList = Array<number>;
export declare const ScansGetResponseStatsIpStatsItemGeoipLlList: S.Schema<ScansGetResponseStatsIpStatsItemGeoipLlList>;
export interface ScansGetResponseStatsIpStatsItemGeoip {
    city: string;
    country: string;
    countryName: string;
    ll: ScansGetResponseStatsIpStatsItemGeoipLlList;
    region: string;
}
export declare const ScansGetResponseStatsIpStatsItemGeoip: S.Schema<ScansGetResponseStatsIpStatsItemGeoip>;
export interface ScansGetResponseStatsIpStatsItem {
    asn: ScansGetResponseDataRequestsItemResponseAsn;
    countries: ScansGetResponseStatsIpStatsItemCountriesList;
    domains: ScansGetResponseStatsIpStatsItemDomainsList;
    encodedSize: number;
    geoip: ScansGetResponseStatsIpStatsItemGeoip;
    index: number;
    ip: string;
    ipv6: boolean;
    redirects: number;
    requests: number;
    size: number;
    count?: number | null;
}
export declare const ScansGetResponseStatsIpStatsItem: S.Schema<ScansGetResponseStatsIpStatsItem>;
export type ScansGetResponseStatsIpStatsList = Array<ScansGetResponseStatsIpStatsItem>;
export declare const ScansGetResponseStatsIpStatsList: S.Schema<ScansGetResponseStatsIpStatsList>;
export type ScansGetResponseStatsProtocolStatsItemCountriesList = Array<string>;
export declare const ScansGetResponseStatsProtocolStatsItemCountriesList: S.Schema<ScansGetResponseStatsProtocolStatsItemCountriesList>;
export type ScansGetResponseStatsProtocolStatsItemIpsList = Array<string>;
export declare const ScansGetResponseStatsProtocolStatsItemIpsList: S.Schema<ScansGetResponseStatsProtocolStatsItemIpsList>;
export interface ScansGetResponseStatsProtocolStatsItem {
    count: number;
    countries: ScansGetResponseStatsProtocolStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsProtocolStatsItemIpsList;
    protocol: string;
    size: number;
}
export declare const ScansGetResponseStatsProtocolStatsItem: S.Schema<ScansGetResponseStatsProtocolStatsItem>;
export type ScansGetResponseStatsProtocolStatsList = Array<ScansGetResponseStatsProtocolStatsItem>;
export declare const ScansGetResponseStatsProtocolStatsList: S.Schema<ScansGetResponseStatsProtocolStatsList>;
export type ScansGetResponseStatsResourceStatsItemCountriesList = Array<string>;
export declare const ScansGetResponseStatsResourceStatsItemCountriesList: S.Schema<ScansGetResponseStatsResourceStatsItemCountriesList>;
export type ScansGetResponseStatsResourceStatsItemIpsList = Array<string>;
export declare const ScansGetResponseStatsResourceStatsItemIpsList: S.Schema<ScansGetResponseStatsResourceStatsItemIpsList>;
export interface ScansGetResponseStatsResourceStatsItem {
    compression: number;
    count: number;
    countries: ScansGetResponseStatsResourceStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsResourceStatsItemIpsList;
    percentage: number;
    size: number;
    type: string;
}
export declare const ScansGetResponseStatsResourceStatsItem: S.Schema<ScansGetResponseStatsResourceStatsItem>;
export type ScansGetResponseStatsResourceStatsList = Array<ScansGetResponseStatsResourceStatsItem>;
export declare const ScansGetResponseStatsResourceStatsList: S.Schema<ScansGetResponseStatsResourceStatsList>;
export type ScansGetResponseStatsServerStatsItemCountriesList = Array<string>;
export declare const ScansGetResponseStatsServerStatsItemCountriesList: S.Schema<ScansGetResponseStatsServerStatsItemCountriesList>;
export type ScansGetResponseStatsServerStatsItemIpsList = Array<string>;
export declare const ScansGetResponseStatsServerStatsItemIpsList: S.Schema<ScansGetResponseStatsServerStatsItemIpsList>;
export interface ScansGetResponseStatsServerStatsItem {
    count: number;
    countries: ScansGetResponseStatsServerStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsServerStatsItemIpsList;
    server: string;
    size: number;
}
export declare const ScansGetResponseStatsServerStatsItem: S.Schema<ScansGetResponseStatsServerStatsItem>;
export type ScansGetResponseStatsServerStatsList = Array<ScansGetResponseStatsServerStatsItem>;
export declare const ScansGetResponseStatsServerStatsList: S.Schema<ScansGetResponseStatsServerStatsList>;
export type ScansGetResponseStatsTlsStatsItemCountriesList = Array<string>;
export declare const ScansGetResponseStatsTlsStatsItemCountriesList: S.Schema<ScansGetResponseStatsTlsStatsItemCountriesList>;
export type ScansGetResponseStatsTlsStatsItemIpsList = Array<string>;
export declare const ScansGetResponseStatsTlsStatsItemIpsList: S.Schema<ScansGetResponseStatsTlsStatsItemIpsList>;
export interface ScansGetResponseStatsTlsStatsItemProtocols {
    TLS_1_3___AES_128_GCM: number;
}
export declare const ScansGetResponseStatsTlsStatsItemProtocols: S.Schema<ScansGetResponseStatsTlsStatsItemProtocols>;
export interface ScansGetResponseStatsTlsStatsItem {
    count: number;
    countries: ScansGetResponseStatsTlsStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsTlsStatsItemIpsList;
    protocols: ScansGetResponseStatsTlsStatsItemProtocols;
    securityState: string;
    size: number;
}
export declare const ScansGetResponseStatsTlsStatsItem: S.Schema<ScansGetResponseStatsTlsStatsItem>;
export type ScansGetResponseStatsTlsStatsList = Array<ScansGetResponseStatsTlsStatsItem>;
export declare const ScansGetResponseStatsTlsStatsList: S.Schema<ScansGetResponseStatsTlsStatsList>;
export interface ScansGetResponseStats {
    domainStats: ScansGetResponseStatsDomainStatsList;
    ipStats: ScansGetResponseStatsIpStatsList;
    iPv6Percentage: number;
    malicious: number;
    protocolStats: ScansGetResponseStatsProtocolStatsList;
    resourceStats: ScansGetResponseStatsResourceStatsList;
    securePercentage: number;
    secureRequests: number;
    serverStats: ScansGetResponseStatsServerStatsList;
    tlsStats: ScansGetResponseStatsTlsStatsList;
    totalLinks: number;
    uniqASNs: number;
    uniqCountries: number;
}
export declare const ScansGetResponseStats: S.Schema<ScansGetResponseStats>;
export type ScansGetResponseTaskOptionsScreenshotsResolutionsList = Array<string>;
export declare const ScansGetResponseTaskOptionsScreenshotsResolutionsList: S.Schema<ScansGetResponseTaskOptionsScreenshotsResolutionsList>;
export interface ScansGetResponseTaskOptions {
    /** Custom headers set. */
    customHeaders?: unknown | null;
    screenshotsResolutions?: ScansGetResponseTaskOptionsScreenshotsResolutionsList | null;
}
export declare const ScansGetResponseTaskOptions: S.Schema<ScansGetResponseTaskOptions>;
export interface ScansGetResponseTask {
    apexDomain: string;
    domain: string;
    domURL: string;
    method: string;
    options: ScansGetResponseTaskOptions;
    reportURL: string;
    screenshotURL: string;
    source: string;
    success: boolean;
    time: string;
    url: string;
    uuid: string;
    visibility: string;
}
export declare const ScansGetResponseTask: S.Schema<ScansGetResponseTask>;
export type ScansGetResponseVerdictsOverallCategoriesList = Array<string>;
export declare const ScansGetResponseVerdictsOverallCategoriesList: S.Schema<ScansGetResponseVerdictsOverallCategoriesList>;
export type ScansGetResponseVerdictsOverallTagsList = Array<string>;
export declare const ScansGetResponseVerdictsOverallTagsList: S.Schema<ScansGetResponseVerdictsOverallTagsList>;
export interface ScansGetResponseVerdictsOverall {
    categories: ScansGetResponseVerdictsOverallCategoriesList;
    hasVerdicts: boolean;
    malicious: boolean;
    tags: ScansGetResponseVerdictsOverallTagsList;
}
export declare const ScansGetResponseVerdictsOverall: S.Schema<ScansGetResponseVerdictsOverall>;
export interface ScansGetResponseVerdicts {
    overall: ScansGetResponseVerdictsOverall;
}
export declare const ScansGetResponseVerdicts: S.Schema<ScansGetResponseVerdicts>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetScanResponse {
    data: ScansGetResponseData;
    lists: ScansGetResponseLists;
    meta: ScansGetResponseMeta;
    page: ScansGetResponsePage;
    scanner: ScansGetResponseScanner;
    stats: ScansGetResponseStats;
    task: ScansGetResponseTask;
    verdicts: ScansGetResponseVerdicts;
}
export declare const GetScanResponse: S.Schema<GetScanResponse>;
export interface HarScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export declare const HarScanRequest: S.Schema<HarScanRequest>;
export interface ScansHarResponseLogCreator {
    comment: string;
    name: string;
    version: string;
}
export declare const ScansHarResponseLogCreator: S.Schema<ScansHarResponseLogCreator>;
export type ScansHarResponseLogEntriesItemRequestHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export declare const ScansHarResponseLogEntriesItemRequestHeadersItem: S.Schema<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export type ScansHarResponseLogEntriesItemRequestHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export declare const ScansHarResponseLogEntriesItemRequestHeadersList: S.Schema<ScansHarResponseLogEntriesItemRequestHeadersList>;
export interface ScansHarResponseLogEntriesItemRequest {
    bodySize: number;
    headers: ScansHarResponseLogEntriesItemRequestHeadersList;
    headersSize: number;
    httpVersion: string;
    method: string;
    url: string;
}
export declare const ScansHarResponseLogEntriesItemRequest: S.Schema<ScansHarResponseLogEntriesItemRequest>;
export interface ScansHarResponseLogEntriesItemResponseContent {
    mimeType: string;
    size: number;
    compression?: number | null;
}
export declare const ScansHarResponseLogEntriesItemResponseContent: S.Schema<ScansHarResponseLogEntriesItemResponseContent>;
export type ScansHarResponseLogEntriesItemResponseHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export declare const ScansHarResponseLogEntriesItemResponseHeadersItem: S.Schema<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export type ScansHarResponseLogEntriesItemResponseHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export declare const ScansHarResponseLogEntriesItemResponseHeadersList: S.Schema<ScansHarResponseLogEntriesItemResponseHeadersList>;
export interface ScansHarResponseLogEntriesItemResponse {
    transferSize: number;
    bodySize: number;
    content: ScansHarResponseLogEntriesItemResponseContent;
    headers: ScansHarResponseLogEntriesItemResponseHeadersList;
    headersSize: number;
    httpVersion: string;
    redirectURL: string;
    status: number;
    statusText: string;
}
export declare const ScansHarResponseLogEntriesItemResponse: S.Schema<ScansHarResponseLogEntriesItemResponse>;
export interface ScansHarResponseLogEntriesItem {
    initialPriority: string;
    initiatorType: string;
    priority: string;
    requestId: string;
    requestTime: number;
    resourceType: string;
    cache: unknown;
    connection: string;
    pageref: string;
    request: ScansHarResponseLogEntriesItemRequest;
    response: ScansHarResponseLogEntriesItemResponse;
    serverIPAddress: string;
    startedDateTime: string;
    time: number;
}
export declare const ScansHarResponseLogEntriesItem: S.Schema<ScansHarResponseLogEntriesItem>;
export type ScansHarResponseLogEntriesList = Array<ScansHarResponseLogEntriesItem>;
export declare const ScansHarResponseLogEntriesList: S.Schema<ScansHarResponseLogEntriesList>;
export interface ScansHarResponseLogPagesItemPageTimings {
    onContentLoad: number;
    onLoad: number;
}
export declare const ScansHarResponseLogPagesItemPageTimings: S.Schema<ScansHarResponseLogPagesItemPageTimings>;
export interface ScansHarResponseLogPagesItem {
    id: string;
    pageTimings: ScansHarResponseLogPagesItemPageTimings;
    startedDateTime: string;
    title: string;
}
export declare const ScansHarResponseLogPagesItem: S.Schema<ScansHarResponseLogPagesItem>;
export type ScansHarResponseLogPagesList = Array<ScansHarResponseLogPagesItem>;
export declare const ScansHarResponseLogPagesList: S.Schema<ScansHarResponseLogPagesList>;
export interface ScansHarResponseLog {
    creator: ScansHarResponseLogCreator;
    entries: ScansHarResponseLogEntriesList;
    pages: ScansHarResponseLogPagesList;
    version: string;
}
export declare const ScansHarResponseLog: S.Schema<ScansHarResponseLog>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface HarScanResponse {
    log: ScansHarResponseLog;
}
export declare const HarScanResponse: S.Schema<HarScanResponse>;
export interface ListScansRequest {
    /** Account ID. */
    accountId: string;
    /** Filter scans */
    q?: string;
    /** Limit the number of objects in the response. */
    size?: number;
}
export declare const ListScansRequest: S.Schema<ListScansRequest>;
export interface ScansListResponseResultsItemPage {
    asn: string;
    country: string;
    ip: string;
    url: string;
}
export declare const ScansListResponseResultsItemPage: S.Schema<ScansListResponseResultsItemPage>;
export interface ScansListResponseResultsItemStats {
    dataLength: number;
    requests: number;
    uniqCountries: number;
    uniqIPs: number;
}
export declare const ScansListResponseResultsItemStats: S.Schema<ScansListResponseResultsItemStats>;
export interface ScansListResponseResultsItemTask {
    time: string;
    url: string;
    uuid: string;
    visibility: string;
}
export declare const ScansListResponseResultsItemTask: S.Schema<ScansListResponseResultsItemTask>;
export interface ScansListResponseResultsItemVerdicts {
    malicious: boolean;
}
export declare const ScansListResponseResultsItemVerdicts: S.Schema<ScansListResponseResultsItemVerdicts>;
export interface ScansListResponseResultsItem {
    id: string;
    page: ScansListResponseResultsItemPage;
    result: string;
    stats: ScansListResponseResultsItemStats;
    task: ScansListResponseResultsItemTask;
    verdicts: ScansListResponseResultsItemVerdicts;
}
export declare const ScansListResponseResultsItem: S.Schema<ScansListResponseResultsItem>;
export type ScansListResponseResultsList = Array<ScansListResponseResultsItem>;
export declare const ScansListResponseResultsList: S.Schema<ScansListResponseResultsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListScansResponse {
    results: ScansListResponseResultsList;
}
export declare const ListScansResponse: S.Schema<ListScansResponse>;
export type ScansScreenshotRequestResolution = "desktop" | "mobile" | "tablet";
export declare const ScansScreenshotRequestResolution: any;
export interface ScreenshotScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
    /** Target device type. */
    resolution?: ScansScreenshotRequestResolution | (string & {});
}
export declare const ScreenshotScanRequest: S.Schema<ScreenshotScanRequest>;
export interface ScreenshotScanResponse {
}
export declare const ScreenshotScanResponse: S.Schema<ScreenshotScanResponse>;
export type BulkCreateScansError = CloudflareOpError;
/** Submit URLs to scan. Check limits at https://developers.cloudflare.com/security-center/investigate/scan-limits/ and take into account scans submitted in bulk have lower priority and may take longer to finish. */
export declare const bulkCreateScans: API.OperationMethod<BulkCreateScansRequest, BulkCreateScansResponse, BulkCreateScansError, CloudflareOpContext>;
export type CreateScanError = CloudflareOpError;
/** Submit a URL to scan. Check limits at https://developers.cloudflare.com/security-center/investigate/scan-limits/. */
export declare const createScan: API.OperationMethod<CreateScanRequest, CreateScanResponse, CreateScanError, CloudflareOpContext>;
export type DomScanError = CloudflareOpError;
/** Returns a plain text response, with the scan's DOM content as rendered by Chrome. */
export declare const domScan: API.OperationMethod<DomScanRequest, DomScanResponse, DomScanError, CloudflareOpContext>;
export type GetResponsError = CloudflareOpError;
/** Returns the raw response of the network request. Find the `response_id` in the `data.requests.response.hash`. */
export declare const getRespons: API.OperationMethod<GetResponsRequest, GetResponsResponse, GetResponsError, CloudflareOpContext>;
export type GetScanError = CloudflareOpError;
/** Get URL scan by uuid */
export declare const getScan: API.OperationMethod<GetScanRequest, GetScanResponse, GetScanError, CloudflareOpContext>;
export type HarScanError = CloudflareOpError;
/** Get a URL scan's HAR file. See HAR spec at http://www.softwareishard.com/blog/har-12-spec/. */
export declare const harScan: API.OperationMethod<HarScanRequest, HarScanResponse, HarScanError, CloudflareOpContext>;
export type ListScansError = CloudflareOpError;
/** Use a subset of ElasticSearch Query syntax to filter scans. Some example queries:<br/> <br/>- 'path:"/bundles/jquery.js"': Searches for scans who requested resources with the given path.<br/>- 'page.asn:AS24940 AND hash:xxx': Websites hosted in AS24940 where a resource with the given hash was downloaded.<br/>- 'page.domain:microsoft* AND verdicts.malicious:true AND NOT page.domain:microsoft.com': malicious scans whose hostname starts with "microsoft".<br/>- 'apikey:me AND date:[2025-01 TO 2025-02]': my scans from 2025 January to 2025 February. */
export declare const listScans: API.OperationMethod<ListScansRequest, ListScansResponse, ListScansError, CloudflareOpContext>;
export type ScreenshotScanError = CloudflareOpError;
/** Get scan's screenshot by resolution (desktop/mobile/tablet). */
export declare const screenshotScan: API.OperationMethod<ScreenshotScanRequest, ScreenshotScanResponse, ScreenshotScanError, CloudflareOpContext>;
//# sourceMappingURL=url_scanner.d.ts.map