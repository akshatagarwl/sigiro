import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ImageAlreadyExists_base: S.Class<ImageAlreadyExists, S.TaggedStruct<"ImageAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageAlreadyExists extends /*@__PURE__*/ ImageAlreadyExists_base {
}
declare const ImageNotFound_base: S.Class<ImageNotFound, S.TaggedStruct<"ImageNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageNotFound extends /*@__PURE__*/ ImageNotFound_base {
}
declare const ImagesAccessNotEnabled_base: S.Class<ImagesAccessNotEnabled, S.TaggedStruct<"ImagesAccessNotEnabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImagesAccessNotEnabled extends /*@__PURE__*/ ImagesAccessNotEnabled_base {
}
declare const InvalidUploadFormat_base: S.Class<InvalidUploadFormat, S.TaggedStruct<"InvalidUploadFormat", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidUploadFormat extends /*@__PURE__*/ InvalidUploadFormat_base {
}
declare const KeyNotFound_base: S.Class<KeyNotFound, S.TaggedStruct<"KeyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KeyNotFound extends /*@__PURE__*/ KeyNotFound_base {
}
declare const VariantAlreadyExists_base: S.Class<VariantAlreadyExists, S.TaggedStruct<"VariantAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VariantAlreadyExists extends /*@__PURE__*/ VariantAlreadyExists_base {
}
declare const VariantNameNotAllowed_base: S.Class<VariantNameNotAllowed, S.TaggedStruct<"VariantNameNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VariantNameNotAllowed extends /*@__PURE__*/ VariantNameNotAllowed_base {
}
declare const VariantNotFound_base: S.Class<VariantNotFound, S.TaggedStruct<"VariantNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VariantNotFound extends /*@__PURE__*/ VariantNotFound_base {
}
export interface CreateV1Request {
    /** Account identifier tag. */
    accountId: string;
}
export declare const CreateV1Request: S.Schema<CreateV1Request>;
export type V1CreateResponseVariantsList = Array<string>;
export declare const V1CreateResponseVariantsList: S.Schema<V1CreateResponseVariantsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateV1Response {
    /** Image unique identifier. */
    id?: string | null;
    /** Can set the creator field with an internal user ID. */
    creator?: string | null;
    /** Image file name. */
    filename?: string | null;
    /** User modifiable key-value store. Can be used for keeping references to another system of record for managing images. Metadata must not exceed 1024 bytes. */
    meta?: unknown | null;
    /** Indicates whether the image can be a accessed only using it's UID. If set to true, a signed token needs to be generated with a signing key to view the image. */
    requireSignedURLs?: boolean | null;
    /** When the media item was uploaded. */
    uploaded?: string | null;
    /** Object specifying available variants for an image. */
    variants?: V1CreateResponseVariantsList | null;
}
export declare const CreateV1Response: S.Schema<CreateV1Response>;
export type V1VariantsCreateRequestOptionsFit = "scale-down" | "contain" | "cover" | "crop" | "pad";
export declare const V1VariantsCreateRequestOptionsFit: any;
export type V1VariantsCreateRequestOptionsMetadata = "keep" | "copyright" | "none";
export declare const V1VariantsCreateRequestOptionsMetadata: any;
export interface V1VariantsCreateRequestOptions {
    /** The fit property describes how the width and height dimensions should be interpreted. */
    fit: V1VariantsCreateRequestOptionsFit | (string & {});
    /** Maximum height in image pixels. */
    height: number;
    /** What EXIF data should be preserved in the output image. */
    metadata: V1VariantsCreateRequestOptionsMetadata | (string & {});
    /** Maximum width in image pixels. */
    width: number;
}
export declare const V1VariantsCreateRequestOptions: S.Schema<V1VariantsCreateRequestOptions>;
export interface CreateV1VariantRequest {
    /** Account identifier tag. */
    accountId: string;
    id: string;
    /** Allows you to define image resizing sizes for different use cases. */
    options: V1VariantsCreateRequestOptions;
    /** Indicates whether the variant can access an image without a signature, regardless of image access control. */
    neverRequireSignedURLs?: boolean;
}
export declare const CreateV1VariantRequest: S.Schema<CreateV1VariantRequest>;
export type V1VariantsCreateResponseVariantOptionsFit = "scale-down" | "contain" | "cover" | "crop" | "pad";
export declare const V1VariantsCreateResponseVariantOptionsFit: any;
export type V1VariantsCreateResponseVariantOptionsMetadata = "keep" | "copyright" | "none";
export declare const V1VariantsCreateResponseVariantOptionsMetadata: any;
export interface V1VariantsCreateResponseVariantOptions {
    /** The fit property describes how the width and height dimensions should be interpreted. */
    fit: V1VariantsCreateResponseVariantOptionsFit;
    /** Maximum height in image pixels. */
    height: number;
    /** What EXIF data should be preserved in the output image. */
    metadata: V1VariantsCreateResponseVariantOptionsMetadata;
    /** Maximum width in image pixels. */
    width: number;
}
export declare const V1VariantsCreateResponseVariantOptions: S.Schema<V1VariantsCreateResponseVariantOptions>;
export interface V1VariantsCreateResponseVariant {
    id: string;
    /** Allows you to define image resizing sizes for different use cases. */
    options: V1VariantsCreateResponseVariantOptions;
    /** Indicates whether the variant can access an image without a signature, regardless of image access control. */
    neverRequireSignedURLs?: boolean | null;
}
export declare const V1VariantsCreateResponseVariant: S.Schema<V1VariantsCreateResponseVariant>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateV1VariantResponse {
    variant?: V1VariantsCreateResponseVariant | null;
}
export declare const CreateV1VariantResponse: S.Schema<CreateV1VariantResponse>;
export interface CreateV2DirectUploadRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const CreateV2DirectUploadRequest: S.Schema<CreateV2DirectUploadRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateV2DirectUploadResponse {
    /** Image unique identifier. */
    id?: string | null;
    /** The URL the unauthenticated upload can be performed to using a single HTTP POST (multipart/form-data) request. */
    uploadURL?: string | null;
}
export declare const CreateV2DirectUploadResponse: S.Schema<CreateV2DirectUploadResponse>;
export interface DeleteV1Request {
    /** Account identifier tag. */
    accountId: string;
    /** Image unique identifier. */
    imageId: string;
}
export declare const DeleteV1Request: S.Schema<DeleteV1Request>;
export type DeleteV1Response = unknown;
export declare const DeleteV1Response: S.Schema<DeleteV1Response>;
export interface DeleteV1KeyRequest {
    /** Account identifier tag. */
    accountId: string;
    signingKeyName: string;
}
export declare const DeleteV1KeyRequest: S.Schema<DeleteV1KeyRequest>;
export interface V1KeysDeleteResponseKeysItem {
    /** Key name. */
    name?: string | null;
    /** Key value. */
    value?: string | null;
}
export declare const V1KeysDeleteResponseKeysItem: S.Schema<V1KeysDeleteResponseKeysItem>;
export type V1KeysDeleteResponseKeysList = Array<V1KeysDeleteResponseKeysItem>;
export declare const V1KeysDeleteResponseKeysList: S.Schema<V1KeysDeleteResponseKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteV1KeyResponse {
    keys?: V1KeysDeleteResponseKeysList | null;
}
export declare const DeleteV1KeyResponse: S.Schema<DeleteV1KeyResponse>;
export interface DeleteV1VariantRequest {
    /** Account identifier tag. */
    accountId: string;
    variantId: string;
}
export declare const DeleteV1VariantRequest: S.Schema<DeleteV1VariantRequest>;
export type DeleteV1VariantResponse = unknown;
export declare const DeleteV1VariantResponse: S.Schema<DeleteV1VariantResponse>;
export interface GetV1Request {
    /** Account identifier tag. */
    accountId: string;
    /** Image unique identifier. */
    imageId: string;
}
export declare const GetV1Request: S.Schema<GetV1Request>;
export type V1GetResponseVariantsList = Array<string>;
export declare const V1GetResponseVariantsList: S.Schema<V1GetResponseVariantsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetV1Response {
    /** Image unique identifier. */
    id?: string | null;
    /** Can set the creator field with an internal user ID. */
    creator?: string | null;
    /** Image file name. */
    filename?: string | null;
    /** User modifiable key-value store. Can be used for keeping references to another system of record for managing images. Metadata must not exceed 1024 bytes. */
    meta?: unknown | null;
    /** Indicates whether the image can be a accessed only using it's UID. If set to true, a signed token needs to be generated with a signing key to view the image. */
    requireSignedURLs?: boolean | null;
    /** When the media item was uploaded. */
    uploaded?: string | null;
    /** Object specifying available variants for an image. */
    variants?: V1GetResponseVariantsList | null;
}
export declare const GetV1Response: S.Schema<GetV1Response>;
export interface GetV1BlobRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Image unique identifier. */
    imageId: string;
}
export declare const GetV1BlobRequest: S.Schema<GetV1BlobRequest>;
export interface GetV1BlobResponse {
}
export declare const GetV1BlobResponse: S.Schema<GetV1BlobResponse>;
export interface GetV1StatRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const GetV1StatRequest: S.Schema<GetV1StatRequest>;
export interface V1StatsGetResponseCount {
    /** Cloudflare Images allowed usage. */
    allowed?: number | null;
    /** Cloudflare Images current usage. */
    current?: number | null;
}
export declare const V1StatsGetResponseCount: S.Schema<V1StatsGetResponseCount>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetV1StatResponse {
    count?: V1StatsGetResponseCount | null;
}
export declare const GetV1StatResponse: S.Schema<GetV1StatResponse>;
export interface GetV1VariantRequest {
    /** Account identifier tag. */
    accountId: string;
    variantId: string;
}
export declare const GetV1VariantRequest: S.Schema<GetV1VariantRequest>;
export type V1VariantsGetResponseVariantOptionsFit = "scale-down" | "contain" | "cover" | "crop" | "pad";
export declare const V1VariantsGetResponseVariantOptionsFit: any;
export type V1VariantsGetResponseVariantOptionsMetadata = "keep" | "copyright" | "none";
export declare const V1VariantsGetResponseVariantOptionsMetadata: any;
export interface V1VariantsGetResponseVariantOptions {
    /** The fit property describes how the width and height dimensions should be interpreted. */
    fit: V1VariantsGetResponseVariantOptionsFit;
    /** Maximum height in image pixels. */
    height: number;
    /** What EXIF data should be preserved in the output image. */
    metadata: V1VariantsGetResponseVariantOptionsMetadata;
    /** Maximum width in image pixels. */
    width: number;
}
export declare const V1VariantsGetResponseVariantOptions: S.Schema<V1VariantsGetResponseVariantOptions>;
export interface V1VariantsGetResponseVariant {
    id: string;
    /** Allows you to define image resizing sizes for different use cases. */
    options: V1VariantsGetResponseVariantOptions;
    /** Indicates whether the variant can access an image without a signature, regardless of image access control. */
    neverRequireSignedURLs?: boolean | null;
}
export declare const V1VariantsGetResponseVariant: S.Schema<V1VariantsGetResponseVariant>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetV1VariantResponse {
    variant?: V1VariantsGetResponseVariant | null;
}
export declare const GetV1VariantResponse: S.Schema<GetV1VariantResponse>;
export interface ListV1KeysRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const ListV1KeysRequest: S.Schema<ListV1KeysRequest>;
export type V1KeysListResponseKeysItem = V1KeysDeleteResponseKeysItem;
export declare const V1KeysListResponseKeysItem: S.Schema<V1KeysDeleteResponseKeysItem>;
export type V1KeysListResponseKeysList = Array<V1KeysDeleteResponseKeysItem>;
export declare const V1KeysListResponseKeysList: S.Schema<V1KeysListResponseKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListV1KeysResponse {
    keys?: V1KeysListResponseKeysList | null;
}
export declare const ListV1KeysResponse: S.Schema<ListV1KeysResponse>;
export interface ListV1sRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Internal user ID set within the creator field. Setting to empty string "" will return images where creator field is not set */
    creator?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export declare const ListV1sRequest: S.Schema<ListV1sRequest>;
export type V1ListResponseImagesItemVariantsList = Array<string>;
export declare const V1ListResponseImagesItemVariantsList: S.Schema<V1ListResponseImagesItemVariantsList>;
export interface V1ListResponseImagesItem {
    /** Image unique identifier. */
    id?: string | null;
    /** Can set the creator field with an internal user ID. */
    creator?: string | null;
    /** Image file name. */
    filename?: string | null;
    /** User modifiable key-value store. Can be used for keeping references to another system of record for managing images. Metadata must not exceed 1024 bytes. */
    meta?: unknown | null;
    /** Indicates whether the image can be a accessed only using it's UID. If set to true, a signed token needs to be generated with a signing key to view the image. */
    requireSignedURLs?: boolean | null;
    /** When the media item was uploaded. */
    uploaded?: string | null;
    /** Object specifying available variants for an image. */
    variants?: V1ListResponseImagesItemVariantsList | null;
}
export declare const V1ListResponseImagesItem: S.Schema<V1ListResponseImagesItem>;
export type V1ListResponseImagesList = Array<V1ListResponseImagesItem>;
export declare const V1ListResponseImagesList: S.Schema<V1ListResponseImagesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListV1sResponse {
    images?: V1ListResponseImagesList | null;
}
export declare const ListV1sResponse: S.Schema<ListV1sResponse>;
export interface ListV1VariantsRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const ListV1VariantsRequest: S.Schema<ListV1VariantsRequest>;
export type V1VariantsListResponseVariantsHeroOptionsFit = "scale-down" | "contain" | "cover" | "crop" | "pad";
export declare const V1VariantsListResponseVariantsHeroOptionsFit: any;
export type V1VariantsListResponseVariantsHeroOptionsMetadata = "keep" | "copyright" | "none";
export declare const V1VariantsListResponseVariantsHeroOptionsMetadata: any;
export interface V1VariantsListResponseVariantsHeroOptions {
    /** The fit property describes how the width and height dimensions should be interpreted. */
    fit: V1VariantsListResponseVariantsHeroOptionsFit;
    /** Maximum height in image pixels. */
    height: number;
    /** What EXIF data should be preserved in the output image. */
    metadata: V1VariantsListResponseVariantsHeroOptionsMetadata;
    /** Maximum width in image pixels. */
    width: number;
}
export declare const V1VariantsListResponseVariantsHeroOptions: S.Schema<V1VariantsListResponseVariantsHeroOptions>;
export interface V1VariantsListResponseVariantsHero {
    id: string;
    /** Allows you to define image resizing sizes for different use cases. */
    options: V1VariantsListResponseVariantsHeroOptions;
    /** Indicates whether the variant can access an image without a signature, regardless of image access control. */
    neverRequireSignedURLs?: boolean | null;
}
export declare const V1VariantsListResponseVariantsHero: S.Schema<V1VariantsListResponseVariantsHero>;
export interface V1VariantsListResponseVariants {
    hero?: V1VariantsListResponseVariantsHero | null;
}
export declare const V1VariantsListResponseVariants: S.Schema<V1VariantsListResponseVariants>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListV1VariantsResponse {
    variants?: V1VariantsListResponseVariants | null;
}
export declare const ListV1VariantsResponse: S.Schema<ListV1VariantsResponse>;
export interface V2ListRequestMeta {
    /** Optional metadata filter(s). Multiple filters can be combined with AND logic. */
    fieldOperator__?: unknown;
}
export declare const V2ListRequestMeta: S.Schema<V2ListRequestMeta>;
export type V2ListRequestSortOrder = "asc" | "desc";
export declare const V2ListRequestSortOrder: any;
export interface ListV2sRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Continuation token to fetch next page. Passed as a query param when requesting List V2 api endpoint. */
    continuationToken?: string;
    /** Internal user ID set within the creator field. Setting to empty string "" will return images where creator field is not set */
    creator?: string;
    meta?: V2ListRequestMeta;
    /** Number of items per page */
    perPage?: number;
    /** Sorting order by upload time */
    sortOrder?: V2ListRequestSortOrder | (string & {});
}
export declare const ListV2sRequest: S.Schema<ListV2sRequest>;
export type V2ListResponseImagesItemVariantsList = Array<string>;
export declare const V2ListResponseImagesItemVariantsList: S.Schema<V2ListResponseImagesItemVariantsList>;
export interface V2ListResponseImagesItem {
    /** Image unique identifier. */
    id?: string | null;
    /** Can set the creator field with an internal user ID. */
    creator?: string | null;
    /** Image file name. */
    filename?: string | null;
    /** User modifiable key-value store. Can be used for keeping references to another system of record for managing images. Metadata must not exceed 1024 bytes. */
    meta?: unknown | null;
    /** Indicates whether the image can be a accessed only using it's UID. If set to true, a signed token needs to be generated with a signing key to view the image. */
    requireSignedURLs?: boolean | null;
    /** When the media item was uploaded. */
    uploaded?: string | null;
    /** Object specifying available variants for an image. */
    variants?: V2ListResponseImagesItemVariantsList | null;
}
export declare const V2ListResponseImagesItem: S.Schema<V2ListResponseImagesItem>;
export type V2ListResponseImagesList = Array<V2ListResponseImagesItem>;
export declare const V2ListResponseImagesList: S.Schema<V2ListResponseImagesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListV2sResponse {
    /** Continuation token to fetch next page. Passed as a query param when requesting List V2 api endpoint. */
    continuationToken?: string | null;
    images?: V2ListResponseImagesList | null;
}
export declare const ListV2sResponse: S.Schema<ListV2sResponse>;
export interface PatchV1Request {
    /** Account identifier tag. */
    accountId: string;
    /** Image unique identifier. */
    imageId: string;
    /** Can set the creator field with an internal user ID. */
    creator?: string;
    /** User modifiable key-value store. Can be used for keeping references to another system of record for managing images. No change if not specified. */
    metadata?: unknown;
    /** Indicates whether the image can be accessed using only its UID. If set to `true`, a signed token needs to be generated with a signing key to view the image. Returns a new UID on a change. No change if not specified. */
    requireSignedURLs?: boolean;
}
export declare const PatchV1Request: S.Schema<PatchV1Request>;
export type V1EditResponseVariantsList = Array<string>;
export declare const V1EditResponseVariantsList: S.Schema<V1EditResponseVariantsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchV1Response {
    /** Image unique identifier. */
    id?: string | null;
    /** Can set the creator field with an internal user ID. */
    creator?: string | null;
    /** Image file name. */
    filename?: string | null;
    /** User modifiable key-value store. Can be used for keeping references to another system of record for managing images. Metadata must not exceed 1024 bytes. */
    meta?: unknown | null;
    /** Indicates whether the image can be a accessed only using it's UID. If set to true, a signed token needs to be generated with a signing key to view the image. */
    requireSignedURLs?: boolean | null;
    /** When the media item was uploaded. */
    uploaded?: string | null;
    /** Object specifying available variants for an image. */
    variants?: V1EditResponseVariantsList | null;
}
export declare const PatchV1Response: S.Schema<PatchV1Response>;
export type V1VariantsEditRequestOptionsFit = "scale-down" | "contain" | "cover" | "crop" | "pad";
export declare const V1VariantsEditRequestOptionsFit: any;
export type V1VariantsEditRequestOptionsMetadata = "keep" | "copyright" | "none";
export declare const V1VariantsEditRequestOptionsMetadata: any;
export interface V1VariantsEditRequestOptions {
    /** The fit property describes how the width and height dimensions should be interpreted. */
    fit: V1VariantsEditRequestOptionsFit | (string & {});
    /** Maximum height in image pixels. */
    height: number;
    /** What EXIF data should be preserved in the output image. */
    metadata: V1VariantsEditRequestOptionsMetadata | (string & {});
    /** Maximum width in image pixels. */
    width: number;
}
export declare const V1VariantsEditRequestOptions: S.Schema<V1VariantsEditRequestOptions>;
export interface PatchV1VariantRequest {
    /** Account identifier tag. */
    accountId: string;
    variantId: string;
    /** Allows you to define image resizing sizes for different use cases. */
    options: V1VariantsEditRequestOptions;
    /** Indicates whether the variant can access an image without a signature, regardless of image access control. */
    neverRequireSignedURLs?: boolean;
}
export declare const PatchV1VariantRequest: S.Schema<PatchV1VariantRequest>;
export type V1VariantsEditResponseVariantOptionsFit = "scale-down" | "contain" | "cover" | "crop" | "pad";
export declare const V1VariantsEditResponseVariantOptionsFit: any;
export type V1VariantsEditResponseVariantOptionsMetadata = "keep" | "copyright" | "none";
export declare const V1VariantsEditResponseVariantOptionsMetadata: any;
export interface V1VariantsEditResponseVariantOptions {
    /** The fit property describes how the width and height dimensions should be interpreted. */
    fit: V1VariantsEditResponseVariantOptionsFit;
    /** Maximum height in image pixels. */
    height: number;
    /** What EXIF data should be preserved in the output image. */
    metadata: V1VariantsEditResponseVariantOptionsMetadata;
    /** Maximum width in image pixels. */
    width: number;
}
export declare const V1VariantsEditResponseVariantOptions: S.Schema<V1VariantsEditResponseVariantOptions>;
export interface V1VariantsEditResponseVariant {
    id: string;
    /** Allows you to define image resizing sizes for different use cases. */
    options: V1VariantsEditResponseVariantOptions;
    /** Indicates whether the variant can access an image without a signature, regardless of image access control. */
    neverRequireSignedURLs?: boolean | null;
}
export declare const V1VariantsEditResponseVariant: S.Schema<V1VariantsEditResponseVariant>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchV1VariantResponse {
    variant?: V1VariantsEditResponseVariant | null;
}
export declare const PatchV1VariantResponse: S.Schema<PatchV1VariantResponse>;
export interface PutV1KeyRequest {
    /** Account identifier tag. */
    accountId: string;
    signingKeyName: string;
}
export declare const PutV1KeyRequest: S.Schema<PutV1KeyRequest>;
export type V1KeysUpdateResponseKeysItem = V1KeysDeleteResponseKeysItem;
export declare const V1KeysUpdateResponseKeysItem: S.Schema<V1KeysDeleteResponseKeysItem>;
export type V1KeysUpdateResponseKeysList = Array<V1KeysDeleteResponseKeysItem>;
export declare const V1KeysUpdateResponseKeysList: S.Schema<V1KeysUpdateResponseKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutV1KeyResponse {
    keys?: V1KeysUpdateResponseKeysList | null;
}
export declare const PutV1KeyResponse: S.Schema<PutV1KeyResponse>;
export type CreateV1Error = ImagesAccessNotEnabled | CloudflareOpError;
/** Upload an image to CF Images. Images up to 10 Megabytes can be uploaded using a single HTTP POST (multipart/form-data) request by sending an image file or passing a URL accessible to the API. */
export declare const createV1: API.OperationMethod<CreateV1Request, CreateV1Response, CreateV1Error, CloudflareOpContext>;
export type CreateV1VariantError = ImagesAccessNotEnabled | VariantNameNotAllowed | VariantAlreadyExists | CloudflareOpError;
/** Create a CF Images variant that allows you to resize images for different use cases. */
export declare const createV1Variant: API.OperationMethod<CreateV1VariantRequest, CreateV1VariantResponse, CreateV1VariantError, CloudflareOpContext>;
export type CreateV2DirectUploadError = ImagesAccessNotEnabled | ImageAlreadyExists | InvalidUploadFormat | CloudflareOpError;
/** Direct uploads allow users to upload images without API keys. A common use case are web apps, client-side applications, or mobile devices where users upload content directly to Cloudflare Images. This method creates a draft record for a future image. It returns an upload URL and an image identifier. To verify if the image itself has been uploaded, send an image details request (accounts/:account_identifier/images/v1/:identifier), and check that the `draft: true` property is not present. */
export declare const createV2DirectUpload: API.OperationMethod<CreateV2DirectUploadRequest, CreateV2DirectUploadResponse, CreateV2DirectUploadError, CloudflareOpContext>;
export type DeleteV1Error = ImagesAccessNotEnabled | ImageNotFound | CloudflareOpError;
/** Delete an image on Cloudflare Images. On success, all copies of the image are deleted and purged from cache. */
export declare const deleteV1: API.OperationMethod<DeleteV1Request, DeleteV1Response, DeleteV1Error, CloudflareOpContext>;
export type DeleteV1KeyError = ImagesAccessNotEnabled | KeyNotFound | CloudflareOpError;
/** Delete a CF Images signing key with specified name. Returns all keys available. When the last key is removed, a new default signing key will be generated. */
export declare const deleteV1Key: API.OperationMethod<DeleteV1KeyRequest, DeleteV1KeyResponse, DeleteV1KeyError, CloudflareOpContext>;
export type DeleteV1VariantError = ImagesAccessNotEnabled | VariantNameNotAllowed | VariantNotFound | CloudflareOpError;
/** Delete a CF Images variant. This will purge the cache for all images associated with the variant. */
export declare const deleteV1Variant: API.OperationMethod<DeleteV1VariantRequest, DeleteV1VariantResponse, DeleteV1VariantError, CloudflareOpContext>;
export type GetV1Error = ImagesAccessNotEnabled | ImageNotFound | CloudflareOpError;
/** Fetch details for a CF Images image. */
export declare const getV1: API.OperationMethod<GetV1Request, GetV1Response, GetV1Error, CloudflareOpContext>;
export type GetV1BlobError = ImagesAccessNotEnabled | ImageNotFound | CloudflareOpError;
/** Download an image from CF Images. For most images this will be the originally uploaded file. For larger images it can be a near-lossless version of the original. */
export declare const getV1Blob: API.OperationMethod<GetV1BlobRequest, GetV1BlobResponse, GetV1BlobError, CloudflareOpContext>;
export type GetV1StatError = ImagesAccessNotEnabled | CloudflareOpError;
/** Fetch image statistics details for Cloudflare Images. The returned statistics detail storage usage, including the current image count vs this account's allowance. */
export declare const getV1Stat: API.OperationMethod<GetV1StatRequest, GetV1StatResponse, GetV1StatError, CloudflareOpContext>;
export type GetV1VariantError = ImagesAccessNotEnabled | VariantNameNotAllowed | VariantNotFound | CloudflareOpError;
/** Fetch details for a CF Images variant. */
export declare const getV1Variant: API.OperationMethod<GetV1VariantRequest, GetV1VariantResponse, GetV1VariantError, CloudflareOpContext>;
export type ListV1KeysError = ImagesAccessNotEnabled | CloudflareOpError;
/** List your CF Images signing keys. */
export declare const listV1Keys: API.OperationMethod<ListV1KeysRequest, ListV1KeysResponse, ListV1KeysError, CloudflareOpContext>;
export type ListV1sError = ImagesAccessNotEnabled | CloudflareOpError;
/** List up to 100 images with one request. Use the optional parameters below to get a specific range of images. */
export declare const listV1s: API.OperationMethod<ListV1sRequest, ListV1sResponse, ListV1sError, CloudflareOpContext>;
export type ListV1VariantsError = ImagesAccessNotEnabled | CloudflareOpError;
/** List existing CF Images variants. */
export declare const listV1Variants: API.OperationMethod<ListV1VariantsRequest, ListV1VariantsResponse, ListV1VariantsError, CloudflareOpContext>;
export type ListV2sError = ImagesAccessNotEnabled | CloudflareOpError;
/** List up to 10000 images from CF Images, with up to 1000 results per page. Use the optional parameters below to get a specific range of images. Pagination is supported via continuation_token. **Metadata Filtering (Optional):** You can optionally filter images by custom metadata fields using the `meta.<field>[<operator>]=<value>` syntax. **Supported Operators:** - `eq` / `eq:string` / `eq:number` / `eq:boolean` - Exact match - `gt` / `gt:number` - Greater than (number only) - `gte` / `gte:number` - Greater than or equal (number only) - `lt` / `lt:number` - Less than (number only) - `lte` / `lte:number` - Less than or equal (number only) - `in` / `in:string` / `in:number` - Match any value in list (pipe-separated) **Metadata Filter Constraints:** - Maximum 5 metadata filters per request - Maximum 5 levels of nesting (e.g., `meta.first.second.third.fourth.fifth`) - Maximum 10 elements for list operators (`in`) - Supports string, number, and boolean value types - Range operators (`gt`, `gte`, `lt`, `lte`) only accept numeric values **Filter Consistency:** Filters are combined with AND logic. The system does not validate whether filter combinations are logically consistent. For example, `meta.priority[eq:number]=5&meta.priority[lte:number]=3` will return zero results because no value can satisfy both conditions simultaneously. It is the caller's responsibility to ensure filter combinations make sense. **Examples:** ``` # List all images /images/v2 # Filter by metadata [eq] /images/v2?meta.status[eq:string]=active # Filter by metadata [in] /images/v2?meta.status[in]=pending|deleted|flagged # Filter by metadata [in:number] /images/v2?meta.ratings[in:number]=4|5 # Filter by metadata range [gte:number] /images/v2?meta.priority[gte:number]=1 # Filter by bounded range /images/v2?meta.priority[gte:number]=1&meta.priority[lte:number]=5 # Filter by nested metadata /images/v2?meta.region.name[eq]=eu-west # Combine metadata filters with creator /images/v2?meta.status[eq]=active&creator=user123 # Multiple metadata filters (AND logic) /images/v2?meta.status[eq]=active&meta.priority[eq:number]=5 ``` */
export declare const listV2s: API.OperationMethod<ListV2sRequest, ListV2sResponse, ListV2sError, CloudflareOpContext>;
export type PatchV1Error = ImagesAccessNotEnabled | ImageNotFound | CloudflareOpError;
/** Update a CF Images image's metadata, creator, or access control. On access control change, all copies of the image are purged from cache. */
export declare const patchV1: API.OperationMethod<PatchV1Request, PatchV1Response, PatchV1Error, CloudflareOpContext>;
export type PatchV1VariantError = ImagesAccessNotEnabled | VariantNameNotAllowed | VariantNotFound | CloudflareOpError;
/** Update a CF Images variant. This will purge the cache for all images associated with the variant. */
export declare const patchV1Variant: API.OperationMethod<PatchV1VariantRequest, PatchV1VariantResponse, PatchV1VariantError, CloudflareOpContext>;
export type PutV1KeyError = ImagesAccessNotEnabled | CloudflareOpError;
/** Create a new CF Images signing key with specified name. Returns all keys available. */
export declare const putV1Key: API.OperationMethod<PutV1KeyRequest, PutV1KeyResponse, PutV1KeyError, CloudflareOpContext>;
//# sourceMappingURL=images.d.ts.map