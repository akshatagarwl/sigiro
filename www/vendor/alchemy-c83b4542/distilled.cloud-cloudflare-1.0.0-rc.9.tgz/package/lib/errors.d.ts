/**
 * Cloudflare-specific error types.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
import type { DefaultErrors as CoreDefaultErrors } from "@distilled.cloud/core/errors";
import * as Schema from "effect/Schema";
declare const CloudflareParseError_base: Schema.Class<CloudflareParseError, Schema.TaggedStruct<"CloudflareParseError", {
    readonly body: Schema.Unknown;
    readonly cause: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
export declare class CloudflareParseError extends CloudflareParseError_base {
}
declare const UnknownCloudflareError_base: Schema.Class<UnknownCloudflareError, Schema.TaggedStruct<"UnknownCloudflareError", {
    readonly code: Schema.optional<Schema.Number>;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * Unknown Cloudflare error - returned when an error code is not recognized.
 * Contains the raw error code for later cataloging.
 */
export declare class UnknownCloudflareError extends UnknownCloudflareError_base {
}
declare const InvalidRoute_base: Schema.Class<InvalidRoute, Schema.TaggedStruct<"InvalidRoute", {
    readonly code: Schema.optional<Schema.Number>;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * Cloudflare error code 7003 — "invalid request: invalid route". Returned when
 * a path component (typically accountId / zoneId) doesn't match a real
 * Cloudflare resource. Mapped globally so every operation surfaces it as
 * InvalidRoute rather than UnknownCloudflareError.
 *
 * Per-operation patches that explicitly map code 7003 still produce their
 * service-local InvalidRoute class with the same `_tag`, so test assertions
 * on `e._tag === "InvalidRoute"` work for both global and per-op variants.
 */
export declare class InvalidRoute extends InvalidRoute_base {
}
declare const CloudflareHttpError_base: Schema.Class<CloudflareHttpError, Schema.TaggedStruct<"CloudflareHttpError", {
    readonly status: Schema.Number;
    readonly statusText: Schema.String;
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
/**
 * HTTP error - non-2xx response without a parseable Cloudflare error body.
 */
export declare class CloudflareHttpError extends CloudflareHttpError_base {
}
/**
 * Errors that any Cloudflare operation may surface in addition to status/code-
 * matched API errors declared per endpoint.
 */
export type ClientErrors = CloudflareHttpError | CloudflareParseError | InvalidRoute | UnknownCloudflareError;
/**
 * Default Cloudflare operation errors include the shared HTTP status errors from
 * core plus the client-level fallback/decode errors that the Cloudflare client
 * can emit at runtime.
 */
export type DefaultErrors = CoreDefaultErrors | ClientErrors;
/** A single `{ code, message }` entry from the envelope's `errors` array. */
export interface CloudflareApiError {
    readonly code?: number;
    readonly message: string;
}
declare const CloudflareError_base: Schema.Class<CloudflareError, Schema.TaggedStruct<"CloudflareError", {
    readonly status: Schema.Number;
    readonly errors: Schema.$Array<Schema.Struct<{
        readonly code: Schema.optional<Schema.Number>;
        readonly message: Schema.String;
    }>>;
}>, import("effect/Cause").YieldableError>;
/**
 * Legacy generic Cloudflare API error. The protocol no longer constructs
 * this (failures map to the distilled-compatible DefaultErrors classes
 * above); it remains exported because generated operations reference it in
 * their `errors` lists.
 */
export declare class CloudflareError extends CloudflareError_base {
}
declare const CloudflareRateLimited_base: Schema.Class<CloudflareRateLimited, Schema.TaggedStruct<"CloudflareRateLimited", {
    readonly status: Schema.Number;
    readonly errors: Schema.$Array<Schema.Struct<{
        readonly code: Schema.optional<Schema.Number>;
        readonly message: Schema.String;
    }>>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled/meta/error-categories": {
        "@distilled/errors/retryable": true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
/** Legacy rate-limit error — see {@link CloudflareError}'s note. */
export declare class CloudflareRateLimited extends CloudflareRateLimited_base {
}
//# sourceMappingURL=errors.d.ts.map