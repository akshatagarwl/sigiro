import * as S from "effect/Schema";
import * as Pagination from "@distilled.cloud/core/pagination";
export interface ResultInfoCursors {
    readonly after?: string | null;
    readonly before?: string | null;
}
/**
 * The v4 envelope's `result_info` block (camelCased by the paginated
 * protocol). Cloudflare varies the exact fields per endpoint — page-mode
 * endpoints report `page`/`perPage`/`totalCount`, cursor-mode endpoints
 * report `cursor` or `cursors` — so all fields are optional here.
 */
export interface ResultInfo {
    readonly count?: number | null;
    readonly page?: number | null;
    readonly perPage?: number | null;
    readonly totalCount?: number | null;
    readonly totalPages?: number | null;
    readonly cursor?: string | null;
    readonly cursors?: ResultInfoCursors | null;
}
export declare const ResultInfo: S.Schema<ResultInfo>;
/** Dispatch on the operation's pagination mode, Cloudflare-style. */
export declare const cloudflarePaginate: Pagination.PaginationStrategy;
//# sourceMappingURL=pagination.d.ts.map