import * as Layer from "effect/Layer";
import type * as HttpClient from "effect/unstable/http/HttpClient";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import * as API from "@distilled.cloud/core/api";
import { ConfigError } from "@distilled.cloud/core/errors";
import { Credentials, type OAuthRefreshError } from "./credentials.ts";
import { type CloudflareError, type CloudflareRateLimited, type DefaultErrors } from "./errors.ts";
/**
 * Error channel shared by every generated Cloudflare operation. Generated
 * service files annotate operations with `API.OperationMethod<I, O,
 * CloudflareOpError, CloudflareOpContext>` explicitly so the compiler never
 * infers these back out of the schema generics.
 */
export type CloudflareOpError = DefaultErrors | ConfigError | OAuthRefreshError | CloudflareError | CloudflareRateLimited | HttpClientError.HttpClientError;
/** Context (requirements) shared by every generated Cloudflare operation. */
export type CloudflareOpContext = Credentials | HttpClient.HttpClient;
export declare const CloudflareProtocol: Layer.Layer<API.Protocol>;
/**
 * Protocol for paginated operations: identical to {@link CloudflareProtocol}
 * except the envelope's top-level `result_info` is kept on the response (as
 * the member marked `T.ResultInfo()`, camelCased) so `.pages()` / `.items()`
 * can advance and callers can read totals.
 */
export declare const CloudflarePaginatedProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map