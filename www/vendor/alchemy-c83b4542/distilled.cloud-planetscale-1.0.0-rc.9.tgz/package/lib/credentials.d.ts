import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
export declare const DEFAULT_API_BASE_URL = "https://api.planetscale.com/v1";
/**
 * Service-token credentials. Sent as `Authorization: <tokenId>:<token>`.
 *
 * `type` is optional and defaults to `"serviceToken"` so existing callers
 * that construct a bare `{ tokenId, token, organization, apiBaseUrl }`
 * continue to work unchanged.
 */
export interface ServiceTokenConfig {
    readonly type?: "serviceToken";
    readonly tokenId: Redacted.Redacted<string>;
    readonly token: Redacted.Redacted<string>;
    readonly organization: string;
    readonly apiBaseUrl: string;
}
/**
 * OAuth credentials. Sent as `Authorization: Bearer <accessToken>`.
 *
 * PlanetScale OAuth has no PKCE flow and refreshes require the app's
 * client_secret, so refresh is handled by the caller (e.g. Alchemy's
 * AuthProvider) rather than here — this config only carries the resolved
 * access token used to authenticate API requests.
 */
export interface OAuthConfig {
    readonly type: "oauth";
    readonly accessToken: Redacted.Redacted<string>;
    readonly organization: string;
    readonly apiBaseUrl: string;
}
export type Config = ServiceTokenConfig | OAuthConfig;
declare const Credentials_base: Context.ServiceClass<Credentials, "PlanetScaleCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends Credentials_base {
}
/**
 * Build the `Authorization` header for a resolved set of credentials.
 * Service tokens use PlanetScale's `<id>:<secret>` scheme; OAuth access
 * tokens use standard `Bearer`.
 */
export declare const formatHeaders: (config: Config) => Record<string, string>;
/**
 * Build a `Credentials` Layer from an OAuth access token.
 */
export declare const fromOAuth: (input: {
    accessToken: string | Redacted.Redacted<string>;
    organization: string;
    apiBaseUrl?: string;
}) => Layer.Layer<Credentials>;
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
export {};
//# sourceMappingURL=credentials.d.ts.map