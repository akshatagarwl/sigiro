/**
 * PlanetScale-specific error types.
 *
 * Re-exports the common HTTP errors from core and adds the PlanetScale
 * fallback errors. Note the generated service module additionally defines
 * its own per-status matcher classes (BadRequest/Forbidden/NotFound/…) for
 * the statuses each operation declares — those share `_tag`s with the core
 * classes here, so `catchTag` works against either.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, Locked, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
export type { DefaultErrors } from "@distilled.cloud/core/errors";
import * as Schema from "effect/Schema";
/**
 * PlanetScale API error code mapping (v0 surface parity).
 * Maps API error response codes to HTTP error classes.
 */
export { HTTP_STATUS_MAP as ERROR_CODE_MAP } from "@distilled.cloud/core/errors";
declare const UnknownPlanetScaleError_base: Schema.Class<UnknownPlanetScaleError, Schema.TaggedStruct<"UnknownPlanetScaleError", {
    readonly code: Schema.optional<Schema.String>;
    readonly message: Schema.optional<Schema.String>;
    readonly body: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/** Unknown PlanetScale error — returned when nothing else matches the failure. */
export declare class UnknownPlanetScaleError extends UnknownPlanetScaleError_base {
}
declare const PlanetScaleParseError_base: Schema.Class<PlanetScaleParseError, Schema.TaggedStruct<"PlanetScaleParseError", {
    readonly body: Schema.Unknown;
    readonly cause: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
/** Schema parse error wrapper (kept for v0 surface parity). */
export declare class PlanetScaleParseError extends PlanetScaleParseError_base {
}
//# sourceMappingURL=errors.d.ts.map