/**
 * PlanetScale retry configuration.
 *
 * Defines the per-SDK `Retry` Context.Service tag that the generated
 * operations wire into `API.make`. Callers can install a blanket retry
 * policy at the layer level and have every PlanetScale API call below it
 * pick it up:
 *
 * @example
 * ```ts
 * import * as PlanetScale from "@distilled.cloud/planetscale";
 *
 * myEffect.pipe(PlanetScale.Retry.transient);
 * Effect.provide(myEffect, Layer.succeed(PlanetScale.Retry.Retry, customPolicy));
 * ```
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { type Policy } from "@distilled.cloud/core/retry";
export { type Options, type Factory, type Policy, makeDefault, jittered, capped, throttlingOptions, transientOptions, throttlingFactory, transientFactory, } from "@distilled.cloud/core/retry";
declare const Retry_base: Context.ServiceClass<Retry, "PlanetScaleRetry", Policy>;
/** Context tag for configuring retry behavior of PlanetScale API calls. */
export declare class Retry extends Retry_base {
}
/** Provides a custom retry policy to every PlanetScale API call below it. */
export declare const policy: (optionsOrFactory: Policy) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Disables all automatic retries. */
export declare const none: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Apply the throttling retry policy (retries throttling errors indefinitely). */
export declare const throttling: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
/** Apply the transient retry policy (retries all transient errors indefinitely). */
export declare const transient: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, Retry>>;
//# sourceMappingURL=retry.d.ts.map