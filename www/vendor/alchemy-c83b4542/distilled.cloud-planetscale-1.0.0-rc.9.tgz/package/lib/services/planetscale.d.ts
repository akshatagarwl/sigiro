import * as S from "@distilled.cloud/core/schema";
import * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type PlanetScaleOpError, type PlanetScaleOpContext } from "../protocol.ts";
export type { PlanetScaleOpError, PlanetScaleOpContext };
declare const BadRequest_base: S.Class<BadRequest, S.TaggedStruct<"BadRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const UnprocessableEntity_base: S.Class<UnprocessableEntity, S.TaggedStruct<"UnprocessableEntity", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntity extends /*@__PURE__*/ UnprocessableEntity_base {
}
export interface AddOrganizationTeamMemberRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
    /** The ID of the organization member to add to the team */
    user_id: string;
}
export declare const AddOrganizationTeamMemberRequest: S.Schema<AddOrganizationTeamMemberRequest>;
export interface OrganizationTeamMembershipUserDefaultOrganization {
    /** The ID for the resource */
    id: string;
    /** The name for the resource */
    name: string;
    /** When the resource was created */
    created_at: string;
    /** When the resource was last updated */
    updated_at: string;
    /** When the resource was deleted, if deleted */
    deleted_at: string | null;
}
export declare const OrganizationTeamMembershipUserDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface OrganizationTeamMembershipUser {
    /** The ID of the user */
    id: string;
    /** The display name of the user */
    display_name: string;
    /** The name of the user */
    name: string;
    /** The email of the user */
    email: string;
    /** The URL source of the user's avatar */
    avatar_url: string;
    /** When the user was created */
    created_at: string;
    /** When the user was last updated */
    updated_at: string;
    /** Whether or not the user has configured two factor authentication */
    two_factor_auth_configured: boolean;
    default_organization?: OrganizationTeamMembershipUserDefaultOrganization | null;
    /** Whether or not the user is managed by SSO. */
    sso?: boolean | null;
    /** Whether or not the user is managed by an authentication provider. */
    managed?: boolean | null;
    /** Whether or not the user is managed by a SSO directory. */
    directory_managed?: boolean | null;
    /** Whether or not the user is verified by email. */
    email_verified?: boolean | null;
}
export declare const OrganizationTeamMembershipUser: S.Schema<OrganizationTeamMembershipUser>;
export interface OrganizationTeamMembershipActor {
    /** The ID of the actor */
    id: string;
    /** The name of the actor */
    display_name: string;
    /** The URL of the actor's avatar */
    avatar_url: string;
}
export declare const OrganizationTeamMembershipActor: S.Schema<OrganizationTeamMembershipActor>;
/** The role for the password */
export type OrganizationTeamMembershipPasswordsItemRole = "reader" | "writer" | "admin" | "readwriter";
export declare const OrganizationTeamMembershipPasswordsItemRole: any;
/** List of IP addresses or CIDR ranges that can use this password */
export type OrganizationTeamMembershipPasswordsItemCidrsList = Array<string>;
export declare const OrganizationTeamMembershipPasswordsItemCidrsList: S.Schema<OrganizationTeamMembershipPasswordsItemCidrsList>;
/** The list of hosts in each availability zone providing direct access to a vtgate */
export type OrganizationTeamMembershipPasswordsItemDirectVtgateAddressesList = Array<string>;
export declare const OrganizationTeamMembershipPasswordsItemDirectVtgateAddressesList: S.Schema<OrganizationTeamMembershipPasswordsItemDirectVtgateAddressesList>;
/** The read-only replica host URLs */
export type OrganizationTeamMembershipPasswordsItemAccessHostRegionalUrlsList = Array<string>;
export declare const OrganizationTeamMembershipPasswordsItemAccessHostRegionalUrlsList: S.Schema<OrganizationTeamMembershipPasswordsItemAccessHostRegionalUrlsList>;
export type OrganizationTeamMembershipPasswordsItemActor = OrganizationTeamMembershipActor;
export declare const OrganizationTeamMembershipPasswordsItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type OrganizationTeamMembershipPasswordsItemRegionPublicIpAddressesList = Array<string>;
export declare const OrganizationTeamMembershipPasswordsItemRegionPublicIpAddressesList: S.Schema<OrganizationTeamMembershipPasswordsItemRegionPublicIpAddressesList>;
export interface OrganizationTeamMembershipPasswordsItemRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: OrganizationTeamMembershipPasswordsItemRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const OrganizationTeamMembershipPasswordsItemRegion: S.Schema<OrganizationTeamMembershipPasswordsItemRegion>;
export interface OrganizationTeamMembershipPasswordsItemDatabaseBranch {
    /** The name for the branch */
    name: string;
    /** The ID for the branch */
    id: string;
    /** Whether or not the branch is a production branch */
    production: boolean;
    /** The address of the MySQL provider for the branch */
    mysql_edge_address: string;
    /** True if private connectivity is enabled */
    private_edge_connectivity: boolean;
}
export declare const OrganizationTeamMembershipPasswordsItemDatabaseBranch: S.Schema<OrganizationTeamMembershipPasswordsItemDatabaseBranch>;
export interface OrganizationTeamMembershipPasswordsItem {
    /** The ID for the password */
    id: string;
    /** The display name for the password */
    name: string;
    /** The role for the password */
    role: OrganizationTeamMembershipPasswordsItemRole;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs: OrganizationTeamMembershipPasswordsItemCidrsList | null;
    /** When the password was created */
    created_at: string;
    /** When the password was deleted */
    deleted_at: string | null;
    /** When the password will expire */
    expires_at: string | null;
    /** When the password was last used to execute a query */
    last_used_at: string | null;
    /** True if the credentials are expired */
    expired: boolean;
    /** True if the credentials connect directly to a vtgate, bypassing load balancers */
    direct_vtgate: boolean;
    /** The list of hosts in each availability zone providing direct access to a vtgate */
    direct_vtgate_addresses: OrganizationTeamMembershipPasswordsItemDirectVtgateAddressesList;
    /** Time to live (in seconds) for the password. The password will be invalid when TTL has passed */
    ttl_seconds: number | null;
    /** The host URL for the password */
    access_host_url: string;
    /** The regional host URL */
    access_host_regional_url: string;
    /** The read-only replica host URLs */
    access_host_regional_urls: OrganizationTeamMembershipPasswordsItemAccessHostRegionalUrlsList;
    actor: OrganizationTeamMembershipActor | null;
    region: OrganizationTeamMembershipPasswordsItemRegion;
    /** The username for the password */
    username: string;
    /** The plaintext password. Null except in the response from the create endpoint. */
    plain_text: Redacted.Redacted<string> | null;
    /** Whether or not the password is for a read replica */
    replica: boolean;
    /** Whether or not the password is scoped to a read-only region */
    read_only_region: boolean;
    /** Whether or not the password can be renewed */
    renewable: boolean;
    database_branch: OrganizationTeamMembershipPasswordsItemDatabaseBranch;
}
export declare const OrganizationTeamMembershipPasswordsItem: S.Schema<OrganizationTeamMembershipPasswordsItem>;
export type OrganizationTeamMembershipPasswordsList = Array<OrganizationTeamMembershipPasswordsItem>;
export declare const OrganizationTeamMembershipPasswordsList: S.Schema<OrganizationTeamMembershipPasswordsList>;
export interface OrganizationTeamMembership {
    /** The ID of the team membership */
    id: string;
    user: OrganizationTeamMembershipUser;
    actor: OrganizationTeamMembershipActor;
    /** When the membership was created */
    created_at: string;
    /** When the membership was last updated */
    updated_at: string;
    passwords: OrganizationTeamMembershipPasswordsList;
}
export declare const OrganizationTeamMembership: S.Schema<OrganizationTeamMembership>;
export interface CancelBouncerResizeRequestRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the bouncer */
    bouncer: string;
}
export declare const CancelBouncerResizeRequestRequest: S.Schema<CancelBouncerResizeRequestRequest>;
export interface CancelBouncerResizeRequestResponse {
}
export declare const CancelBouncerResizeRequestResponse: S.Schema<CancelBouncerResizeRequestResponse>;
export interface CancelBranchChangeRequestRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const CancelBranchChangeRequestRequest: S.Schema<CancelBranchChangeRequestRequest>;
export interface CancelBranchChangeRequestResponse {
}
export declare const CancelBranchChangeRequestResponse: S.Schema<CancelBranchChangeRequestResponse>;
export interface CancelDeployRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const CancelDeployRequestRequest: S.Schema<CancelDeployRequestRequest>;
export type DatabaseDeployRequestActor = OrganizationTeamMembershipActor;
export declare const DatabaseDeployRequestActor: S.Schema<OrganizationTeamMembershipActor>;
export type DatabaseDeployRequestClosedBy = OrganizationTeamMembershipActor;
export declare const DatabaseDeployRequestClosedBy: S.Schema<OrganizationTeamMembershipActor>;
export type DatabaseDeployRequestBranchDeletedBy = OrganizationTeamMembershipActor;
export declare const DatabaseDeployRequestBranchDeletedBy: S.Schema<OrganizationTeamMembershipActor>;
/** Whether the deploy request is open or closed */
export type DatabaseDeployRequestState = "open" | "closed";
export declare const DatabaseDeployRequestState: any;
/** The deployment state of the deploy request */
export type DatabaseDeployRequestDeploymentState = "pending" | "ready" | "no_changes" | "queued" | "submitting" | "in_progress" | "pending_cutover" | "in_progress_vschema" | "in_progress_cancel" | "in_progress_cutover" | "complete" | "complete_cancel" | "complete_error" | "complete_pending_revert" | "in_progress_revert" | "in_progress_revert_vschema" | "complete_revert" | "complete_revert_error" | "cancelled" | "error";
export declare const DatabaseDeployRequestDeploymentState: any;
/** The state the deployment is in */
export type DatabaseDeployRequestDeploymentState2 = "pending" | "ready" | "no_changes" | "queued" | "submitting" | "in_progress" | "pending_cutover" | "in_progress_vschema" | "in_progress_cancel" | "in_progress_cutover" | "complete" | "complete_cancel" | "complete_error" | "complete_pending_revert" | "in_progress_revert" | "in_progress_revert_vschema" | "complete_revert" | "complete_revert_error" | "cancelled" | "error";
export declare const DatabaseDeployRequestDeploymentState2: any;
export type DatabaseDeployRequestDeploymentPrecedingDeploymentsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseDeployRequestDeploymentPrecedingDeploymentsItemMap: S.Schema<DatabaseDeployRequestDeploymentPrecedingDeploymentsItemMap>;
/** The deployments ahead of this one in the queue */
export type DatabaseDeployRequestDeploymentPrecedingDeploymentsList = Array<DatabaseDeployRequestDeploymentPrecedingDeploymentsItemMap>;
export declare const DatabaseDeployRequestDeploymentPrecedingDeploymentsList: S.Schema<DatabaseDeployRequestDeploymentPrecedingDeploymentsList>;
/** The state of the deploy operation */
export type DatabaseDeployRequestDeploymentDeployOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const DatabaseDeployRequestDeploymentDeployOperationsItemState: any;
/** Names of foreign keys removed by this operation */
export type DatabaseDeployRequestDeploymentDeployOperationsItemRemovedForeignKeyNamesList = Array<string>;
export declare const DatabaseDeployRequestDeploymentDeployOperationsItemRemovedForeignKeyNamesList: S.Schema<DatabaseDeployRequestDeploymentDeployOperationsItemRemovedForeignKeyNamesList>;
export interface DatabaseDeployRequestDeploymentDeployOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The state of the deploy operation */
    state: DatabaseDeployRequestDeploymentDeployOperationsItemState;
    /** The keyspace modified by the deploy operation */
    keyspace_name: string;
    /** The name of the table modifed by the deploy operation */
    table_name: string;
    /** The operation name of the deploy operation */
    operation_name: string;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number | null;
    /** The percent completion for the deploy operation */
    progress_percentage: number | null;
    /** A link to documentation explaining the deploy error, if present */
    deploy_error_docs_url: string | null;
    /** The DDL statement for the deploy operation */
    ddl_statement: string;
    /** A syntax-highlighted DDL statement for the deploy operation */
    syntax_highlighted_ddl: string;
    /** When the deploy operation was created */
    created_at: string;
    /** When the deploy operation was last updated */
    updated_at: string;
    /** When the deploy operation was last throttled */
    throttled_at: string | null;
    /** Whether or not the deploy operation is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation is currently locked */
    table_locked: boolean;
    /** Whether or not the table modified by the deploy operation was recently used */
    table_recently_used: boolean;
    /** When the table modified by the deploy operation was last used */
    table_recently_used_at: string | null;
    /** Names of foreign keys removed by this operation */
    removed_foreign_key_names: DatabaseDeployRequestDeploymentDeployOperationsItemRemovedForeignKeyNamesList | null;
    /** Deploy errors for the deploy operation */
    deploy_errors: string | null;
}
export declare const DatabaseDeployRequestDeploymentDeployOperationsItem: S.Schema<DatabaseDeployRequestDeploymentDeployOperationsItem>;
export type DatabaseDeployRequestDeploymentDeployOperationsList = Array<DatabaseDeployRequestDeploymentDeployOperationsItem>;
export declare const DatabaseDeployRequestDeploymentDeployOperationsList: S.Schema<DatabaseDeployRequestDeploymentDeployOperationsList>;
/** The state of the deploy operation summary */
export type DatabaseDeployRequestDeploymentDeployOperationSummariesItemState = "pending" | "in_progress" | "complete" | "cancelled" | "error";
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItemState: any;
/** Names of foreign keys removed by this operation summary */
export type DatabaseDeployRequestDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList = Array<string>;
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList: S.Schema<DatabaseDeployRequestDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList>;
/** Names of shards in the keyspace modified by the deploy operation summary */
export type DatabaseDeployRequestDeploymentDeployOperationSummariesItemShardNamesList = Array<string>;
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItemShardNamesList: S.Schema<DatabaseDeployRequestDeploymentDeployOperationSummariesItemShardNamesList>;
/** The state of the deploy operation */
export type DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItemState: any;
export interface DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The shard the deploy operation is being performed on */
    shard: string;
    /** The state of the deploy operation */
    state: DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItemState;
    /** The percent completion for the deploy operation */
    progress_percentage: number;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number;
}
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItem: S.Schema<DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItem>;
export type DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsList = Array<DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsItem>;
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsList: S.Schema<DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsList>;
export interface DatabaseDeployRequestDeploymentDeployOperationSummariesItem {
    /** The ID for the deploy operation summary */
    id: string;
    /** When the deploy operation summary was created */
    created_at: string;
    /** Deploy errors for the deploy operation summary */
    deploy_errors: string;
    /** The DDL statement for the deploy operation summary */
    ddl_statement: string;
    /** The estimated seconds until completion for the deploy operation summary */
    eta_seconds: number;
    /** The keyspace modified by the deploy operation summary */
    keyspace_name: string;
    /** The operation name of the deploy operation summary */
    operation_name: string;
    /** The percent completion for the deploy operation summary */
    progress_percentage: number;
    /** The state of the deploy operation summary */
    state: DatabaseDeployRequestDeploymentDeployOperationSummariesItemState;
    /** A syntax-highlighted DDL statement for the deploy operation summary */
    syntax_highlighted_ddl: string;
    /** The name of the table modifed by the deploy operation summary */
    table_name: string;
    /** When the table modified by the deploy operation summary was last used */
    table_recently_used_at: string | null;
    /** When the deploy operation summary was last throttled */
    throttled_at: string | null;
    /** Names of foreign keys removed by this operation summary */
    removed_foreign_key_names: DatabaseDeployRequestDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList;
    /** The number of shards in the keyspace modified by the deploy operation summary */
    shard_count: number;
    /** Names of shards in the keyspace modified by the deploy operation summary */
    shard_names: DatabaseDeployRequestDeploymentDeployOperationSummariesItemShardNamesList;
    /** Whether or not the deploy operation summary is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation summary was recently used */
    table_recently_used: boolean;
    /** Whether or not the keyspace modified by the deploy operation summary is sharded */
    sharded: boolean;
    operations: DatabaseDeployRequestDeploymentDeployOperationSummariesItemOperationsList;
}
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesItem: S.Schema<DatabaseDeployRequestDeploymentDeployOperationSummariesItem>;
export type DatabaseDeployRequestDeploymentDeployOperationSummariesList = Array<DatabaseDeployRequestDeploymentDeployOperationSummariesItem>;
export declare const DatabaseDeployRequestDeploymentDeployOperationSummariesList: S.Schema<DatabaseDeployRequestDeploymentDeployOperationSummariesList>;
export type DatabaseDeployRequestDeploymentLintErrorsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseDeployRequestDeploymentLintErrorsItemMap: S.Schema<DatabaseDeployRequestDeploymentLintErrorsItemMap>;
/** Schema lint errors preventing the deployment from completing */
export type DatabaseDeployRequestDeploymentLintErrorsList = Array<DatabaseDeployRequestDeploymentLintErrorsItemMap>;
export declare const DatabaseDeployRequestDeploymentLintErrorsList: S.Schema<DatabaseDeployRequestDeploymentLintErrorsList>;
export type DatabaseDeployRequestDeploymentSequentialDiffDependenciesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseDeployRequestDeploymentSequentialDiffDependenciesItemMap: S.Schema<DatabaseDeployRequestDeploymentSequentialDiffDependenciesItemMap>;
/** The schema dependencies that must be satisfied */
export type DatabaseDeployRequestDeploymentSequentialDiffDependenciesList = Array<DatabaseDeployRequestDeploymentSequentialDiffDependenciesItemMap>;
export declare const DatabaseDeployRequestDeploymentSequentialDiffDependenciesList: S.Schema<DatabaseDeployRequestDeploymentSequentialDiffDependenciesList>;
export type DatabaseDeployRequestDeploymentLookupVindexOperationsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseDeployRequestDeploymentLookupVindexOperationsItemMap: S.Schema<DatabaseDeployRequestDeploymentLookupVindexOperationsItemMap>;
/** Lookup Vitess index operations */
export type DatabaseDeployRequestDeploymentLookupVindexOperationsList = Array<DatabaseDeployRequestDeploymentLookupVindexOperationsItemMap>;
export declare const DatabaseDeployRequestDeploymentLookupVindexOperationsList: S.Schema<DatabaseDeployRequestDeploymentLookupVindexOperationsList>;
/** Deployment throttling configurations. */
export type DatabaseDeployRequestDeploymentThrottlerConfigurationsMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseDeployRequestDeploymentThrottlerConfigurationsMap: S.Schema<DatabaseDeployRequestDeploymentThrottlerConfigurationsMap>;
/** The request to revert the schema operations in this deployment */
export type DatabaseDeployRequestDeploymentDeploymentRevertRequestMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseDeployRequestDeploymentDeploymentRevertRequestMap: S.Schema<DatabaseDeployRequestDeploymentDeploymentRevertRequestMap>;
export type DatabaseDeployRequestDeploymentActor = OrganizationTeamMembershipActor;
export declare const DatabaseDeployRequestDeploymentActor: S.Schema<OrganizationTeamMembershipActor>;
export type DatabaseDeployRequestDeploymentCutoverActor = OrganizationTeamMembershipActor;
export declare const DatabaseDeployRequestDeploymentCutoverActor: S.Schema<OrganizationTeamMembershipActor>;
export type DatabaseDeployRequestDeploymentCancelledActor = OrganizationTeamMembershipActor;
export declare const DatabaseDeployRequestDeploymentCancelledActor: S.Schema<OrganizationTeamMembershipActor>;
export interface DatabaseDeployRequestDeployment {
    /** The ID of the deployment */
    id: string;
    /** Whether or not to automatically cutover once deployment is finished */
    auto_cutover: boolean;
    /** Whether or not to automatically delete the head branch once deployment is finished */
    auto_delete_branch: boolean;
    /** When the deployment was created */
    created_at: string;
    /** When the cutover for the deployment was initiated */
    cutover_at: string | null;
    /** Whether or not the deployment cutover will expire soon */
    cutover_expiring: boolean;
    /** Deploy check errors for the deployment. */
    deploy_check_errors?: string | null;
    /** When the deployment was finished */
    finished_at: string | null;
    /** When force cutover was triggered for the deployment */
    force_cutover_requested_at: string | null;
    /** When the deployment was queued */
    queued_at: string | null;
    /** When the deployment was ready for cutover */
    ready_to_cutover_at: string | null;
    /** When the deployment was started */
    started_at: string | null;
    /** The state the deployment is in */
    state: DatabaseDeployRequestDeploymentState2;
    /** When the deployment was submitted */
    submitted_at: string | null;
    /** When the deployment was last updated */
    updated_at: string;
    /** The name of the base branch the deployment will be merged into */
    into_branch: string;
    /** The number of the deploy request associated with this deployment */
    deploy_request_number: number;
    /** Whether the deployment is deployable */
    deployable: boolean;
    /** The deployments ahead of this one in the queue */
    preceding_deployments: DatabaseDeployRequestDeploymentPrecedingDeploymentsList;
    deploy_operations: DatabaseDeployRequestDeploymentDeployOperationsList;
    deploy_operation_summaries: DatabaseDeployRequestDeploymentDeployOperationSummariesList;
    /** Schema lint errors preventing the deployment from completing */
    lint_errors: DatabaseDeployRequestDeploymentLintErrorsList;
    /** The schema dependencies that must be satisfied */
    sequential_diff_dependencies: DatabaseDeployRequestDeploymentSequentialDiffDependenciesList;
    /** Lookup Vitess index operations */
    lookup_vindex_operations: DatabaseDeployRequestDeploymentLookupVindexOperationsList;
    /** Deployment throttling configurations. */
    throttler_configurations?: DatabaseDeployRequestDeploymentThrottlerConfigurationsMap | null;
    /** The request to revert the schema operations in this deployment */
    deployment_revert_request: DatabaseDeployRequestDeploymentDeploymentRevertRequestMap | null;
    actor?: OrganizationTeamMembershipActor | null;
    cutover_actor?: OrganizationTeamMembershipActor | null;
    cancelled_actor?: OrganizationTeamMembershipActor | null;
    /** When the schema was last updated for the deployment */
    schema_last_updated_at: string | null;
    /** Whether or not the deployment has a table locked */
    table_locked: boolean;
    /** The name of the table that is locked by the deployment. */
    locked_table_name?: string | null;
    /** Whether or not the deployment is an instant DDL deployment */
    instant_ddl: boolean;
    /** Whether or not the deployment is eligible for instant DDL */
    instant_ddl_eligible: boolean;
    /** Whether the deploy queue for the target branch is currently paused */
    queue_paused: boolean;
    /** A human-readable reason the deploy queue is paused, if known */
    queue_pause_reason: string | null;
}
export declare const DatabaseDeployRequestDeployment: S.Schema<DatabaseDeployRequestDeployment>;
export interface DatabaseDeployRequest {
    /** The ID of the deploy request */
    id: string;
    /** The number of the deploy request */
    number: number;
    actor: OrganizationTeamMembershipActor;
    closed_by?: OrganizationTeamMembershipActor | null;
    /** The name of the branch the deploy request was created from */
    branch: string;
    /** The ID of the branch the deploy request was created from */
    branch_id: string;
    /** Whether or not the deploy request branch was deleted */
    branch_deleted: boolean;
    branch_deleted_by?: OrganizationTeamMembershipActor | null;
    /** When the deploy request branch was deleted */
    branch_deleted_at: string | null;
    /** The name of the branch the deploy request will be merged into */
    into_branch: string;
    /** Whether or not the branch the deploy request will be merged into is sharded */
    into_branch_sharded: boolean;
    /** The number of shards the branch the deploy request will be merged into has */
    into_branch_shard_count: number;
    /** The number of keyspaces the branch the deploy request will be merged into has */
    into_branch_keyspace_count: number;
    /** Whether or not the deploy request is approved */
    approved: boolean;
    /** Whether the deploy request is open or closed */
    state: DatabaseDeployRequestState;
    /** The deployment state of the deploy request */
    deployment_state: DatabaseDeployRequestDeploymentState;
    deployment: DatabaseDeployRequestDeployment;
    /** The number of comments on the deploy request */
    num_comments: number;
    /** The PlanetScale app address for the deploy request */
    html_url: string;
    /** Notes on the deploy request */
    notes: string;
    /** The HTML body of the deploy request */
    html_body: string;
    /** When the deploy request was created */
    created_at: string;
    /** When the deploy request was last updated */
    updated_at: string;
    /** When the deploy request was closed */
    closed_at: string | null;
    /** When the deploy request was deployed */
    deployed_at: string | null;
}
export declare const DatabaseDeployRequest: S.Schema<DatabaseDeployRequest>;
export interface CancelKeyspaceResizeRequestRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
}
export declare const CancelKeyspaceResizeRequestRequest: S.Schema<CancelKeyspaceResizeRequestRequest>;
export interface CancelKeyspaceResizeRequestResponse {
}
export declare const CancelKeyspaceResizeRequestResponse: S.Schema<CancelKeyspaceResizeRequestResponse>;
export interface CancelWorkflowRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const CancelWorkflowRequest: S.Schema<CancelWorkflowRequest>;
/** The state of the workflow */
export type WorkflowState = "pending" | "copying" | "running" | "stopped" | "verifying_data" | "verified_data" | "switching_replicas" | "switched_replicas" | "switching_primaries" | "switched_primaries" | "reversing_traffic" | "reversing_traffic_for_cancel" | "cutting_over" | "cutover" | "reversed_cutover" | "completed" | "cancelling" | "cancelled" | "error";
export declare const WorkflowState: any;
/** The type of the workflow */
export type WorkflowWorkflowType = "move_tables";
export declare const WorkflowWorkflowType: any;
/** The behavior when DDL changes during the workflow */
export type WorkflowOnDdl = "IGNORE" | "STOP" | "EXEC" | "EXEC_IGNORE";
export declare const WorkflowOnDdl: any;
export type WorkflowActor = OrganizationTeamMembershipActor;
export declare const WorkflowActor: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowVerifyDataBy = OrganizationTeamMembershipActor;
export declare const WorkflowVerifyDataBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowReversedBy = OrganizationTeamMembershipActor;
export declare const WorkflowReversedBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowSwitchReplicasBy = OrganizationTeamMembershipActor;
export declare const WorkflowSwitchReplicasBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowSwitchPrimariesBy = OrganizationTeamMembershipActor;
export declare const WorkflowSwitchPrimariesBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowCancelledBy = OrganizationTeamMembershipActor;
export declare const WorkflowCancelledBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowCompletedBy = OrganizationTeamMembershipActor;
export declare const WorkflowCompletedBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowRetriedBy = OrganizationTeamMembershipActor;
export declare const WorkflowRetriedBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowCutoverBy = OrganizationTeamMembershipActor;
export declare const WorkflowCutoverBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowReversedCutoverBy = OrganizationTeamMembershipActor;
export declare const WorkflowReversedCutoverBy: S.Schema<OrganizationTeamMembershipActor>;
export type WorkflowBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const WorkflowBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type WorkflowSourceKeyspace = OrganizationTeamMembershipUserDefaultOrganization;
export declare const WorkflowSourceKeyspace: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type WorkflowTargetKeyspace = OrganizationTeamMembershipUserDefaultOrganization;
export declare const WorkflowTargetKeyspace: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type WorkflowGlobalKeyspace = OrganizationTeamMembershipUserDefaultOrganization;
export declare const WorkflowGlobalKeyspace: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface Workflow {
    /** The ID of the workflow */
    id: string;
    /** The name of the workflow */
    name: string;
    /** The sequence number of the workflow */
    number: number;
    /** The state of the workflow */
    state: WorkflowState;
    /** When the workflow was created */
    created_at: string;
    /** When the workflow was last updated */
    updated_at: string;
    /** When the workflow was started */
    started_at: string | null;
    /** When the workflow was completed */
    completed_at: string | null;
    /** When the workflow was cancelled */
    cancelled_at: string | null;
    /** When the workflow was reversed */
    reversed_at: string | null;
    /** When the workflow was retried */
    retried_at: string | null;
    /** When the data copy was completed */
    data_copy_completed_at: string | null;
    /** When the cutover was completed */
    cutover_at: string | null;
    /** Whether or not the replicas have been switched */
    replicas_switched: boolean;
    /** Whether or not the primaries have been switched */
    primaries_switched: boolean;
    /** When the replicas were switched */
    switch_replicas_at: string | null;
    /** When the primaries were switched */
    switch_primaries_at: string | null;
    /** When the data was verified */
    verify_data_at: string | null;
    /** The type of the workflow */
    workflow_type: WorkflowWorkflowType;
    /** The subtype of the workflow */
    workflow_subtype: string;
    /** Whether or not secondary keys are deferred */
    defer_secondary_keys: boolean;
    /** The behavior when DDL changes during the workflow */
    on_ddl: WorkflowOnDdl;
    /** The errors that occurred during the workflow */
    workflow_errors: string;
    /** Whether or not the workflow may be retried */
    may_retry: boolean;
    /** Whether or not the workflow may be restarted */
    may_restart: boolean;
    /** Whether or not the verified data is stale */
    verified_data_stale: boolean;
    /** Whether or not sequence tables have been created */
    sequence_tables_applied: boolean;
    actor: OrganizationTeamMembershipActor;
    verify_data_by: OrganizationTeamMembershipActor;
    reversed_by: OrganizationTeamMembershipActor;
    switch_replicas_by: OrganizationTeamMembershipActor;
    switch_primaries_by: OrganizationTeamMembershipActor;
    cancelled_by: OrganizationTeamMembershipActor;
    completed_by: OrganizationTeamMembershipActor;
    retried_by: OrganizationTeamMembershipActor;
    cutover_by: OrganizationTeamMembershipActor;
    reversed_cutover_by: OrganizationTeamMembershipActor;
    branch: OrganizationTeamMembershipUserDefaultOrganization;
    source_keyspace: OrganizationTeamMembershipUserDefaultOrganization;
    target_keyspace: OrganizationTeamMembershipUserDefaultOrganization;
    global_keyspace: OrganizationTeamMembershipUserDefaultOrganization;
}
export declare const Workflow: S.Schema<Workflow>;
export interface CompleteRevertRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const CompleteRevertRequest: S.Schema<CompleteRevertRequest>;
export interface CompleteWorkflowRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const CompleteWorkflowRequest: S.Schema<CompleteWorkflowRequest>;
export interface ConfigureOrganizationSsoRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const ConfigureOrganizationSsoRequest: S.Schema<ConfigureOrganizationSsoRequest>;
export interface ConfigureOrganizationSsoResponse {
    /** URL to open for configuring the identity provider */
    portal_url: string;
}
export declare const ConfigureOrganizationSsoResponse: S.Schema<ConfigureOrganizationSsoResponse>;
/** Unit for the retention period of the backup */
export type CreateBackupRequestRetentionUnit = "hour" | "day" | "week" | "month" | "year";
export declare const CreateBackupRequestRetentionUnit: any;
export interface CreateBackupRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** Name for the backup */
    name?: string;
    /** Unit for the retention period of the backup */
    retention_unit?: CreateBackupRequestRetentionUnit | (string & {});
    /** Value between `1` and `1000` for the retention period of the backup (i.e retention_value `6` and retention_unit `hour` means 6 hours) */
    retention_value?: number;
    /** Whether the backup is an immediate backup that may affect database performance. Emergency backups are only supported for PostgreSQL databases. */
    emergency?: boolean;
}
export declare const CreateBackupRequest: S.Schema<CreateBackupRequest>;
/** The current state of the backup */
export type BackupState = "pending" | "running" | "success" | "failed" | "canceled" | "ignored";
export declare const BackupState: any;
export type BackupRestoredBranchesItem = OrganizationTeamMembershipUserDefaultOrganization;
export declare const BackupRestoredBranchesItem: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type BackupRestoredBranchesList = Array<OrganizationTeamMembershipUserDefaultOrganization>;
export declare const BackupRestoredBranchesList: S.Schema<BackupRestoredBranchesList>;
export type BackupActor = OrganizationTeamMembershipActor;
export declare const BackupActor: S.Schema<OrganizationTeamMembershipActor>;
/** Whether the policy is for production or development branches */
export type BackupBackupPolicyTarget = "production" | "development";
export declare const BackupBackupPolicyTarget: any;
export interface BackupBackupPolicy {
    /** The ID of the backup policy */
    id: string;
    /** The display name of the backup policy */
    display_name: string;
    /** The name of the backup policy */
    name: string;
    /** Whether the policy is for production or development branches */
    target: BackupBackupPolicyTarget;
    /** A number value for the retention period of the backup policy */
    retention_value: number;
    /** The unit for the retention period of the backup policy */
    retention_unit: string;
    /** A number value for the frequency of the backup policy */
    frequency_value: number;
    /** The unit for the frequency of the backup policy */
    frequency_unit: string;
    /** The time of day that the backup is scheduled, in HH:MM format */
    schedule_time: string | null;
    /** Day of the week that the backup is scheduled. 0 is Sunday, 6 is Saturday */
    schedule_day: number | null;
    /** Week of the month that the backup is scheduled. 0 is the first week, 3 is the fourth week */
    schedule_week: number | null;
    /** When the backup policy was created */
    created_at: string;
    /** When the backup policy was last updated */
    updated_at: string;
    /** When the backup was last run */
    last_ran_at: string | null;
    /** When the backup will next run */
    next_run_at: string | null;
    /** Whether the policy is a required system backup */
    required: boolean;
}
export declare const BackupBackupPolicy: S.Schema<BackupBackupPolicy>;
export interface BackupSchemaSnapshot {
    /** The ID of the schema snapshot */
    id: string;
    /** The name of the schema snapshot */
    name: string;
    /** When the schema snapshot was created */
    created_at: string;
    /** When the schema snapshot was last updated */
    updated_at: string;
    /** When the schema snapshot was last linted */
    linted_at: string | null;
    /** The URL to the schema snapshot in the PlanetScale app */
    url: string;
}
export declare const BackupSchemaSnapshot: S.Schema<BackupSchemaSnapshot>;
export type BackupDatabaseBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const BackupDatabaseBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface Backup {
    /** The ID of the backup */
    id: string;
    /** The name of the backup */
    name: string;
    /** The current state of the backup */
    state: BackupState;
    /** The size of the backup in bytes */
    size: number;
    /** The estimated storage cost of the backup */
    estimated_storage_cost: number;
    /** When the backup was created */
    created_at: string;
    /** When the backup was last updated */
    updated_at: string;
    /** When the backup started */
    started_at: string | null;
    /** When the backup expires */
    expires_at: string | null;
    /** When the backup completed */
    completed_at: string | null;
    /** When the backup was deleted */
    deleted_at: string | null;
    /** Size of the PVC used for the backup */
    pvc_size: number;
    /** The uncompressed (logical) size of the backup in bytes */
    uncompressed_size: number;
    /** Whether or not the backup is protected from deletion */
    protected: boolean;
    /** Whether or not the backup policy is required */
    required: boolean;
    restored_branches: BackupRestoredBranchesList;
    actor: OrganizationTeamMembershipActor | null;
    backup_policy?: BackupBackupPolicy | null;
    schema_snapshot?: BackupSchemaSnapshot | null;
    database_branch?: OrganizationTeamMembershipUserDefaultOrganization | null;
}
export declare const Backup: S.Schema<Backup>;
/** Whether the policy is for production or development branches */
export type CreateBackupPolicyRequestTarget = "production" | "development";
export declare const CreateBackupPolicyRequestTarget: any;
/** The unit for the retention period of the backup policy */
export type CreateBackupPolicyRequestRetentionUnit = "hour" | "day" | "week" | "month" | "year";
export declare const CreateBackupPolicyRequestRetentionUnit: any;
/** The unit for the frequency of the backup policy */
export type CreateBackupPolicyRequestFrequencyUnit = "hour" | "day" | "week" | "month";
export declare const CreateBackupPolicyRequestFrequencyUnit: any;
export interface CreateBackupPolicyRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The name of the backup policy */
    name?: string;
    /** Whether the policy is for production or development branches */
    target?: CreateBackupPolicyRequestTarget | (string & {});
    /** A number value for the retention period of the backup policy */
    retention_value?: number;
    /** The unit for the retention period of the backup policy */
    retention_unit?: CreateBackupPolicyRequestRetentionUnit | (string & {});
    /** A number value for the frequency of the backup policy */
    frequency_value?: number;
    /** The unit for the frequency of the backup policy */
    frequency_unit?: CreateBackupPolicyRequestFrequencyUnit | (string & {});
    /** The time of day that the backup is scheduled, in HH:MM format */
    schedule_time?: string;
    /** Day of the week that the backup is scheduled. 0 is Sunday, 6 is Saturday */
    schedule_day?: number;
    /** Week of the month that the backup is scheduled. 0 is the first week, 3 is the fourth week */
    schedule_week?: number;
}
export declare const CreateBackupPolicyRequest: S.Schema<CreateBackupPolicyRequest>;
/** Whether the policy is for production or development branches */
export type BackupPolicyTarget = "production" | "development";
export declare const BackupPolicyTarget: any;
export interface BackupPolicy {
    /** The ID of the backup policy */
    id: string;
    /** The display name of the backup policy */
    display_name: string;
    /** The name of the backup policy */
    name: string;
    /** Whether the policy is for production or development branches */
    target: BackupPolicyTarget;
    /** A number value for the retention period of the backup policy */
    retention_value: number;
    /** The unit for the retention period of the backup policy */
    retention_unit: string;
    /** A number value for the frequency of the backup policy */
    frequency_value: number;
    /** The unit for the frequency of the backup policy */
    frequency_unit: string;
    /** The time of day that the backup is scheduled, in HH:MM format */
    schedule_time: string;
    /** Day of the week that the backup is scheduled. 0 is Sunday, 6 is Saturday */
    schedule_day: number | null;
    /** Week of the month that the backup is scheduled. 0 is the first week, 3 is the fourth week */
    schedule_week: number | null;
    /** When the backup policy was created */
    created_at: string;
    /** When the backup policy was last updated */
    updated_at: string;
    /** When the backup was last run */
    last_ran_at: string | null;
    /** When the backup will next run */
    next_run_at: string | null;
    /** Whether the policy is a required system backup */
    required: boolean;
}
export declare const BackupPolicy: S.Schema<BackupPolicy>;
export interface CreateBouncerRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The bouncer name */
    name?: string;
    /** The type of server the bouncer targets */
    target?: string;
    /** The size SKU for the bouncer */
    bouncer_size?: string;
    /** The number of replica servers per cell */
    replicas_per_cell?: number;
}
export declare const CreateBouncerRequest: S.Schema<CreateBouncerRequest>;
export interface PostgresBouncerSku {
    /** The name of the Postgres bouncer SKU */
    name: string;
    /** The display name */
    display_name: string;
    /** The CPU allocation */
    cpu: string;
    /** The amount of memory in bytes */
    ram: number;
    /** The sort order of the Postgres bouncer SKU */
    sort_order: number;
}
export declare const PostgresBouncerSku: S.Schema<PostgresBouncerSku>;
/** The instance type the bouncer targets */
export type PostgresBouncerTarget = "primary" | "replica" | "replica_az_affinity";
export declare const PostgresBouncerTarget: any;
export type PostgresBouncerActor = OrganizationTeamMembershipActor;
export declare const PostgresBouncerActor: S.Schema<OrganizationTeamMembershipActor>;
export type PostgresBouncerBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PostgresBouncerBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
/** The namespace of the parameter */
export type PostgresBouncerParametersItemNamespace = "pgbouncer";
export declare const PostgresBouncerParametersItemNamespace: any;
/** The type of the parameter */
export type PostgresBouncerParametersItemParameterType = "array" | "integer" | "seconds" | "select" | "string";
export declare const PostgresBouncerParametersItemParameterType: any;
/** Valid options for the parameter value */
export type PostgresBouncerParametersItemOptionsList = Array<string>;
export declare const PostgresBouncerParametersItemOptionsList: S.Schema<PostgresBouncerParametersItemOptionsList>;
export type PostgresBouncerParametersItemActor = OrganizationTeamMembershipActor;
export declare const PostgresBouncerParametersItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PostgresBouncerParametersItem {
    /** The ID of the parameter */
    id: string;
    /** The namespace of the parameter */
    namespace: PostgresBouncerParametersItemNamespace;
    /** The name of the parameter */
    name: string;
    /** The display name of the parameter */
    display_name: string;
    /** The category of the parameter */
    category: string;
    /** The description of the parameter */
    description: string;
    /** Whether the parameter can be changed */
    immutable: boolean;
    /** The type of the parameter */
    parameter_type: PostgresBouncerParametersItemParameterType;
    /** The default value of the parameter */
    default_value: string;
    /** The configured value of the parameter */
    value: string;
    /** Whether the parameter is required */
    required: boolean;
    /** When the parameter was created */
    created_at: string;
    /** When the parameter was last updated */
    updated_at: string;
    /** True if processes require a server restart on change */
    restart: boolean;
    /** The maximum value of the parameter */
    max: number;
    /** The minimum value of the parameter */
    min: number;
    /** The URL of the parameter */
    url: string;
    /** Valid options for the parameter value */
    options: PostgresBouncerParametersItemOptionsList;
    actor: OrganizationTeamMembershipActor;
}
export declare const PostgresBouncerParametersItem: S.Schema<PostgresBouncerParametersItem>;
export type PostgresBouncerParametersList = Array<PostgresBouncerParametersItem>;
export declare const PostgresBouncerParametersList: S.Schema<PostgresBouncerParametersList>;
export interface PostgresBouncer {
    /** The ID of the bouncer */
    id: string;
    /** The name of the bouncer */
    name: string;
    sku: PostgresBouncerSku;
    /** The instance type the bouncer targets */
    target: PostgresBouncerTarget;
    /** The count of replicas in each cell */
    replicas_per_cell: number;
    /** When the bouncer was created */
    created_at: string;
    /** When the bouncer was updated */
    updated_at: string;
    /** When the bouncer was deleted */
    deleted_at: string | null;
    actor: OrganizationTeamMembershipActor;
    branch: OrganizationTeamMembershipUserDefaultOrganization;
    parameters: PostgresBouncerParametersList;
}
export declare const PostgresBouncer: S.Schema<PostgresBouncer>;
/** If provided, restores the last successful backup's schema and data to the new branch. Must have `restore_production_branch_backup(s)` or `restore_backup(s)` access to do this, in addition to Data Branching™ being enabled for the branch. */
export type CreateBranchRequestSeedData = "last_successful_backup";
export declare const CreateBranchRequestSeedData: any;
/** For MySQL backup restores, per-keyspace cluster sizes. Each entry is { "keyspace_name": "main", "cluster_size": "PS_40" }. When provided, each restored keyspace must have a size here or via cluster_size. */
export type CreateBranchRequestKeyspaceClusterSizesList = Array<string>;
export declare const CreateBranchRequestKeyspaceClusterSizesList: S.Schema<CreateBranchRequestKeyspaceClusterSizesList>;
export interface CreateBranchRequestStorage {
    /** The minimum storage size in bytes. */
    minimum_storage_bytes?: number;
    /** The maximum storage size in bytes for autoscaling. */
    maximum_storage_bytes?: number;
}
export declare const CreateBranchRequestStorage: S.Schema<CreateBranchRequestStorage>;
/** The kind of branch to create. Required when create_database_if_missing is set. */
export type CreateBranchRequestKind = "mysql" | "postgresql";
export declare const CreateBranchRequestKind: any;
export interface CreateBranchRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch to create */
    name: string;
    /** Whether deletion protection is enabled for the branch */
    deletion_protected?: boolean;
    /** The name of the parent branch. Defaults to the database's default branch if not provided. */
    parent_branch?: string;
    /** If provided, restores the backup's schema and data to the new branch. Must have `restore_production_branch_backup(s)` or `restore_backup(s)` access to do this. */
    backup_id?: string;
    /** The region to create the branch in. If not provided, the branch will be created in the default region for its database. */
    region?: string;
    /** Restore from a point-in-time recovery timestamp (e.g. 2023-01-01T00:00:00Z). Available only for PostgreSQL databases. */
    restore_point?: string;
    /** For PostgreSQL backup restores and point-in-time recovery, the number of additional replicas from 0 to 8, subject to the target cluster size. 0 creates a single-node branch. If omitted, the target cluster size's minimum is used. */
    replicas?: number;
    /** If provided, restores the last successful backup's schema and data to the new branch. Must have `restore_production_branch_backup(s)` or `restore_backup(s)` access to do this, in addition to Data Branching™ being enabled for the branch. */
    seed_data?: CreateBranchRequestSeedData | (string & {});
    /** The database cluster size. Required if a backup_id is provided (unless keyspace_cluster_sizes covers every keyspace), optional otherwise. Options: PS_10, PS_20, PS_40, ..., PS_2800 */
    cluster_size?: string;
    /** For MySQL backup restores, per-keyspace cluster sizes. Each entry is { "keyspace_name": "main", "cluster_size": "PS_40" }. When provided, each restored keyspace must have a size here or via cluster_size. */
    keyspace_cluster_sizes?: CreateBranchRequestKeyspaceClusterSizesList;
    storage?: CreateBranchRequestStorage;
    /** For PostgreSQL databases, the PostgreSQL major version to use for the branch. Defaults to the major version of the parent branch if it exists or the database's default branch major version. Ignored for branches restored from backups. */
    major_version?: string;
    /** Create a new database for the branch if the database does not exist. Defaults to false. */
    create_database_if_missing?: boolean;
    /** The kind of branch to create. Required when create_database_if_missing is set. */
    kind?: CreateBranchRequestKind | (string & {});
}
export declare const CreateBranchRequest: S.Schema<CreateBranchRequest>;
/** The kind of branch */
export type DatabaseBranchKind = "mysql" | "postgresql";
export declare const DatabaseBranchKind: any;
/** The current state of the branch */
export type DatabaseBranchState = "pending" | "sleep_in_progress" | "sleeping" | "awakening" | "ready";
export declare const DatabaseBranchState: any;
export type DatabaseBranchActor = OrganizationTeamMembershipActor;
export declare const DatabaseBranchActor: S.Schema<OrganizationTeamMembershipActor>;
export type DatabaseBranchRestoredFromBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const DatabaseBranchRestoredFromBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
/** Public IP addresses for the region */
export type DatabaseBranchRegionPublicIpAddressesList = Array<string>;
export declare const DatabaseBranchRegionPublicIpAddressesList: S.Schema<DatabaseBranchRegionPublicIpAddressesList>;
export interface DatabaseBranchRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: DatabaseBranchRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const DatabaseBranchRegion: S.Schema<DatabaseBranchRegion>;
/** VTGate configuration options */
export type DatabaseBranchVtgateOptionsMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseBranchVtgateOptionsMap: S.Schema<DatabaseBranchVtgateOptionsMap>;
export interface DatabaseBranch {
    /** The ID of the branch */
    id: string;
    /** The name of the branch */
    name: string;
    /** When the branch was created */
    created_at: string;
    /** When the branch was last updated */
    updated_at: string;
    /** When the branch was deleted */
    deleted_at: string | null;
    /** When a user last marked a backup restore checklist as completed */
    restore_checklist_completed_at: string | null;
    /** When the schema for the branch was last updated */
    schema_last_updated_at: string | null;
    /** The kind of branch */
    kind: DatabaseBranchKind;
    /** The MySQL address for the branch */
    mysql_address?: string;
    /** The address of the MySQL provider for the branch */
    mysql_edge_address?: string;
    /** The current state of the branch */
    state: DatabaseBranchState;
    /** True if the branch allows passwords to connect directly to a vtgate, bypassing load balancers */
    direct_vtgate?: boolean;
    /** The size of the vtgate cluster for the branch */
    vtgate_size?: string;
    /** The public SKU representing the VTGate size */
    vtgate_name?: string | null;
    /** The number of vtgate instances in the branch */
    vtgate_count?: number;
    /** Whether VTGate autoscaling is enabled */
    vtgate_autoscaling?: boolean;
    /** The maximum number of VTGate instances when autoscaling is enabled */
    vtgate_max_count?: number | null;
    /** The target CPU utilization for VTGate autoscaling */
    vtgate_target_cpu_utilization?: number | null;
    /** The SKU representing the branch's cluster size */
    cluster_name: string;
    /** IOPS for the cluster */
    cluster_iops: number | null;
    /** Whether or not the branch is ready to serve queries */
    ready: boolean;
    /** Whether or not the schema is ready for queries */
    schema_ready?: boolean;
    /** Whether or not this is a metal database */
    metal: boolean;
    /** Whether or not the branch is a production branch */
    production: boolean;
    /** Whether or not the branch has safe migrations enabled */
    safe_migrations: boolean;
    /** Whether deletion protection is enabled for the branch */
    deletion_protected?: boolean;
    /** Whether or not the branch is sharded */
    sharded?: boolean;
    /** The number of shards in the branch */
    shard_count?: number;
    /** The number of keyspaces in the branch */
    keyspace_count?: number;
    /** Whether or not the branch has a stale schema */
    stale_schema: boolean;
    actor: OrganizationTeamMembershipActor | null;
    restored_from_branch: OrganizationTeamMembershipUserDefaultOrganization | null;
    /** True if private connections are enabled */
    private_edge_connectivity: boolean;
    /** True if the branch has replica servers */
    has_replicas: boolean;
    /** True if the branch has read-only replica servers */
    has_read_only_replicas: boolean;
    /** Planetscale app URL for the branch */
    html_url: string;
    /** Planetscale API URL for the branch */
    url: string;
    region: DatabaseBranchRegion;
    /** The name of the parent branch from which the branch was created */
    parent_branch: string | null;
    /** VTGate configuration options */
    vtgate_options?: DatabaseBranchVtgateOptionsMap;
    cluster_architecture?: string;
}
export declare const DatabaseBranch: S.Schema<DatabaseBranch>;
/** The kind of database to create. */
export type CreateDatabaseRequestKind = "mysql" | "postgresql";
export declare const CreateDatabaseRequestKind: any;
export interface CreateDatabaseRequestStorage {
    /** The initial minimum storage size in bytes. */
    minimum_storage_bytes?: number;
    /** The maximum storage size in bytes for autoscaling. */
    maximum_storage_bytes?: number;
}
export declare const CreateDatabaseRequestStorage: S.Schema<CreateDatabaseRequestStorage>;
export interface CreateDatabaseRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Name of the database */
    name: string;
    /** The region the database will be deployed in. If left blank, defaults to the organization's default region. */
    region?: string;
    /** The database cluster size name (e.g., 'PS_10', 'PS_80'). Use the 'List available cluster sizes' endpoint to get available options for your organization. /v1/organizations/:organization/cluster-size-skus */
    cluster_size: string;
    /** The number of replicas for the database. 0 for non-HA, 2+ for HA. */
    replicas?: number;
    /** The kind of database to create. */
    kind?: CreateDatabaseRequestKind | (string & {});
    /** For PostgreSQL databases, the PostgreSQL major version to use for the database. Defaults to the latest available major version. */
    major_version?: string;
    storage?: CreateDatabaseRequestStorage;
}
export declare const CreateDatabaseRequest: S.Schema<CreateDatabaseRequest>;
export interface DatabaseDataImportDataSource {
    /** Hostname of the data source */
    hostname: string;
    /** Port of the data source */
    port: number;
    /** Database name of the data source */
    database: string;
}
export declare const DatabaseDataImportDataSource: S.Schema<DatabaseDataImportDataSource>;
export interface DatabaseDataImport {
    /** State of the data import */
    state: string;
    /** Errors encountered during the import check */
    import_check_errors: string;
    /** When the import started */
    started_at: string | null;
    /** When the import finished */
    finished_at: string | null;
    data_source: DatabaseDataImportDataSource;
}
export declare const DatabaseDataImport: S.Schema<DatabaseDataImport>;
/** Public IP addresses for the region */
export type DatabaseRegionPublicIpAddressesList = Array<string>;
export declare const DatabaseRegionPublicIpAddressesList: S.Schema<DatabaseRegionPublicIpAddressesList>;
export interface DatabaseRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: DatabaseRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const DatabaseRegion: S.Schema<DatabaseRegion>;
/** State of the database */
export type DatabaseState = "pending" | "importing" | "sleep_in_progress" | "sleeping" | "awakening" | "import_ready" | "ready";
export declare const DatabaseState: any;
/** The kind of database */
export type DatabaseKind = "mysql" | "postgresql";
export declare const DatabaseKind: any;
export interface Database {
    /** The ID of the database */
    id: string;
    /** The URL to the database API endpoint */
    url: string;
    /** The URL to retrieve this database's branches via the API */
    branches_url: string;
    /** The total number of database branches */
    branches_count?: number;
    /** The total number of schema recommendations */
    open_schema_recommendations_count?: number;
    /** The total number of database development branches */
    development_branches_count?: number;
    /** The total number of database production branches */
    production_branches_count?: number;
    /** The total number of ongoing issues within a database */
    issues_count?: number | null;
    /** If the database requires multiple admins for deletion */
    multiple_admins_required_for_deletion?: boolean;
    /** If the database is ready to be used */
    ready: boolean;
    /** If the database has reached its backup restored branch limit */
    at_backup_restore_branches_limit?: boolean;
    /** If the database has reached its development branch limit */
    at_development_branch_usage_limit?: boolean;
    data_import?: DatabaseDataImport | null;
    region: DatabaseRegion;
    /** The URL to see this database's branches in the web UI */
    html_url: string;
    /** Name of the database */
    name: string;
    /** State of the database */
    state: DatabaseState;
    /** If the database is sharded */
    sharded?: boolean;
    /** Number of shards in the default branch */
    default_branch_shard_count?: number;
    /** Number of read only regions in the default branch */
    default_branch_read_only_regions_count?: number;
    /** Number of tables in the default branch schema */
    default_branch_table_count?: number;
    /** The default branch for the database */
    default_branch?: string;
    /** Whether an approval is required to deploy schema changes to this database */
    require_approval_for_deploy?: boolean;
    /** Whether deletion protection is enabled for the database */
    deletion_protected?: boolean;
    /** True if a branch is currently resizing */
    resizing?: boolean;
    /** True if a branch has a queued resize request */
    resize_queued?: boolean;
    /** True if a config change is in progress */
    config_changing?: boolean;
    /** True if a config change is queued for maintenance window */
    config_change_queued?: boolean;
    /** Whether seeding branches with data is enabled for all branches */
    allow_data_branching?: boolean;
    /** Whether foreign key constraints are enabled */
    foreign_keys_enabled?: boolean;
    /** Whether to automatically manage Rails migrations during deploy requests. */
    automatic_migrations?: boolean | null;
    /** Whether to restrict branch creation to one region */
    restrict_branch_region?: boolean;
    /** Whether deploy requests default to instant deploy when it is available */
    prefer_instant?: boolean;
    /** Whether raw SQL queries are collected */
    insights_raw_queries?: boolean;
    /** The database plan */
    plan?: string;
    /** True if query insights is enabled for the database */
    insights_enabled?: boolean;
    /** Whether web console is enabled for production branches */
    production_branch_web_console?: boolean;
    /** Table name to use for copying schema migration data. */
    migration_table_name?: string | null;
    /** Framework used for applying migrations. */
    migration_framework?: string | null;
    /** When the database was created */
    created_at: string;
    /** When the database was last updated */
    updated_at: string;
    /** When the default branch schema was last changed. */
    schema_last_updated_at?: string | null;
    /** The kind of database */
    kind: DatabaseKind;
}
export declare const Database: S.Schema<Database>;
/** List of IPv4 CIDR ranges (e.g., ['192.168.1.0/24', '192.168.1.1/32']). Must contain at least one valid IPv4 address or range. */
export type CreateDatabasePostgresCidrRequestCidrsList = Array<string>;
export declare const CreateDatabasePostgresCidrRequestCidrsList: S.Schema<CreateDatabasePostgresCidrRequestCidrsList>;
export interface CreateDatabasePostgresCidrRequest {
    /** The name of the organization the database belongs to */
    organization: string;
    /** The name of the database */
    database: string;
    /** The PostgreSQL schema to restrict access to. Leave empty or omit to allow access to all schemas. */
    schema?: string;
    /** The PostgreSQL role to restrict access to. Leave empty or omit to allow access for all roles. */
    role?: string;
    /** List of IPv4 CIDR ranges (e.g., ['192.168.1.0/24', '192.168.1.1/32']). Must contain at least one valid IPv4 address or range. */
    cidrs: CreateDatabasePostgresCidrRequestCidrsList;
    /** An optional description for the IP restriction rule. */
    description?: string;
}
export declare const CreateDatabasePostgresCidrRequest: S.Schema<CreateDatabasePostgresCidrRequest>;
/** List of CIDR ranges */
export type PostgresClusterCidrCidrsList = Array<string>;
export declare const PostgresClusterCidrCidrsList: S.Schema<PostgresClusterCidrCidrsList>;
export type PostgresClusterCidrActor = OrganizationTeamMembershipActor;
export declare const PostgresClusterCidrActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PostgresClusterCidr {
    /** The ID of the IP allowlist entry */
    id: string;
    /** The schema name to restrict access to (optional) */
    schema: string;
    /** The role to restrict access to (optional) */
    role: string;
    /** List of CIDR ranges */
    cidrs: PostgresClusterCidrCidrsList;
    /** An optional description for the IP restriction rule */
    description: string | null;
    /** When the entry was created */
    created_at: string;
    /** When the entry was updated */
    updated_at: string;
    /** When the entry was deleted */
    deleted_at: string | null;
    actor: OrganizationTeamMembershipActor;
}
export declare const PostgresClusterCidr: S.Schema<PostgresClusterCidr>;
export interface CreateDeployRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The name of the branch the deploy request is created from */
    branch: string;
    /** The name of the branch the deploy request will be merged into */
    into_branch: string;
    /** Notes about the deploy request */
    notes?: string;
    /** Whether or not to enable auto_cutover for the deploy request. When enabled, will auto cutover to the new schema as soon as it is ready. */
    auto_cutover?: boolean;
    /** Whether or not to enable auto_delete_branch for the deploy request. When enabled, will delete the branch once the DR successfully completes. */
    auto_delete_branch?: boolean;
}
export declare const CreateDeployRequestRequest: S.Schema<CreateDeployRequestRequest>;
export interface CreateKeyspaceRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    name: string;
    /** The database cluster size name (e.g., 'PS_10', 'PS_80'). Use the 'List available cluster sizes' endpoint to get available options for your organization. /v1/organizations/:organization/cluster-size-skus */
    cluster_size: string;
    /** The number of additional replicas beyond the included default */
    extra_replicas?: number;
    /** The number of shards. Default: 1 */
    shards?: number;
}
export declare const CreateKeyspaceRequest: S.Schema<CreateKeyspaceRequest>;
/** Controls when node TTL drains are allowed */
export type DatabaseBranchKeyspaceNodeTtlStrategy = "node_ttl_follow_maintenance" | "node_ttl_always" | "node_ttl_off";
export declare const DatabaseBranchKeyspaceNodeTtlStrategy: any;
/** The replication durability strategy */
export type DatabaseBranchKeyspaceReplicationDurabilityConstraintsStrategy = "available" | "lag" | "always";
export declare const DatabaseBranchKeyspaceReplicationDurabilityConstraintsStrategy: any;
export interface DatabaseBranchKeyspaceReplicationDurabilityConstraints {
    /** The replication durability strategy */
    strategy?: DatabaseBranchKeyspaceReplicationDurabilityConstraintsStrategy | null;
}
export declare const DatabaseBranchKeyspaceReplicationDurabilityConstraints: S.Schema<DatabaseBranchKeyspaceReplicationDurabilityConstraints>;
export interface DatabaseBranchKeyspaceVreplicationFlags {
    /** Enable optimized inserts */
    optimize_inserts: boolean;
    /** Allow no blob binlog row image */
    allow_no_blob_binlog_row_image: boolean;
    /** Enable VPlayer batching */
    vplayer_batching: boolean;
}
export declare const DatabaseBranchKeyspaceVreplicationFlags: S.Schema<DatabaseBranchKeyspaceVreplicationFlags>;
/** MySQL daemon configuration options */
export type DatabaseBranchKeyspaceMysqldOptionsMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseBranchKeyspaceMysqldOptionsMap: S.Schema<DatabaseBranchKeyspaceMysqldOptionsMap>;
/** VTTablet configuration options */
export type DatabaseBranchKeyspaceVttabletOptionsMap = {
    [key: string]: unknown | undefined;
};
export declare const DatabaseBranchKeyspaceVttabletOptionsMap: S.Schema<DatabaseBranchKeyspaceVttabletOptionsMap>;
export interface DatabaseBranchKeyspace {
    /** The ID of the keyspace */
    id: string;
    /** Name of the keyspace */
    name: string;
    /** The number of keyspace shards */
    shards: number;
    /** If the keyspace is sharded */
    sharded: boolean;
    /** If the keyspace uses an external datasource */
    external: boolean;
    /** Total number of replicas in the keyspace */
    replicas: number;
    /** Number of extra replicas in the keyspace */
    extra_replicas: number;
    /** When the keyspace was created */
    created_at: string;
    /** When the keyspace was last updated */
    updated_at: string;
    /** The SKU representing the keyspace cluster size */
    cluster_name: string;
    /** The SKU representing the keyspace cluster size for display */
    cluster_display_name: string;
    /** Is the keyspace currently resizing */
    resizing: boolean;
    /** True if the keyspace has an unfinished resize request */
    resize_in_progress: boolean;
    /** Is the keyspace awaiting a resize */
    resize_pending: boolean;
    /** Is the keyspace undergoing a config change */
    config_change_in_progress: boolean;
    /** Is the keyspace provisioned and serving traffic */
    ready: boolean;
    /** Is the keyspace running on metal instances */
    metal: boolean;
    /** Is this the default keyspace for the branch */
    default: boolean;
    /** Is this keyspace used in an import */
    imported: boolean;
    /** Percentage of buffer pool memory allocated to vector indexes */
    vector_pool_allocation: number | null;
    /** Controls when node TTL drains are allowed */
    node_ttl_strategy: DatabaseBranchKeyspaceNodeTtlStrategy;
    replication_durability_constraints: DatabaseBranchKeyspaceReplicationDurabilityConstraints;
    vreplication_flags: DatabaseBranchKeyspaceVreplicationFlags;
    /** MySQL daemon configuration options */
    mysqld_options: DatabaseBranchKeyspaceMysqldOptionsMap;
    /** VTTablet configuration options */
    vttablet_options: DatabaseBranchKeyspaceVttabletOptionsMap;
}
export declare const DatabaseBranchKeyspace: S.Schema<DatabaseBranchKeyspace>;
export interface CreateKeyspaceResizeRequestRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
    /** The new cluster size for the keyspace: PS_10, PS_20,… */
    cluster_size?: string;
    /** The number of additional replicas per shard beyond the cluster size's included default (each production cluster includes 2 replicas) */
    extra_replicas?: number;
}
export declare const CreateKeyspaceResizeRequestRequest: S.Schema<CreateKeyspaceResizeRequestRequest>;
export type KeyspaceResizeRequestActor = OrganizationTeamMembershipActor;
export declare const KeyspaceResizeRequestActor: S.Schema<OrganizationTeamMembershipActor>;
export interface KeyspaceResizeRequest {
    /** The ID of the keyspace resize request */
    id: string;
    /** The state of the keyspace resize request: pending, resizing, completed, or cancelled */
    state: string;
    /** The time the resize started, or null when still queued */
    started_at: string | null;
    /** The time the resize completed, or null while in progress */
    completed_at: string | null;
    /** The time the resize request was created */
    created_at: string;
    /** The time the resize request was last updated */
    updated_at: string;
    /** The total number of replicas after the resize */
    replicas: number;
    /** The number of additional replicas beyond the cluster size's included default after the resize */
    extra_replicas: number;
    /** The total number of replicas before the resize */
    previous_replicas: number;
    /** The SKU representing the keyspace's cluster after the resize */
    cluster_name: string;
    /** The SKU representing the keyspace's cluster after the resize, for display */
    cluster_display_name?: string;
    /** The SKU representing the keyspace's cluster before the resize */
    previous_cluster_name: string;
    /** The SKU representing the keyspace's cluster before the resize, for display */
    previous_cluster_display_name?: string;
    /** The number of read-only replicas after the resize */
    rdonly_replicas?: number | null;
    /** The number of read-only replicas before the resize */
    previous_rdonly_replicas?: number | null;
    /** The vector pool allocation after the resize */
    vector_pool_allocation?: number | null;
    /** The vector pool allocation before the resize */
    previous_vector_pool_allocation?: number | null;
    actor?: OrganizationTeamMembershipActor;
}
export declare const KeyspaceResizeRequest: S.Schema<KeyspaceResizeRequest>;
/** Whether an OAuth grant code or a refresh token is being exchanged for an OAuth token */
export type CreateOauthTokenRequestGrantType = "authorization_code" | "refresh_token";
export declare const CreateOauthTokenRequestGrantType: any;
export interface CreateOauthTokenRequest {
    /** The name of the organization the OAuth application belongs to */
    organization: string;
    /** The ID of the OAuth application */
    id: string;
    /** The OAuth application's client ID */
    client_id: string;
    /** The OAuth application's client secret */
    client_secret: Redacted.Redacted<string>;
    /** Whether an OAuth grant code or a refresh token is being exchanged for an OAuth token */
    grant_type: CreateOauthTokenRequestGrantType | (string & {});
    /** The OAuth grant code provided to your OAuth application's redirect URI. Required when grant_type is authorization_code */
    code?: string;
    /** The OAuth application's redirect URI. Required when grant_type is authorization_code */
    redirect_uri?: string;
    /** The refresh token from the original OAuth token grant. Required when grant_type is refresh_token */
    refresh_token?: Redacted.Redacted<string>;
}
export declare const CreateOauthTokenRequest: S.Schema<CreateOauthTokenRequest>;
export type ServiceTokenServiceTokenAccessesItemResource = OrganizationTeamMembershipUserDefaultOrganization;
export declare const ServiceTokenServiceTokenAccessesItemResource: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface ServiceTokenServiceTokenAccessesItem {
    /** The ID of the service token access */
    id: string;
    /** The name of the service token access */
    access: string;
    /** The description of the service token access */
    description: string;
    /** The name of the resource the service token access gives access to */
    resource_name: string;
    /** The ID of the resource the service token access gives access to */
    resource_id: string;
    /** The type of the resource the service token access gives access to */
    resource_type: string;
    resource: OrganizationTeamMembershipUserDefaultOrganization;
}
export declare const ServiceTokenServiceTokenAccessesItem: S.Schema<ServiceTokenServiceTokenAccessesItem>;
export type ServiceTokenServiceTokenAccessesList = Array<ServiceTokenServiceTokenAccessesItem>;
export declare const ServiceTokenServiceTokenAccessesList: S.Schema<ServiceTokenServiceTokenAccessesList>;
export interface ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem {
    /** the name of the database the token has access to */
    name: string;
    /** the id of the database the token has access to */
    id: string;
    /** the name of the database's organization */
    organization: string;
    /** the planetscale app url for the database */
    url: string;
}
export declare const ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem>;
export type ServiceTokenOauthAccessesByResourceDatabaseDatabasesList = Array<ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem>;
export declare const ServiceTokenOauthAccessesByResourceDatabaseDatabasesList: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseDatabasesList>;
export interface ServiceTokenOauthAccessesByResourceDatabaseAccessesItem {
    /** The name of the access scope */
    name: string;
    /** The scope description */
    description: string;
}
export declare const ServiceTokenOauthAccessesByResourceDatabaseAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type ServiceTokenOauthAccessesByResourceDatabaseAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const ServiceTokenOauthAccessesByResourceDatabaseAccessesList: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesList>;
export interface ServiceTokenOauthAccessesByResourceDatabase {
    databases: ServiceTokenOauthAccessesByResourceDatabaseDatabasesList;
    accesses: ServiceTokenOauthAccessesByResourceDatabaseAccessesList;
}
export declare const ServiceTokenOauthAccessesByResourceDatabase: S.Schema<ServiceTokenOauthAccessesByResourceDatabase>;
export interface ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem {
    /** the name of the organization */
    name: string;
    /** the id of the organization */
    id: string;
    /** the planetscale app url for the organization */
    url: string;
}
export declare const ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem: S.Schema<ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem>;
export type ServiceTokenOauthAccessesByResourceOrganizationOrganizationsList = Array<ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem>;
export declare const ServiceTokenOauthAccessesByResourceOrganizationOrganizationsList: S.Schema<ServiceTokenOauthAccessesByResourceOrganizationOrganizationsList>;
export type ServiceTokenOauthAccessesByResourceOrganizationAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const ServiceTokenOauthAccessesByResourceOrganizationAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type ServiceTokenOauthAccessesByResourceOrganizationAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const ServiceTokenOauthAccessesByResourceOrganizationAccessesList: S.Schema<ServiceTokenOauthAccessesByResourceOrganizationAccessesList>;
export interface ServiceTokenOauthAccessesByResourceOrganization {
    organizations: ServiceTokenOauthAccessesByResourceOrganizationOrganizationsList;
    accesses: ServiceTokenOauthAccessesByResourceOrganizationAccessesList;
}
export declare const ServiceTokenOauthAccessesByResourceOrganization: S.Schema<ServiceTokenOauthAccessesByResourceOrganization>;
export interface ServiceTokenOauthAccessesByResourceBranchBranchesItem {
    /** the name of the branch */
    name: string;
    /** the id of the branch */
    id: string;
    /** the name of the database the branch belongs to */
    database: string;
    /** the name of the organization the branch belongs to */
    organization: string;
    /** the planetscale app url for the branch */
    url: string;
}
export declare const ServiceTokenOauthAccessesByResourceBranchBranchesItem: S.Schema<ServiceTokenOauthAccessesByResourceBranchBranchesItem>;
export type ServiceTokenOauthAccessesByResourceBranchBranchesList = Array<ServiceTokenOauthAccessesByResourceBranchBranchesItem>;
export declare const ServiceTokenOauthAccessesByResourceBranchBranchesList: S.Schema<ServiceTokenOauthAccessesByResourceBranchBranchesList>;
export type ServiceTokenOauthAccessesByResourceBranchAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const ServiceTokenOauthAccessesByResourceBranchAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type ServiceTokenOauthAccessesByResourceBranchAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const ServiceTokenOauthAccessesByResourceBranchAccessesList: S.Schema<ServiceTokenOauthAccessesByResourceBranchAccessesList>;
export interface ServiceTokenOauthAccessesByResourceBranch {
    branches: ServiceTokenOauthAccessesByResourceBranchBranchesList;
    accesses: ServiceTokenOauthAccessesByResourceBranchAccessesList;
}
export declare const ServiceTokenOauthAccessesByResourceBranch: S.Schema<ServiceTokenOauthAccessesByResourceBranch>;
export interface ServiceTokenOauthAccessesByResourceUserUsersItem {
    /** the name of the user */
    name: string;
    /** the id of the user */
    id: string;
}
export declare const ServiceTokenOauthAccessesByResourceUserUsersItem: S.Schema<ServiceTokenOauthAccessesByResourceUserUsersItem>;
export type ServiceTokenOauthAccessesByResourceUserUsersList = Array<ServiceTokenOauthAccessesByResourceUserUsersItem>;
export declare const ServiceTokenOauthAccessesByResourceUserUsersList: S.Schema<ServiceTokenOauthAccessesByResourceUserUsersList>;
export type ServiceTokenOauthAccessesByResourceUserAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const ServiceTokenOauthAccessesByResourceUserAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type ServiceTokenOauthAccessesByResourceUserAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const ServiceTokenOauthAccessesByResourceUserAccessesList: S.Schema<ServiceTokenOauthAccessesByResourceUserAccessesList>;
export interface ServiceTokenOauthAccessesByResourceUser {
    users: ServiceTokenOauthAccessesByResourceUserUsersList;
    accesses: ServiceTokenOauthAccessesByResourceUserAccessesList;
}
export declare const ServiceTokenOauthAccessesByResourceUser: S.Schema<ServiceTokenOauthAccessesByResourceUser>;
export interface ServiceTokenOauthAccessesByResource {
    database: ServiceTokenOauthAccessesByResourceDatabase;
    organization: ServiceTokenOauthAccessesByResourceOrganization;
    branch: ServiceTokenOauthAccessesByResourceBranch;
    user: ServiceTokenOauthAccessesByResourceUser;
}
export declare const ServiceTokenOauthAccessesByResource: S.Schema<ServiceTokenOauthAccessesByResource>;
export interface ServiceToken {
    /** The ID of the service token */
    id: string;
    /** The name of the service token */
    name?: string | null;
    /** The display name of the service token */
    display_name: string;
    /** The plaintext token. Available only after create. */
    token?: Redacted.Redacted<string> | null;
    /** The plaintext refresh token. Available only after create. */
    plain_text_refresh_token?: Redacted.Redacted<string> | null;
    /** The image source for the avatar of the service token */
    avatar_url: string;
    /** When the service token was created */
    created_at: string;
    /** When the service token was last updated */
    updated_at: string;
    /** When the service token will expire */
    expires_at?: string | null;
    /** When the service token was last used */
    last_used_at?: string | null;
    /** The ID of the actor on whose behalf the service token was created */
    actor_id: string | null;
    /** The name of the actor on whose behalf the service token was created */
    actor_display_name: string | null;
    /** The type of the actor on whose behalf the service token was created */
    actor_type: string | null;
    service_token_accesses?: ServiceTokenServiceTokenAccessesList | null;
    oauth_accesses_by_resource?: ServiceTokenOauthAccessesByResource | null;
}
export declare const ServiceToken: S.Schema<ServiceToken>;
export interface CreateOrganizationSsoDomainRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const CreateOrganizationSsoDomainRequest: S.Schema<CreateOrganizationSsoDomainRequest>;
export interface CreateOrganizationSsoDomainResponse {
    /** URL to open for verifying an email domain */
    portal_url: string;
}
export declare const CreateOrganizationSsoDomainResponse: S.Schema<CreateOrganizationSsoDomainResponse>;
export interface CreateOrganizationTeamRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the team */
    name: string;
    /** A description of the team's purpose */
    description?: string;
}
export declare const CreateOrganizationTeamRequest: S.Schema<CreateOrganizationTeamRequest>;
export type OrganizationTeamCreator = OrganizationTeamMembershipActor;
export declare const OrganizationTeamCreator: S.Schema<OrganizationTeamMembershipActor>;
export type OrganizationTeamMembersItemDefaultOrganization = OrganizationTeamMembershipUserDefaultOrganization;
export declare const OrganizationTeamMembersItemDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type OrganizationTeamMembersItem = OrganizationTeamMembershipUser;
export declare const OrganizationTeamMembersItem: S.Schema<OrganizationTeamMembershipUser>;
export type OrganizationTeamMembersList = Array<OrganizationTeamMembershipUser>;
export declare const OrganizationTeamMembersList: S.Schema<OrganizationTeamMembersList>;
export interface OrganizationTeamDatabasesItem {
    /** The ID of the database */
    id: string;
    /** The name of the database */
    name: string;
    /** The URL to the database API endpoint */
    url: string;
    /** The URL to retrieve this database's branches via the API */
    branches_url: string;
}
export declare const OrganizationTeamDatabasesItem: S.Schema<OrganizationTeamDatabasesItem>;
export type OrganizationTeamDatabasesList = Array<OrganizationTeamDatabasesItem>;
export declare const OrganizationTeamDatabasesList: S.Schema<OrganizationTeamDatabasesList>;
export type OrganizationTeamAnalystDatabasesItem = OrganizationTeamDatabasesItem;
export declare const OrganizationTeamAnalystDatabasesItem: S.Schema<OrganizationTeamDatabasesItem>;
export type OrganizationTeamAnalystDatabasesList = Array<OrganizationTeamDatabasesItem>;
export declare const OrganizationTeamAnalystDatabasesList: S.Schema<OrganizationTeamAnalystDatabasesList>;
export interface OrganizationTeam {
    /** The ID of the team */
    id: string;
    /** The display name of the team */
    display_name: string;
    creator: OrganizationTeamMembershipActor;
    members: OrganizationTeamMembersList;
    databases: OrganizationTeamDatabasesList;
    analyst_databases: OrganizationTeamAnalystDatabasesList;
    /** The name of the team */
    name: string;
    /** The slug of the team */
    slug: string;
    /** When the team was created */
    created_at: string;
    /** When the team was last updated */
    updated_at: string;
    /** The description of the team */
    description: string | null;
    /** Whether the team is managed through SSO/directory services */
    managed: boolean;
}
export declare const OrganizationTeam: S.Schema<OrganizationTeam>;
/** The database role of the password (i.e. admin) */
export type CreatePasswordRequestRole = "reader" | "writer" | "admin" | "readwriter";
export declare const CreatePasswordRequestRole: any;
/** List of IP addresses or CIDR ranges that can use this password */
export type CreatePasswordRequestCidrsList = Array<string>;
export declare const CreatePasswordRequestCidrsList: S.Schema<CreatePasswordRequestCidrsList>;
export interface CreatePasswordRequest {
    /** The name of the organization the password belongs to */
    organization: string;
    /** The name of the database the password belongs to */
    database: string;
    /** The name of the branch the password belongs to */
    branch: string;
    /** Optional name of the password */
    name?: string;
    /** The database role of the password (i.e. admin) */
    role?: CreatePasswordRequestRole | (string & {});
    /** Whether the password is for a read replica */
    replica?: boolean;
    /** Time to live (in seconds) for the password. The password will be invalid when TTL has passed */
    ttl?: number;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs?: CreatePasswordRequestCidrsList;
    /** Whether the password connects directly to a VTGate */
    direct_vtgate?: boolean;
}
export declare const CreatePasswordRequest: S.Schema<CreatePasswordRequest>;
/** The role for the password */
export type DatabaseBranchPasswordWithSecretRole = "reader" | "writer" | "admin" | "readwriter";
export declare const DatabaseBranchPasswordWithSecretRole: any;
/** List of IP addresses or CIDR ranges that can use this password */
export type DatabaseBranchPasswordWithSecretCidrsList = Array<string>;
export declare const DatabaseBranchPasswordWithSecretCidrsList: S.Schema<DatabaseBranchPasswordWithSecretCidrsList>;
/** The list of hosts in each availability zone providing direct access to a vtgate */
export type DatabaseBranchPasswordWithSecretDirectVtgateAddressesList = Array<string>;
export declare const DatabaseBranchPasswordWithSecretDirectVtgateAddressesList: S.Schema<DatabaseBranchPasswordWithSecretDirectVtgateAddressesList>;
/** The read-only replica host URLs */
export type DatabaseBranchPasswordWithSecretAccessHostRegionalUrlsList = Array<string>;
export declare const DatabaseBranchPasswordWithSecretAccessHostRegionalUrlsList: S.Schema<DatabaseBranchPasswordWithSecretAccessHostRegionalUrlsList>;
export type DatabaseBranchPasswordWithSecretActor = OrganizationTeamMembershipActor;
export declare const DatabaseBranchPasswordWithSecretActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type DatabaseBranchPasswordWithSecretRegionPublicIpAddressesList = Array<string>;
export declare const DatabaseBranchPasswordWithSecretRegionPublicIpAddressesList: S.Schema<DatabaseBranchPasswordWithSecretRegionPublicIpAddressesList>;
export interface DatabaseBranchPasswordWithSecretRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: DatabaseBranchPasswordWithSecretRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const DatabaseBranchPasswordWithSecretRegion: S.Schema<DatabaseBranchPasswordWithSecretRegion>;
export type DatabaseBranchPasswordWithSecretDatabaseBranch = OrganizationTeamMembershipPasswordsItemDatabaseBranch;
export declare const DatabaseBranchPasswordWithSecretDatabaseBranch: S.Schema<OrganizationTeamMembershipPasswordsItemDatabaseBranch>;
export interface DatabaseBranchPasswordWithSecret {
    /** The ID for the password */
    id: string;
    /** The display name for the password */
    name: string;
    /** The role for the password */
    role: DatabaseBranchPasswordWithSecretRole;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs: DatabaseBranchPasswordWithSecretCidrsList | null;
    /** When the password was created */
    created_at: string;
    /** When the password was deleted */
    deleted_at: string | null;
    /** When the password will expire */
    expires_at: string | null;
    /** When the password was last used to execute a query */
    last_used_at: string | null;
    /** True if the credentials are expired */
    expired: boolean;
    /** True if the credentials connect directly to a vtgate, bypassing load balancers */
    direct_vtgate: boolean;
    /** The list of hosts in each availability zone providing direct access to a vtgate */
    direct_vtgate_addresses: DatabaseBranchPasswordWithSecretDirectVtgateAddressesList;
    /** Time to live (in seconds) for the password. The password will be invalid when TTL has passed */
    ttl_seconds: number | null;
    /** The host URL for the password */
    access_host_url: string;
    /** The regional host URL */
    access_host_regional_url: string;
    /** The read-only replica host URLs */
    access_host_regional_urls: DatabaseBranchPasswordWithSecretAccessHostRegionalUrlsList;
    actor: OrganizationTeamMembershipActor | null;
    region: DatabaseBranchPasswordWithSecretRegion;
    /** The username for the password */
    username: string;
    /** The plaintext password. Null except in the response from the create endpoint. */
    plain_text: Redacted.Redacted<string>;
    /** Whether or not the password is for a read replica */
    replica: boolean;
    /** Whether or not the password is scoped to a read-only region */
    read_only_region: boolean;
    /** Whether or not the password can be renewed */
    renewable: boolean;
    database_branch: OrganizationTeamMembershipPasswordsItemDatabaseBranch;
}
export declare const DatabaseBranchPasswordWithSecret: S.Schema<DatabaseBranchPasswordWithSecret>;
export interface CreateQueryPatternsReportRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
}
export declare const CreateQueryPatternsReportRequest: S.Schema<CreateQueryPatternsReportRequest>;
/** The state of the download */
export type QueryPatternsDownloadState = "pending" | "completed" | "failed";
export declare const QueryPatternsDownloadState: any;
export type QueryPatternsDownloadActor = OrganizationTeamMembershipActor;
export declare const QueryPatternsDownloadActor: S.Schema<OrganizationTeamMembershipActor>;
export interface QueryPatternsDownload {
    /** The ID of the query patterns download */
    id: string;
    /** The state of the download */
    state: QueryPatternsDownloadState;
    /** When the download was created */
    created_at: string;
    /** When the download was finished */
    finished_at: string | null;
    /** The URL to access the query patterns download */
    url: string;
    /** The URL to download the query patterns file */
    download_url: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const QueryPatternsDownload: S.Schema<QueryPatternsDownload>;
export interface CreateReadOnlyReplicaRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The read-only replica name */
    name: string;
    /** The region slug for the read-only replica */
    region: string;
    /** The number of instances serving reads. Defaults to 1. */
    replicas?: number;
    /** The cluster size SKU name. Defaults to the primary cluster size. */
    cluster_size?: string;
}
export declare const CreateReadOnlyReplicaRequest: S.Schema<CreateReadOnlyReplicaRequest>;
export type PostgresReadOnlyReplicaActor = OrganizationTeamMembershipActor;
export declare const PostgresReadOnlyReplicaActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type PostgresReadOnlyReplicaRegionPublicIpAddressesList = Array<string>;
export declare const PostgresReadOnlyReplicaRegionPublicIpAddressesList: S.Schema<PostgresReadOnlyReplicaRegionPublicIpAddressesList>;
export interface PostgresReadOnlyReplicaRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PostgresReadOnlyReplicaRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PostgresReadOnlyReplicaRegion: S.Schema<PostgresReadOnlyReplicaRegion>;
/** The namespace of the parameter */
export type PostgresReadOnlyReplicaParametersItemNamespace = "pgconf";
export declare const PostgresReadOnlyReplicaParametersItemNamespace: any;
/** The type of the parameter */
export type PostgresReadOnlyReplicaParametersItemParameterType = "integer" | "time";
export declare const PostgresReadOnlyReplicaParametersItemParameterType: any;
/** Valid options for the parameter value */
export type PostgresReadOnlyReplicaParametersItemOptionsList = Array<string>;
export declare const PostgresReadOnlyReplicaParametersItemOptionsList: S.Schema<PostgresReadOnlyReplicaParametersItemOptionsList>;
/** Display units for the parameter value */
export type PostgresReadOnlyReplicaParametersItemUnitsList = Array<string>;
export declare const PostgresReadOnlyReplicaParametersItemUnitsList: S.Schema<PostgresReadOnlyReplicaParametersItemUnitsList>;
export type PostgresReadOnlyReplicaParametersItemActor = OrganizationTeamMembershipActor;
export declare const PostgresReadOnlyReplicaParametersItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PostgresReadOnlyReplicaParametersItem {
    /** The ID of the parameter */
    id: string;
    /** The namespace of the parameter */
    namespace: PostgresReadOnlyReplicaParametersItemNamespace;
    /** The name of the parameter */
    name: string;
    /** The display name of the parameter */
    display_name: string;
    /** The category of the parameter */
    category: string;
    /** The description of the parameter */
    description: string;
    /** Whether the parameter can be changed */
    immutable: boolean;
    /** The type of the parameter */
    parameter_type: PostgresReadOnlyReplicaParametersItemParameterType;
    /** The default value of the parameter, which is the primary's current value */
    default_value: string;
    /** Why the parameter cannot be changed */
    disabled_reason?: string | null;
    /** The configured value of the parameter */
    value: string;
    /** Whether the parameter is required */
    required: boolean;
    /** When the parameter was created */
    created_at: string | null;
    /** When the parameter was last updated */
    updated_at: string | null;
    /** True if processes require a server restart on change */
    restart: boolean;
    /** The maximum value of the parameter */
    max: number;
    /** The minimum value of the parameter, floored at the primary's current value */
    min: number;
    /** The URL of the parameter */
    url: string;
    /** Valid options for the parameter value */
    options: PostgresReadOnlyReplicaParametersItemOptionsList;
    /** Display units for the parameter value */
    units: PostgresReadOnlyReplicaParametersItemUnitsList;
    actor: OrganizationTeamMembershipActor;
}
export declare const PostgresReadOnlyReplicaParametersItem: S.Schema<PostgresReadOnlyReplicaParametersItem>;
export type PostgresReadOnlyReplicaParametersList = Array<PostgresReadOnlyReplicaParametersItem>;
export declare const PostgresReadOnlyReplicaParametersList: S.Schema<PostgresReadOnlyReplicaParametersList>;
export interface PostgresReadOnlyReplica {
    /** The ID of the read-only replica */
    id: string;
    /** The name of the read-only replica */
    name: string;
    /** The state of the read-only replica: pending, ready, or deleting */
    state: string;
    /** The number of instances serving reads in this read-only replica */
    replicas: number;
    /** The SKU representing the cluster size of the read-only replica */
    cluster_name: string;
    /** The SKU representing the cluster size of the read-only replica, for display */
    cluster_display_name: string;
    /** The database connection host for the read-only replica */
    access_host_url: string;
    /** The private database connection host for the read-only replica */
    private_access_host_url: string;
    /** The service name to set up private connectivity for the read-only replica */
    private_connection_service_name: string | null;
    /** When the read-only replica was created */
    created_at: string;
    /** When the read-only replica was last updated */
    updated_at: string;
    /** When the read-only replica was ready to serve queries */
    ready_at: string | null;
    /** Whether or not the read-only replica is ready to serve queries */
    ready: boolean;
    actor: OrganizationTeamMembershipActor;
    region: PostgresReadOnlyReplicaRegion;
    parameters: PostgresReadOnlyReplicaParametersList;
}
export declare const PostgresReadOnlyReplica: S.Schema<PostgresReadOnlyReplica>;
export type CreateRoleRequestInheritedRolesItem = "pg_checkpoint" | "pg_create_subscription" | "pg_maintain" | "pg_monitor" | "pg_read_all_data" | "pg_read_all_settings" | "pg_read_all_stats" | "pg_signal_backend" | "pg_stat_scan_tables" | "pg_use_reserved_connections" | "pg_write_all_data" | "postgres";
export declare const CreateRoleRequestInheritedRolesItem: any;
/** Roles to inherit from */
export type CreateRoleRequestInheritedRolesList = Array<CreateRoleRequestInheritedRolesItem | (string & {})>;
export declare const CreateRoleRequestInheritedRolesList: S.Schema<CreateRoleRequestInheritedRolesList>;
export interface CreateRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the role */
    name?: string;
    /** Time to live in seconds */
    ttl?: number;
    /** Roles to inherit from */
    inherited_roles?: CreateRoleRequestInheritedRolesList;
    /** Whether the role should have the REPLICATION attribute */
    with_replication?: boolean;
    /** Require WHERE clause on DELETE statements */
    require_where_on_delete?: string;
    /** Require WHERE clause on UPDATE statements */
    require_where_on_update?: string;
}
export declare const CreateRoleRequest: S.Schema<CreateRoleRequest>;
export type PostgresRoleInheritedRolesItem = "pg_checkpoint" | "pg_create_subscription" | "pg_maintain" | "pg_monitor" | "pg_read_all_data" | "pg_read_all_settings" | "pg_read_all_stats" | "pg_signal_backend" | "pg_stat_scan_tables" | "pg_use_reserved_connections" | "pg_write_all_data" | "postgres";
export declare const PostgresRoleInheritedRolesItem: any;
/** Database roles these credentials inherit */
export type PostgresRoleInheritedRolesList = Array<PostgresRoleInheritedRolesItem>;
export declare const PostgresRoleInheritedRolesList: S.Schema<PostgresRoleInheritedRolesList>;
export type PostgresRoleBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PostgresRoleBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PostgresRoleActor = OrganizationTeamMembershipActor;
export declare const PostgresRoleActor: S.Schema<OrganizationTeamMembershipActor>;
/** Require WHERE clause on DELETE statements */
export type PostgresRoleQuerySafetySettingsRequireWhereOnDelete = "off" | "warn" | "on";
export declare const PostgresRoleQuerySafetySettingsRequireWhereOnDelete: any;
/** Require WHERE clause on UPDATE statements */
export type PostgresRoleQuerySafetySettingsRequireWhereOnUpdate = "off" | "warn" | "on";
export declare const PostgresRoleQuerySafetySettingsRequireWhereOnUpdate: any;
export interface PostgresRoleQuerySafetySettings {
    /** Require WHERE clause on DELETE statements */
    require_where_on_delete: PostgresRoleQuerySafetySettingsRequireWhereOnDelete;
    /** Require WHERE clause on UPDATE statements */
    require_where_on_update: PostgresRoleQuerySafetySettingsRequireWhereOnUpdate;
}
export declare const PostgresRoleQuerySafetySettings: S.Schema<PostgresRoleQuerySafetySettings>;
export interface PostgresRole {
    /** The ID of the role */
    id: string;
    /** The name of the role */
    name: string;
    /** The database connection string */
    access_host_url: string;
    /** The database connection string for private connections */
    private_access_host_url: string;
    /** The service name to set up private connectivity */
    private_connection_service_name: string;
    /** The database user name */
    username: string;
    /** The base username without branch routing suffix */
    base_username: string;
    /** The plaintext password, available only after create */
    password: Redacted.Redacted<string> | null;
    /** The database name */
    database_name: string;
    /** When the role was created */
    created_at: string;
    /** When the role was updated */
    updated_at: string;
    /** When the role was deleted */
    deleted_at: string | null;
    /** When the role expires */
    expires_at: string | null;
    /** When the role was dropped */
    dropped_at: string | null;
    /** When the role was disabled */
    disabled_at: string | null;
    /** Error message available when dropping the role fails */
    drop_failed: string | null;
    /** Whether the role is ready to accept connections */
    ready: boolean;
    /** True if the credentials are expired */
    expired: boolean;
    /** Whether the role is the default postgres user */
    default: boolean;
    /** Number of seconds before the credentials expire */
    ttl: number | null;
    /** Database roles these credentials inherit */
    inherited_roles: PostgresRoleInheritedRolesList;
    /** Whether the role has the REPLICATION attribute */
    with_replication: boolean;
    branch: OrganizationTeamMembershipUserDefaultOrganization;
    actor: OrganizationTeamMembershipActor;
    query_safety_settings: PostgresRoleQuerySafetySettings;
}
export declare const PostgresRole: S.Schema<PostgresRole>;
export interface CreateServiceTokenRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the service token */
    name?: string;
    /** Time to live (in seconds) for the service token. The token will be invalid when TTL has passed */
    ttl?: number;
}
export declare const CreateServiceTokenRequest: S.Schema<CreateServiceTokenRequest>;
export interface CreateSwitchoverRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The exact `name` of the replica returned by the branch's Postgres infrastructure endpoint to promote. Omit to let the operator select an eligible replica. Only applies to branches with replicas. */
    candidate?: string;
}
export declare const CreateSwitchoverRequest: S.Schema<CreateSwitchoverRequest>;
/** The state of the switchover */
export type PostgresSwitchoverState = "pending" | "running" | "succeeded" | "failed" | "canceled";
export declare const PostgresSwitchoverState: any;
/** How the primary was moved. `switchover` promotes a replica on a highly available branch; `restart` restarts the single instance of a branch that has no replicas. Absent until the operator selects one. */
export type PostgresSwitchoverMethod = "switchover" | "restart";
export declare const PostgresSwitchoverMethod: any;
export type PostgresSwitchoverActor = OrganizationTeamMembershipActor;
export declare const PostgresSwitchoverActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PostgresSwitchover {
    /** The ID of the switchover */
    id: string;
    /** The state of the switchover */
    state: PostgresSwitchoverState;
    /** How the primary was moved. `switchover` promotes a replica on a highly available branch; `restart` restarts the single instance of a branch that has no replicas. Absent until the operator selects one. */
    method?: PostgresSwitchoverMethod | null;
    /** Why the switchover failed. A failed switchover has an unconfirmed outcome and does not imply the primary stayed put. */
    error?: string | null;
    /** When the switchover was requested */
    started_at: string | null;
    /** When the switchover finished */
    completed_at: string | null;
    /** When the switchover was created */
    created_at: string;
    /** When the switchover was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const PostgresSwitchover: S.Schema<PostgresSwitchover>;
/** The mode of the traffic budget */
export type CreateTrafficBudgetRequestMode = "enforce" | "warn" | "off";
export declare const CreateTrafficBudgetRequestMode: any;
/** Array of traffic rules to apply to the budget */
export type CreateTrafficBudgetRequestRulesList = Array<string>;
export declare const CreateTrafficBudgetRequestRulesList: S.Schema<CreateTrafficBudgetRequestRulesList>;
export interface CreateTrafficBudgetRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Name of the traffic budget */
    name?: string;
    /** The mode of the traffic budget */
    mode?: CreateTrafficBudgetRequestMode | (string & {});
    /** The maximum capacity that can be banked, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    capacity?: number;
    /** The rate at which capacity refills, as a percentage of server resources (0-100). Unlimited when not set. */
    rate?: number;
    /** The maximum capacity a single query can consume, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    burst?: number;
    /** The percentage of available worker processes this policy can use (0-100). Unlimited when not set. */
    concurrency?: number;
    /** A percentage of capacity, burst, or concurrency thresholds to emit warnings for enforced budgets (0-100). */
    warning_threshold?: number;
    /** Array of traffic rules to apply to the budget */
    rules?: CreateTrafficBudgetRequestRulesList;
}
export declare const CreateTrafficBudgetRequest: S.Schema<CreateTrafficBudgetRequest>;
/** The mode of the budget */
export type TrafficBudgetMode = "enforce" | "warn" | "off";
export declare const TrafficBudgetMode: any;
export type TrafficBudgetActor = OrganizationTeamMembershipActor;
export declare const TrafficBudgetActor: S.Schema<OrganizationTeamMembershipActor>;
/** The kind of rule */
export type TrafficBudgetRulesItemKind = "match" | "each";
export declare const TrafficBudgetRulesItemKind: any;
/** The source of this tag */
export type TrafficBudgetRulesItemTagsItemSource = "sql" | "system";
export declare const TrafficBudgetRulesItemTagsItemSource: any;
export interface TrafficBudgetRulesItemTagsItem {
    /** The ID of the key for this tag */
    key_id: string;
    /** The key for this tag */
    key: string;
    /** The value for this tag */
    value: string;
    /** The source of this tag */
    source: TrafficBudgetRulesItemTagsItemSource;
}
export declare const TrafficBudgetRulesItemTagsItem: S.Schema<TrafficBudgetRulesItemTagsItem>;
export type TrafficBudgetRulesItemTagsList = Array<TrafficBudgetRulesItemTagsItem>;
export declare const TrafficBudgetRulesItemTagsList: S.Schema<TrafficBudgetRulesItemTagsList>;
export type TrafficBudgetRulesItemActor = OrganizationTeamMembershipActor;
export declare const TrafficBudgetRulesItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface TrafficBudgetRulesItem {
    /** The ID of the traffic rule */
    id: string;
    /** The kind of rule */
    kind: TrafficBudgetRulesItemKind;
    tags: TrafficBudgetRulesItemTagsList;
    /** The query fingerprint targeted by this rule */
    fingerprint?: string | null;
    /** The keyspace of the fingerprint */
    keyspace?: string | null;
    actor: OrganizationTeamMembershipActor;
    /** Syntax highlighted SQL for rules with SQL keys */
    syntax_highlighted_sql: string;
    /** When the rule was created */
    created_at: string;
    /** When the rule was updated */
    updated_at: string;
}
export declare const TrafficBudgetRulesItem: S.Schema<TrafficBudgetRulesItem>;
export type TrafficBudgetRulesList = Array<TrafficBudgetRulesItem>;
export declare const TrafficBudgetRulesList: S.Schema<TrafficBudgetRulesList>;
export interface TrafficBudget {
    /** The ID of the traffic budget */
    id: string;
    /** The name of the budget */
    name: string;
    /** The mode of the budget */
    mode: TrafficBudgetMode;
    /** The maximum capacity that can be banked, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    capacity?: number | null;
    /** The rate at which capacity refills, as a percentage of server resources (0-100). Unlimited when not set. */
    rate?: number | null;
    /** The maximum capacity a single query can consume, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    burst?: number | null;
    /** The percentage of available worker processes this policy can use (0-100). Unlimited when not set. */
    concurrency?: number | null;
    /** A percentage of capacity, burst, or concurrency thresholds to emit warnings for enforced budgets (0-100). */
    warning_threshold?: number | null;
    actor: OrganizationTeamMembershipActor;
    rules: TrafficBudgetRulesList;
    /** When the budget was created */
    created_at: string;
    /** When the budget was updated */
    updated_at: string;
}
export declare const TrafficBudget: S.Schema<TrafficBudget>;
/** Kind of rule */
export type CreateTrafficRuleRequestKind = "match" | "each";
export declare const CreateTrafficRuleRequestKind: any;
/** Optional array of tags for this rule. Each rules take exactly one tag. */
export type CreateTrafficRuleRequestTagsList = Array<string>;
export declare const CreateTrafficRuleRequestTagsList: S.Schema<CreateTrafficRuleRequestTagsList>;
export interface CreateTrafficRuleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the traffic budget */
    budget_id: string;
    /** Kind of rule */
    kind?: CreateTrafficRuleRequestKind | (string & {});
    /** The keyspace to apply a query pattern rule to */
    keyspace?: string;
    /** Query pattern fingerprint to apply rule to */
    fingerprint?: string;
    /** Optional array of tags for this rule. Each rules take exactly one tag. */
    tags?: CreateTrafficRuleRequestTagsList;
}
export declare const CreateTrafficRuleRequest: S.Schema<CreateTrafficRuleRequest>;
/** The kind of rule */
export type TrafficRuleKind = "match" | "each";
export declare const TrafficRuleKind: any;
/** The source of this tag */
export type TrafficRuleTagsItemSource = "sql" | "system";
export declare const TrafficRuleTagsItemSource: any;
export interface TrafficRuleTagsItem {
    /** The ID of the key for this tag */
    key_id: string;
    /** The key for this tag */
    key: string;
    /** The value for this tag */
    value: string;
    /** The source of this tag */
    source: TrafficRuleTagsItemSource;
}
export declare const TrafficRuleTagsItem: S.Schema<TrafficRuleTagsItem>;
export type TrafficRuleTagsList = Array<TrafficRuleTagsItem>;
export declare const TrafficRuleTagsList: S.Schema<TrafficRuleTagsList>;
export type TrafficRuleActor = OrganizationTeamMembershipActor;
export declare const TrafficRuleActor: S.Schema<OrganizationTeamMembershipActor>;
export interface TrafficRule {
    /** The ID of the traffic rule */
    id: string;
    /** The kind of rule */
    kind: TrafficRuleKind;
    tags: TrafficRuleTagsList;
    /** The query fingerprint targeted by this rule */
    fingerprint?: string | null;
    /** The keyspace of the fingerprint */
    keyspace?: string | null;
    actor: OrganizationTeamMembershipActor;
    /** Syntax highlighted SQL for rules with SQL keys */
    syntax_highlighted_sql: string;
    /** When the rule was created */
    created_at: string;
    /** When the rule was updated */
    updated_at: string;
}
export declare const TrafficRule: S.Schema<TrafficRule>;
/** The events this webhook should subscribe to */
export type CreateWebhookRequestEventsList = Array<string>;
export declare const CreateWebhookRequestEventsList: S.Schema<CreateWebhookRequestEventsList>;
export interface CreateWebhookRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the database */
    database: string;
    /** The URL the webhook will send events to */
    url: string;
    /** Whether the webhook should be enabled */
    enabled?: boolean;
    /** The events this webhook should subscribe to */
    events?: CreateWebhookRequestEventsList;
}
export declare const CreateWebhookRequest: S.Schema<CreateWebhookRequest>;
export type DatabaseWebhookEventsItem = "branch.ready" | "branch.anomaly" | "branch.out_of_memory" | "branch.primary_promoted" | "branch.primary_switchover_imminent" | "branch.schema_recommendation" | "branch.sleeping" | "branch.start_maintenance" | "backup.failed" | "backup.succeeded" | "cluster.storage" | "database.access_request" | "deploy_request.closed" | "deploy_request.errored" | "deploy_request.in_progress" | "deploy_request.opened" | "deploy_request.pending_cutover" | "deploy_request.queued" | "deploy_request.reverted" | "deploy_request.schema_applied" | "keyspace.storage" | "webhook.test";
export declare const DatabaseWebhookEventsItem: any;
/** The events this webhook subscribes to */
export type DatabaseWebhookEventsList = Array<DatabaseWebhookEventsItem>;
export declare const DatabaseWebhookEventsList: S.Schema<DatabaseWebhookEventsList>;
export interface DatabaseWebhook {
    /** The ID of the webhook */
    id: string;
    /** The URL the webhook will send events to */
    url: string;
    /** The secret used to sign the webhook payloads */
    secret: Redacted.Redacted<string>;
    /** Whether the webhook is enabled */
    enabled: boolean;
    /** The last result sent by the webhook */
    last_sent_result: string | null;
    /** Whether the last sent was successful */
    last_sent_success: boolean | null;
    /** When the last event was sent */
    last_sent_at: string | null;
    /** When the webhook was created */
    created_at: string;
    /** When the webhook was updated */
    updated_at: string;
    /** The events this webhook subscribes to */
    events: DatabaseWebhookEventsList;
}
export declare const DatabaseWebhook: S.Schema<DatabaseWebhook>;
/** The behavior when DDL changes during the workflow */
export type CreateWorkflowRequestOnDdl = "IGNORE" | "STOP" | "EXEC" | "EXEC_IGNORE";
export declare const CreateWorkflowRequestOnDdl: any;
/** List of tables to move */
export type CreateWorkflowRequestTablesList = Array<string>;
export declare const CreateWorkflowRequestTablesList: S.Schema<CreateWorkflowRequestTablesList>;
export interface CreateWorkflowRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** Name the workflow */
    name: string;
    /** Name of the source keyspace */
    source_keyspace: string;
    /** Name of the target keyspace */
    target_keyspace: string;
    /** Name of the global sequence keyspace */
    global_keyspace?: string;
    /** Defer secondary keys */
    defer_secondary_keys?: boolean;
    /** The behavior when DDL changes during the workflow */
    on_ddl?: CreateWorkflowRequestOnDdl | (string & {});
    /** List of tables to move */
    tables: CreateWorkflowRequestTablesList;
}
export declare const CreateWorkflowRequest: S.Schema<CreateWorkflowRequest>;
export interface DeleteBackupRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID of the backup */
    id: string;
}
export declare const DeleteBackupRequest: S.Schema<DeleteBackupRequest>;
export interface DeleteBackupResponse {
}
export declare const DeleteBackupResponse: S.Schema<DeleteBackupResponse>;
export interface DeleteBackupPolicyRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The ID of the backup policy */
    id: string;
}
export declare const DeleteBackupPolicyRequest: S.Schema<DeleteBackupPolicyRequest>;
export interface DeleteBackupPolicyResponse {
}
export declare const DeleteBackupPolicyResponse: S.Schema<DeleteBackupPolicyResponse>;
export interface DeleteBouncerRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the bouncer */
    bouncer: string;
}
export declare const DeleteBouncerRequest: S.Schema<DeleteBouncerRequest>;
export interface DeleteBouncerResponse {
}
export declare const DeleteBouncerResponse: S.Schema<DeleteBouncerResponse>;
export interface DeleteBranchRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** If true, recursively delete all descendant branches along with this branch */
    delete_descendants?: boolean;
}
export declare const DeleteBranchRequest: S.Schema<DeleteBranchRequest>;
export interface DeleteBranchResponse {
}
export declare const DeleteBranchResponse: S.Schema<DeleteBranchResponse>;
export interface DeleteDatabaseRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
}
export declare const DeleteDatabaseRequest: S.Schema<DeleteDatabaseRequest>;
export interface DeleteDatabaseResponse {
}
export declare const DeleteDatabaseResponse: S.Schema<DeleteDatabaseResponse>;
export interface DeleteDatabasePostgresCidrRequest {
    /** The name of the organization the database belongs to */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the IP restriction entry */
    id: string;
}
export declare const DeleteDatabasePostgresCidrRequest: S.Schema<DeleteDatabasePostgresCidrRequest>;
export interface DeleteDatabasePostgresCidrResponse {
}
export declare const DeleteDatabasePostgresCidrResponse: S.Schema<DeleteDatabasePostgresCidrResponse>;
export interface DeleteKeyspaceRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
}
export declare const DeleteKeyspaceRequest: S.Schema<DeleteKeyspaceRequest>;
export interface DeleteKeyspaceResponse {
}
export declare const DeleteKeyspaceResponse: S.Schema<DeleteKeyspaceResponse>;
export interface DeleteOauthTokenRequest {
    /** The name of the organization the OAuth application belongs to */
    organization: string;
    /** The ID of the OAuth application */
    application_id: string;
    /** The ID of the OAuth application token */
    token_id: string;
}
export declare const DeleteOauthTokenRequest: S.Schema<DeleteOauthTokenRequest>;
export interface DeleteOauthTokenResponse {
}
export declare const DeleteOauthTokenResponse: S.Schema<DeleteOauthTokenResponse>;
export interface DeleteOrganizationBillingPaymentMethodRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const DeleteOrganizationBillingPaymentMethodRequest: S.Schema<DeleteOrganizationBillingPaymentMethodRequest>;
export interface DeleteOrganizationBillingPaymentMethodResponse {
}
export declare const DeleteOrganizationBillingPaymentMethodResponse: S.Schema<DeleteOrganizationBillingPaymentMethodResponse>;
export interface DeleteOrganizationSsoDomainRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** The public ID of the organization domain */
    id: string;
}
export declare const DeleteOrganizationSsoDomainRequest: S.Schema<DeleteOrganizationSsoDomainRequest>;
export interface DeleteOrganizationSsoDomainResponse {
}
export declare const DeleteOrganizationSsoDomainResponse: S.Schema<DeleteOrganizationSsoDomainResponse>;
export interface DeleteOrganizationTeamRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
}
export declare const DeleteOrganizationTeamRequest: S.Schema<DeleteOrganizationTeamRequest>;
export interface DeleteOrganizationTeamResponse {
}
export declare const DeleteOrganizationTeamResponse: S.Schema<DeleteOrganizationTeamResponse>;
export interface DeletePasswordRequest {
    /** The name of the organization the password belongs to */
    organization: string;
    /** The name of the database the password belongs to */
    database: string;
    /** The name of the branch the password belongs to */
    branch: string;
    /** The ID of the password */
    id: string;
}
export declare const DeletePasswordRequest: S.Schema<DeletePasswordRequest>;
export interface DeletePasswordResponse {
}
export declare const DeletePasswordResponse: S.Schema<DeletePasswordResponse>;
export interface DeleteQueryPatternsReportRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID of the query patterns report */
    id: string;
}
export declare const DeleteQueryPatternsReportRequest: S.Schema<DeleteQueryPatternsReportRequest>;
export interface DeleteQueryPatternsReportResponse {
}
export declare const DeleteQueryPatternsReportResponse: S.Schema<DeleteQueryPatternsReportResponse>;
export interface DeleteReadOnlyReplicaRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the read-only replica */
    read_only_replica: string;
}
export declare const DeleteReadOnlyReplicaRequest: S.Schema<DeleteReadOnlyReplicaRequest>;
export interface DeleteReadOnlyReplicaResponse {
}
export declare const DeleteReadOnlyReplicaResponse: S.Schema<DeleteReadOnlyReplicaResponse>;
export interface DeleteRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the role */
    id: string;
    /** The optional role to reassign ownership to before dropping. Accepts the role's ID, or its username with or without the branch ID suffix. */
    successor?: string;
}
export declare const DeleteRoleRequest: S.Schema<DeleteRoleRequest>;
export interface DeleteRoleResponse {
}
export declare const DeleteRoleResponse: S.Schema<DeleteRoleResponse>;
export interface DeleteServiceTokenRequest {
    /** The name of the organization */
    organization: string;
    /** The ID of the service token */
    id: string;
}
export declare const DeleteServiceTokenRequest: S.Schema<DeleteServiceTokenRequest>;
export interface DeleteServiceTokenResponse {
}
export declare const DeleteServiceTokenResponse: S.Schema<DeleteServiceTokenResponse>;
export interface DeleteTrafficBudgetRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the traffic budget */
    id: string;
}
export declare const DeleteTrafficBudgetRequest: S.Schema<DeleteTrafficBudgetRequest>;
export interface DeleteTrafficBudgetResponse {
}
export declare const DeleteTrafficBudgetResponse: S.Schema<DeleteTrafficBudgetResponse>;
export interface DeleteTrafficRuleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the traffic budget */
    budget_id: string;
    /** The ID of the traffic rule */
    id: string;
}
export declare const DeleteTrafficRuleRequest: S.Schema<DeleteTrafficRuleRequest>;
export interface DeleteTrafficRuleResponse {
}
export declare const DeleteTrafficRuleResponse: S.Schema<DeleteTrafficRuleResponse>;
export interface DeleteWebhookRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the webhook */
    id: string;
}
export declare const DeleteWebhookRequest: S.Schema<DeleteWebhookRequest>;
export interface DeleteWebhookResponse {
}
export declare const DeleteWebhookResponse: S.Schema<DeleteWebhookResponse>;
export interface DemoteBranchRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
}
export declare const DemoteBranchRequest: S.Schema<DemoteBranchRequest>;
export interface DeployCheckRequestStorageRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const DeployCheckRequestStorageRequest: S.Schema<DeployCheckRequestStorageRequest>;
export interface DeployCheckRequestStorageResponseStorageReportValueValue {
    /** Current storage used in bytes */
    used?: number;
    /** Total storage capacity in bytes */
    capacity?: number;
    /** Remaining storage available in bytes */
    remaining?: number;
    /** Percentage of storage capacity currently used */
    percentage_used?: number;
    /** Estimated additional storage needed for this deployment in bytes */
    storage_needed?: number;
    /** Whether this shard has enough remaining storage for the deployment */
    has_enough?: boolean;
    /** Whether this shard lacks storage only because a competing in-flight deployment is still copying */
    blocked_by_in_flight?: boolean;
}
export declare const DeployCheckRequestStorageResponseStorageReportValueValue: S.Schema<DeployCheckRequestStorageResponseStorageReportValueValue>;
/** Per-shard storage details. Keys are shard names. */
export type DeployCheckRequestStorageResponseStorageReportValueMap = {
    [key: string]: DeployCheckRequestStorageResponseStorageReportValueValue | undefined;
};
export declare const DeployCheckRequestStorageResponseStorageReportValueMap: S.Schema<DeployCheckRequestStorageResponseStorageReportValueMap>;
/** Per-keyspace and per-shard storage report. Keys are keyspace names. */
export type DeployCheckRequestStorageResponseStorageReportMap = {
    [key: string]: DeployCheckRequestStorageResponseStorageReportValueMap | undefined;
};
export declare const DeployCheckRequestStorageResponseStorageReportMap: S.Schema<DeployCheckRequestStorageResponseStorageReportMap>;
export interface DeployCheckRequestStorageResponse {
    /** Whether the cluster has enough storage to safely deploy */
    enough_storage: boolean;
    /** Whether the target branch cluster can be upgraded for more storage */
    upgradeable: boolean;
    /** Total estimated bytes of additional storage needed for the deployment */
    storage_bytes_needed: number;
    /** Per-keyspace and per-shard storage report. Keys are keyspace names. */
    storage_report: DeployCheckRequestStorageResponseStorageReportMap;
}
export declare const DeployCheckRequestStorageResponse: S.Schema<DeployCheckRequestStorageResponse>;
/** The deploy request will be updated to this state */
export type DeployCloseRequestRequestState = "closed";
export declare const DeployCloseRequestRequestState: any;
export interface DeployCloseRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** The deploy request will be updated to this state */
    state?: DeployCloseRequestRequestState | (string & {});
}
export declare const DeployCloseRequestRequest: S.Schema<DeployCloseRequestRequest>;
export interface DeployCompleteErroredRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const DeployCompleteErroredRequest: S.Schema<DeployCompleteErroredRequest>;
export interface DeployCompleteGatedRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const DeployCompleteGatedRequestRequest: S.Schema<DeployCompleteGatedRequestRequest>;
export interface DeployForceCutoverRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const DeployForceCutoverRequestRequest: S.Schema<DeployForceCutoverRequestRequest>;
export interface DeployQueueRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** Whether or not to deploy the request with instant DDL. Defaults to false. */
    instant_ddl?: boolean;
}
export declare const DeployQueueRequestRequest: S.Schema<DeployQueueRequestRequest>;
/** Whether the review is a comment or approval. Service tokens must have corresponding access (either `approve_deploy_request` or `review_deploy_request`) */
export type DeployReviewRequestRequestState = "commented" | "approved";
export declare const DeployReviewRequestRequestState: any;
export interface DeployReviewRequestRequest {
    /** The name of the organization the deploy request belongs to */
    organization: string;
    /** The name of the database the deploy request belongs to */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** Whether the review is a comment or approval. Service tokens must have corresponding access (either `approve_deploy_request` or `review_deploy_request`) */
    state?: DeployReviewRequestRequestState | (string & {});
    /** Deploy request review comments */
    body?: string;
}
export declare const DeployReviewRequestRequest: S.Schema<DeployReviewRequestRequest>;
/** Whether the review is a comment or approval */
export type DeployRequestReviewState = "commented" | "approved";
export declare const DeployRequestReviewState: any;
export type DeployRequestReviewActor = OrganizationTeamMembershipActor;
export declare const DeployRequestReviewActor: S.Schema<OrganizationTeamMembershipActor>;
export interface DeployRequestReview {
    /** The ID of the review */
    id: string;
    /** The text body of the review */
    body: string;
    /** The HTML body of the review */
    html_body: string;
    /** Whether the review is a comment or approval */
    state: DeployRequestReviewState;
    /** When the review was created */
    created_at: string;
    /** When the review was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const DeployRequestReview: S.Schema<DeployRequestReview>;
export interface DisableOrganizationSsoRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const DisableOrganizationSsoRequest: S.Schema<DisableOrganizationSsoRequest>;
/** The resource type */
export type OrganizationSsoSerializerType = "OrganizationSSO";
export declare const OrganizationSsoSerializerType: any;
/** The resource type */
export type OrganizationSsoSerializerDomainsItemType = "OrganizationDomain";
export declare const OrganizationSsoSerializerDomainsItemType: any;
/** The verification state of the domain */
export type OrganizationSsoSerializerDomainsItemState = "pending" | "verified" | "failed";
export declare const OrganizationSsoSerializerDomainsItemState: any;
export interface OrganizationSsoSerializerDomainsItem {
    /** The resource type */
    type: OrganizationSsoSerializerDomainsItemType;
    /** The public ID of the organization domain */
    id: string;
    /** The domain name */
    domain: string;
    /** The verification state of the domain */
    state: OrganizationSsoSerializerDomainsItemState;
    /** When the domain was verified */
    verified_at: string | null;
    /** The reason domain verification failed */
    failure_reason: string | null;
    /** When the domain was created */
    created_at: string;
    /** When the domain was last updated */
    updated_at: string;
}
export declare const OrganizationSsoSerializerDomainsItem: S.Schema<OrganizationSsoSerializerDomainsItem>;
export type OrganizationSsoSerializerDomainsList = Array<OrganizationSsoSerializerDomainsItem>;
export declare const OrganizationSsoSerializerDomainsList: S.Schema<OrganizationSsoSerializerDomainsList>;
export interface OrganizationSsoSerializer {
    /** The resource type */
    type: OrganizationSsoSerializerType;
    /** The organization ID */
    id: string;
    /** Whether the SSO add-on is enabled for the organization */
    enabled: boolean;
    /** Whether an identity provider connection is active */
    configured: boolean;
    /** Whether directory sync is enabled */
    directory: boolean;
    /** Whether the organization has at least one verified email domain */
    has_verified_domain: boolean;
    domains: OrganizationSsoSerializerDomainsList;
    /** URL to open for verifying an email domain, returned when SSO is enabled */
    domain_verification_url: string | null;
}
export declare const OrganizationSsoSerializer: S.Schema<OrganizationSsoSerializer>;
export interface DisableOrganizationSsoDirectoryRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const DisableOrganizationSsoDirectoryRequest: S.Schema<DisableOrganizationSsoDirectoryRequest>;
export interface DisableSafeMigrationsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
}
export declare const DisableSafeMigrationsRequest: S.Schema<DisableSafeMigrationsRequest>;
export interface DismissSchemaRecommendationRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Schema recommendation sequence number. Example: `42`. */
    number: number;
    /** The reason for dismissing the recommendation (max 500 characters) */
    reason?: string;
}
export declare const DismissSchemaRecommendationRequest: S.Schema<DismissSchemaRecommendationRequest>;
/** The state of the recommendation */
export type SchemaRecommendationState = "open" | "applied" | "dismissed" | "stale";
export declare const SchemaRecommendationState: any;
/** The type of recommendation */
export type SchemaRecommendationRecommendationType = "unused_table" | "unused_index" | "duplicate_index" | "sequence_overflow" | "sequence_overflow_foreign_key" | "new_index" | "encoding_upgrade" | "bloated_table" | "bloated_index";
export declare const SchemaRecommendationRecommendationType: any;
export interface SchemaRecommendationClosedByDeployRequest {
    /** The ID of the deploy request */
    id: string;
    /** The ID of the branch */
    branch_id: string;
    /** The number of the deploy request */
    number: number;
}
export declare const SchemaRecommendationClosedByDeployRequest: S.Schema<SchemaRecommendationClosedByDeployRequest>;
export type SchemaRecommendationDismissedBy = OrganizationTeamMembershipActor;
export declare const SchemaRecommendationDismissedBy: S.Schema<OrganizationTeamMembershipActor>;
export interface SchemaRecommendation {
    /** The ID of the schema recommendation */
    id: string;
    /** The URL to the schema recommendation in the app */
    html_url: string;
    /** The title of the schema recommendation */
    title: string;
    /** The name of the table the recommendation applies to */
    table_name: string;
    /** The keyspace the recommendation applies to */
    keyspace: string;
    /** The DDL statement to apply the recommendation */
    ddl_statement: string;
    /** The number of the schema recommendation */
    number: number;
    /** The state of the recommendation */
    state: SchemaRecommendationState;
    /** The type of recommendation */
    recommendation_type: SchemaRecommendationRecommendationType;
    /** When the recommendation was created */
    created_at: string;
    /** When the recommendation was last updated */
    updated_at: string;
    /** When the recommendation was applied */
    applied_at: string | null;
    /** When the recommendation was dismissed */
    dismissed_at: string | null;
    closed_by_deploy_request: SchemaRecommendationClosedByDeployRequest | null;
    dismissed_by: OrganizationTeamMembershipActor | null;
}
export declare const SchemaRecommendation: S.Schema<SchemaRecommendation>;
export interface EnableOrganizationSsoRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const EnableOrganizationSsoRequest: S.Schema<EnableOrganizationSsoRequest>;
export interface EnableOrganizationSsoDirectoryRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const EnableOrganizationSsoDirectoryRequest: S.Schema<EnableOrganizationSsoDirectoryRequest>;
export interface EnableOrganizationSsoDirectoryResponse {
    /** URL to open for configuring directory sync */
    portal_url: string;
}
export declare const EnableOrganizationSsoDirectoryResponse: S.Schema<EnableOrganizationSsoDirectoryResponse>;
export interface EnableSafeMigrationsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
}
export declare const EnableSafeMigrationsRequest: S.Schema<EnableSafeMigrationsRequest>;
export interface GetBackupRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID for the backup */
    id: string;
}
export declare const GetBackupRequest: S.Schema<GetBackupRequest>;
export interface GetBackupPolicyRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The ID of the backup policy */
    id: string;
}
export declare const GetBackupPolicyRequest: S.Schema<GetBackupPolicyRequest>;
export interface GetBouncerRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the bouncer */
    bouncer: string;
}
export declare const GetBouncerRequest: S.Schema<GetBouncerRequest>;
export interface GetBranchRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const GetBranchRequest: S.Schema<GetBranchRequest>;
export interface GetBranchAnomalyRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The anomaly ID */
    id: string;
}
export declare const GetBranchAnomalyRequest: S.Schema<GetBranchAnomalyRequest>;
/** The tablet type the query ran against */
export type AnomalyCorrelationsItemTabletType = "primary" | "replica" | "rdonly";
export declare const AnomalyCorrelationsItemTabletType: any;
export interface AnomalyCorrelationsItem {
    /** The ID of the correlation */
    id: string;
    /** The correlation coefficient between the query and the anomaly */
    r: number;
    /** The keyspace the query ran against */
    keyspace: string;
    /** The query fingerprint */
    fingerprint: string;
    /** The normalized SQL statement */
    normalized_sql: string;
    /** Syntax highlighted SQL statement */
    syntax_highlighted_sql: string;
    /** The tablet type the query ran against */
    tablet_type: AnomalyCorrelationsItemTabletType;
}
export declare const AnomalyCorrelationsItem: S.Schema<AnomalyCorrelationsItem>;
export type AnomalyCorrelationsList = Array<AnomalyCorrelationsItem>;
export declare const AnomalyCorrelationsList: S.Schema<AnomalyCorrelationsList>;
export interface Anomaly {
    /** The ID of the anomaly */
    id: string;
    /** When the anomaly started */
    period_start: string;
    /** When the anomaly ended */
    period_end: string;
    /** The number of minutes query latency was in violation of the expected baseline */
    minutes_in_violation: number;
    /** Whether the anomaly is ongoing */
    active: boolean;
    /** The duration of the anomaly in seconds */
    duration: number;
    /** Start of the metrics window surrounding the anomaly */
    metrics_start: string;
    /** End of the metrics window surrounding the anomaly */
    metrics_end: string;
    correlations?: AnomalyCorrelationsList | null;
}
export declare const Anomaly: S.Schema<Anomaly>;
export interface GetBranchChangeRequestRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the change request */
    id: string;
}
export declare const GetBranchChangeRequestRequest: S.Schema<GetBranchChangeRequestRequest>;
/** The state of the branch change request */
export type PostgresClusterResizeRequestState = "queued" | "pending" | "resizing" | "canceled" | "completed";
export declare const PostgresClusterResizeRequestState: any;
export type PostgresClusterResizeRequestActor = OrganizationTeamMembershipActor;
export declare const PostgresClusterResizeRequestActor: S.Schema<OrganizationTeamMembershipActor>;
/** The branch parameters */
export type PostgresClusterResizeRequestParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PostgresClusterResizeRequestParametersMap: S.Schema<PostgresClusterResizeRequestParametersMap>;
/** The previous branch parameters */
export type PostgresClusterResizeRequestPreviousParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PostgresClusterResizeRequestPreviousParametersMap: S.Schema<PostgresClusterResizeRequestPreviousParametersMap>;
/** The storage type (gp3 or io2) */
export type PostgresClusterResizeRequestStorageType = "gp3" | "io2" | "pd_ssd" | "hyperdisk_balanced" | "premium_v2_lrs";
export declare const PostgresClusterResizeRequestStorageType: any;
export interface PostgresClusterResizeRequest {
    /** The ID of the branch change request */
    id: string;
    /** The state of the branch change request */
    state: PostgresClusterResizeRequestState;
    /** The time the branch change request started */
    started_at: string | null;
    /** The time the branch change request completed */
    completed_at?: string | null;
    /** The time the branch change request was created */
    created_at: string;
    /** The time the branch change request was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
    /** The SKU representing the branch cluster */
    cluster_name: string;
    /** The SKU representing the branch cluster for display */
    cluster_display_name: string;
    /** Whether or not this is a metal database */
    cluster_metal: boolean;
    /** The total number of replicas */
    replicas: number;
    /** The PostgreSQL version after the change */
    version?: string;
    /** The branch parameters */
    parameters: PostgresClusterResizeRequestParametersMap;
    /** The previous SKU representing the branch cluster */
    previous_cluster_name: string;
    /** The previous SKU representing the branch cluster for display */
    previous_cluster_display_name: string;
    /** Whether or not the previous SKU was a metal database */
    previous_cluster_metal: boolean;
    /** The previous total number of replicas */
    previous_replicas: number;
    /** The PostgreSQL version before the change */
    previous_version?: string;
    /** The previous branch parameters */
    previous_parameters: PostgresClusterResizeRequestPreviousParametersMap;
    /** The minimum storage size in bytes */
    minimum_storage_bytes: number;
    /** The maximum storage size in bytes */
    maximum_storage_bytes: number;
    /** Whether storage autoscaling is enabled */
    storage_autoscaling: boolean;
    /** Whether storage shrinking is enabled when autoscaling is enabled */
    storage_shrinking: boolean;
    /** The storage type (gp3 or io2) */
    storage_type: PostgresClusterResizeRequestStorageType;
    /** The storage IOPS */
    storage_iops: number;
    /** The storage throughput in MiB/s */
    storage_throughput_mibs: number;
    /** The previous minimum storage size in bytes */
    previous_minimum_storage_bytes: number;
    /** The previous maximum storage size in bytes */
    previous_maximum_storage_bytes: number;
    /** Whether storage autoscaling was previously enabled */
    previous_storage_autoscaling: boolean;
    /** Whether storage shrinking was previously enabled */
    previous_storage_shrinking: boolean;
    /** The previous storage type */
    previous_storage_type: string;
    /** The previous storage IOPS */
    previous_storage_iops: number;
    /** The previous storage throughput in MiB/s */
    previous_storage_throughput_mibs: number;
    /** Whether the change re-applies the current minimum disk size to shrink the provisioned disk */
    confirm_shrink?: boolean;
}
export declare const PostgresClusterResizeRequest: S.Schema<PostgresClusterResizeRequest>;
export interface GetBranchKeyspaceTableMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const GetBranchKeyspaceTableMetricsRequest: S.Schema<GetBranchKeyspaceTableMetricsRequest>;
export interface GetBranchKeyspaceTableMetricsResponse {
}
export declare const GetBranchKeyspaceTableMetricsResponse: S.Schema<GetBranchKeyspaceTableMetricsResponse>;
export type GetBranchMetricsRequestMetricsItem = "avg_parallel_workers" | "avg_shard_queries" | "block_cache_hit_ratio" | "blocks_dirtied" | "blocks_hit" | "blocks_read" | "blocks_written" | "connections" | "cpu_duration_millis" | "egress_bytes" | "egress_bytes_per_query" | "ingress_bytes" | "ingress_bytes_per_query" | "io_duration_millis" | "latency_max" | "latency_p50" | "latency_p95" | "latency_p99" | "latency_p999" | "max_egress_bytes" | "max_ingress_bytes" | "max_shard_queries" | "planetscale_dedicated_pgbouncer_cpu_usage" | "planetscale_dedicated_pgbouncer_current_connections" | "planetscale_dedicated_pgbouncer_memory_usage" | "planetscale_edge_bytes_received" | "planetscale_edge_bytes_received_rate" | "planetscale_edge_bytes_sent" | "planetscale_edge_bytes_sent_rate" | "planetscale_pgbouncer_current_connections" | "planetscale_pgbouncer_pools_client" | "planetscale_pgbouncer_pools_server" | "planetscale_pods_container_ooms" | "planetscale_pods_cpu_util_percentages" | "planetscale_pods_iops_total" | "planetscale_pods_mem_util_percentages" | "planetscale_primary_memory_active_cache_bytes" | "planetscale_primary_memory_inactive_cache_bytes" | "planetscale_primary_memory_mmap_bytes" | "planetscale_primary_memory_rss_bytes" | "planetscale_primary_pgbouncer_cpu_util_percentages" | "planetscale_primary_pgbouncer_mem_util_percentages" | "planetscale_primary_pods_cpu_util_percentages" | "planetscale_primary_pods_iops_total" | "planetscale_primary_pods_mem_util_percentages" | "planetscale_primary_postgres_connection_state" | "planetscale_primary_storage_usage" | "planetscale_primary_xact_commit_rate" | "planetscale_replica_lag_seconds" | "planetscale_replica_memory_active_cache_bytes" | "planetscale_replica_memory_inactive_cache_bytes" | "planetscale_replica_memory_mmap_bytes" | "planetscale_replica_memory_rss_bytes" | "planetscale_replica_pgbouncer_cpu_util_percentages" | "planetscale_replica_pgbouncer_current_connections" | "planetscale_replica_pgbouncer_mem_util_percentages" | "planetscale_replica_pods_cpu_util_percentages" | "planetscale_replica_pods_iops_total" | "planetscale_replica_pods_mem_util_percentages" | "planetscale_replica_postgres_connection_state" | "planetscale_replica_storage_usage_bytes" | "planetscale_replica_volume_usage_percentages" | "planetscale_replication_slot_max_wal_retained_bytes" | "planetscale_replication_slots_lost" | "planetscale_settings_max_slot_wal_keep_size_bytes" | "planetscale_storage_usage_bytes" | "planetscale_volume_usage_percentages" | "planetscale_wal_archiver_failed_rate" | "planetscale_wal_archiver_last_age_succeeded" | "planetscale_wal_archiver_succeeded_rate" | "planetscale_wal_size_bytes" | "queries" | "query_errors" | "rows_affected_per_query" | "rows_read" | "rows_read_per_query" | "rows_read_per_returned" | "rows_returned" | "rows_returned_per_query" | "rows_written" | "storage_per_table" | "total_duration_millis" | "traffic_control_throttled" | "traffic_control_warnings" | "violations" | "vtgate_cpu_avg_by_az" | "vtgate_cpu_by_az" | "vtgate_latency_p50" | "vtgate_latency_p95" | "vtgate_memory_avg_by_az" | "vtgate_memory_by_az" | "vtgate_requests";
export declare const GetBranchMetricsRequestMetricsItem: any;
export type GetBranchMetricsRequestMetricsList = Array<GetBranchMetricsRequestMetricsItem | (string & {})>;
export declare const GetBranchMetricsRequestMetricsList: S.Schema<GetBranchMetricsRequestMetricsList>;
export type GetBranchMetricsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetBranchMetricsRequestPeriod: any;
export type GetBranchMetricsRequestTabletType = "primary" | "replica" | "rdonly";
export declare const GetBranchMetricsRequestTabletType: any;
export type GetBranchMetricsRequestPodsList = Array<string>;
export declare const GetBranchMetricsRequestPodsList: S.Schema<GetBranchMetricsRequestPodsList>;
export type GetBranchMetricsRequestQueryIdsList = Array<string>;
export declare const GetBranchMetricsRequestQueryIdsList: S.Schema<GetBranchMetricsRequestQueryIdsList>;
export interface GetBranchMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Metric names to retrieve. Pass as `metrics[]=name` (repeat for multiple), `metrics=name`, or a comma-separated list (`metrics=name,other`). Time range is `period` (for example `15m`) or ISO 8601 `from`/`to`. */
    metrics?: GetBranchMetricsRequestMetricsList;
    /** Named time period to retrieve. Defaults to 12h. */
    period?: GetBranchMetricsRequestPeriod | (string & {});
    /** Start of a custom time range as an ISO 8601 timestamp */
    from?: string;
    /** End of a custom time range as an ISO 8601 timestamp */
    to?: string;
    /** Number of data points to return */
    steps?: number;
    /** Filter by tablet type */
    tablet_type?: GetBranchMetricsRequestTabletType | (string & {});
    /** Filter by keyspace */
    keyspace?: string;
    /** Filter by shard */
    shard?: string;
    /** Filter by Postgres role */
    role?: string;
    /** Filter by container */
    container?: string;
    /** Filter by pod */
    pod?: string;
    /** Filter by pods */
    pods?: GetBranchMetricsRequestPodsList;
    /** Filter by query pattern IDs */
    query_ids?: GetBranchMetricsRequestQueryIdsList;
    /** Filter by query fingerprint */
    fingerprint?: string;
    /** Filter by traffic budget ID */
    budget_id?: string;
    /** Filter by traffic rule ID */
    rule_id?: string;
    /** Filter by search terms */
    q?: string;
}
export declare const GetBranchMetricsRequest: S.Schema<GetBranchMetricsRequest>;
export type GetBranchMetricsResponseSeriesList = Array<string>;
export declare const GetBranchMetricsResponseSeriesList: S.Schema<GetBranchMetricsResponseSeriesList>;
export interface GetBranchMetricsResponse {
    /** The metrics response type */
    type: string;
    /** The start of the time range */
    start_date: string;
    /** The end of the time range */
    end_date: string;
    /** The step interval in seconds between data points */
    interval: number;
    series: GetBranchMetricsResponseSeriesList;
}
export declare const GetBranchMetricsResponse: S.Schema<GetBranchMetricsResponse>;
export interface GetBranchQueryRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The query ID */
    id: string;
}
export declare const GetBranchQueryRequest: S.Schema<GetBranchQueryRequest>;
/** The database password used for the query */
export type QueryPasswordMap = {
    [key: string]: unknown | undefined;
};
export declare const QueryPasswordMap: S.Schema<QueryPasswordMap>;
export type QueryTagsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const QueryTagsItemMap: S.Schema<QueryTagsItemMap>;
/** Tags associated with the query */
export type QueryTagsList = Array<QueryTagsItemMap>;
export declare const QueryTagsList: S.Schema<QueryTagsList>;
/** Tables accessed by the query */
export type QueryTablesList = Array<string>;
export declare const QueryTablesList: S.Schema<QueryTablesList>;
export interface Query {
    /** The ID of the query */
    id: string;
    /** The database password used for the query */
    password: QueryPasswordMap;
    /** Tags associated with the query */
    tags: QueryTagsList;
    /** The query fingerprint */
    fingerprint: string;
    /** When the query started */
    started_at: string | null;
    /** The type of SQL statement */
    statement_type: string;
    /** The keyspace the query ran against */
    keyspace: string;
    /** Tables accessed by the query */
    tables: QueryTablesList;
    /** The username that executed the query */
    username: string;
    /** The remote IP address of the client */
    remote_address: string;
    /** The number of shard queries executed */
    shard_queries: number;
    /** The number of rows read */
    rows_read: number;
    /** The number of rows affected */
    rows_affected: number;
    /** The number of rows returned */
    rows_returned: number;
    /** Total query duration in milliseconds */
    total_duration_millis: number;
    /** Error message if the query failed */
    error_message: string;
    /** The normalized SQL statement */
    normalized_sql: string;
    /** Syntax highlighted SQL statement */
    syntax_highlighted_sql: string;
    /** When the query record was created */
    created_at: string;
    /** When the query record was last updated */
    updated_at: string;
    /** Whether the query can be explained */
    explainable: boolean;
    /** Whether the query was truncated */
    truncated: boolean;
}
export declare const Query: S.Schema<Query>;
export type GetBranchQueryErrorRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetBranchQueryErrorRequestPeriod: any;
export interface GetBranchQueryErrorRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The error fingerprint */
    fingerprint: string;
    /** Start time for filtering queries (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering queries (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering queries */
    period?: GetBranchQueryErrorRequestPeriod | (string & {});
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const GetBranchQueryErrorRequest: S.Schema<GetBranchQueryErrorRequest>;
/** The database password used for the query */
export type PaginatedQueryDataItemPasswordMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedQueryDataItemPasswordMap: S.Schema<PaginatedQueryDataItemPasswordMap>;
export type PaginatedQueryDataItemTagsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedQueryDataItemTagsItemMap: S.Schema<PaginatedQueryDataItemTagsItemMap>;
/** Tags associated with the query */
export type PaginatedQueryDataItemTagsList = Array<PaginatedQueryDataItemTagsItemMap>;
export declare const PaginatedQueryDataItemTagsList: S.Schema<PaginatedQueryDataItemTagsList>;
/** Tables accessed by the query */
export type PaginatedQueryDataItemTablesList = Array<string>;
export declare const PaginatedQueryDataItemTablesList: S.Schema<PaginatedQueryDataItemTablesList>;
export interface PaginatedQueryDataItem {
    /** The ID of the query */
    id: string;
    /** The database password used for the query */
    password: PaginatedQueryDataItemPasswordMap;
    /** Tags associated with the query */
    tags: PaginatedQueryDataItemTagsList;
    /** The query fingerprint */
    fingerprint: string;
    /** When the query started */
    started_at: string | null;
    /** The type of SQL statement */
    statement_type: string;
    /** The keyspace the query ran against */
    keyspace: string;
    /** Tables accessed by the query */
    tables: PaginatedQueryDataItemTablesList;
    /** The username that executed the query */
    username: string;
    /** The remote IP address of the client */
    remote_address: string;
    /** The number of shard queries executed */
    shard_queries: number;
    /** The number of rows read */
    rows_read: number;
    /** The number of rows affected */
    rows_affected: number;
    /** The number of rows returned */
    rows_returned: number;
    /** Total query duration in milliseconds */
    total_duration_millis: number;
    /** Error message if the query failed */
    error_message: string;
    /** The normalized SQL statement */
    normalized_sql: string;
    /** Syntax highlighted SQL statement */
    syntax_highlighted_sql: string;
    /** When the query record was created */
    created_at: string;
    /** When the query record was last updated */
    updated_at: string;
    /** Whether the query can be explained */
    explainable: boolean;
    /** Whether the query was truncated */
    truncated: boolean;
}
export declare const PaginatedQueryDataItem: S.Schema<PaginatedQueryDataItem>;
export type PaginatedQueryDataList = Array<PaginatedQueryDataItem>;
export declare const PaginatedQueryDataList: S.Schema<PaginatedQueryDataList>;
export interface PaginatedQuery {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedQueryDataList;
}
export declare const PaginatedQuery: S.Schema<PaginatedQuery>;
export type GetBranchQueryMetricsRequestMetricsItem = "avg_parallel_workers" | "avg_shard_queries" | "block_cache_hit_ratio" | "blocks_dirtied" | "blocks_hit" | "blocks_read" | "blocks_written" | "cpu_duration_millis" | "egress_bytes" | "egress_bytes_per_query" | "index_usage_percent" | "ingress_bytes" | "ingress_bytes_per_query" | "io_duration_millis" | "latency_max" | "latency_min" | "latency_p50" | "latency_p95" | "latency_p99" | "latency_p999" | "max_egress_bytes" | "max_ingress_bytes" | "max_shard_queries" | "plan_change_score" | "queries" | "query_errors" | "routing_index_usage_percent" | "rows_affected_per_query" | "rows_read" | "rows_read_per_query" | "rows_read_per_returned" | "rows_returned" | "rows_returned_per_query" | "rows_written" | "total_duration_millis" | "traffic_control_throttled" | "traffic_control_warnings";
export declare const GetBranchQueryMetricsRequestMetricsItem: any;
export type GetBranchQueryMetricsRequestMetricsList = Array<GetBranchQueryMetricsRequestMetricsItem | (string & {})>;
export declare const GetBranchQueryMetricsRequestMetricsList: S.Schema<GetBranchQueryMetricsRequestMetricsList>;
export type GetBranchQueryMetricsRequestQueryIdsList = Array<string>;
export declare const GetBranchQueryMetricsRequestQueryIdsList: S.Schema<GetBranchQueryMetricsRequestQueryIdsList>;
export type GetBranchQueryMetricsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetBranchQueryMetricsRequestPeriod: any;
export type GetBranchQueryMetricsRequestTabletType = "primary" | "replica" | "rdonly";
export declare const GetBranchQueryMetricsRequestTabletType: any;
export interface GetBranchQueryMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Metric names to retrieve. Pass as `metrics[]=name` (repeat for multiple), `metrics=name`, or a comma-separated list (`metrics=name,other`). Time range is `period` (for example `15m`) or ISO 8601 `from`/`to`. */
    metrics?: GetBranchQueryMetricsRequestMetricsList;
    /** Query pattern IDs to retrieve metrics for */
    query_ids?: GetBranchQueryMetricsRequestQueryIdsList;
    /** Filter by query fingerprint */
    fingerprint?: string;
    /** Keyspace for the query fingerprint */
    keyspace?: string;
    /** Named time period to retrieve. Defaults to 12h. */
    period?: GetBranchQueryMetricsRequestPeriod | (string & {});
    /** Start of a custom time range as an ISO 8601 timestamp */
    from?: string;
    /** End of a custom time range as an ISO 8601 timestamp */
    to?: string;
    /** Number of data points to return */
    steps?: number;
    /** Filter by tablet type */
    tablet_type?: GetBranchQueryMetricsRequestTabletType | (string & {});
    /** Filter by traffic budget ID */
    budget_id?: string;
    /** Filter by traffic rule ID */
    rule_id?: string;
    /** Filter by search terms */
    q?: string;
}
export declare const GetBranchQueryMetricsRequest: S.Schema<GetBranchQueryMetricsRequest>;
export type GetBranchQueryMetricsResponseSeriesList = Array<string>;
export declare const GetBranchQueryMetricsResponseSeriesList: S.Schema<GetBranchQueryMetricsResponseSeriesList>;
export interface GetBranchQueryMetricsResponse {
    /** The metrics response type */
    type: string;
    /** The start of the time range */
    start_date: string;
    /** The end of the time range */
    end_date: string;
    /** The step interval in seconds between data points */
    interval: number;
    series: GetBranchQueryMetricsResponseSeriesList;
}
export declare const GetBranchQueryMetricsResponse: S.Schema<GetBranchQueryMetricsResponse>;
export type GetBranchQueryTagRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetBranchQueryTagRequestPeriod: any;
export type GetBranchQueryTagRequestTabletType = "primary" | "replica" | "rdonly";
export declare const GetBranchQueryTagRequestTabletType: any;
export interface GetBranchQueryTagRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The tag name */
    tag: string;
    /** Start time for filtering tag values (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering tag values (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering tag values */
    period?: GetBranchQueryTagRequestPeriod | (string & {});
    /** Filter to tag values on queries with this fingerprint */
    fingerprint?: string;
    /** Filter by keyspace */
    keyspace?: string;
    /** Filter by tablet type */
    tablet_type?: GetBranchQueryTagRequestTabletType | (string & {});
    /** Maximum number of values returned (1-100) */
    values_limit?: number;
    /** Only return literal tag values, excluding overflow and collapsed values */
    literal_values_only?: boolean;
}
export declare const GetBranchQueryTagRequest: S.Schema<GetBranchQueryTagRequest>;
/** The source of the tag */
export type QueryTagSource = "sql" | "system";
export declare const QueryTagSource: any;
/** The kind of tag value */
export type QueryTagValuesItemKind = "literal" | "overflow" | "collapsed";
export declare const QueryTagValuesItemKind: any;
export interface QueryTagValuesItem {
    /** The name of the tag value */
    name: string;
    /** The number of queries that have this tag value */
    query_count: number;
    /** The kind of tag value */
    kind: QueryTagValuesItemKind;
}
export declare const QueryTagValuesItem: S.Schema<QueryTagValuesItem>;
export type QueryTagValuesList = Array<QueryTagValuesItem>;
export declare const QueryTagValuesList: S.Schema<QueryTagValuesList>;
export interface QueryTag {
    /** The ID of the tag */
    id: string;
    /** The name of the tag */
    name: string;
    /** The source of the tag */
    source: QueryTagSource;
    /** The number of queries that have this tag */
    query_count: number;
    values: QueryTagValuesList;
}
export declare const QueryTag: S.Schema<QueryTag>;
export interface GetBranchResizeRequestRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID of the branch resize request */
    resize: string;
}
export declare const GetBranchResizeRequestRequest: S.Schema<GetBranchResizeRequestRequest>;
/** The state of the branch resize request */
export type MysqlClusterResizeRequestState = "pending" | "resizing" | "canceled" | "completed" | "queued";
export declare const MysqlClusterResizeRequestState: any;
export type MysqlClusterResizeRequestActor = OrganizationTeamMembershipActor;
export declare const MysqlClusterResizeRequestActor: S.Schema<OrganizationTeamMembershipActor>;
export interface MysqlClusterResizeRequest {
    /** The ID of the branch resize request */
    id: string;
    /** The state of the branch resize request */
    state: MysqlClusterResizeRequestState;
    /** When the branch resize request started */
    started_at: string | null;
    /** When the branch resize request completed */
    completed_at: string | null;
    /** When the branch resize request was created */
    created_at: string;
    /** When the branch resize request was last updated */
    updated_at: string;
    /** The size of the vtgate cluster */
    vtgate_size: string;
    /** The previous size of the vtgate cluster */
    previous_vtgate_size: string;
    /** The number of vtgates in an availability zone */
    vtgate_count: number;
    /** The previous number of vtgates in the availability zone */
    previous_vtgate_count: number;
    /** The maximum number of vtgates in an availability zone when autoscaling is enabled */
    vtgate_max_count: number;
    /** The previous maximum number of vtgates in the availability zone when autoscaling is enabled */
    previous_vtgate_max_count: number;
    /** If autoscaling is enabled for the vtgate cluster */
    vtgate_autoscaling: boolean;
    /** The previous autoscaling setting for the vtgate cluster */
    previous_vtgate_autoscaling: boolean;
    /** The target CPU utilization for the vtgate cluster */
    vtgate_target_cpu_utilization: number;
    /** The previous target CPU utilization for the vtgate cluster */
    previous_vtgate_target_cpu_utilization: number;
    /** The SKU representing the vtgate cluster size: VTG_5, VTG_10,… */
    vtgate_name: string;
    /** The SKU representing the vtgate cluster size for display */
    vtgate_display_name: string;
    /** The previous SKU representing the vtgate cluster size */
    previous_vtgate_name: string;
    /** The previous SKU representing the vtgate cluster size for display */
    previous_vtgate_display_name: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const MysqlClusterResizeRequest: S.Schema<MysqlClusterResizeRequest>;
export interface GetBranchSchemaRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** Return the schema for a single Vitess keyspace */
    keyspace?: string;
    /** Return the schema for a PostgreSQL catalog namespace in `<database>.<schema>` format (e.g. public.schema1) */
    namespace?: string;
}
export declare const GetBranchSchemaRequest: S.Schema<GetBranchSchemaRequest>;
export interface GetBranchSchemaResponseDataItem {
    /** Name of the table */
    name: string;
    /** Syntax highlighted HTML for the table's schema */
    html: string;
    /** The table's schema */
    raw: string;
}
export declare const GetBranchSchemaResponseDataItem: S.Schema<GetBranchSchemaResponseDataItem>;
export type GetBranchSchemaResponseDataList = Array<GetBranchSchemaResponseDataItem>;
export declare const GetBranchSchemaResponseDataList: S.Schema<GetBranchSchemaResponseDataList>;
export interface GetBranchSchemaResponse {
    data: GetBranchSchemaResponseDataList;
}
export declare const GetBranchSchemaResponse: S.Schema<GetBranchSchemaResponse>;
export interface GetBranchTableMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const GetBranchTableMetricsRequest: S.Schema<GetBranchTableMetricsRequest>;
export interface GetBranchTableMetricsResponse {
}
export declare const GetBranchTableMetricsResponse: S.Schema<GetBranchTableMetricsResponse>;
export type GetBranchTagMetricsRequestMetricsItem = "avg_parallel_workers" | "avg_shard_queries" | "block_cache_hit_ratio" | "blocks_dirtied" | "blocks_hit" | "blocks_read" | "blocks_written" | "cpu_duration_millis" | "egress_bytes" | "egress_bytes_per_query" | "ingress_bytes" | "ingress_bytes_per_query" | "io_duration_millis" | "latency_max" | "latency_min" | "latency_p50" | "latency_p95" | "latency_p99" | "latency_p999" | "max_egress_bytes" | "max_ingress_bytes" | "max_shard_queries" | "queries" | "query_errors" | "rows_affected_per_query" | "rows_read" | "rows_read_per_query" | "rows_read_per_returned" | "rows_returned" | "rows_returned_per_query" | "rows_written" | "total_duration_millis" | "traffic_control_throttled" | "traffic_control_warnings";
export declare const GetBranchTagMetricsRequestMetricsItem: any;
export type GetBranchTagMetricsRequestMetricsList = Array<GetBranchTagMetricsRequestMetricsItem | (string & {})>;
export declare const GetBranchTagMetricsRequestMetricsList: S.Schema<GetBranchTagMetricsRequestMetricsList>;
export type GetBranchTagMetricsRequestTagSetsList = Array<string>;
export declare const GetBranchTagMetricsRequestTagSetsList: S.Schema<GetBranchTagMetricsRequestTagSetsList>;
export type GetBranchTagMetricsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetBranchTagMetricsRequestPeriod: any;
export type GetBranchTagMetricsRequestTabletType = "primary" | "replica" | "rdonly";
export declare const GetBranchTagMetricsRequestTabletType: any;
export interface GetBranchTagMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Metric names to retrieve. Pass as `metrics[]=name` (repeat for multiple), `metrics=name`, or a comma-separated list (`metrics=name,other`). Time range is `period` (for example `15m`) or ISO 8601 `from`/`to`. */
    metrics?: GetBranchTagMetricsRequestMetricsList;
    /** Tag sets to retrieve metrics for */
    tag_sets?: GetBranchTagMetricsRequestTagSetsList;
    /** Named time period to retrieve. Defaults to 12h. */
    period?: GetBranchTagMetricsRequestPeriod | (string & {});
    /** Start of a custom time range as an ISO 8601 timestamp */
    from?: string;
    /** End of a custom time range as an ISO 8601 timestamp */
    to?: string;
    /** Number of data points to return */
    steps?: number;
    /** Filter by tablet type */
    tablet_type?: GetBranchTagMetricsRequestTabletType | (string & {});
    /** Filter by traffic budget ID */
    budget_id?: string;
    /** Filter by traffic rule ID */
    rule_id?: string;
    /** Filter by search terms */
    q?: string;
}
export declare const GetBranchTagMetricsRequest: S.Schema<GetBranchTagMetricsRequest>;
export type GetBranchTagMetricsResponseSeriesList = Array<string>;
export declare const GetBranchTagMetricsResponseSeriesList: S.Schema<GetBranchTagMetricsResponseSeriesList>;
export interface GetBranchTagMetricsResponse {
    /** The metrics response type */
    type: string;
    /** The start of the time range */
    start_date: string;
    /** The end of the time range */
    end_date: string;
    /** The step interval in seconds between data points */
    interval: number;
    series: GetBranchTagMetricsResponseSeriesList;
}
export declare const GetBranchTagMetricsResponse: S.Schema<GetBranchTagMetricsResponse>;
export interface GetCurrentUserRequest {
}
export declare const GetCurrentUserRequest: S.Schema<GetCurrentUserRequest>;
export type UserDefaultOrganization = OrganizationTeamMembershipUserDefaultOrganization;
export declare const UserDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface User {
    /** The ID of the user */
    id: string;
    /** The display name of the user */
    display_name: string;
    /** The name of the user */
    name?: string | null;
    /** The email of the user */
    email: string;
    /** The URL source of the user's avatar */
    avatar_url: string;
    /** When the user was created */
    created_at: string;
    /** When the user was last updated */
    updated_at: string;
    /** Whether or not the user has configured two factor authentication */
    two_factor_auth_configured: boolean;
    default_organization?: OrganizationTeamMembershipUserDefaultOrganization | null;
    /** Whether or not the user is managed by SSO. */
    sso?: boolean | null;
    /** Whether or not the user is managed by an authentication provider. */
    managed?: boolean | null;
    /** Whether or not the user is managed by a SSO directory. */
    directory_managed?: boolean | null;
    /** Whether or not the user is verified by email. */
    email_verified?: boolean | null;
}
export declare const User: S.Schema<User>;
export interface GetDatabaseRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
}
export declare const GetDatabaseRequest: S.Schema<GetDatabaseRequest>;
export interface GetDatabasePostgresCidrRequest {
    /** The name of the organization the database belongs to */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the IP restriction entry */
    id: string;
}
export declare const GetDatabasePostgresCidrRequest: S.Schema<GetDatabasePostgresCidrRequest>;
export interface GetDatabaseThrottlerRequest {
    /** The name of the organization that the throttled deploy requests belong to */
    organization: string;
    /** The name of the database that the throttled deploy requests belong to */
    database: string;
}
export declare const GetDatabaseThrottlerRequest: S.Schema<GetDatabaseThrottlerRequest>;
/** Keyspaces that are eligible for throttler configuration in the configurable resource (database or deploy request) */
export type ThrottlerConfigurationsKeyspacesList = Array<string>;
export declare const ThrottlerConfigurationsKeyspacesList: S.Schema<ThrottlerConfigurationsKeyspacesList>;
export type ThrottlerConfigurationsConfigurable = OrganizationTeamMembershipUserDefaultOrganization;
export declare const ThrottlerConfigurationsConfigurable: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface ThrottlerConfigurationsConfigurationsItem {
    /** Name of keyspace this throttler ratio applies to */
    keyspace_name: string;
    /** A throttler ratio between 0 and 95 that applies to migrations in this specific keyspace */
    ratio: number;
}
export declare const ThrottlerConfigurationsConfigurationsItem: S.Schema<ThrottlerConfigurationsConfigurationsItem>;
export type ThrottlerConfigurationsConfigurationsList = Array<ThrottlerConfigurationsConfigurationsItem>;
export declare const ThrottlerConfigurationsConfigurationsList: S.Schema<ThrottlerConfigurationsConfigurationsList>;
export interface ThrottlerConfigurations {
    /** Keyspaces that are eligible for throttler configuration in the configurable resource (database or deploy request) */
    keyspaces: ThrottlerConfigurationsKeyspacesList;
    configurable: OrganizationTeamMembershipUserDefaultOrganization;
    configurations: ThrottlerConfigurationsConfigurationsList;
}
export declare const ThrottlerConfigurations: S.Schema<ThrottlerConfigurations>;
export interface GetDefaultRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const GetDefaultRoleRequest: S.Schema<GetDefaultRoleRequest>;
export interface GetDeploymentRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const GetDeploymentRequest: S.Schema<GetDeploymentRequest>;
/** The state the deployment is in */
export type DeploymentState = "pending" | "ready" | "no_changes" | "queued" | "submitting" | "in_progress" | "pending_cutover" | "in_progress_vschema" | "in_progress_cancel" | "in_progress_cutover" | "complete" | "complete_cancel" | "complete_error" | "complete_pending_revert" | "in_progress_revert" | "in_progress_revert_vschema" | "complete_revert" | "complete_revert_error" | "cancelled" | "error";
export declare const DeploymentState: any;
export type DeploymentPrecedingDeploymentsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DeploymentPrecedingDeploymentsItemMap: S.Schema<DeploymentPrecedingDeploymentsItemMap>;
/** The deployments ahead of this one in the queue */
export type DeploymentPrecedingDeploymentsList = Array<DeploymentPrecedingDeploymentsItemMap>;
export declare const DeploymentPrecedingDeploymentsList: S.Schema<DeploymentPrecedingDeploymentsList>;
/** The state of the deploy operation */
export type DeploymentDeployOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const DeploymentDeployOperationsItemState: any;
/** Names of foreign keys removed by this operation */
export type DeploymentDeployOperationsItemRemovedForeignKeyNamesList = Array<string>;
export declare const DeploymentDeployOperationsItemRemovedForeignKeyNamesList: S.Schema<DeploymentDeployOperationsItemRemovedForeignKeyNamesList>;
export interface DeploymentDeployOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The state of the deploy operation */
    state: DeploymentDeployOperationsItemState;
    /** The keyspace modified by the deploy operation */
    keyspace_name: string;
    /** The name of the table modifed by the deploy operation */
    table_name: string;
    /** The operation name of the deploy operation */
    operation_name: string;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number | null;
    /** The percent completion for the deploy operation */
    progress_percentage: number | null;
    /** A link to documentation explaining the deploy error, if present */
    deploy_error_docs_url: string | null;
    /** The DDL statement for the deploy operation */
    ddl_statement: string;
    /** A syntax-highlighted DDL statement for the deploy operation */
    syntax_highlighted_ddl: string;
    /** When the deploy operation was created */
    created_at: string;
    /** When the deploy operation was last updated */
    updated_at: string;
    /** When the deploy operation was last throttled */
    throttled_at: string | null;
    /** Whether or not the deploy operation is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation is currently locked */
    table_locked: boolean;
    /** Whether or not the table modified by the deploy operation was recently used */
    table_recently_used: boolean;
    /** When the table modified by the deploy operation was last used */
    table_recently_used_at: string | null;
    /** Names of foreign keys removed by this operation */
    removed_foreign_key_names: DeploymentDeployOperationsItemRemovedForeignKeyNamesList | null;
    /** Deploy errors for the deploy operation */
    deploy_errors: string | null;
}
export declare const DeploymentDeployOperationsItem: S.Schema<DeploymentDeployOperationsItem>;
export type DeploymentDeployOperationsList = Array<DeploymentDeployOperationsItem>;
export declare const DeploymentDeployOperationsList: S.Schema<DeploymentDeployOperationsList>;
/** The state of the deploy operation summary */
export type DeploymentDeployOperationSummariesItemState = "pending" | "in_progress" | "complete" | "cancelled" | "error";
export declare const DeploymentDeployOperationSummariesItemState: any;
/** Names of foreign keys removed by this operation summary */
export type DeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList = Array<string>;
export declare const DeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList: S.Schema<DeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList>;
/** Names of shards in the keyspace modified by the deploy operation summary */
export type DeploymentDeployOperationSummariesItemShardNamesList = Array<string>;
export declare const DeploymentDeployOperationSummariesItemShardNamesList: S.Schema<DeploymentDeployOperationSummariesItemShardNamesList>;
/** The state of the deploy operation */
export type DeploymentDeployOperationSummariesItemOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const DeploymentDeployOperationSummariesItemOperationsItemState: any;
export interface DeploymentDeployOperationSummariesItemOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The shard the deploy operation is being performed on */
    shard: string;
    /** The state of the deploy operation */
    state: DeploymentDeployOperationSummariesItemOperationsItemState;
    /** The percent completion for the deploy operation */
    progress_percentage: number;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number;
}
export declare const DeploymentDeployOperationSummariesItemOperationsItem: S.Schema<DeploymentDeployOperationSummariesItemOperationsItem>;
export type DeploymentDeployOperationSummariesItemOperationsList = Array<DeploymentDeployOperationSummariesItemOperationsItem>;
export declare const DeploymentDeployOperationSummariesItemOperationsList: S.Schema<DeploymentDeployOperationSummariesItemOperationsList>;
export interface DeploymentDeployOperationSummariesItem {
    /** The ID for the deploy operation summary */
    id: string;
    /** When the deploy operation summary was created */
    created_at: string;
    /** Deploy errors for the deploy operation summary */
    deploy_errors: string;
    /** The DDL statement for the deploy operation summary */
    ddl_statement: string;
    /** The estimated seconds until completion for the deploy operation summary */
    eta_seconds: number;
    /** The keyspace modified by the deploy operation summary */
    keyspace_name: string;
    /** The operation name of the deploy operation summary */
    operation_name: string;
    /** The percent completion for the deploy operation summary */
    progress_percentage: number;
    /** The state of the deploy operation summary */
    state: DeploymentDeployOperationSummariesItemState;
    /** A syntax-highlighted DDL statement for the deploy operation summary */
    syntax_highlighted_ddl: string;
    /** The name of the table modifed by the deploy operation summary */
    table_name: string;
    /** When the table modified by the deploy operation summary was last used */
    table_recently_used_at: string | null;
    /** When the deploy operation summary was last throttled */
    throttled_at: string | null;
    /** Names of foreign keys removed by this operation summary */
    removed_foreign_key_names: DeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList;
    /** The number of shards in the keyspace modified by the deploy operation summary */
    shard_count: number;
    /** Names of shards in the keyspace modified by the deploy operation summary */
    shard_names: DeploymentDeployOperationSummariesItemShardNamesList;
    /** Whether or not the deploy operation summary is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation summary was recently used */
    table_recently_used: boolean;
    /** Whether or not the keyspace modified by the deploy operation summary is sharded */
    sharded: boolean;
    operations: DeploymentDeployOperationSummariesItemOperationsList;
}
export declare const DeploymentDeployOperationSummariesItem: S.Schema<DeploymentDeployOperationSummariesItem>;
export type DeploymentDeployOperationSummariesList = Array<DeploymentDeployOperationSummariesItem>;
export declare const DeploymentDeployOperationSummariesList: S.Schema<DeploymentDeployOperationSummariesList>;
export type DeploymentLintErrorsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DeploymentLintErrorsItemMap: S.Schema<DeploymentLintErrorsItemMap>;
/** Schema lint errors preventing the deployment from completing */
export type DeploymentLintErrorsList = Array<DeploymentLintErrorsItemMap>;
export declare const DeploymentLintErrorsList: S.Schema<DeploymentLintErrorsList>;
export type DeploymentSequentialDiffDependenciesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DeploymentSequentialDiffDependenciesItemMap: S.Schema<DeploymentSequentialDiffDependenciesItemMap>;
/** The schema dependencies that must be satisfied */
export type DeploymentSequentialDiffDependenciesList = Array<DeploymentSequentialDiffDependenciesItemMap>;
export declare const DeploymentSequentialDiffDependenciesList: S.Schema<DeploymentSequentialDiffDependenciesList>;
export type DeploymentLookupVindexOperationsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const DeploymentLookupVindexOperationsItemMap: S.Schema<DeploymentLookupVindexOperationsItemMap>;
/** Lookup Vitess index operations */
export type DeploymentLookupVindexOperationsList = Array<DeploymentLookupVindexOperationsItemMap>;
export declare const DeploymentLookupVindexOperationsList: S.Schema<DeploymentLookupVindexOperationsList>;
/** Deployment throttling configurations. */
export type DeploymentThrottlerConfigurationsMap = {
    [key: string]: unknown | undefined;
};
export declare const DeploymentThrottlerConfigurationsMap: S.Schema<DeploymentThrottlerConfigurationsMap>;
/** The request to revert the schema operations in this deployment */
export type DeploymentDeploymentRevertRequestMap = {
    [key: string]: unknown | undefined;
};
export declare const DeploymentDeploymentRevertRequestMap: S.Schema<DeploymentDeploymentRevertRequestMap>;
export type DeploymentActor = OrganizationTeamMembershipActor;
export declare const DeploymentActor: S.Schema<OrganizationTeamMembershipActor>;
export type DeploymentCutoverActor = OrganizationTeamMembershipActor;
export declare const DeploymentCutoverActor: S.Schema<OrganizationTeamMembershipActor>;
export type DeploymentCancelledActor = OrganizationTeamMembershipActor;
export declare const DeploymentCancelledActor: S.Schema<OrganizationTeamMembershipActor>;
export interface Deployment {
    /** The ID of the deployment */
    id: string;
    /** Whether or not to automatically cutover once deployment is finished */
    auto_cutover: boolean;
    /** Whether or not to automatically delete the head branch once deployment is finished */
    auto_delete_branch: boolean;
    /** When the deployment was created */
    created_at: string;
    /** When the cutover for the deployment was initiated */
    cutover_at: string | null;
    /** Whether or not the deployment cutover will expire soon */
    cutover_expiring: boolean;
    /** Deploy check errors for the deployment. */
    deploy_check_errors?: string | null;
    /** When the deployment was finished */
    finished_at: string | null;
    /** When force cutover was triggered for the deployment */
    force_cutover_requested_at: string | null;
    /** When the deployment was queued */
    queued_at: string | null;
    /** When the deployment was ready for cutover */
    ready_to_cutover_at: string | null;
    /** When the deployment was started */
    started_at: string | null;
    /** The state the deployment is in */
    state: DeploymentState;
    /** When the deployment was submitted */
    submitted_at: string | null;
    /** When the deployment was last updated */
    updated_at: string;
    /** The name of the base branch the deployment will be merged into */
    into_branch: string;
    /** The number of the deploy request associated with this deployment */
    deploy_request_number: number;
    /** Whether the deployment is deployable */
    deployable: boolean;
    /** The deployments ahead of this one in the queue */
    preceding_deployments: DeploymentPrecedingDeploymentsList;
    deploy_operations: DeploymentDeployOperationsList;
    deploy_operation_summaries: DeploymentDeployOperationSummariesList;
    /** Schema lint errors preventing the deployment from completing */
    lint_errors: DeploymentLintErrorsList;
    /** The schema dependencies that must be satisfied */
    sequential_diff_dependencies: DeploymentSequentialDiffDependenciesList;
    /** Lookup Vitess index operations */
    lookup_vindex_operations: DeploymentLookupVindexOperationsList;
    /** Deployment throttling configurations. */
    throttler_configurations?: DeploymentThrottlerConfigurationsMap | null;
    /** The request to revert the schema operations in this deployment */
    deployment_revert_request: DeploymentDeploymentRevertRequestMap | null;
    actor?: OrganizationTeamMembershipActor | null;
    cutover_actor?: OrganizationTeamMembershipActor | null;
    cancelled_actor?: OrganizationTeamMembershipActor | null;
    /** When the schema was last updated for the deployment */
    schema_last_updated_at: string | null;
    /** Whether or not the deployment has a table locked */
    table_locked: boolean;
    /** The name of the table that is locked by the deployment. */
    locked_table_name?: string | null;
    /** Whether or not the deployment is an instant DDL deployment */
    instant_ddl: boolean;
    /** Whether or not the deployment is eligible for instant DDL */
    instant_ddl_eligible: boolean;
    /** Whether the deploy queue for the target branch is currently paused */
    queue_paused: boolean;
    /** A human-readable reason the deploy queue is paused, if known */
    queue_pause_reason: string | null;
}
export declare const Deployment: S.Schema<Deployment>;
export interface GetDeployQueueRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const GetDeployQueueRequest: S.Schema<GetDeployQueueRequest>;
/** The state the deployment is in */
export type PaginatedDeploymentDataItemState = "pending" | "ready" | "no_changes" | "queued" | "submitting" | "in_progress" | "pending_cutover" | "in_progress_vschema" | "in_progress_cancel" | "in_progress_cutover" | "complete" | "complete_cancel" | "complete_error" | "complete_pending_revert" | "in_progress_revert" | "in_progress_revert_vschema" | "complete_revert" | "complete_revert_error" | "cancelled" | "error";
export declare const PaginatedDeploymentDataItemState: any;
export type PaginatedDeploymentDataItemPrecedingDeploymentsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDeploymentDataItemPrecedingDeploymentsItemMap: S.Schema<PaginatedDeploymentDataItemPrecedingDeploymentsItemMap>;
/** The deployments ahead of this one in the queue */
export type PaginatedDeploymentDataItemPrecedingDeploymentsList = Array<PaginatedDeploymentDataItemPrecedingDeploymentsItemMap>;
export declare const PaginatedDeploymentDataItemPrecedingDeploymentsList: S.Schema<PaginatedDeploymentDataItemPrecedingDeploymentsList>;
/** The state of the deploy operation */
export type PaginatedDeploymentDataItemDeployOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDeploymentDataItemDeployOperationsItemState: any;
/** Names of foreign keys removed by this operation */
export type PaginatedDeploymentDataItemDeployOperationsItemRemovedForeignKeyNamesList = Array<string>;
export declare const PaginatedDeploymentDataItemDeployOperationsItemRemovedForeignKeyNamesList: S.Schema<PaginatedDeploymentDataItemDeployOperationsItemRemovedForeignKeyNamesList>;
export interface PaginatedDeploymentDataItemDeployOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The state of the deploy operation */
    state: PaginatedDeploymentDataItemDeployOperationsItemState;
    /** The keyspace modified by the deploy operation */
    keyspace_name: string;
    /** The name of the table modifed by the deploy operation */
    table_name: string;
    /** The operation name of the deploy operation */
    operation_name: string;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number | null;
    /** The percent completion for the deploy operation */
    progress_percentage: number | null;
    /** A link to documentation explaining the deploy error, if present */
    deploy_error_docs_url: string | null;
    /** The DDL statement for the deploy operation */
    ddl_statement: string;
    /** A syntax-highlighted DDL statement for the deploy operation */
    syntax_highlighted_ddl: string;
    /** When the deploy operation was created */
    created_at: string;
    /** When the deploy operation was last updated */
    updated_at: string;
    /** When the deploy operation was last throttled */
    throttled_at: string | null;
    /** Whether or not the deploy operation is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation is currently locked */
    table_locked: boolean;
    /** Whether or not the table modified by the deploy operation was recently used */
    table_recently_used: boolean;
    /** When the table modified by the deploy operation was last used */
    table_recently_used_at: string | null;
    /** Names of foreign keys removed by this operation */
    removed_foreign_key_names: PaginatedDeploymentDataItemDeployOperationsItemRemovedForeignKeyNamesList | null;
    /** Deploy errors for the deploy operation */
    deploy_errors: string | null;
}
export declare const PaginatedDeploymentDataItemDeployOperationsItem: S.Schema<PaginatedDeploymentDataItemDeployOperationsItem>;
export type PaginatedDeploymentDataItemDeployOperationsList = Array<PaginatedDeploymentDataItemDeployOperationsItem>;
export declare const PaginatedDeploymentDataItemDeployOperationsList: S.Schema<PaginatedDeploymentDataItemDeployOperationsList>;
/** The state of the deploy operation summary */
export type PaginatedDeploymentDataItemDeployOperationSummariesItemState = "pending" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItemState: any;
/** Names of foreign keys removed by this operation summary */
export type PaginatedDeploymentDataItemDeployOperationSummariesItemRemovedForeignKeyNamesList = Array<string>;
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItemRemovedForeignKeyNamesList: S.Schema<PaginatedDeploymentDataItemDeployOperationSummariesItemRemovedForeignKeyNamesList>;
/** Names of shards in the keyspace modified by the deploy operation summary */
export type PaginatedDeploymentDataItemDeployOperationSummariesItemShardNamesList = Array<string>;
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItemShardNamesList: S.Schema<PaginatedDeploymentDataItemDeployOperationSummariesItemShardNamesList>;
/** The state of the deploy operation */
export type PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItemState: any;
export interface PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The shard the deploy operation is being performed on */
    shard: string;
    /** The state of the deploy operation */
    state: PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItemState;
    /** The percent completion for the deploy operation */
    progress_percentage: number;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number;
}
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItem: S.Schema<PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItem>;
export type PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsList = Array<PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsItem>;
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsList: S.Schema<PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsList>;
export interface PaginatedDeploymentDataItemDeployOperationSummariesItem {
    /** The ID for the deploy operation summary */
    id: string;
    /** When the deploy operation summary was created */
    created_at: string;
    /** Deploy errors for the deploy operation summary */
    deploy_errors: string;
    /** The DDL statement for the deploy operation summary */
    ddl_statement: string;
    /** The estimated seconds until completion for the deploy operation summary */
    eta_seconds: number;
    /** The keyspace modified by the deploy operation summary */
    keyspace_name: string;
    /** The operation name of the deploy operation summary */
    operation_name: string;
    /** The percent completion for the deploy operation summary */
    progress_percentage: number;
    /** The state of the deploy operation summary */
    state: PaginatedDeploymentDataItemDeployOperationSummariesItemState;
    /** A syntax-highlighted DDL statement for the deploy operation summary */
    syntax_highlighted_ddl: string;
    /** The name of the table modifed by the deploy operation summary */
    table_name: string;
    /** When the table modified by the deploy operation summary was last used */
    table_recently_used_at: string | null;
    /** When the deploy operation summary was last throttled */
    throttled_at: string | null;
    /** Names of foreign keys removed by this operation summary */
    removed_foreign_key_names: PaginatedDeploymentDataItemDeployOperationSummariesItemRemovedForeignKeyNamesList;
    /** The number of shards in the keyspace modified by the deploy operation summary */
    shard_count: number;
    /** Names of shards in the keyspace modified by the deploy operation summary */
    shard_names: PaginatedDeploymentDataItemDeployOperationSummariesItemShardNamesList;
    /** Whether or not the deploy operation summary is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation summary was recently used */
    table_recently_used: boolean;
    /** Whether or not the keyspace modified by the deploy operation summary is sharded */
    sharded: boolean;
    operations: PaginatedDeploymentDataItemDeployOperationSummariesItemOperationsList;
}
export declare const PaginatedDeploymentDataItemDeployOperationSummariesItem: S.Schema<PaginatedDeploymentDataItemDeployOperationSummariesItem>;
export type PaginatedDeploymentDataItemDeployOperationSummariesList = Array<PaginatedDeploymentDataItemDeployOperationSummariesItem>;
export declare const PaginatedDeploymentDataItemDeployOperationSummariesList: S.Schema<PaginatedDeploymentDataItemDeployOperationSummariesList>;
export type PaginatedDeploymentDataItemLintErrorsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDeploymentDataItemLintErrorsItemMap: S.Schema<PaginatedDeploymentDataItemLintErrorsItemMap>;
/** Schema lint errors preventing the deployment from completing */
export type PaginatedDeploymentDataItemLintErrorsList = Array<PaginatedDeploymentDataItemLintErrorsItemMap>;
export declare const PaginatedDeploymentDataItemLintErrorsList: S.Schema<PaginatedDeploymentDataItemLintErrorsList>;
export type PaginatedDeploymentDataItemSequentialDiffDependenciesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDeploymentDataItemSequentialDiffDependenciesItemMap: S.Schema<PaginatedDeploymentDataItemSequentialDiffDependenciesItemMap>;
/** The schema dependencies that must be satisfied */
export type PaginatedDeploymentDataItemSequentialDiffDependenciesList = Array<PaginatedDeploymentDataItemSequentialDiffDependenciesItemMap>;
export declare const PaginatedDeploymentDataItemSequentialDiffDependenciesList: S.Schema<PaginatedDeploymentDataItemSequentialDiffDependenciesList>;
export type PaginatedDeploymentDataItemLookupVindexOperationsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDeploymentDataItemLookupVindexOperationsItemMap: S.Schema<PaginatedDeploymentDataItemLookupVindexOperationsItemMap>;
/** Lookup Vitess index operations */
export type PaginatedDeploymentDataItemLookupVindexOperationsList = Array<PaginatedDeploymentDataItemLookupVindexOperationsItemMap>;
export declare const PaginatedDeploymentDataItemLookupVindexOperationsList: S.Schema<PaginatedDeploymentDataItemLookupVindexOperationsList>;
/** Deployment throttling configurations. */
export type PaginatedDeploymentDataItemThrottlerConfigurationsMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDeploymentDataItemThrottlerConfigurationsMap: S.Schema<PaginatedDeploymentDataItemThrottlerConfigurationsMap>;
/** The request to revert the schema operations in this deployment */
export type PaginatedDeploymentDataItemDeploymentRevertRequestMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDeploymentDataItemDeploymentRevertRequestMap: S.Schema<PaginatedDeploymentDataItemDeploymentRevertRequestMap>;
export type PaginatedDeploymentDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedDeploymentDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDeploymentDataItemCutoverActor = OrganizationTeamMembershipActor;
export declare const PaginatedDeploymentDataItemCutoverActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDeploymentDataItemCancelledActor = OrganizationTeamMembershipActor;
export declare const PaginatedDeploymentDataItemCancelledActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedDeploymentDataItem {
    /** The ID of the deployment */
    id: string;
    /** Whether or not to automatically cutover once deployment is finished */
    auto_cutover: boolean;
    /** Whether or not to automatically delete the head branch once deployment is finished */
    auto_delete_branch: boolean;
    /** When the deployment was created */
    created_at: string;
    /** When the cutover for the deployment was initiated */
    cutover_at: string | null;
    /** Whether or not the deployment cutover will expire soon */
    cutover_expiring: boolean;
    /** Deploy check errors for the deployment. */
    deploy_check_errors?: string | null;
    /** When the deployment was finished */
    finished_at: string | null;
    /** When force cutover was triggered for the deployment */
    force_cutover_requested_at: string | null;
    /** When the deployment was queued */
    queued_at: string | null;
    /** When the deployment was ready for cutover */
    ready_to_cutover_at: string | null;
    /** When the deployment was started */
    started_at: string | null;
    /** The state the deployment is in */
    state: PaginatedDeploymentDataItemState;
    /** When the deployment was submitted */
    submitted_at: string | null;
    /** When the deployment was last updated */
    updated_at: string;
    /** The name of the base branch the deployment will be merged into */
    into_branch: string;
    /** The number of the deploy request associated with this deployment */
    deploy_request_number: number;
    /** Whether the deployment is deployable */
    deployable: boolean;
    /** The deployments ahead of this one in the queue */
    preceding_deployments: PaginatedDeploymentDataItemPrecedingDeploymentsList;
    deploy_operations: PaginatedDeploymentDataItemDeployOperationsList;
    deploy_operation_summaries: PaginatedDeploymentDataItemDeployOperationSummariesList;
    /** Schema lint errors preventing the deployment from completing */
    lint_errors: PaginatedDeploymentDataItemLintErrorsList;
    /** The schema dependencies that must be satisfied */
    sequential_diff_dependencies: PaginatedDeploymentDataItemSequentialDiffDependenciesList;
    /** Lookup Vitess index operations */
    lookup_vindex_operations: PaginatedDeploymentDataItemLookupVindexOperationsList;
    /** Deployment throttling configurations. */
    throttler_configurations?: PaginatedDeploymentDataItemThrottlerConfigurationsMap | null;
    /** The request to revert the schema operations in this deployment */
    deployment_revert_request: PaginatedDeploymentDataItemDeploymentRevertRequestMap | null;
    actor?: OrganizationTeamMembershipActor | null;
    cutover_actor?: OrganizationTeamMembershipActor | null;
    cancelled_actor?: OrganizationTeamMembershipActor | null;
    /** When the schema was last updated for the deployment */
    schema_last_updated_at: string | null;
    /** Whether or not the deployment has a table locked */
    table_locked: boolean;
    /** The name of the table that is locked by the deployment. */
    locked_table_name?: string | null;
    /** Whether or not the deployment is an instant DDL deployment */
    instant_ddl: boolean;
    /** Whether or not the deployment is eligible for instant DDL */
    instant_ddl_eligible: boolean;
    /** Whether the deploy queue for the target branch is currently paused */
    queue_paused: boolean;
    /** A human-readable reason the deploy queue is paused, if known */
    queue_pause_reason: string | null;
}
export declare const PaginatedDeploymentDataItem: S.Schema<PaginatedDeploymentDataItem>;
export type PaginatedDeploymentDataList = Array<PaginatedDeploymentDataItem>;
export declare const PaginatedDeploymentDataList: S.Schema<PaginatedDeploymentDataList>;
export interface PaginatedDeployment {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDeploymentDataList;
}
export declare const PaginatedDeployment: S.Schema<PaginatedDeployment>;
export interface GetDeployRequestRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const GetDeployRequestRequest: S.Schema<GetDeployRequestRequest>;
export interface GetDeployRequestThrottlerRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const GetDeployRequestThrottlerRequest: S.Schema<GetDeployRequestThrottlerRequest>;
export type GetInstantBranchMetricsRequestMetricsItem = "planetscale_backup_fetch_percent" | "planetscale_backup_restore_active" | "planetscale_dedicated_pgbouncer_cpu_usage" | "planetscale_dedicated_pgbouncer_current_client_connections" | "planetscale_dedicated_pgbouncer_current_connections" | "planetscale_dedicated_pgbouncer_current_server_connections" | "planetscale_dedicated_pgbouncer_max_connections" | "planetscale_dedicated_pgbouncer_memory_usage" | "planetscale_pgbouncer_current_client_connections" | "planetscale_pgbouncer_current_server_connections" | "planetscale_pgbouncer_settings_max_client_conn" | "planetscale_postgres_connection_state" | "planetscale_postgres_settings_max_connections" | "planetscale_volume_capacity_bytes" | "planetscale_volume_disk_usage_bytes" | "planetscale_volume_usage_percentage";
export declare const GetInstantBranchMetricsRequestMetricsItem: any;
export type GetInstantBranchMetricsRequestMetricsList = Array<GetInstantBranchMetricsRequestMetricsItem | (string & {})>;
export declare const GetInstantBranchMetricsRequestMetricsList: S.Schema<GetInstantBranchMetricsRequestMetricsList>;
export interface GetInstantBranchMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Metric names to retrieve. Pass as `metrics[]=name` (repeat for multiple), `metrics=name`, or a comma-separated list (`metrics=name,other`). */
    metrics?: GetInstantBranchMetricsRequestMetricsList;
    /** Filter by Postgres role */
    role?: string;
    /** Filter by shard */
    shard?: string;
    /** Filter by container */
    container?: string;
    /** Filter by pod */
    pod?: string;
}
export declare const GetInstantBranchMetricsRequest: S.Schema<GetInstantBranchMetricsRequest>;
export interface GetInstantBranchMetricsResponseBranch {
    /** The ID for the resource */
    id: string;
    /** The name for the resource */
    name: string;
    /** When the resource was created */
    created_at: string;
    /** When the resource was last updated */
    updated_at: string;
    /** When the resource was deleted, if deleted */
    deleted_at: string;
}
export declare const GetInstantBranchMetricsResponseBranch: S.Schema<GetInstantBranchMetricsResponseBranch>;
export interface GetInstantBranchMetricsResponseMetricsItemValuesItem {
    /** Pod name */
    pod: string;
    /** Postgres role (primary or replica) */
    role: string;
    /** Current metric value */
    value: number;
}
export declare const GetInstantBranchMetricsResponseMetricsItemValuesItem: S.Schema<GetInstantBranchMetricsResponseMetricsItemValuesItem>;
export type GetInstantBranchMetricsResponseMetricsItemValuesList = Array<GetInstantBranchMetricsResponseMetricsItemValuesItem>;
export declare const GetInstantBranchMetricsResponseMetricsItemValuesList: S.Schema<GetInstantBranchMetricsResponseMetricsItemValuesList>;
export interface GetInstantBranchMetricsResponseMetricsItem {
    /** The metric name */
    metric: string;
    /** A human-readable metric label */
    label: string;
    values: GetInstantBranchMetricsResponseMetricsItemValuesList;
}
export declare const GetInstantBranchMetricsResponseMetricsItem: S.Schema<GetInstantBranchMetricsResponseMetricsItem>;
export type GetInstantBranchMetricsResponseMetricsList = Array<GetInstantBranchMetricsResponseMetricsItem>;
export declare const GetInstantBranchMetricsResponseMetricsList: S.Schema<GetInstantBranchMetricsResponseMetricsList>;
export interface GetInstantBranchMetricsResponse {
    /** The metrics response type */
    type: string;
    branch: GetInstantBranchMetricsResponseBranch;
    metrics: GetInstantBranchMetricsResponseMetricsList;
}
export declare const GetInstantBranchMetricsResponse: S.Schema<GetInstantBranchMetricsResponse>;
export type GetInstantTabletMetricsRequestMetricsItem = "replication_lag" | "primary_cpu_usage" | "primary_memory_usage" | "vtgate_cpu_usage" | "vtgate_memory_usage";
export declare const GetInstantTabletMetricsRequestMetricsItem: any;
export type GetInstantTabletMetricsRequestMetricsList = Array<GetInstantTabletMetricsRequestMetricsItem | (string & {})>;
export declare const GetInstantTabletMetricsRequestMetricsList: S.Schema<GetInstantTabletMetricsRequestMetricsList>;
export interface GetInstantTabletMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Metric names to retrieve. Pass as `metrics[]=name` (repeat for multiple), `metrics=name`, or a comma-separated list (`metrics=name,other`). */
    metrics?: GetInstantTabletMetricsRequestMetricsList;
    /** Filter by keyspace */
    keyspace?: string;
    /** Filter by shard */
    shard?: string;
}
export declare const GetInstantTabletMetricsRequest: S.Schema<GetInstantTabletMetricsRequest>;
export type GetInstantTabletMetricsResponseBranch = GetInstantBranchMetricsResponseBranch;
export declare const GetInstantTabletMetricsResponseBranch: S.Schema<GetInstantBranchMetricsResponseBranch>;
export type GetInstantTabletMetricsResponseMetricsItemValuesItem = GetInstantBranchMetricsResponseMetricsItemValuesItem;
export declare const GetInstantTabletMetricsResponseMetricsItemValuesItem: S.Schema<GetInstantBranchMetricsResponseMetricsItemValuesItem>;
export type GetInstantTabletMetricsResponseMetricsItemValuesList = Array<GetInstantBranchMetricsResponseMetricsItemValuesItem>;
export declare const GetInstantTabletMetricsResponseMetricsItemValuesList: S.Schema<GetInstantTabletMetricsResponseMetricsItemValuesList>;
export interface GetInstantTabletMetricsResponseMetricsItem {
    /** The metric name */
    metric: string;
    /** A human-readable metric label */
    label: string;
    values: GetInstantTabletMetricsResponseMetricsItemValuesList;
}
export declare const GetInstantTabletMetricsResponseMetricsItem: S.Schema<GetInstantTabletMetricsResponseMetricsItem>;
export type GetInstantTabletMetricsResponseMetricsList = Array<GetInstantTabletMetricsResponseMetricsItem>;
export declare const GetInstantTabletMetricsResponseMetricsList: S.Schema<GetInstantTabletMetricsResponseMetricsList>;
export interface GetInstantTabletMetricsResponse {
    /** The metrics response type */
    type: string;
    branch: GetInstantBranchMetricsResponseBranch;
    metrics: GetInstantTabletMetricsResponseMetricsList;
}
export declare const GetInstantTabletMetricsResponse: S.Schema<GetInstantTabletMetricsResponse>;
export interface GetInvoiceRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Invoice public ID from `list_invoices`. Example: `aabb12123434`. */
    id: string;
}
export declare const GetInvoiceRequest: S.Schema<GetInvoiceRequest>;
export interface Invoice {
    /** The ID of the invoice */
    id: string;
    /** The total amount of the invoice, as a stringified decimal to preserve precision */
    total: string;
    /** Start of the billing period */
    billing_period_start: string;
    /** End of the billing period */
    billing_period_end: string;
    /** Whether the invoice has been paid */
    paid: boolean;
    /** Whether the invoice is past due and unpaid */
    overdue: boolean;
}
export declare const Invoice: S.Schema<Invoice>;
export interface GetInvoiceLineItemsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Invoice public ID from `list_invoices`. Example: `aabb12123434`. */
    id: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const GetInvoiceLineItemsRequest: S.Schema<GetInvoiceLineItemsRequest>;
export type PaginatedLineItemDataItemResource = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedLineItemDataItemResource: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface PaginatedLineItemDataItem {
    /** The ID for the line item */
    id: string;
    /** The total for the line item */
    subtotal: number;
    /** The description for the line item */
    description: string;
    /** The name of the billable item */
    metric_name: string;
    /** Whether the line item is billed through Cloudflare */
    cloudflare_billed: boolean;
    /** The ID for the billed database */
    database_id: string;
    /** The name for the billed database */
    database_name: string;
    resource: OrganizationTeamMembershipUserDefaultOrganization;
}
export declare const PaginatedLineItemDataItem: S.Schema<PaginatedLineItemDataItem>;
export type PaginatedLineItemDataList = Array<PaginatedLineItemDataItem>;
export declare const PaginatedLineItemDataList: S.Schema<PaginatedLineItemDataList>;
export interface PaginatedLineItem {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedLineItemDataList;
}
export declare const PaginatedLineItem: S.Schema<PaginatedLineItem>;
export interface GetKeyspaceRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
}
export declare const GetKeyspaceRequest: S.Schema<GetKeyspaceRequest>;
export interface GetKeyspaceResizeRequestRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
    /** The ID of the resize request */
    id: string;
}
export declare const GetKeyspaceResizeRequestRequest: S.Schema<GetKeyspaceResizeRequestRequest>;
export interface GetKeyspaceRolloutStatusRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
}
export declare const GetKeyspaceRolloutStatusRequest: S.Schema<GetKeyspaceRolloutStatusRequest>;
export interface GetKeyspaceRolloutStatusResponseShardsItem {
    /** The name of the shard */
    name: string;
    /** The time at which the rollout started */
    last_rollout_started_at: string;
    /** The time at which the rollout completed */
    last_rollout_finished_at: string;
    /** The current state of the rollout at the shard level */
    state: string;
}
export declare const GetKeyspaceRolloutStatusResponseShardsItem: S.Schema<GetKeyspaceRolloutStatusResponseShardsItem>;
export type GetKeyspaceRolloutStatusResponseShardsList = Array<GetKeyspaceRolloutStatusResponseShardsItem>;
export declare const GetKeyspaceRolloutStatusResponseShardsList: S.Schema<GetKeyspaceRolloutStatusResponseShardsList>;
export interface GetKeyspaceRolloutStatusResponse {
    /** The name of the keyspace */
    name: string;
    /** The current state of the rollout at the keyspace level */
    state: string;
    shards: GetKeyspaceRolloutStatusResponseShardsList;
}
export declare const GetKeyspaceRolloutStatusResponse: S.Schema<GetKeyspaceRolloutStatusResponse>;
export interface GetKeyspaceVschemaRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
}
export declare const GetKeyspaceVschemaRequest: S.Schema<GetKeyspaceVschemaRequest>;
export interface GetKeyspaceVschemaResponse {
    /** The keyspace's VSchema */
    raw: string;
}
export declare const GetKeyspaceVschemaResponse: S.Schema<GetKeyspaceVschemaResponse>;
export interface GetMaintenanceScheduleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The ID of the maintenance schedule */
    id: string;
}
export declare const GetMaintenanceScheduleRequest: S.Schema<GetMaintenanceScheduleRequest>;
/** The frequency unit of the maintenance schedule */
export type BranchMaintenanceScheduleFrequencyUnit = "day" | "week" | "month" | "once";
export declare const BranchMaintenanceScheduleFrequencyUnit: any;
export interface BranchMaintenanceSchedule {
    /** The ID of the maintenance schedule */
    id: string;
    /** The display name of the maintenance schedule */
    name: string;
    /** When the maintenance schedule was created */
    created_at: string;
    /** When the maintenance schedule was last updated */
    updated_at: string;
    /** When the last maintenance window started */
    last_window_datetime: string;
    /** When the next maintenance window is scheduled */
    next_window_datetime: string;
    /** The duration of the maintenance window in hours */
    duration: number;
    /** Day of the week (0 = Sunday, 6 = Saturday, 7 = every day) */
    day: number;
    /** Hour of the day in UTC (0-23) */
    hour: number;
    /** Week of the month for monthly schedules (0-3) */
    week: number;
    /** The frequency value of the maintenance schedule */
    frequency_value: number;
    /** The frequency unit of the maintenance schedule */
    frequency_unit: BranchMaintenanceScheduleFrequencyUnit;
    /** Whether the maintenance schedule is enabled */
    enabled: boolean;
    /** When a one-time maintenance schedule expires */
    expires_at: string | null;
    /** The deadline for a required maintenance schedule */
    deadline_at: string | null;
    /** Whether the maintenance schedule is required */
    required: boolean;
    /** Whether there is a pending Vitess version update */
    pending_vitess_version_update: boolean;
    /** The pending Vitess version, if any */
    pending_vitess_version: string | null;
    /** Whether there is a pending MySQL version update */
    pending_mysql_version_update: boolean;
    /** The pending MySQL version, if any */
    pending_mysql_version: string | null;
}
export declare const BranchMaintenanceSchedule: S.Schema<BranchMaintenanceSchedule>;
export interface GetOauthApplicationRequest {
    /** The name of the organization the OAuth application belongs to */
    organization: string;
    /** The ID of the OAuth application */
    application_id: string;
}
export declare const GetOauthApplicationRequest: S.Schema<GetOauthApplicationRequest>;
/** Scopes grouped by resource type (database, organization, branch, user) with scope, description, and admin flag */
export type OauthApplicationScopesByResourceMap = {
    [key: string]: unknown | undefined;
};
export declare const OauthApplicationScopesByResourceMap: S.Schema<OauthApplicationScopesByResourceMap>;
/** All available scopes grouped by resource type with scope, description, selected, and admin flags */
export type OauthApplicationAllScopesByResourceMap = {
    [key: string]: unknown | undefined;
};
export declare const OauthApplicationAllScopesByResourceMap: S.Schema<OauthApplicationAllScopesByResourceMap>;
export type OauthApplicationMcpToolGroupsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const OauthApplicationMcpToolGroupsItemMap: S.Schema<OauthApplicationMcpToolGroupsItemMap>;
/** MCP tool groups (id, label, section, tools, scopes, parent_id, default_enabled, roles) selectable when authorizing a DCR app; only present for DCR apps. Database-section groups also carry org_scopes (the organization-tier scope names granting the group across all databases in an organization) and org_roles (the organization roles allowed to grant them); both are null for organization-section groups */
export type OauthApplicationMcpToolGroupsList = Array<OauthApplicationMcpToolGroupsItemMap>;
export declare const OauthApplicationMcpToolGroupsList: S.Schema<OauthApplicationMcpToolGroupsList>;
export interface OauthApplication {
    /** The ID of the app */
    id: string;
    /** The name of the app */
    name: string;
    /** The redirect URI of the OAuth application */
    redirect_uri: string;
    /** The domain of the OAuth application. Used for verification of a valid redirect uri */
    domain: string;
    /** When the OAuth application was created */
    created_at: string;
    /** When the OAuth application was last updated */
    updated_at: string;
    /** The scopes that the OAuth application requires on a user account, as a space-separated string */
    scopes: string;
    /** The image source for the OAuth application's avatar */
    avatar: string;
    /** The OAuth application's unique client id */
    client_id: string;
    /** The number of tokens issued by the OAuth application */
    tokens: number;
    /** Whether the OAuth application was created via Dynamic Client Registration */
    dcr: boolean;
    /** Whether the OAuth application is limited to authorizing a single organization */
    single_org_authorization: boolean;
    /** Whether the OAuth application requires at least one organization to be authorized */
    requires_org_scope: boolean;
    /** Scopes grouped by resource type (database, organization, branch, user) with scope, description, and admin flag */
    scopes_by_resource: OauthApplicationScopesByResourceMap;
    /** All available scopes grouped by resource type with scope, description, selected, and admin flags */
    all_scopes_by_resource: OauthApplicationAllScopesByResourceMap;
    /** MCP tool groups (id, label, section, tools, scopes, parent_id, default_enabled, roles) selectable when authorizing a DCR app; only present for DCR apps. Database-section groups also carry org_scopes (the organization-tier scope names granting the group across all databases in an organization) and org_roles (the organization roles allowed to grant them); both are null for organization-section groups */
    mcp_tool_groups?: OauthApplicationMcpToolGroupsList | null;
}
export declare const OauthApplication: S.Schema<OauthApplication>;
export interface GetOauthTokenRequest {
    /** The name of the organization the OAuth application belongs to */
    organization: string;
    /** The ID of the OAuth application */
    application_id: string;
    /** The ID of the OAuth application token */
    token_id: string;
}
export declare const GetOauthTokenRequest: S.Schema<GetOauthTokenRequest>;
export interface GetOrganizationRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const GetOrganizationRequest: S.Schema<GetOrganizationRequest>;
/** Features that can be enabled on the organization */
export type OrganizationFeaturesMap = {
    [key: string]: unknown | undefined;
};
export declare const OrganizationFeaturesMap: S.Schema<OrganizationFeaturesMap>;
export interface Organization {
    /** The ID for the organization */
    id: string;
    /** The name of the organization */
    name: string;
    /** The billing email of the organization */
    billing_email: string;
    /** When the organization was created */
    created_at: string;
    /** When the organization was last updated */
    updated_at: string;
    /** The billing plan of the organization */
    plan: string;
    /** Whether or not the organization's billing information is valid */
    valid_billing_info: boolean;
    /** Whether or not SSO is enabled on the organization */
    sso: boolean;
    /** Whether or not the organization uses an SSO directory */
    sso_directory: boolean;
    /** Whether or not the organization has single tenancy enabled */
    single_tenancy: boolean;
    /** Whether or not the organization has managed tenancy enabled */
    managed_tenancy: boolean;
    /** Whether or not the organization has past due billing invoices. */
    has_past_due_invoices?: boolean | null;
    /** The number of databases in the organization */
    database_count: number;
    /** The URL of the organization's SSO portal. */
    sso_portal_url?: string | null;
    /** Features that can be enabled on the organization */
    features: OrganizationFeaturesMap;
    /** Whether or not the IdP provider is be responsible for managing roles in PlanetScale */
    idp_managed_roles: boolean;
    /** The expected monthly budget for the organization */
    invoice_budget_amount: string;
    /** The keyspace shard limit for the organization */
    keyspace_shard_limit: number;
    /** Whether or not the organization has a payment method on file */
    has_card: boolean;
    /** Whether or not the organization requires payment information */
    payment_info_required: boolean;
}
export declare const Organization: S.Schema<Organization>;
export interface GetOrganizationBillingPaymentMethodRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const GetOrganizationBillingPaymentMethodRequest: S.Schema<GetOrganizationBillingPaymentMethodRequest>;
/** The resource type */
export type BillingPaymentMethodType = "PaymentMethod";
export declare const BillingPaymentMethodType: any;
export interface BillingPaymentMethod {
    /** The resource type */
    type: BillingPaymentMethodType;
    /** The payment method ID */
    id: string;
    /** The card brand, such as visa or mastercard */
    brand: string;
    /** The final four digits of the card number */
    last4: string;
    /** The card expiration month */
    exp_month: number;
    /** The card expiration year */
    exp_year: number;
    /** The cardholder name */
    name: string | null;
}
export declare const BillingPaymentMethod: S.Schema<BillingPaymentMethod>;
export interface GetOrganizationMembershipRequest {
    /** The name of the organization */
    organization: string;
    /** The ID of the user */
    id: string;
}
export declare const GetOrganizationMembershipRequest: S.Schema<GetOrganizationMembershipRequest>;
export type OrganizationMembershipUserDefaultOrganization = OrganizationTeamMembershipUserDefaultOrganization;
export declare const OrganizationMembershipUserDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface OrganizationMembershipUser {
    /** The ID of the user */
    id: string;
    /** The display name of the user */
    display_name: string;
    /** The name of the user */
    name?: string | null;
    /** The email of the user */
    email: string;
    /** The URL source of the user's avatar */
    avatar_url: string;
    /** When the user was created */
    created_at: string;
    /** When the user was last updated */
    updated_at: string;
    /** Whether or not the user has configured two factor authentication */
    two_factor_auth_configured: boolean;
    default_organization?: OrganizationTeamMembershipUserDefaultOrganization | null;
    /** Whether or not the user is managed by SSO. */
    sso?: boolean | null;
    /** Whether or not the user is managed by an authentication provider. */
    managed?: boolean | null;
    /** Whether or not the user is managed by a SSO directory. */
    directory_managed?: boolean | null;
    /** Whether or not the user is verified by email. */
    email_verified?: boolean | null;
}
export declare const OrganizationMembershipUser: S.Schema<OrganizationMembershipUser>;
/** The role of the user in the organization */
export type OrganizationMembershipRole = "member" | "admin";
export declare const OrganizationMembershipRole: any;
export interface OrganizationMembership {
    /** The ID of the membership */
    id: string;
    user: OrganizationMembershipUser;
    /** The role of the user in the organization */
    role: OrganizationMembershipRole;
    /** When the membership was created */
    created_at: string;
    /** When the membership was last updated */
    updated_at: string;
}
export declare const OrganizationMembership: S.Schema<OrganizationMembership>;
export interface GetOrganizationSsoRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const GetOrganizationSsoRequest: S.Schema<GetOrganizationSsoRequest>;
export interface GetOrganizationSsoDomainRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** The public ID of the organization domain */
    id: string;
}
export declare const GetOrganizationSsoDomainRequest: S.Schema<GetOrganizationSsoDomainRequest>;
/** The resource type */
export type OrganizationDomainType = "OrganizationDomain";
export declare const OrganizationDomainType: any;
/** The verification state of the domain */
export type OrganizationDomainState = "pending" | "verified" | "failed";
export declare const OrganizationDomainState: any;
export interface OrganizationDomain {
    /** The resource type */
    type: OrganizationDomainType;
    /** The public ID of the organization domain */
    id: string;
    /** The domain name */
    domain: string;
    /** The verification state of the domain */
    state: OrganizationDomainState;
    /** When the domain was verified */
    verified_at: string | null;
    /** The reason domain verification failed */
    failure_reason: string | null;
    /** When the domain was created */
    created_at: string;
    /** When the domain was last updated */
    updated_at: string;
}
export declare const OrganizationDomain: S.Schema<OrganizationDomain>;
export interface GetOrganizationTeamRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
}
export declare const GetOrganizationTeamRequest: S.Schema<GetOrganizationTeamRequest>;
export interface GetOrganizationTeamMemberRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
    /** The ID of the team membership or the ID of the member */
    id: string;
}
export declare const GetOrganizationTeamMemberRequest: S.Schema<GetOrganizationTeamMemberRequest>;
export interface GetPasswordRequest {
    /** The name of the organization the password belongs to */
    organization: string;
    /** The name of the database the password belongs to */
    database: string;
    /** The name of the branch the password belongs to */
    branch: string;
    /** The ID of the password */
    id: string;
}
export declare const GetPasswordRequest: S.Schema<GetPasswordRequest>;
/** The role for the password */
export type DatabaseBranchPasswordRole = "reader" | "writer" | "admin" | "readwriter";
export declare const DatabaseBranchPasswordRole: any;
/** List of IP addresses or CIDR ranges that can use this password */
export type DatabaseBranchPasswordCidrsList = Array<string>;
export declare const DatabaseBranchPasswordCidrsList: S.Schema<DatabaseBranchPasswordCidrsList>;
/** The list of hosts in each availability zone providing direct access to a vtgate */
export type DatabaseBranchPasswordDirectVtgateAddressesList = Array<string>;
export declare const DatabaseBranchPasswordDirectVtgateAddressesList: S.Schema<DatabaseBranchPasswordDirectVtgateAddressesList>;
/** The read-only replica host URLs */
export type DatabaseBranchPasswordAccessHostRegionalUrlsList = Array<string>;
export declare const DatabaseBranchPasswordAccessHostRegionalUrlsList: S.Schema<DatabaseBranchPasswordAccessHostRegionalUrlsList>;
export type DatabaseBranchPasswordActor = OrganizationTeamMembershipActor;
export declare const DatabaseBranchPasswordActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type DatabaseBranchPasswordRegionPublicIpAddressesList = Array<string>;
export declare const DatabaseBranchPasswordRegionPublicIpAddressesList: S.Schema<DatabaseBranchPasswordRegionPublicIpAddressesList>;
export interface DatabaseBranchPasswordRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: DatabaseBranchPasswordRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const DatabaseBranchPasswordRegion: S.Schema<DatabaseBranchPasswordRegion>;
export type DatabaseBranchPasswordDatabaseBranch = OrganizationTeamMembershipPasswordsItemDatabaseBranch;
export declare const DatabaseBranchPasswordDatabaseBranch: S.Schema<OrganizationTeamMembershipPasswordsItemDatabaseBranch>;
export interface DatabaseBranchPassword {
    /** The ID for the password */
    id: string;
    /** The display name for the password */
    name: string;
    /** The role for the password */
    role: DatabaseBranchPasswordRole;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs: DatabaseBranchPasswordCidrsList | null;
    /** When the password was created */
    created_at: string;
    /** When the password was deleted */
    deleted_at: string | null;
    /** When the password will expire */
    expires_at: string | null;
    /** When the password was last used to execute a query */
    last_used_at: string | null;
    /** True if the credentials are expired */
    expired: boolean;
    /** True if the credentials connect directly to a vtgate, bypassing load balancers */
    direct_vtgate: boolean;
    /** The list of hosts in each availability zone providing direct access to a vtgate */
    direct_vtgate_addresses: DatabaseBranchPasswordDirectVtgateAddressesList;
    /** Time to live (in seconds) for the password. The password will be invalid when TTL has passed */
    ttl_seconds: number | null;
    /** The host URL for the password */
    access_host_url: string;
    /** The regional host URL */
    access_host_regional_url: string;
    /** The read-only replica host URLs */
    access_host_regional_urls: DatabaseBranchPasswordAccessHostRegionalUrlsList;
    actor: OrganizationTeamMembershipActor | null;
    region: DatabaseBranchPasswordRegion;
    /** The username for the password */
    username: string;
    /** The plaintext password. Null except in the response from the create endpoint. */
    plain_text: Redacted.Redacted<string> | null;
    /** Whether or not the password is for a read replica */
    replica: boolean;
    /** Whether or not the password is scoped to a read-only region */
    read_only_region: boolean;
    /** Whether or not the password can be renewed */
    renewable: boolean;
    database_branch: OrganizationTeamMembershipPasswordsItemDatabaseBranch;
}
export declare const DatabaseBranchPassword: S.Schema<DatabaseBranchPassword>;
export interface GetPaymentMethodSetupRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Billing payment method setup ID from `update_payment_method`. Example: `pmsetup_1234`. */
    id: string;
}
export declare const GetPaymentMethodSetupRequest: S.Schema<GetPaymentMethodSetupRequest>;
/** The resource type */
export type BillingPaymentMethodSetupType = "BillingPaymentMethodSetup";
export declare const BillingPaymentMethodSetupType: any;
/** The setup state */
export type BillingPaymentMethodSetupState = "pending" | "completed" | "failed" | "expired";
export declare const BillingPaymentMethodSetupState: any;
export interface BillingPaymentMethodSetup {
    /** The resource type */
    type: BillingPaymentMethodSetupType;
    /** The billing payment method setup ID */
    id: string;
    /** The setup state */
    state: BillingPaymentMethodSetupState;
    /** The hosted checkout URL while the setup is pending */
    checkout_url: string | null;
    /** The failure message when the setup failed */
    error: string | null;
    /** When the pending setup expires */
    expires_at: string | null;
    /** When the setup completed */
    completed_at: string | null;
    /** When the setup failed */
    failed_at: string | null;
}
export declare const BillingPaymentMethodSetup: S.Schema<BillingPaymentMethodSetup>;
export interface GetQueryPatternsReportRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID of the query patterns report */
    id: string;
}
export declare const GetQueryPatternsReportRequest: S.Schema<GetQueryPatternsReportRequest>;
export interface GetQueryPatternsReportResponse {
}
export declare const GetQueryPatternsReportResponse: S.Schema<GetQueryPatternsReportResponse>;
export interface GetQueryPatternsReportStatusRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID of the query patterns report */
    id: string;
}
export declare const GetQueryPatternsReportStatusRequest: S.Schema<GetQueryPatternsReportStatusRequest>;
export type GetQueryStatisticsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetQueryStatisticsRequestPeriod: any;
export interface GetQueryStatisticsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The query fingerprint */
    fingerprint: string;
    /** The keyspace to filter by */
    keyspace: string;
    /** Start time for filtering query statistics (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering query statistics (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering query statistics */
    period?: GetQueryStatisticsRequestPeriod | (string & {});
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const GetQueryStatisticsRequest: S.Schema<GetQueryStatisticsRequest>;
export type GetQuerySummaryRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetQuerySummaryRequestPeriod: any;
export interface GetQuerySummaryRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The query fingerprint */
    fingerprint: string;
    /** The keyspace to filter by */
    keyspace: string;
    /** Start time for filtering query statistics (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering query statistics (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering query statistics */
    period?: GetQuerySummaryRequestPeriod | (string & {});
}
export declare const GetQuerySummaryRequest: S.Schema<GetQuerySummaryRequest>;
/** Tables accessed by the query */
export type QuerySummaryTablesList = Array<string>;
export declare const QuerySummaryTablesList: S.Schema<QuerySummaryTablesList>;
/** Fully qualified tables accessed by the query */
export type QuerySummaryQualifiedTablesList = Array<string>;
export declare const QuerySummaryQualifiedTablesList: S.Schema<QuerySummaryQualifiedTablesList>;
export type QuerySummaryTableKeyspacesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const QuerySummaryTableKeyspacesItemMap: S.Schema<QuerySummaryTableKeyspacesItemMap>;
/** Mapping of tables to their keyspaces */
export type QuerySummaryTableKeyspacesList = Array<QuerySummaryTableKeyspacesItemMap>;
export declare const QuerySummaryTableKeyspacesList: S.Schema<QuerySummaryTableKeyspacesList>;
export type QuerySummaryIndexUsagesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const QuerySummaryIndexUsagesItemMap: S.Schema<QuerySummaryIndexUsagesItemMap>;
/** Index usage information */
export type QuerySummaryIndexUsagesList = Array<QuerySummaryIndexUsagesItemMap>;
export declare const QuerySummaryIndexUsagesList: S.Schema<QuerySummaryIndexUsagesList>;
export type QuerySummaryRoutingIndexUsagesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const QuerySummaryRoutingIndexUsagesItemMap: S.Schema<QuerySummaryRoutingIndexUsagesItemMap>;
/** Routing index usage information */
export type QuerySummaryRoutingIndexUsagesList = Array<QuerySummaryRoutingIndexUsagesItemMap>;
export declare const QuerySummaryRoutingIndexUsagesList: S.Schema<QuerySummaryRoutingIndexUsagesList>;
export interface QuerySummary {
    /** The ID of the query summary */
    id: string;
    /** The query fingerprint */
    fingerprint: string;
    /** The type of SQL statement */
    statement_type: string;
    /** The keyspace the query ran against */
    keyspace: string;
    /** The normalized SQL statement */
    normalized_sql: string;
    /** Syntax highlighted SQL statement */
    syntax_highlighted_sql: string;
    /** Whether the query is a multishard query */
    multishard: boolean;
    /** The number of times this query was executed */
    query_count: number;
    /** The number of times this query resulted in an error */
    error_count: number;
    /** Tables accessed by the query */
    tables: QuerySummaryTablesList;
    /** Fully qualified tables accessed by the query */
    qualified_tables: QuerySummaryQualifiedTablesList;
    /** Mapping of tables to their keyspaces */
    table_keyspaces: QuerySummaryTableKeyspacesList;
    /** Index usage information */
    index_usages: QuerySummaryIndexUsagesList;
    /** Routing index usage information */
    routing_index_usages: QuerySummaryRoutingIndexUsagesList;
    /** The total number of shard queries */
    sum_shard_queries: number;
    /** The maximum number of shard queries for a single execution */
    max_shard_queries: number;
    /** The average number of shard queries */
    avg_shard_queries: number;
    /** The average number of parallel workers */
    avg_parallel_workers: number;
    /** The total number of rows read */
    sum_rows_read: number;
    /** The total number of rows affected */
    sum_rows_affected: number;
    /** The total number of rows returned */
    sum_rows_returned: number;
    /** Average rows read per row returned */
    rows_read_per_returned: number;
    /** Average rows read per query */
    rows_read_per_query: number;
    /** Average rows returned per query */
    rows_returned_per_query: number;
    /** Average rows affected per query */
    rows_affected_per_query: number;
    /** Total duration in milliseconds across all executions */
    sum_total_duration_millis: number;
    /** Percentage of total query time */
    sum_total_duration_percent: number;
    /** Total CPU duration in milliseconds */
    sum_cpu_duration_millis: number;
    /** Percentage of total CPU time */
    sum_cpu_duration_percent: number;
    /** Total IO duration in milliseconds */
    sum_io_duration_millis: number;
    /** Percentage of total IO time */
    sum_io_duration_percent: number;
    /** When this query was last executed */
    last_run_at: string | null;
    /** Average time per query execution */
    time_per_query: number;
    /** 50th percentile latency */
    p50_latency: number;
    /** 99th percentile latency */
    p99_latency: number;
    /** Maximum latency observed */
    max_latency: number;
    /** Total egress bytes */
    egress_bytes: number;
    /** Average egress bytes per query */
    egress_bytes_per_query: number;
    /** Maximum egress bytes for a single execution */
    max_egress_bytes: number;
    /** Total ingress bytes */
    ingress_bytes: number;
    /** Average ingress bytes per query */
    ingress_bytes_per_query: number;
    /** Maximum ingress bytes for a single execution */
    max_ingress_bytes: number;
    /** Total blocks read from disk */
    blocks_read: number;
    /** Total blocks found in cache */
    blocks_hit: number;
    /** Cache hit ratio for blocks */
    block_cache_hit_ratio: number;
    /** Total blocks dirtied */
    blocks_dirtied: number;
    /** Total blocks written */
    blocks_written: number;
    /** The number of executions that triggered a traffic control warning */
    traffic_control_warnings: number;
    /** The number of executions throttled by traffic control */
    traffic_control_throttled: number;
    /** The number of executions checked by traffic control rules */
    traffic_control_checked: number;
}
export declare const QuerySummary: S.Schema<QuerySummary>;
export interface GetReadOnlyReplicaRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the read-only replica */
    read_only_replica: string;
}
export declare const GetReadOnlyReplicaRequest: S.Schema<GetReadOnlyReplicaRequest>;
export interface GetRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the role */
    id: string;
    /** Return connection details for a replica */
    replica?: boolean;
    /** Return connection details for this read-only replica */
    read_only_replica?: string;
    /** Return connection details for this bouncer */
    bouncer?: string;
}
export declare const GetRoleRequest: S.Schema<GetRoleRequest>;
export interface GetSchemaRecommendationRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Schema recommendation sequence number. Example: `42`. */
    number: number;
}
export declare const GetSchemaRecommendationRequest: S.Schema<GetSchemaRecommendationRequest>;
export interface GetServiceTokenRequest {
    /** The name of the organization */
    organization: string;
    /** The ID of the service token */
    id: string;
}
export declare const GetServiceTokenRequest: S.Schema<GetServiceTokenRequest>;
export interface GetSwitchoverRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the switchover */
    id: string;
}
export declare const GetSwitchoverRequest: S.Schema<GetSwitchoverRequest>;
export type GetTabletMetricsRequestMetricsItem = "replication_lag" | "vreplication_lag" | "pod_cpu_usage" | "pod_memory_usage" | "pod_queries" | "pod_rows_read" | "pod_iops" | "pod_ooms" | "primary_cpu_usage" | "primary_memory_usage" | "primary_iops" | "primary_queries" | "primary_rows_read" | "primary_rows_written" | "shard_storage_usage" | "shard_storage_available";
export declare const GetTabletMetricsRequestMetricsItem: any;
export type GetTabletMetricsRequestMetricsList = Array<GetTabletMetricsRequestMetricsItem | (string & {})>;
export declare const GetTabletMetricsRequestMetricsList: S.Schema<GetTabletMetricsRequestMetricsList>;
export type GetTabletMetricsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const GetTabletMetricsRequestPeriod: any;
export interface GetTabletMetricsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Metric names to retrieve. Pass as `metrics[]=name` (repeat for multiple), `metrics=name`, or a comma-separated list (`metrics=name,other`). Time range is `period` (for example `15m`) or ISO 8601 `from`/`to`. */
    metrics?: GetTabletMetricsRequestMetricsList;
    /** Named time period to retrieve. Defaults to 12h. */
    period?: GetTabletMetricsRequestPeriod | (string & {});
    /** Start of a custom time range as an ISO 8601 timestamp */
    from?: string;
    /** End of a custom time range as an ISO 8601 timestamp */
    to?: string;
    /** Number of data points to return */
    steps?: number;
    /** Filter by keyspace */
    keyspace?: string;
    /** Filter by shard */
    shard?: string;
    /** Filter by pod */
    pod?: string;
    /** Filter by workflow ID */
    workflow?: string;
}
export declare const GetTabletMetricsRequest: S.Schema<GetTabletMetricsRequest>;
export type GetTabletMetricsResponseSeriesList = Array<string>;
export declare const GetTabletMetricsResponseSeriesList: S.Schema<GetTabletMetricsResponseSeriesList>;
export interface GetTabletMetricsResponse {
    /** The metrics response type */
    type: string;
    /** The start of the time range */
    start_date: string;
    /** The end of the time range */
    end_date: string;
    /** The step interval in seconds between data points */
    interval: number;
    series: GetTabletMetricsResponseSeriesList;
}
export declare const GetTabletMetricsResponse: S.Schema<GetTabletMetricsResponse>;
export interface GetTrafficBudgetRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the traffic budget */
    id: string;
}
export declare const GetTrafficBudgetRequest: S.Schema<GetTrafficBudgetRequest>;
export interface GetWebhookRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the webhook */
    id: string;
}
export declare const GetWebhookRequest: S.Schema<GetWebhookRequest>;
export interface GetWorkflowRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const GetWorkflowRequest: S.Schema<GetWorkflowRequest>;
export interface LintBranchSchemaRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const LintBranchSchemaRequest: S.Schema<LintBranchSchemaRequest>;
/** The subject for the errors */
export type PaginatedSchemaLintErrorDataItemSubjectType = "table" | "vschema" | "routing_rules";
export declare const PaginatedSchemaLintErrorDataItemSubjectType: any;
/** A list of invalid foreign key columns in a table */
export type PaginatedSchemaLintErrorDataItemForeignKeyColumnNamesList = Array<string>;
export declare const PaginatedSchemaLintErrorDataItemForeignKeyColumnNamesList: S.Schema<PaginatedSchemaLintErrorDataItemForeignKeyColumnNamesList>;
/** A list of invalid auto-incremented columns */
export type PaginatedSchemaLintErrorDataItemAutoIncrementColumnNamesList = Array<string>;
export declare const PaginatedSchemaLintErrorDataItemAutoIncrementColumnNamesList: S.Schema<PaginatedSchemaLintErrorDataItemAutoIncrementColumnNamesList>;
export interface PaginatedSchemaLintErrorDataItem {
    /** Code representing the type of error */
    lint_error: string;
    /** The subject for the errors */
    subject_type: PaginatedSchemaLintErrorDataItemSubjectType;
    /** The keyspace of the schema with the error */
    keyspace_name: string;
    /** The table with the error */
    table_name: string;
    /** A description for the error that occurred */
    error_description: string;
    /** A link to the documentation related to the error */
    docs_url: string;
    /** The column in a table relevant to the error */
    column_name: string;
    /** A list of invalid foreign key columns in a table */
    foreign_key_column_names: PaginatedSchemaLintErrorDataItemForeignKeyColumnNamesList;
    /** A list of invalid auto-incremented columns */
    auto_increment_column_names: PaginatedSchemaLintErrorDataItemAutoIncrementColumnNamesList;
    /** The charset of the schema */
    charset_name: string;
    /** The engine of the schema */
    engine_name: string;
    /** The name of the vindex for the schema */
    vindex_name: string;
    /** The path for an invalid JSON column */
    json_path: string;
    /** The name of the invalid check constraint */
    check_constraint_name: string;
    /** The name of the invalid enum value */
    enum_value: string;
    /** The name of the invalid partitioning type */
    partitioning_type: string;
    /** The name of the invalid partition in the schema */
    partition_name: string;
}
export declare const PaginatedSchemaLintErrorDataItem: S.Schema<PaginatedSchemaLintErrorDataItem>;
export type PaginatedSchemaLintErrorDataList = Array<PaginatedSchemaLintErrorDataItem>;
export declare const PaginatedSchemaLintErrorDataList: S.Schema<PaginatedSchemaLintErrorDataList>;
export interface PaginatedSchemaLintError {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedSchemaLintErrorDataList;
}
export declare const PaginatedSchemaLintError: S.Schema<PaginatedSchemaLintError>;
export interface ListAuditLogsRequest {
    /** The name of the organization */
    organization: string;
    /** If provided, returns results after the specified cursor */
    starting_after?: string;
    /** If provided, returns results before the specified cursor */
    ending_before?: string;
    /** If provided, specifies the number of returned results (max 100) */
    limit?: number;
}
export declare const ListAuditLogsRequest: S.Schema<ListAuditLogsRequest>;
/** Additional metadata containing details about the change */
export type PaginatedAuditLogEventDataItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedAuditLogEventDataItemMetadataMap: S.Schema<PaginatedAuditLogEventDataItemMetadataMap>;
export interface PaginatedAuditLogEventDataItem {
    /** The ID for the audit log */
    id: string;
    /** The ID of the actor */
    actor_id: string | null;
    /** The type of the actor. Such as 'User' or 'ServiceToken' */
    actor_type: string | null;
    /** The ID of the auditable object */
    auditable_id: string | null;
    /** The type of the auditable. Such as 'Organization' or 'Database' */
    auditable_type: string | null;
    /** The ID of the target */
    target_id: string | null;
    /** The type of the target. Such as 'DatabaseBranch' or 'DatabaseBranchPassword' */
    target_type: string | null;
    /** The location of the actor based on their IP address */
    location: string | null;
    /** The name of the target */
    target_display_name: string | null;
    /** The action that was taken */
    audit_action: string;
    /** The action that was taken */
    action: string;
    /** The name of the actor */
    actor_display_name: string;
    /** The name of the auditable object */
    auditable_display_name: string;
    /** The IP address of the actor */
    remote_ip: string | null;
    /** When the audit log was created */
    created_at: string;
    /** When the audit log was last updated */
    updated_at: string;
    /** Additional metadata containing details about the change */
    metadata: PaginatedAuditLogEventDataItemMetadataMap | null;
}
export declare const PaginatedAuditLogEventDataItem: S.Schema<PaginatedAuditLogEventDataItem>;
export type PaginatedAuditLogEventDataList = Array<PaginatedAuditLogEventDataItem>;
export declare const PaginatedAuditLogEventDataList: S.Schema<PaginatedAuditLogEventDataList>;
export interface PaginatedAuditLogEvent {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** Whether there is a next page of results */
    has_next: boolean;
    /** Whether there is a previous page of results */
    has_prev: boolean;
    /** The ID of the first object in the current results, or null when there are no results */
    cursor_start: string | null;
    /** The ID of the last object in the current results, or null when there are no results */
    cursor_end: string | null;
    data: PaginatedAuditLogEventDataList;
}
export declare const PaginatedAuditLogEvent: S.Schema<PaginatedAuditLogEvent>;
export interface ListBackupPoliciesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBackupPoliciesRequest: S.Schema<ListBackupPoliciesRequest>;
/** Whether the policy is for production or development branches */
export type PaginatedBackupPolicyDataItemTarget = "production" | "development";
export declare const PaginatedBackupPolicyDataItemTarget: any;
export interface PaginatedBackupPolicyDataItem {
    /** The ID of the backup policy */
    id: string;
    /** The display name of the backup policy */
    display_name: string;
    /** The name of the backup policy */
    name: string;
    /** Whether the policy is for production or development branches */
    target: PaginatedBackupPolicyDataItemTarget;
    /** A number value for the retention period of the backup policy */
    retention_value: number;
    /** The unit for the retention period of the backup policy */
    retention_unit: string;
    /** A number value for the frequency of the backup policy */
    frequency_value: number;
    /** The unit for the frequency of the backup policy */
    frequency_unit: string;
    /** The time of day that the backup is scheduled, in HH:MM format */
    schedule_time: string;
    /** Day of the week that the backup is scheduled. 0 is Sunday, 6 is Saturday */
    schedule_day: number | null;
    /** Week of the month that the backup is scheduled. 0 is the first week, 3 is the fourth week */
    schedule_week: number | null;
    /** When the backup policy was created */
    created_at: string;
    /** When the backup policy was last updated */
    updated_at: string;
    /** When the backup was last run */
    last_ran_at: string | null;
    /** When the backup will next run */
    next_run_at: string | null;
    /** Whether the policy is a required system backup */
    required: boolean;
}
export declare const PaginatedBackupPolicyDataItem: S.Schema<PaginatedBackupPolicyDataItem>;
export type PaginatedBackupPolicyDataList = Array<PaginatedBackupPolicyDataItem>;
export declare const PaginatedBackupPolicyDataList: S.Schema<PaginatedBackupPolicyDataList>;
export interface PaginatedBackupPolicy {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedBackupPolicyDataList;
}
export declare const PaginatedBackupPolicy: S.Schema<PaginatedBackupPolicy>;
export type ListBackupsRequestState = "pending" | "running" | "success" | "failed" | "canceled" | "ignored";
export declare const ListBackupsRequestState: any;
export interface ListBackupsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** Whether to include all backups, including deleted ones */
    all?: boolean;
    /** Filter backups by state */
    state?: ListBackupsRequestState | (string & {});
    /** Filter backups by backup policy ID */
    policy?: string;
    /** Filter backups started after this date (e.g. 2023-01-01T00:00:00Z) */
    from?: string;
    /** Filter backups started before this date (e.g. 2023-01-31T23:59:59Z) */
    to?: string;
    /** Filter backups that are running during a specific time (e.g. 2023-01-01T00:00:00Z..2023-01-01T23:59:59Z) */
    running_at?: string;
    /** Filter backups by production branch */
    production?: boolean;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBackupsRequest: S.Schema<ListBackupsRequest>;
/** The current state of the backup */
export type PaginatedBackupDataItemState = "pending" | "running" | "success" | "failed" | "canceled" | "ignored";
export declare const PaginatedBackupDataItemState: any;
export type PaginatedBackupDataItemRestoredBranchesItem = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedBackupDataItemRestoredBranchesItem: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedBackupDataItemRestoredBranchesList = Array<OrganizationTeamMembershipUserDefaultOrganization>;
export declare const PaginatedBackupDataItemRestoredBranchesList: S.Schema<PaginatedBackupDataItemRestoredBranchesList>;
export type PaginatedBackupDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedBackupDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** Whether the policy is for production or development branches */
export type PaginatedBackupDataItemBackupPolicyTarget = "production" | "development";
export declare const PaginatedBackupDataItemBackupPolicyTarget: any;
export interface PaginatedBackupDataItemBackupPolicy {
    /** The ID of the backup policy */
    id: string;
    /** The display name of the backup policy */
    display_name: string;
    /** The name of the backup policy */
    name: string;
    /** Whether the policy is for production or development branches */
    target: PaginatedBackupDataItemBackupPolicyTarget;
    /** A number value for the retention period of the backup policy */
    retention_value: number;
    /** The unit for the retention period of the backup policy */
    retention_unit: string;
    /** A number value for the frequency of the backup policy */
    frequency_value: number;
    /** The unit for the frequency of the backup policy */
    frequency_unit: string;
    /** The time of day that the backup is scheduled, in HH:MM format */
    schedule_time: string | null;
    /** Day of the week that the backup is scheduled. 0 is Sunday, 6 is Saturday */
    schedule_day: number | null;
    /** Week of the month that the backup is scheduled. 0 is the first week, 3 is the fourth week */
    schedule_week: number | null;
    /** When the backup policy was created */
    created_at: string;
    /** When the backup policy was last updated */
    updated_at: string;
    /** When the backup was last run */
    last_ran_at: string | null;
    /** When the backup will next run */
    next_run_at: string | null;
    /** Whether the policy is a required system backup */
    required: boolean;
}
export declare const PaginatedBackupDataItemBackupPolicy: S.Schema<PaginatedBackupDataItemBackupPolicy>;
export type PaginatedBackupDataItemSchemaSnapshot = BackupSchemaSnapshot;
export declare const PaginatedBackupDataItemSchemaSnapshot: S.Schema<BackupSchemaSnapshot>;
export type PaginatedBackupDataItemDatabaseBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedBackupDataItemDatabaseBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface PaginatedBackupDataItem {
    /** The ID of the backup */
    id: string;
    /** The name of the backup */
    name: string;
    /** The current state of the backup */
    state: PaginatedBackupDataItemState;
    /** The size of the backup in bytes */
    size: number;
    /** The estimated storage cost of the backup */
    estimated_storage_cost: number;
    /** When the backup was created */
    created_at: string;
    /** When the backup was last updated */
    updated_at: string;
    /** When the backup started */
    started_at: string | null;
    /** When the backup expires */
    expires_at: string | null;
    /** When the backup completed */
    completed_at: string | null;
    /** When the backup was deleted */
    deleted_at: string | null;
    /** Size of the PVC used for the backup */
    pvc_size: number;
    /** The uncompressed (logical) size of the backup in bytes */
    uncompressed_size: number;
    /** Whether or not the backup is protected from deletion */
    protected: boolean;
    /** Whether or not the backup policy is required */
    required: boolean;
    restored_branches: PaginatedBackupDataItemRestoredBranchesList;
    actor: OrganizationTeamMembershipActor | null;
    backup_policy?: PaginatedBackupDataItemBackupPolicy | null;
    schema_snapshot?: BackupSchemaSnapshot | null;
    database_branch?: OrganizationTeamMembershipUserDefaultOrganization | null;
}
export declare const PaginatedBackupDataItem: S.Schema<PaginatedBackupDataItem>;
export type PaginatedBackupDataList = Array<PaginatedBackupDataItem>;
export declare const PaginatedBackupDataList: S.Schema<PaginatedBackupDataList>;
export interface PaginatedBackup {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedBackupDataList;
}
export declare const PaginatedBackup: S.Schema<PaginatedBackup>;
export interface ListBouncerResizeRequestsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the bouncer */
    bouncer: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBouncerResizeRequestsRequest: S.Schema<ListBouncerResizeRequestsRequest>;
/** The state of the bouncer resize */
export type PaginatedPostgresBouncerResizeRequestDataItemState = "pending" | "resizing" | "canceled" | "completed";
export declare const PaginatedPostgresBouncerResizeRequestDataItemState: any;
/** The backend target for the bouncer after the resize */
export type PaginatedPostgresBouncerResizeRequestDataItemTarget = "primary" | "replica" | "replica_az_affinity";
export declare const PaginatedPostgresBouncerResizeRequestDataItemTarget: any;
/** The bouncer parameters */
export type PaginatedPostgresBouncerResizeRequestDataItemParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedPostgresBouncerResizeRequestDataItemParametersMap: S.Schema<PaginatedPostgresBouncerResizeRequestDataItemParametersMap>;
/** The backend target for the bouncer before the resize */
export type PaginatedPostgresBouncerResizeRequestDataItemPreviousTarget = "primary" | "replica" | "replica_az_affinity";
export declare const PaginatedPostgresBouncerResizeRequestDataItemPreviousTarget: any;
/** The previous bouncer parameters */
export type PaginatedPostgresBouncerResizeRequestDataItemPreviousParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedPostgresBouncerResizeRequestDataItemPreviousParametersMap: S.Schema<PaginatedPostgresBouncerResizeRequestDataItemPreviousParametersMap>;
export type PaginatedPostgresBouncerResizeRequestDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresBouncerResizeRequestDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedPostgresBouncerResizeRequestDataItemBouncer = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedPostgresBouncerResizeRequestDataItemBouncer: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedPostgresBouncerResizeRequestDataItemSku = PostgresBouncerSku;
export declare const PaginatedPostgresBouncerResizeRequestDataItemSku: S.Schema<PostgresBouncerSku>;
export type PaginatedPostgresBouncerResizeRequestDataItemPreviousSku = PostgresBouncerSku;
export declare const PaginatedPostgresBouncerResizeRequestDataItemPreviousSku: S.Schema<PostgresBouncerSku>;
export interface PaginatedPostgresBouncerResizeRequestDataItem {
    /** The ID of the bouncer resize */
    id: string;
    /** The state of the bouncer resize */
    state: PaginatedPostgresBouncerResizeRequestDataItemState;
    /** The number of replicas per cell for the bouncer after the resize */
    replicas_per_cell: number;
    /** The backend target for the bouncer after the resize */
    target: PaginatedPostgresBouncerResizeRequestDataItemTarget;
    /** The bouncer parameters */
    parameters: PaginatedPostgresBouncerResizeRequestDataItemParametersMap;
    /** The number of replicas per cell for the bouncer before the resize */
    previous_replicas_per_cell: number;
    /** The backend target for the bouncer before the resize */
    previous_target: PaginatedPostgresBouncerResizeRequestDataItemPreviousTarget;
    /** The previous bouncer parameters */
    previous_parameters: PaginatedPostgresBouncerResizeRequestDataItemPreviousParametersMap;
    /** The time the bouncer resize started */
    started_at: string | null;
    /** The time the bouncer resize completed */
    completed_at: string | null;
    /** The time the bouncer resize was created */
    created_at: string;
    /** The time the bouncer resize was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
    bouncer: OrganizationTeamMembershipUserDefaultOrganization;
    sku: PostgresBouncerSku;
    previous_sku: PostgresBouncerSku;
}
export declare const PaginatedPostgresBouncerResizeRequestDataItem: S.Schema<PaginatedPostgresBouncerResizeRequestDataItem>;
export type PaginatedPostgresBouncerResizeRequestDataList = Array<PaginatedPostgresBouncerResizeRequestDataItem>;
export declare const PaginatedPostgresBouncerResizeRequestDataList: S.Schema<PaginatedPostgresBouncerResizeRequestDataList>;
export interface PaginatedPostgresBouncerResizeRequest {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPostgresBouncerResizeRequestDataList;
}
export declare const PaginatedPostgresBouncerResizeRequest: S.Schema<PaginatedPostgresBouncerResizeRequest>;
export interface ListBouncersRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBouncersRequest: S.Schema<ListBouncersRequest>;
export type PaginatedPostgresBouncerDataItemSku = PostgresBouncerSku;
export declare const PaginatedPostgresBouncerDataItemSku: S.Schema<PostgresBouncerSku>;
/** The instance type the bouncer targets */
export type PaginatedPostgresBouncerDataItemTarget = "primary" | "replica" | "replica_az_affinity";
export declare const PaginatedPostgresBouncerDataItemTarget: any;
export type PaginatedPostgresBouncerDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresBouncerDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedPostgresBouncerDataItemBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedPostgresBouncerDataItemBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
/** The namespace of the parameter */
export type PaginatedPostgresBouncerDataItemParametersItemNamespace = "pgbouncer";
export declare const PaginatedPostgresBouncerDataItemParametersItemNamespace: any;
/** The type of the parameter */
export type PaginatedPostgresBouncerDataItemParametersItemParameterType = "array" | "integer" | "seconds" | "select" | "string";
export declare const PaginatedPostgresBouncerDataItemParametersItemParameterType: any;
/** Valid options for the parameter value */
export type PaginatedPostgresBouncerDataItemParametersItemOptionsList = Array<string>;
export declare const PaginatedPostgresBouncerDataItemParametersItemOptionsList: S.Schema<PaginatedPostgresBouncerDataItemParametersItemOptionsList>;
export type PaginatedPostgresBouncerDataItemParametersItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresBouncerDataItemParametersItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedPostgresBouncerDataItemParametersItem {
    /** The ID of the parameter */
    id: string;
    /** The namespace of the parameter */
    namespace: PaginatedPostgresBouncerDataItemParametersItemNamespace;
    /** The name of the parameter */
    name: string;
    /** The display name of the parameter */
    display_name: string;
    /** The category of the parameter */
    category: string;
    /** The description of the parameter */
    description: string;
    /** Whether the parameter can be changed */
    immutable: boolean;
    /** The type of the parameter */
    parameter_type: PaginatedPostgresBouncerDataItemParametersItemParameterType;
    /** The default value of the parameter */
    default_value: string;
    /** The configured value of the parameter */
    value: string;
    /** Whether the parameter is required */
    required: boolean;
    /** When the parameter was created */
    created_at: string;
    /** When the parameter was last updated */
    updated_at: string;
    /** True if processes require a server restart on change */
    restart: boolean;
    /** The maximum value of the parameter */
    max: number;
    /** The minimum value of the parameter */
    min: number;
    /** The URL of the parameter */
    url: string;
    /** Valid options for the parameter value */
    options: PaginatedPostgresBouncerDataItemParametersItemOptionsList;
    actor: OrganizationTeamMembershipActor;
}
export declare const PaginatedPostgresBouncerDataItemParametersItem: S.Schema<PaginatedPostgresBouncerDataItemParametersItem>;
export type PaginatedPostgresBouncerDataItemParametersList = Array<PaginatedPostgresBouncerDataItemParametersItem>;
export declare const PaginatedPostgresBouncerDataItemParametersList: S.Schema<PaginatedPostgresBouncerDataItemParametersList>;
export interface PaginatedPostgresBouncerDataItem {
    /** The ID of the bouncer */
    id: string;
    /** The name of the bouncer */
    name: string;
    sku: PostgresBouncerSku;
    /** The instance type the bouncer targets */
    target: PaginatedPostgresBouncerDataItemTarget;
    /** The count of replicas in each cell */
    replicas_per_cell: number;
    /** When the bouncer was created */
    created_at: string;
    /** When the bouncer was updated */
    updated_at: string;
    /** When the bouncer was deleted */
    deleted_at: string | null;
    actor: OrganizationTeamMembershipActor;
    branch: OrganizationTeamMembershipUserDefaultOrganization;
    parameters: PaginatedPostgresBouncerDataItemParametersList;
}
export declare const PaginatedPostgresBouncerDataItem: S.Schema<PaginatedPostgresBouncerDataItem>;
export type PaginatedPostgresBouncerDataList = Array<PaginatedPostgresBouncerDataItem>;
export declare const PaginatedPostgresBouncerDataList: S.Schema<PaginatedPostgresBouncerDataList>;
export interface PaginatedPostgresBouncer {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPostgresBouncerDataList;
}
export declare const PaginatedPostgresBouncer: S.Schema<PaginatedPostgresBouncer>;
export type ListBranchAnomaliesRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListBranchAnomaliesRequestPeriod: any;
export interface ListBranchAnomaliesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Start time for filtering anomalies (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering anomalies (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering anomalies */
    period?: ListBranchAnomaliesRequestPeriod | (string & {});
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchAnomaliesRequest: S.Schema<ListBranchAnomaliesRequest>;
/** The tablet type the query ran against */
export type PaginatedAnomalyDataItemCorrelationsItemTabletType = "primary" | "replica" | "rdonly";
export declare const PaginatedAnomalyDataItemCorrelationsItemTabletType: any;
export interface PaginatedAnomalyDataItemCorrelationsItem {
    /** The ID of the correlation */
    id: string;
    /** The correlation coefficient between the query and the anomaly */
    r: number;
    /** The keyspace the query ran against */
    keyspace: string;
    /** The query fingerprint */
    fingerprint: string;
    /** The normalized SQL statement */
    normalized_sql: string;
    /** Syntax highlighted SQL statement */
    syntax_highlighted_sql: string;
    /** The tablet type the query ran against */
    tablet_type: PaginatedAnomalyDataItemCorrelationsItemTabletType;
}
export declare const PaginatedAnomalyDataItemCorrelationsItem: S.Schema<PaginatedAnomalyDataItemCorrelationsItem>;
export type PaginatedAnomalyDataItemCorrelationsList = Array<PaginatedAnomalyDataItemCorrelationsItem>;
export declare const PaginatedAnomalyDataItemCorrelationsList: S.Schema<PaginatedAnomalyDataItemCorrelationsList>;
export interface PaginatedAnomalyDataItem {
    /** The ID of the anomaly */
    id: string;
    /** When the anomaly started */
    period_start: string;
    /** When the anomaly ended */
    period_end: string;
    /** The number of minutes query latency was in violation of the expected baseline */
    minutes_in_violation: number;
    /** Whether the anomaly is ongoing */
    active: boolean;
    /** The duration of the anomaly in seconds */
    duration: number;
    /** Start of the metrics window surrounding the anomaly */
    metrics_start: string;
    /** End of the metrics window surrounding the anomaly */
    metrics_end: string;
    correlations?: PaginatedAnomalyDataItemCorrelationsList | null;
}
export declare const PaginatedAnomalyDataItem: S.Schema<PaginatedAnomalyDataItem>;
export type PaginatedAnomalyDataList = Array<PaginatedAnomalyDataItem>;
export declare const PaginatedAnomalyDataList: S.Schema<PaginatedAnomalyDataList>;
export interface PaginatedAnomaly {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedAnomalyDataList;
}
export declare const PaginatedAnomaly: S.Schema<PaginatedAnomaly>;
export interface ListBranchBouncerResizeRequestsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchBouncerResizeRequestsRequest: S.Schema<ListBranchBouncerResizeRequestsRequest>;
export interface ListBranchChangeRequestsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchChangeRequestsRequest: S.Schema<ListBranchChangeRequestsRequest>;
/** The state of the branch change request */
export type PaginatedPostgresClusterResizeRequestDataItemState = "queued" | "pending" | "resizing" | "canceled" | "completed";
export declare const PaginatedPostgresClusterResizeRequestDataItemState: any;
export type PaginatedPostgresClusterResizeRequestDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresClusterResizeRequestDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** The branch parameters */
export type PaginatedPostgresClusterResizeRequestDataItemParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedPostgresClusterResizeRequestDataItemParametersMap: S.Schema<PaginatedPostgresClusterResizeRequestDataItemParametersMap>;
/** The previous branch parameters */
export type PaginatedPostgresClusterResizeRequestDataItemPreviousParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedPostgresClusterResizeRequestDataItemPreviousParametersMap: S.Schema<PaginatedPostgresClusterResizeRequestDataItemPreviousParametersMap>;
/** The storage type (gp3 or io2) */
export type PaginatedPostgresClusterResizeRequestDataItemStorageType = "gp3" | "io2" | "pd_ssd" | "hyperdisk_balanced" | "premium_v2_lrs";
export declare const PaginatedPostgresClusterResizeRequestDataItemStorageType: any;
export interface PaginatedPostgresClusterResizeRequestDataItem {
    /** The ID of the branch change request */
    id: string;
    /** The state of the branch change request */
    state: PaginatedPostgresClusterResizeRequestDataItemState;
    /** The time the branch change request started */
    started_at: string | null;
    /** The time the branch change request completed */
    completed_at?: string | null;
    /** The time the branch change request was created */
    created_at: string;
    /** The time the branch change request was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
    /** The SKU representing the branch cluster */
    cluster_name: string;
    /** The SKU representing the branch cluster for display */
    cluster_display_name: string;
    /** Whether or not this is a metal database */
    cluster_metal: boolean;
    /** The total number of replicas */
    replicas: number;
    /** The PostgreSQL version after the change */
    version?: string;
    /** The branch parameters */
    parameters: PaginatedPostgresClusterResizeRequestDataItemParametersMap;
    /** The previous SKU representing the branch cluster */
    previous_cluster_name: string;
    /** The previous SKU representing the branch cluster for display */
    previous_cluster_display_name: string;
    /** Whether or not the previous SKU was a metal database */
    previous_cluster_metal: boolean;
    /** The previous total number of replicas */
    previous_replicas: number;
    /** The PostgreSQL version before the change */
    previous_version?: string;
    /** The previous branch parameters */
    previous_parameters: PaginatedPostgresClusterResizeRequestDataItemPreviousParametersMap;
    /** The minimum storage size in bytes */
    minimum_storage_bytes: number;
    /** The maximum storage size in bytes */
    maximum_storage_bytes: number;
    /** Whether storage autoscaling is enabled */
    storage_autoscaling: boolean;
    /** Whether storage shrinking is enabled when autoscaling is enabled */
    storage_shrinking: boolean;
    /** The storage type (gp3 or io2) */
    storage_type: PaginatedPostgresClusterResizeRequestDataItemStorageType;
    /** The storage IOPS */
    storage_iops: number;
    /** The storage throughput in MiB/s */
    storage_throughput_mibs: number;
    /** The previous minimum storage size in bytes */
    previous_minimum_storage_bytes: number;
    /** The previous maximum storage size in bytes */
    previous_maximum_storage_bytes: number;
    /** Whether storage autoscaling was previously enabled */
    previous_storage_autoscaling: boolean;
    /** Whether storage shrinking was previously enabled */
    previous_storage_shrinking: boolean;
    /** The previous storage type */
    previous_storage_type: string;
    /** The previous storage IOPS */
    previous_storage_iops: number;
    /** The previous storage throughput in MiB/s */
    previous_storage_throughput_mibs: number;
    /** Whether the change re-applies the current minimum disk size to shrink the provisioned disk */
    confirm_shrink?: boolean;
}
export declare const PaginatedPostgresClusterResizeRequestDataItem: S.Schema<PaginatedPostgresClusterResizeRequestDataItem>;
export type PaginatedPostgresClusterResizeRequestDataList = Array<PaginatedPostgresClusterResizeRequestDataItem>;
export declare const PaginatedPostgresClusterResizeRequestDataList: S.Schema<PaginatedPostgresClusterResizeRequestDataList>;
export interface PaginatedPostgresClusterResizeRequest {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPostgresClusterResizeRequestDataList;
}
export declare const PaginatedPostgresClusterResizeRequest: S.Schema<PaginatedPostgresClusterResizeRequest>;
export type ListBranchesRequestOrder = "asc" | "desc";
export declare const ListBranchesRequestOrder: any;
export interface ListBranchesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Search branches by name */
    q?: string;
    /** Filter branches by production status */
    production?: boolean;
    /** Filter branches by safe migrations (DDL protection) */
    safe_migrations?: boolean;
    /** Order branches by created_at time */
    order?: ListBranchesRequestOrder | (string & {});
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchesRequest: S.Schema<ListBranchesRequest>;
/** The kind of branch */
export type PaginatedDatabaseBranchDataItemKind = "mysql" | "postgresql";
export declare const PaginatedDatabaseBranchDataItemKind: any;
/** The current state of the branch */
export type PaginatedDatabaseBranchDataItemState = "pending" | "sleep_in_progress" | "sleeping" | "awakening" | "ready";
export declare const PaginatedDatabaseBranchDataItemState: any;
export type PaginatedDatabaseBranchDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseBranchDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDatabaseBranchDataItemRestoredFromBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedDatabaseBranchDataItemRestoredFromBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
/** Public IP addresses for the region */
export type PaginatedDatabaseBranchDataItemRegionPublicIpAddressesList = Array<string>;
export declare const PaginatedDatabaseBranchDataItemRegionPublicIpAddressesList: S.Schema<PaginatedDatabaseBranchDataItemRegionPublicIpAddressesList>;
export interface PaginatedDatabaseBranchDataItemRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PaginatedDatabaseBranchDataItemRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PaginatedDatabaseBranchDataItemRegion: S.Schema<PaginatedDatabaseBranchDataItemRegion>;
/** VTGate configuration options */
export type PaginatedDatabaseBranchDataItemVtgateOptionsMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseBranchDataItemVtgateOptionsMap: S.Schema<PaginatedDatabaseBranchDataItemVtgateOptionsMap>;
export interface PaginatedDatabaseBranchDataItem {
    /** The ID of the branch */
    id: string;
    /** The name of the branch */
    name: string;
    /** When the branch was created */
    created_at: string;
    /** When the branch was last updated */
    updated_at: string;
    /** When the branch was deleted */
    deleted_at: string | null;
    /** When a user last marked a backup restore checklist as completed */
    restore_checklist_completed_at: string | null;
    /** When the schema for the branch was last updated */
    schema_last_updated_at: string | null;
    /** The kind of branch */
    kind: PaginatedDatabaseBranchDataItemKind;
    /** The MySQL address for the branch */
    mysql_address?: string;
    /** The address of the MySQL provider for the branch */
    mysql_edge_address?: string;
    /** The current state of the branch */
    state: PaginatedDatabaseBranchDataItemState;
    /** True if the branch allows passwords to connect directly to a vtgate, bypassing load balancers */
    direct_vtgate?: boolean;
    /** The size of the vtgate cluster for the branch */
    vtgate_size?: string;
    /** The public SKU representing the VTGate size */
    vtgate_name?: string | null;
    /** The number of vtgate instances in the branch */
    vtgate_count?: number;
    /** Whether VTGate autoscaling is enabled */
    vtgate_autoscaling?: boolean;
    /** The maximum number of VTGate instances when autoscaling is enabled */
    vtgate_max_count?: number | null;
    /** The target CPU utilization for VTGate autoscaling */
    vtgate_target_cpu_utilization?: number | null;
    /** The SKU representing the branch's cluster size */
    cluster_name: string;
    /** IOPS for the cluster */
    cluster_iops: number | null;
    /** Whether or not the branch is ready to serve queries */
    ready: boolean;
    /** Whether or not the schema is ready for queries */
    schema_ready?: boolean;
    /** Whether or not this is a metal database */
    metal: boolean;
    /** Whether or not the branch is a production branch */
    production: boolean;
    /** Whether or not the branch has safe migrations enabled */
    safe_migrations: boolean;
    /** Whether deletion protection is enabled for the branch */
    deletion_protected?: boolean;
    /** Whether or not the branch is sharded */
    sharded?: boolean;
    /** The number of shards in the branch */
    shard_count?: number;
    /** The number of keyspaces in the branch */
    keyspace_count?: number;
    /** Whether or not the branch has a stale schema */
    stale_schema: boolean;
    actor: OrganizationTeamMembershipActor | null;
    restored_from_branch: OrganizationTeamMembershipUserDefaultOrganization | null;
    /** True if private connections are enabled */
    private_edge_connectivity: boolean;
    /** True if the branch has replica servers */
    has_replicas: boolean;
    /** True if the branch has read-only replica servers */
    has_read_only_replicas: boolean;
    /** Planetscale app URL for the branch */
    html_url: string;
    /** Planetscale API URL for the branch */
    url: string;
    region: PaginatedDatabaseBranchDataItemRegion;
    /** The name of the parent branch from which the branch was created */
    parent_branch: string | null;
    /** VTGate configuration options */
    vtgate_options?: PaginatedDatabaseBranchDataItemVtgateOptionsMap;
    cluster_architecture?: string;
}
export declare const PaginatedDatabaseBranchDataItem: S.Schema<PaginatedDatabaseBranchDataItem>;
export type PaginatedDatabaseBranchDataList = Array<PaginatedDatabaseBranchDataItem>;
export declare const PaginatedDatabaseBranchDataList: S.Schema<PaginatedDatabaseBranchDataList>;
export interface PaginatedDatabaseBranch {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedDatabaseBranchDataList;
}
export declare const PaginatedDatabaseBranch: S.Schema<PaginatedDatabaseBranch>;
export type ListBranchQueriesRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListBranchQueriesRequestPeriod: any;
export type ListBranchQueriesRequestSort = "keyspace" | "query" | "lastRun" | "count" | "errorCount" | "rowsRead" | "rowsAffected" | "rowsReturned" | "rowsReadPerReturned" | "rowsReadPerQuery" | "rowsReturnedPerQuery" | "rowsAffectedPerQuery" | "totalTime" | "cpuTime" | "ioTime" | "sumShardQueries" | "maxShardQueries" | "avgShardQueries" | "avgParallelWorkers" | "table" | "qualifiedTable" | "tableKeyspace" | "indexes" | "routingIndexes" | "p50Latency" | "p99Latency" | "maxLatency" | "percentTime" | "percentCpuTime" | "percentIoTime" | "egressBytes" | "egressBytesPerQuery" | "maxEgressBytes" | "ingressBytes" | "ingressBytesPerQuery" | "maxIngressBytes" | "blocksRead" | "blocksHit" | "blockCacheHitRatio" | "blocksDirtied" | "blocksWritten" | "trafficControlWarnings" | "trafficControlThrottled" | "trafficControlChecked" | "trafficControlBudgetsUsed";
export declare const ListBranchQueriesRequestSort: any;
export type ListBranchQueriesRequestDir = "asc" | "desc";
export declare const ListBranchQueriesRequestDir: any;
export type ListBranchQueriesRequestTabletType = "primary" | "replica" | "rdonly";
export declare const ListBranchQueriesRequestTabletType: any;
export type ListBranchQueriesRequestType = "SELECT" | "INSERT" | "UPDATE" | "DELETE";
export declare const ListBranchQueriesRequestType: any;
export type ListBranchQueriesRequestFieldsList = Array<string>;
export declare const ListBranchQueriesRequestFieldsList: S.Schema<ListBranchQueriesRequestFieldsList>;
export interface ListBranchQueriesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Search query statistics by SQL pattern */
    q?: string;
    /** Start time for filtering query statistics (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering query statistics (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering query statistics */
    period?: ListBranchQueriesRequestPeriod | (string & {});
    /** Field to sort by */
    sort?: ListBranchQueriesRequestSort | (string & {});
    /** Sort direction */
    dir?: ListBranchQueriesRequestDir | (string & {});
    /** Filter by tablet type */
    tablet_type?: ListBranchQueriesRequestTabletType | (string & {});
    /** Filter by statement type */
    type?: ListBranchQueriesRequestType | (string & {});
    /** Specific fields to include in the response */
    fields?: ListBranchQueriesRequestFieldsList;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchQueriesRequest: S.Schema<ListBranchQueriesRequest>;
/** Tables accessed by the query */
export type PaginatedQuerySummaryDataItemTablesList = Array<string>;
export declare const PaginatedQuerySummaryDataItemTablesList: S.Schema<PaginatedQuerySummaryDataItemTablesList>;
/** Fully qualified tables accessed by the query */
export type PaginatedQuerySummaryDataItemQualifiedTablesList = Array<string>;
export declare const PaginatedQuerySummaryDataItemQualifiedTablesList: S.Schema<PaginatedQuerySummaryDataItemQualifiedTablesList>;
export type PaginatedQuerySummaryDataItemTableKeyspacesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedQuerySummaryDataItemTableKeyspacesItemMap: S.Schema<PaginatedQuerySummaryDataItemTableKeyspacesItemMap>;
/** Mapping of tables to their keyspaces */
export type PaginatedQuerySummaryDataItemTableKeyspacesList = Array<PaginatedQuerySummaryDataItemTableKeyspacesItemMap>;
export declare const PaginatedQuerySummaryDataItemTableKeyspacesList: S.Schema<PaginatedQuerySummaryDataItemTableKeyspacesList>;
export type PaginatedQuerySummaryDataItemIndexUsagesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedQuerySummaryDataItemIndexUsagesItemMap: S.Schema<PaginatedQuerySummaryDataItemIndexUsagesItemMap>;
/** Index usage information */
export type PaginatedQuerySummaryDataItemIndexUsagesList = Array<PaginatedQuerySummaryDataItemIndexUsagesItemMap>;
export declare const PaginatedQuerySummaryDataItemIndexUsagesList: S.Schema<PaginatedQuerySummaryDataItemIndexUsagesList>;
export type PaginatedQuerySummaryDataItemRoutingIndexUsagesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedQuerySummaryDataItemRoutingIndexUsagesItemMap: S.Schema<PaginatedQuerySummaryDataItemRoutingIndexUsagesItemMap>;
/** Routing index usage information */
export type PaginatedQuerySummaryDataItemRoutingIndexUsagesList = Array<PaginatedQuerySummaryDataItemRoutingIndexUsagesItemMap>;
export declare const PaginatedQuerySummaryDataItemRoutingIndexUsagesList: S.Schema<PaginatedQuerySummaryDataItemRoutingIndexUsagesList>;
export interface PaginatedQuerySummaryDataItem {
    /** The ID of the query summary */
    id: string;
    /** The query fingerprint */
    fingerprint: string;
    /** The type of SQL statement */
    statement_type: string;
    /** The keyspace the query ran against */
    keyspace: string;
    /** The normalized SQL statement */
    normalized_sql: string;
    /** Syntax highlighted SQL statement */
    syntax_highlighted_sql: string;
    /** Whether the query is a multishard query */
    multishard: boolean;
    /** The number of times this query was executed */
    query_count: number;
    /** The number of times this query resulted in an error */
    error_count: number;
    /** Tables accessed by the query */
    tables: PaginatedQuerySummaryDataItemTablesList;
    /** Fully qualified tables accessed by the query */
    qualified_tables: PaginatedQuerySummaryDataItemQualifiedTablesList;
    /** Mapping of tables to their keyspaces */
    table_keyspaces: PaginatedQuerySummaryDataItemTableKeyspacesList;
    /** Index usage information */
    index_usages: PaginatedQuerySummaryDataItemIndexUsagesList;
    /** Routing index usage information */
    routing_index_usages: PaginatedQuerySummaryDataItemRoutingIndexUsagesList;
    /** The total number of shard queries */
    sum_shard_queries: number;
    /** The maximum number of shard queries for a single execution */
    max_shard_queries: number;
    /** The average number of shard queries */
    avg_shard_queries: number;
    /** The average number of parallel workers */
    avg_parallel_workers: number;
    /** The total number of rows read */
    sum_rows_read: number;
    /** The total number of rows affected */
    sum_rows_affected: number;
    /** The total number of rows returned */
    sum_rows_returned: number;
    /** Average rows read per row returned */
    rows_read_per_returned: number;
    /** Average rows read per query */
    rows_read_per_query: number;
    /** Average rows returned per query */
    rows_returned_per_query: number;
    /** Average rows affected per query */
    rows_affected_per_query: number;
    /** Total duration in milliseconds across all executions */
    sum_total_duration_millis: number;
    /** Percentage of total query time */
    sum_total_duration_percent: number;
    /** Total CPU duration in milliseconds */
    sum_cpu_duration_millis: number;
    /** Percentage of total CPU time */
    sum_cpu_duration_percent: number;
    /** Total IO duration in milliseconds */
    sum_io_duration_millis: number;
    /** Percentage of total IO time */
    sum_io_duration_percent: number;
    /** When this query was last executed */
    last_run_at: string | null;
    /** Average time per query execution */
    time_per_query: number;
    /** 50th percentile latency */
    p50_latency: number;
    /** 99th percentile latency */
    p99_latency: number;
    /** Maximum latency observed */
    max_latency: number;
    /** Total egress bytes */
    egress_bytes: number;
    /** Average egress bytes per query */
    egress_bytes_per_query: number;
    /** Maximum egress bytes for a single execution */
    max_egress_bytes: number;
    /** Total ingress bytes */
    ingress_bytes: number;
    /** Average ingress bytes per query */
    ingress_bytes_per_query: number;
    /** Maximum ingress bytes for a single execution */
    max_ingress_bytes: number;
    /** Total blocks read from disk */
    blocks_read: number;
    /** Total blocks found in cache */
    blocks_hit: number;
    /** Cache hit ratio for blocks */
    block_cache_hit_ratio: number;
    /** Total blocks dirtied */
    blocks_dirtied: number;
    /** Total blocks written */
    blocks_written: number;
    /** The number of executions that triggered a traffic control warning */
    traffic_control_warnings: number;
    /** The number of executions throttled by traffic control */
    traffic_control_throttled: number;
    /** The number of executions checked by traffic control rules */
    traffic_control_checked: number;
}
export declare const PaginatedQuerySummaryDataItem: S.Schema<PaginatedQuerySummaryDataItem>;
export type PaginatedQuerySummaryDataList = Array<PaginatedQuerySummaryDataItem>;
export declare const PaginatedQuerySummaryDataList: S.Schema<PaginatedQuerySummaryDataList>;
export interface PaginatedQuerySummary {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedQuerySummaryDataList;
}
export declare const PaginatedQuerySummary: S.Schema<PaginatedQuerySummary>;
export type ListBranchQueryErrorsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListBranchQueryErrorsRequestPeriod: any;
export type ListBranchQueryErrorsRequestSort = "error" | "lastRun" | "count" | "totalTime" | "timePerQuery";
export declare const ListBranchQueryErrorsRequestSort: any;
export type ListBranchQueryErrorsRequestDir = "asc" | "desc";
export declare const ListBranchQueryErrorsRequestDir: any;
export type ListBranchQueryErrorsRequestTabletType = "primary" | "replica" | "rdonly";
export declare const ListBranchQueryErrorsRequestTabletType: any;
export interface ListBranchQueryErrorsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Search query errors by error message */
    q?: string;
    /** Start time for filtering query errors (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering query errors (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering query errors */
    period?: ListBranchQueryErrorsRequestPeriod | (string & {});
    /** Field to sort by */
    sort?: ListBranchQueryErrorsRequestSort | (string & {});
    /** Sort direction */
    dir?: ListBranchQueryErrorsRequestDir | (string & {});
    /** Filter by tablet type */
    tablet_type?: ListBranchQueryErrorsRequestTabletType | (string & {});
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchQueryErrorsRequest: S.Schema<ListBranchQueryErrorsRequest>;
export interface PaginatedErrorSummaryDataItem {
    /** The ID of the error summary */
    id: string;
    /** The error fingerprint */
    error_fingerprint: string;
    /** When the error last occurred */
    started_at: string;
    /** Total duration in milliseconds across all failed executions */
    total_duration_millis: number;
    /** Average duration per failed execution in milliseconds */
    time_per_query: number;
    /** The number of times the error occurred */
    error_count: number;
    /** The error message */
    error_message: string;
}
export declare const PaginatedErrorSummaryDataItem: S.Schema<PaginatedErrorSummaryDataItem>;
export type PaginatedErrorSummaryDataList = Array<PaginatedErrorSummaryDataItem>;
export declare const PaginatedErrorSummaryDataList: S.Schema<PaginatedErrorSummaryDataList>;
export interface PaginatedErrorSummary {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedErrorSummaryDataList;
}
export declare const PaginatedErrorSummary: S.Schema<PaginatedErrorSummary>;
export type ListBranchQueryTagsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListBranchQueryTagsRequestPeriod: any;
export type ListBranchQueryTagsRequestTabletType = "primary" | "replica" | "rdonly";
export declare const ListBranchQueryTagsRequestTabletType: any;
export interface ListBranchQueryTagsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Search tags by name */
    q?: string;
    /** Start time for filtering tags (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering tags (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering tags */
    period?: ListBranchQueryTagsRequestPeriod | (string & {});
    /** Filter to tags on queries with this fingerprint */
    fingerprint?: string;
    /** Filter by keyspace */
    keyspace?: string;
    /** Filter by tablet type */
    tablet_type?: ListBranchQueryTagsRequestTabletType | (string & {});
    /** Maximum number of values returned per tag (1-100) */
    values_limit?: number;
    /** Only return literal tag values, excluding overflow and collapsed values */
    literal_values_only?: boolean;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchQueryTagsRequest: S.Schema<ListBranchQueryTagsRequest>;
/** The source of the tag */
export type PaginatedQueryTagDataItemSource = "sql" | "system";
export declare const PaginatedQueryTagDataItemSource: any;
/** The kind of tag value */
export type PaginatedQueryTagDataItemValuesItemKind = "literal" | "overflow" | "collapsed";
export declare const PaginatedQueryTagDataItemValuesItemKind: any;
export interface PaginatedQueryTagDataItemValuesItem {
    /** The name of the tag value */
    name: string;
    /** The number of queries that have this tag value */
    query_count: number;
    /** The kind of tag value */
    kind: PaginatedQueryTagDataItemValuesItemKind;
}
export declare const PaginatedQueryTagDataItemValuesItem: S.Schema<PaginatedQueryTagDataItemValuesItem>;
export type PaginatedQueryTagDataItemValuesList = Array<PaginatedQueryTagDataItemValuesItem>;
export declare const PaginatedQueryTagDataItemValuesList: S.Schema<PaginatedQueryTagDataItemValuesList>;
export interface PaginatedQueryTagDataItem {
    /** The ID of the tag */
    id: string;
    /** The name of the tag */
    name: string;
    /** The source of the tag */
    source: PaginatedQueryTagDataItemSource;
    /** The number of queries that have this tag */
    query_count: number;
    values: PaginatedQueryTagDataItemValuesList;
}
export declare const PaginatedQueryTagDataItem: S.Schema<PaginatedQueryTagDataItem>;
export type PaginatedQueryTagDataList = Array<PaginatedQueryTagDataItem>;
export declare const PaginatedQueryTagDataList: S.Schema<PaginatedQueryTagDataList>;
export interface PaginatedQueryTag {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedQueryTagDataList;
}
export declare const PaginatedQueryTag: S.Schema<PaginatedQueryTag>;
export type ListBranchQueryTagSummariesRequestTagsList = Array<string>;
export declare const ListBranchQueryTagSummariesRequestTagsList: S.Schema<ListBranchQueryTagSummariesRequestTagsList>;
export type ListBranchQueryTagSummariesRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListBranchQueryTagSummariesRequestPeriod: any;
export type ListBranchQueryTagSummariesRequestSort = "dimensions" | "lastRun" | "count" | "errorCount" | "rowsRead" | "rowsAffected" | "rowsReturned" | "rowsReadPerReturned" | "rowsReadPerQuery" | "rowsReturnedPerQuery" | "rowsAffectedPerQuery" | "totalTime" | "cpuTime" | "ioTime" | "sumShardQueries" | "maxShardQueries" | "avgShardQueries" | "avgParallelWorkers" | "table" | "qualifiedTable" | "tableKeyspace" | "indexes" | "routingIndexes" | "p50Latency" | "p99Latency" | "maxLatency" | "percentTime" | "percentCpuTime" | "percentIoTime" | "egressBytes" | "egressBytesPerQuery" | "maxEgressBytes" | "ingressBytes" | "ingressBytesPerQuery" | "maxIngressBytes" | "blocksRead" | "blocksHit" | "blockCacheHitRatio" | "blocksDirtied" | "blocksWritten" | "trafficControlWarnings" | "trafficControlThrottled" | "trafficControlChecked" | "trafficControlBudgetsUsed";
export declare const ListBranchQueryTagSummariesRequestSort: any;
export type ListBranchQueryTagSummariesRequestDir = "asc" | "desc";
export declare const ListBranchQueryTagSummariesRequestDir: any;
export type ListBranchQueryTagSummariesRequestTabletType = "primary" | "replica" | "rdonly";
export declare const ListBranchQueryTagSummariesRequestTabletType: any;
export type ListBranchQueryTagSummariesRequestType = "SELECT" | "INSERT" | "UPDATE" | "DELETE";
export declare const ListBranchQueryTagSummariesRequestType: any;
export type ListBranchQueryTagSummariesRequestFieldsList = Array<string>;
export declare const ListBranchQueryTagSummariesRequestFieldsList: S.Schema<ListBranchQueryTagSummariesRequestFieldsList>;
export interface ListBranchQueryTagSummariesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Tag ids returned by the tags list endpoint */
    tags?: ListBranchQueryTagSummariesRequestTagsList;
    /** Search query statistics by SQL pattern */
    q?: string;
    /** Start time for filtering query statistics (ISO 8601 timestamp) */
    from?: string;
    /** End time for filtering query statistics (ISO 8601 timestamp) */
    to?: string;
    /** Time period for filtering query statistics */
    period?: ListBranchQueryTagSummariesRequestPeriod | (string & {});
    /** Field to sort by */
    sort?: ListBranchQueryTagSummariesRequestSort | (string & {});
    /** Sort direction */
    dir?: ListBranchQueryTagSummariesRequestDir | (string & {});
    /** Filter by tablet type */
    tablet_type?: ListBranchQueryTagSummariesRequestTabletType | (string & {});
    /** Filter by statement type */
    type?: ListBranchQueryTagSummariesRequestType | (string & {});
    /** Specific fields to include in the response */
    fields?: ListBranchQueryTagSummariesRequestFieldsList;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchQueryTagSummariesRequest: S.Schema<ListBranchQueryTagSummariesRequest>;
/** The tag names and values this summary is grouped by */
export type PaginatedDimensionsQuerySummaryDataItemDimensionsMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDimensionsQuerySummaryDataItemDimensionsMap: S.Schema<PaginatedDimensionsQuerySummaryDataItemDimensionsMap>;
/** Tables accessed by the query */
export type PaginatedDimensionsQuerySummaryDataItemTablesList = Array<string>;
export declare const PaginatedDimensionsQuerySummaryDataItemTablesList: S.Schema<PaginatedDimensionsQuerySummaryDataItemTablesList>;
/** Fully qualified tables accessed by the query */
export type PaginatedDimensionsQuerySummaryDataItemQualifiedTablesList = Array<string>;
export declare const PaginatedDimensionsQuerySummaryDataItemQualifiedTablesList: S.Schema<PaginatedDimensionsQuerySummaryDataItemQualifiedTablesList>;
export type PaginatedDimensionsQuerySummaryDataItemTableKeyspacesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDimensionsQuerySummaryDataItemTableKeyspacesItemMap: S.Schema<PaginatedDimensionsQuerySummaryDataItemTableKeyspacesItemMap>;
/** Mapping of tables to their keyspaces */
export type PaginatedDimensionsQuerySummaryDataItemTableKeyspacesList = Array<PaginatedDimensionsQuerySummaryDataItemTableKeyspacesItemMap>;
export declare const PaginatedDimensionsQuerySummaryDataItemTableKeyspacesList: S.Schema<PaginatedDimensionsQuerySummaryDataItemTableKeyspacesList>;
export type PaginatedDimensionsQuerySummaryDataItemIndexUsagesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDimensionsQuerySummaryDataItemIndexUsagesItemMap: S.Schema<PaginatedDimensionsQuerySummaryDataItemIndexUsagesItemMap>;
/** Index usage information */
export type PaginatedDimensionsQuerySummaryDataItemIndexUsagesList = Array<PaginatedDimensionsQuerySummaryDataItemIndexUsagesItemMap>;
export declare const PaginatedDimensionsQuerySummaryDataItemIndexUsagesList: S.Schema<PaginatedDimensionsQuerySummaryDataItemIndexUsagesList>;
export type PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesItemMap: S.Schema<PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesItemMap>;
/** Routing index usage information */
export type PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesList = Array<PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesItemMap>;
export declare const PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesList: S.Schema<PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesList>;
export interface PaginatedDimensionsQuerySummaryDataItem {
    /** The tag names and values this summary is grouped by */
    dimensions: PaginatedDimensionsQuerySummaryDataItemDimensionsMap;
    /** The number of times this query was executed */
    query_count: number;
    /** The number of times this query resulted in an error */
    error_count: number;
    /** Tables accessed by the query */
    tables: PaginatedDimensionsQuerySummaryDataItemTablesList;
    /** Fully qualified tables accessed by the query */
    qualified_tables: PaginatedDimensionsQuerySummaryDataItemQualifiedTablesList;
    /** Mapping of tables to their keyspaces */
    table_keyspaces: PaginatedDimensionsQuerySummaryDataItemTableKeyspacesList;
    /** Index usage information */
    index_usages: PaginatedDimensionsQuerySummaryDataItemIndexUsagesList;
    /** Routing index usage information */
    routing_index_usages: PaginatedDimensionsQuerySummaryDataItemRoutingIndexUsagesList;
    /** The total number of shard queries */
    sum_shard_queries: number;
    /** The maximum number of shard queries for a single execution */
    max_shard_queries: number;
    /** The average number of shard queries */
    avg_shard_queries: number;
    /** The average number of parallel workers */
    avg_parallel_workers: number;
    /** The total number of rows read */
    sum_rows_read: number;
    /** The total number of rows affected */
    sum_rows_affected: number;
    /** The total number of rows returned */
    sum_rows_returned: number;
    /** Average rows read per row returned */
    rows_read_per_returned: number;
    /** Average rows read per query */
    rows_read_per_query: number;
    /** Average rows returned per query */
    rows_returned_per_query: number;
    /** Average rows affected per query */
    rows_affected_per_query: number;
    /** Total duration in milliseconds across all executions */
    sum_total_duration_millis: number;
    /** Percentage of total query time */
    sum_total_duration_percent: number;
    /** Total CPU duration in milliseconds */
    sum_cpu_duration_millis: number;
    /** Percentage of total CPU time */
    sum_cpu_duration_percent: number;
    /** Total IO duration in milliseconds */
    sum_io_duration_millis: number;
    /** Percentage of total IO time */
    sum_io_duration_percent: number;
    /** When this query was last executed */
    last_run_at: string | null;
    /** Average time per query execution */
    time_per_query: number;
    /** 50th percentile latency */
    p50_latency: number;
    /** 99th percentile latency */
    p99_latency: number;
    /** Maximum latency observed */
    max_latency: number;
    /** Total egress bytes */
    egress_bytes: number;
    /** Average egress bytes per query */
    egress_bytes_per_query: number;
    /** Maximum egress bytes for a single execution */
    max_egress_bytes: number;
    /** Total ingress bytes */
    ingress_bytes: number;
    /** Average ingress bytes per query */
    ingress_bytes_per_query: number;
    /** Maximum ingress bytes for a single execution */
    max_ingress_bytes: number;
    /** Total blocks read from disk */
    blocks_read: number;
    /** Total blocks found in cache */
    blocks_hit: number;
    /** Cache hit ratio for blocks */
    block_cache_hit_ratio: number;
    /** Total blocks dirtied */
    blocks_dirtied: number;
    /** Total blocks written */
    blocks_written: number;
    /** The number of executions that triggered a traffic control warning */
    traffic_control_warnings: number;
    /** The number of executions throttled by traffic control */
    traffic_control_throttled: number;
    /** The number of executions checked by traffic control rules */
    traffic_control_checked: number;
}
export declare const PaginatedDimensionsQuerySummaryDataItem: S.Schema<PaginatedDimensionsQuerySummaryDataItem>;
export type PaginatedDimensionsQuerySummaryDataList = Array<PaginatedDimensionsQuerySummaryDataItem>;
export declare const PaginatedDimensionsQuerySummaryDataList: S.Schema<PaginatedDimensionsQuerySummaryDataList>;
export interface PaginatedDimensionsQuerySummary {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDimensionsQuerySummaryDataList;
}
export declare const PaginatedDimensionsQuerySummary: S.Schema<PaginatedDimensionsQuerySummary>;
export interface ListBranchResizeRequestsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListBranchResizeRequestsRequest: S.Schema<ListBranchResizeRequestsRequest>;
/** The state of the branch resize request */
export type PaginatedMysqlClusterResizeRequestDataItemState = "pending" | "resizing" | "canceled" | "completed" | "queued";
export declare const PaginatedMysqlClusterResizeRequestDataItemState: any;
export type PaginatedMysqlClusterResizeRequestDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedMysqlClusterResizeRequestDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedMysqlClusterResizeRequestDataItem {
    /** The ID of the branch resize request */
    id: string;
    /** The state of the branch resize request */
    state: PaginatedMysqlClusterResizeRequestDataItemState;
    /** When the branch resize request started */
    started_at: string | null;
    /** When the branch resize request completed */
    completed_at: string | null;
    /** When the branch resize request was created */
    created_at: string;
    /** When the branch resize request was last updated */
    updated_at: string;
    /** The size of the vtgate cluster */
    vtgate_size: string;
    /** The previous size of the vtgate cluster */
    previous_vtgate_size: string;
    /** The number of vtgates in an availability zone */
    vtgate_count: number;
    /** The previous number of vtgates in the availability zone */
    previous_vtgate_count: number;
    /** The maximum number of vtgates in an availability zone when autoscaling is enabled */
    vtgate_max_count: number;
    /** The previous maximum number of vtgates in the availability zone when autoscaling is enabled */
    previous_vtgate_max_count: number;
    /** If autoscaling is enabled for the vtgate cluster */
    vtgate_autoscaling: boolean;
    /** The previous autoscaling setting for the vtgate cluster */
    previous_vtgate_autoscaling: boolean;
    /** The target CPU utilization for the vtgate cluster */
    vtgate_target_cpu_utilization: number;
    /** The previous target CPU utilization for the vtgate cluster */
    previous_vtgate_target_cpu_utilization: number;
    /** The SKU representing the vtgate cluster size: VTG_5, VTG_10,… */
    vtgate_name: string;
    /** The SKU representing the vtgate cluster size for display */
    vtgate_display_name: string;
    /** The previous SKU representing the vtgate cluster size */
    previous_vtgate_name: string;
    /** The previous SKU representing the vtgate cluster size for display */
    previous_vtgate_display_name: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const PaginatedMysqlClusterResizeRequestDataItem: S.Schema<PaginatedMysqlClusterResizeRequestDataItem>;
export type PaginatedMysqlClusterResizeRequestDataList = Array<PaginatedMysqlClusterResizeRequestDataItem>;
export declare const PaginatedMysqlClusterResizeRequestDataList: S.Schema<PaginatedMysqlClusterResizeRequestDataList>;
export interface PaginatedMysqlClusterResizeRequest {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedMysqlClusterResizeRequestDataList;
}
export declare const PaginatedMysqlClusterResizeRequest: S.Schema<PaginatedMysqlClusterResizeRequest>;
export type ListClusterSizeSkusRequestEngine = "mysql" | "postgresql";
export declare const ListClusterSizeSkusRequestEngine: any;
export interface ListClusterSizeSkusRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** The database engine to filter by. Defaults to 'mysql'. */
    engine?: ListClusterSizeSkusRequestEngine | (string & {});
    /** Whether to include pricing rates in the response. Defaults to false. */
    rates?: boolean;
    /** The region slug to get rates for. If not specified, uses the organization's default region. */
    region?: string;
    /** The database name to resolve rates for. When specified, database-level custom rates take precedence over organization rates. */
    database?: string;
}
export declare const ListClusterSizeSkusRequest: S.Schema<ListClusterSizeSkusRequest>;
export interface ClusterSizeSku {
    /** The name of the cluster SKU */
    name: string;
    /** The display name */
    display_name: string;
    /** The number of CPUs */
    cpu: string;
    /** The amount of storage in bytes */
    storage?: number | null;
    /** The amount of memory in bytes */
    ram: number;
    /** Whether or not the cluster SKU is Metal */
    metal: boolean;
    /** Whether or not the cluster SKU is enabled for the organization */
    enabled: boolean;
    /** The provider of the cluster SKU (nil, AWS or GCP) */
    provider?: string | null;
    /** The default vtgate size for the cluster SKU */
    default_vtgate: string;
    /** The default vtgate rate for the cluster SKU */
    default_vtgate_rate?: number | null;
    /** The recommended Neki router size for the cluster SKU */
    default_neki_router?: string | null;
    /** The replica rate for the cluster SKU */
    replica_rate?: number | null;
    /** The rate for the cluster SKU */
    rate?: number | null;
    /** The sort order of the cluster SKU */
    sort_order: number;
    /** The architecture of the cluster SKU (null, x86_64 or arm64) */
    architecture?: string | null;
    /** Whether or not the cluster SKU is a development SKU */
    development: boolean;
    /** Whether or not the cluster SKU is a production SKU */
    production: boolean;
}
export declare const ClusterSizeSku: S.Schema<ClusterSizeSku>;
export type ListClusterSizeSkusResponseBodyList = Array<ClusterSizeSku>;
export declare const ListClusterSizeSkusResponseBodyList: S.Schema<ListClusterSizeSkusResponseBodyList>;
export type ListClusterSizeSkusResponse = ListClusterSizeSkusResponseBodyList;
export declare const ListClusterSizeSkusResponse: S.Schema<ListClusterSizeSkusResponse>;
export interface ListDatabasePostgresCidrsRequest {
    /** The name of the organization the database belongs to */
    organization: string;
    /** The name of the database */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListDatabasePostgresCidrsRequest: S.Schema<ListDatabasePostgresCidrsRequest>;
/** List of CIDR ranges */
export type PaginatedPostgresClusterCidrDataItemCidrsList = Array<string>;
export declare const PaginatedPostgresClusterCidrDataItemCidrsList: S.Schema<PaginatedPostgresClusterCidrDataItemCidrsList>;
export type PaginatedPostgresClusterCidrDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresClusterCidrDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedPostgresClusterCidrDataItem {
    /** The ID of the IP allowlist entry */
    id: string;
    /** The schema name to restrict access to (optional) */
    schema: string;
    /** The role to restrict access to (optional) */
    role: string;
    /** List of CIDR ranges */
    cidrs: PaginatedPostgresClusterCidrDataItemCidrsList;
    /** An optional description for the IP restriction rule */
    description: string | null;
    /** When the entry was created */
    created_at: string;
    /** When the entry was updated */
    updated_at: string;
    /** When the entry was deleted */
    deleted_at: string | null;
    actor: OrganizationTeamMembershipActor;
}
export declare const PaginatedPostgresClusterCidrDataItem: S.Schema<PaginatedPostgresClusterCidrDataItem>;
export type PaginatedPostgresClusterCidrDataList = Array<PaginatedPostgresClusterCidrDataItem>;
export declare const PaginatedPostgresClusterCidrDataList: S.Schema<PaginatedPostgresClusterCidrDataList>;
export interface PaginatedPostgresClusterCidr {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedPostgresClusterCidrDataList;
}
export declare const PaginatedPostgresClusterCidr: S.Schema<PaginatedPostgresClusterCidr>;
export interface ListDatabaseRegionsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListDatabaseRegionsRequest: S.Schema<ListDatabaseRegionsRequest>;
/** Public IP addresses for the region */
export type PaginatedPlanetscaleRegionDataItemPublicIpAddressesList = Array<string>;
export declare const PaginatedPlanetscaleRegionDataItemPublicIpAddressesList: S.Schema<PaginatedPlanetscaleRegionDataItemPublicIpAddressesList>;
export interface PaginatedPlanetscaleRegionDataItem {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PaginatedPlanetscaleRegionDataItemPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PaginatedPlanetscaleRegionDataItem: S.Schema<PaginatedPlanetscaleRegionDataItem>;
export type PaginatedPlanetscaleRegionDataList = Array<PaginatedPlanetscaleRegionDataItem>;
export declare const PaginatedPlanetscaleRegionDataList: S.Schema<PaginatedPlanetscaleRegionDataList>;
export interface PaginatedPlanetscaleRegion {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPlanetscaleRegionDataList;
}
export declare const PaginatedPlanetscaleRegion: S.Schema<PaginatedPlanetscaleRegion>;
export interface ListDatabasesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Search term to filter databases by name */
    q?: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListDatabasesRequest: S.Schema<ListDatabasesRequest>;
export type PaginatedDatabaseDataItemDataImportDataSource = DatabaseDataImportDataSource;
export declare const PaginatedDatabaseDataItemDataImportDataSource: S.Schema<DatabaseDataImportDataSource>;
export type PaginatedDatabaseDataItemDataImport = DatabaseDataImport;
export declare const PaginatedDatabaseDataItemDataImport: S.Schema<DatabaseDataImport>;
/** Public IP addresses for the region */
export type PaginatedDatabaseDataItemRegionPublicIpAddressesList = Array<string>;
export declare const PaginatedDatabaseDataItemRegionPublicIpAddressesList: S.Schema<PaginatedDatabaseDataItemRegionPublicIpAddressesList>;
export interface PaginatedDatabaseDataItemRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PaginatedDatabaseDataItemRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PaginatedDatabaseDataItemRegion: S.Schema<PaginatedDatabaseDataItemRegion>;
/** State of the database */
export type PaginatedDatabaseDataItemState = "pending" | "importing" | "sleep_in_progress" | "sleeping" | "awakening" | "import_ready" | "ready";
export declare const PaginatedDatabaseDataItemState: any;
/** The kind of database */
export type PaginatedDatabaseDataItemKind = "mysql" | "postgresql";
export declare const PaginatedDatabaseDataItemKind: any;
export interface PaginatedDatabaseDataItem {
    /** The ID of the database */
    id: string;
    /** The URL to the database API endpoint */
    url: string;
    /** The URL to retrieve this database's branches via the API */
    branches_url: string;
    /** The total number of database branches */
    branches_count?: number;
    /** The total number of schema recommendations */
    open_schema_recommendations_count?: number;
    /** The total number of database development branches */
    development_branches_count?: number;
    /** The total number of database production branches */
    production_branches_count?: number;
    /** The total number of ongoing issues within a database */
    issues_count?: number | null;
    /** If the database requires multiple admins for deletion */
    multiple_admins_required_for_deletion?: boolean;
    /** If the database is ready to be used */
    ready: boolean;
    /** If the database has reached its backup restored branch limit */
    at_backup_restore_branches_limit?: boolean;
    /** If the database has reached its development branch limit */
    at_development_branch_usage_limit?: boolean;
    data_import?: DatabaseDataImport | null;
    region: PaginatedDatabaseDataItemRegion;
    /** The URL to see this database's branches in the web UI */
    html_url: string;
    /** Name of the database */
    name: string;
    /** State of the database */
    state: PaginatedDatabaseDataItemState;
    /** If the database is sharded */
    sharded?: boolean;
    /** Number of shards in the default branch */
    default_branch_shard_count?: number;
    /** Number of read only regions in the default branch */
    default_branch_read_only_regions_count?: number;
    /** Number of tables in the default branch schema */
    default_branch_table_count?: number;
    /** The default branch for the database */
    default_branch?: string;
    /** Whether an approval is required to deploy schema changes to this database */
    require_approval_for_deploy?: boolean;
    /** Whether deletion protection is enabled for the database */
    deletion_protected?: boolean;
    /** True if a branch is currently resizing */
    resizing?: boolean;
    /** True if a branch has a queued resize request */
    resize_queued?: boolean;
    /** True if a config change is in progress */
    config_changing?: boolean;
    /** True if a config change is queued for maintenance window */
    config_change_queued?: boolean;
    /** Whether seeding branches with data is enabled for all branches */
    allow_data_branching?: boolean;
    /** Whether foreign key constraints are enabled */
    foreign_keys_enabled?: boolean;
    /** Whether to automatically manage Rails migrations during deploy requests. */
    automatic_migrations?: boolean | null;
    /** Whether to restrict branch creation to one region */
    restrict_branch_region?: boolean;
    /** Whether deploy requests default to instant deploy when it is available */
    prefer_instant?: boolean;
    /** Whether raw SQL queries are collected */
    insights_raw_queries?: boolean;
    /** The database plan */
    plan?: string;
    /** True if query insights is enabled for the database */
    insights_enabled?: boolean;
    /** Whether web console is enabled for production branches */
    production_branch_web_console?: boolean;
    /** Table name to use for copying schema migration data. */
    migration_table_name?: string | null;
    /** Framework used for applying migrations. */
    migration_framework?: string | null;
    /** When the database was created */
    created_at: string;
    /** When the database was last updated */
    updated_at: string;
    /** When the default branch schema was last changed. */
    schema_last_updated_at?: string | null;
    /** The kind of database */
    kind: PaginatedDatabaseDataItemKind;
}
export declare const PaginatedDatabaseDataItem: S.Schema<PaginatedDatabaseDataItem>;
export type PaginatedDatabaseDataList = Array<PaginatedDatabaseDataItem>;
export declare const PaginatedDatabaseDataList: S.Schema<PaginatedDatabaseDataList>;
export interface PaginatedDatabase {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedDatabaseDataList;
}
export declare const PaginatedDatabase: S.Schema<PaginatedDatabase>;
export interface ListDeployOperationsRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListDeployOperationsRequest: S.Schema<ListDeployOperationsRequest>;
/** The state of the deploy operation */
export type PaginatedDeployOperationDataItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDeployOperationDataItemState: any;
/** Names of foreign keys removed by this operation */
export type PaginatedDeployOperationDataItemRemovedForeignKeyNamesList = Array<string>;
export declare const PaginatedDeployOperationDataItemRemovedForeignKeyNamesList: S.Schema<PaginatedDeployOperationDataItemRemovedForeignKeyNamesList>;
export interface PaginatedDeployOperationDataItem {
    /** The ID for the deploy operation */
    id: string;
    /** The state of the deploy operation */
    state: PaginatedDeployOperationDataItemState;
    /** The keyspace modified by the deploy operation */
    keyspace_name: string;
    /** The name of the table modifed by the deploy operation */
    table_name: string;
    /** The operation name of the deploy operation */
    operation_name: string;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number | null;
    /** The percent completion for the deploy operation */
    progress_percentage: number | null;
    /** A link to documentation explaining the deploy error, if present */
    deploy_error_docs_url: string | null;
    /** The DDL statement for the deploy operation */
    ddl_statement: string;
    /** A syntax-highlighted DDL statement for the deploy operation */
    syntax_highlighted_ddl: string;
    /** When the deploy operation was created */
    created_at: string;
    /** When the deploy operation was last updated */
    updated_at: string;
    /** When the deploy operation was last throttled */
    throttled_at: string | null;
    /** Whether or not the deploy operation is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation is currently locked */
    table_locked: boolean;
    /** Whether or not the table modified by the deploy operation was recently used */
    table_recently_used: boolean;
    /** When the table modified by the deploy operation was last used */
    table_recently_used_at: string | null;
    /** Names of foreign keys removed by this operation */
    removed_foreign_key_names: PaginatedDeployOperationDataItemRemovedForeignKeyNamesList | null;
    /** Deploy errors for the deploy operation */
    deploy_errors: string | null;
}
export declare const PaginatedDeployOperationDataItem: S.Schema<PaginatedDeployOperationDataItem>;
export type PaginatedDeployOperationDataList = Array<PaginatedDeployOperationDataItem>;
export declare const PaginatedDeployOperationDataList: S.Schema<PaginatedDeployOperationDataList>;
export interface PaginatedDeployOperation {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDeployOperationDataList;
}
export declare const PaginatedDeployOperation: S.Schema<PaginatedDeployOperation>;
export interface ListDeployRequestReviewsRequest {
    /** The name of the organization the deploy request belongs to */
    organization: string;
    /** The name of the database the deploy request belongs to */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListDeployRequestReviewsRequest: S.Schema<ListDeployRequestReviewsRequest>;
/** Whether the review is a comment or approval */
export type PaginatedDeployRequestReviewDataItemState = "commented" | "approved";
export declare const PaginatedDeployRequestReviewDataItemState: any;
export type PaginatedDeployRequestReviewDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedDeployRequestReviewDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedDeployRequestReviewDataItem {
    /** The ID of the review */
    id: string;
    /** The text body of the review */
    body: string;
    /** The HTML body of the review */
    html_body: string;
    /** Whether the review is a comment or approval */
    state: PaginatedDeployRequestReviewDataItemState;
    /** When the review was created */
    created_at: string;
    /** When the review was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const PaginatedDeployRequestReviewDataItem: S.Schema<PaginatedDeployRequestReviewDataItem>;
export type PaginatedDeployRequestReviewDataList = Array<PaginatedDeployRequestReviewDataItem>;
export declare const PaginatedDeployRequestReviewDataList: S.Schema<PaginatedDeployRequestReviewDataList>;
export interface PaginatedDeployRequestReview {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDeployRequestReviewDataList;
}
export declare const PaginatedDeployRequestReview: S.Schema<PaginatedDeployRequestReview>;
export interface ListDeployRequestsRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** Filter by state of the deploy request (open, closed, deployed) */
    state?: string;
    /** Filter by the name of the branch the deploy request is created from */
    branch?: string;
    /** Filter by the name of the branch the deploy request will be merged into */
    into_branch?: string;
    /** Filter deploy requests by the date they were deployed. (e.g. 2023-01-01T00:00:00Z..2023-01-31T23:59:59Z) */
    deployed_at?: string;
    /** Filter deploy requests by the date they were running. (e.g. 2023-01-01T00:00:00Z..2023-01-31T23:59:59Z) */
    running_at?: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListDeployRequestsRequest: S.Schema<ListDeployRequestsRequest>;
export type PaginatedDatabaseDeployRequestDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseDeployRequestDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDatabaseDeployRequestDataItemClosedBy = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseDeployRequestDataItemClosedBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDatabaseDeployRequestDataItemBranchDeletedBy = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseDeployRequestDataItemBranchDeletedBy: S.Schema<OrganizationTeamMembershipActor>;
/** Whether the deploy request is open or closed */
export type PaginatedDatabaseDeployRequestDataItemState = "open" | "closed";
export declare const PaginatedDatabaseDeployRequestDataItemState: any;
/** The deployment state of the deploy request */
export type PaginatedDatabaseDeployRequestDataItemDeploymentState = "pending" | "ready" | "no_changes" | "queued" | "submitting" | "in_progress" | "pending_cutover" | "in_progress_vschema" | "in_progress_cancel" | "in_progress_cutover" | "complete" | "complete_cancel" | "complete_error" | "complete_pending_revert" | "in_progress_revert" | "in_progress_revert_vschema" | "complete_revert" | "complete_revert_error" | "cancelled" | "error";
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentState: any;
/** The state the deployment is in */
export type PaginatedDatabaseDeployRequestDataItemDeploymentState2 = "pending" | "ready" | "no_changes" | "queued" | "submitting" | "in_progress" | "pending_cutover" | "in_progress_vschema" | "in_progress_cancel" | "in_progress_cutover" | "complete" | "complete_cancel" | "complete_error" | "complete_pending_revert" | "in_progress_revert" | "in_progress_revert_vschema" | "complete_revert" | "complete_revert_error" | "cancelled" | "error";
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentState2: any;
export type PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsItemMap: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsItemMap>;
/** The deployments ahead of this one in the queue */
export type PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsItemMap>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsList>;
/** The state of the deploy operation */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemState: any;
/** Names of foreign keys removed by this operation */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemRemovedForeignKeyNamesList = Array<string>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemRemovedForeignKeyNamesList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemRemovedForeignKeyNamesList>;
export interface PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The state of the deploy operation */
    state: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemState;
    /** The keyspace modified by the deploy operation */
    keyspace_name: string;
    /** The name of the table modifed by the deploy operation */
    table_name: string;
    /** The operation name of the deploy operation */
    operation_name: string;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number | null;
    /** The percent completion for the deploy operation */
    progress_percentage: number | null;
    /** A link to documentation explaining the deploy error, if present */
    deploy_error_docs_url: string | null;
    /** The DDL statement for the deploy operation */
    ddl_statement: string;
    /** A syntax-highlighted DDL statement for the deploy operation */
    syntax_highlighted_ddl: string;
    /** When the deploy operation was created */
    created_at: string;
    /** When the deploy operation was last updated */
    updated_at: string;
    /** When the deploy operation was last throttled */
    throttled_at: string | null;
    /** Whether or not the deploy operation is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation is currently locked */
    table_locked: boolean;
    /** Whether or not the table modified by the deploy operation was recently used */
    table_recently_used: boolean;
    /** When the table modified by the deploy operation was last used */
    table_recently_used_at: string | null;
    /** Names of foreign keys removed by this operation */
    removed_foreign_key_names: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItemRemovedForeignKeyNamesList | null;
    /** Deploy errors for the deploy operation */
    deploy_errors: string | null;
}
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItem: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItem>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsItem>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsList>;
/** The state of the deploy operation summary */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemState = "pending" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemState: any;
/** Names of foreign keys removed by this operation summary */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList = Array<string>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList>;
/** Names of shards in the keyspace modified by the deploy operation summary */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemShardNamesList = Array<string>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemShardNamesList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemShardNamesList>;
/** The state of the deploy operation */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItemState = "pending" | "queued" | "in_progress" | "complete" | "cancelled" | "error";
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItemState: any;
export interface PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItem {
    /** The ID for the deploy operation */
    id: string;
    /** The shard the deploy operation is being performed on */
    shard: string;
    /** The state of the deploy operation */
    state: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItemState;
    /** The percent completion for the deploy operation */
    progress_percentage: number;
    /** The estimated seconds until completion for the deploy operation */
    eta_seconds: number;
}
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItem: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItem>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsItem>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsList>;
export interface PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItem {
    /** The ID for the deploy operation summary */
    id: string;
    /** When the deploy operation summary was created */
    created_at: string;
    /** Deploy errors for the deploy operation summary */
    deploy_errors: string;
    /** The DDL statement for the deploy operation summary */
    ddl_statement: string;
    /** The estimated seconds until completion for the deploy operation summary */
    eta_seconds: number;
    /** The keyspace modified by the deploy operation summary */
    keyspace_name: string;
    /** The operation name of the deploy operation summary */
    operation_name: string;
    /** The percent completion for the deploy operation summary */
    progress_percentage: number;
    /** The state of the deploy operation summary */
    state: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemState;
    /** A syntax-highlighted DDL statement for the deploy operation summary */
    syntax_highlighted_ddl: string;
    /** The name of the table modifed by the deploy operation summary */
    table_name: string;
    /** When the table modified by the deploy operation summary was last used */
    table_recently_used_at: string | null;
    /** When the deploy operation summary was last throttled */
    throttled_at: string | null;
    /** Names of foreign keys removed by this operation summary */
    removed_foreign_key_names: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemRemovedForeignKeyNamesList;
    /** The number of shards in the keyspace modified by the deploy operation summary */
    shard_count: number;
    /** Names of shards in the keyspace modified by the deploy operation summary */
    shard_names: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemShardNamesList;
    /** Whether or not the deploy operation summary is capable of dropping data */
    can_drop_data: boolean;
    /** Whether or not the table modified by the deploy operation summary was recently used */
    table_recently_used: boolean;
    /** Whether or not the keyspace modified by the deploy operation summary is sharded */
    sharded: boolean;
    operations: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItemOperationsList;
}
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItem: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItem>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesItem>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesList>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsItemMap: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsItemMap>;
/** Schema lint errors preventing the deployment from completing */
export type PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsItemMap>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsList>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesItemMap: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesItemMap>;
/** The schema dependencies that must be satisfied */
export type PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesItemMap>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesList>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsItemMap: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsItemMap>;
/** Lookup Vitess index operations */
export type PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsList = Array<PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsItemMap>;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsList: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsList>;
/** Deployment throttling configurations. */
export type PaginatedDatabaseDeployRequestDataItemDeploymentThrottlerConfigurationsMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentThrottlerConfigurationsMap: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentThrottlerConfigurationsMap>;
/** The request to revert the schema operations in this deployment */
export type PaginatedDatabaseDeployRequestDataItemDeploymentDeploymentRevertRequestMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentDeploymentRevertRequestMap: S.Schema<PaginatedDatabaseDeployRequestDataItemDeploymentDeploymentRevertRequestMap>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentCutoverActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentCutoverActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedDatabaseDeployRequestDataItemDeploymentCancelledActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseDeployRequestDataItemDeploymentCancelledActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedDatabaseDeployRequestDataItemDeployment {
    /** The ID of the deployment */
    id: string;
    /** Whether or not to automatically cutover once deployment is finished */
    auto_cutover: boolean;
    /** Whether or not to automatically delete the head branch once deployment is finished */
    auto_delete_branch: boolean;
    /** When the deployment was created */
    created_at: string;
    /** When the cutover for the deployment was initiated */
    cutover_at: string | null;
    /** Whether or not the deployment cutover will expire soon */
    cutover_expiring: boolean;
    /** Deploy check errors for the deployment. */
    deploy_check_errors?: string | null;
    /** When the deployment was finished */
    finished_at: string | null;
    /** When force cutover was triggered for the deployment */
    force_cutover_requested_at: string | null;
    /** When the deployment was queued */
    queued_at: string | null;
    /** When the deployment was ready for cutover */
    ready_to_cutover_at: string | null;
    /** When the deployment was started */
    started_at: string | null;
    /** The state the deployment is in */
    state: PaginatedDatabaseDeployRequestDataItemDeploymentState2;
    /** When the deployment was submitted */
    submitted_at: string | null;
    /** When the deployment was last updated */
    updated_at: string;
    /** The name of the base branch the deployment will be merged into */
    into_branch: string;
    /** The number of the deploy request associated with this deployment */
    deploy_request_number: number;
    /** Whether the deployment is deployable */
    deployable: boolean;
    /** The deployments ahead of this one in the queue */
    preceding_deployments: PaginatedDatabaseDeployRequestDataItemDeploymentPrecedingDeploymentsList;
    deploy_operations: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationsList;
    deploy_operation_summaries: PaginatedDatabaseDeployRequestDataItemDeploymentDeployOperationSummariesList;
    /** Schema lint errors preventing the deployment from completing */
    lint_errors: PaginatedDatabaseDeployRequestDataItemDeploymentLintErrorsList;
    /** The schema dependencies that must be satisfied */
    sequential_diff_dependencies: PaginatedDatabaseDeployRequestDataItemDeploymentSequentialDiffDependenciesList;
    /** Lookup Vitess index operations */
    lookup_vindex_operations: PaginatedDatabaseDeployRequestDataItemDeploymentLookupVindexOperationsList;
    /** Deployment throttling configurations. */
    throttler_configurations?: PaginatedDatabaseDeployRequestDataItemDeploymentThrottlerConfigurationsMap | null;
    /** The request to revert the schema operations in this deployment */
    deployment_revert_request: PaginatedDatabaseDeployRequestDataItemDeploymentDeploymentRevertRequestMap | null;
    actor?: OrganizationTeamMembershipActor | null;
    cutover_actor?: OrganizationTeamMembershipActor | null;
    cancelled_actor?: OrganizationTeamMembershipActor | null;
    /** When the schema was last updated for the deployment */
    schema_last_updated_at: string | null;
    /** Whether or not the deployment has a table locked */
    table_locked: boolean;
    /** The name of the table that is locked by the deployment. */
    locked_table_name?: string | null;
    /** Whether or not the deployment is an instant DDL deployment */
    instant_ddl: boolean;
    /** Whether or not the deployment is eligible for instant DDL */
    instant_ddl_eligible: boolean;
    /** Whether the deploy queue for the target branch is currently paused */
    queue_paused: boolean;
    /** A human-readable reason the deploy queue is paused, if known */
    queue_pause_reason: string | null;
}
export declare const PaginatedDatabaseDeployRequestDataItemDeployment: S.Schema<PaginatedDatabaseDeployRequestDataItemDeployment>;
export interface PaginatedDatabaseDeployRequestDataItem {
    /** The ID of the deploy request */
    id: string;
    /** The number of the deploy request */
    number: number;
    actor: OrganizationTeamMembershipActor;
    closed_by?: OrganizationTeamMembershipActor | null;
    /** The name of the branch the deploy request was created from */
    branch: string;
    /** The ID of the branch the deploy request was created from */
    branch_id: string;
    /** Whether or not the deploy request branch was deleted */
    branch_deleted: boolean;
    branch_deleted_by?: OrganizationTeamMembershipActor | null;
    /** When the deploy request branch was deleted */
    branch_deleted_at: string | null;
    /** The name of the branch the deploy request will be merged into */
    into_branch: string;
    /** Whether or not the branch the deploy request will be merged into is sharded */
    into_branch_sharded: boolean;
    /** The number of shards the branch the deploy request will be merged into has */
    into_branch_shard_count: number;
    /** The number of keyspaces the branch the deploy request will be merged into has */
    into_branch_keyspace_count: number;
    /** Whether or not the deploy request is approved */
    approved: boolean;
    /** Whether the deploy request is open or closed */
    state: PaginatedDatabaseDeployRequestDataItemState;
    /** The deployment state of the deploy request */
    deployment_state: PaginatedDatabaseDeployRequestDataItemDeploymentState;
    deployment: PaginatedDatabaseDeployRequestDataItemDeployment;
    /** The number of comments on the deploy request */
    num_comments: number;
    /** The PlanetScale app address for the deploy request */
    html_url: string;
    /** Notes on the deploy request */
    notes: string;
    /** The HTML body of the deploy request */
    html_body: string;
    /** When the deploy request was created */
    created_at: string;
    /** When the deploy request was last updated */
    updated_at: string;
    /** When the deploy request was closed */
    closed_at: string | null;
    /** When the deploy request was deployed */
    deployed_at: string | null;
}
export declare const PaginatedDatabaseDeployRequestDataItem: S.Schema<PaginatedDatabaseDeployRequestDataItem>;
export type PaginatedDatabaseDeployRequestDataList = Array<PaginatedDatabaseDeployRequestDataItem>;
export declare const PaginatedDatabaseDeployRequestDataList: S.Schema<PaginatedDatabaseDeployRequestDataList>;
export interface PaginatedDatabaseDeployRequest {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedDatabaseDeployRequestDataList;
}
export declare const PaginatedDatabaseDeployRequest: S.Schema<PaginatedDatabaseDeployRequest>;
export interface ListExtensionsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const ListExtensionsRequest: S.Schema<ListExtensionsRequest>;
/** How the extension is loaded */
export type PostgresClusterExtensionLoader = "shared_preload_libraries" | "session_preload_libraries" | "create_extension";
export declare const PostgresClusterExtensionLoader: any;
/** The namespace of the parameter */
export type PostgresClusterExtensionParametersItemNamespace = "patroni" | "pgconf" | "pgbouncer";
export declare const PostgresClusterExtensionParametersItemNamespace: any;
/** The type of the parameter */
export type PostgresClusterExtensionParametersItemParameterType = "array" | "boolean" | "bytes" | "float" | "integer" | "seconds" | "select" | "string" | "time";
export declare const PostgresClusterExtensionParametersItemParameterType: any;
/** Valid options for the parameter value */
export type PostgresClusterExtensionParametersItemOptionsList = Array<string>;
export declare const PostgresClusterExtensionParametersItemOptionsList: S.Schema<PostgresClusterExtensionParametersItemOptionsList>;
export type PostgresClusterExtensionParametersItemActor = OrganizationTeamMembershipActor;
export declare const PostgresClusterExtensionParametersItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PostgresClusterExtensionParametersItem {
    /** The ID of the parameter */
    id: string;
    /** The name of the parameter */
    name: string;
    /** The display name of the parameter */
    display_name: string;
    /** The namespace of the parameter */
    namespace: PostgresClusterExtensionParametersItemNamespace;
    /** The category of the parameter */
    category: string;
    /** The description of the parameter */
    description: string;
    /** Configures an extension */
    extension: boolean;
    /** Whether the parameter can be changed */
    immutable: boolean;
    /** The type of the parameter */
    parameter_type: PostgresClusterExtensionParametersItemParameterType;
    /** The default value of the parameter */
    default_value: string;
    /** The configured value of the parameter */
    value: string;
    /** Whether the parameter is required */
    required: boolean;
    /** When the parameter was created */
    created_at: string;
    /** When the parameter was last updated */
    updated_at: string;
    /** True if processes require a server restart on change */
    restart: boolean;
    /** The maximum value of the parameter */
    max: number;
    /** The minimum value of the parameter */
    min: number;
    /** The URL of the parameter */
    url: string;
    /** Valid options for the parameter value */
    options: PostgresClusterExtensionParametersItemOptionsList;
    actor: OrganizationTeamMembershipActor;
}
export declare const PostgresClusterExtensionParametersItem: S.Schema<PostgresClusterExtensionParametersItem>;
export type PostgresClusterExtensionParametersList = Array<PostgresClusterExtensionParametersItem>;
export declare const PostgresClusterExtensionParametersList: S.Schema<PostgresClusterExtensionParametersList>;
export interface PostgresClusterExtension {
    /** The ID of the extension */
    id: string;
    /** The name of the extension */
    name: string;
    /** The description of the extension */
    description: string;
    /** The internal state of the extension */
    internal: boolean;
    /** How the extension is loaded */
    loader: PostgresClusterExtensionLoader;
    /** The URL of the extension */
    url: string;
    /** Whether the extension is available on the current cluster image */
    available: boolean;
    /** The reason the extension is unavailable (e.g., 'container_upgrade_required') */
    unavailable_reason: string;
    parameters: PostgresClusterExtensionParametersList;
}
export declare const PostgresClusterExtension: S.Schema<PostgresClusterExtension>;
export type ListExtensionsResponseBodyList = Array<PostgresClusterExtension>;
export declare const ListExtensionsResponseBodyList: S.Schema<ListExtensionsResponseBodyList>;
export type ListExtensionsResponse = ListExtensionsResponseBodyList;
export declare const ListExtensionsResponse: S.Schema<ListExtensionsResponse>;
export interface ListGeneratedQueryPatternsReportsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** If provided, returns results after the specified cursor */
    starting_after?: string;
    /** If provided, returns results before the specified cursor */
    ending_before?: string;
    /** If provided, specifies the number of returned results (max 100) */
    limit?: number;
}
export declare const ListGeneratedQueryPatternsReportsRequest: S.Schema<ListGeneratedQueryPatternsReportsRequest>;
/** The state of the download */
export type PaginatedQueryPatternsDownloadDataItemState = "pending" | "completed" | "failed";
export declare const PaginatedQueryPatternsDownloadDataItemState: any;
export type PaginatedQueryPatternsDownloadDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedQueryPatternsDownloadDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedQueryPatternsDownloadDataItem {
    /** The ID of the query patterns download */
    id: string;
    /** The state of the download */
    state: PaginatedQueryPatternsDownloadDataItemState;
    /** When the download was created */
    created_at: string;
    /** When the download was finished */
    finished_at: string | null;
    /** The URL to access the query patterns download */
    url: string;
    /** The URL to download the query patterns file */
    download_url: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const PaginatedQueryPatternsDownloadDataItem: S.Schema<PaginatedQueryPatternsDownloadDataItem>;
export type PaginatedQueryPatternsDownloadDataList = Array<PaginatedQueryPatternsDownloadDataItem>;
export declare const PaginatedQueryPatternsDownloadDataList: S.Schema<PaginatedQueryPatternsDownloadDataList>;
export interface PaginatedQueryPatternsDownload {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** Whether there is a next page of results */
    has_next: boolean;
    /** Whether there is a previous page of results */
    has_prev: boolean;
    /** The ID of the first object in the current results, or null when there are no results */
    cursor_start: string | null;
    /** The ID of the last object in the current results, or null when there are no results */
    cursor_end: string | null;
    data: PaginatedQueryPatternsDownloadDataList;
}
export declare const PaginatedQueryPatternsDownload: S.Schema<PaginatedQueryPatternsDownload>;
export interface ListInvoicesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListInvoicesRequest: S.Schema<ListInvoicesRequest>;
export interface PaginatedInvoiceDataItem {
    /** The ID of the invoice */
    id: string;
    /** The total amount of the invoice, as a stringified decimal to preserve precision */
    total: string;
    /** Start of the billing period */
    billing_period_start: string;
    /** End of the billing period */
    billing_period_end: string;
    /** Whether the invoice has been paid */
    paid: boolean;
    /** Whether the invoice is past due and unpaid */
    overdue: boolean;
}
export declare const PaginatedInvoiceDataItem: S.Schema<PaginatedInvoiceDataItem>;
export type PaginatedInvoiceDataList = Array<PaginatedInvoiceDataItem>;
export declare const PaginatedInvoiceDataList: S.Schema<PaginatedInvoiceDataList>;
export interface PaginatedInvoice {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedInvoiceDataList;
}
export declare const PaginatedInvoice: S.Schema<PaginatedInvoice>;
export interface ListKeyspaceResizeRequestsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListKeyspaceResizeRequestsRequest: S.Schema<ListKeyspaceResizeRequestsRequest>;
export type PaginatedKeyspaceResizeRequestDataList = Array<KeyspaceResizeRequest>;
export declare const PaginatedKeyspaceResizeRequestDataList: S.Schema<PaginatedKeyspaceResizeRequestDataList>;
export interface PaginatedKeyspaceResizeRequest {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedKeyspaceResizeRequestDataList;
}
export declare const PaginatedKeyspaceResizeRequest: S.Schema<PaginatedKeyspaceResizeRequest>;
export interface ListKeyspacesRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListKeyspacesRequest: S.Schema<ListKeyspacesRequest>;
/** Controls when node TTL drains are allowed */
export type PaginatedDatabaseBranchKeyspaceDataItemNodeTtlStrategy = "node_ttl_follow_maintenance" | "node_ttl_always" | "node_ttl_off";
export declare const PaginatedDatabaseBranchKeyspaceDataItemNodeTtlStrategy: any;
/** The replication durability strategy */
export type PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraintsStrategy = "available" | "lag" | "always";
export declare const PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraintsStrategy: any;
export interface PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraints {
    /** The replication durability strategy */
    strategy?: PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraintsStrategy | null;
}
export declare const PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraints: S.Schema<PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraints>;
export type PaginatedDatabaseBranchKeyspaceDataItemVreplicationFlags = DatabaseBranchKeyspaceVreplicationFlags;
export declare const PaginatedDatabaseBranchKeyspaceDataItemVreplicationFlags: S.Schema<DatabaseBranchKeyspaceVreplicationFlags>;
/** MySQL daemon configuration options */
export type PaginatedDatabaseBranchKeyspaceDataItemMysqldOptionsMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseBranchKeyspaceDataItemMysqldOptionsMap: S.Schema<PaginatedDatabaseBranchKeyspaceDataItemMysqldOptionsMap>;
/** VTTablet configuration options */
export type PaginatedDatabaseBranchKeyspaceDataItemVttabletOptionsMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedDatabaseBranchKeyspaceDataItemVttabletOptionsMap: S.Schema<PaginatedDatabaseBranchKeyspaceDataItemVttabletOptionsMap>;
export interface PaginatedDatabaseBranchKeyspaceDataItem {
    /** The ID of the keyspace */
    id: string;
    /** Name of the keyspace */
    name: string;
    /** The number of keyspace shards */
    shards: number;
    /** If the keyspace is sharded */
    sharded: boolean;
    /** If the keyspace uses an external datasource */
    external: boolean;
    /** Total number of replicas in the keyspace */
    replicas: number;
    /** Number of extra replicas in the keyspace */
    extra_replicas: number;
    /** When the keyspace was created */
    created_at: string;
    /** When the keyspace was last updated */
    updated_at: string;
    /** The SKU representing the keyspace cluster size */
    cluster_name: string;
    /** The SKU representing the keyspace cluster size for display */
    cluster_display_name: string;
    /** Is the keyspace currently resizing */
    resizing: boolean;
    /** True if the keyspace has an unfinished resize request */
    resize_in_progress: boolean;
    /** Is the keyspace awaiting a resize */
    resize_pending: boolean;
    /** Is the keyspace undergoing a config change */
    config_change_in_progress: boolean;
    /** Is the keyspace provisioned and serving traffic */
    ready: boolean;
    /** Is the keyspace running on metal instances */
    metal: boolean;
    /** Is this the default keyspace for the branch */
    default: boolean;
    /** Is this keyspace used in an import */
    imported: boolean;
    /** Percentage of buffer pool memory allocated to vector indexes */
    vector_pool_allocation: number | null;
    /** Controls when node TTL drains are allowed */
    node_ttl_strategy: PaginatedDatabaseBranchKeyspaceDataItemNodeTtlStrategy;
    replication_durability_constraints: PaginatedDatabaseBranchKeyspaceDataItemReplicationDurabilityConstraints;
    vreplication_flags: DatabaseBranchKeyspaceVreplicationFlags;
    /** MySQL daemon configuration options */
    mysqld_options: PaginatedDatabaseBranchKeyspaceDataItemMysqldOptionsMap;
    /** VTTablet configuration options */
    vttablet_options: PaginatedDatabaseBranchKeyspaceDataItemVttabletOptionsMap;
}
export declare const PaginatedDatabaseBranchKeyspaceDataItem: S.Schema<PaginatedDatabaseBranchKeyspaceDataItem>;
export type PaginatedDatabaseBranchKeyspaceDataList = Array<PaginatedDatabaseBranchKeyspaceDataItem>;
export declare const PaginatedDatabaseBranchKeyspaceDataList: S.Schema<PaginatedDatabaseBranchKeyspaceDataList>;
export interface PaginatedDatabaseBranchKeyspace {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDatabaseBranchKeyspaceDataList;
}
export declare const PaginatedDatabaseBranchKeyspace: S.Schema<PaginatedDatabaseBranchKeyspace>;
export interface ListMaintenanceSchedulesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListMaintenanceSchedulesRequest: S.Schema<ListMaintenanceSchedulesRequest>;
/** The frequency unit of the maintenance schedule */
export type PaginatedBranchMaintenanceScheduleDataItemFrequencyUnit = "day" | "week" | "month" | "once";
export declare const PaginatedBranchMaintenanceScheduleDataItemFrequencyUnit: any;
export interface PaginatedBranchMaintenanceScheduleDataItem {
    /** The ID of the maintenance schedule */
    id: string;
    /** The display name of the maintenance schedule */
    name: string;
    /** When the maintenance schedule was created */
    created_at: string;
    /** When the maintenance schedule was last updated */
    updated_at: string;
    /** When the last maintenance window started */
    last_window_datetime: string;
    /** When the next maintenance window is scheduled */
    next_window_datetime: string;
    /** The duration of the maintenance window in hours */
    duration: number;
    /** Day of the week (0 = Sunday, 6 = Saturday, 7 = every day) */
    day: number;
    /** Hour of the day in UTC (0-23) */
    hour: number;
    /** Week of the month for monthly schedules (0-3) */
    week: number;
    /** The frequency value of the maintenance schedule */
    frequency_value: number;
    /** The frequency unit of the maintenance schedule */
    frequency_unit: PaginatedBranchMaintenanceScheduleDataItemFrequencyUnit;
    /** Whether the maintenance schedule is enabled */
    enabled: boolean;
    /** When a one-time maintenance schedule expires */
    expires_at: string | null;
    /** The deadline for a required maintenance schedule */
    deadline_at: string | null;
    /** Whether the maintenance schedule is required */
    required: boolean;
    /** Whether there is a pending Vitess version update */
    pending_vitess_version_update: boolean;
    /** The pending Vitess version, if any */
    pending_vitess_version: string | null;
    /** Whether there is a pending MySQL version update */
    pending_mysql_version_update: boolean;
    /** The pending MySQL version, if any */
    pending_mysql_version: string | null;
}
export declare const PaginatedBranchMaintenanceScheduleDataItem: S.Schema<PaginatedBranchMaintenanceScheduleDataItem>;
export type PaginatedBranchMaintenanceScheduleDataList = Array<PaginatedBranchMaintenanceScheduleDataItem>;
export declare const PaginatedBranchMaintenanceScheduleDataList: S.Schema<PaginatedBranchMaintenanceScheduleDataList>;
export interface PaginatedBranchMaintenanceSchedule {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedBranchMaintenanceScheduleDataList;
}
export declare const PaginatedBranchMaintenanceSchedule: S.Schema<PaginatedBranchMaintenanceSchedule>;
export interface ListMaintenanceWindowsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The ID of the maintenance schedule */
    id: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListMaintenanceWindowsRequest: S.Schema<ListMaintenanceWindowsRequest>;
export interface PaginatedBranchMaintenanceWindowDataItem {
    /** The ID of the maintenance window */
    id: string;
    /** When the maintenance window was created */
    created_at: string;
    /** When the maintenance window was last updated */
    updated_at: string;
    /** When the maintenance window started */
    started_at: string | null;
    /** When the maintenance window finished */
    finished_at: string | null;
}
export declare const PaginatedBranchMaintenanceWindowDataItem: S.Schema<PaginatedBranchMaintenanceWindowDataItem>;
export type PaginatedBranchMaintenanceWindowDataList = Array<PaginatedBranchMaintenanceWindowDataItem>;
export declare const PaginatedBranchMaintenanceWindowDataList: S.Schema<PaginatedBranchMaintenanceWindowDataList>;
export interface PaginatedBranchMaintenanceWindow {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedBranchMaintenanceWindowDataList;
}
export declare const PaginatedBranchMaintenanceWindow: S.Schema<PaginatedBranchMaintenanceWindow>;
export interface ListOauthApplicationsRequest {
    /** The name of the organization the OAuth applications belong to */
    organization: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListOauthApplicationsRequest: S.Schema<ListOauthApplicationsRequest>;
/** Scopes grouped by resource type (database, organization, branch, user) with scope, description, and admin flag */
export type PaginatedOauthApplicationDataItemScopesByResourceMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedOauthApplicationDataItemScopesByResourceMap: S.Schema<PaginatedOauthApplicationDataItemScopesByResourceMap>;
/** All available scopes grouped by resource type with scope, description, selected, and admin flags */
export type PaginatedOauthApplicationDataItemAllScopesByResourceMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedOauthApplicationDataItemAllScopesByResourceMap: S.Schema<PaginatedOauthApplicationDataItemAllScopesByResourceMap>;
export type PaginatedOauthApplicationDataItemMcpToolGroupsItemMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedOauthApplicationDataItemMcpToolGroupsItemMap: S.Schema<PaginatedOauthApplicationDataItemMcpToolGroupsItemMap>;
/** MCP tool groups (id, label, section, tools, scopes, parent_id, default_enabled, roles) selectable when authorizing a DCR app; only present for DCR apps. Database-section groups also carry org_scopes (the organization-tier scope names granting the group across all databases in an organization) and org_roles (the organization roles allowed to grant them); both are null for organization-section groups */
export type PaginatedOauthApplicationDataItemMcpToolGroupsList = Array<PaginatedOauthApplicationDataItemMcpToolGroupsItemMap>;
export declare const PaginatedOauthApplicationDataItemMcpToolGroupsList: S.Schema<PaginatedOauthApplicationDataItemMcpToolGroupsList>;
export interface PaginatedOauthApplicationDataItem {
    /** The ID of the app */
    id: string;
    /** The name of the app */
    name: string;
    /** The redirect URI of the OAuth application */
    redirect_uri: string;
    /** The domain of the OAuth application. Used for verification of a valid redirect uri */
    domain: string;
    /** When the OAuth application was created */
    created_at: string;
    /** When the OAuth application was last updated */
    updated_at: string;
    /** The scopes that the OAuth application requires on a user account, as a space-separated string */
    scopes: string;
    /** The image source for the OAuth application's avatar */
    avatar: string;
    /** The OAuth application's unique client id */
    client_id: string;
    /** The number of tokens issued by the OAuth application */
    tokens: number;
    /** Whether the OAuth application was created via Dynamic Client Registration */
    dcr: boolean;
    /** Whether the OAuth application is limited to authorizing a single organization */
    single_org_authorization: boolean;
    /** Whether the OAuth application requires at least one organization to be authorized */
    requires_org_scope: boolean;
    /** Scopes grouped by resource type (database, organization, branch, user) with scope, description, and admin flag */
    scopes_by_resource: PaginatedOauthApplicationDataItemScopesByResourceMap;
    /** All available scopes grouped by resource type with scope, description, selected, and admin flags */
    all_scopes_by_resource: PaginatedOauthApplicationDataItemAllScopesByResourceMap;
    /** MCP tool groups (id, label, section, tools, scopes, parent_id, default_enabled, roles) selectable when authorizing a DCR app; only present for DCR apps. Database-section groups also carry org_scopes (the organization-tier scope names granting the group across all databases in an organization) and org_roles (the organization roles allowed to grant them); both are null for organization-section groups */
    mcp_tool_groups?: PaginatedOauthApplicationDataItemMcpToolGroupsList | null;
}
export declare const PaginatedOauthApplicationDataItem: S.Schema<PaginatedOauthApplicationDataItem>;
export type PaginatedOauthApplicationDataList = Array<PaginatedOauthApplicationDataItem>;
export declare const PaginatedOauthApplicationDataList: S.Schema<PaginatedOauthApplicationDataList>;
export interface PaginatedOauthApplication {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedOauthApplicationDataList;
}
export declare const PaginatedOauthApplication: S.Schema<PaginatedOauthApplication>;
export interface ListOauthTokensRequest {
    /** The name of the organization the OAuth application belongs to */
    organization: string;
    /** The ID of the OAuth application */
    application_id: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListOauthTokensRequest: S.Schema<ListOauthTokensRequest>;
export type PaginatedServiceTokenDataItemServiceTokenAccessesItemResource = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedServiceTokenDataItemServiceTokenAccessesItemResource: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedServiceTokenDataItemServiceTokenAccessesItem = ServiceTokenServiceTokenAccessesItem;
export declare const PaginatedServiceTokenDataItemServiceTokenAccessesItem: S.Schema<ServiceTokenServiceTokenAccessesItem>;
export type PaginatedServiceTokenDataItemServiceTokenAccessesList = Array<ServiceTokenServiceTokenAccessesItem>;
export declare const PaginatedServiceTokenDataItemServiceTokenAccessesList: S.Schema<PaginatedServiceTokenDataItemServiceTokenAccessesList>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseDatabasesItem = ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseDatabasesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseDatabasesList = Array<ServiceTokenOauthAccessesByResourceDatabaseDatabasesItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseDatabasesList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseDatabasesList>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseAccessesList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseAccessesList>;
export interface PaginatedServiceTokenDataItemOauthAccessesByResourceDatabase {
    databases: PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseDatabasesList;
    accesses: PaginatedServiceTokenDataItemOauthAccessesByResourceDatabaseAccessesList;
}
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceDatabase: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceDatabase>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationOrganizationsItem = ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationOrganizationsItem: S.Schema<ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationOrganizationsList = Array<ServiceTokenOauthAccessesByResourceOrganizationOrganizationsItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationOrganizationsList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationOrganizationsList>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationAccessesList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationAccessesList>;
export interface PaginatedServiceTokenDataItemOauthAccessesByResourceOrganization {
    organizations: PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationOrganizationsList;
    accesses: PaginatedServiceTokenDataItemOauthAccessesByResourceOrganizationAccessesList;
}
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceOrganization: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceOrganization>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceBranchBranchesItem = ServiceTokenOauthAccessesByResourceBranchBranchesItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceBranchBranchesItem: S.Schema<ServiceTokenOauthAccessesByResourceBranchBranchesItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceBranchBranchesList = Array<ServiceTokenOauthAccessesByResourceBranchBranchesItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceBranchBranchesList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceBranchBranchesList>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceBranchAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceBranchAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceBranchAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceBranchAccessesList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceBranchAccessesList>;
export interface PaginatedServiceTokenDataItemOauthAccessesByResourceBranch {
    branches: PaginatedServiceTokenDataItemOauthAccessesByResourceBranchBranchesList;
    accesses: PaginatedServiceTokenDataItemOauthAccessesByResourceBranchAccessesList;
}
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceBranch: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceBranch>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceUserUsersItem = ServiceTokenOauthAccessesByResourceUserUsersItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceUserUsersItem: S.Schema<ServiceTokenOauthAccessesByResourceUserUsersItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceUserUsersList = Array<ServiceTokenOauthAccessesByResourceUserUsersItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceUserUsersList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceUserUsersList>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceUserAccessesItem = ServiceTokenOauthAccessesByResourceDatabaseAccessesItem;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceUserAccessesItem: S.Schema<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export type PaginatedServiceTokenDataItemOauthAccessesByResourceUserAccessesList = Array<ServiceTokenOauthAccessesByResourceDatabaseAccessesItem>;
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceUserAccessesList: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceUserAccessesList>;
export interface PaginatedServiceTokenDataItemOauthAccessesByResourceUser {
    users: PaginatedServiceTokenDataItemOauthAccessesByResourceUserUsersList;
    accesses: PaginatedServiceTokenDataItemOauthAccessesByResourceUserAccessesList;
}
export declare const PaginatedServiceTokenDataItemOauthAccessesByResourceUser: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResourceUser>;
export interface PaginatedServiceTokenDataItemOauthAccessesByResource {
    database: PaginatedServiceTokenDataItemOauthAccessesByResourceDatabase;
    organization: PaginatedServiceTokenDataItemOauthAccessesByResourceOrganization;
    branch: PaginatedServiceTokenDataItemOauthAccessesByResourceBranch;
    user: PaginatedServiceTokenDataItemOauthAccessesByResourceUser;
}
export declare const PaginatedServiceTokenDataItemOauthAccessesByResource: S.Schema<PaginatedServiceTokenDataItemOauthAccessesByResource>;
export interface PaginatedServiceTokenDataItem {
    /** The ID of the service token */
    id: string;
    /** The name of the service token */
    name?: string | null;
    /** The display name of the service token */
    display_name: string;
    /** The plaintext token. Available only after create. */
    token?: string | null;
    /** The plaintext refresh token. Available only after create. */
    plain_text_refresh_token?: Redacted.Redacted<string> | null;
    /** The image source for the avatar of the service token */
    avatar_url: string;
    /** When the service token was created */
    created_at: string;
    /** When the service token was last updated */
    updated_at: string;
    /** When the service token will expire */
    expires_at?: string | null;
    /** When the service token was last used */
    last_used_at?: string | null;
    /** The ID of the actor on whose behalf the service token was created */
    actor_id: string | null;
    /** The name of the actor on whose behalf the service token was created */
    actor_display_name: string | null;
    /** The type of the actor on whose behalf the service token was created */
    actor_type: string | null;
    service_token_accesses?: PaginatedServiceTokenDataItemServiceTokenAccessesList | null;
    oauth_accesses_by_resource?: PaginatedServiceTokenDataItemOauthAccessesByResource | null;
}
export declare const PaginatedServiceTokenDataItem: S.Schema<PaginatedServiceTokenDataItem>;
export type PaginatedServiceTokenDataList = Array<PaginatedServiceTokenDataItem>;
export declare const PaginatedServiceTokenDataList: S.Schema<PaginatedServiceTokenDataList>;
export interface PaginatedServiceToken {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedServiceTokenDataList;
}
export declare const PaginatedServiceToken: S.Schema<PaginatedServiceToken>;
export interface ListOrganizationMembersRequest {
    /** The name of the organization */
    organization: string;
    /** Search term to filter members by name or email */
    q?: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListOrganizationMembersRequest: S.Schema<ListOrganizationMembersRequest>;
export type PaginatedOrganizationMembershipDataItemUserDefaultOrganization = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedOrganizationMembershipDataItemUserDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedOrganizationMembershipDataItemUser = OrganizationMembershipUser;
export declare const PaginatedOrganizationMembershipDataItemUser: S.Schema<OrganizationMembershipUser>;
/** The role of the user in the organization */
export type PaginatedOrganizationMembershipDataItemRole = "member" | "admin";
export declare const PaginatedOrganizationMembershipDataItemRole: any;
export interface PaginatedOrganizationMembershipDataItem {
    /** The ID of the membership */
    id: string;
    user: OrganizationMembershipUser;
    /** The role of the user in the organization */
    role: PaginatedOrganizationMembershipDataItemRole;
    /** When the membership was created */
    created_at: string;
    /** When the membership was last updated */
    updated_at: string;
}
export declare const PaginatedOrganizationMembershipDataItem: S.Schema<PaginatedOrganizationMembershipDataItem>;
export type PaginatedOrganizationMembershipDataList = Array<PaginatedOrganizationMembershipDataItem>;
export declare const PaginatedOrganizationMembershipDataList: S.Schema<PaginatedOrganizationMembershipDataList>;
export interface PaginatedOrganizationMembership {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedOrganizationMembershipDataList;
}
export declare const PaginatedOrganizationMembership: S.Schema<PaginatedOrganizationMembership>;
export interface ListOrganizationsRequest {
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListOrganizationsRequest: S.Schema<ListOrganizationsRequest>;
/** Features that can be enabled on the organization */
export type PaginatedOrganizationDataItemFeaturesMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedOrganizationDataItemFeaturesMap: S.Schema<PaginatedOrganizationDataItemFeaturesMap>;
export interface PaginatedOrganizationDataItem {
    /** The ID for the organization */
    id: string;
    /** The name of the organization */
    name: string;
    /** The billing email of the organization */
    billing_email: string;
    /** When the organization was created */
    created_at: string;
    /** When the organization was last updated */
    updated_at: string;
    /** The billing plan of the organization */
    plan: string;
    /** Whether or not the organization's billing information is valid */
    valid_billing_info: boolean;
    /** Whether or not SSO is enabled on the organization */
    sso: boolean;
    /** Whether or not the organization uses an SSO directory */
    sso_directory: boolean;
    /** Whether or not the organization has single tenancy enabled */
    single_tenancy: boolean;
    /** Whether or not the organization has managed tenancy enabled */
    managed_tenancy: boolean;
    /** Whether or not the organization has past due billing invoices. */
    has_past_due_invoices?: boolean | null;
    /** The number of databases in the organization */
    database_count: number;
    /** The URL of the organization's SSO portal. */
    sso_portal_url?: string | null;
    /** Features that can be enabled on the organization */
    features: PaginatedOrganizationDataItemFeaturesMap;
    /** Whether or not the IdP provider is be responsible for managing roles in PlanetScale */
    idp_managed_roles: boolean;
    /** The expected monthly budget for the organization */
    invoice_budget_amount: string;
    /** The keyspace shard limit for the organization */
    keyspace_shard_limit: number;
    /** Whether or not the organization has a payment method on file */
    has_card: boolean;
    /** Whether or not the organization requires payment information */
    payment_info_required: boolean;
}
export declare const PaginatedOrganizationDataItem: S.Schema<PaginatedOrganizationDataItem>;
export type PaginatedOrganizationDataList = Array<PaginatedOrganizationDataItem>;
export declare const PaginatedOrganizationDataList: S.Schema<PaginatedOrganizationDataList>;
export interface PaginatedOrganization {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedOrganizationDataList;
}
export declare const PaginatedOrganization: S.Schema<PaginatedOrganization>;
export interface ListOrganizationSsoDomainsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const ListOrganizationSsoDomainsRequest: S.Schema<ListOrganizationSsoDomainsRequest>;
export type ListOrganizationSsoDomainsResponseBodyList = Array<OrganizationDomain>;
export declare const ListOrganizationSsoDomainsResponseBodyList: S.Schema<ListOrganizationSsoDomainsResponseBodyList>;
export type ListOrganizationSsoDomainsResponse = ListOrganizationSsoDomainsResponseBodyList;
export declare const ListOrganizationSsoDomainsResponse: S.Schema<ListOrganizationSsoDomainsResponse>;
export interface ListOrganizationTeamMembersRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListOrganizationTeamMembersRequest: S.Schema<ListOrganizationTeamMembersRequest>;
export type PaginatedOrganizationTeamMembershipDataItemUserDefaultOrganization = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedOrganizationTeamMembershipDataItemUserDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedOrganizationTeamMembershipDataItemUser = OrganizationTeamMembershipUser;
export declare const PaginatedOrganizationTeamMembershipDataItemUser: S.Schema<OrganizationTeamMembershipUser>;
export type PaginatedOrganizationTeamMembershipDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedOrganizationTeamMembershipDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** The role for the password */
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemRole = "reader" | "writer" | "admin" | "readwriter";
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemRole: any;
/** List of IP addresses or CIDR ranges that can use this password */
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemCidrsList = Array<string>;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemCidrsList: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsItemCidrsList>;
/** The list of hosts in each availability zone providing direct access to a vtgate */
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemDirectVtgateAddressesList = Array<string>;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemDirectVtgateAddressesList: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsItemDirectVtgateAddressesList>;
/** The read-only replica host URLs */
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemAccessHostRegionalUrlsList = Array<string>;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemAccessHostRegionalUrlsList: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsItemAccessHostRegionalUrlsList>;
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegionPublicIpAddressesList = Array<string>;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegionPublicIpAddressesList: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegionPublicIpAddressesList>;
export interface PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegion: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegion>;
export type PaginatedOrganizationTeamMembershipDataItemPasswordsItemDatabaseBranch = OrganizationTeamMembershipPasswordsItemDatabaseBranch;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItemDatabaseBranch: S.Schema<OrganizationTeamMembershipPasswordsItemDatabaseBranch>;
export interface PaginatedOrganizationTeamMembershipDataItemPasswordsItem {
    /** The ID for the password */
    id: string;
    /** The display name for the password */
    name: string;
    /** The role for the password */
    role: PaginatedOrganizationTeamMembershipDataItemPasswordsItemRole;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs: PaginatedOrganizationTeamMembershipDataItemPasswordsItemCidrsList | null;
    /** When the password was created */
    created_at: string;
    /** When the password was deleted */
    deleted_at: string | null;
    /** When the password will expire */
    expires_at: string | null;
    /** When the password was last used to execute a query */
    last_used_at: string | null;
    /** True if the credentials are expired */
    expired: boolean;
    /** True if the credentials connect directly to a vtgate, bypassing load balancers */
    direct_vtgate: boolean;
    /** The list of hosts in each availability zone providing direct access to a vtgate */
    direct_vtgate_addresses: PaginatedOrganizationTeamMembershipDataItemPasswordsItemDirectVtgateAddressesList;
    /** Time to live (in seconds) for the password. The password will be invalid when TTL has passed */
    ttl_seconds: number | null;
    /** The host URL for the password */
    access_host_url: string;
    /** The regional host URL */
    access_host_regional_url: string;
    /** The read-only replica host URLs */
    access_host_regional_urls: PaginatedOrganizationTeamMembershipDataItemPasswordsItemAccessHostRegionalUrlsList;
    actor: OrganizationTeamMembershipActor | null;
    region: PaginatedOrganizationTeamMembershipDataItemPasswordsItemRegion;
    /** The username for the password */
    username: string;
    /** The plaintext password. Null except in the response from the create endpoint. */
    plain_text: Redacted.Redacted<string> | null;
    /** Whether or not the password is for a read replica */
    replica: boolean;
    /** Whether or not the password is scoped to a read-only region */
    read_only_region: boolean;
    /** Whether or not the password can be renewed */
    renewable: boolean;
    database_branch: OrganizationTeamMembershipPasswordsItemDatabaseBranch;
}
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsItem: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsItem>;
export type PaginatedOrganizationTeamMembershipDataItemPasswordsList = Array<PaginatedOrganizationTeamMembershipDataItemPasswordsItem>;
export declare const PaginatedOrganizationTeamMembershipDataItemPasswordsList: S.Schema<PaginatedOrganizationTeamMembershipDataItemPasswordsList>;
export interface PaginatedOrganizationTeamMembershipDataItem {
    /** The ID of the team membership */
    id: string;
    user: OrganizationTeamMembershipUser;
    actor: OrganizationTeamMembershipActor;
    /** When the membership was created */
    created_at: string;
    /** When the membership was last updated */
    updated_at: string;
    passwords: PaginatedOrganizationTeamMembershipDataItemPasswordsList;
}
export declare const PaginatedOrganizationTeamMembershipDataItem: S.Schema<PaginatedOrganizationTeamMembershipDataItem>;
export type PaginatedOrganizationTeamMembershipDataList = Array<PaginatedOrganizationTeamMembershipDataItem>;
export declare const PaginatedOrganizationTeamMembershipDataList: S.Schema<PaginatedOrganizationTeamMembershipDataList>;
export interface PaginatedOrganizationTeamMembership {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedOrganizationTeamMembershipDataList;
}
export declare const PaginatedOrganizationTeamMembership: S.Schema<PaginatedOrganizationTeamMembership>;
export interface ListOrganizationTeamsRequest {
    /** The name of the organization */
    organization: string;
    /** Search term to filter teams by name */
    q?: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListOrganizationTeamsRequest: S.Schema<ListOrganizationTeamsRequest>;
export type PaginatedOrganizationTeamDataItemCreator = OrganizationTeamMembershipActor;
export declare const PaginatedOrganizationTeamDataItemCreator: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedOrganizationTeamDataItemMembersItemDefaultOrganization = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedOrganizationTeamDataItemMembersItemDefaultOrganization: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedOrganizationTeamDataItemMembersItem = OrganizationTeamMembershipUser;
export declare const PaginatedOrganizationTeamDataItemMembersItem: S.Schema<OrganizationTeamMembershipUser>;
export type PaginatedOrganizationTeamDataItemMembersList = Array<OrganizationTeamMembershipUser>;
export declare const PaginatedOrganizationTeamDataItemMembersList: S.Schema<PaginatedOrganizationTeamDataItemMembersList>;
export type PaginatedOrganizationTeamDataItemDatabasesItem = OrganizationTeamDatabasesItem;
export declare const PaginatedOrganizationTeamDataItemDatabasesItem: S.Schema<OrganizationTeamDatabasesItem>;
export type PaginatedOrganizationTeamDataItemDatabasesList = Array<OrganizationTeamDatabasesItem>;
export declare const PaginatedOrganizationTeamDataItemDatabasesList: S.Schema<PaginatedOrganizationTeamDataItemDatabasesList>;
export type PaginatedOrganizationTeamDataItemAnalystDatabasesItem = OrganizationTeamDatabasesItem;
export declare const PaginatedOrganizationTeamDataItemAnalystDatabasesItem: S.Schema<OrganizationTeamDatabasesItem>;
export type PaginatedOrganizationTeamDataItemAnalystDatabasesList = Array<OrganizationTeamDatabasesItem>;
export declare const PaginatedOrganizationTeamDataItemAnalystDatabasesList: S.Schema<PaginatedOrganizationTeamDataItemAnalystDatabasesList>;
export interface PaginatedOrganizationTeamDataItem {
    /** The ID of the team */
    id: string;
    /** The display name of the team */
    display_name: string;
    creator: OrganizationTeamMembershipActor;
    members: PaginatedOrganizationTeamDataItemMembersList;
    databases: PaginatedOrganizationTeamDataItemDatabasesList;
    analyst_databases: PaginatedOrganizationTeamDataItemAnalystDatabasesList;
    /** The name of the team */
    name: string;
    /** The slug of the team */
    slug: string;
    /** When the team was created */
    created_at: string;
    /** When the team was last updated */
    updated_at: string;
    /** The description of the team */
    description: string | null;
    /** Whether the team is managed through SSO/directory services */
    managed: boolean;
}
export declare const PaginatedOrganizationTeamDataItem: S.Schema<PaginatedOrganizationTeamDataItem>;
export type PaginatedOrganizationTeamDataList = Array<PaginatedOrganizationTeamDataItem>;
export declare const PaginatedOrganizationTeamDataList: S.Schema<PaginatedOrganizationTeamDataList>;
export interface PaginatedOrganizationTeam {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedOrganizationTeamDataList;
}
export declare const PaginatedOrganizationTeam: S.Schema<PaginatedOrganizationTeam>;
export interface ListParametersRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const ListParametersRequest: S.Schema<ListParametersRequest>;
/** The namespace of the parameter */
export type PostgresClusterParameterNamespace = "patroni" | "pgconf" | "pgbouncer";
export declare const PostgresClusterParameterNamespace: any;
/** The type of the parameter */
export type PostgresClusterParameterParameterType = "array" | "boolean" | "bytes" | "float" | "integer" | "seconds" | "select" | "string" | "time";
export declare const PostgresClusterParameterParameterType: any;
/** Valid options for the parameter value */
export type PostgresClusterParameterOptionsList = Array<string>;
export declare const PostgresClusterParameterOptionsList: S.Schema<PostgresClusterParameterOptionsList>;
export type PostgresClusterParameterActor = OrganizationTeamMembershipActor;
export declare const PostgresClusterParameterActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PostgresClusterParameter {
    /** The ID of the parameter */
    id: string;
    /** The name of the parameter */
    name: string;
    /** The display name of the parameter */
    display_name: string;
    /** The namespace of the parameter */
    namespace: PostgresClusterParameterNamespace;
    /** The category of the parameter */
    category: string;
    /** The description of the parameter */
    description: string;
    /** Configures an extension */
    extension: boolean;
    /** Whether the parameter can be changed */
    immutable: boolean;
    /** The type of the parameter */
    parameter_type: PostgresClusterParameterParameterType;
    /** The default value of the parameter */
    default_value: string;
    /** The configured value of the parameter */
    value: string;
    /** Whether the parameter is required */
    required: boolean;
    /** When the parameter was created */
    created_at: string;
    /** When the parameter was last updated */
    updated_at: string;
    /** True if processes require a server restart on change */
    restart: boolean;
    /** The maximum value of the parameter */
    max: number;
    /** The minimum value of the parameter */
    min: number;
    /** The URL of the parameter */
    url: string;
    /** Valid options for the parameter value */
    options: PostgresClusterParameterOptionsList;
    actor: OrganizationTeamMembershipActor;
}
export declare const PostgresClusterParameter: S.Schema<PostgresClusterParameter>;
export type ListParametersResponseBodyList = Array<PostgresClusterParameter>;
export declare const ListParametersResponseBodyList: S.Schema<ListParametersResponseBodyList>;
export type ListParametersResponse = ListParametersResponseBodyList;
export declare const ListParametersResponse: S.Schema<ListParametersResponse>;
export interface ListPasswordsRequest {
    /** The name of the organization the password belongs to */
    organization: string;
    /** The name of the database the password belongs to */
    database: string;
    /** The name of the branch the password belongs to */
    branch: string;
    /** A read-only region of the database branch. If present, the password results will be filtered to only those in the region */
    read_only_region_id?: string;
    /** Filter passwords by status */
    status?: string;
    /** Search passwords by name */
    q?: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListPasswordsRequest: S.Schema<ListPasswordsRequest>;
/** The role for the password */
export type PaginatedDatabaseBranchPasswordDataItemRole = "reader" | "writer" | "admin" | "readwriter";
export declare const PaginatedDatabaseBranchPasswordDataItemRole: any;
/** List of IP addresses or CIDR ranges that can use this password */
export type PaginatedDatabaseBranchPasswordDataItemCidrsList = Array<string>;
export declare const PaginatedDatabaseBranchPasswordDataItemCidrsList: S.Schema<PaginatedDatabaseBranchPasswordDataItemCidrsList>;
/** The list of hosts in each availability zone providing direct access to a vtgate */
export type PaginatedDatabaseBranchPasswordDataItemDirectVtgateAddressesList = Array<string>;
export declare const PaginatedDatabaseBranchPasswordDataItemDirectVtgateAddressesList: S.Schema<PaginatedDatabaseBranchPasswordDataItemDirectVtgateAddressesList>;
/** The read-only replica host URLs */
export type PaginatedDatabaseBranchPasswordDataItemAccessHostRegionalUrlsList = Array<string>;
export declare const PaginatedDatabaseBranchPasswordDataItemAccessHostRegionalUrlsList: S.Schema<PaginatedDatabaseBranchPasswordDataItemAccessHostRegionalUrlsList>;
export type PaginatedDatabaseBranchPasswordDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseBranchPasswordDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type PaginatedDatabaseBranchPasswordDataItemRegionPublicIpAddressesList = Array<string>;
export declare const PaginatedDatabaseBranchPasswordDataItemRegionPublicIpAddressesList: S.Schema<PaginatedDatabaseBranchPasswordDataItemRegionPublicIpAddressesList>;
export interface PaginatedDatabaseBranchPasswordDataItemRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PaginatedDatabaseBranchPasswordDataItemRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PaginatedDatabaseBranchPasswordDataItemRegion: S.Schema<PaginatedDatabaseBranchPasswordDataItemRegion>;
export type PaginatedDatabaseBranchPasswordDataItemDatabaseBranch = OrganizationTeamMembershipPasswordsItemDatabaseBranch;
export declare const PaginatedDatabaseBranchPasswordDataItemDatabaseBranch: S.Schema<OrganizationTeamMembershipPasswordsItemDatabaseBranch>;
export interface PaginatedDatabaseBranchPasswordDataItem {
    /** The ID for the password */
    id: string;
    /** The display name for the password */
    name: string;
    /** The role for the password */
    role: PaginatedDatabaseBranchPasswordDataItemRole;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs: PaginatedDatabaseBranchPasswordDataItemCidrsList | null;
    /** When the password was created */
    created_at: string;
    /** When the password was deleted */
    deleted_at: string | null;
    /** When the password will expire */
    expires_at: string | null;
    /** When the password was last used to execute a query */
    last_used_at: string | null;
    /** True if the credentials are expired */
    expired: boolean;
    /** True if the credentials connect directly to a vtgate, bypassing load balancers */
    direct_vtgate: boolean;
    /** The list of hosts in each availability zone providing direct access to a vtgate */
    direct_vtgate_addresses: PaginatedDatabaseBranchPasswordDataItemDirectVtgateAddressesList;
    /** Time to live (in seconds) for the password. The password will be invalid when TTL has passed */
    ttl_seconds: number | null;
    /** The host URL for the password */
    access_host_url: string;
    /** The regional host URL */
    access_host_regional_url: string;
    /** The read-only replica host URLs */
    access_host_regional_urls: PaginatedDatabaseBranchPasswordDataItemAccessHostRegionalUrlsList;
    actor: OrganizationTeamMembershipActor | null;
    region: PaginatedDatabaseBranchPasswordDataItemRegion;
    /** The username for the password */
    username: string;
    /** The plaintext password. Null except in the response from the create endpoint. */
    plain_text: Redacted.Redacted<string> | null;
    /** Whether or not the password is for a read replica */
    replica: boolean;
    /** Whether or not the password is scoped to a read-only region */
    read_only_region: boolean;
    /** Whether or not the password can be renewed */
    renewable: boolean;
    database_branch: OrganizationTeamMembershipPasswordsItemDatabaseBranch;
}
export declare const PaginatedDatabaseBranchPasswordDataItem: S.Schema<PaginatedDatabaseBranchPasswordDataItem>;
export type PaginatedDatabaseBranchPasswordDataList = Array<PaginatedDatabaseBranchPasswordDataItem>;
export declare const PaginatedDatabaseBranchPasswordDataList: S.Schema<PaginatedDatabaseBranchPasswordDataList>;
export interface PaginatedDatabaseBranchPassword {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedDatabaseBranchPasswordDataList;
}
export declare const PaginatedDatabaseBranchPassword: S.Schema<PaginatedDatabaseBranchPassword>;
export interface ListPublicRegionsRequest {
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListPublicRegionsRequest: S.Schema<ListPublicRegionsRequest>;
/** List of public IP addresses for the region */
export type PaginatedPublicPlanetscaleRegionSerializerDataItemPublicIpAddressesList = Array<string>;
export declare const PaginatedPublicPlanetscaleRegionSerializerDataItemPublicIpAddressesList: S.Schema<PaginatedPublicPlanetscaleRegionSerializerDataItemPublicIpAddressesList>;
export interface PaginatedPublicPlanetscaleRegionSerializerDataItem {
    /** The ID of the region */
    id: string;
    /** The cloud provider for the region */
    provider: string;
    /** Whether new clusters can be created in this region */
    enabled: boolean;
    /** List of public IP addresses for the region */
    public_ip_addresses: PaginatedPublicPlanetscaleRegionSerializerDataItemPublicIpAddressesList;
    /** The name of the region */
    display_name: string;
    /** The location of the region */
    location: string;
    /** The slug identifier for the region */
    slug: string;
}
export declare const PaginatedPublicPlanetscaleRegionSerializerDataItem: S.Schema<PaginatedPublicPlanetscaleRegionSerializerDataItem>;
export type PaginatedPublicPlanetscaleRegionSerializerDataList = Array<PaginatedPublicPlanetscaleRegionSerializerDataItem>;
export declare const PaginatedPublicPlanetscaleRegionSerializerDataList: S.Schema<PaginatedPublicPlanetscaleRegionSerializerDataList>;
export interface PaginatedPublicPlanetscaleRegionSerializer {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPublicPlanetscaleRegionSerializerDataList;
}
export declare const PaginatedPublicPlanetscaleRegionSerializer: S.Schema<PaginatedPublicPlanetscaleRegionSerializer>;
export interface ListReadOnlyRegionsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListReadOnlyRegionsRequest: S.Schema<ListReadOnlyRegionsRequest>;
export type PaginatedDatabaseBranchReadOnlyRegionDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedDatabaseBranchReadOnlyRegionDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** Public IP addresses for the region */
export type PaginatedDatabaseBranchReadOnlyRegionDataItemRegionPublicIpAddressesList = Array<string>;
export declare const PaginatedDatabaseBranchReadOnlyRegionDataItemRegionPublicIpAddressesList: S.Schema<PaginatedDatabaseBranchReadOnlyRegionDataItemRegionPublicIpAddressesList>;
export interface PaginatedDatabaseBranchReadOnlyRegionDataItemRegion {
    /** The ID of the region */
    id: string;
    /** Provider for the region (ex. AWS) */
    provider: string;
    /** Whether or not the region is currently active */
    enabled: boolean;
    /** Public IP addresses for the region */
    public_ip_addresses: PaginatedDatabaseBranchReadOnlyRegionDataItemRegionPublicIpAddressesList;
    /** Name of the region */
    display_name: string;
    /** Location of the region */
    location: string;
    /** The slug of the region */
    slug: string;
    /** True if the region is the default for new branch creation */
    current_default: boolean;
    /** Whether the region supports MySQL/Vitess databases */
    mysql_supported: boolean;
    /** Whether the region supports PostgreSQL databases */
    postgresql_supported: boolean;
}
export declare const PaginatedDatabaseBranchReadOnlyRegionDataItemRegion: S.Schema<PaginatedDatabaseBranchReadOnlyRegionDataItemRegion>;
export interface PaginatedDatabaseBranchReadOnlyRegionDataItem {
    /** The ID of the read-only region */
    id: string;
    /** The name of the read-only region */
    display_name: string;
    /** When the read-only region was created */
    created_at: string;
    /** When the read-only region was last updated */
    updated_at: string;
    /** When the read-only region was ready to serve queries */
    ready_at: string | null;
    /** Whether or not the read-only region is ready to serve queries */
    ready: boolean;
    actor: OrganizationTeamMembershipActor;
    region: PaginatedDatabaseBranchReadOnlyRegionDataItemRegion;
}
export declare const PaginatedDatabaseBranchReadOnlyRegionDataItem: S.Schema<PaginatedDatabaseBranchReadOnlyRegionDataItem>;
export type PaginatedDatabaseBranchReadOnlyRegionDataList = Array<PaginatedDatabaseBranchReadOnlyRegionDataItem>;
export declare const PaginatedDatabaseBranchReadOnlyRegionDataList: S.Schema<PaginatedDatabaseBranchReadOnlyRegionDataList>;
export interface PaginatedDatabaseBranchReadOnlyRegion {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDatabaseBranchReadOnlyRegionDataList;
}
export declare const PaginatedDatabaseBranchReadOnlyRegion: S.Schema<PaginatedDatabaseBranchReadOnlyRegion>;
export type ListReadOnlyReplicaChangeRequestsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListReadOnlyReplicaChangeRequestsRequestPeriod: any;
export interface ListReadOnlyReplicaChangeRequestsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
    /** Filter change requests by named period */
    period?: ListReadOnlyReplicaChangeRequestsRequestPeriod | (string & {});
    /** Filter change requests completed between two ISO 8601 timestamps */
    completed_at?: string;
}
export declare const ListReadOnlyReplicaChangeRequestsRequest: S.Schema<ListReadOnlyReplicaChangeRequestsRequest>;
/** The state of the change request */
export type PaginatedPostgresReadOnlyReplicaChangeRequestDataItemState = "pending" | "resizing" | "canceled" | "completed";
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataItemState: any;
/** The new parameters */
export type PaginatedPostgresReadOnlyReplicaChangeRequestDataItemParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataItemParametersMap: S.Schema<PaginatedPostgresReadOnlyReplicaChangeRequestDataItemParametersMap>;
/** The previous parameters */
export type PaginatedPostgresReadOnlyReplicaChangeRequestDataItemPreviousParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataItemPreviousParametersMap: S.Schema<PaginatedPostgresReadOnlyReplicaChangeRequestDataItemPreviousParametersMap>;
export type PaginatedPostgresReadOnlyReplicaChangeRequestDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedPostgresReadOnlyReplicaChangeRequestDataItemReplica = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataItemReplica: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface PaginatedPostgresReadOnlyReplicaChangeRequestDataItem {
    /** The ID of the read-only replica change request */
    id: string;
    /** The state of the change request */
    state: PaginatedPostgresReadOnlyReplicaChangeRequestDataItemState;
    /** The new cluster size SKU */
    cluster_name: string;
    /** The new cluster size for display */
    cluster_display_name: string;
    /** The new cluster size sort order */
    cluster_rank: number;
    /** The new instance count */
    replicas: number;
    /** The new parameters */
    parameters: PaginatedPostgresReadOnlyReplicaChangeRequestDataItemParametersMap;
    /** The previous cluster size SKU */
    previous_cluster_name: string;
    /** The previous cluster size for display */
    previous_cluster_display_name: string;
    /** The previous cluster size sort order */
    previous_cluster_rank: number;
    /** The previous instance count */
    previous_replicas: number;
    /** The previous parameters */
    previous_parameters: PaginatedPostgresReadOnlyReplicaChangeRequestDataItemPreviousParametersMap;
    /** When the change started */
    started_at: string | null;
    /** When the change completed */
    completed_at: string | null;
    /** When the change request was created */
    created_at: string;
    /** When the change request was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
    replica: OrganizationTeamMembershipUserDefaultOrganization;
}
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataItem: S.Schema<PaginatedPostgresReadOnlyReplicaChangeRequestDataItem>;
export type PaginatedPostgresReadOnlyReplicaChangeRequestDataList = Array<PaginatedPostgresReadOnlyReplicaChangeRequestDataItem>;
export declare const PaginatedPostgresReadOnlyReplicaChangeRequestDataList: S.Schema<PaginatedPostgresReadOnlyReplicaChangeRequestDataList>;
export interface PaginatedPostgresReadOnlyReplicaChangeRequest {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPostgresReadOnlyReplicaChangeRequestDataList;
}
export declare const PaginatedPostgresReadOnlyReplicaChangeRequest: S.Schema<PaginatedPostgresReadOnlyReplicaChangeRequest>;
export interface ListReadOnlyReplicasRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const ListReadOnlyReplicasRequest: S.Schema<ListReadOnlyReplicasRequest>;
export type ListReadOnlyReplicasResponseBodyList = Array<PostgresReadOnlyReplica>;
export declare const ListReadOnlyReplicasResponseBodyList: S.Schema<ListReadOnlyReplicasResponseBodyList>;
export type ListReadOnlyReplicasResponse = ListReadOnlyReplicasResponseBodyList;
export declare const ListReadOnlyReplicasResponse: S.Schema<ListReadOnlyReplicasResponse>;
export interface ListRegionsForOrganizationRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListRegionsForOrganizationRequest: S.Schema<ListRegionsForOrganizationRequest>;
export interface ListRolesRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
    /** Filter roles by status */
    status?: string;
    /** Search roles by name or username */
    q?: string;
}
export declare const ListRolesRequest: S.Schema<ListRolesRequest>;
export type PaginatedPostgresRoleDataItemInheritedRolesItem = "pg_checkpoint" | "pg_create_subscription" | "pg_maintain" | "pg_monitor" | "pg_read_all_data" | "pg_read_all_settings" | "pg_read_all_stats" | "pg_signal_backend" | "pg_stat_scan_tables" | "pg_use_reserved_connections" | "pg_write_all_data" | "postgres";
export declare const PaginatedPostgresRoleDataItemInheritedRolesItem: any;
/** Database roles these credentials inherit */
export type PaginatedPostgresRoleDataItemInheritedRolesList = Array<PaginatedPostgresRoleDataItemInheritedRolesItem>;
export declare const PaginatedPostgresRoleDataItemInheritedRolesList: S.Schema<PaginatedPostgresRoleDataItemInheritedRolesList>;
export type PaginatedPostgresRoleDataItemBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedPostgresRoleDataItemBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedPostgresRoleDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresRoleDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** Require WHERE clause on DELETE statements */
export type PaginatedPostgresRoleDataItemQuerySafetySettingsRequireWhereOnDelete = "off" | "warn" | "on";
export declare const PaginatedPostgresRoleDataItemQuerySafetySettingsRequireWhereOnDelete: any;
/** Require WHERE clause on UPDATE statements */
export type PaginatedPostgresRoleDataItemQuerySafetySettingsRequireWhereOnUpdate = "off" | "warn" | "on";
export declare const PaginatedPostgresRoleDataItemQuerySafetySettingsRequireWhereOnUpdate: any;
export interface PaginatedPostgresRoleDataItemQuerySafetySettings {
    /** Require WHERE clause on DELETE statements */
    require_where_on_delete: PaginatedPostgresRoleDataItemQuerySafetySettingsRequireWhereOnDelete;
    /** Require WHERE clause on UPDATE statements */
    require_where_on_update: PaginatedPostgresRoleDataItemQuerySafetySettingsRequireWhereOnUpdate;
}
export declare const PaginatedPostgresRoleDataItemQuerySafetySettings: S.Schema<PaginatedPostgresRoleDataItemQuerySafetySettings>;
export interface PaginatedPostgresRoleDataItem {
    /** The ID of the role */
    id: string;
    /** The name of the role */
    name: string;
    /** The database connection string */
    access_host_url: string;
    /** The database connection string for private connections */
    private_access_host_url: string;
    /** The service name to set up private connectivity */
    private_connection_service_name: string;
    /** The database user name */
    username: string;
    /** The base username without branch routing suffix */
    base_username: string;
    /** The plaintext password, available only after create */
    password: Redacted.Redacted<string> | null;
    /** The database name */
    database_name: string;
    /** When the role was created */
    created_at: string;
    /** When the role was updated */
    updated_at: string;
    /** When the role was deleted */
    deleted_at: string | null;
    /** When the role expires */
    expires_at: string | null;
    /** When the role was dropped */
    dropped_at: string | null;
    /** When the role was disabled */
    disabled_at: string | null;
    /** Error message available when dropping the role fails */
    drop_failed: string | null;
    /** Whether the role is ready to accept connections */
    ready: boolean;
    /** True if the credentials are expired */
    expired: boolean;
    /** Whether the role is the default postgres user */
    default: boolean;
    /** Number of seconds before the credentials expire */
    ttl: number | null;
    /** Database roles these credentials inherit */
    inherited_roles: PaginatedPostgresRoleDataItemInheritedRolesList;
    /** Whether the role has the REPLICATION attribute */
    with_replication: boolean;
    branch: OrganizationTeamMembershipUserDefaultOrganization;
    actor: OrganizationTeamMembershipActor;
    query_safety_settings: PaginatedPostgresRoleDataItemQuerySafetySettings;
}
export declare const PaginatedPostgresRoleDataItem: S.Schema<PaginatedPostgresRoleDataItem>;
export type PaginatedPostgresRoleDataList = Array<PaginatedPostgresRoleDataItem>;
export declare const PaginatedPostgresRoleDataList: S.Schema<PaginatedPostgresRoleDataList>;
export interface PaginatedPostgresRole {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedPostgresRoleDataList;
}
export declare const PaginatedPostgresRole: S.Schema<PaginatedPostgresRole>;
export type ListSchemaRecommendationsRequestState = "open" | "closed";
export declare const ListSchemaRecommendationsRequestState: any;
export interface ListSchemaRecommendationsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Filter by recommendation state */
    state?: ListSchemaRecommendationsRequestState | (string & {});
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListSchemaRecommendationsRequest: S.Schema<ListSchemaRecommendationsRequest>;
/** The state of the recommendation */
export type PaginatedSchemaRecommendationDataItemState = "open" | "applied" | "dismissed" | "stale";
export declare const PaginatedSchemaRecommendationDataItemState: any;
/** The type of recommendation */
export type PaginatedSchemaRecommendationDataItemRecommendationType = "unused_table" | "unused_index" | "duplicate_index" | "sequence_overflow" | "sequence_overflow_foreign_key" | "new_index" | "encoding_upgrade" | "bloated_table" | "bloated_index";
export declare const PaginatedSchemaRecommendationDataItemRecommendationType: any;
export type PaginatedSchemaRecommendationDataItemClosedByDeployRequest = SchemaRecommendationClosedByDeployRequest;
export declare const PaginatedSchemaRecommendationDataItemClosedByDeployRequest: S.Schema<SchemaRecommendationClosedByDeployRequest>;
export type PaginatedSchemaRecommendationDataItemDismissedBy = OrganizationTeamMembershipActor;
export declare const PaginatedSchemaRecommendationDataItemDismissedBy: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedSchemaRecommendationDataItem {
    /** The ID of the schema recommendation */
    id: string;
    /** The URL to the schema recommendation in the app */
    html_url: string;
    /** The title of the schema recommendation */
    title: string;
    /** The name of the table the recommendation applies to */
    table_name: string;
    /** The keyspace the recommendation applies to */
    keyspace: string;
    /** The DDL statement to apply the recommendation */
    ddl_statement: string;
    /** The number of the schema recommendation */
    number: number;
    /** The state of the recommendation */
    state: PaginatedSchemaRecommendationDataItemState;
    /** The type of recommendation */
    recommendation_type: PaginatedSchemaRecommendationDataItemRecommendationType;
    /** When the recommendation was created */
    created_at: string;
    /** When the recommendation was last updated */
    updated_at: string;
    /** When the recommendation was applied */
    applied_at: string | null;
    /** When the recommendation was dismissed */
    dismissed_at: string | null;
    closed_by_deploy_request: SchemaRecommendationClosedByDeployRequest | null;
    dismissed_by: OrganizationTeamMembershipActor | null;
}
export declare const PaginatedSchemaRecommendationDataItem: S.Schema<PaginatedSchemaRecommendationDataItem>;
export type PaginatedSchemaRecommendationDataList = Array<PaginatedSchemaRecommendationDataItem>;
export declare const PaginatedSchemaRecommendationDataList: S.Schema<PaginatedSchemaRecommendationDataList>;
export interface PaginatedSchemaRecommendation {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    /** The total number of matching results */
    total_count: number;
    /** The total number of pages of matching results */
    total_pages: number;
    data: PaginatedSchemaRecommendationDataList;
}
export declare const PaginatedSchemaRecommendation: S.Schema<PaginatedSchemaRecommendation>;
export interface ListServiceTokensRequest {
    /** The name of the organization */
    organization: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListServiceTokensRequest: S.Schema<ListServiceTokensRequest>;
export interface ListSwitchoversRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListSwitchoversRequest: S.Schema<ListSwitchoversRequest>;
/** The state of the switchover */
export type PaginatedPostgresSwitchoverDataItemState = "pending" | "running" | "succeeded" | "failed" | "canceled";
export declare const PaginatedPostgresSwitchoverDataItemState: any;
/** How the primary was moved. `switchover` promotes a replica on a highly available branch; `restart` restarts the single instance of a branch that has no replicas. Absent until the operator selects one. */
export type PaginatedPostgresSwitchoverDataItemMethod = "switchover" | "restart";
export declare const PaginatedPostgresSwitchoverDataItemMethod: any;
export type PaginatedPostgresSwitchoverDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedPostgresSwitchoverDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedPostgresSwitchoverDataItem {
    /** The ID of the switchover */
    id: string;
    /** The state of the switchover */
    state: PaginatedPostgresSwitchoverDataItemState;
    /** How the primary was moved. `switchover` promotes a replica on a highly available branch; `restart` restarts the single instance of a branch that has no replicas. Absent until the operator selects one. */
    method?: PaginatedPostgresSwitchoverDataItemMethod | null;
    /** Why the switchover failed. A failed switchover has an unconfirmed outcome and does not imply the primary stayed put. */
    error?: string | null;
    /** When the switchover was requested */
    started_at: string | null;
    /** When the switchover finished */
    completed_at: string | null;
    /** When the switchover was created */
    created_at: string;
    /** When the switchover was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
}
export declare const PaginatedPostgresSwitchoverDataItem: S.Schema<PaginatedPostgresSwitchoverDataItem>;
export type PaginatedPostgresSwitchoverDataList = Array<PaginatedPostgresSwitchoverDataItem>;
export declare const PaginatedPostgresSwitchoverDataList: S.Schema<PaginatedPostgresSwitchoverDataList>;
export interface PaginatedPostgresSwitchover {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedPostgresSwitchoverDataList;
}
export declare const PaginatedPostgresSwitchover: S.Schema<PaginatedPostgresSwitchover>;
export type ListTrafficBudgetsRequestPeriod = "15m" | "1h" | "3h" | "6h" | "12h" | "1d" | "2d" | "7d" | "8d";
export declare const ListTrafficBudgetsRequestPeriod: any;
export interface ListTrafficBudgetsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
    /** Time period filter */
    period?: ListTrafficBudgetsRequestPeriod | (string & {});
    /** Filter by creation date range (format: 'start..end') */
    created_at?: string;
    /** Filter budgets by query fingerprint */
    fingerprint?: string;
}
export declare const ListTrafficBudgetsRequest: S.Schema<ListTrafficBudgetsRequest>;
/** The mode of the budget */
export type PaginatedTrafficBudgetDataItemMode = "enforce" | "warn" | "off";
export declare const PaginatedTrafficBudgetDataItemMode: any;
export type PaginatedTrafficBudgetDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedTrafficBudgetDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
/** The kind of rule */
export type PaginatedTrafficBudgetDataItemRulesItemKind = "match" | "each";
export declare const PaginatedTrafficBudgetDataItemRulesItemKind: any;
/** The source of this tag */
export type PaginatedTrafficBudgetDataItemRulesItemTagsItemSource = "sql" | "system";
export declare const PaginatedTrafficBudgetDataItemRulesItemTagsItemSource: any;
export interface PaginatedTrafficBudgetDataItemRulesItemTagsItem {
    /** The ID of the key for this tag */
    key_id: string;
    /** The key for this tag */
    key: string;
    /** The value for this tag */
    value: string;
    /** The source of this tag */
    source: PaginatedTrafficBudgetDataItemRulesItemTagsItemSource;
}
export declare const PaginatedTrafficBudgetDataItemRulesItemTagsItem: S.Schema<PaginatedTrafficBudgetDataItemRulesItemTagsItem>;
export type PaginatedTrafficBudgetDataItemRulesItemTagsList = Array<PaginatedTrafficBudgetDataItemRulesItemTagsItem>;
export declare const PaginatedTrafficBudgetDataItemRulesItemTagsList: S.Schema<PaginatedTrafficBudgetDataItemRulesItemTagsList>;
export type PaginatedTrafficBudgetDataItemRulesItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedTrafficBudgetDataItemRulesItemActor: S.Schema<OrganizationTeamMembershipActor>;
export interface PaginatedTrafficBudgetDataItemRulesItem {
    /** The ID of the traffic rule */
    id: string;
    /** The kind of rule */
    kind: PaginatedTrafficBudgetDataItemRulesItemKind;
    tags: PaginatedTrafficBudgetDataItemRulesItemTagsList;
    /** The query fingerprint targeted by this rule */
    fingerprint?: string | null;
    /** The keyspace of the fingerprint */
    keyspace?: string | null;
    actor: OrganizationTeamMembershipActor;
    /** Syntax highlighted SQL for rules with SQL keys */
    syntax_highlighted_sql: string;
    /** When the rule was created */
    created_at: string;
    /** When the rule was updated */
    updated_at: string;
}
export declare const PaginatedTrafficBudgetDataItemRulesItem: S.Schema<PaginatedTrafficBudgetDataItemRulesItem>;
export type PaginatedTrafficBudgetDataItemRulesList = Array<PaginatedTrafficBudgetDataItemRulesItem>;
export declare const PaginatedTrafficBudgetDataItemRulesList: S.Schema<PaginatedTrafficBudgetDataItemRulesList>;
export interface PaginatedTrafficBudgetDataItem {
    /** The ID of the traffic budget */
    id: string;
    /** The name of the budget */
    name: string;
    /** The mode of the budget */
    mode: PaginatedTrafficBudgetDataItemMode;
    /** The maximum capacity that can be banked, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    capacity?: number | null;
    /** The rate at which capacity refills, as a percentage of server resources (0-100). Unlimited when not set. */
    rate?: number | null;
    /** The maximum capacity a single query can consume, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    burst?: number | null;
    /** The percentage of available worker processes this policy can use (0-100). Unlimited when not set. */
    concurrency?: number | null;
    /** A percentage of capacity, burst, or concurrency thresholds to emit warnings for enforced budgets (0-100). */
    warning_threshold?: number | null;
    actor: OrganizationTeamMembershipActor;
    rules: PaginatedTrafficBudgetDataItemRulesList;
    /** When the budget was created */
    created_at: string;
    /** When the budget was updated */
    updated_at: string;
}
export declare const PaginatedTrafficBudgetDataItem: S.Schema<PaginatedTrafficBudgetDataItem>;
export type PaginatedTrafficBudgetDataList = Array<PaginatedTrafficBudgetDataItem>;
export declare const PaginatedTrafficBudgetDataList: S.Schema<PaginatedTrafficBudgetDataList>;
export interface PaginatedTrafficBudget {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedTrafficBudgetDataList;
}
export declare const PaginatedTrafficBudget: S.Schema<PaginatedTrafficBudget>;
export interface ListTrafficBudgetsForQueryRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The query fingerprint */
    fingerprint: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
    /** Optional keyspace filter */
    keyspace?: string;
}
export declare const ListTrafficBudgetsForQueryRequest: S.Schema<ListTrafficBudgetsForQueryRequest>;
export interface ListWebhooksRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the database */
    database: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListWebhooksRequest: S.Schema<ListWebhooksRequest>;
export type PaginatedDatabaseWebhookDataItemEventsItem = "branch.ready" | "branch.anomaly" | "branch.out_of_memory" | "branch.primary_promoted" | "branch.primary_switchover_imminent" | "branch.schema_recommendation" | "branch.sleeping" | "branch.start_maintenance" | "backup.failed" | "backup.succeeded" | "cluster.storage" | "database.access_request" | "deploy_request.closed" | "deploy_request.errored" | "deploy_request.in_progress" | "deploy_request.opened" | "deploy_request.pending_cutover" | "deploy_request.queued" | "deploy_request.reverted" | "deploy_request.schema_applied" | "keyspace.storage" | "webhook.test";
export declare const PaginatedDatabaseWebhookDataItemEventsItem: any;
/** The events this webhook subscribes to */
export type PaginatedDatabaseWebhookDataItemEventsList = Array<PaginatedDatabaseWebhookDataItemEventsItem>;
export declare const PaginatedDatabaseWebhookDataItemEventsList: S.Schema<PaginatedDatabaseWebhookDataItemEventsList>;
export interface PaginatedDatabaseWebhookDataItem {
    /** The ID of the webhook */
    id: string;
    /** The URL the webhook will send events to */
    url: string;
    /** The secret used to sign the webhook payloads */
    secret: Redacted.Redacted<string>;
    /** Whether the webhook is enabled */
    enabled: boolean;
    /** The last result sent by the webhook */
    last_sent_result: string | null;
    /** Whether the last sent was successful */
    last_sent_success: boolean | null;
    /** When the last event was sent */
    last_sent_at: string | null;
    /** When the webhook was created */
    created_at: string;
    /** When the webhook was updated */
    updated_at: string;
    /** The events this webhook subscribes to */
    events: PaginatedDatabaseWebhookDataItemEventsList;
}
export declare const PaginatedDatabaseWebhookDataItem: S.Schema<PaginatedDatabaseWebhookDataItem>;
export type PaginatedDatabaseWebhookDataList = Array<PaginatedDatabaseWebhookDataItem>;
export declare const PaginatedDatabaseWebhookDataList: S.Schema<PaginatedDatabaseWebhookDataList>;
export interface PaginatedDatabaseWebhook {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedDatabaseWebhookDataList;
}
export declare const PaginatedDatabaseWebhook: S.Schema<PaginatedDatabaseWebhook>;
export interface ListWorkflowsRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** Filter workflows to those active during a time range (e.g. 2025-01-01T00:00:00Z..2025-01-01T23:59:59) */
    between?: string;
    /** If provided, specifies the page offset of returned results */
    page?: number;
    /** If provided, specifies the number of returned results */
    per_page?: number;
}
export declare const ListWorkflowsRequest: S.Schema<ListWorkflowsRequest>;
/** The state of the workflow */
export type PaginatedWorkflowDataItemState = "pending" | "copying" | "running" | "stopped" | "verifying_data" | "verified_data" | "switching_replicas" | "switched_replicas" | "switching_primaries" | "switched_primaries" | "reversing_traffic" | "reversing_traffic_for_cancel" | "cutting_over" | "cutover" | "reversed_cutover" | "completed" | "cancelling" | "cancelled" | "error";
export declare const PaginatedWorkflowDataItemState: any;
/** The type of the workflow */
export type PaginatedWorkflowDataItemWorkflowType = "move_tables";
export declare const PaginatedWorkflowDataItemWorkflowType: any;
/** The behavior when DDL changes during the workflow */
export type PaginatedWorkflowDataItemOnDdl = "IGNORE" | "STOP" | "EXEC" | "EXEC_IGNORE";
export declare const PaginatedWorkflowDataItemOnDdl: any;
export type PaginatedWorkflowDataItemActor = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemActor: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemVerifyDataBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemVerifyDataBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemReversedBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemReversedBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemSwitchReplicasBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemSwitchReplicasBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemSwitchPrimariesBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemSwitchPrimariesBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemCancelledBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemCancelledBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemCompletedBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemCompletedBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemRetriedBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemRetriedBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemCutoverBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemCutoverBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemReversedCutoverBy = OrganizationTeamMembershipActor;
export declare const PaginatedWorkflowDataItemReversedCutoverBy: S.Schema<OrganizationTeamMembershipActor>;
export type PaginatedWorkflowDataItemBranch = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedWorkflowDataItemBranch: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedWorkflowDataItemSourceKeyspace = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedWorkflowDataItemSourceKeyspace: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedWorkflowDataItemTargetKeyspace = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedWorkflowDataItemTargetKeyspace: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PaginatedWorkflowDataItemGlobalKeyspace = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PaginatedWorkflowDataItemGlobalKeyspace: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export interface PaginatedWorkflowDataItem {
    /** The ID of the workflow */
    id: string;
    /** The name of the workflow */
    name: string;
    /** The sequence number of the workflow */
    number: number;
    /** The state of the workflow */
    state: PaginatedWorkflowDataItemState;
    /** When the workflow was created */
    created_at: string;
    /** When the workflow was last updated */
    updated_at: string;
    /** When the workflow was started */
    started_at: string | null;
    /** When the workflow was completed */
    completed_at: string | null;
    /** When the workflow was cancelled */
    cancelled_at: string | null;
    /** When the workflow was reversed */
    reversed_at: string | null;
    /** When the workflow was retried */
    retried_at: string | null;
    /** When the data copy was completed */
    data_copy_completed_at: string | null;
    /** When the cutover was completed */
    cutover_at: string | null;
    /** Whether or not the replicas have been switched */
    replicas_switched: boolean;
    /** Whether or not the primaries have been switched */
    primaries_switched: boolean;
    /** When the replicas were switched */
    switch_replicas_at: string | null;
    /** When the primaries were switched */
    switch_primaries_at: string | null;
    /** When the data was verified */
    verify_data_at: string | null;
    /** The type of the workflow */
    workflow_type: PaginatedWorkflowDataItemWorkflowType;
    /** The subtype of the workflow */
    workflow_subtype: string;
    /** Whether or not secondary keys are deferred */
    defer_secondary_keys: boolean;
    /** The behavior when DDL changes during the workflow */
    on_ddl: PaginatedWorkflowDataItemOnDdl;
    /** The errors that occurred during the workflow */
    workflow_errors: string;
    /** Whether or not the workflow may be retried */
    may_retry: boolean;
    /** Whether or not the workflow may be restarted */
    may_restart: boolean;
    /** Whether or not the verified data is stale */
    verified_data_stale: boolean;
    /** Whether or not sequence tables have been created */
    sequence_tables_applied: boolean;
    actor: OrganizationTeamMembershipActor;
    verify_data_by: OrganizationTeamMembershipActor;
    reversed_by: OrganizationTeamMembershipActor;
    switch_replicas_by: OrganizationTeamMembershipActor;
    switch_primaries_by: OrganizationTeamMembershipActor;
    cancelled_by: OrganizationTeamMembershipActor;
    completed_by: OrganizationTeamMembershipActor;
    retried_by: OrganizationTeamMembershipActor;
    cutover_by: OrganizationTeamMembershipActor;
    reversed_cutover_by: OrganizationTeamMembershipActor;
    branch: OrganizationTeamMembershipUserDefaultOrganization;
    source_keyspace: OrganizationTeamMembershipUserDefaultOrganization;
    target_keyspace: OrganizationTeamMembershipUserDefaultOrganization;
    global_keyspace: OrganizationTeamMembershipUserDefaultOrganization;
}
export declare const PaginatedWorkflowDataItem: S.Schema<PaginatedWorkflowDataItem>;
export type PaginatedWorkflowDataList = Array<PaginatedWorkflowDataItem>;
export declare const PaginatedWorkflowDataList: S.Schema<PaginatedWorkflowDataList>;
export interface PaginatedWorkflow {
    /** The response type. Always "list" for paginated responses. */
    type: string;
    /** The current page number */
    current_page: number;
    /** The maximum number of results per page */
    per_page: number;
    /** The next page number, or null when this is the last page */
    next_page: number | null;
    /** The next page of results, or null when this is the last page */
    next_page_url: string | null;
    /** The previous page number, or null when this is the first page */
    prev_page: number | null;
    /** The previous page of results, or null when this is the first page */
    prev_page_url: string | null;
    data: PaginatedWorkflowDataList;
}
export declare const PaginatedWorkflow: S.Schema<PaginatedWorkflow>;
export interface PromoteBranchRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
}
export declare const PromoteBranchRequest: S.Schema<PromoteBranchRequest>;
export interface ReassignRoleObjectsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the role */
    id: string;
    /** The role to reassign ownership to. Accepts the role's ID, or its username with or without the branch ID suffix. */
    successor: string;
}
export declare const ReassignRoleObjectsRequest: S.Schema<ReassignRoleObjectsRequest>;
export interface ReassignRoleObjectsResponse {
}
export declare const ReassignRoleObjectsResponse: S.Schema<ReassignRoleObjectsResponse>;
export interface RemoveOrganizationMemberRequest {
    /** The name of the organization */
    organization: string;
    /** The ID of the user */
    id: string;
    /** Whether to delete all passwords associated with the member. Only available when removing other members (not yourself). */
    delete_passwords?: boolean;
    /** Whether to delete all service tokens associated with the member. Only available when removing other members (not yourself). */
    delete_service_tokens?: boolean;
}
export declare const RemoveOrganizationMemberRequest: S.Schema<RemoveOrganizationMemberRequest>;
export interface RemoveOrganizationMemberResponse {
}
export declare const RemoveOrganizationMemberResponse: S.Schema<RemoveOrganizationMemberResponse>;
export interface RemoveOrganizationTeamMemberRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
    /** The ID of the team membership or the ID of the member to remove */
    id: string;
    /** Whether to delete the member's passwords created through this team */
    delete_passwords?: boolean;
}
export declare const RemoveOrganizationTeamMemberRequest: S.Schema<RemoveOrganizationTeamMemberRequest>;
export interface RemoveOrganizationTeamMemberResponse {
}
export declare const RemoveOrganizationTeamMemberResponse: S.Schema<RemoveOrganizationTeamMemberResponse>;
export interface RenewPasswordRequest {
    /** The name of the organization the password belongs to */
    organization: string;
    /** The name of the database the password belongs to */
    database: string;
    /** The name of the branch the password belongs to */
    branch: string;
    /** The ID of the password */
    id: string;
}
export declare const RenewPasswordRequest: S.Schema<RenewPasswordRequest>;
export interface RenewRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the role */
    id: string;
}
export declare const RenewRoleRequest: S.Schema<RenewRoleRequest>;
export interface ResetDefaultRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
}
export declare const ResetDefaultRoleRequest: S.Schema<ResetDefaultRoleRequest>;
export interface ResetRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the role */
    id: string;
}
export declare const ResetRoleRequest: S.Schema<ResetRoleRequest>;
export interface RetryWorkflowRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const RetryWorkflowRequest: S.Schema<RetryWorkflowRequest>;
export interface RunBranchMaintenanceRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** Whether to upgrade the branch to the latest PostgreSQL minor version during maintenance. */
    update_postgres_minor_version?: boolean;
}
export declare const RunBranchMaintenanceRequest: S.Schema<RunBranchMaintenanceRequest>;
export interface RunBranchMaintenanceResponse {
}
export declare const RunBranchMaintenanceResponse: S.Schema<RunBranchMaintenanceResponse>;
export interface SkipRevertPeriodRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
}
export declare const SkipRevertPeriodRequest: S.Schema<SkipRevertPeriodRequest>;
export interface TestWebhookRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the webhook */
    id: string;
}
export declare const TestWebhookRequest: S.Schema<TestWebhookRequest>;
export interface TestWebhookResponse {
}
export declare const TestWebhookResponse: S.Schema<TestWebhookResponse>;
export interface UpdateAutoApplyRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** Whether or not to enable auto-apply for the deploy request */
    enable?: boolean;
}
export declare const UpdateAutoApplyRequest: S.Schema<UpdateAutoApplyRequest>;
export interface UpdateAutoDeleteBranchRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** Whether or not to enable auto-delete branch for the deploy request */
    enable?: boolean;
}
export declare const UpdateAutoDeleteBranchRequest: S.Schema<UpdateAutoDeleteBranchRequest>;
export interface UpdateBackupRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The ID of the backup */
    id: string;
    /** Whether the backup is protected from deletion or not */
    protected?: boolean;
}
export declare const UpdateBackupRequest: S.Schema<UpdateBackupRequest>;
/** Whether the policy is for production or development branches */
export type UpdateBackupPolicyRequestTarget = "production" | "development";
export declare const UpdateBackupPolicyRequestTarget: any;
/** The unit for the retention period of the backup policy */
export type UpdateBackupPolicyRequestRetentionUnit = "hour" | "day" | "week" | "month" | "year";
export declare const UpdateBackupPolicyRequestRetentionUnit: any;
/** The unit for the frequency of the backup policy */
export type UpdateBackupPolicyRequestFrequencyUnit = "hour" | "day" | "week" | "month";
export declare const UpdateBackupPolicyRequestFrequencyUnit: any;
export interface UpdateBackupPolicyRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The ID of the backup policy */
    id: string;
    /** The name of the backup policy */
    name?: string;
    /** Whether the policy is for production or development branches */
    target?: UpdateBackupPolicyRequestTarget | (string & {});
    /** A number value for the retention period of the backup policy */
    retention_value?: number;
    /** The unit for the retention period of the backup policy */
    retention_unit?: UpdateBackupPolicyRequestRetentionUnit | (string & {});
    /** A number value for the frequency of the backup policy */
    frequency_value?: number;
    /** The unit for the frequency of the backup policy */
    frequency_unit?: UpdateBackupPolicyRequestFrequencyUnit | (string & {});
    /** The time of day that the backup is scheduled, in HH:MM format */
    schedule_time?: string;
    /** Day of the week that the backup is scheduled. 0 is Sunday, 6 is Saturday */
    schedule_day?: number;
    /** Week of the month that the backup is scheduled. 0 is the first week, 3 is the fourth week */
    schedule_week?: number;
}
export declare const UpdateBackupPolicyRequest: S.Schema<UpdateBackupPolicyRequest>;
/** Bouncer configuration parameters nested by namespace (e.g., {"pgbouncer": {"default_pool_size": "100"}}). Use the 'List cluster parameters' endpoint to retrieve available parameters. Only parameters with namespace 'pgbouncer' can be updated. */
export type UpdateBouncerResizeRequestRequestParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateBouncerResizeRequestRequestParametersMap: S.Schema<UpdateBouncerResizeRequestRequestParametersMap>;
export interface UpdateBouncerResizeRequestRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the bouncer */
    bouncer: string;
    /** The bouncer size SKU name (e.g., 'PGB_5', 'PGB_10', 'PGB_20', 'PGB_40', 'PGB_80', 'PGB_160'). Defaults to 'PGB_5'. */
    bouncer_size?: string;
    /** The number of PgBouncers per availability zone. Defaults to 1. */
    replicas_per_cell?: number;
    /** The type of server the bouncer targets. */
    target?: string;
    /** Bouncer configuration parameters nested by namespace (e.g., {"pgbouncer": {"default_pool_size": "100"}}). Use the 'List cluster parameters' endpoint to retrieve available parameters. Only parameters with namespace 'pgbouncer' can be updated. */
    parameters?: UpdateBouncerResizeRequestRequestParametersMap;
}
export declare const UpdateBouncerResizeRequestRequest: S.Schema<UpdateBouncerResizeRequestRequest>;
/** The state of the bouncer resize */
export type PostgresBouncerResizeRequestState = "pending" | "resizing" | "canceled" | "completed";
export declare const PostgresBouncerResizeRequestState: any;
/** The backend target for the bouncer after the resize */
export type PostgresBouncerResizeRequestTarget = "primary" | "replica" | "replica_az_affinity";
export declare const PostgresBouncerResizeRequestTarget: any;
/** The bouncer parameters */
export type PostgresBouncerResizeRequestParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PostgresBouncerResizeRequestParametersMap: S.Schema<PostgresBouncerResizeRequestParametersMap>;
/** The backend target for the bouncer before the resize */
export type PostgresBouncerResizeRequestPreviousTarget = "primary" | "replica" | "replica_az_affinity";
export declare const PostgresBouncerResizeRequestPreviousTarget: any;
/** The previous bouncer parameters */
export type PostgresBouncerResizeRequestPreviousParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const PostgresBouncerResizeRequestPreviousParametersMap: S.Schema<PostgresBouncerResizeRequestPreviousParametersMap>;
export type PostgresBouncerResizeRequestActor = OrganizationTeamMembershipActor;
export declare const PostgresBouncerResizeRequestActor: S.Schema<OrganizationTeamMembershipActor>;
export type PostgresBouncerResizeRequestBouncer = OrganizationTeamMembershipUserDefaultOrganization;
export declare const PostgresBouncerResizeRequestBouncer: S.Schema<OrganizationTeamMembershipUserDefaultOrganization>;
export type PostgresBouncerResizeRequestSku = PostgresBouncerSku;
export declare const PostgresBouncerResizeRequestSku: S.Schema<PostgresBouncerSku>;
export type PostgresBouncerResizeRequestPreviousSku = PostgresBouncerSku;
export declare const PostgresBouncerResizeRequestPreviousSku: S.Schema<PostgresBouncerSku>;
export interface PostgresBouncerResizeRequest {
    /** The ID of the bouncer resize */
    id: string;
    /** The state of the bouncer resize */
    state: PostgresBouncerResizeRequestState;
    /** The number of replicas per cell for the bouncer after the resize */
    replicas_per_cell: number;
    /** The backend target for the bouncer after the resize */
    target: PostgresBouncerResizeRequestTarget;
    /** The bouncer parameters */
    parameters: PostgresBouncerResizeRequestParametersMap;
    /** The number of replicas per cell for the bouncer before the resize */
    previous_replicas_per_cell: number;
    /** The backend target for the bouncer before the resize */
    previous_target: PostgresBouncerResizeRequestPreviousTarget;
    /** The previous bouncer parameters */
    previous_parameters: PostgresBouncerResizeRequestPreviousParametersMap;
    /** The time the bouncer resize started */
    started_at: string | null;
    /** The time the bouncer resize completed */
    completed_at: string | null;
    /** The time the bouncer resize was created */
    created_at: string;
    /** The time the bouncer resize was last updated */
    updated_at: string;
    actor: OrganizationTeamMembershipActor;
    bouncer: OrganizationTeamMembershipUserDefaultOrganization;
    sku: PostgresBouncerSku;
    previous_sku: PostgresBouncerSku;
}
export declare const PostgresBouncerResizeRequest: S.Schema<PostgresBouncerResizeRequest>;
export interface UpdateBranchRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name to update the branch */
    new_name?: string;
    /** Whether deletion protection is enabled for the branch */
    deletion_protected?: boolean;
}
export declare const UpdateBranchRequest: S.Schema<UpdateBranchRequest>;
/** Cluster configuration parameters nested by namespace (e.g., {"pgconf": {"max_connections": "200"}}). Use the 'List cluster parameters' endpoint to retrieve available parameters. Supported namespaces include 'patroni', 'pgconf', and 'pgbouncer'. */
export type UpdateBranchChangeRequestRequestParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateBranchChangeRequestRequestParametersMap: S.Schema<UpdateBranchChangeRequestRequestParametersMap>;
export interface UpdateBranchChangeRequestRequestStorage {
    /** The minimum storage size in bytes. */
    minimum_storage_bytes?: number;
    /** The maximum storage size in bytes for autoscaling. */
    maximum_storage_bytes?: number;
    /** Whether storage autoscaling is enabled. */
    storage_autoscaling?: boolean;
    /** The storage IOPS. */
    storage_iops?: number;
    /** The storage throughput in MiB/s. */
    storage_throughput_mibs?: number;
    /** Re-apply the current minimum disk size to shrink the provisioned disk. */
    confirm_shrink?: boolean;
}
export declare const UpdateBranchChangeRequestRequestStorage: S.Schema<UpdateBranchChangeRequestRequestStorage>;
export interface UpdateBranchChangeRequestRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The size of the cluster. Available sizes can be found using the 'List cluster sizes' endpoint. */
    cluster_size?: string;
    /** The total number of replicas */
    replicas?: number;
    /** Cluster configuration parameters nested by namespace (e.g., {"pgconf": {"max_connections": "200"}}). Use the 'List cluster parameters' endpoint to retrieve available parameters. Supported namespaces include 'patroni', 'pgconf', and 'pgbouncer'. */
    parameters?: UpdateBranchChangeRequestRequestParametersMap;
    storage?: UpdateBranchChangeRequestRequestStorage;
}
export declare const UpdateBranchChangeRequestRequest: S.Schema<UpdateBranchChangeRequestRequest>;
export interface UpdateBranchClusterConfigRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch to configure */
    branch: string;
    /** The new size of the database cluster: PS_10, PS_20,… */
    cluster_size: string;
}
export declare const UpdateBranchClusterConfigRequest: S.Schema<UpdateBranchClusterConfigRequest>;
export interface UpdateBranchClusterConfigResponse {
}
export declare const UpdateBranchClusterConfigResponse: S.Schema<UpdateBranchClusterConfigResponse>;
export interface UpdateBranchResizeRequestRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The size of the vtgate cluster: VTG_5, VTG_10,… */
    vtgate_size?: string;
    /** The number of vtgates in an availability zone */
    vtgate_count?: number;
    /** The maximum number of vtgates in an availability zone when autoscaling is enabled */
    vtgate_max_count?: number;
    /** If autoscaling is enabled for the vtgate cluster */
    vtgate_autoscaling?: boolean;
    /** The target CPU utilization for the vtgate cluster when autoscaling is enabled */
    vtgate_target_cpu_utilization?: number;
}
export declare const UpdateBranchResizeRequestRequest: S.Schema<UpdateBranchResizeRequestRequest>;
/** List of IPv4 CIDR ranges (e.g., ['192.168.1.0/24', '192.168.1.1/32']). Only provided fields will be updated. */
export type UpdateDatabasePostgresCidrRequestCidrsList = Array<string>;
export declare const UpdateDatabasePostgresCidrRequestCidrsList: S.Schema<UpdateDatabasePostgresCidrRequestCidrsList>;
export interface UpdateDatabasePostgresCidrRequest {
    /** The name of the organization the database belongs to */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the IP restriction entry */
    id: string;
    /** The PostgreSQL schema to restrict access to. Leave empty to allow access to all schemas. */
    schema?: string;
    /** The PostgreSQL role to restrict access to. Leave empty to allow access for all roles. */
    role?: string;
    /** List of IPv4 CIDR ranges (e.g., ['192.168.1.0/24', '192.168.1.1/32']). Only provided fields will be updated. */
    cidrs?: UpdateDatabasePostgresCidrRequestCidrsList;
    /** An optional description for the IP restriction rule. Pass an empty string to clear. */
    description?: string;
}
export declare const UpdateDatabasePostgresCidrRequest: S.Schema<UpdateDatabasePostgresCidrRequest>;
export interface UpdateDatabaseSettingsRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** The name to update the database to */
    new_name?: string;
    /** Whether or not to copy migration data to new branches and in deploy requests. (Vitess only) */
    automatic_migrations?: boolean;
    /** A migration framework to use on the database. (Vitess only) */
    migration_framework?: string;
    /** Name of table to use as migration table for the database. (Vitess only) */
    migration_table_name?: string;
    /** Whether or not deploy requests must be approved by a database administrator other than the request creator */
    require_approval_for_deploy?: boolean;
    /** Whether or not to limit branch creation to the same region as the one selected during database creation. */
    restrict_branch_region?: boolean;
    /** Whether or not data branching is allowed on the database. (Vitess only) */
    allow_data_branching?: boolean;
    /** Whether or not foreign key constraints are allowed on the database. (Vitess only) */
    allow_foreign_key_constraints?: boolean;
    /** Whether or not full queries should be collected from the database */
    insights_raw_queries?: boolean;
    /** Whether deletion protection is enabled for the database */
    deletion_protected?: boolean;
    /** Whether or not the web console can be used on the production branch of the database */
    production_branch_web_console?: boolean;
    /** The default branch of the database */
    default_branch?: string;
}
export declare const UpdateDatabaseSettingsRequest: S.Schema<UpdateDatabaseSettingsRequest>;
/** If specifying throttler ratios per keyspace, an array of { "keyspace_name": "mykeyspace", "ratio": 10 }, one for each eligible keyspace */
export type UpdateDatabaseThrottlerRequestConfigurationsList = Array<string>;
export declare const UpdateDatabaseThrottlerRequestConfigurationsList: S.Schema<UpdateDatabaseThrottlerRequestConfigurationsList>;
export interface UpdateDatabaseThrottlerRequest {
    /** The name of the organization that the throttled deploy requests belong to */
    organization: string;
    /** The name of the database that the throttled deploy requests belong to */
    database: string;
    /** A throttler ratio between 0 and 95 that will apply to all keyspaces in the database. 0 effectively disables throttler, while 95 drastically slows down deploy request migrations */
    ratio?: number;
    /** If specifying throttler ratios per keyspace, an array of { "keyspace_name": "mykeyspace", "ratio": 10 }, one for each eligible keyspace */
    configurations?: UpdateDatabaseThrottlerRequestConfigurationsList;
}
export declare const UpdateDatabaseThrottlerRequest: S.Schema<UpdateDatabaseThrottlerRequest>;
/** If specifying throttler ratios per keyspace, an array of { "keyspace_name": "mykeyspace", "ratio": 10 }, one for each eligible keyspace */
export type UpdateDeployRequestThrottlerRequestConfigurationsList = Array<string>;
export declare const UpdateDeployRequestThrottlerRequestConfigurationsList: S.Schema<UpdateDeployRequestThrottlerRequestConfigurationsList>;
export interface UpdateDeployRequestThrottlerRequest {
    /** The name of the deploy request's organization */
    organization: string;
    /** The name of the deploy request's database */
    database: string;
    /** The number of the deploy request */
    number: number;
    /** A throttler ratio between 0 and 95 that will apply to all keyspaces affected by the deploy request. 0 effectively disables throttler, while 95 drastically slows down migrations in the deploy request */
    ratio?: number;
    /** If specifying throttler ratios per keyspace, an array of { "keyspace_name": "mykeyspace", "ratio": 10 }, one for each eligible keyspace */
    configurations?: UpdateDeployRequestThrottlerRequestConfigurationsList;
}
export declare const UpdateDeployRequestThrottlerRequest: S.Schema<UpdateDeployRequestThrottlerRequest>;
export interface UpdateKeyspaceRequestReplicationDurabilityConstraints {
    /** The replication durability strategy */
    strategy?: string;
}
export declare const UpdateKeyspaceRequestReplicationDurabilityConstraints: S.Schema<UpdateKeyspaceRequestReplicationDurabilityConstraints>;
export interface UpdateKeyspaceRequestVreplicationFlags {
    /** Enable optimized inserts */
    optimize_inserts?: boolean;
    /** Allow no blob binlog row image */
    allow_no_blob_binlog_row_image?: boolean;
    /** Enable VPlayer batching */
    vplayer_batching?: boolean;
}
export declare const UpdateKeyspaceRequestVreplicationFlags: S.Schema<UpdateKeyspaceRequestVreplicationFlags>;
export interface UpdateKeyspaceRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
    replication_durability_constraints?: UpdateKeyspaceRequestReplicationDurabilityConstraints;
    vreplication_flags?: UpdateKeyspaceRequestVreplicationFlags;
}
export declare const UpdateKeyspaceRequest: S.Schema<UpdateKeyspaceRequest>;
export interface UpdateKeyspaceVschemaRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** The name of the keyspace */
    keyspace: string;
    /** The new VSchema for the keyspace */
    vschema: string;
}
export declare const UpdateKeyspaceVschemaRequest: S.Schema<UpdateKeyspaceVschemaRequest>;
export interface UpdateKeyspaceVschemaResponse {
    /** The keyspace's VSchema */
    raw: string;
}
export declare const UpdateKeyspaceVschemaResponse: S.Schema<UpdateKeyspaceVschemaResponse>;
export interface UpdateOrganizationRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** The billing email for the organization */
    billing_email?: string;
    /** Whether or not the IdP provider is be responsible for managing roles in PlanetScale */
    idp_managed_roles?: boolean;
    /** The expected monthly budget for the organization */
    invoice_budget_amount?: number;
}
export declare const UpdateOrganizationRequest: S.Schema<UpdateOrganizationRequest>;
export interface UpdateOrganizationMembershipRequest {
    /** The name of the organization */
    organization: string;
    /** The ID of the user */
    id: string;
    /** The role to assign to the member (e.g., 'admin', 'member'). Note: Cannot update your own role. Roles managed by IdP cannot be updated via API. */
    role: string;
}
export declare const UpdateOrganizationMembershipRequest: S.Schema<UpdateOrganizationMembershipRequest>;
export interface UpdateOrganizationTeamRequest {
    /** The name of the organization */
    organization: string;
    /** The slug of the team */
    team: string;
    /** The new name for the team */
    name?: string;
    /** The new description for the team */
    description?: string;
}
export declare const UpdateOrganizationTeamRequest: S.Schema<UpdateOrganizationTeamRequest>;
/** List of IP addresses or CIDR ranges that can use this password */
export type UpdatePasswordRequestCidrsList = Array<string>;
export declare const UpdatePasswordRequestCidrsList: S.Schema<UpdatePasswordRequestCidrsList>;
export interface UpdatePasswordRequest {
    /** The name of the organization the password belongs to */
    organization: string;
    /** The name of the database the password belongs to */
    database: string;
    /** The name of the branch the password belongs to */
    branch: string;
    /** The ID of the password */
    id: string;
    /** The name for the password */
    name?: string;
    /** List of IP addresses or CIDR ranges that can use this password */
    cidrs?: UpdatePasswordRequestCidrsList;
}
export declare const UpdatePasswordRequest: S.Schema<UpdatePasswordRequest>;
export interface UpdatePaymentMethodRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
}
export declare const UpdatePaymentMethodRequest: S.Schema<UpdatePaymentMethodRequest>;
/** Configuration parameters nested by namespace (e.g., {"pgconf": {"max_connections": "300"}}). Values must be greater than or equal to the primary's. */
export type UpdateReadOnlyReplicaRequestParametersMap = {
    [key: string]: unknown | undefined;
};
export declare const UpdateReadOnlyReplicaRequestParametersMap: S.Schema<UpdateReadOnlyReplicaRequestParametersMap>;
export interface UpdateReadOnlyReplicaRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The name of the read-only replica */
    read_only_replica: string;
    /** The number of instances serving reads */
    replicas?: number;
    /** The cluster size SKU name */
    cluster_size?: string;
    /** Configuration parameters nested by namespace (e.g., {"pgconf": {"max_connections": "300"}}). Values must be greater than or equal to the primary's. */
    parameters?: UpdateReadOnlyReplicaRequestParametersMap;
}
export declare const UpdateReadOnlyReplicaRequest: S.Schema<UpdateReadOnlyReplicaRequest>;
export interface UpdateRoleRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the role */
    id: string;
    /** The new name of the role */
    name?: string;
    /** Require WHERE clause on DELETE statements */
    require_where_on_delete?: string;
    /** Require WHERE clause on UPDATE statements */
    require_where_on_update?: string;
}
export declare const UpdateRoleRequest: S.Schema<UpdateRoleRequest>;
export interface UpdateSafeMigrationsRequest {
    /** The name of the organization the branch belongs to */
    organization: string;
    /** The name of the database the branch belongs to */
    database: string;
    /** The name of the branch */
    branch: string;
    /** Whether safe migrations are enabled */
    safe_migrations: boolean;
}
export declare const UpdateSafeMigrationsRequest: S.Schema<UpdateSafeMigrationsRequest>;
/** The mode of the traffic budget */
export type UpdateTrafficBudgetRequestMode = "enforce" | "warn" | "off";
export declare const UpdateTrafficBudgetRequestMode: any;
/** Array of traffic rules to apply to the budget */
export type UpdateTrafficBudgetRequestRulesList = Array<string>;
export declare const UpdateTrafficBudgetRequestRulesList: S.Schema<UpdateTrafficBudgetRequestRulesList>;
export interface UpdateTrafficBudgetRequest {
    /** Organization name slug from `list_organizations`. Example: `acme`. */
    organization: string;
    /** Database name slug from `list_databases`. Example: `app-db`. */
    database: string;
    /** Branch name from `list_branches`. Example: `main`. */
    branch: string;
    /** The ID of the traffic budget */
    id: string;
    /** Name of the traffic budget */
    name?: string;
    /** The mode of the traffic budget */
    mode?: UpdateTrafficBudgetRequestMode | (string & {});
    /** The maximum capacity that can be banked, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    capacity?: number;
    /** The rate at which capacity refills, as a percentage of server resources (0-100). Unlimited when not set. */
    rate?: number;
    /** The maximum capacity a single query can consume, measured as a percentage of seconds of full server usage (0-6000). Unlimited when not set. */
    burst?: number;
    /** The percentage of available worker processes this policy can use (0-100). Unlimited when not set. */
    concurrency?: number;
    /** A percentage of capacity, burst, or concurrency thresholds to emit warnings for enforced budgets (0-100). */
    warning_threshold?: number;
    /** Array of traffic rules to apply to the budget */
    rules?: UpdateTrafficBudgetRequestRulesList;
}
export declare const UpdateTrafficBudgetRequest: S.Schema<UpdateTrafficBudgetRequest>;
/** The events this webhook should subscribe to */
export type UpdateWebhookRequestEventsList = Array<string>;
export declare const UpdateWebhookRequestEventsList: S.Schema<UpdateWebhookRequestEventsList>;
export interface UpdateWebhookRequest {
    /** The name of the organization */
    organization: string;
    /** The name of the database */
    database: string;
    /** The ID of the webhook */
    id: string;
    /** The URL the webhook will send events to */
    url?: string;
    /** Whether the webhook should be enabled */
    enabled?: boolean;
    /** The events this webhook should subscribe to */
    events?: UpdateWebhookRequestEventsList;
}
export declare const UpdateWebhookRequest: S.Schema<UpdateWebhookRequest>;
export interface VerifyWorkflowRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const VerifyWorkflowRequest: S.Schema<VerifyWorkflowRequest>;
export interface WorkflowCutoverRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const WorkflowCutoverRequest: S.Schema<WorkflowCutoverRequest>;
export interface WorkflowReverseCutoverRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const WorkflowReverseCutoverRequest: S.Schema<WorkflowReverseCutoverRequest>;
export interface WorkflowReverseTrafficRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const WorkflowReverseTrafficRequest: S.Schema<WorkflowReverseTrafficRequest>;
export interface WorkflowSwitchPrimariesRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const WorkflowSwitchPrimariesRequest: S.Schema<WorkflowSwitchPrimariesRequest>;
export interface WorkflowSwitchReplicasRequest {
    /** The name of the organization the workflow belongs to */
    organization: string;
    /** The name of the database the workflow belongs to */
    database: string;
    /** The sequence number of the workflow */
    number: number;
}
export declare const WorkflowSwitchReplicasRequest: S.Schema<WorkflowSwitchReplicasRequest>;
export type AddOrganizationTeamMemberError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Add a member to a team */
export declare const addOrganizationTeamMember: API.OperationMethod<AddOrganizationTeamMemberRequest, OrganizationTeamMembership, AddOrganizationTeamMemberError, PlanetScaleOpContext>;
export type CancelBouncerResizeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Cancel a resize request */
export declare const cancelBouncerResizeRequest: API.OperationMethod<CancelBouncerResizeRequestRequest, CancelBouncerResizeRequestResponse, CancelBouncerResizeRequestError, PlanetScaleOpContext>;
export type CancelBranchChangeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Cancel a change request */
export declare const cancelBranchChangeRequest: API.OperationMethod<CancelBranchChangeRequestRequest, CancelBranchChangeRequestResponse, CancelBranchChangeRequestError, PlanetScaleOpContext>;
export type CancelDeployRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Cancel a queued deploy request */
export declare const cancelDeployRequest: API.OperationMethod<CancelDeployRequestRequest, DatabaseDeployRequest, CancelDeployRequestError, PlanetScaleOpContext>;
export type CancelKeyspaceResizeRequestError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Cancel a queued keyspace resize request Cancels a queued resize of a branch keyspace. */
export declare const cancelKeyspaceResizeRequest: API.OperationMethod<CancelKeyspaceResizeRequestRequest, CancelKeyspaceResizeRequestResponse, CancelKeyspaceResizeRequestError, PlanetScaleOpContext>;
export type CancelWorkflowError = Forbidden | NotFound | PlanetScaleOpError;
/** Cancel a workflow */
export declare const cancelWorkflow: API.OperationMethod<CancelWorkflowRequest, Workflow, CancelWorkflowError, PlanetScaleOpContext>;
export type CompleteRevertError = Forbidden | NotFound | PlanetScaleOpError;
/** Complete a revert */
export declare const completeRevert: API.OperationMethod<CompleteRevertRequest, DatabaseDeployRequest, CompleteRevertError, PlanetScaleOpContext>;
export type CompleteWorkflowError = Forbidden | NotFound | PlanetScaleOpError;
/** Complete a workflow */
export declare const completeWorkflow: API.OperationMethod<CompleteWorkflowRequest, Workflow, CompleteWorkflowError, PlanetScaleOpContext>;
export type ConfigureOrganizationSsoError = Forbidden | NotFound | PlanetScaleOpError;
/** Open the SSO configuration portal Return a URL for configuring the identity provider. Requires at least one verified domain. */
export declare const configureOrganizationSso: API.OperationMethod<ConfigureOrganizationSsoRequest, ConfigureOrganizationSsoResponse, ConfigureOrganizationSsoError, PlanetScaleOpContext>;
export type CreateBackupError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a backup */
export declare const createBackup: API.OperationMethod<CreateBackupRequest, Backup, CreateBackupError, PlanetScaleOpContext>;
export type CreateBackupPolicyError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a backup policy */
export declare const createBackupPolicy: API.OperationMethod<CreateBackupPolicyRequest, BackupPolicy, CreateBackupPolicyError, PlanetScaleOpContext>;
export type CreateBouncerError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a bouncer */
export declare const createBouncer: API.OperationMethod<CreateBouncerRequest, PostgresBouncer, CreateBouncerError, PlanetScaleOpContext>;
export type CreateBranchError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a branch */
export declare const createBranch: API.OperationMethod<CreateBranchRequest, DatabaseBranch, CreateBranchError, PlanetScaleOpContext>;
export type CreateDatabaseError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create a database */
export declare const createDatabase: API.OperationMethod<CreateDatabaseRequest, Database, CreateDatabaseError, PlanetScaleOpContext>;
export type CreateDatabasePostgresCidrError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create an IP restriction entry */
export declare const createDatabasePostgresCidr: API.OperationMethod<CreateDatabasePostgresCidrRequest, PostgresClusterCidr, CreateDatabasePostgresCidrError, PlanetScaleOpContext>;
export type CreateDeployRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a deploy request */
export declare const createDeployRequest: API.OperationMethod<CreateDeployRequestRequest, DatabaseDeployRequest, CreateDeployRequestError, PlanetScaleOpContext>;
export type CreateKeyspaceError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a keyspace */
export declare const createKeyspace: API.OperationMethod<CreateKeyspaceRequest, DatabaseBranchKeyspace, CreateKeyspaceError, PlanetScaleOpContext>;
export type CreateKeyspaceResizeRequestError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create a keyspace resize request Starts or queues an in-place resize of a branch keyspace's cluster size and/or replica count. Rejected with 422 while another resize is in progress or when the keyspace is already configured with the requested values. */
export declare const createKeyspaceResizeRequest: API.OperationMethod<CreateKeyspaceResizeRequestRequest, KeyspaceResizeRequest, CreateKeyspaceResizeRequestError, PlanetScaleOpContext>;
export type CreateOauthTokenError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create or renew an OAuth token Create an OAuth token from an authorization grant code, or refresh an OAuth token from a refresh token */
export declare const createOauthToken: API.OperationMethod<CreateOauthTokenRequest, ServiceToken, CreateOauthTokenError, PlanetScaleOpContext>;
export type CreateOrganizationSsoDomainError = Forbidden | NotFound | PlanetScaleOpError;
/** Start SSO domain verification Enable SSO if needed and return a URL for verifying an email domain */
export declare const createOrganizationSsoDomain: API.OperationMethod<CreateOrganizationSsoDomainRequest, CreateOrganizationSsoDomainResponse, CreateOrganizationSsoDomainError, PlanetScaleOpContext>;
export type CreateOrganizationTeamError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create an organization team */
export declare const createOrganizationTeam: API.OperationMethod<CreateOrganizationTeamRequest, OrganizationTeam, CreateOrganizationTeamError, PlanetScaleOpContext>;
export type CreatePasswordError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create a password */
export declare const createPassword: API.OperationMethod<CreatePasswordRequest, DatabaseBranchPasswordWithSecret, CreatePasswordError, PlanetScaleOpContext>;
export type CreateQueryPatternsReportError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a new query patterns report */
export declare const createQueryPatternsReport: API.OperationMethod<CreateQueryPatternsReportRequest, QueryPatternsDownload, CreateQueryPatternsReportError, PlanetScaleOpContext>;
export type CreateReadOnlyReplicaError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a read-only replica */
export declare const createReadOnlyReplica: API.OperationMethod<CreateReadOnlyReplicaRequest, PostgresReadOnlyReplica, CreateReadOnlyReplicaError, PlanetScaleOpContext>;
export type CreateRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Create role credentials */
export declare const createRole: API.OperationMethod<CreateRoleRequest, PostgresRole, CreateRoleError, PlanetScaleOpContext>;
export type CreateServiceTokenError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a service token Create a new service token for the organization. */
export declare const createServiceToken: API.OperationMethod<CreateServiceTokenRequest, ServiceToken, CreateServiceTokenError, PlanetScaleOpContext>;
export type CreateSwitchoverError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Create a switchover Moves the primary of a Postgres branch. On a branch with replicas the primary steps down and a replica is promoted in its place. A branch running a single instance has nothing to promote, so that instance is restarted where it stands and the branch is unreachable while it comes back. Read `method` on the response to see which one the branch got. A branch accepts one switchover at a time. A switchover that ends in the `failed` state has an unconfirmed outcome: the primary may still have moved, and nothing is rolled back. */
export declare const createSwitchover: API.OperationMethod<CreateSwitchoverRequest, PostgresSwitchover, CreateSwitchoverError, PlanetScaleOpContext>;
export type CreateTrafficBudgetError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a traffic budget */
export declare const createTrafficBudget: API.OperationMethod<CreateTrafficBudgetRequest, TrafficBudget, CreateTrafficBudgetError, PlanetScaleOpContext>;
export type CreateTrafficRuleError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a traffic rule */
export declare const createTrafficRule: API.OperationMethod<CreateTrafficRuleRequest, TrafficRule, CreateTrafficRuleError, PlanetScaleOpContext>;
export type CreateWebhookError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a webhook */
export declare const createWebhook: API.OperationMethod<CreateWebhookRequest, DatabaseWebhook, CreateWebhookError, PlanetScaleOpContext>;
export type CreateWorkflowError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a workflow */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest, Workflow, CreateWorkflowError, PlanetScaleOpContext>;
export type DeleteBackupError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a backup */
export declare const deleteBackup: API.OperationMethod<DeleteBackupRequest, DeleteBackupResponse, DeleteBackupError, PlanetScaleOpContext>;
export type DeleteBackupPolicyError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a backup policy */
export declare const deleteBackupPolicy: API.OperationMethod<DeleteBackupPolicyRequest, DeleteBackupPolicyResponse, DeleteBackupPolicyError, PlanetScaleOpContext>;
export type DeleteBouncerError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a bouncer */
export declare const deleteBouncer: API.OperationMethod<DeleteBouncerRequest, DeleteBouncerResponse, DeleteBouncerError, PlanetScaleOpContext>;
export type DeleteBranchError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Delete a branch */
export declare const deleteBranch: API.OperationMethod<DeleteBranchRequest, DeleteBranchResponse, DeleteBranchError, PlanetScaleOpContext>;
export type DeleteDatabaseError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a database */
export declare const deleteDatabase: API.OperationMethod<DeleteDatabaseRequest, DeleteDatabaseResponse, DeleteDatabaseError, PlanetScaleOpContext>;
export type DeleteDatabasePostgresCidrError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Delete an IP restriction entry */
export declare const deleteDatabasePostgresCidr: API.OperationMethod<DeleteDatabasePostgresCidrRequest, DeleteDatabasePostgresCidrResponse, DeleteDatabasePostgresCidrError, PlanetScaleOpContext>;
export type DeleteKeyspaceError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a keyspace */
export declare const deleteKeyspace: API.OperationMethod<DeleteKeyspaceRequest, DeleteKeyspaceResponse, DeleteKeyspaceError, PlanetScaleOpContext>;
export type DeleteOauthTokenError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete an OAuth token */
export declare const deleteOauthToken: API.OperationMethod<DeleteOauthTokenRequest, DeleteOauthTokenResponse, DeleteOauthTokenError, PlanetScaleOpContext>;
export type DeleteOrganizationBillingPaymentMethodError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete the current billing payment method Delete the current payment method for an organization */
export declare const deleteOrganizationBillingPaymentMethod: API.OperationMethod<DeleteOrganizationBillingPaymentMethodRequest, DeleteOrganizationBillingPaymentMethodResponse, DeleteOrganizationBillingPaymentMethodError, PlanetScaleOpContext>;
export type DeleteOrganizationSsoDomainError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete an SSO domain Delete a verified or pending SSO domain */
export declare const deleteOrganizationSsoDomain: API.OperationMethod<DeleteOrganizationSsoDomainRequest, DeleteOrganizationSsoDomainResponse, DeleteOrganizationSsoDomainError, PlanetScaleOpContext>;
export type DeleteOrganizationTeamError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Delete an organization team */
export declare const deleteOrganizationTeam: API.OperationMethod<DeleteOrganizationTeamRequest, DeleteOrganizationTeamResponse, DeleteOrganizationTeamError, PlanetScaleOpContext>;
export type DeletePasswordError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a password */
export declare const deletePassword: API.OperationMethod<DeletePasswordRequest, DeletePasswordResponse, DeletePasswordError, PlanetScaleOpContext>;
export type DeleteQueryPatternsReportError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a query patterns report */
export declare const deleteQueryPatternsReport: API.OperationMethod<DeleteQueryPatternsReportRequest, DeleteQueryPatternsReportResponse, DeleteQueryPatternsReportError, PlanetScaleOpContext>;
export type DeleteReadOnlyReplicaError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a read-only replica */
export declare const deleteReadOnlyReplica: API.OperationMethod<DeleteReadOnlyReplicaRequest, DeleteReadOnlyReplicaResponse, DeleteReadOnlyReplicaError, PlanetScaleOpContext>;
export type DeleteRoleError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Delete role credentials */
export declare const deleteRole: API.OperationMethod<DeleteRoleRequest, DeleteRoleResponse, DeleteRoleError, PlanetScaleOpContext>;
export type DeleteServiceTokenError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a service token Delete a service token from the organization. */
export declare const deleteServiceToken: API.OperationMethod<DeleteServiceTokenRequest, DeleteServiceTokenResponse, DeleteServiceTokenError, PlanetScaleOpContext>;
export type DeleteTrafficBudgetError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a traffic budget */
export declare const deleteTrafficBudget: API.OperationMethod<DeleteTrafficBudgetRequest, DeleteTrafficBudgetResponse, DeleteTrafficBudgetError, PlanetScaleOpContext>;
export type DeleteTrafficRuleError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a traffic rule */
export declare const deleteTrafficRule: API.OperationMethod<DeleteTrafficRuleRequest, DeleteTrafficRuleResponse, DeleteTrafficRuleError, PlanetScaleOpContext>;
export type DeleteWebhookError = Forbidden | NotFound | PlanetScaleOpError;
/** Delete a webhook */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest, DeleteWebhookResponse, DeleteWebhookError, PlanetScaleOpContext>;
export type DemoteBranchError = Forbidden | NotFound | PlanetScaleOpError;
/** Demote a branch Demotes a branch from production to development */
export declare const demoteBranch: API.OperationMethod<DemoteBranchRequest, DatabaseBranch, DemoteBranchError, PlanetScaleOpContext>;
export type DeployCheckRequestStorageError = Forbidden | NotFound | PlanetScaleOpError;
/** Check deploy request storage Checks whether the deploy request's target branch cluster has enough storage to safely deploy the schema changes. */
export declare const deployCheckRequestStorage: API.OperationMethod<DeployCheckRequestStorageRequest, DeployCheckRequestStorageResponse, DeployCheckRequestStorageError, PlanetScaleOpContext>;
export type DeployCloseRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Close a deploy request */
export declare const deployCloseRequest: API.OperationMethod<DeployCloseRequestRequest, DatabaseDeployRequest, DeployCloseRequestError, PlanetScaleOpContext>;
export type DeployCompleteErroredError = Forbidden | NotFound | PlanetScaleOpError;
/** Complete an errored deploy */
export declare const deployCompleteErrored: API.OperationMethod<DeployCompleteErroredRequest, DatabaseDeployRequest, DeployCompleteErroredError, PlanetScaleOpContext>;
export type DeployCompleteGatedRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Complete a gated deploy request */
export declare const deployCompleteGatedRequest: API.OperationMethod<DeployCompleteGatedRequestRequest, DatabaseDeployRequest, DeployCompleteGatedRequestError, PlanetScaleOpContext>;
export type DeployForceCutoverRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Enable force cutover for a deploy request */
export declare const deployForceCutoverRequest: API.OperationMethod<DeployForceCutoverRequestRequest, DatabaseDeployRequest, DeployForceCutoverRequestError, PlanetScaleOpContext>;
export type DeployQueueRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Queue a deploy request */
export declare const deployQueueRequest: API.OperationMethod<DeployQueueRequestRequest, DatabaseDeployRequest, DeployQueueRequestError, PlanetScaleOpContext>;
export type DeployReviewRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Review a deploy request Review a deploy request by either approving or commenting on the deploy request */
export declare const deployReviewRequest: API.OperationMethod<DeployReviewRequestRequest, DeployRequestReview, DeployReviewRequestError, PlanetScaleOpContext>;
export type DisableOrganizationSsoError = Forbidden | NotFound | PlanetScaleOpError;
/** Disable organization SSO Disable SSO and directory sync for the organization */
export declare const disableOrganizationSso: API.OperationMethod<DisableOrganizationSsoRequest, OrganizationSsoSerializer, DisableOrganizationSsoError, PlanetScaleOpContext>;
export type DisableOrganizationSsoDirectoryError = Forbidden | NotFound | PlanetScaleOpError;
/** Disable directory sync Disable directory sync for the organization. Non-admin directory members are removed. */
export declare const disableOrganizationSsoDirectory: API.OperationMethod<DisableOrganizationSsoDirectoryRequest, OrganizationSsoSerializer, DisableOrganizationSsoDirectoryError, PlanetScaleOpContext>;
export type DisableSafeMigrationsError = Forbidden | NotFound | PlanetScaleOpError;
/** Disable safe migrations for a branch */
export declare const disableSafeMigrations: API.OperationMethod<DisableSafeMigrationsRequest, DatabaseBranch, DisableSafeMigrationsError, PlanetScaleOpContext>;
export type DismissSchemaRecommendationError = Forbidden | NotFound | PlanetScaleOpError;
/** Dismiss a schema recommendation */
export declare const dismissSchemaRecommendation: API.OperationMethod<DismissSchemaRecommendationRequest, SchemaRecommendation, DismissSchemaRecommendationError, PlanetScaleOpContext>;
export type EnableOrganizationSsoError = Forbidden | NotFound | PlanetScaleOpError;
/** Enable organization SSO Enable the SSO add-on and return a URL for verifying an email domain */
export declare const enableOrganizationSso: API.OperationMethod<EnableOrganizationSsoRequest, OrganizationSsoSerializer, EnableOrganizationSsoError, PlanetScaleOpContext>;
export type EnableOrganizationSsoDirectoryError = Forbidden | NotFound | PlanetScaleOpError;
/** Open the directory sync portal Return a URL for configuring directory sync. Requires SSO to be enabled. */
export declare const enableOrganizationSsoDirectory: API.OperationMethod<EnableOrganizationSsoDirectoryRequest, EnableOrganizationSsoDirectoryResponse, EnableOrganizationSsoDirectoryError, PlanetScaleOpContext>;
export type EnableSafeMigrationsError = Forbidden | NotFound | PlanetScaleOpError;
/** Enable safe migrations for a branch */
export declare const enableSafeMigrations: API.OperationMethod<EnableSafeMigrationsRequest, DatabaseBranch, EnableSafeMigrationsError, PlanetScaleOpContext>;
export type GetBackupError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a backup */
export declare const getBackup: API.OperationMethod<GetBackupRequest, Backup, GetBackupError, PlanetScaleOpContext>;
export type GetBackupPolicyError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a backup policy */
export declare const getBackupPolicy: API.OperationMethod<GetBackupPolicyRequest, BackupPolicy, GetBackupPolicyError, PlanetScaleOpContext>;
export type GetBouncerError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a bouncer */
export declare const getBouncer: API.OperationMethod<GetBouncerRequest, PostgresBouncer, GetBouncerError, PlanetScaleOpContext>;
export type GetBranchError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a branch */
export declare const getBranch: API.OperationMethod<GetBranchRequest, DatabaseBranch, GetBranchError, PlanetScaleOpContext>;
export type GetBranchAnomalyError = Forbidden | NotFound | PlanetScaleOpError;
/** Retrieve a branch anomaly */
export declare const getBranchAnomaly: API.OperationMethod<GetBranchAnomalyRequest, Anomaly, GetBranchAnomalyError, PlanetScaleOpContext>;
export type GetBranchChangeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a branch change request */
export declare const getBranchChangeRequest: API.OperationMethod<GetBranchChangeRequestRequest, PostgresClusterResizeRequest, GetBranchChangeRequestError, PlanetScaleOpContext>;
export type GetBranchKeyspaceTableMetricsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get table storage metrics by keyspace */
export declare const getBranchKeyspaceTableMetrics: API.OperationMethod<GetBranchKeyspaceTableMetricsRequest, GetBranchKeyspaceTableMetricsResponse, GetBranchKeyspaceTableMetricsError, PlanetScaleOpContext>;
export type GetBranchMetricsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Get time-series metrics */
export declare const getBranchMetrics: API.OperationMethod<GetBranchMetricsRequest, GetBranchMetricsResponse, GetBranchMetricsError, PlanetScaleOpContext>;
export type GetBranchQueryError = Forbidden | NotFound | PlanetScaleOpError;
/** Retrieve a branch query */
export declare const getBranchQuery: API.OperationMethod<GetBranchQueryRequest, Query, GetBranchQueryError, PlanetScaleOpContext>;
export type GetBranchQueryErrorError = Forbidden | NotFound | PlanetScaleOpError;
/** List queries for an error fingerprint */
export declare const getBranchQueryError: API.PaginatedOperationMethod<GetBranchQueryErrorRequest, PaginatedQuery, GetBranchQueryErrorError, PlanetScaleOpContext, PaginatedQueryDataItem>;
export type GetBranchQueryMetricsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Get time-series metrics for SQL queries */
export declare const getBranchQueryMetrics: API.OperationMethod<GetBranchQueryMetricsRequest, GetBranchQueryMetricsResponse, GetBranchQueryMetricsError, PlanetScaleOpContext>;
export type GetBranchQueryTagError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Retrieve a query tag */
export declare const getBranchQueryTag: API.OperationMethod<GetBranchQueryTagRequest, QueryTag, GetBranchQueryTagError, PlanetScaleOpContext>;
export type GetBranchResizeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a branch resize request */
export declare const getBranchResizeRequest: API.OperationMethod<GetBranchResizeRequestRequest, MysqlClusterResizeRequest, GetBranchResizeRequestError, PlanetScaleOpContext>;
export type GetBranchSchemaError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a branch schema */
export declare const getBranchSchema: API.OperationMethod<GetBranchSchemaRequest, GetBranchSchemaResponse, GetBranchSchemaError, PlanetScaleOpContext>;
export type GetBranchTableMetricsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get table storage metrics */
export declare const getBranchTableMetrics: API.OperationMethod<GetBranchTableMetricsRequest, GetBranchTableMetricsResponse, GetBranchTableMetricsError, PlanetScaleOpContext>;
export type GetBranchTagMetricsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Get time-series metrics grouped by query tags */
export declare const getBranchTagMetrics: API.OperationMethod<GetBranchTagMetricsRequest, GetBranchTagMetricsResponse, GetBranchTagMetricsError, PlanetScaleOpContext>;
export type GetCurrentUserError = Forbidden | NotFound | PlanetScaleOpError;
/** Get current user Get the user associated with this service token */
export declare const getCurrentUser: API.OperationMethod<GetCurrentUserRequest, User, GetCurrentUserError, PlanetScaleOpContext>;
export type GetDatabaseError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a database */
export declare const getDatabase: API.OperationMethod<GetDatabaseRequest, Database, GetDatabaseError, PlanetScaleOpContext>;
export type GetDatabasePostgresCidrError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Get an IP restriction entry */
export declare const getDatabasePostgresCidr: API.OperationMethod<GetDatabasePostgresCidrRequest, PostgresClusterCidr, GetDatabasePostgresCidrError, PlanetScaleOpContext>;
export type GetDatabaseThrottlerError = Forbidden | NotFound | PlanetScaleOpError;
/** Get database throttler configurations */
export declare const getDatabaseThrottler: API.OperationMethod<GetDatabaseThrottlerRequest, ThrottlerConfigurations, GetDatabaseThrottlerError, PlanetScaleOpContext>;
export type GetDefaultRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Get the default postgres role */
export declare const getDefaultRole: API.OperationMethod<GetDefaultRoleRequest, PostgresRole, GetDefaultRoleError, PlanetScaleOpContext>;
export type GetDeploymentError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a deployment Get the deployment for a deploy request */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, Deployment, GetDeploymentError, PlanetScaleOpContext>;
export type GetDeployQueueError = Forbidden | NotFound | PlanetScaleOpError;
/** Get the deploy queue The deploy queue returns the current list of deploy requests in the order they will be deployed. */
export declare const getDeployQueue: API.PaginatedOperationMethod<GetDeployQueueRequest, PaginatedDeployment, GetDeployQueueError, PlanetScaleOpContext, PaginatedDeploymentDataItem>;
export type GetDeployRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a deploy request */
export declare const getDeployRequest: API.OperationMethod<GetDeployRequestRequest, DatabaseDeployRequest, GetDeployRequestError, PlanetScaleOpContext>;
export type GetDeployRequestThrottlerError = Forbidden | NotFound | PlanetScaleOpError;
/** Get deploy request throttler configurations */
export declare const getDeployRequestThrottler: API.OperationMethod<GetDeployRequestThrottlerRequest, ThrottlerConfigurations, GetDeployRequestThrottlerError, PlanetScaleOpContext>;
export type GetInstantBranchMetricsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Get current metric values */
export declare const getInstantBranchMetrics: API.OperationMethod<GetInstantBranchMetricsRequest, GetInstantBranchMetricsResponse, GetInstantBranchMetricsError, PlanetScaleOpContext>;
export type GetInstantTabletMetricsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Get current tablet metrics */
export declare const getInstantTabletMetrics: API.OperationMethod<GetInstantTabletMetricsRequest, GetInstantTabletMetricsResponse, GetInstantTabletMetricsError, PlanetScaleOpContext>;
export type GetInvoiceError = Forbidden | NotFound | PlanetScaleOpError;
/** Get an invoice */
export declare const getInvoice: API.OperationMethod<GetInvoiceRequest, Invoice, GetInvoiceError, PlanetScaleOpContext>;
export type GetInvoiceLineItemsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get invoice line items Get the line items for an invoice */
export declare const getInvoiceLineItems: API.PaginatedOperationMethod<GetInvoiceLineItemsRequest, PaginatedLineItem, GetInvoiceLineItemsError, PlanetScaleOpContext, PaginatedLineItemDataItem>;
export type GetKeyspaceError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a keyspace */
export declare const getKeyspace: API.OperationMethod<GetKeyspaceRequest, DatabaseBranchKeyspace, GetKeyspaceError, PlanetScaleOpContext>;
export type GetKeyspaceResizeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a keyspace resize request */
export declare const getKeyspaceResizeRequest: API.OperationMethod<GetKeyspaceResizeRequestRequest, KeyspaceResizeRequest, GetKeyspaceResizeRequestError, PlanetScaleOpContext>;
export type GetKeyspaceRolloutStatusError = Forbidden | NotFound | PlanetScaleOpError;
/** Get keyspace rollout status */
export declare const getKeyspaceRolloutStatus: API.OperationMethod<GetKeyspaceRolloutStatusRequest, GetKeyspaceRolloutStatusResponse, GetKeyspaceRolloutStatusError, PlanetScaleOpContext>;
export type GetKeyspaceVschemaError = Forbidden | NotFound | PlanetScaleOpError;
/** Get the VSchema for the keyspace */
export declare const getKeyspaceVschema: API.OperationMethod<GetKeyspaceVschemaRequest, GetKeyspaceVschemaResponse, GetKeyspaceVschemaError, PlanetScaleOpContext>;
export type GetMaintenanceScheduleError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a maintenance schedule */
export declare const getMaintenanceSchedule: API.OperationMethod<GetMaintenanceScheduleRequest, BranchMaintenanceSchedule, GetMaintenanceScheduleError, PlanetScaleOpContext>;
export type GetOauthApplicationError = Forbidden | NotFound | PlanetScaleOpError;
/** Get an OAuth application */
export declare const getOauthApplication: API.OperationMethod<GetOauthApplicationRequest, OauthApplication, GetOauthApplicationError, PlanetScaleOpContext>;
export type GetOauthTokenError = Forbidden | NotFound | PlanetScaleOpError;
/** Get an OAuth token */
export declare const getOauthToken: API.OperationMethod<GetOauthTokenRequest, ServiceToken, GetOauthTokenError, PlanetScaleOpContext>;
export type GetOrganizationError = Forbidden | NotFound | PlanetScaleOpError;
/** Get an organization */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, Organization, GetOrganizationError, PlanetScaleOpContext>;
export type GetOrganizationBillingPaymentMethodError = Forbidden | NotFound | PlanetScaleOpError;
/** Get the current billing payment method Get the current payment method for an organization */
export declare const getOrganizationBillingPaymentMethod: API.OperationMethod<GetOrganizationBillingPaymentMethodRequest, BillingPaymentMethod, GetOrganizationBillingPaymentMethodError, PlanetScaleOpContext>;
export type GetOrganizationMembershipError = Forbidden | NotFound | PlanetScaleOpError;
/** Get an organization member */
export declare const getOrganizationMembership: API.OperationMethod<GetOrganizationMembershipRequest, OrganizationMembership, GetOrganizationMembershipError, PlanetScaleOpContext>;
export type GetOrganizationSsoError = Forbidden | NotFound | PlanetScaleOpError;
/** Get organization SSO status Get SSO add-on status, identity provider connection state, directory sync, and verified domains */
export declare const getOrganizationSso: API.OperationMethod<GetOrganizationSsoRequest, OrganizationSsoSerializer, GetOrganizationSsoError, PlanetScaleOpContext>;
export type GetOrganizationSsoDomainError = Forbidden | NotFound | PlanetScaleOpError;
/** Get an SSO domain Get a registered SSO email domain and its verification state */
export declare const getOrganizationSsoDomain: API.OperationMethod<GetOrganizationSsoDomainRequest, OrganizationDomain, GetOrganizationSsoDomainError, PlanetScaleOpContext>;
export type GetOrganizationTeamError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Get an organization team */
export declare const getOrganizationTeam: API.OperationMethod<GetOrganizationTeamRequest, OrganizationTeam, GetOrganizationTeamError, PlanetScaleOpContext>;
export type GetOrganizationTeamMemberError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Get a team member */
export declare const getOrganizationTeamMember: API.OperationMethod<GetOrganizationTeamMemberRequest, OrganizationTeamMembership, GetOrganizationTeamMemberError, PlanetScaleOpContext>;
export type GetPasswordError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a password */
export declare const getPassword: API.OperationMethod<GetPasswordRequest, DatabaseBranchPassword, GetPasswordError, PlanetScaleOpContext>;
export type GetPaymentMethodSetupError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a billing payment method setup Get the state of a billing payment method setup */
export declare const getPaymentMethodSetup: API.OperationMethod<GetPaymentMethodSetupRequest, BillingPaymentMethodSetup, GetPaymentMethodSetupError, PlanetScaleOpContext>;
export type GetQueryPatternsReportError = Forbidden | NotFound | PlanetScaleOpError;
/** Download a finished query patterns report */
export declare const getQueryPatternsReport: API.OperationMethod<GetQueryPatternsReportRequest, GetQueryPatternsReportResponse, GetQueryPatternsReportError, PlanetScaleOpContext>;
export type GetQueryPatternsReportStatusError = Forbidden | NotFound | PlanetScaleOpError;
/** Show the status of a query patterns report */
export declare const getQueryPatternsReportStatus: API.OperationMethod<GetQueryPatternsReportStatusRequest, QueryPatternsDownload, GetQueryPatternsReportStatusError, PlanetScaleOpContext>;
export type GetQueryStatisticsError = Forbidden | NotFound | PlanetScaleOpError;
/** Retrieve query statistics */
export declare const getQueryStatistics: API.PaginatedOperationMethod<GetQueryStatisticsRequest, PaginatedQuery, GetQueryStatisticsError, PlanetScaleOpContext, PaginatedQueryDataItem>;
export type GetQuerySummaryError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Retrieve a summary of query statistics */
export declare const getQuerySummary: API.OperationMethod<GetQuerySummaryRequest, QuerySummary, GetQuerySummaryError, PlanetScaleOpContext>;
export type GetReadOnlyReplicaError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a read-only replica */
export declare const getReadOnlyReplica: API.OperationMethod<GetReadOnlyReplicaRequest, PostgresReadOnlyReplica, GetReadOnlyReplicaError, PlanetScaleOpContext>;
export type GetRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a role */
export declare const getRole: API.OperationMethod<GetRoleRequest, PostgresRole, GetRoleError, PlanetScaleOpContext>;
export type GetSchemaRecommendationError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a schema recommendation */
export declare const getSchemaRecommendation: API.OperationMethod<GetSchemaRecommendationRequest, SchemaRecommendation, GetSchemaRecommendationError, PlanetScaleOpContext>;
export type GetServiceTokenError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a service token Get information about a service token. */
export declare const getServiceToken: API.OperationMethod<GetServiceTokenRequest, ServiceToken, GetServiceTokenError, PlanetScaleOpContext>;
export type GetSwitchoverError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a switchover */
export declare const getSwitchover: API.OperationMethod<GetSwitchoverRequest, PostgresSwitchover, GetSwitchoverError, PlanetScaleOpContext>;
export type GetTabletMetricsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** Get time-series tablet metrics */
export declare const getTabletMetrics: API.OperationMethod<GetTabletMetricsRequest, GetTabletMetricsResponse, GetTabletMetricsError, PlanetScaleOpContext>;
export type GetTrafficBudgetError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a traffic budget */
export declare const getTrafficBudget: API.OperationMethod<GetTrafficBudgetRequest, TrafficBudget, GetTrafficBudgetError, PlanetScaleOpContext>;
export type GetWebhookError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a webhook */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest, DatabaseWebhook, GetWebhookError, PlanetScaleOpContext>;
export type GetWorkflowError = Forbidden | NotFound | PlanetScaleOpError;
/** Get a workflow */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, Workflow, GetWorkflowError, PlanetScaleOpContext>;
export type LintBranchSchemaError = Forbidden | NotFound | PlanetScaleOpError;
/** Lint a branch schema */
export declare const lintBranchSchema: API.PaginatedOperationMethod<LintBranchSchemaRequest, PaginatedSchemaLintError, LintBranchSchemaError, PlanetScaleOpContext, PaginatedSchemaLintErrorDataItem>;
export type ListAuditLogsError = Forbidden | NotFound | PlanetScaleOpError;
/** List audit logs */
export declare const listAuditLogs: API.OperationMethod<ListAuditLogsRequest, PaginatedAuditLogEvent, ListAuditLogsError, PlanetScaleOpContext>;
export type ListBackupPoliciesError = Forbidden | NotFound | PlanetScaleOpError;
/** List backup policies */
export declare const listBackupPolicies: API.PaginatedOperationMethod<ListBackupPoliciesRequest, PaginatedBackupPolicy, ListBackupPoliciesError, PlanetScaleOpContext, PaginatedBackupPolicyDataItem>;
export type ListBackupsError = Forbidden | NotFound | PlanetScaleOpError;
/** List backups */
export declare const listBackups: API.PaginatedOperationMethod<ListBackupsRequest, PaginatedBackup, ListBackupsError, PlanetScaleOpContext, PaginatedBackupDataItem>;
export type ListBouncerResizeRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get bouncer resize requests */
export declare const listBouncerResizeRequests: API.PaginatedOperationMethod<ListBouncerResizeRequestsRequest, PaginatedPostgresBouncerResizeRequest, ListBouncerResizeRequestsError, PlanetScaleOpContext, PaginatedPostgresBouncerResizeRequestDataItem>;
export type ListBouncersError = Forbidden | NotFound | PlanetScaleOpError;
/** List bouncers */
export declare const listBouncers: API.PaginatedOperationMethod<ListBouncersRequest, PaginatedPostgresBouncer, ListBouncersError, PlanetScaleOpContext, PaginatedPostgresBouncerDataItem>;
export type ListBranchAnomaliesError = Forbidden | NotFound | PlanetScaleOpError;
/** List branch anomalies */
export declare const listBranchAnomalies: API.PaginatedOperationMethod<ListBranchAnomaliesRequest, PaginatedAnomaly, ListBranchAnomaliesError, PlanetScaleOpContext, PaginatedAnomalyDataItem>;
export type ListBranchBouncerResizeRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get bouncer resize requests */
export declare const listBranchBouncerResizeRequests: API.PaginatedOperationMethod<ListBranchBouncerResizeRequestsRequest, PaginatedPostgresBouncerResizeRequest, ListBranchBouncerResizeRequestsError, PlanetScaleOpContext, PaginatedPostgresBouncerResizeRequestDataItem>;
export type ListBranchChangeRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get branch change requests */
export declare const listBranchChangeRequests: API.PaginatedOperationMethod<ListBranchChangeRequestsRequest, PaginatedPostgresClusterResizeRequest, ListBranchChangeRequestsError, PlanetScaleOpContext, PaginatedPostgresClusterResizeRequestDataItem>;
export type ListBranchesError = Forbidden | NotFound | PlanetScaleOpError;
/** List branches */
export declare const listBranches: API.PaginatedOperationMethod<ListBranchesRequest, PaginatedDatabaseBranch, ListBranchesError, PlanetScaleOpContext, PaginatedDatabaseBranchDataItem>;
export type ListBranchQueriesError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** List branch queries */
export declare const listBranchQueries: API.PaginatedOperationMethod<ListBranchQueriesRequest, PaginatedQuerySummary, ListBranchQueriesError, PlanetScaleOpContext, PaginatedQuerySummaryDataItem>;
export type ListBranchQueryErrorsError = Forbidden | NotFound | PlanetScaleOpError;
/** List branch query errors */
export declare const listBranchQueryErrors: API.PaginatedOperationMethod<ListBranchQueryErrorsRequest, PaginatedErrorSummary, ListBranchQueryErrorsError, PlanetScaleOpContext, PaginatedErrorSummaryDataItem>;
export type ListBranchQueryTagsError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** List query tags */
export declare const listBranchQueryTags: API.PaginatedOperationMethod<ListBranchQueryTagsRequest, PaginatedQueryTag, ListBranchQueryTagsError, PlanetScaleOpContext, PaginatedQueryTagDataItem>;
export type ListBranchQueryTagSummariesError = BadRequest | Forbidden | NotFound | PlanetScaleOpError;
/** List query statistics grouped by tag */
export declare const listBranchQueryTagSummaries: API.PaginatedOperationMethod<ListBranchQueryTagSummariesRequest, PaginatedDimensionsQuerySummary, ListBranchQueryTagSummariesError, PlanetScaleOpContext, PaginatedDimensionsQuerySummaryDataItem>;
export type ListBranchResizeRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get branch resize requests */
export declare const listBranchResizeRequests: API.PaginatedOperationMethod<ListBranchResizeRequestsRequest, PaginatedMysqlClusterResizeRequest, ListBranchResizeRequestsError, PlanetScaleOpContext, PaginatedMysqlClusterResizeRequestDataItem>;
export type ListClusterSizeSkusError = Forbidden | NotFound | PlanetScaleOpError;
/** List available cluster sizes List available cluster sizes for an organization */
export declare const listClusterSizeSkus: API.OperationMethod<ListClusterSizeSkusRequest, ListClusterSizeSkusResponse, ListClusterSizeSkusError, PlanetScaleOpContext>;
export type ListDatabasePostgresCidrsError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** List IP restriction entries */
export declare const listDatabasePostgresCidrs: API.PaginatedOperationMethod<ListDatabasePostgresCidrsRequest, PaginatedPostgresClusterCidr, ListDatabasePostgresCidrsError, PlanetScaleOpContext, PaginatedPostgresClusterCidrDataItem>;
export type ListDatabaseRegionsError = Forbidden | NotFound | PlanetScaleOpError;
/** List database regions */
export declare const listDatabaseRegions: API.PaginatedOperationMethod<ListDatabaseRegionsRequest, PaginatedPlanetscaleRegion, ListDatabaseRegionsError, PlanetScaleOpContext, PaginatedPlanetscaleRegionDataItem>;
export type ListDatabasesError = Forbidden | NotFound | PlanetScaleOpError;
/** List databases */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesRequest, PaginatedDatabase, ListDatabasesError, PlanetScaleOpContext, PaginatedDatabaseDataItem>;
export type ListDeployOperationsError = Forbidden | NotFound | PlanetScaleOpError;
/** List deploy operations List deploy operations for a deploy request */
export declare const listDeployOperations: API.PaginatedOperationMethod<ListDeployOperationsRequest, PaginatedDeployOperation, ListDeployOperationsError, PlanetScaleOpContext, PaginatedDeployOperationDataItem>;
export type ListDeployRequestReviewsError = Forbidden | NotFound | PlanetScaleOpError;
/** List deploy request reviews */
export declare const listDeployRequestReviews: API.PaginatedOperationMethod<ListDeployRequestReviewsRequest, PaginatedDeployRequestReview, ListDeployRequestReviewsError, PlanetScaleOpContext, PaginatedDeployRequestReviewDataItem>;
export type ListDeployRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** List deploy requests List deploy requests for a database */
export declare const listDeployRequests: API.PaginatedOperationMethod<ListDeployRequestsRequest, PaginatedDatabaseDeployRequest, ListDeployRequestsError, PlanetScaleOpContext, PaginatedDatabaseDeployRequestDataItem>;
export type ListExtensionsError = Forbidden | NotFound | PlanetScaleOpError;
/** List cluster extensions */
export declare const listExtensions: API.OperationMethod<ListExtensionsRequest, ListExtensionsResponse, ListExtensionsError, PlanetScaleOpContext>;
export type ListGeneratedQueryPatternsReportsError = Forbidden | NotFound | PlanetScaleOpError;
/** List generated query patterns reports */
export declare const listGeneratedQueryPatternsReports: API.OperationMethod<ListGeneratedQueryPatternsReportsRequest, PaginatedQueryPatternsDownload, ListGeneratedQueryPatternsReportsError, PlanetScaleOpContext>;
export type ListInvoicesError = Forbidden | NotFound | PlanetScaleOpError;
/** Get invoices Get the invoices for an organization */
export declare const listInvoices: API.PaginatedOperationMethod<ListInvoicesRequest, PaginatedInvoice, ListInvoicesError, PlanetScaleOpContext, PaginatedInvoiceDataItem>;
export type ListKeyspaceResizeRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** List keyspace resize requests Lists resize requests for a branch keyspace, most recent first. */
export declare const listKeyspaceResizeRequests: API.PaginatedOperationMethod<ListKeyspaceResizeRequestsRequest, PaginatedKeyspaceResizeRequest, ListKeyspaceResizeRequestsError, PlanetScaleOpContext, KeyspaceResizeRequest>;
export type ListKeyspacesError = Forbidden | NotFound | PlanetScaleOpError;
/** Get keyspaces */
export declare const listKeyspaces: API.PaginatedOperationMethod<ListKeyspacesRequest, PaginatedDatabaseBranchKeyspace, ListKeyspacesError, PlanetScaleOpContext, PaginatedDatabaseBranchKeyspaceDataItem>;
export type ListMaintenanceSchedulesError = Forbidden | NotFound | PlanetScaleOpError;
/** List maintenance schedules */
export declare const listMaintenanceSchedules: API.PaginatedOperationMethod<ListMaintenanceSchedulesRequest, PaginatedBranchMaintenanceSchedule, ListMaintenanceSchedulesError, PlanetScaleOpContext, PaginatedBranchMaintenanceScheduleDataItem>;
export type ListMaintenanceWindowsError = Forbidden | NotFound | PlanetScaleOpError;
/** List maintenance windows */
export declare const listMaintenanceWindows: API.PaginatedOperationMethod<ListMaintenanceWindowsRequest, PaginatedBranchMaintenanceWindow, ListMaintenanceWindowsError, PlanetScaleOpContext, PaginatedBranchMaintenanceWindowDataItem>;
export type ListOauthApplicationsError = Forbidden | NotFound | PlanetScaleOpError;
/** List OAuth applications */
export declare const listOauthApplications: API.PaginatedOperationMethod<ListOauthApplicationsRequest, PaginatedOauthApplication, ListOauthApplicationsError, PlanetScaleOpContext, PaginatedOauthApplicationDataItem>;
export type ListOauthTokensError = Forbidden | NotFound | PlanetScaleOpError;
/** List OAuth tokens List OAuth tokens created by an OAuth application */
export declare const listOauthTokens: API.PaginatedOperationMethod<ListOauthTokensRequest, PaginatedServiceToken, ListOauthTokensError, PlanetScaleOpContext, PaginatedServiceTokenDataItem>;
export type ListOrganizationMembersError = Forbidden | NotFound | PlanetScaleOpError;
/** List organization members */
export declare const listOrganizationMembers: API.PaginatedOperationMethod<ListOrganizationMembersRequest, PaginatedOrganizationMembership, ListOrganizationMembersError, PlanetScaleOpContext, PaginatedOrganizationMembershipDataItem>;
export type ListOrganizationsError = Forbidden | NotFound | PlanetScaleOpError;
/** List organizations When using a service token, returns the list of organizations the service token has access to. When using an OAuth token, returns the list of organizations the user has access to. */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, PaginatedOrganization, ListOrganizationsError, PlanetScaleOpContext, PaginatedOrganizationDataItem>;
export type ListOrganizationSsoDomainsError = Forbidden | NotFound | PlanetScaleOpError;
/** List organization SSO domains List email domains registered for organization SSO */
export declare const listOrganizationSsoDomains: API.OperationMethod<ListOrganizationSsoDomainsRequest, ListOrganizationSsoDomainsResponse, ListOrganizationSsoDomainsError, PlanetScaleOpContext>;
export type ListOrganizationTeamMembersError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** List team members */
export declare const listOrganizationTeamMembers: API.PaginatedOperationMethod<ListOrganizationTeamMembersRequest, PaginatedOrganizationTeamMembership, ListOrganizationTeamMembersError, PlanetScaleOpContext, PaginatedOrganizationTeamMembershipDataItem>;
export type ListOrganizationTeamsError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** List teams in an organization */
export declare const listOrganizationTeams: API.PaginatedOperationMethod<ListOrganizationTeamsRequest, PaginatedOrganizationTeam, ListOrganizationTeamsError, PlanetScaleOpContext, PaginatedOrganizationTeamDataItem>;
export type ListParametersError = Forbidden | NotFound | PlanetScaleOpError;
/** List cluster parameters Returns the parameters for a branch. To update the parameters, use the "update_branch_change_request" endpoint. */
export declare const listParameters: API.OperationMethod<ListParametersRequest, ListParametersResponse, ListParametersError, PlanetScaleOpContext>;
export type ListPasswordsError = Forbidden | NotFound | PlanetScaleOpError;
/** List passwords */
export declare const listPasswords: API.PaginatedOperationMethod<ListPasswordsRequest, PaginatedDatabaseBranchPassword, ListPasswordsError, PlanetScaleOpContext, PaginatedDatabaseBranchPasswordDataItem>;
export type ListPublicRegionsError = Forbidden | NotFound | PlanetScaleOpError;
/** List public regions Endpoint is available without authentication. */
export declare const listPublicRegions: API.PaginatedOperationMethod<ListPublicRegionsRequest, PaginatedPublicPlanetscaleRegionSerializer, ListPublicRegionsError, PlanetScaleOpContext, PaginatedPublicPlanetscaleRegionSerializerDataItem>;
export type ListReadOnlyRegionsError = Forbidden | NotFound | PlanetScaleOpError;
/** List read-only regions List read-only regions for the database's default branch */
export declare const listReadOnlyRegions: API.PaginatedOperationMethod<ListReadOnlyRegionsRequest, PaginatedDatabaseBranchReadOnlyRegion, ListReadOnlyRegionsError, PlanetScaleOpContext, PaginatedDatabaseBranchReadOnlyRegionDataItem>;
export type ListReadOnlyReplicaChangeRequestsError = Forbidden | NotFound | PlanetScaleOpError;
/** Get read-only replica change requests */
export declare const listReadOnlyReplicaChangeRequests: API.PaginatedOperationMethod<ListReadOnlyReplicaChangeRequestsRequest, PaginatedPostgresReadOnlyReplicaChangeRequest, ListReadOnlyReplicaChangeRequestsError, PlanetScaleOpContext, PaginatedPostgresReadOnlyReplicaChangeRequestDataItem>;
export type ListReadOnlyReplicasError = Forbidden | NotFound | PlanetScaleOpError;
/** List read-only replicas */
export declare const listReadOnlyReplicas: API.OperationMethod<ListReadOnlyReplicasRequest, ListReadOnlyReplicasResponse, ListReadOnlyReplicasError, PlanetScaleOpContext>;
export type ListRegionsForOrganizationError = Forbidden | NotFound | PlanetScaleOpError;
/** List regions for an organization */
export declare const listRegionsForOrganization: API.PaginatedOperationMethod<ListRegionsForOrganizationRequest, PaginatedPlanetscaleRegion, ListRegionsForOrganizationError, PlanetScaleOpContext, PaginatedPlanetscaleRegionDataItem>;
export type ListRolesError = Forbidden | NotFound | PlanetScaleOpError;
/** List roles */
export declare const listRoles: API.PaginatedOperationMethod<ListRolesRequest, PaginatedPostgresRole, ListRolesError, PlanetScaleOpContext, PaginatedPostgresRoleDataItem>;
export type ListSchemaRecommendationsError = Forbidden | NotFound | PlanetScaleOpError;
/** List schema recommendations */
export declare const listSchemaRecommendations: API.PaginatedOperationMethod<ListSchemaRecommendationsRequest, PaginatedSchemaRecommendation, ListSchemaRecommendationsError, PlanetScaleOpContext, PaginatedSchemaRecommendationDataItem>;
export type ListServiceTokensError = Forbidden | NotFound | PlanetScaleOpError;
/** List service tokens List service tokens for an organization. */
export declare const listServiceTokens: API.PaginatedOperationMethod<ListServiceTokensRequest, PaginatedServiceToken, ListServiceTokensError, PlanetScaleOpContext, PaginatedServiceTokenDataItem>;
export type ListSwitchoversError = Forbidden | NotFound | PlanetScaleOpError;
/** List switchovers */
export declare const listSwitchovers: API.PaginatedOperationMethod<ListSwitchoversRequest, PaginatedPostgresSwitchover, ListSwitchoversError, PlanetScaleOpContext, PaginatedPostgresSwitchoverDataItem>;
export type ListTrafficBudgetsError = Forbidden | NotFound | PlanetScaleOpError;
/** List traffic budgets */
export declare const listTrafficBudgets: API.PaginatedOperationMethod<ListTrafficBudgetsRequest, PaginatedTrafficBudget, ListTrafficBudgetsError, PlanetScaleOpContext, PaginatedTrafficBudgetDataItem>;
export type ListTrafficBudgetsForQueryError = Forbidden | NotFound | PlanetScaleOpError;
/** List traffic budgets affecting a query fingerprint */
export declare const listTrafficBudgetsForQuery: API.PaginatedOperationMethod<ListTrafficBudgetsForQueryRequest, PaginatedTrafficBudget, ListTrafficBudgetsForQueryError, PlanetScaleOpContext, PaginatedTrafficBudgetDataItem>;
export type ListWebhooksError = Forbidden | NotFound | PlanetScaleOpError;
/** List webhooks List webhooks for a database */
export declare const listWebhooks: API.PaginatedOperationMethod<ListWebhooksRequest, PaginatedDatabaseWebhook, ListWebhooksError, PlanetScaleOpContext, PaginatedDatabaseWebhookDataItem>;
export type ListWorkflowsError = Forbidden | NotFound | PlanetScaleOpError;
/** List workflows */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, PaginatedWorkflow, ListWorkflowsError, PlanetScaleOpContext, PaginatedWorkflowDataItem>;
export type PromoteBranchError = Forbidden | NotFound | PlanetScaleOpError;
/** Promote a branch Promotes a branch from development to production */
export declare const promoteBranch: API.OperationMethod<PromoteBranchRequest, DatabaseBranch, PromoteBranchError, PlanetScaleOpContext>;
export type ReassignRoleObjectsError = Forbidden | NotFound | PlanetScaleOpError;
/** Reassign objects owned by one role to another role */
export declare const reassignRoleObjects: API.OperationMethod<ReassignRoleObjectsRequest, ReassignRoleObjectsResponse, ReassignRoleObjectsError, PlanetScaleOpContext>;
export type RemoveOrganizationMemberError = Forbidden | NotFound | PlanetScaleOpError;
/** Remove a member from an organization */
export declare const removeOrganizationMember: API.OperationMethod<RemoveOrganizationMemberRequest, RemoveOrganizationMemberResponse, RemoveOrganizationMemberError, PlanetScaleOpContext>;
export type RemoveOrganizationTeamMemberError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Remove a member from a team */
export declare const removeOrganizationTeamMember: API.OperationMethod<RemoveOrganizationTeamMemberRequest, RemoveOrganizationTeamMemberResponse, RemoveOrganizationTeamMemberError, PlanetScaleOpContext>;
export type RenewPasswordError = Forbidden | NotFound | PlanetScaleOpError;
/** Renew a password */
export declare const renewPassword: API.OperationMethod<RenewPasswordRequest, DatabaseBranchPasswordWithSecret, RenewPasswordError, PlanetScaleOpContext>;
export type RenewRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Renew role expiration */
export declare const renewRole: API.OperationMethod<RenewRoleRequest, PostgresRole, RenewRoleError, PlanetScaleOpContext>;
export type ResetDefaultRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Reset default credentials */
export declare const resetDefaultRole: API.OperationMethod<ResetDefaultRoleRequest, PostgresRole, ResetDefaultRoleError, PlanetScaleOpContext>;
export type ResetRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Reset a role's password */
export declare const resetRole: API.OperationMethod<ResetRoleRequest, PostgresRole, ResetRoleError, PlanetScaleOpContext>;
export type RetryWorkflowError = Forbidden | NotFound | PlanetScaleOpError;
/** Retry a failed workflow */
export declare const retryWorkflow: API.OperationMethod<RetryWorkflowRequest, Workflow, RetryWorkflowError, PlanetScaleOpContext>;
export type RunBranchMaintenanceError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Run maintenance for a Postgres branch */
export declare const runBranchMaintenance: API.OperationMethod<RunBranchMaintenanceRequest, RunBranchMaintenanceResponse, RunBranchMaintenanceError, PlanetScaleOpContext>;
export type SkipRevertPeriodError = Forbidden | NotFound | PlanetScaleOpError;
/** Skip revert period Skips the revert period for a deploy request */
export declare const skipRevertPeriod: API.OperationMethod<SkipRevertPeriodRequest, DatabaseDeployRequest, SkipRevertPeriodError, PlanetScaleOpContext>;
export type TestWebhookError = Forbidden | NotFound | PlanetScaleOpError;
/** Test a webhook Sends a test event to the webhook */
export declare const testWebhook: API.OperationMethod<TestWebhookRequest, TestWebhookResponse, TestWebhookError, PlanetScaleOpContext>;
export type UpdateAutoApplyError = Forbidden | NotFound | PlanetScaleOpError;
/** Update auto-apply for deploy request Enables or disabled the auto-apply setting for a deploy request */
export declare const updateAutoApply: API.OperationMethod<UpdateAutoApplyRequest, DatabaseDeployRequest, UpdateAutoApplyError, PlanetScaleOpContext>;
export type UpdateAutoDeleteBranchError = Forbidden | NotFound | PlanetScaleOpError;
/** Update auto-delete branch for deploy request Enables or disabled the auto-delete branch setting for a deploy request */
export declare const updateAutoDeleteBranch: API.OperationMethod<UpdateAutoDeleteBranchRequest, DatabaseDeployRequest, UpdateAutoDeleteBranchError, PlanetScaleOpContext>;
export type UpdateBackupError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a backup */
export declare const updateBackup: API.OperationMethod<UpdateBackupRequest, Backup, UpdateBackupError, PlanetScaleOpContext>;
export type UpdateBackupPolicyError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a backup policy */
export declare const updateBackupPolicy: API.OperationMethod<UpdateBackupPolicyRequest, BackupPolicy, UpdateBackupPolicyError, PlanetScaleOpContext>;
export type UpdateBouncerResizeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Upsert a bouncer resize request */
export declare const updateBouncerResizeRequest: API.OperationMethod<UpdateBouncerResizeRequestRequest, PostgresBouncerResizeRequest, UpdateBouncerResizeRequestError, PlanetScaleOpContext>;
export type UpdateBranchError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a branch */
export declare const updateBranch: API.OperationMethod<UpdateBranchRequest, DatabaseBranch, UpdateBranchError, PlanetScaleOpContext>;
export type UpdateBranchChangeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Upsert a change request for cluster size, replicas, storage, or parameters */
export declare const updateBranchChangeRequest: API.OperationMethod<UpdateBranchChangeRequestRequest, PostgresClusterResizeRequest, UpdateBranchChangeRequestError, PlanetScaleOpContext>;
export type UpdateBranchClusterConfigError = Forbidden | NotFound | PlanetScaleOpError;
/** Change a branch cluster configuration */
export declare const updateBranchClusterConfig: API.OperationMethod<UpdateBranchClusterConfigRequest, UpdateBranchClusterConfigResponse, UpdateBranchClusterConfigError, PlanetScaleOpContext>;
export type UpdateBranchResizeRequestError = Forbidden | NotFound | PlanetScaleOpError;
/** Upsert a resize request */
export declare const updateBranchResizeRequest: API.OperationMethod<UpdateBranchResizeRequestRequest, MysqlClusterResizeRequest, UpdateBranchResizeRequestError, PlanetScaleOpContext>;
export type UpdateDatabasePostgresCidrError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Update an IP restriction entry */
export declare const updateDatabasePostgresCidr: API.OperationMethod<UpdateDatabasePostgresCidrRequest, PostgresClusterCidr, UpdateDatabasePostgresCidrError, PlanetScaleOpContext>;
export type UpdateDatabaseSettingsError = Forbidden | NotFound | PlanetScaleOpError;
/** Update database settings */
export declare const updateDatabaseSettings: API.OperationMethod<UpdateDatabaseSettingsRequest, Database, UpdateDatabaseSettingsError, PlanetScaleOpContext>;
export type UpdateDatabaseThrottlerError = Forbidden | NotFound | PlanetScaleOpError;
/** Update database throttler configurations */
export declare const updateDatabaseThrottler: API.OperationMethod<UpdateDatabaseThrottlerRequest, ThrottlerConfigurations, UpdateDatabaseThrottlerError, PlanetScaleOpContext>;
export type UpdateDeployRequestThrottlerError = Forbidden | NotFound | PlanetScaleOpError;
/** Update deploy request throttler configurations */
export declare const updateDeployRequestThrottler: API.OperationMethod<UpdateDeployRequestThrottlerRequest, ThrottlerConfigurations, UpdateDeployRequestThrottlerError, PlanetScaleOpContext>;
export type UpdateKeyspaceError = Forbidden | NotFound | PlanetScaleOpError;
/** Configure keyspace settings */
export declare const updateKeyspace: API.OperationMethod<UpdateKeyspaceRequest, DatabaseBranchKeyspace, UpdateKeyspaceError, PlanetScaleOpContext>;
export type UpdateKeyspaceVschemaError = Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Update the VSchema for the keyspace */
export declare const updateKeyspaceVschema: API.OperationMethod<UpdateKeyspaceVschemaRequest, UpdateKeyspaceVschemaResponse, UpdateKeyspaceVschemaError, PlanetScaleOpContext>;
export type UpdateOrganizationError = Forbidden | NotFound | PlanetScaleOpError;
/** Update an organization */
export declare const updateOrganization: API.OperationMethod<UpdateOrganizationRequest, Organization, UpdateOrganizationError, PlanetScaleOpContext>;
export type UpdateOrganizationMembershipError = Forbidden | NotFound | PlanetScaleOpError;
/** Update organization member role */
export declare const updateOrganizationMembership: API.OperationMethod<UpdateOrganizationMembershipRequest, OrganizationMembership, UpdateOrganizationMembershipError, PlanetScaleOpContext>;
export type UpdateOrganizationTeamError = BadRequest | Forbidden | NotFound | UnprocessableEntity | PlanetScaleOpError;
/** Update an organization team */
export declare const updateOrganizationTeam: API.OperationMethod<UpdateOrganizationTeamRequest, OrganizationTeam, UpdateOrganizationTeamError, PlanetScaleOpContext>;
export type UpdatePasswordError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a password */
export declare const updatePassword: API.OperationMethod<UpdatePasswordRequest, DatabaseBranchPassword, UpdatePasswordError, PlanetScaleOpContext>;
export type UpdatePaymentMethodError = Forbidden | NotFound | PlanetScaleOpError;
/** Create a billing payment method setup Create a hosted checkout session for adding or replacing an organization's payment method */
export declare const updatePaymentMethod: API.OperationMethod<UpdatePaymentMethodRequest, BillingPaymentMethodSetup, UpdatePaymentMethodError, PlanetScaleOpContext>;
export type UpdateReadOnlyReplicaError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a read-only replica */
export declare const updateReadOnlyReplica: API.OperationMethod<UpdateReadOnlyReplicaRequest, PostgresReadOnlyReplica, UpdateReadOnlyReplicaError, PlanetScaleOpContext>;
export type UpdateRoleError = Forbidden | NotFound | PlanetScaleOpError;
/** Update role name */
export declare const updateRole: API.OperationMethod<UpdateRoleRequest, PostgresRole, UpdateRoleError, PlanetScaleOpContext>;
export type UpdateSafeMigrationsError = Forbidden | NotFound | PlanetScaleOpError;
/** Update safe migrations for a branch */
export declare const updateSafeMigrations: API.OperationMethod<UpdateSafeMigrationsRequest, DatabaseBranch, UpdateSafeMigrationsError, PlanetScaleOpContext>;
export type UpdateTrafficBudgetError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a traffic budget */
export declare const updateTrafficBudget: API.OperationMethod<UpdateTrafficBudgetRequest, TrafficBudget, UpdateTrafficBudgetError, PlanetScaleOpContext>;
export type UpdateWebhookError = Forbidden | NotFound | PlanetScaleOpError;
/** Update a webhook */
export declare const updateWebhook: API.OperationMethod<UpdateWebhookRequest, DatabaseWebhook, UpdateWebhookError, PlanetScaleOpContext>;
export type VerifyWorkflowError = Forbidden | NotFound | PlanetScaleOpError;
/** Verify workflow data */
export declare const verifyWorkflow: API.OperationMethod<VerifyWorkflowRequest, Workflow, VerifyWorkflowError, PlanetScaleOpContext>;
export type WorkflowCutoverError = Forbidden | NotFound | PlanetScaleOpError;
/** Cutover traffic */
export declare const workflowCutover: API.OperationMethod<WorkflowCutoverRequest, Workflow, WorkflowCutoverError, PlanetScaleOpContext>;
export type WorkflowReverseCutoverError = Forbidden | NotFound | PlanetScaleOpError;
/** Reverse traffic cutover */
export declare const workflowReverseCutover: API.OperationMethod<WorkflowReverseCutoverRequest, Workflow, WorkflowReverseCutoverError, PlanetScaleOpContext>;
export type WorkflowReverseTrafficError = Forbidden | NotFound | PlanetScaleOpError;
/** Reverse traffic */
export declare const workflowReverseTraffic: API.OperationMethod<WorkflowReverseTrafficRequest, Workflow, WorkflowReverseTrafficError, PlanetScaleOpContext>;
export type WorkflowSwitchPrimariesError = Forbidden | NotFound | PlanetScaleOpError;
/** Switch primary traffic */
export declare const workflowSwitchPrimaries: API.OperationMethod<WorkflowSwitchPrimariesRequest, Workflow, WorkflowSwitchPrimariesError, PlanetScaleOpContext>;
export type WorkflowSwitchReplicasError = Forbidden | NotFound | PlanetScaleOpError;
/** Switch replica traffic */
export declare const workflowSwitchReplicas: API.OperationMethod<WorkflowSwitchReplicasRequest, Workflow, WorkflowSwitchReplicasError, PlanetScaleOpContext>;
export type AddOrganizationTeamMemberInput = AddOrganizationTeamMemberRequest;
export type AddOrganizationTeamMemberOutput = OrganizationTeamMembership;
export type CancelBouncerResizeRequestInput = CancelBouncerResizeRequestRequest;
export type CancelBouncerResizeRequestOutput = CancelBouncerResizeRequestResponse;
export type CancelBranchChangeRequestInput = CancelBranchChangeRequestRequest;
export type CancelBranchChangeRequestOutput = CancelBranchChangeRequestResponse;
export type CancelDeployRequestInput = CancelDeployRequestRequest;
export type CancelDeployRequestOutput = DatabaseDeployRequest;
export type CancelKeyspaceResizeRequestInput = CancelKeyspaceResizeRequestRequest;
export type CancelKeyspaceResizeRequestOutput = CancelKeyspaceResizeRequestResponse;
export type CancelWorkflowInput = CancelWorkflowRequest;
export type CancelWorkflowOutput = Workflow;
export type CompleteRevertInput = CompleteRevertRequest;
export type CompleteRevertOutput = DatabaseDeployRequest;
export type CompleteWorkflowInput = CompleteWorkflowRequest;
export type CompleteWorkflowOutput = Workflow;
export type ConfigureOrganizationSsoInput = ConfigureOrganizationSsoRequest;
export type ConfigureOrganizationSsoOutput = ConfigureOrganizationSsoResponse;
export type CreateBackupInput = CreateBackupRequest;
export type CreateBackupOutput = Backup;
export type CreateBackupPolicyInput = CreateBackupPolicyRequest;
export type CreateBackupPolicyOutput = BackupPolicy;
export type CreateBouncerInput = CreateBouncerRequest;
export type CreateBouncerOutput = PostgresBouncer;
export type CreateBranchInput = CreateBranchRequest;
export type CreateBranchOutput = DatabaseBranch;
export type CreateDatabaseInput = CreateDatabaseRequest;
export type CreateDatabaseOutput = Database;
export type CreateDatabasePostgresCidrInput = CreateDatabasePostgresCidrRequest;
export type CreateDatabasePostgresCidrOutput = PostgresClusterCidr;
export type CreateDeployRequestInput = CreateDeployRequestRequest;
export type CreateDeployRequestOutput = DatabaseDeployRequest;
export type CreateKeyspaceInput = CreateKeyspaceRequest;
export type CreateKeyspaceOutput = DatabaseBranchKeyspace;
export type CreateKeyspaceResizeRequestInput = CreateKeyspaceResizeRequestRequest;
export type CreateKeyspaceResizeRequestOutput = KeyspaceResizeRequest;
export type CreateOauthTokenInput = CreateOauthTokenRequest;
export type CreateOauthTokenOutput = ServiceToken;
export type CreateOrganizationSsoDomainInput = CreateOrganizationSsoDomainRequest;
export type CreateOrganizationSsoDomainOutput = CreateOrganizationSsoDomainResponse;
export type CreateOrganizationTeamInput = CreateOrganizationTeamRequest;
export type CreateOrganizationTeamOutput = OrganizationTeam;
export type CreatePasswordInput = CreatePasswordRequest;
export type CreatePasswordOutput = DatabaseBranchPasswordWithSecret;
export type CreateQueryPatternsReportInput = CreateQueryPatternsReportRequest;
export type CreateQueryPatternsReportOutput = QueryPatternsDownload;
export type CreateReadOnlyReplicaInput = CreateReadOnlyReplicaRequest;
export type CreateReadOnlyReplicaOutput = PostgresReadOnlyReplica;
export type CreateRoleInput = CreateRoleRequest;
export type CreateRoleOutput = PostgresRole;
export type CreateServiceTokenInput = CreateServiceTokenRequest;
export type CreateServiceTokenOutput = ServiceToken;
export type CreateSwitchoverInput = CreateSwitchoverRequest;
export type CreateSwitchoverOutput = PostgresSwitchover;
export type CreateTrafficBudgetInput = CreateTrafficBudgetRequest;
export type CreateTrafficBudgetOutput = TrafficBudget;
export type CreateTrafficRuleInput = CreateTrafficRuleRequest;
export type CreateTrafficRuleOutput = TrafficRule;
export type CreateWebhookInput = CreateWebhookRequest;
export type CreateWebhookOutput = DatabaseWebhook;
export type CreateWorkflowInput = CreateWorkflowRequest;
export type CreateWorkflowOutput = Workflow;
export type DeleteBackupInput = DeleteBackupRequest;
export type DeleteBackupOutput = DeleteBackupResponse;
export type DeleteBackupPolicyInput = DeleteBackupPolicyRequest;
export type DeleteBackupPolicyOutput = DeleteBackupPolicyResponse;
export type DeleteBouncerInput = DeleteBouncerRequest;
export type DeleteBouncerOutput = DeleteBouncerResponse;
export type DeleteBranchInput = DeleteBranchRequest;
export type DeleteBranchOutput = DeleteBranchResponse;
export type DeleteDatabaseInput = DeleteDatabaseRequest;
export type DeleteDatabaseOutput = DeleteDatabaseResponse;
export type DeleteDatabasePostgresCidrInput = DeleteDatabasePostgresCidrRequest;
export type DeleteDatabasePostgresCidrOutput = DeleteDatabasePostgresCidrResponse;
export type DeleteKeyspaceInput = DeleteKeyspaceRequest;
export type DeleteKeyspaceOutput = DeleteKeyspaceResponse;
export type DeleteOauthTokenInput = DeleteOauthTokenRequest;
export type DeleteOauthTokenOutput = DeleteOauthTokenResponse;
export type DeleteOrganizationBillingPaymentMethodInput = DeleteOrganizationBillingPaymentMethodRequest;
export type DeleteOrganizationBillingPaymentMethodOutput = DeleteOrganizationBillingPaymentMethodResponse;
export type DeleteOrganizationSsoDomainInput = DeleteOrganizationSsoDomainRequest;
export type DeleteOrganizationSsoDomainOutput = DeleteOrganizationSsoDomainResponse;
export type DeleteOrganizationTeamInput = DeleteOrganizationTeamRequest;
export type DeleteOrganizationTeamOutput = DeleteOrganizationTeamResponse;
export type DeletePasswordInput = DeletePasswordRequest;
export type DeletePasswordOutput = DeletePasswordResponse;
export type DeleteQueryPatternsReportInput = DeleteQueryPatternsReportRequest;
export type DeleteQueryPatternsReportOutput = DeleteQueryPatternsReportResponse;
export type DeleteReadOnlyReplicaInput = DeleteReadOnlyReplicaRequest;
export type DeleteReadOnlyReplicaOutput = DeleteReadOnlyReplicaResponse;
export type DeleteRoleInput = DeleteRoleRequest;
export type DeleteRoleOutput = DeleteRoleResponse;
export type DeleteServiceTokenInput = DeleteServiceTokenRequest;
export type DeleteServiceTokenOutput = DeleteServiceTokenResponse;
export type DeleteTrafficBudgetInput = DeleteTrafficBudgetRequest;
export type DeleteTrafficBudgetOutput = DeleteTrafficBudgetResponse;
export type DeleteTrafficRuleInput = DeleteTrafficRuleRequest;
export type DeleteTrafficRuleOutput = DeleteTrafficRuleResponse;
export type DeleteWebhookInput = DeleteWebhookRequest;
export type DeleteWebhookOutput = DeleteWebhookResponse;
export type DemoteBranchInput = DemoteBranchRequest;
export type DemoteBranchOutput = DatabaseBranch;
export type DeployCheckRequestStorageInput = DeployCheckRequestStorageRequest;
export type DeployCheckRequestStorageOutput = DeployCheckRequestStorageResponse;
export type DeployCloseRequestInput = DeployCloseRequestRequest;
export type DeployCloseRequestOutput = DatabaseDeployRequest;
export type DeployCompleteErroredInput = DeployCompleteErroredRequest;
export type DeployCompleteErroredOutput = DatabaseDeployRequest;
export type DeployCompleteGatedRequestInput = DeployCompleteGatedRequestRequest;
export type DeployCompleteGatedRequestOutput = DatabaseDeployRequest;
export type DeployForceCutoverRequestInput = DeployForceCutoverRequestRequest;
export type DeployForceCutoverRequestOutput = DatabaseDeployRequest;
export type DeployQueueRequestInput = DeployQueueRequestRequest;
export type DeployQueueRequestOutput = DatabaseDeployRequest;
export type DeployReviewRequestInput = DeployReviewRequestRequest;
export type DeployReviewRequestOutput = DeployRequestReview;
export type DisableOrganizationSsoInput = DisableOrganizationSsoRequest;
export type DisableOrganizationSsoOutput = OrganizationSsoSerializer;
export type DisableOrganizationSsoDirectoryInput = DisableOrganizationSsoDirectoryRequest;
export type DisableOrganizationSsoDirectoryOutput = OrganizationSsoSerializer;
export type DisableSafeMigrationsInput = DisableSafeMigrationsRequest;
export type DisableSafeMigrationsOutput = DatabaseBranch;
export type DismissSchemaRecommendationInput = DismissSchemaRecommendationRequest;
export type DismissSchemaRecommendationOutput = SchemaRecommendation;
export type EnableOrganizationSsoInput = EnableOrganizationSsoRequest;
export type EnableOrganizationSsoOutput = OrganizationSsoSerializer;
export type EnableOrganizationSsoDirectoryInput = EnableOrganizationSsoDirectoryRequest;
export type EnableOrganizationSsoDirectoryOutput = EnableOrganizationSsoDirectoryResponse;
export type EnableSafeMigrationsInput = EnableSafeMigrationsRequest;
export type EnableSafeMigrationsOutput = DatabaseBranch;
export type GetBackupInput = GetBackupRequest;
export type GetBackupOutput = Backup;
export type GetBackupPolicyInput = GetBackupPolicyRequest;
export type GetBackupPolicyOutput = BackupPolicy;
export type GetBouncerInput = GetBouncerRequest;
export type GetBouncerOutput = PostgresBouncer;
export type GetBranchInput = GetBranchRequest;
export type GetBranchOutput = DatabaseBranch;
export type GetBranchAnomalyInput = GetBranchAnomalyRequest;
export type GetBranchAnomalyOutput = Anomaly;
export type GetBranchChangeRequestInput = GetBranchChangeRequestRequest;
export type GetBranchChangeRequestOutput = PostgresClusterResizeRequest;
export type GetBranchKeyspaceTableMetricsInput = GetBranchKeyspaceTableMetricsRequest;
export type GetBranchKeyspaceTableMetricsOutput = GetBranchKeyspaceTableMetricsResponse;
export type GetBranchMetricsInput = GetBranchMetricsRequest;
export type GetBranchMetricsOutput = GetBranchMetricsResponse;
export type GetBranchQueryInput = GetBranchQueryRequest;
export type GetBranchQueryOutput = Query;
export type GetBranchQueryErrorInput = GetBranchQueryErrorRequest;
export type GetBranchQueryErrorOutput = PaginatedQuery;
export type GetBranchQueryMetricsInput = GetBranchQueryMetricsRequest;
export type GetBranchQueryMetricsOutput = GetBranchQueryMetricsResponse;
export type GetBranchQueryTagInput = GetBranchQueryTagRequest;
export type GetBranchQueryTagOutput = QueryTag;
export type GetBranchResizeRequestInput = GetBranchResizeRequestRequest;
export type GetBranchResizeRequestOutput = MysqlClusterResizeRequest;
export type GetBranchSchemaInput = GetBranchSchemaRequest;
export type GetBranchSchemaOutput = GetBranchSchemaResponse;
export type GetBranchTableMetricsInput = GetBranchTableMetricsRequest;
export type GetBranchTableMetricsOutput = GetBranchTableMetricsResponse;
export type GetBranchTagMetricsInput = GetBranchTagMetricsRequest;
export type GetBranchTagMetricsOutput = GetBranchTagMetricsResponse;
export type GetCurrentUserInput = GetCurrentUserRequest;
export type GetCurrentUserOutput = User;
export type GetDatabaseInput = GetDatabaseRequest;
export type GetDatabaseOutput = Database;
export type GetDatabasePostgresCidrInput = GetDatabasePostgresCidrRequest;
export type GetDatabasePostgresCidrOutput = PostgresClusterCidr;
export type GetDatabaseThrottlerInput = GetDatabaseThrottlerRequest;
export type GetDatabaseThrottlerOutput = ThrottlerConfigurations;
export type GetDefaultRoleInput = GetDefaultRoleRequest;
export type GetDefaultRoleOutput = PostgresRole;
export type GetDeploymentInput = GetDeploymentRequest;
export type GetDeploymentOutput = Deployment;
export type GetDeployQueueInput = GetDeployQueueRequest;
export type GetDeployQueueOutput = PaginatedDeployment;
export type GetDeployRequestInput = GetDeployRequestRequest;
export type GetDeployRequestOutput = DatabaseDeployRequest;
export type GetDeployRequestThrottlerInput = GetDeployRequestThrottlerRequest;
export type GetDeployRequestThrottlerOutput = ThrottlerConfigurations;
export type GetInstantBranchMetricsInput = GetInstantBranchMetricsRequest;
export type GetInstantBranchMetricsOutput = GetInstantBranchMetricsResponse;
export type GetInstantTabletMetricsInput = GetInstantTabletMetricsRequest;
export type GetInstantTabletMetricsOutput = GetInstantTabletMetricsResponse;
export type GetInvoiceInput = GetInvoiceRequest;
export type GetInvoiceOutput = Invoice;
export type GetInvoiceLineItemsInput = GetInvoiceLineItemsRequest;
export type GetInvoiceLineItemsOutput = PaginatedLineItem;
export type GetKeyspaceInput = GetKeyspaceRequest;
export type GetKeyspaceOutput = DatabaseBranchKeyspace;
export type GetKeyspaceResizeRequestInput = GetKeyspaceResizeRequestRequest;
export type GetKeyspaceResizeRequestOutput = KeyspaceResizeRequest;
export type GetKeyspaceRolloutStatusInput = GetKeyspaceRolloutStatusRequest;
export type GetKeyspaceRolloutStatusOutput = GetKeyspaceRolloutStatusResponse;
export type GetKeyspaceVschemaInput = GetKeyspaceVschemaRequest;
export type GetKeyspaceVschemaOutput = GetKeyspaceVschemaResponse;
export type GetMaintenanceScheduleInput = GetMaintenanceScheduleRequest;
export type GetMaintenanceScheduleOutput = BranchMaintenanceSchedule;
export type GetOauthApplicationInput = GetOauthApplicationRequest;
export type GetOauthApplicationOutput = OauthApplication;
export type GetOauthTokenInput = GetOauthTokenRequest;
export type GetOauthTokenOutput = ServiceToken;
export type GetOrganizationInput = GetOrganizationRequest;
export type GetOrganizationOutput = Organization;
export type GetOrganizationBillingPaymentMethodInput = GetOrganizationBillingPaymentMethodRequest;
export type GetOrganizationBillingPaymentMethodOutput = BillingPaymentMethod;
export type GetOrganizationMembershipInput = GetOrganizationMembershipRequest;
export type GetOrganizationMembershipOutput = OrganizationMembership;
export type GetOrganizationSsoInput = GetOrganizationSsoRequest;
export type GetOrganizationSsoOutput = OrganizationSsoSerializer;
export type GetOrganizationSsoDomainInput = GetOrganizationSsoDomainRequest;
export type GetOrganizationSsoDomainOutput = OrganizationDomain;
export type GetOrganizationTeamInput = GetOrganizationTeamRequest;
export type GetOrganizationTeamOutput = OrganizationTeam;
export type GetOrganizationTeamMemberInput = GetOrganizationTeamMemberRequest;
export type GetOrganizationTeamMemberOutput = OrganizationTeamMembership;
export type GetPasswordInput = GetPasswordRequest;
export type GetPasswordOutput = DatabaseBranchPassword;
export type GetPaymentMethodSetupInput = GetPaymentMethodSetupRequest;
export type GetPaymentMethodSetupOutput = BillingPaymentMethodSetup;
export type GetQueryPatternsReportInput = GetQueryPatternsReportRequest;
export type GetQueryPatternsReportOutput = GetQueryPatternsReportResponse;
export type GetQueryPatternsReportStatusInput = GetQueryPatternsReportStatusRequest;
export type GetQueryPatternsReportStatusOutput = QueryPatternsDownload;
export type GetQueryStatisticsInput = GetQueryStatisticsRequest;
export type GetQueryStatisticsOutput = PaginatedQuery;
export type GetQuerySummaryInput = GetQuerySummaryRequest;
export type GetQuerySummaryOutput = QuerySummary;
export type GetReadOnlyReplicaInput = GetReadOnlyReplicaRequest;
export type GetReadOnlyReplicaOutput = PostgresReadOnlyReplica;
export type GetRoleInput = GetRoleRequest;
export type GetRoleOutput = PostgresRole;
export type GetSchemaRecommendationInput = GetSchemaRecommendationRequest;
export type GetSchemaRecommendationOutput = SchemaRecommendation;
export type GetServiceTokenInput = GetServiceTokenRequest;
export type GetServiceTokenOutput = ServiceToken;
export type GetSwitchoverInput = GetSwitchoverRequest;
export type GetSwitchoverOutput = PostgresSwitchover;
export type GetTabletMetricsInput = GetTabletMetricsRequest;
export type GetTabletMetricsOutput = GetTabletMetricsResponse;
export type GetTrafficBudgetInput = GetTrafficBudgetRequest;
export type GetTrafficBudgetOutput = TrafficBudget;
export type GetWebhookInput = GetWebhookRequest;
export type GetWebhookOutput = DatabaseWebhook;
export type GetWorkflowInput = GetWorkflowRequest;
export type GetWorkflowOutput = Workflow;
export type LintBranchSchemaInput = LintBranchSchemaRequest;
export type LintBranchSchemaOutput = PaginatedSchemaLintError;
export type ListAuditLogsInput = ListAuditLogsRequest;
export type ListAuditLogsOutput = PaginatedAuditLogEvent;
export type ListBackupPoliciesInput = ListBackupPoliciesRequest;
export type ListBackupPoliciesOutput = PaginatedBackupPolicy;
export type ListBackupsInput = ListBackupsRequest;
export type ListBackupsOutput = PaginatedBackup;
export type ListBouncerResizeRequestsInput = ListBouncerResizeRequestsRequest;
export type ListBouncerResizeRequestsOutput = PaginatedPostgresBouncerResizeRequest;
export type ListBouncersInput = ListBouncersRequest;
export type ListBouncersOutput = PaginatedPostgresBouncer;
export type ListBranchAnomaliesInput = ListBranchAnomaliesRequest;
export type ListBranchAnomaliesOutput = PaginatedAnomaly;
export type ListBranchBouncerResizeRequestsInput = ListBranchBouncerResizeRequestsRequest;
export type ListBranchBouncerResizeRequestsOutput = PaginatedPostgresBouncerResizeRequest;
export type ListBranchChangeRequestsInput = ListBranchChangeRequestsRequest;
export type ListBranchChangeRequestsOutput = PaginatedPostgresClusterResizeRequest;
export type ListBranchesInput = ListBranchesRequest;
export type ListBranchesOutput = PaginatedDatabaseBranch;
export type ListBranchQueriesInput = ListBranchQueriesRequest;
export type ListBranchQueriesOutput = PaginatedQuerySummary;
export type ListBranchQueryErrorsInput = ListBranchQueryErrorsRequest;
export type ListBranchQueryErrorsOutput = PaginatedErrorSummary;
export type ListBranchQueryTagsInput = ListBranchQueryTagsRequest;
export type ListBranchQueryTagsOutput = PaginatedQueryTag;
export type ListBranchQueryTagSummariesInput = ListBranchQueryTagSummariesRequest;
export type ListBranchQueryTagSummariesOutput = PaginatedDimensionsQuerySummary;
export type ListBranchResizeRequestsInput = ListBranchResizeRequestsRequest;
export type ListBranchResizeRequestsOutput = PaginatedMysqlClusterResizeRequest;
export type ListClusterSizeSkusInput = ListClusterSizeSkusRequest;
export type ListClusterSizeSkusOutput = ListClusterSizeSkusResponse;
export type ListDatabasePostgresCidrsInput = ListDatabasePostgresCidrsRequest;
export type ListDatabasePostgresCidrsOutput = PaginatedPostgresClusterCidr;
export type ListDatabaseRegionsInput = ListDatabaseRegionsRequest;
export type ListDatabaseRegionsOutput = PaginatedPlanetscaleRegion;
export type ListDatabasesInput = ListDatabasesRequest;
export type ListDatabasesOutput = PaginatedDatabase;
export type ListDeployOperationsInput = ListDeployOperationsRequest;
export type ListDeployOperationsOutput = PaginatedDeployOperation;
export type ListDeployRequestReviewsInput = ListDeployRequestReviewsRequest;
export type ListDeployRequestReviewsOutput = PaginatedDeployRequestReview;
export type ListDeployRequestsInput = ListDeployRequestsRequest;
export type ListDeployRequestsOutput = PaginatedDatabaseDeployRequest;
export type ListExtensionsInput = ListExtensionsRequest;
export type ListExtensionsOutput = ListExtensionsResponse;
export type ListGeneratedQueryPatternsReportsInput = ListGeneratedQueryPatternsReportsRequest;
export type ListGeneratedQueryPatternsReportsOutput = PaginatedQueryPatternsDownload;
export type ListInvoicesInput = ListInvoicesRequest;
export type ListInvoicesOutput = PaginatedInvoice;
export type ListKeyspaceResizeRequestsInput = ListKeyspaceResizeRequestsRequest;
export type ListKeyspaceResizeRequestsOutput = PaginatedKeyspaceResizeRequest;
export type ListKeyspacesInput = ListKeyspacesRequest;
export type ListKeyspacesOutput = PaginatedDatabaseBranchKeyspace;
export type ListMaintenanceSchedulesInput = ListMaintenanceSchedulesRequest;
export type ListMaintenanceSchedulesOutput = PaginatedBranchMaintenanceSchedule;
export type ListMaintenanceWindowsInput = ListMaintenanceWindowsRequest;
export type ListMaintenanceWindowsOutput = PaginatedBranchMaintenanceWindow;
export type ListOauthApplicationsInput = ListOauthApplicationsRequest;
export type ListOauthApplicationsOutput = PaginatedOauthApplication;
export type ListOauthTokensInput = ListOauthTokensRequest;
export type ListOauthTokensOutput = PaginatedServiceToken;
export type ListOrganizationMembersInput = ListOrganizationMembersRequest;
export type ListOrganizationMembersOutput = PaginatedOrganizationMembership;
export type ListOrganizationsInput = ListOrganizationsRequest;
export type ListOrganizationsOutput = PaginatedOrganization;
export type ListOrganizationSsoDomainsInput = ListOrganizationSsoDomainsRequest;
export type ListOrganizationSsoDomainsOutput = ListOrganizationSsoDomainsResponse;
export type ListOrganizationTeamMembersInput = ListOrganizationTeamMembersRequest;
export type ListOrganizationTeamMembersOutput = PaginatedOrganizationTeamMembership;
export type ListOrganizationTeamsInput = ListOrganizationTeamsRequest;
export type ListOrganizationTeamsOutput = PaginatedOrganizationTeam;
export type ListParametersInput = ListParametersRequest;
export type ListParametersOutput = ListParametersResponse;
export type ListPasswordsInput = ListPasswordsRequest;
export type ListPasswordsOutput = PaginatedDatabaseBranchPassword;
export type ListPublicRegionsInput = ListPublicRegionsRequest;
export type ListPublicRegionsOutput = PaginatedPublicPlanetscaleRegionSerializer;
export type ListReadOnlyRegionsInput = ListReadOnlyRegionsRequest;
export type ListReadOnlyRegionsOutput = PaginatedDatabaseBranchReadOnlyRegion;
export type ListReadOnlyReplicaChangeRequestsInput = ListReadOnlyReplicaChangeRequestsRequest;
export type ListReadOnlyReplicaChangeRequestsOutput = PaginatedPostgresReadOnlyReplicaChangeRequest;
export type ListReadOnlyReplicasInput = ListReadOnlyReplicasRequest;
export type ListReadOnlyReplicasOutput = ListReadOnlyReplicasResponse;
export type ListRegionsForOrganizationInput = ListRegionsForOrganizationRequest;
export type ListRegionsForOrganizationOutput = PaginatedPlanetscaleRegion;
export type ListRolesInput = ListRolesRequest;
export type ListRolesOutput = PaginatedPostgresRole;
export type ListSchemaRecommendationsInput = ListSchemaRecommendationsRequest;
export type ListSchemaRecommendationsOutput = PaginatedSchemaRecommendation;
export type ListServiceTokensInput = ListServiceTokensRequest;
export type ListServiceTokensOutput = PaginatedServiceToken;
export type ListSwitchoversInput = ListSwitchoversRequest;
export type ListSwitchoversOutput = PaginatedPostgresSwitchover;
export type ListTrafficBudgetsInput = ListTrafficBudgetsRequest;
export type ListTrafficBudgetsOutput = PaginatedTrafficBudget;
export type ListTrafficBudgetsForQueryInput = ListTrafficBudgetsForQueryRequest;
export type ListTrafficBudgetsForQueryOutput = PaginatedTrafficBudget;
export type ListWebhooksInput = ListWebhooksRequest;
export type ListWebhooksOutput = PaginatedDatabaseWebhook;
export type ListWorkflowsInput = ListWorkflowsRequest;
export type ListWorkflowsOutput = PaginatedWorkflow;
export type PromoteBranchInput = PromoteBranchRequest;
export type PromoteBranchOutput = DatabaseBranch;
export type ReassignRoleObjectsInput = ReassignRoleObjectsRequest;
export type ReassignRoleObjectsOutput = ReassignRoleObjectsResponse;
export type RemoveOrganizationMemberInput = RemoveOrganizationMemberRequest;
export type RemoveOrganizationMemberOutput = RemoveOrganizationMemberResponse;
export type RemoveOrganizationTeamMemberInput = RemoveOrganizationTeamMemberRequest;
export type RemoveOrganizationTeamMemberOutput = RemoveOrganizationTeamMemberResponse;
export type RenewPasswordInput = RenewPasswordRequest;
export type RenewPasswordOutput = DatabaseBranchPasswordWithSecret;
export type RenewRoleInput = RenewRoleRequest;
export type RenewRoleOutput = PostgresRole;
export type ResetDefaultRoleInput = ResetDefaultRoleRequest;
export type ResetDefaultRoleOutput = PostgresRole;
export type ResetRoleInput = ResetRoleRequest;
export type ResetRoleOutput = PostgresRole;
export type RetryWorkflowInput = RetryWorkflowRequest;
export type RetryWorkflowOutput = Workflow;
export type RunBranchMaintenanceInput = RunBranchMaintenanceRequest;
export type RunBranchMaintenanceOutput = RunBranchMaintenanceResponse;
export type SkipRevertPeriodInput = SkipRevertPeriodRequest;
export type SkipRevertPeriodOutput = DatabaseDeployRequest;
export type TestWebhookInput = TestWebhookRequest;
export type TestWebhookOutput = TestWebhookResponse;
export type UpdateAutoApplyInput = UpdateAutoApplyRequest;
export type UpdateAutoApplyOutput = DatabaseDeployRequest;
export type UpdateAutoDeleteBranchInput = UpdateAutoDeleteBranchRequest;
export type UpdateAutoDeleteBranchOutput = DatabaseDeployRequest;
export type UpdateBackupInput = UpdateBackupRequest;
export type UpdateBackupOutput = Backup;
export type UpdateBackupPolicyInput = UpdateBackupPolicyRequest;
export type UpdateBackupPolicyOutput = BackupPolicy;
export type UpdateBouncerResizeRequestInput = UpdateBouncerResizeRequestRequest;
export type UpdateBouncerResizeRequestOutput = PostgresBouncerResizeRequest;
export type UpdateBranchInput = UpdateBranchRequest;
export type UpdateBranchOutput = DatabaseBranch;
export type UpdateBranchChangeRequestInput = UpdateBranchChangeRequestRequest;
export type UpdateBranchChangeRequestOutput = PostgresClusterResizeRequest;
export type UpdateBranchClusterConfigInput = UpdateBranchClusterConfigRequest;
export type UpdateBranchClusterConfigOutput = UpdateBranchClusterConfigResponse;
export type UpdateBranchResizeRequestInput = UpdateBranchResizeRequestRequest;
export type UpdateBranchResizeRequestOutput = MysqlClusterResizeRequest;
export type UpdateDatabasePostgresCidrInput = UpdateDatabasePostgresCidrRequest;
export type UpdateDatabasePostgresCidrOutput = PostgresClusterCidr;
export type UpdateDatabaseSettingsInput = UpdateDatabaseSettingsRequest;
export type UpdateDatabaseSettingsOutput = Database;
export type UpdateDatabaseThrottlerInput = UpdateDatabaseThrottlerRequest;
export type UpdateDatabaseThrottlerOutput = ThrottlerConfigurations;
export type UpdateDeployRequestThrottlerInput = UpdateDeployRequestThrottlerRequest;
export type UpdateDeployRequestThrottlerOutput = ThrottlerConfigurations;
export type UpdateKeyspaceInput = UpdateKeyspaceRequest;
export type UpdateKeyspaceOutput = DatabaseBranchKeyspace;
export type UpdateKeyspaceVschemaInput = UpdateKeyspaceVschemaRequest;
export type UpdateKeyspaceVschemaOutput = UpdateKeyspaceVschemaResponse;
export type UpdateOrganizationInput = UpdateOrganizationRequest;
export type UpdateOrganizationOutput = Organization;
export type UpdateOrganizationMembershipInput = UpdateOrganizationMembershipRequest;
export type UpdateOrganizationMembershipOutput = OrganizationMembership;
export type UpdateOrganizationTeamInput = UpdateOrganizationTeamRequest;
export type UpdateOrganizationTeamOutput = OrganizationTeam;
export type UpdatePasswordInput = UpdatePasswordRequest;
export type UpdatePasswordOutput = DatabaseBranchPassword;
export type UpdatePaymentMethodInput = UpdatePaymentMethodRequest;
export type UpdatePaymentMethodOutput = BillingPaymentMethodSetup;
export type UpdateReadOnlyReplicaInput = UpdateReadOnlyReplicaRequest;
export type UpdateReadOnlyReplicaOutput = PostgresReadOnlyReplica;
export type UpdateRoleInput = UpdateRoleRequest;
export type UpdateRoleOutput = PostgresRole;
export type UpdateSafeMigrationsInput = UpdateSafeMigrationsRequest;
export type UpdateSafeMigrationsOutput = DatabaseBranch;
export type UpdateTrafficBudgetInput = UpdateTrafficBudgetRequest;
export type UpdateTrafficBudgetOutput = TrafficBudget;
export type UpdateWebhookInput = UpdateWebhookRequest;
export type UpdateWebhookOutput = DatabaseWebhook;
export type VerifyWorkflowInput = VerifyWorkflowRequest;
export type VerifyWorkflowOutput = Workflow;
export type WorkflowCutoverInput = WorkflowCutoverRequest;
export type WorkflowCutoverOutput = Workflow;
export type WorkflowReverseCutoverInput = WorkflowReverseCutoverRequest;
export type WorkflowReverseCutoverOutput = Workflow;
export type WorkflowReverseTrafficInput = WorkflowReverseTrafficRequest;
export type WorkflowReverseTrafficOutput = Workflow;
export type WorkflowSwitchPrimariesInput = WorkflowSwitchPrimariesRequest;
export type WorkflowSwitchPrimariesOutput = Workflow;
export type WorkflowSwitchReplicasInput = WorkflowSwitchReplicasRequest;
export type WorkflowSwitchReplicasOutput = Workflow;
//# sourceMappingURL=planetscale.d.ts.map