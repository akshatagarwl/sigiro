export type Arn = string;
