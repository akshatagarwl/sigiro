import type { JSX } from "react";
import { Screen, type ScreenController } from "../../CliKit/index.ts";
import type { Plan as AlchemyPlan } from "../../../Plan.ts";
export interface ApprovePlanProps {
    plan: AlchemyPlan;
    detailed?: boolean;
    controller: ScreenController<boolean>;
}
/**
 * Plan approval prompt: the plan tree followed by an operation-specific
 * action and Cancel. Escape cancels; Ctrl+C is handled centrally by the
 * screen runner.
 */
export declare function ApprovePlan(props: ApprovePlanProps): JSX.Element;
export declare const approvePlanScreen: (plan: AlchemyPlan, detailed?: boolean) => Screen<boolean>;
//# sourceMappingURL=ApprovePlan.d.ts.map