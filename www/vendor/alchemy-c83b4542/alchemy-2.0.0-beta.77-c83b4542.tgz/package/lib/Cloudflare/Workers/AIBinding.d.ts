import { AI, type AIClient } from "./AI.ts";
import * as Binding from "./Binding.ts";
/** The binding value produced by calling {@link AI} (declared on `env` or `yield*`-ed). */
export type AIBinding = Binding.Binding<AI["key"], AIClient, AI>;
/**
 * The layer that provides the Effect-native interface for the Cloudflare
 * Workers AI binding.
 *
 * Provide it on the Worker effect (`Effect.provide(Cloudflare.Workers.AIBinding)`)
 * so that yielding an {@link AI} binding attaches the native `ai` binding to
 * the surrounding Worker at deploy time and, at runtime, resolves to the
 * Effect-native {@link AIClient} (wrapping the raw `Ai` handle so `run` /
 * `models` return Effects and `model(...)` yields a `LanguageModel` layer).
 */
export declare const AIBinding: import("effect/Layer").Layer<AI, never, import("./Worker.ts").WorkerEnvironment>;
//# sourceMappingURL=AIBinding.d.ts.map