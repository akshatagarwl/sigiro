import * as Effect from "effect/Effect";
import { RuntimeContext } from "../../RuntimeContext.ts";
export declare const STATE_STORE_SCRIPT_NAME: "alchemy-state-store";
/**
 * Version of the deployed Cloudflare State Store worker contract.
 *
 * Bump this whenever the wire format or runtime behaviour of the
 * worker changes in a way that an older deployed copy can no longer
 * satisfy. Clients query `/version` on the deployed worker and
 * compare against this constant; a mismatch (or 404) triggers a
 * forced redeploy via the bootstrap flow.
 */
export declare const STATE_STORE_VERSION: 7;
/**
 * Hard-coded OTLP/HTTP endpoints. Point at the public ingest relay
 * defined in `stacks/otel.ts` (bound to `otel.alchemy.run`), which
 * forwards to Axiom with the bearer token attached server-side. Hard-
 * coded on purpose: the worker has no env-var plumbing and the relay
 * is account-level infra that lives outside any single deploy.
 */
/**
 * OTLP traces + metrics + logs Layer for the state-store worker.
 * Mirrors the CLI's `TelemetryLive` so every signal the worker emits
 * (`Effect.withSpan`, runtime metrics, `Effect.log*`) ships to the
 * same Axiom datasets as deploy-time CLI signals. Resource attributes
 * brand each signal with the worker's service name + contract version
 * so they're easy to slice in Axiom.
 */
/**
 * Path on disk to *this* file, used as the worker's bundling entry.
 *
 * When running from source (e.g. dev / monorepo), `import.meta.url` points
 * at `Api.ts` and we can use it directly. When the alchemy CLI is run from
 * its published `bin/alchemy.js` bundle, this module is inlined into the
 * CLI bundle and `import.meta.url` resolves to `bin/alchemy.js` — which
 * has no `default` export and breaks the worker bundler with
 * `[MISSING_EXPORT] "default" is not exported by "bin/alchemy.js"`.
 *
 * In the bundled case, fall back to the published source file shipped
 * alongside the CLI under `../src/Cloudflare/StateStore/Api.ts`.
 */
declare const _default: Effect.Effect<import("effect/Pipeable").Pipeable & import("../../Resource.ts").ResourceLike<"Cloudflare.Worker", import("../index.ts").WorkerProps<any, import("../index.ts").WorkerAssetsConfig | undefined>, {
    workerId: string;
    workerName: string;
    namespace: string | undefined;
    logpush: boolean | undefined;
    url: string | undefined;
    urls: string[];
    domain: {
        name: string;
        aliases: string[];
        redirects: string[];
        zone?: import("../Zone/lookup.ts").Reference;
        previews?: boolean;
    } | undefined;
    tags: string[] | undefined;
    durableObjectNamespaces: Record<string, string>;
    accountId: string;
    routes: {
        id: string;
        pattern: string;
        zoneId: string;
    }[];
    crons: string[];
    tailConsumers?: {
        service: string;
    }[] | undefined;
    streamingTailConsumers?: {
        service: string;
    }[] | undefined;
    versionOf?: string | undefined;
    previewOf?: string | undefined;
    previewId?: string | undefined;
    previewName?: string | undefined;
    previewSlug?: string | undefined;
    previewDoClasses?: string[] | undefined;
    versionId?: string | undefined;
    versionAlias?: string | undefined;
    deploymentId?: string | undefined;
    affinityZoneIds?: string[] | undefined;
    hash?: {
        assets: string | undefined;
        bundle: string | undefined;
        input: string | undefined;
        additionalWorkspaces: string[] | undefined;
        metadata?: string | undefined;
    };
}, {
    bindings?: import("../index.ts").WorkerBinding[];
    cache?: import("../index.ts").WorkerCache;
    observability?: Pick<import("../index.ts").WorkerObservability, "traces">;
    containers?: {
        className: string;
        dev: import("../index.ts").DevContainerImage | undefined;
        hash: string | undefined;
    }[];
    crons?: string[];
    hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
    devRemote?: Record<string, boolean>;
}, import("../Providers.ts").Providers> & {
    bind(sid: import("../../Input.ts").Input<string>, binding: import("../../Input.ts").Input<{
        bindings?: import("../index.ts").WorkerBinding[];
        cache?: import("../index.ts").WorkerCache;
        observability?: Pick<import("../index.ts").WorkerObservability, "traces">;
        containers?: {
            className: string;
            dev: import("../index.ts").DevContainerImage | undefined;
            hash: string | undefined;
        }[];
        crons?: string[];
        hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
        devRemote?: Record<string, boolean>;
    }>): Effect.Effect<void>;
    bind(template: TemplateStringsArray, ...args: any[]): (binding: import("../../Input.ts").Input<{
        bindings?: import("../index.ts").WorkerBinding[];
        cache?: import("../index.ts").WorkerCache;
        observability?: Pick<import("../index.ts").WorkerObservability, "traces">;
        containers?: {
            className: string;
            dev: import("../index.ts").DevContainerImage | undefined;
            hash: string | undefined;
        }[];
        crons?: string[];
        hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
        devRemote?: Record<string, boolean>;
    }>) => Effect.Effect<void>;
} & {
    workerId: import("../../Output.ts").Output<string, never>;
    workerName: import("../../Output.ts").Output<string, never>;
    namespace: import("../../Output.ts").Output<string | undefined, never>;
    logpush: import("../../Output.ts").Output<boolean | undefined, never>;
    url: import("../../Output.ts").Output<string | undefined, never>;
    urls: import("../../Output.ts").Output<string[], never>;
    domain: import("../../Output.ts").Output<{
        name: string;
        aliases: string[];
        redirects: string[];
        zone?: import("../Zone/lookup.ts").Reference;
        previews?: boolean;
    } | undefined, never>;
    tags: import("../../Output.ts").Output<string[] | undefined, never>;
    durableObjectNamespaces: import("../../Output.ts").ObjectExpr<Record<string, string>, never>;
    accountId: import("../../Output.ts").Output<string, never>;
    routes: import("../../Output.ts").Output<{
        id: string;
        pattern: string;
        zoneId: string;
    }[], never>;
    crons: import("../../Output.ts").Output<string[], never>;
    tailConsumers: import("../../Output.ts").Output<{
        service: string;
    }[] | undefined, never>;
    streamingTailConsumers: import("../../Output.ts").Output<{
        service: string;
    }[] | undefined, never>;
    versionOf: import("../../Output.ts").Output<string | undefined, never>;
    previewOf: import("../../Output.ts").Output<string | undefined, never>;
    previewId: import("../../Output.ts").Output<string | undefined, never>;
    previewName: import("../../Output.ts").Output<string | undefined, never>;
    previewSlug: import("../../Output.ts").Output<string | undefined, never>;
    previewDoClasses: import("../../Output.ts").Output<string[] | undefined, never>;
    versionId: import("../../Output.ts").Output<string | undefined, never>;
    versionAlias: import("../../Output.ts").Output<string | undefined, never>;
    deploymentId: import("../../Output.ts").Output<string | undefined, never>;
    affinityZoneIds: import("../../Output.ts").Output<string[] | undefined, never>;
    hash: import("../../Output.ts").Output<{
        assets: string | undefined;
        bundle: string | undefined;
        input: string | undefined;
        additionalWorkspaces: string[] | undefined;
        metadata?: string | undefined;
    } | undefined, never>;
} & import("../Bridge.ts").Rpc<{
    fetch: Effect.Effect<Effect.Effect<import("effect/unstable/http/HttpServerResponse").HttpServerResponse, import("effect/unstable/http/HttpServerError").HttpServerError, import("effect/unstable/http/HttpServerRequest").HttpServerRequest | RuntimeContext | import("effect/Scope").Scope>, never, import("effect/FileSystem").FileSystem | import("effect/Scope").Scope>;
}>, never, import("../Providers.ts").Providers> & import("../../Named.ts").Named<string>;
export default _default;
//# sourceMappingURL=Api.d.ts.map