import * as Layer from "effect/Layer";
import { AbortMultipartUpload } from "./AbortMultipartUpload.ts";
export declare const AbortMultipartUploadHttp: Layer.Layer<AbortMultipartUpload, never, never>;
//# sourceMappingURL=AbortMultipartUploadHttp.d.ts.map