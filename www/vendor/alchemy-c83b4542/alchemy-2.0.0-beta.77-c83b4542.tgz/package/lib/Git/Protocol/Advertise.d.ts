import type { RefsSnapshot } from "./Store.ts";
/** The agent string advertised by both services. */
export declare const AGENT = "git-service/1";
/** The two smart-HTTP services. */
export type GitService = "git-upload-pack" | "git-receive-pack";
/**
 * The v0 upload-pack capability set (DESIGN §2.3): stateless
 * `multi_ack_detailed` + `no-done` negotiation, side-band-64k muxing, shallow
 * (`deepen <n>` only), and the default-branch symref.
 */
export declare const uploadPackCapabilities: (defaultBranch: string) => string;
/**
 * The v0 receive-pack capability set (DESIGN §2.3): per-ref report-status
 * (v1 and v2 — v2 is implemented identically, with no `option` lines, which
 * is valid), ref deletion, atomic pushes, and OFS_DELTA in pushed packs.
 */
export declare const receivePackCapabilities: () => string;
/**
 * The `Content-Type` of a `GET info/refs?service=` advertisement response.
 */
export declare const advertisementContentType: (service: GitService) => string;
/**
 * The `Content-Type` of a `POST /git-{upload,receive}-pack` result response.
 */
export declare const resultContentType: (service: GitService) => string;
/**
 * Builds the `# service=` prelude: one pkt-line plus a flush. Sent before the
 * ref list on `info/refs` for both services.
 */
export declare const servicePrelude: (service: GitService) => Uint8Array;
/**
 * Builds the complete `info/refs?service=git-upload-pack` advertisement body:
 * prelude, then `HEAD` first (its oid = the default branch tip, when that
 * branch exists) with the capability line, then refs sorted by name with
 * peeled `^{}` lines for annotated tags. An empty repo advertises the
 * zero-id `capabilities^{}` form.
 */
export declare const uploadPackAdvertisement: (snapshot: RefsSnapshot) => Uint8Array;
/**
 * Builds the complete `info/refs?service=git-receive-pack` advertisement
 * body. `HEAD` is not advertised (it is not pushable); refs are sorted with
 * peeled lines; an empty repo advertises the zero-id `capabilities^{}` form
 * (which is how the first-ever push learns the capability set).
 */
export declare const receivePackAdvertisement: (snapshot: RefsSnapshot) => Uint8Array;
/**
 * Builds the advertisement for either service.
 */
export declare const advertisement: (service: GitService, snapshot: RefsSnapshot) => Uint8Array;
//# sourceMappingURL=Advertise.d.ts.map