import * as railway from "@distilled.cloud/railway";
import * as Effect from "effect/Effect";
type AuditLogEventTypeInfoResultItem = railway.Result<"AuditLogEventTypeInfo!", {
    description: true;
    eventType: true;
}>;
/**
 * Project identity for {@link listAuditLogs}. Accepts a `Railway.Project`
 * or a `{ projectId }` stub.
 */
export type AuditLogProject = {
    readonly projectId: string;
};
/**
 * Environment identity for {@link listAuditLogs}. Accepts a
 * `Railway.Project` (primary environment), a `Railway.Environment`, or
 * `{ environmentId }`.
 */
export type AuditLogEnvironment = {
    readonly environmentId: string;
};
export interface ListAuditLogsOptions {
    /**
     * Restrict to a project. Accepts a `Railway.Project` or `{ projectId }`.
     */
    project?: AuditLogProject | string;
    /**
     * Restrict to an environment. Accepts a `Railway.Project`, a
     * `Railway.Environment`, or `{ environmentId }`.
     */
    environment?: AuditLogEnvironment | string;
    /**
     * Event type names from {@link listAuditLogEventTypes}.
     */
    eventTypes?: readonly string[];
    /**
     * Inclusive start (RFC3339).
     */
    startDate?: string;
    /**
     * Inclusive end (RFC3339).
     */
    endDate?: string;
    /**
     * Workspace id. Defaults to the current token workspace.
     */
    workspaceId?: string;
    /**
     * Page size. Defaults to 50. This helper fetches one page — it does
     * not walk the whole workspace history.
     * @default 50
     */
    first?: number;
    /**
     * Sort by `createdAt`. Railway default is `desc`.
     */
    sort?: "asc" | "desc";
}
/**
 * One workspace audit-log row from `auditLogs` / `auditLog`.
 */
export interface AuditLogEntry {
    /** Audit log id. */
    readonly id: string;
    /** Event type name (see {@link listAuditLogEventTypes}). */
    readonly eventType: string;
    /** RFC3339 creation timestamp. */
    readonly createdAt: string;
    /** Workspace the event was recorded in. */
    readonly workspaceId: string | undefined;
    /** Project the event targeted, when Railway attached one. */
    readonly projectId: string | undefined;
    /** Environment the event targeted, when Railway attached one. */
    readonly environmentId: string | undefined;
    /** Event payload. Shape depends on `eventType`. */
    readonly payload: unknown;
    /** Extra context Railway attached to the event. */
    readonly context: unknown;
}
export type AuditLogEventType = AuditLogEventTypeInfoResultItem;
/**
 * List workspace audit logs. Query-only — Railway has no audit-log
 * create/update/delete, so this is a catalog helper, not a resource.
 *
 * Defaults to the current token workspace. Pass `project` /
 * `environment` to filter. The result may be empty.
 *
 * @see https://docs.railway.com/reference/audit-logs
 *
 * ### List logs
 * **Example:** Workspace logs
 * ```typescript
 * const logs = yield* Railway.listAuditLogs();
 * ```
 *
 * **Example:** Filter by project
 * ```typescript
 * const site = yield* Railway.Project("Site");
 * const logs = yield* Railway.listAuditLogs({
 *   project: site,
 *   environment: site,
 * });
 * ```
 *
 * ### Get by id
 * **Example:** One row
 * ```typescript
 * const log = yield* Railway.getAuditLog({ id: logs[0].id });
 * ```
 *
 * ### Event types
 * **Example:** Catalog
 * ```typescript
 * const types = yield* Railway.listAuditLogEventTypes();
 * ```
 *
 * @resource
 */
export declare const AuditLog: (options?: ListAuditLogsOptions | undefined) => Effect.Effect<AuditLogEntry[], railway.GraphQLDecodeError | railway.GraphQLFailure<import("@distilled.cloud/core/graphql").Errors<railway.Schema, "Query", {
    apiToken: {
        select: {
            readonly workspaces: {
                readonly id: true;
                readonly name: true;
            };
        };
    };
}>> | railway.GraphQLRequestError | railway.GraphQLTransportError | import("./Environment.ts").RailwayWorkspaceNotFound, railway.GraphQLRequirements>;
/** Alias of {@link AuditLog}. */
export declare const listAuditLogs: (options?: ListAuditLogsOptions | undefined) => Effect.Effect<AuditLogEntry[], railway.GraphQLDecodeError | railway.GraphQLFailure<import("@distilled.cloud/core/graphql").Errors<railway.Schema, "Query", {
    apiToken: {
        select: {
            readonly workspaces: {
                readonly id: true;
                readonly name: true;
            };
        };
    };
}>> | railway.GraphQLRequestError | railway.GraphQLTransportError | import("./Environment.ts").RailwayWorkspaceNotFound, railway.GraphQLRequirements>;
/**
 * Fetch one audit log by id. Workspace defaults to the current token
 * workspace.
 *
 * @example Get by id
 * ```typescript
 * const log = yield* Railway.getAuditLog({ id: logs[0].id });
 * ```
 */
export declare const getAuditLog: (options: {
    id: string;
    workspaceId?: string;
}) => Effect.Effect<AuditLogEntry, railway.GraphQLDecodeError | railway.GraphQLFailure<import("@distilled.cloud/core/graphql").Errors<railway.Schema, "Query", {
    apiToken: {
        select: {
            readonly workspaces: {
                readonly id: true;
                readonly name: true;
            };
        };
    };
}>> | railway.GraphQLRequestError | railway.GraphQLTransportError | import("./Environment.ts").RailwayWorkspaceNotFound, railway.GraphQLRequirements>;
/**
 * Event types Railway can record, with descriptions.
 *
 * @example Event type catalog
 * ```typescript
 * const types = yield* Railway.listAuditLogEventTypes();
 * ```
 */
export declare const listAuditLogEventTypes: () => Effect.Effect<{
    description: string;
    eventType: string;
}[], railway.GraphQLFailure<import("@distilled.cloud/core/graphql").Errors<railway.Schema, "Query", {
    auditLogEventTypeInfo: {
        select: {
            readonly description: true;
            readonly eventType: true;
        };
    };
}>> | import("@distilled.cloud/core/graphql").ClientError, railway.GraphQLRequirements>;
export {};
//# sourceMappingURL=AuditLog.d.ts.map