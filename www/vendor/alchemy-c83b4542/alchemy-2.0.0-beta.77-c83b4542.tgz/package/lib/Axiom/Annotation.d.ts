import * as Axiom from "@distilled.cloud/axiom";
import * as Provider from "../Provider.ts";
import { Resource } from "../Resource.ts";
import type { Providers } from "./Providers.ts";
export type AnnotationProps = Axiom.CreateAnnotationRequest;
export type Annotation = Resource<"Axiom.Annotation", AnnotationProps, Axiom.Annotation, never, Providers>;
/**
 * An Axiom annotation — a vertical marker overlaid on charts to flag a
 * deploy, incident, feature flag flip, or any other point/range event you
 * want correlated with telemetry.
 *
 * Annotations are scoped to one or more `datasets`. Use a single `time` for
 * a point marker or `time` + `endTime` for a range. The `type` (e.g.
 * `"deploy"`, `"incident"`) groups markers visually in the UI.
 *
 * Although typically created at deploy/release time (out-of-band of
 * regular IaC), modelling them as resources makes per-environment
 * annotation history reproducible.
 * @see https://axiom.co/docs/query-data/annotate-charts
 *
 * ### Creating an Annotation
 * **Example:** Point-in-time deploy marker
 * ```typescript
 * yield* Axiom.Annotation("deploy-1.2.3", {
 *   type: "deploy",
 *   title: "Release 1.2.3",
 *   description: "https://github.com/acme/app/releases/tag/v1.2.3",
 *   datasets: ["my-app-traces", "my-app-logs"],
 *   time: new Date().toISOString(),
 *   url: "https://github.com/acme/app/releases/tag/v1.2.3",
 * });
 * ```
 *
 * **Example:** Incident time-range
 * ```typescript
 * yield* Axiom.Annotation("inc-2026-04-27", {
 *   type: "incident",
 *   title: "Database failover",
 *   datasets: ["my-app-traces"],
 *   time:    "2026-04-27T18:05:00Z",
 *   endTime: "2026-04-27T18:32:00Z",
 *   url: "https://incident.io/incidents/abc123",
 * });
 * ```
 *
 * @resource
 */
export declare const Annotation: import("../Resource.ts").ResourceClass<Annotation>;
export declare const AnnotationProvider: () => import("effect/Layer").Layer<Provider.Provider<Annotation>, never, Axiom.AxiomOpContext>;
//# sourceMappingURL=Annotation.d.ts.map