/**
 * Hetzner Cloud-specific error types.
 *
 * Re-exports the common HTTP errors from core and adds the three statuses
 * Hetzner's documented error table uses that core's shared map has no entry
 * for, plus the unknown-error and parse-error wrappers.
 *
 * Hetzner pairs every status with a machine-readable `code` (`locked`,
 * `uniqueness_error`, `resource_limit_exceeded`, …) that is finer-grained
 * than the status itself. The spec declares failures only as the `4xx`/`5xx`
 * wildcards — no operation says which codes it can produce — so the SDK
 * dispatches on the status (the classes here) and carries the code through
 * on {@link UnknownHetznerError} for the statuses nothing else maps. The
 * human-readable `message` is preserved verbatim on every class.
 */
export { BadGateway, BadRequest, Conflict, ConfigError, Forbidden, GatewayTimeout, InternalServerError, Locked, NotFound, ServiceUnavailable, TooManyRequests, Unauthorized, UnprocessableEntity, HTTP_STATUS_MAP, DEFAULT_ERRORS, API_ERRORS, } from "@distilled.cloud/core/errors";
import type { BadRequest as CoreBadRequest, Conflict as CoreConflict, DefaultErrors as CoreDefaultErrors, Forbidden as CoreForbidden, Locked as CoreLocked, NotFound as CoreNotFound, UnprocessableEntity as CoreUnprocessableEntity } from "@distilled.cloud/core/errors";
import * as Schema from "effect/Schema";
declare const MethodNotAllowed_base: Schema.Class<MethodNotAllowed, Schema.TaggedStruct<"MethodNotAllowed", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/**
 * HTTP 405 — `method_not_allowed`: the route exists but not for this method.
 * In practice this means the SDK and the API disagree about a route, so it
 * is a bug report rather than something to branch on.
 */
export declare class MethodNotAllowed extends MethodNotAllowed_base {
}
declare const Gone_base: Schema.Class<Gone, Schema.TaggedStruct<"Gone", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
/**
 * HTTP 410 — `deprecated_api_endpoint`: the endpoint's functionality was
 * REMOVED, not merely marked deprecated. Hetzner announces removals with a
 * date and the spec keeps flagging an endpoint `deprecated: true` until then
 * (those are skipped at generation time), so a 410 from a generated
 * operation means the pinned spec has fallen behind and needs a
 * regeneration. The error `details` carry a changelog link.
 */
export declare class Gone extends Gone_base {
}
declare const PreconditionFailed_base: Schema.Class<PreconditionFailed, Schema.TaggedStruct<"PreconditionFailed", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
/**
 * HTTP 412 — `resource_unavailable`: the resource itself is fine, but what
 * you asked for is not currently orderable — a Server type sold out in the
 * chosen Location, an Image not offered there. Retrying the same request
 * unchanged will keep failing until Hetzner has capacity again, so it is NOT
 * marked retryable; a different Location or Server type is the fix.
 */
export declare class PreconditionFailed extends PreconditionFailed_base {
}
declare const UnknownHetznerError_base: Schema.Class<UnknownHetznerError, Schema.TaggedStruct<"UnknownHetznerError", {
    readonly code: Schema.optional<Schema.String>;
    readonly message: Schema.optional<Schema.String>;
    readonly details: Schema.optional<Schema.Unknown>;
    readonly body: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
/**
 * Unknown Hetzner error — returned when a failed response's HTTP status has
 * no mapped error class. `code` is Hetzner's own error code (the
 * machine-parsable half of its error envelope) and `details` the
 * code-dependent detail object — the offending fields for `invalid_input`
 * and `uniqueness_error`, the exceeded limits for
 * `resource_limit_exceeded`. See
 * https://docs.hetzner.cloud/reference/cloud#errors.
 */
export declare class UnknownHetznerError extends UnknownHetznerError_base {
}
declare const HetznerParseError_base: Schema.Class<HetznerParseError, Schema.TaggedStruct<"HetznerParseError", {
    readonly body: Schema.Unknown;
    readonly cause: Schema.Unknown;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ParseError: true;
    };
});
/** Schema parse error wrapper. */
export declare class HetznerParseError extends HetznerParseError_base {
}
/**
 * Errors any Hetzner operation may surface in addition to the shared HTTP
 * status errors.
 */
export type ClientErrors = UnknownHetznerError | HetznerParseError | MethodNotAllowed | Gone | PreconditionFailed;
/**
 * Default Hetzner operation errors.
 *
 * EVERY operation carries the whole set: the spec types no failure per
 * operation (see the module docs), so any of the statuses Hetzner documents
 * can come back from any call and the error channel says so rather than
 * pretending a `404` is impossible on a route that never declared one.
 */
export type DefaultErrors = CoreDefaultErrors | CoreBadRequest | CoreForbidden | CoreNotFound | CoreConflict | CoreUnprocessableEntity | CoreLocked | ClientErrors;
//# sourceMappingURL=errors.d.ts.map