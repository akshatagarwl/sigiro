import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
/**
 * Hetzner Cloud's API root. The version is a PATH segment rather than a
 * header, so it belongs to the base URL: the generated operations carry
 * version-less routes (`/servers`, `/volumes/{id}`).
 */
export declare const DEFAULT_API_BASE_URL = "https://api.hetzner.cloud/v1";
export interface Config {
    readonly token: Redacted.Redacted<string>;
    readonly apiBaseUrl: string;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "HetznerCredentials", Effect.Effect<Config, never, never>>;
export declare class Credentials extends Credentials_base {
}
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
/** Convenience layer from a plain token + optional base URL. */
export declare const credentials: (config: {
    readonly token: string;
    readonly apiBaseUrl?: string;
}) => Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map