import type * as Layer from "effect/Layer";
import type * as HttpClient from "effect/unstable/http/HttpClient";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import type * as API from "@distilled.cloud/core/api";
import type { ConfigError } from "@distilled.cloud/core/errors";
import { Credentials } from "./credentials.ts";
import { type DefaultErrors } from "./errors.ts";
/**
 * Error channel shared by every generated Hetzner operation. Generated
 * service files annotate operations with `API.OperationMethod<I, O,
 * HetznerOpError, HetznerOpContext>` explicitly so the compiler never infers
 * these back out of the schema generics.
 */
export type HetznerOpError = DefaultErrors | ConfigError | HttpClientError.HttpClientError;
/** Context (requirements) shared by every generated Hetzner operation. */
export type HetznerOpContext = Credentials | HttpClient.HttpClient;
export declare const HetznerProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map