import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Protocol of the Load Balancer. */
export type AddLoadBalancerServiceRequestProtocol = "tcp" | "http" | "https";
export declare const AddLoadBalancerServiceRequestProtocol: any;
/** Type of the health check. */
export type AddLoadBalancerServiceRequestHealthCheckProtocol = "tcp" | "http";
export declare const AddLoadBalancerServiceRequestHealthCheckProtocol: any;
/** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
export type AddLoadBalancerServiceRequestHealthCheckHttpStatusCodesList = Array<string>;
export declare const AddLoadBalancerServiceRequestHealthCheckHttpStatusCodesList: S.Schema<AddLoadBalancerServiceRequestHealthCheckHttpStatusCodesList>;
/** Additional configuration for protocol http. */
export interface AddLoadBalancerServiceRequestHealthCheckHttp {
    /** Host header to send in the HTTP request. May not contain spaces, percent or backslash symbols. Can be null, in that case no host header is sent. */
    domain?: string | null;
    /** HTTP path to use for health checks. May not contain literal spaces, use percent-encoding instead. */
    path?: string;
    /** String that must be contained in HTTP response in order to pass the health check. */
    response?: string;
    /** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
    status_codes?: AddLoadBalancerServiceRequestHealthCheckHttpStatusCodesList;
    /** Use HTTPS for health check. */
    tls?: boolean;
}
export declare const AddLoadBalancerServiceRequestHealthCheckHttp: S.Schema<AddLoadBalancerServiceRequestHealthCheckHttp>;
export interface AddLoadBalancerServiceRequestHealthCheck {
    /** Type of the health check. */
    protocol: AddLoadBalancerServiceRequestHealthCheckProtocol | (string & {});
    /** Port the health check will be performed on. */
    port: number;
    /** Time interval in seconds health checks are performed. */
    interval: number;
    /** Time in seconds after an attempt is considered a timeout. */
    timeout: number;
    /** Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again. */
    retries: number;
    /** Additional configuration for protocol http. */
    http?: AddLoadBalancerServiceRequestHealthCheckHttp;
}
export declare const AddLoadBalancerServiceRequestHealthCheck: S.Schema<AddLoadBalancerServiceRequestHealthCheck>;
/** IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough or if `protocol` is `http`. */
export type AddLoadBalancerServiceRequestHttpCertificatesList = Array<number>;
export declare const AddLoadBalancerServiceRequestHttpCertificatesList: S.Schema<AddLoadBalancerServiceRequestHttpCertificatesList>;
/** Configuration option for protocols http and https. */
export interface AddLoadBalancerServiceRequestHttp {
    /** Name of the cookie used for sticky sessions. */
    cookie_name?: string;
    /** Lifetime of the cookie used for sticky sessions (in seconds). */
    cookie_lifetime?: number;
    /** Idle timeout in seconds for the client and server side. */
    timeout_idle?: number;
    /** IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough or if `protocol` is `http`. */
    certificates?: AddLoadBalancerServiceRequestHttpCertificatesList;
    /** Redirect HTTP requests to HTTPS. Only available if `protocol` is `https`. */
    redirect_http?: boolean;
    /** Use sticky sessions. Only available if `protocol` is `http` or `https`. */
    sticky_sessions?: boolean;
}
export declare const AddLoadBalancerServiceRequestHttp: S.Schema<AddLoadBalancerServiceRequestHttp>;
export interface AddLoadBalancerServiceRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Protocol of the Load Balancer. */
    protocol: AddLoadBalancerServiceRequestProtocol | (string & {});
    /** Port the Load Balancer listens on. */
    listen_port: number;
    /** Port the Load Balancer will balance to. */
    destination_port: number;
    /** Is Proxyprotocol enabled or not. */
    proxyprotocol: boolean;
    health_check: AddLoadBalancerServiceRequestHealthCheck;
    /** Configuration option for protocols http and https. */
    http?: AddLoadBalancerServiceRequestHttp;
}
export declare const AddLoadBalancerServiceRequest: S.Schema<AddLoadBalancerServiceRequest>;
/** Status of the Action. */
export type AddLoadBalancerServiceResponseActionStatus = "running" | "success" | "error";
export declare const AddLoadBalancerServiceResponseActionStatus: any;
export interface AddLoadBalancerServiceResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AddLoadBalancerServiceResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AddLoadBalancerServiceResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const AddLoadBalancerServiceResponseActionResourcesList: S.Schema<AddLoadBalancerServiceResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AddLoadBalancerServiceResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AddLoadBalancerServiceResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface AddLoadBalancerServiceResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AddLoadBalancerServiceResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AddLoadBalancerServiceResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const AddLoadBalancerServiceResponseAction: S.Schema<AddLoadBalancerServiceResponseAction>;
export interface AddLoadBalancerServiceResponse {
    action: AddLoadBalancerServiceResponseAction;
}
export declare const AddLoadBalancerServiceResponse: S.Schema<AddLoadBalancerServiceResponse>;
/** Type of the resource. */
export type AddLoadBalancerTargetRequestType = "server" | "label_selector" | "ip";
export declare const AddLoadBalancerTargetRequestType: any;
/** Configuration for type Server, only valid and required if type is `server`. */
export interface AddLoadBalancerTargetRequestServer {
    /** ID of the Server. */
    id: number;
    /** Optional public IP of the Server to use as target. Must be the Primary IPv4 of the Server, or an IPv6 host address within IPv6 /64 subnet of the Server. If omitted, the Primary IPv4 of the Server is used. Must not be a private IP and is only valid for public targets. */
    ip?: string;
}
export declare const AddLoadBalancerTargetRequestServer: S.Schema<AddLoadBalancerTargetRequestServer>;
/** Configuration for label selector targets, only valid and required if type is `label_selector`. */
export interface AddLoadBalancerTargetRequestLabelSelector {
    /** Label selector. */
    selector: string;
}
export declare const AddLoadBalancerTargetRequestLabelSelector: S.Schema<AddLoadBalancerTargetRequestLabelSelector>;
/** Configuration for an IP target. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only valid and required if type is `ip`. */
export interface AddLoadBalancerTargetRequestIp {
    /** IP of a server that belongs to the same customer (public IPv4/IPv6) or private IP in a subnet type vswitch. */
    ip: string;
}
export declare const AddLoadBalancerTargetRequestIp: S.Schema<AddLoadBalancerTargetRequestIp>;
export interface AddLoadBalancerTargetRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Type of the resource. */
    type: AddLoadBalancerTargetRequestType | (string & {});
    /** Configuration for type Server, only valid and required if type is `server`. */
    server?: AddLoadBalancerTargetRequestServer;
    /** Configuration for label selector targets, only valid and required if type is `label_selector`. */
    label_selector?: AddLoadBalancerTargetRequestLabelSelector;
    /** Configuration for an IP target. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only valid and required if type is `ip`. */
    ip?: AddLoadBalancerTargetRequestIp;
    /** Use the private network IP instead of the public IP of the Server, requires the Server and Load Balancer to be in the same network. Only valid for target types `server` and `label_selector`. */
    use_private_ip?: boolean;
}
export declare const AddLoadBalancerTargetRequest: S.Schema<AddLoadBalancerTargetRequest>;
/** Status of the Action. */
export type AddLoadBalancerTargetResponseActionStatus = "running" | "success" | "error";
export declare const AddLoadBalancerTargetResponseActionStatus: any;
export type AddLoadBalancerTargetResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const AddLoadBalancerTargetResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AddLoadBalancerTargetResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const AddLoadBalancerTargetResponseActionResourcesList: S.Schema<AddLoadBalancerTargetResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type AddLoadBalancerTargetResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const AddLoadBalancerTargetResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface AddLoadBalancerTargetResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AddLoadBalancerTargetResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AddLoadBalancerTargetResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const AddLoadBalancerTargetResponseAction: S.Schema<AddLoadBalancerTargetResponseAction>;
export interface AddLoadBalancerTargetResponse {
    action: AddLoadBalancerTargetResponseAction;
}
export declare const AddLoadBalancerTargetResponse: S.Schema<AddLoadBalancerTargetResponse>;
export interface AttachLoadBalancerToNetworkRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** ID of an existing network to attach the Load Balancer to. */
    network: number;
    /** IP to request to be assigned to this Load Balancer; if you do not provide this then you will be auto assigned an IP address. */
    ip?: string;
    /** IP range in CIDR block notation of the subnet to attach to. This allows for auto assigning an IP address for a specific subnet. Providing `ip` that is not part of `ip_range` will result in an error. */
    ip_range?: string;
}
export declare const AttachLoadBalancerToNetworkRequest: S.Schema<AttachLoadBalancerToNetworkRequest>;
/** Status of the Action. */
export type AttachLoadBalancerToNetworkResponseActionStatus = "running" | "success" | "error";
export declare const AttachLoadBalancerToNetworkResponseActionStatus: any;
export type AttachLoadBalancerToNetworkResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const AttachLoadBalancerToNetworkResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AttachLoadBalancerToNetworkResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const AttachLoadBalancerToNetworkResponseActionResourcesList: S.Schema<AttachLoadBalancerToNetworkResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type AttachLoadBalancerToNetworkResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const AttachLoadBalancerToNetworkResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface AttachLoadBalancerToNetworkResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AttachLoadBalancerToNetworkResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AttachLoadBalancerToNetworkResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const AttachLoadBalancerToNetworkResponseAction: S.Schema<AttachLoadBalancerToNetworkResponseAction>;
export interface AttachLoadBalancerToNetworkResponse {
    action: AttachLoadBalancerToNetworkResponseAction;
}
export declare const AttachLoadBalancerToNetworkResponse: S.Schema<AttachLoadBalancerToNetworkResponse>;
/** Type of the algorithm. */
export type ChangeLoadBalancerAlgorithmRequestType = "round_robin" | "least_connections";
export declare const ChangeLoadBalancerAlgorithmRequestType: any;
export interface ChangeLoadBalancerAlgorithmRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Type of the algorithm. */
    type: ChangeLoadBalancerAlgorithmRequestType | (string & {});
}
export declare const ChangeLoadBalancerAlgorithmRequest: S.Schema<ChangeLoadBalancerAlgorithmRequest>;
/** Status of the Action. */
export type ChangeLoadBalancerAlgorithmResponseActionStatus = "running" | "success" | "error";
export declare const ChangeLoadBalancerAlgorithmResponseActionStatus: any;
export type ChangeLoadBalancerAlgorithmResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const ChangeLoadBalancerAlgorithmResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeLoadBalancerAlgorithmResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const ChangeLoadBalancerAlgorithmResponseActionResourcesList: S.Schema<ChangeLoadBalancerAlgorithmResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeLoadBalancerAlgorithmResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const ChangeLoadBalancerAlgorithmResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface ChangeLoadBalancerAlgorithmResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeLoadBalancerAlgorithmResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeLoadBalancerAlgorithmResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const ChangeLoadBalancerAlgorithmResponseAction: S.Schema<ChangeLoadBalancerAlgorithmResponseAction>;
export interface ChangeLoadBalancerAlgorithmResponse {
    action: ChangeLoadBalancerAlgorithmResponseAction;
}
export declare const ChangeLoadBalancerAlgorithmResponse: S.Schema<ChangeLoadBalancerAlgorithmResponse>;
export interface ChangeLoadBalancerDnsPtrRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Single IPv4 or IPv6 address to create pointer for. */
    ip: string;
    /** Domain Name to point to. PTR record content used for reverse DNS. Set to null to reset (IPv4) to the default value or remove (IPv6) the record. */
    dns_ptr?: string | null;
}
export declare const ChangeLoadBalancerDnsPtrRequest: S.Schema<ChangeLoadBalancerDnsPtrRequest>;
/** Status of the Action. */
export type ChangeLoadBalancerDnsPtrResponseActionStatus = "running" | "success" | "error";
export declare const ChangeLoadBalancerDnsPtrResponseActionStatus: any;
export type ChangeLoadBalancerDnsPtrResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const ChangeLoadBalancerDnsPtrResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeLoadBalancerDnsPtrResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const ChangeLoadBalancerDnsPtrResponseActionResourcesList: S.Schema<ChangeLoadBalancerDnsPtrResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeLoadBalancerDnsPtrResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const ChangeLoadBalancerDnsPtrResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface ChangeLoadBalancerDnsPtrResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeLoadBalancerDnsPtrResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeLoadBalancerDnsPtrResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const ChangeLoadBalancerDnsPtrResponseAction: S.Schema<ChangeLoadBalancerDnsPtrResponseAction>;
export interface ChangeLoadBalancerDnsPtrResponse {
    action: ChangeLoadBalancerDnsPtrResponseAction;
}
export declare const ChangeLoadBalancerDnsPtrResponse: S.Schema<ChangeLoadBalancerDnsPtrResponse>;
export interface ChangeLoadBalancerProtectionRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** If true, prevents the Load Balancer from being deleted. */
    delete?: boolean;
}
export declare const ChangeLoadBalancerProtectionRequest: S.Schema<ChangeLoadBalancerProtectionRequest>;
/** Status of the Action. */
export type ChangeLoadBalancerProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeLoadBalancerProtectionResponseActionStatus: any;
export type ChangeLoadBalancerProtectionResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const ChangeLoadBalancerProtectionResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeLoadBalancerProtectionResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const ChangeLoadBalancerProtectionResponseActionResourcesList: S.Schema<ChangeLoadBalancerProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeLoadBalancerProtectionResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const ChangeLoadBalancerProtectionResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface ChangeLoadBalancerProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeLoadBalancerProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeLoadBalancerProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const ChangeLoadBalancerProtectionResponseAction: S.Schema<ChangeLoadBalancerProtectionResponseAction>;
export interface ChangeLoadBalancerProtectionResponse {
    action: ChangeLoadBalancerProtectionResponseAction;
}
export declare const ChangeLoadBalancerProtectionResponse: S.Schema<ChangeLoadBalancerProtectionResponse>;
export interface ChangeLoadBalancerTypeRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** ID or name of Load Balancer type the Load Balancer should migrate to. */
    load_balancer_type: string;
}
export declare const ChangeLoadBalancerTypeRequest: S.Schema<ChangeLoadBalancerTypeRequest>;
/** Status of the Action. */
export type ChangeLoadBalancerTypeResponseActionStatus = "running" | "success" | "error";
export declare const ChangeLoadBalancerTypeResponseActionStatus: any;
export type ChangeLoadBalancerTypeResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const ChangeLoadBalancerTypeResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeLoadBalancerTypeResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const ChangeLoadBalancerTypeResponseActionResourcesList: S.Schema<ChangeLoadBalancerTypeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeLoadBalancerTypeResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const ChangeLoadBalancerTypeResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface ChangeLoadBalancerTypeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeLoadBalancerTypeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeLoadBalancerTypeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const ChangeLoadBalancerTypeResponseAction: S.Schema<ChangeLoadBalancerTypeResponseAction>;
export interface ChangeLoadBalancerTypeResponse {
    action: ChangeLoadBalancerTypeResponseAction;
}
export declare const ChangeLoadBalancerTypeResponse: S.Schema<ChangeLoadBalancerTypeResponse>;
export interface DeleteLoadBalancerServiceRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** The listen port of the service you want to delete. */
    listen_port: number;
}
export declare const DeleteLoadBalancerServiceRequest: S.Schema<DeleteLoadBalancerServiceRequest>;
/** Status of the Action. */
export type DeleteLoadBalancerServiceResponseActionStatus = "running" | "success" | "error";
export declare const DeleteLoadBalancerServiceResponseActionStatus: any;
export type DeleteLoadBalancerServiceResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const DeleteLoadBalancerServiceResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DeleteLoadBalancerServiceResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const DeleteLoadBalancerServiceResponseActionResourcesList: S.Schema<DeleteLoadBalancerServiceResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DeleteLoadBalancerServiceResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const DeleteLoadBalancerServiceResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface DeleteLoadBalancerServiceResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DeleteLoadBalancerServiceResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DeleteLoadBalancerServiceResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const DeleteLoadBalancerServiceResponseAction: S.Schema<DeleteLoadBalancerServiceResponseAction>;
export interface DeleteLoadBalancerServiceResponse {
    action: DeleteLoadBalancerServiceResponseAction;
}
export declare const DeleteLoadBalancerServiceResponse: S.Schema<DeleteLoadBalancerServiceResponse>;
export interface DetachLoadBalancerFromNetworkRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** ID of an existing network to detach the Load Balancer from. */
    network: number;
}
export declare const DetachLoadBalancerFromNetworkRequest: S.Schema<DetachLoadBalancerFromNetworkRequest>;
/** Status of the Action. */
export type DetachLoadBalancerFromNetworkResponseActionStatus = "running" | "success" | "error";
export declare const DetachLoadBalancerFromNetworkResponseActionStatus: any;
export type DetachLoadBalancerFromNetworkResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const DetachLoadBalancerFromNetworkResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DetachLoadBalancerFromNetworkResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const DetachLoadBalancerFromNetworkResponseActionResourcesList: S.Schema<DetachLoadBalancerFromNetworkResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DetachLoadBalancerFromNetworkResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const DetachLoadBalancerFromNetworkResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface DetachLoadBalancerFromNetworkResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DetachLoadBalancerFromNetworkResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DetachLoadBalancerFromNetworkResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const DetachLoadBalancerFromNetworkResponseAction: S.Schema<DetachLoadBalancerFromNetworkResponseAction>;
export interface DetachLoadBalancerFromNetworkResponse {
    action: DetachLoadBalancerFromNetworkResponseAction;
}
export declare const DetachLoadBalancerFromNetworkResponse: S.Schema<DetachLoadBalancerFromNetworkResponse>;
export interface DisableLoadBalancerPublicInterfaceRequest {
    /** ID of the Load Balancer. */
    id: number;
}
export declare const DisableLoadBalancerPublicInterfaceRequest: S.Schema<DisableLoadBalancerPublicInterfaceRequest>;
/** Status of the Action. */
export type DisableLoadBalancerPublicInterfaceResponseActionStatus = "running" | "success" | "error";
export declare const DisableLoadBalancerPublicInterfaceResponseActionStatus: any;
export type DisableLoadBalancerPublicInterfaceResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const DisableLoadBalancerPublicInterfaceResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DisableLoadBalancerPublicInterfaceResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const DisableLoadBalancerPublicInterfaceResponseActionResourcesList: S.Schema<DisableLoadBalancerPublicInterfaceResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DisableLoadBalancerPublicInterfaceResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const DisableLoadBalancerPublicInterfaceResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface DisableLoadBalancerPublicInterfaceResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DisableLoadBalancerPublicInterfaceResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DisableLoadBalancerPublicInterfaceResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const DisableLoadBalancerPublicInterfaceResponseAction: S.Schema<DisableLoadBalancerPublicInterfaceResponseAction>;
export interface DisableLoadBalancerPublicInterfaceResponse {
    action: DisableLoadBalancerPublicInterfaceResponseAction;
}
export declare const DisableLoadBalancerPublicInterfaceResponse: S.Schema<DisableLoadBalancerPublicInterfaceResponse>;
export interface EnableLoadBalancerPublicInterfaceRequest {
    /** ID of the Load Balancer. */
    id: number;
}
export declare const EnableLoadBalancerPublicInterfaceRequest: S.Schema<EnableLoadBalancerPublicInterfaceRequest>;
/** Status of the Action. */
export type EnableLoadBalancerPublicInterfaceResponseActionStatus = "running" | "success" | "error";
export declare const EnableLoadBalancerPublicInterfaceResponseActionStatus: any;
export type EnableLoadBalancerPublicInterfaceResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const EnableLoadBalancerPublicInterfaceResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type EnableLoadBalancerPublicInterfaceResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const EnableLoadBalancerPublicInterfaceResponseActionResourcesList: S.Schema<EnableLoadBalancerPublicInterfaceResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type EnableLoadBalancerPublicInterfaceResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const EnableLoadBalancerPublicInterfaceResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface EnableLoadBalancerPublicInterfaceResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: EnableLoadBalancerPublicInterfaceResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: EnableLoadBalancerPublicInterfaceResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const EnableLoadBalancerPublicInterfaceResponseAction: S.Schema<EnableLoadBalancerPublicInterfaceResponseAction>;
export interface EnableLoadBalancerPublicInterfaceResponse {
    action: EnableLoadBalancerPublicInterfaceResponseAction;
}
export declare const EnableLoadBalancerPublicInterfaceResponse: S.Schema<EnableLoadBalancerPublicInterfaceResponse>;
export interface GetLoadBalancersActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetLoadBalancersActionRequest: S.Schema<GetLoadBalancersActionRequest>;
/** Status of the Action. */
export type GetLoadBalancersActionResponseActionStatus = "running" | "success" | "error";
export declare const GetLoadBalancersActionResponseActionStatus: any;
export type GetLoadBalancersActionResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const GetLoadBalancersActionResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetLoadBalancersActionResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const GetLoadBalancersActionResponseActionResourcesList: S.Schema<GetLoadBalancersActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetLoadBalancersActionResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const GetLoadBalancersActionResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface GetLoadBalancersActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetLoadBalancersActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetLoadBalancersActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const GetLoadBalancersActionResponseAction: S.Schema<GetLoadBalancersActionResponseAction>;
export interface GetLoadBalancersActionResponse {
    action: GetLoadBalancersActionResponseAction;
}
export declare const GetLoadBalancersActionResponse: S.Schema<GetLoadBalancersActionResponse>;
export type ListLoadBalancerActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListLoadBalancerActionsRequestSortItem: any;
export type ListLoadBalancerActionsRequestSortList = Array<ListLoadBalancerActionsRequestSortItem | (string & {})>;
export declare const ListLoadBalancerActionsRequestSortList: S.Schema<ListLoadBalancerActionsRequestSortList>;
/** Status of the Action. */
export type ListLoadBalancerActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListLoadBalancerActionsRequestStatusItem: any;
export type ListLoadBalancerActionsRequestStatusList = Array<ListLoadBalancerActionsRequestStatusItem | (string & {})>;
export declare const ListLoadBalancerActionsRequestStatusList: S.Schema<ListLoadBalancerActionsRequestStatusList>;
export interface ListLoadBalancerActionsRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListLoadBalancerActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListLoadBalancerActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListLoadBalancerActionsRequest: S.Schema<ListLoadBalancerActionsRequest>;
/** Status of the Action. */
export type ListLoadBalancerActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListLoadBalancerActionsResponseActionsItemStatus: any;
export type ListLoadBalancerActionsResponseActionsItemResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const ListLoadBalancerActionsResponseActionsItemResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListLoadBalancerActionsResponseActionsItemResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const ListLoadBalancerActionsResponseActionsItemResourcesList: S.Schema<ListLoadBalancerActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListLoadBalancerActionsResponseActionsItemError = AddLoadBalancerServiceResponseActionError;
export declare const ListLoadBalancerActionsResponseActionsItemError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface ListLoadBalancerActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListLoadBalancerActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListLoadBalancerActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const ListLoadBalancerActionsResponseActionsItem: S.Schema<ListLoadBalancerActionsResponseActionsItem>;
export type ListLoadBalancerActionsResponseActionsList = Array<ListLoadBalancerActionsResponseActionsItem>;
export declare const ListLoadBalancerActionsResponseActionsList: S.Schema<ListLoadBalancerActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListLoadBalancerActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListLoadBalancerActionsResponseMetaPagination: S.Schema<ListLoadBalancerActionsResponseMetaPagination>;
export interface ListLoadBalancerActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListLoadBalancerActionsResponseMetaPagination;
}
export declare const ListLoadBalancerActionsResponseMeta: S.Schema<ListLoadBalancerActionsResponseMeta>;
export interface ListLoadBalancerActionsResponse {
    actions: ListLoadBalancerActionsResponseActionsList;
    meta: ListLoadBalancerActionsResponseMeta;
}
export declare const ListLoadBalancerActionsResponse: S.Schema<ListLoadBalancerActionsResponse>;
export type ListLoadBalancersActionsRequestIdList = Array<number>;
export declare const ListLoadBalancersActionsRequestIdList: S.Schema<ListLoadBalancersActionsRequestIdList>;
export type ListLoadBalancersActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListLoadBalancersActionsRequestSortItem: any;
export type ListLoadBalancersActionsRequestSortList = Array<ListLoadBalancersActionsRequestSortItem | (string & {})>;
export declare const ListLoadBalancersActionsRequestSortList: S.Schema<ListLoadBalancersActionsRequestSortList>;
/** Status of the Action. */
export type ListLoadBalancersActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListLoadBalancersActionsRequestStatusItem: any;
export type ListLoadBalancersActionsRequestStatusList = Array<ListLoadBalancersActionsRequestStatusItem | (string & {})>;
export declare const ListLoadBalancersActionsRequestStatusList: S.Schema<ListLoadBalancersActionsRequestStatusList>;
export interface ListLoadBalancersActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListLoadBalancersActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListLoadBalancersActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListLoadBalancersActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListLoadBalancersActionsRequest: S.Schema<ListLoadBalancersActionsRequest>;
/** Status of the Action. */
export type ListLoadBalancersActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListLoadBalancersActionsResponseActionsItemStatus: any;
export type ListLoadBalancersActionsResponseActionsItemResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const ListLoadBalancersActionsResponseActionsItemResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListLoadBalancersActionsResponseActionsItemResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const ListLoadBalancersActionsResponseActionsItemResourcesList: S.Schema<ListLoadBalancersActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListLoadBalancersActionsResponseActionsItemError = AddLoadBalancerServiceResponseActionError;
export declare const ListLoadBalancersActionsResponseActionsItemError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface ListLoadBalancersActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListLoadBalancersActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListLoadBalancersActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const ListLoadBalancersActionsResponseActionsItem: S.Schema<ListLoadBalancersActionsResponseActionsItem>;
export type ListLoadBalancersActionsResponseActionsList = Array<ListLoadBalancersActionsResponseActionsItem>;
export declare const ListLoadBalancersActionsResponseActionsList: S.Schema<ListLoadBalancersActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListLoadBalancersActionsResponseMetaPagination = ListLoadBalancerActionsResponseMetaPagination;
export declare const ListLoadBalancersActionsResponseMetaPagination: S.Schema<ListLoadBalancerActionsResponseMetaPagination>;
export type ListLoadBalancersActionsResponseMeta = ListLoadBalancerActionsResponseMeta;
export declare const ListLoadBalancersActionsResponseMeta: S.Schema<ListLoadBalancerActionsResponseMeta>;
export interface ListLoadBalancersActionsResponse {
    actions: ListLoadBalancersActionsResponseActionsList;
    meta: ListLoadBalancerActionsResponseMeta;
}
export declare const ListLoadBalancersActionsResponse: S.Schema<ListLoadBalancersActionsResponse>;
/** Type of the resource. */
export type RemoveLoadBalancerTargetRequestType = "server" | "label_selector" | "ip";
export declare const RemoveLoadBalancerTargetRequestType: any;
/** Configuration for type Server, only valid and required if type is `server`. */
export type RemoveLoadBalancerTargetRequestServer = AddLoadBalancerTargetRequestServer;
export declare const RemoveLoadBalancerTargetRequestServer: S.Schema<AddLoadBalancerTargetRequestServer>;
/** Configuration for label selector targets, only valid and required if type is `label_selector`. */
export type RemoveLoadBalancerTargetRequestLabelSelector = AddLoadBalancerTargetRequestLabelSelector;
export declare const RemoveLoadBalancerTargetRequestLabelSelector: S.Schema<AddLoadBalancerTargetRequestLabelSelector>;
/** Configuration for an IP target. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only valid and required if type is `ip`. */
export type RemoveLoadBalancerTargetRequestIp = AddLoadBalancerTargetRequestIp;
export declare const RemoveLoadBalancerTargetRequestIp: S.Schema<AddLoadBalancerTargetRequestIp>;
export interface RemoveLoadBalancerTargetRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Type of the resource. */
    type: RemoveLoadBalancerTargetRequestType | (string & {});
    /** Configuration for type Server, only valid and required if type is `server`. */
    server?: AddLoadBalancerTargetRequestServer;
    /** Configuration for label selector targets, only valid and required if type is `label_selector`. */
    label_selector?: AddLoadBalancerTargetRequestLabelSelector;
    /** Configuration for an IP target. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only valid and required if type is `ip`. */
    ip?: AddLoadBalancerTargetRequestIp;
}
export declare const RemoveLoadBalancerTargetRequest: S.Schema<RemoveLoadBalancerTargetRequest>;
/** Status of the Action. */
export type RemoveLoadBalancerTargetResponseActionStatus = "running" | "success" | "error";
export declare const RemoveLoadBalancerTargetResponseActionStatus: any;
export type RemoveLoadBalancerTargetResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const RemoveLoadBalancerTargetResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RemoveLoadBalancerTargetResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const RemoveLoadBalancerTargetResponseActionResourcesList: S.Schema<RemoveLoadBalancerTargetResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RemoveLoadBalancerTargetResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const RemoveLoadBalancerTargetResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface RemoveLoadBalancerTargetResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RemoveLoadBalancerTargetResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RemoveLoadBalancerTargetResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const RemoveLoadBalancerTargetResponseAction: S.Schema<RemoveLoadBalancerTargetResponseAction>;
export interface RemoveLoadBalancerTargetResponse {
    action: RemoveLoadBalancerTargetResponseAction;
}
export declare const RemoveLoadBalancerTargetResponse: S.Schema<RemoveLoadBalancerTargetResponse>;
/** Protocol of the Load Balancer. */
export type UpdateLoadBalancerServiceRequestProtocol = "tcp" | "http" | "https";
export declare const UpdateLoadBalancerServiceRequestProtocol: any;
/** Type of the health check. */
export type UpdateLoadBalancerServiceRequestHealthCheckProtocol = "tcp" | "http";
export declare const UpdateLoadBalancerServiceRequestHealthCheckProtocol: any;
/** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
export type UpdateLoadBalancerServiceRequestHealthCheckHttpStatusCodesList = Array<string>;
export declare const UpdateLoadBalancerServiceRequestHealthCheckHttpStatusCodesList: S.Schema<UpdateLoadBalancerServiceRequestHealthCheckHttpStatusCodesList>;
/** Additional configuration for protocol http. */
export interface UpdateLoadBalancerServiceRequestHealthCheckHttp {
    /** Host header to send in the HTTP request. May not contain spaces, percent or backslash symbols. Can be null, in that case no host header is sent. */
    domain?: string | null;
    /** HTTP path to use for health checks. May not contain literal spaces, use percent-encoding instead. */
    path?: string;
    /** String that must be contained in HTTP response in order to pass the health check. */
    response?: string;
    /** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
    status_codes?: UpdateLoadBalancerServiceRequestHealthCheckHttpStatusCodesList;
    /** Use HTTPS for health check. */
    tls?: boolean;
}
export declare const UpdateLoadBalancerServiceRequestHealthCheckHttp: S.Schema<UpdateLoadBalancerServiceRequestHealthCheckHttp>;
export interface UpdateLoadBalancerServiceRequestHealthCheck {
    /** Type of the health check. */
    protocol: UpdateLoadBalancerServiceRequestHealthCheckProtocol | (string & {});
    /** Port the health check will be performed on. */
    port: number;
    /** Time interval in seconds health checks are performed. */
    interval: number;
    /** Time in seconds after an attempt is considered a timeout. */
    timeout: number;
    /** Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again. */
    retries: number;
    /** Additional configuration for protocol http. */
    http?: UpdateLoadBalancerServiceRequestHealthCheckHttp;
}
export declare const UpdateLoadBalancerServiceRequestHealthCheck: S.Schema<UpdateLoadBalancerServiceRequestHealthCheck>;
/** IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough or if `protocol` is `http`. */
export type UpdateLoadBalancerServiceRequestHttpCertificatesList = Array<number>;
export declare const UpdateLoadBalancerServiceRequestHttpCertificatesList: S.Schema<UpdateLoadBalancerServiceRequestHttpCertificatesList>;
/** Configuration option for protocols http and https. */
export interface UpdateLoadBalancerServiceRequestHttp {
    /** Name of the cookie used for sticky sessions. */
    cookie_name?: string;
    /** Lifetime of the cookie used for sticky sessions (in seconds). */
    cookie_lifetime?: number;
    /** Idle timeout in seconds for the client and server side. */
    timeout_idle?: number;
    /** IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough or if `protocol` is `http`. */
    certificates?: UpdateLoadBalancerServiceRequestHttpCertificatesList;
    /** Redirect HTTP requests to HTTPS. Only available if `protocol` is `https`. */
    redirect_http?: boolean;
    /** Use sticky sessions. Only available if `protocol` is `http` or `https`. */
    sticky_sessions?: boolean;
}
export declare const UpdateLoadBalancerServiceRequestHttp: S.Schema<UpdateLoadBalancerServiceRequestHttp>;
export interface UpdateLoadBalancerServiceRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Protocol of the Load Balancer. */
    protocol?: UpdateLoadBalancerServiceRequestProtocol | (string & {});
    /** Port the Load Balancer listens on. */
    listen_port: number;
    /** Port the Load Balancer will balance to. */
    destination_port?: number;
    /** Is Proxyprotocol enabled or not. */
    proxyprotocol?: boolean;
    health_check?: UpdateLoadBalancerServiceRequestHealthCheck;
    /** Configuration option for protocols http and https. */
    http?: UpdateLoadBalancerServiceRequestHttp;
}
export declare const UpdateLoadBalancerServiceRequest: S.Schema<UpdateLoadBalancerServiceRequest>;
/** Status of the Action. */
export type UpdateLoadBalancerServiceResponseActionStatus = "running" | "success" | "error";
export declare const UpdateLoadBalancerServiceResponseActionStatus: any;
export type UpdateLoadBalancerServiceResponseActionResourcesItem = AddLoadBalancerServiceResponseActionResourcesItem;
export declare const UpdateLoadBalancerServiceResponseActionResourcesItem: S.Schema<AddLoadBalancerServiceResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type UpdateLoadBalancerServiceResponseActionResourcesList = Array<AddLoadBalancerServiceResponseActionResourcesItem>;
export declare const UpdateLoadBalancerServiceResponseActionResourcesList: S.Schema<UpdateLoadBalancerServiceResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type UpdateLoadBalancerServiceResponseActionError = AddLoadBalancerServiceResponseActionError;
export declare const UpdateLoadBalancerServiceResponseActionError: S.Schema<AddLoadBalancerServiceResponseActionError>;
export interface UpdateLoadBalancerServiceResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: UpdateLoadBalancerServiceResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: UpdateLoadBalancerServiceResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddLoadBalancerServiceResponseActionError | null;
}
export declare const UpdateLoadBalancerServiceResponseAction: S.Schema<UpdateLoadBalancerServiceResponseAction>;
export interface UpdateLoadBalancerServiceResponse {
    action: UpdateLoadBalancerServiceResponseAction;
}
export declare const UpdateLoadBalancerServiceResponse: S.Schema<UpdateLoadBalancerServiceResponse>;
export type AddLoadBalancerServiceError = HetznerOpError;
/** Add Service Adds a service to a Load Balancer. #### Operation specific errors */
export declare const addLoadBalancerService: API.OperationMethod<AddLoadBalancerServiceRequest, AddLoadBalancerServiceResponse, AddLoadBalancerServiceError, HetznerOpContext>;
export type AddLoadBalancerTargetError = HetznerOpError;
/** Add Target Adds a target to a Load Balancer. #### Operation specific errors */
export declare const addLoadBalancerTarget: API.OperationMethod<AddLoadBalancerTargetRequest, AddLoadBalancerTargetResponse, AddLoadBalancerTargetError, HetznerOpContext>;
export type AttachLoadBalancerToNetworkError = HetznerOpError;
/** Attach a Load Balancer to a Network Attach a Load Balancer to a Network. #### Operation specific errors */
export declare const attachLoadBalancerToNetwork: API.OperationMethod<AttachLoadBalancerToNetworkRequest, AttachLoadBalancerToNetworkResponse, AttachLoadBalancerToNetworkError, HetznerOpContext>;
export type ChangeLoadBalancerAlgorithmError = HetznerOpError;
/** Change Algorithm Change the algorithm that determines to which target new requests are sent. */
export declare const changeLoadBalancerAlgorithm: API.OperationMethod<ChangeLoadBalancerAlgorithmRequest, ChangeLoadBalancerAlgorithmResponse, ChangeLoadBalancerAlgorithmError, HetznerOpContext>;
export type ChangeLoadBalancerDnsPtrError = HetznerOpError;
/** Change reverse DNS entry for this Load Balancer Changes the hostname that will appear when getting the hostname belonging to the public IPs (IPv4 and IPv6) of this Load Balancer. Floating IPs assigned to the Server are not affected by this. */
export declare const changeLoadBalancerDnsPtr: API.OperationMethod<ChangeLoadBalancerDnsPtrRequest, ChangeLoadBalancerDnsPtrResponse, ChangeLoadBalancerDnsPtrError, HetznerOpContext>;
export type ChangeLoadBalancerProtectionError = HetznerOpError;
/** Change Load Balancer Protection Changes the protection configuration of a Load Balancer. */
export declare const changeLoadBalancerProtection: API.OperationMethod<ChangeLoadBalancerProtectionRequest, ChangeLoadBalancerProtectionResponse, ChangeLoadBalancerProtectionError, HetznerOpContext>;
export type ChangeLoadBalancerTypeError = HetznerOpError;
/** Change the Type of a Load Balancer Changes the type (Max Services, Max Targets and Max Connections) of a Load Balancer. #### Operation specific errors */
export declare const changeLoadBalancerType: API.OperationMethod<ChangeLoadBalancerTypeRequest, ChangeLoadBalancerTypeResponse, ChangeLoadBalancerTypeError, HetznerOpContext>;
export type DeleteLoadBalancerServiceError = HetznerOpError;
/** Delete Service Delete a service of a Load Balancer. */
export declare const deleteLoadBalancerService: API.OperationMethod<DeleteLoadBalancerServiceRequest, DeleteLoadBalancerServiceResponse, DeleteLoadBalancerServiceError, HetznerOpContext>;
export type DetachLoadBalancerFromNetworkError = HetznerOpError;
/** Detach a Load Balancer from a Network Detaches a Load Balancer from a network. */
export declare const detachLoadBalancerFromNetwork: API.OperationMethod<DetachLoadBalancerFromNetworkRequest, DetachLoadBalancerFromNetworkResponse, DetachLoadBalancerFromNetworkError, HetznerOpContext>;
export type DisableLoadBalancerPublicInterfaceError = HetznerOpError;
/** Disable the public interface of a Load Balancer Disable the public interface of a Load Balancer. The Load Balancer will be not accessible from the internet via its public IPs. #### Operation specific errors */
export declare const disableLoadBalancerPublicInterface: API.OperationMethod<DisableLoadBalancerPublicInterfaceRequest, DisableLoadBalancerPublicInterfaceResponse, DisableLoadBalancerPublicInterfaceError, HetznerOpContext>;
export type EnableLoadBalancerPublicInterfaceError = HetznerOpError;
/** Enable the public interface of a Load Balancer Enable the public interface of a Load Balancer. The Load Balancer will be accessible from the internet via its public IPs. */
export declare const enableLoadBalancerPublicInterface: API.OperationMethod<EnableLoadBalancerPublicInterfaceRequest, EnableLoadBalancerPublicInterfaceResponse, EnableLoadBalancerPublicInterfaceError, HetznerOpContext>;
export type GetLoadBalancersActionError = HetznerOpError;
/** Get an Action Returns a specific Action object. */
export declare const getLoadBalancersAction: API.OperationMethod<GetLoadBalancersActionRequest, GetLoadBalancersActionResponse, GetLoadBalancersActionError, HetznerOpContext>;
export type ListLoadBalancerActionsError = HetznerOpError;
/** List Actions for a Load Balancer Returns all Action objects for a Load Balancer. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter. */
export declare const listLoadBalancerActions: API.PaginatedOperationMethod<ListLoadBalancerActionsRequest, ListLoadBalancerActionsResponse, ListLoadBalancerActionsError, HetznerOpContext, ListLoadBalancerActionsResponseActionsItem>;
export type ListLoadBalancersActionsError = HetznerOpError;
/** List Actions Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` and `id` parameter. */
export declare const listLoadBalancersActions: API.PaginatedOperationMethod<ListLoadBalancersActionsRequest, ListLoadBalancersActionsResponse, ListLoadBalancersActionsError, HetznerOpContext, ListLoadBalancersActionsResponseActionsItem>;
export type RemoveLoadBalancerTargetError = HetznerOpError;
/** Remove Target Removes a target from a Load Balancer. */
export declare const removeLoadBalancerTarget: API.OperationMethod<RemoveLoadBalancerTargetRequest, RemoveLoadBalancerTargetResponse, RemoveLoadBalancerTargetError, HetznerOpContext>;
export type UpdateLoadBalancerServiceError = HetznerOpError;
/** Update Service Updates a Load Balancer Service. #### Operation specific errors */
export declare const updateLoadBalancerService: API.OperationMethod<UpdateLoadBalancerServiceRequest, UpdateLoadBalancerServiceResponse, UpdateLoadBalancerServiceError, HetznerOpContext>;
//# sourceMappingURL=load_balancer_actions.d.ts.map