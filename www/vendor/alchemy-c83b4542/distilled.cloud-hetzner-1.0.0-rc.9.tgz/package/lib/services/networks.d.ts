import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateNetworkRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateNetworkRequestLabelsMap: S.Schema<CreateNetworkRequestLabelsMap>;
/** Type of subnet. */
export type CreateNetworkRequestSubnetsItemType = "cloud" | "server" | "vswitch";
export declare const CreateNetworkRequestSubnetsItemType: any;
export interface CreateNetworkRequestSubnetsItem {
    /** Type of subnet. */
    type: CreateNetworkRequestSubnetsItemType | (string & {});
    /** IP range of the subnet. Uses CIDR notation. Must be a subnet of the parent [Networks](#tag/networks) `ip_range`. Must not overlap with any other subnets or with any destinations in routes. Minimum network size is /30. We highly recommend that you pick a larger subnet with a /24 netmask. */
    ip_range?: string;
    /** Name of the [Network Zone](#tag/network-zones). The [Location](#tag/locations) contains the `network_zone` property it belongs to. */
    network_zone: string;
    /** ID of the robot vSwitch. Must only be supplied for subnets of type `vswitch`. */
    vswitch_id?: number;
}
export declare const CreateNetworkRequestSubnetsItem: S.Schema<CreateNetworkRequestSubnetsItem>;
/** Array of subnets to allocate. */
export type CreateNetworkRequestSubnetsList = Array<CreateNetworkRequestSubnetsItem>;
export declare const CreateNetworkRequestSubnetsList: S.Schema<CreateNetworkRequestSubnetsList>;
export interface CreateNetworkRequestRoutesItem {
    /** Destination network or host of the route. Packages addressed for IPs matching the destination IP prefix will be send to the specified gateway. Must be one of * private IPv4 ranges of RFC1918 * or `0.0.0.0/0`. Must not overlap with * an existing ip_range in any subnets * or with any destinations in other routes * or with `172.31.1.1`. `172.31.1.1` is being used as a gateway for the public network interface of [Servers](#tag/servers). */
    destination: string;
    /** Gateway of the route. Packages addressed for the specified destination will be send to this IP address. Cannot be * the first IP of the networks ip_range, * an IP behind a vSwitch or * `172.31.1.1`. `172.31.1.1` is being used as a gateway for the public network interface of [Servers](#tag/servers). */
    gateway: string;
}
export declare const CreateNetworkRequestRoutesItem: S.Schema<CreateNetworkRequestRoutesItem>;
/** Array of routes set in this [Network](#tag/networks). */
export type CreateNetworkRequestRoutesList = Array<CreateNetworkRequestRoutesItem>;
export declare const CreateNetworkRequestRoutesList: S.Schema<CreateNetworkRequestRoutesList>;
export interface CreateNetworkRequest {
    /** Name of the [Network](#tag/networks). */
    name: string;
    /** IP range of the [Network](#tag/networks). Uses CIDR notation. Must span all included subnets. Must be one of the private IPv4 ranges of RFC1918. Minimum network size is /24. We highly recommend that you pick a larger [Network](#tag/networks) with a /16 netmask. */
    ip_range: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateNetworkRequestLabelsMap;
    /** Array of subnets to allocate. */
    subnets?: CreateNetworkRequestSubnetsList;
    /** Array of routes set in this [Network](#tag/networks). */
    routes?: CreateNetworkRequestRoutesList;
    /** Toggle to expose routes to the [Networks](#tag/networks) vSwitch. Indicates if the routes from this [Network](#tag/networks) should be exposed to the vSwitch in this [Network](#tag/networks). Only takes effect if a [vSwitch is setup](https://docs.hetzner.com/cloud/networks/connect-dedi-vswitch) in this [Network](#tag/networks). */
    expose_routes_to_vswitch?: boolean;
}
export declare const CreateNetworkRequest: S.Schema<CreateNetworkRequest>;
/** Type of subnet. */
export type CreateNetworkResponseNetworkSubnetsItemType = "cloud" | "server" | "vswitch";
export declare const CreateNetworkResponseNetworkSubnetsItemType: any;
export interface CreateNetworkResponseNetworkSubnetsItem {
    /** Type of subnet. */
    type: CreateNetworkResponseNetworkSubnetsItemType;
    /** IP range of the subnet. Uses CIDR notation. */
    ip_range?: string;
    /** Name of the [Network Zone](#tag/network-zones). The [Location](#tag/locations) contains the `network_zone` property it belongs to. */
    network_zone: string;
    /** Gateway for [Servers](#tag/servers) attached to this subnet. For subnets of type `server` this is always the first IP of the subnets IP range. */
    gateway: string;
    /** ID of the robot vSwitch if the subnet is of type `vswitch`. */
    vswitch_id?: number | null;
}
export declare const CreateNetworkResponseNetworkSubnetsItem: S.Schema<CreateNetworkResponseNetworkSubnetsItem>;
/** List of subnets allocated in this [Network](#tag/networks). */
export type CreateNetworkResponseNetworkSubnetsList = Array<CreateNetworkResponseNetworkSubnetsItem>;
export declare const CreateNetworkResponseNetworkSubnetsList: S.Schema<CreateNetworkResponseNetworkSubnetsList>;
export type CreateNetworkResponseNetworkRoutesItem = CreateNetworkRequestRoutesItem;
export declare const CreateNetworkResponseNetworkRoutesItem: S.Schema<CreateNetworkRequestRoutesItem>;
/** Array of routes set in this [Network](#tag/networks). */
export type CreateNetworkResponseNetworkRoutesList = Array<CreateNetworkRequestRoutesItem>;
export declare const CreateNetworkResponseNetworkRoutesList: S.Schema<CreateNetworkResponseNetworkRoutesList>;
/** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
export type CreateNetworkResponseNetworkServersList = Array<number>;
export declare const CreateNetworkResponseNetworkServersList: S.Schema<CreateNetworkResponseNetworkServersList>;
/** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
export type CreateNetworkResponseNetworkLoadBalancersList = Array<number>;
export declare const CreateNetworkResponseNetworkLoadBalancersList: S.Schema<CreateNetworkResponseNetworkLoadBalancersList>;
/** Protection configuration for the Resource. */
export interface CreateNetworkResponseNetworkProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreateNetworkResponseNetworkProtection: S.Schema<CreateNetworkResponseNetworkProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateNetworkResponseNetworkLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateNetworkResponseNetworkLabelsMap: S.Schema<CreateNetworkResponseNetworkLabelsMap>;
export interface CreateNetworkResponseNetwork {
    /** ID of the [Network](#tag/networks). */
    id: number;
    /** Name of the [Network](#tag/networks). */
    name: string;
    /** IP range of the [Network](#tag/networks). Uses CIDR notation. */
    ip_range: string;
    /** List of subnets allocated in this [Network](#tag/networks). */
    subnets: CreateNetworkResponseNetworkSubnetsList;
    /** Array of routes set in this [Network](#tag/networks). */
    routes: CreateNetworkResponseNetworkRoutesList;
    /** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
    servers: CreateNetworkResponseNetworkServersList;
    /** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
    load_balancers?: CreateNetworkResponseNetworkLoadBalancersList;
    /** Protection configuration for the Resource. */
    protection: CreateNetworkResponseNetworkProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateNetworkResponseNetworkLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Indicates if the routes from this [Network](#tag/networks) should be exposed to the vSwitch connection. */
    expose_routes_to_vswitch: boolean;
}
export declare const CreateNetworkResponseNetwork: S.Schema<CreateNetworkResponseNetwork>;
export interface CreateNetworkResponse {
    network?: CreateNetworkResponseNetwork;
}
export declare const CreateNetworkResponse: S.Schema<CreateNetworkResponse>;
export interface DeleteNetworkRequest {
    /** ID of the Network. */
    id: number;
}
export declare const DeleteNetworkRequest: S.Schema<DeleteNetworkRequest>;
export interface DeleteNetworkResponse {
}
export declare const DeleteNetworkResponse: S.Schema<DeleteNetworkResponse>;
export interface GetNetworkRequest {
    /** ID of the Network. */
    id: number;
}
export declare const GetNetworkRequest: S.Schema<GetNetworkRequest>;
/** Type of subnet. */
export type GetNetworkResponseNetworkSubnetsItemType = "cloud" | "server" | "vswitch";
export declare const GetNetworkResponseNetworkSubnetsItemType: any;
export interface GetNetworkResponseNetworkSubnetsItem {
    /** Type of subnet. */
    type: GetNetworkResponseNetworkSubnetsItemType;
    /** IP range of the subnet. Uses CIDR notation. */
    ip_range?: string;
    /** Name of the [Network Zone](#tag/network-zones). The [Location](#tag/locations) contains the `network_zone` property it belongs to. */
    network_zone: string;
    /** Gateway for [Servers](#tag/servers) attached to this subnet. For subnets of type `server` this is always the first IP of the subnets IP range. */
    gateway: string;
    /** ID of the robot vSwitch if the subnet is of type `vswitch`. */
    vswitch_id?: number | null;
}
export declare const GetNetworkResponseNetworkSubnetsItem: S.Schema<GetNetworkResponseNetworkSubnetsItem>;
/** List of subnets allocated in this [Network](#tag/networks). */
export type GetNetworkResponseNetworkSubnetsList = Array<GetNetworkResponseNetworkSubnetsItem>;
export declare const GetNetworkResponseNetworkSubnetsList: S.Schema<GetNetworkResponseNetworkSubnetsList>;
export type GetNetworkResponseNetworkRoutesItem = CreateNetworkRequestRoutesItem;
export declare const GetNetworkResponseNetworkRoutesItem: S.Schema<CreateNetworkRequestRoutesItem>;
/** Array of routes set in this [Network](#tag/networks). */
export type GetNetworkResponseNetworkRoutesList = Array<CreateNetworkRequestRoutesItem>;
export declare const GetNetworkResponseNetworkRoutesList: S.Schema<GetNetworkResponseNetworkRoutesList>;
/** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
export type GetNetworkResponseNetworkServersList = Array<number>;
export declare const GetNetworkResponseNetworkServersList: S.Schema<GetNetworkResponseNetworkServersList>;
/** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
export type GetNetworkResponseNetworkLoadBalancersList = Array<number>;
export declare const GetNetworkResponseNetworkLoadBalancersList: S.Schema<GetNetworkResponseNetworkLoadBalancersList>;
/** Protection configuration for the Resource. */
export type GetNetworkResponseNetworkProtection = CreateNetworkResponseNetworkProtection;
export declare const GetNetworkResponseNetworkProtection: S.Schema<CreateNetworkResponseNetworkProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetNetworkResponseNetworkLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetNetworkResponseNetworkLabelsMap: S.Schema<GetNetworkResponseNetworkLabelsMap>;
export interface GetNetworkResponseNetwork {
    /** ID of the [Network](#tag/networks). */
    id: number;
    /** Name of the [Network](#tag/networks). */
    name: string;
    /** IP range of the [Network](#tag/networks). Uses CIDR notation. */
    ip_range: string;
    /** List of subnets allocated in this [Network](#tag/networks). */
    subnets: GetNetworkResponseNetworkSubnetsList;
    /** Array of routes set in this [Network](#tag/networks). */
    routes: GetNetworkResponseNetworkRoutesList;
    /** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
    servers: GetNetworkResponseNetworkServersList;
    /** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
    load_balancers?: GetNetworkResponseNetworkLoadBalancersList;
    /** Protection configuration for the Resource. */
    protection: CreateNetworkResponseNetworkProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetNetworkResponseNetworkLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Indicates if the routes from this [Network](#tag/networks) should be exposed to the vSwitch connection. */
    expose_routes_to_vswitch: boolean;
}
export declare const GetNetworkResponseNetwork: S.Schema<GetNetworkResponseNetwork>;
export interface GetNetworkResponse {
    network?: GetNetworkResponseNetwork;
}
export declare const GetNetworkResponse: S.Schema<GetNetworkResponse>;
export type ListNetworksRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListNetworksRequestSortItem: any;
export type ListNetworksRequestSortList = Array<ListNetworksRequestSortItem | (string & {})>;
export declare const ListNetworksRequestSortList: S.Schema<ListNetworksRequestSortList>;
export interface ListNetworksRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListNetworksRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListNetworksRequest: S.Schema<ListNetworksRequest>;
/** Type of subnet. */
export type ListNetworksResponseNetworksItemSubnetsItemType = "cloud" | "server" | "vswitch";
export declare const ListNetworksResponseNetworksItemSubnetsItemType: any;
export interface ListNetworksResponseNetworksItemSubnetsItem {
    /** Type of subnet. */
    type: ListNetworksResponseNetworksItemSubnetsItemType;
    /** IP range of the subnet. Uses CIDR notation. */
    ip_range?: string;
    /** Name of the [Network Zone](#tag/network-zones). The [Location](#tag/locations) contains the `network_zone` property it belongs to. */
    network_zone: string;
    /** Gateway for [Servers](#tag/servers) attached to this subnet. For subnets of type `server` this is always the first IP of the subnets IP range. */
    gateway: string;
    /** ID of the robot vSwitch if the subnet is of type `vswitch`. */
    vswitch_id?: number | null;
}
export declare const ListNetworksResponseNetworksItemSubnetsItem: S.Schema<ListNetworksResponseNetworksItemSubnetsItem>;
/** List of subnets allocated in this [Network](#tag/networks). */
export type ListNetworksResponseNetworksItemSubnetsList = Array<ListNetworksResponseNetworksItemSubnetsItem>;
export declare const ListNetworksResponseNetworksItemSubnetsList: S.Schema<ListNetworksResponseNetworksItemSubnetsList>;
export type ListNetworksResponseNetworksItemRoutesItem = CreateNetworkRequestRoutesItem;
export declare const ListNetworksResponseNetworksItemRoutesItem: S.Schema<CreateNetworkRequestRoutesItem>;
/** Array of routes set in this [Network](#tag/networks). */
export type ListNetworksResponseNetworksItemRoutesList = Array<CreateNetworkRequestRoutesItem>;
export declare const ListNetworksResponseNetworksItemRoutesList: S.Schema<ListNetworksResponseNetworksItemRoutesList>;
/** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
export type ListNetworksResponseNetworksItemServersList = Array<number>;
export declare const ListNetworksResponseNetworksItemServersList: S.Schema<ListNetworksResponseNetworksItemServersList>;
/** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
export type ListNetworksResponseNetworksItemLoadBalancersList = Array<number>;
export declare const ListNetworksResponseNetworksItemLoadBalancersList: S.Schema<ListNetworksResponseNetworksItemLoadBalancersList>;
/** Protection configuration for the Resource. */
export type ListNetworksResponseNetworksItemProtection = CreateNetworkResponseNetworkProtection;
export declare const ListNetworksResponseNetworksItemProtection: S.Schema<CreateNetworkResponseNetworkProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListNetworksResponseNetworksItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListNetworksResponseNetworksItemLabelsMap: S.Schema<ListNetworksResponseNetworksItemLabelsMap>;
export interface ListNetworksResponseNetworksItem {
    /** ID of the [Network](#tag/networks). */
    id: number;
    /** Name of the [Network](#tag/networks). */
    name: string;
    /** IP range of the [Network](#tag/networks). Uses CIDR notation. */
    ip_range: string;
    /** List of subnets allocated in this [Network](#tag/networks). */
    subnets: ListNetworksResponseNetworksItemSubnetsList;
    /** Array of routes set in this [Network](#tag/networks). */
    routes: ListNetworksResponseNetworksItemRoutesList;
    /** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
    servers: ListNetworksResponseNetworksItemServersList;
    /** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
    load_balancers?: ListNetworksResponseNetworksItemLoadBalancersList;
    /** Protection configuration for the Resource. */
    protection: CreateNetworkResponseNetworkProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListNetworksResponseNetworksItemLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Indicates if the routes from this [Network](#tag/networks) should be exposed to the vSwitch connection. */
    expose_routes_to_vswitch: boolean;
}
export declare const ListNetworksResponseNetworksItem: S.Schema<ListNetworksResponseNetworksItem>;
export type ListNetworksResponseNetworksList = Array<ListNetworksResponseNetworksItem>;
export declare const ListNetworksResponseNetworksList: S.Schema<ListNetworksResponseNetworksList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListNetworksResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListNetworksResponseMetaPagination: S.Schema<ListNetworksResponseMetaPagination>;
export interface ListNetworksResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListNetworksResponseMetaPagination;
}
export declare const ListNetworksResponseMeta: S.Schema<ListNetworksResponseMeta>;
export interface ListNetworksResponse {
    networks: ListNetworksResponseNetworksList;
    meta: ListNetworksResponseMeta;
}
export declare const ListNetworksResponse: S.Schema<ListNetworksResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateNetworkRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateNetworkRequestLabelsMap: S.Schema<UpdateNetworkRequestLabelsMap>;
export interface UpdateNetworkRequest {
    /** ID of the Network. */
    id: number;
    /** New [Network](#tag/networks) name. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateNetworkRequestLabelsMap;
    /** Toggle to expose routes to the [Networks](#tag/networks) vSwitch. Indicates if the routes from this [Network](#tag/networks) should be exposed to the vSwitch in this [Network](#tag/networks). Only takes effect if a [vSwitch is setup](https://docs.hetzner.com/cloud/networks/connect-dedi-vswitch) in this [Network](#tag/networks). */
    expose_routes_to_vswitch?: boolean;
}
export declare const UpdateNetworkRequest: S.Schema<UpdateNetworkRequest>;
/** Type of subnet. */
export type UpdateNetworkResponseNetworkSubnetsItemType = "cloud" | "server" | "vswitch";
export declare const UpdateNetworkResponseNetworkSubnetsItemType: any;
export interface UpdateNetworkResponseNetworkSubnetsItem {
    /** Type of subnet. */
    type: UpdateNetworkResponseNetworkSubnetsItemType;
    /** IP range of the subnet. Uses CIDR notation. */
    ip_range?: string;
    /** Name of the [Network Zone](#tag/network-zones). The [Location](#tag/locations) contains the `network_zone` property it belongs to. */
    network_zone: string;
    /** Gateway for [Servers](#tag/servers) attached to this subnet. For subnets of type `server` this is always the first IP of the subnets IP range. */
    gateway: string;
    /** ID of the robot vSwitch if the subnet is of type `vswitch`. */
    vswitch_id?: number | null;
}
export declare const UpdateNetworkResponseNetworkSubnetsItem: S.Schema<UpdateNetworkResponseNetworkSubnetsItem>;
/** List of subnets allocated in this [Network](#tag/networks). */
export type UpdateNetworkResponseNetworkSubnetsList = Array<UpdateNetworkResponseNetworkSubnetsItem>;
export declare const UpdateNetworkResponseNetworkSubnetsList: S.Schema<UpdateNetworkResponseNetworkSubnetsList>;
export type UpdateNetworkResponseNetworkRoutesItem = CreateNetworkRequestRoutesItem;
export declare const UpdateNetworkResponseNetworkRoutesItem: S.Schema<CreateNetworkRequestRoutesItem>;
/** Array of routes set in this [Network](#tag/networks). */
export type UpdateNetworkResponseNetworkRoutesList = Array<CreateNetworkRequestRoutesItem>;
export declare const UpdateNetworkResponseNetworkRoutesList: S.Schema<UpdateNetworkResponseNetworkRoutesList>;
/** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
export type UpdateNetworkResponseNetworkServersList = Array<number>;
export declare const UpdateNetworkResponseNetworkServersList: S.Schema<UpdateNetworkResponseNetworkServersList>;
/** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
export type UpdateNetworkResponseNetworkLoadBalancersList = Array<number>;
export declare const UpdateNetworkResponseNetworkLoadBalancersList: S.Schema<UpdateNetworkResponseNetworkLoadBalancersList>;
/** Protection configuration for the Resource. */
export type UpdateNetworkResponseNetworkProtection = CreateNetworkResponseNetworkProtection;
export declare const UpdateNetworkResponseNetworkProtection: S.Schema<CreateNetworkResponseNetworkProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateNetworkResponseNetworkLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateNetworkResponseNetworkLabelsMap: S.Schema<UpdateNetworkResponseNetworkLabelsMap>;
export interface UpdateNetworkResponseNetwork {
    /** ID of the [Network](#tag/networks). */
    id: number;
    /** Name of the [Network](#tag/networks). */
    name: string;
    /** IP range of the [Network](#tag/networks). Uses CIDR notation. */
    ip_range: string;
    /** List of subnets allocated in this [Network](#tag/networks). */
    subnets: UpdateNetworkResponseNetworkSubnetsList;
    /** Array of routes set in this [Network](#tag/networks). */
    routes: UpdateNetworkResponseNetworkRoutesList;
    /** Array of IDs of [Servers](#tag/servers) attached to this [Network](#tag/networks). */
    servers: UpdateNetworkResponseNetworkServersList;
    /** Array of IDs of [Load Balancers](#tag/load-balancers) attached to this [Network](#tag/networks). */
    load_balancers?: UpdateNetworkResponseNetworkLoadBalancersList;
    /** Protection configuration for the Resource. */
    protection: CreateNetworkResponseNetworkProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateNetworkResponseNetworkLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Indicates if the routes from this [Network](#tag/networks) should be exposed to the vSwitch connection. */
    expose_routes_to_vswitch: boolean;
}
export declare const UpdateNetworkResponseNetwork: S.Schema<UpdateNetworkResponseNetwork>;
export interface UpdateNetworkResponse {
    network?: UpdateNetworkResponseNetwork;
}
export declare const UpdateNetworkResponse: S.Schema<UpdateNetworkResponse>;
export type CreateNetworkError = HetznerOpError;
/** Create a Network Creates a [Network](#tag/networks). The provided `ip_range` can only be extended later on, but not reduced. Subnets can be added now or later on using the [add subnet action](#tag/network-actions/add_network_subnet). If you do not specify an `ip_range` for the subnet the first available /24 range will be used. Routes can be added now or later by using the [add route action](#tag/network-actions/add_network_route). */
export declare const createNetwork: API.OperationMethod<CreateNetworkRequest, CreateNetworkResponse, CreateNetworkError, HetznerOpContext>;
export type DeleteNetworkError = HetznerOpError;
/** Delete a Network Deletes a [Network](#tag/networks). Attached resources will be detached automatically. */
export declare const deleteNetwork: API.OperationMethod<DeleteNetworkRequest, DeleteNetworkResponse, DeleteNetworkError, HetznerOpContext>;
export type GetNetworkError = HetznerOpError;
/** Get a Network Get a specific [Network](#tag/networks). */
export declare const getNetwork: API.OperationMethod<GetNetworkRequest, GetNetworkResponse, GetNetworkError, HetznerOpContext>;
export type ListNetworksError = HetznerOpError;
/** List Networks List multiple [Networks](#tag/networks). Use the provided URI parameters to modify the result. */
export declare const listNetworks: API.PaginatedOperationMethod<ListNetworksRequest, ListNetworksResponse, ListNetworksError, HetznerOpContext, ListNetworksResponseNetworksItem>;
export type UpdateNetworkError = HetznerOpError;
/** Update a Network Update a [Network](#tag/networks). If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const updateNetwork: API.OperationMethod<UpdateNetworkRequest, UpdateNetworkResponse, UpdateNetworkError, HetznerOpContext>;
//# sourceMappingURL=networks.d.ts.map