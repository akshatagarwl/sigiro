import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateSshKeyRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateSshKeyRequestLabelsMap: S.Schema<CreateSshKeyRequestLabelsMap>;
export interface CreateSshKeyRequest {
    /** Name of the SSH key. */
    name: string;
    /** Public key. */
    public_key: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateSshKeyRequestLabelsMap;
}
export declare const CreateSshKeyRequest: S.Schema<CreateSshKeyRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateSshKeyResponseSshKeyLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateSshKeyResponseSshKeyLabelsMap: S.Schema<CreateSshKeyResponseSshKeyLabelsMap>;
export interface CreateSshKeyResponseSshKey {
    /** ID of the [SSH Key](#tag/ssh-keys). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** MD5 fingerprint of the SSH public key. */
    fingerprint: string;
    /** Public key. */
    public_key: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateSshKeyResponseSshKeyLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const CreateSshKeyResponseSshKey: S.Schema<CreateSshKeyResponseSshKey>;
export interface CreateSshKeyResponse {
    ssh_key: CreateSshKeyResponseSshKey;
}
export declare const CreateSshKeyResponse: S.Schema<CreateSshKeyResponse>;
export interface DeleteSshKeyRequest {
    /** ID of the SSH Key. */
    id: number;
}
export declare const DeleteSshKeyRequest: S.Schema<DeleteSshKeyRequest>;
export interface DeleteSshKeyResponse {
}
export declare const DeleteSshKeyResponse: S.Schema<DeleteSshKeyResponse>;
export interface GetSshKeyRequest {
    /** ID of the SSH Key. */
    id: number;
}
export declare const GetSshKeyRequest: S.Schema<GetSshKeyRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetSshKeyResponseSshKeyLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetSshKeyResponseSshKeyLabelsMap: S.Schema<GetSshKeyResponseSshKeyLabelsMap>;
export interface GetSshKeyResponseSshKey {
    /** ID of the [SSH Key](#tag/ssh-keys). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** MD5 fingerprint of the SSH public key. */
    fingerprint: string;
    /** Public key. */
    public_key: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetSshKeyResponseSshKeyLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const GetSshKeyResponseSshKey: S.Schema<GetSshKeyResponseSshKey>;
export interface GetSshKeyResponse {
    ssh_key: GetSshKeyResponseSshKey;
}
export declare const GetSshKeyResponse: S.Schema<GetSshKeyResponse>;
export type ListSshKeysRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc";
export declare const ListSshKeysRequestSortItem: any;
export type ListSshKeysRequestSortList = Array<ListSshKeysRequestSortItem | (string & {})>;
export declare const ListSshKeysRequestSortList: S.Schema<ListSshKeysRequestSortList>;
export interface ListSshKeysRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListSshKeysRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** May be used to filter SSH keys by their fingerprint. The response will only contain the SSH key matching the specified fingerprint. */
    fingerprint?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListSshKeysRequest: S.Schema<ListSshKeysRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListSshKeysResponseSshKeysItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListSshKeysResponseSshKeysItemLabelsMap: S.Schema<ListSshKeysResponseSshKeysItemLabelsMap>;
export interface ListSshKeysResponseSshKeysItem {
    /** ID of the [SSH Key](#tag/ssh-keys). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** MD5 fingerprint of the SSH public key. */
    fingerprint: string;
    /** Public key. */
    public_key: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListSshKeysResponseSshKeysItemLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const ListSshKeysResponseSshKeysItem: S.Schema<ListSshKeysResponseSshKeysItem>;
export type ListSshKeysResponseSshKeysList = Array<ListSshKeysResponseSshKeysItem>;
export declare const ListSshKeysResponseSshKeysList: S.Schema<ListSshKeysResponseSshKeysList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListSshKeysResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListSshKeysResponseMetaPagination: S.Schema<ListSshKeysResponseMetaPagination>;
export interface ListSshKeysResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListSshKeysResponseMetaPagination;
}
export declare const ListSshKeysResponseMeta: S.Schema<ListSshKeysResponseMeta>;
export interface ListSshKeysResponse {
    ssh_keys: ListSshKeysResponseSshKeysList;
    meta: ListSshKeysResponseMeta;
}
export declare const ListSshKeysResponse: S.Schema<ListSshKeysResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateSshKeyRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateSshKeyRequestLabelsMap: S.Schema<UpdateSshKeyRequestLabelsMap>;
export interface UpdateSshKeyRequest {
    /** ID of the SSH Key. */
    id: number;
    /** New name Name to set. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateSshKeyRequestLabelsMap;
}
export declare const UpdateSshKeyRequest: S.Schema<UpdateSshKeyRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateSshKeyResponseSshKeyLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateSshKeyResponseSshKeyLabelsMap: S.Schema<UpdateSshKeyResponseSshKeyLabelsMap>;
export interface UpdateSshKeyResponseSshKey {
    /** ID of the [SSH Key](#tag/ssh-keys). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** MD5 fingerprint of the SSH public key. */
    fingerprint: string;
    /** Public key. */
    public_key: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateSshKeyResponseSshKeyLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const UpdateSshKeyResponseSshKey: S.Schema<UpdateSshKeyResponseSshKey>;
export interface UpdateSshKeyResponse {
    ssh_key: UpdateSshKeyResponseSshKey;
}
export declare const UpdateSshKeyResponse: S.Schema<UpdateSshKeyResponse>;
export type CreateSshKeyError = HetznerOpError;
/** Create an SSH key Creates a new SSH key with the given `name` and `public_key`. Once an SSH key is created, it can be used in other calls such as creating Servers. */
export declare const createSshKey: API.OperationMethod<CreateSshKeyRequest, CreateSshKeyResponse, CreateSshKeyError, HetznerOpContext>;
export type DeleteSshKeyError = HetznerOpError;
/** Delete an SSH key Deletes an SSH key. It cannot be used anymore. */
export declare const deleteSshKey: API.OperationMethod<DeleteSshKeyRequest, DeleteSshKeyResponse, DeleteSshKeyError, HetznerOpContext>;
export type GetSshKeyError = HetznerOpError;
/** Get a SSH key Returns a specific SSH key object. */
export declare const getSshKey: API.OperationMethod<GetSshKeyRequest, GetSshKeyResponse, GetSshKeyError, HetznerOpContext>;
export type ListSshKeysError = HetznerOpError;
/** List SSH keys Returns all SSH key objects. */
export declare const listSshKeys: API.PaginatedOperationMethod<ListSshKeysRequest, ListSshKeysResponse, ListSshKeysError, HetznerOpContext, ListSshKeysResponseSshKeysItem>;
export type UpdateSshKeyError = HetznerOpError;
/** Update an SSH key Updates an SSH key. You can update an SSH key name and an SSH key labels. */
export declare const updateSshKey: API.OperationMethod<UpdateSshKeyRequest, UpdateSshKeyResponse, UpdateSshKeyError, HetznerOpContext>;
//# sourceMappingURL=ssh_keys.d.ts.map