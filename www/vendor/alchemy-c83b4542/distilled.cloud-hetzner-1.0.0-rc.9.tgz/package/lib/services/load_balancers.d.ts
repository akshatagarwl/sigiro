import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Type of the algorithm. */
export type CreateLoadBalancerRequestAlgorithmType = "round_robin" | "least_connections";
export declare const CreateLoadBalancerRequestAlgorithmType: any;
/** Algorithm of the Load Balancer. */
export interface CreateLoadBalancerRequestAlgorithm {
    /** Type of the algorithm. */
    type: CreateLoadBalancerRequestAlgorithmType | (string & {});
}
export declare const CreateLoadBalancerRequestAlgorithm: S.Schema<CreateLoadBalancerRequestAlgorithm>;
/** Protocol of the Load Balancer. */
export type ServiceTCPProtocol = "tcp" | "http" | "https";
export declare const ServiceTCPProtocol: any;
/** Type of the health check. */
export type ServiceTCPHealthCheckProtocol = "tcp" | "http";
export declare const ServiceTCPHealthCheckProtocol: any;
/** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
export type ServiceTCPHealthCheckHttpStatusCodesList = Array<string>;
export declare const ServiceTCPHealthCheckHttpStatusCodesList: S.Schema<ServiceTCPHealthCheckHttpStatusCodesList>;
/** Additional configuration for protocol http. */
export interface ServiceTCPHealthCheckHttp {
    /** Host header to send in the HTTP request. May not contain spaces, percent or backslash symbols. Can be null, in that case no host header is sent. */
    domain: string | null;
    /** HTTP path to use for health checks. May not contain literal spaces, use percent-encoding instead. */
    path: string;
    /** String that must be contained in HTTP response in order to pass the health check. */
    response?: string;
    /** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
    status_codes?: ServiceTCPHealthCheckHttpStatusCodesList;
    /** Use HTTPS for health check. */
    tls?: boolean;
}
export declare const ServiceTCPHealthCheckHttp: S.Schema<ServiceTCPHealthCheckHttp>;
/** Service health check. */
export interface ServiceTCPHealthCheck {
    /** Type of the health check. */
    protocol: ServiceTCPHealthCheckProtocol | (string & {});
    /** Port the health check will be performed on. */
    port: number;
    /** Time interval in seconds health checks are performed. */
    interval: number;
    /** Time in seconds after an attempt is considered a timeout. */
    timeout: number;
    /** Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again. */
    retries: number;
    /** Additional configuration for protocol http. */
    http?: ServiceTCPHealthCheckHttp;
}
export declare const ServiceTCPHealthCheck: S.Schema<ServiceTCPHealthCheck>;
export interface ServiceTCP {
    /** Protocol of the Load Balancer. */
    protocol: ServiceTCPProtocol | (string & {});
    /** Port the Load Balancer listens on. */
    listen_port: number;
    /** Port the Load Balancer will balance to. */
    destination_port: number;
    /** Is Proxyprotocol enabled or not. */
    proxyprotocol: boolean;
    /** Service health check. */
    health_check: ServiceTCPHealthCheck;
}
export declare const ServiceTCP: S.Schema<ServiceTCP>;
/** Protocol of the Load Balancer. */
export type ServiceHTTPProtocolProtocol = "tcp" | "http" | "https";
export declare const ServiceHTTPProtocolProtocol: any;
/** Type of the health check. */
export type ServiceHTTPProtocolHealthCheckProtocol = "tcp" | "http";
export declare const ServiceHTTPProtocolHealthCheckProtocol: any;
/** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
export type ServiceHTTPProtocolHealthCheckHttpStatusCodesList = Array<string>;
export declare const ServiceHTTPProtocolHealthCheckHttpStatusCodesList: S.Schema<ServiceHTTPProtocolHealthCheckHttpStatusCodesList>;
/** Additional configuration for protocol http. */
export interface ServiceHTTPProtocolHealthCheckHttp {
    /** Host header to send in the HTTP request. May not contain spaces, percent or backslash symbols. Can be null, in that case no host header is sent. */
    domain: string | null;
    /** HTTP path to use for health checks. May not contain literal spaces, use percent-encoding instead. */
    path: string;
    /** String that must be contained in HTTP response in order to pass the health check. */
    response?: string;
    /** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
    status_codes?: ServiceHTTPProtocolHealthCheckHttpStatusCodesList;
    /** Use HTTPS for health check. */
    tls?: boolean;
}
export declare const ServiceHTTPProtocolHealthCheckHttp: S.Schema<ServiceHTTPProtocolHealthCheckHttp>;
/** Service health check. */
export interface ServiceHTTPProtocolHealthCheck {
    /** Type of the health check. */
    protocol: ServiceHTTPProtocolHealthCheckProtocol | (string & {});
    /** Port the health check will be performed on. */
    port: number;
    /** Time interval in seconds health checks are performed. */
    interval: number;
    /** Time in seconds after an attempt is considered a timeout. */
    timeout: number;
    /** Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again. */
    retries: number;
    /** Additional configuration for protocol http. */
    http?: ServiceHTTPProtocolHealthCheckHttp;
}
export declare const ServiceHTTPProtocolHealthCheck: S.Schema<ServiceHTTPProtocolHealthCheck>;
/** Configuration option for protocol http. */
export interface ServiceHTTPProtocolHttp {
    /** Name of the cookie used for sticky sessions. */
    cookie_name: string;
    /** Lifetime of the cookie used for sticky sessions (in seconds). */
    cookie_lifetime: number;
    /** Idle timeout in seconds for the client and server side. */
    timeout_idle: number;
    /** Use sticky sessions. */
    sticky_sessions: boolean;
}
export declare const ServiceHTTPProtocolHttp: S.Schema<ServiceHTTPProtocolHttp>;
export interface ServiceHTTPProtocol {
    /** Protocol of the Load Balancer. */
    protocol: ServiceHTTPProtocolProtocol | (string & {});
    /** Port the Load Balancer listens on. */
    listen_port: number;
    /** Port the Load Balancer will balance to. */
    destination_port: number;
    /** Is Proxyprotocol enabled or not. */
    proxyprotocol: boolean;
    /** Service health check. */
    health_check: ServiceHTTPProtocolHealthCheck;
    /** Configuration option for protocol http. */
    http: ServiceHTTPProtocolHttp;
}
export declare const ServiceHTTPProtocol: S.Schema<ServiceHTTPProtocol>;
/** Protocol of the Load Balancer. */
export type ServiceHTTPSProtocolProtocol = "tcp" | "http" | "https";
export declare const ServiceHTTPSProtocolProtocol: any;
/** Type of the health check. */
export type ServiceHTTPSProtocolHealthCheckProtocol = "tcp" | "http";
export declare const ServiceHTTPSProtocolHealthCheckProtocol: any;
/** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
export type ServiceHTTPSProtocolHealthCheckHttpStatusCodesList = Array<string>;
export declare const ServiceHTTPSProtocolHealthCheckHttpStatusCodesList: S.Schema<ServiceHTTPSProtocolHealthCheckHttpStatusCodesList>;
/** Additional configuration for protocol http. */
export interface ServiceHTTPSProtocolHealthCheckHttp {
    /** Host header to send in the HTTP request. May not contain spaces, percent or backslash symbols. Can be null, in that case no host header is sent. */
    domain: string | null;
    /** HTTP path to use for health checks. May not contain literal spaces, use percent-encoding instead. */
    path: string;
    /** String that must be contained in HTTP response in order to pass the health check. */
    response?: string;
    /** List of returned HTTP status codes in order to pass the health check. Supports the wildcards `?` for exactly one character and `*` for multiple ones. */
    status_codes?: ServiceHTTPSProtocolHealthCheckHttpStatusCodesList;
    /** Use HTTPS for health check. */
    tls?: boolean;
}
export declare const ServiceHTTPSProtocolHealthCheckHttp: S.Schema<ServiceHTTPSProtocolHealthCheckHttp>;
/** Service health check. */
export interface ServiceHTTPSProtocolHealthCheck {
    /** Type of the health check. */
    protocol: ServiceHTTPSProtocolHealthCheckProtocol | (string & {});
    /** Port the health check will be performed on. */
    port: number;
    /** Time interval in seconds health checks are performed. */
    interval: number;
    /** Time in seconds after an attempt is considered a timeout. */
    timeout: number;
    /** Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again. */
    retries: number;
    /** Additional configuration for protocol http. */
    http?: ServiceHTTPSProtocolHealthCheckHttp;
}
export declare const ServiceHTTPSProtocolHealthCheck: S.Schema<ServiceHTTPSProtocolHealthCheck>;
/** IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough. */
export type ServiceHTTPSProtocolHttpCertificatesList = Array<number>;
export declare const ServiceHTTPSProtocolHttpCertificatesList: S.Schema<ServiceHTTPSProtocolHttpCertificatesList>;
/** Configuration option for protocol https. */
export interface ServiceHTTPSProtocolHttp {
    /** Name of the cookie used for sticky sessions. */
    cookie_name: string;
    /** Lifetime of the cookie used for sticky sessions (in seconds). */
    cookie_lifetime: number;
    /** Idle timeout in seconds for the client and server side. */
    timeout_idle: number;
    /** IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough. */
    certificates: ServiceHTTPSProtocolHttpCertificatesList;
    /** Redirect HTTP requests to HTTPS. */
    redirect_http: boolean;
    /** Use sticky sessions. */
    sticky_sessions: boolean;
}
export declare const ServiceHTTPSProtocolHttp: S.Schema<ServiceHTTPSProtocolHttp>;
export interface ServiceHTTPSProtocol {
    /** Protocol of the Load Balancer. */
    protocol: ServiceHTTPSProtocolProtocol | (string & {});
    /** Port the Load Balancer listens on. */
    listen_port: number;
    /** Port the Load Balancer will balance to. */
    destination_port: number;
    /** Is Proxyprotocol enabled or not. */
    proxyprotocol: boolean;
    /** Service health check. */
    health_check: ServiceHTTPSProtocolHealthCheck;
    /** Configuration option for protocol https. */
    http: ServiceHTTPSProtocolHttp;
}
export declare const ServiceHTTPSProtocol: S.Schema<ServiceHTTPSProtocol>;
export type CreateLoadBalancerRequestServicesItem = ServiceTCP | ServiceHTTPProtocol | ServiceHTTPSProtocol;
export declare const CreateLoadBalancerRequestServicesItem: S.Schema<CreateLoadBalancerRequestServicesItem>;
/** Array of services. */
export type CreateLoadBalancerRequestServicesList = Array<CreateLoadBalancerRequestServicesItem>;
export declare const CreateLoadBalancerRequestServicesList: S.Schema<CreateLoadBalancerRequestServicesList>;
/** Type of the resource. */
export type CreateLoadBalancerRequestTargetsItemType = "server" | "label_selector" | "ip";
export declare const CreateLoadBalancerRequestTargetsItemType: any;
/** Configuration for type Server, only valid and required if type is `server`. */
export interface CreateLoadBalancerRequestTargetsItemServer {
    /** ID of the Server. */
    id: number;
    /** Optional public IP of the Server to use as target. Must be the Primary IPv4 of the Server, or an IPv6 host address within IPv6 /64 subnet of the Server. If omitted, the Primary IPv4 of the Server is used. Must not be a private IP and is only valid for public targets. */
    ip?: string;
}
export declare const CreateLoadBalancerRequestTargetsItemServer: S.Schema<CreateLoadBalancerRequestTargetsItemServer>;
/** Configuration for label selector targets, only valid and required if type is `label_selector`. */
export interface CreateLoadBalancerRequestTargetsItemLabelSelector {
    /** Label selector. */
    selector: string;
}
export declare const CreateLoadBalancerRequestTargetsItemLabelSelector: S.Schema<CreateLoadBalancerRequestTargetsItemLabelSelector>;
/** Configuration for an IP target. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only valid and required if type is `ip`. */
export interface CreateLoadBalancerRequestTargetsItemIp {
    /** IP of a server that belongs to the same customer (public IPv4/IPv6) or private IP in a subnet type vswitch. */
    ip: string;
}
export declare const CreateLoadBalancerRequestTargetsItemIp: S.Schema<CreateLoadBalancerRequestTargetsItemIp>;
export interface CreateLoadBalancerRequestTargetsItem {
    /** Type of the resource. */
    type: CreateLoadBalancerRequestTargetsItemType | (string & {});
    /** Configuration for type Server, only valid and required if type is `server`. */
    server?: CreateLoadBalancerRequestTargetsItemServer;
    /** Configuration for label selector targets, only valid and required if type is `label_selector`. */
    label_selector?: CreateLoadBalancerRequestTargetsItemLabelSelector;
    /** Configuration for an IP target. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only valid and required if type is `ip`. */
    ip?: CreateLoadBalancerRequestTargetsItemIp;
    /** Use the private network IP instead of the public IP of the Server, requires the Server and Load Balancer to be in the same network. Only valid for target types `server` and `label_selector`. */
    use_private_ip?: boolean;
}
export declare const CreateLoadBalancerRequestTargetsItem: S.Schema<CreateLoadBalancerRequestTargetsItem>;
/** Array of targets. */
export type CreateLoadBalancerRequestTargetsList = Array<CreateLoadBalancerRequestTargetsItem>;
export declare const CreateLoadBalancerRequestTargetsList: S.Schema<CreateLoadBalancerRequestTargetsList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateLoadBalancerRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateLoadBalancerRequestLabelsMap: S.Schema<CreateLoadBalancerRequestLabelsMap>;
export interface CreateLoadBalancerRequest {
    /** Name of the Load Balancer. */
    name: string;
    /** ID or name of the Load Balancer type this Load Balancer should be created with. */
    load_balancer_type: string;
    /** Algorithm of the Load Balancer. */
    algorithm?: CreateLoadBalancerRequestAlgorithm;
    /** Array of services. */
    services?: CreateLoadBalancerRequestServicesList;
    /** Array of targets. */
    targets?: CreateLoadBalancerRequestTargetsList;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateLoadBalancerRequestLabelsMap;
    /** Enable or disable the public interface of the Load Balancer. */
    public_interface?: boolean;
    /** ID of the network the Load Balancer should be attached to on creation. */
    network?: number;
    /** Name of network zone. */
    network_zone?: string;
    /** ID or name of Location to create Load Balancer in. */
    location?: string;
}
export declare const CreateLoadBalancerRequest: S.Schema<CreateLoadBalancerRequest>;
/** IP address (v4). */
export interface CreateLoadBalancerResponseLoadBalancerPublicNetIpv4 {
    /** IP address (v4) of this Load Balancer. */
    ip: string | null;
    /** Reverse DNS PTR entry for the IPv4 address of this Load Balancer. */
    dns_ptr: string | null;
}
export declare const CreateLoadBalancerResponseLoadBalancerPublicNetIpv4: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv4>;
/** IP address (v6). */
export interface CreateLoadBalancerResponseLoadBalancerPublicNetIpv6 {
    /** IP address (v6) of this Load Balancer. */
    ip: string | null;
    /** Reverse DNS PTR entry for the IPv6 address of this Load Balancer. */
    dns_ptr: string | null;
}
export declare const CreateLoadBalancerResponseLoadBalancerPublicNetIpv6: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv6>;
/** Public network information. */
export interface CreateLoadBalancerResponseLoadBalancerPublicNet {
    /** Public Interface enabled or not. */
    enabled: boolean;
    /** IP address (v4). */
    ipv4: CreateLoadBalancerResponseLoadBalancerPublicNetIpv4;
    /** IP address (v6). */
    ipv6: CreateLoadBalancerResponseLoadBalancerPublicNetIpv6;
}
export declare const CreateLoadBalancerResponseLoadBalancerPublicNet: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNet>;
export interface CreateLoadBalancerResponseLoadBalancerPrivateNetItem {
    /** ID of the Network. */
    network: number;
    /** IP address (v4) of this Load Balancer in this Network. */
    ip: string;
}
export declare const CreateLoadBalancerResponseLoadBalancerPrivateNetItem: S.Schema<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
/** Private networks information. */
export type CreateLoadBalancerResponseLoadBalancerPrivateNetList = Array<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
export declare const CreateLoadBalancerResponseLoadBalancerPrivateNetList: S.Schema<CreateLoadBalancerResponseLoadBalancerPrivateNetList>;
export interface CreateLoadBalancerResponseLoadBalancerLocation {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Unique identifier of the [Location](#tag/locations). */
    name: string;
    /** Human readable description of the [Location](#tag/locations). */
    description: string;
    /** Country the [Location](#tag/locations) resides in. ISO 3166-1 alpha-2 code of the country. */
    country: string;
    /** Name of the closest city to the [Location](#tag/locations). City name or city name and state in short form. E.g. `Falkenstein` or `Ashburn, VA`. */
    city: string;
    /** Latitude of the city closest to the [Location](#tag/locations). */
    latitude: number;
    /** Longitude of the city closest to the [Location](#tag/locations). */
    longitude: number;
    /** Name of the Network Zone this [Location](#tag/locations) resides in. */
    network_zone: string;
}
export declare const CreateLoadBalancerResponseLoadBalancerLocation: S.Schema<CreateLoadBalancerResponseLoadBalancerLocation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export interface CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation {
    /** Date of the deprecated resource removal. Once this date is reached, the resource will not be returned by resource type "list" endpoint, and the resource can not be used to create new resources. For example, if this is an image, you can not create new servers with this image after the mentioned date. */
    unavailable_after: string;
    /** Date of the deprecation announcement. */
    announced: string;
}
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation>;
/** Hourly price in this [Location](#tag/locations). */
export interface CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly {
    /** Price without VAT. */
    net: string;
    /** Price with VAT added. */
    gross: string;
}
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceMonthly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceMonthly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPricePerTbTraffic = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPricePerTbTraffic: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
export interface CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Hourly price in this [Location](#tag/locations). */
    price_hourly: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
    /** Free traffic per month in bytes in this [Location](#tag/locations). */
    included_traffic: number;
    /** Additional traffic price per TB in this [Location](#tag/locations). */
    price_per_tb_traffic: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
}
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList = Array<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList>;
export interface CreateLoadBalancerResponseLoadBalancerLoadBalancerType {
    /** ID of the Load Balancer type. */
    id: number;
    /** Unique identifier of the Load Balancer type. */
    name: string;
    /** Description of the Load Balancer type. */
    description: string;
    /** Number of maximum simultaneous open connections. */
    max_connections: number;
    /** Number of services a Load Balancer of this type can have. */
    max_services: number;
    /** Number of targets a single Load Balancer can have. */
    max_targets: number;
    /** Number of SSL Certificates that can be assigned to a single Load Balancer. */
    max_assigned_certificates: number;
    /** **Deprecated:** This field is deprecated. Use the `deprecation` object instead. Point in time when the Load Balancer type is deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation | null;
    /** Price per [Location](#tag/locations). */
    prices: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList;
}
export declare const CreateLoadBalancerResponseLoadBalancerLoadBalancerType: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerType>;
/** Protection configuration for the Resource. */
export interface CreateLoadBalancerResponseLoadBalancerProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreateLoadBalancerResponseLoadBalancerProtection: S.Schema<CreateLoadBalancerResponseLoadBalancerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateLoadBalancerResponseLoadBalancerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateLoadBalancerResponseLoadBalancerLabelsMap: S.Schema<CreateLoadBalancerResponseLoadBalancerLabelsMap>;
export type CreateLoadBalancerResponseLoadBalancerServicesItem = ServiceTCP | ServiceHTTPProtocol | ServiceHTTPSProtocol;
export declare const CreateLoadBalancerResponseLoadBalancerServicesItem: S.Schema<CreateLoadBalancerResponseLoadBalancerServicesItem>;
/** List of services that belong to this Load Balancer. */
export type CreateLoadBalancerResponseLoadBalancerServicesList = Array<CreateLoadBalancerResponseLoadBalancerServicesItem>;
export declare const CreateLoadBalancerResponseLoadBalancerServicesList: S.Schema<CreateLoadBalancerResponseLoadBalancerServicesList>;
/** Type of the resource. */
export type TargetTypeServerType = "server" | "label_selector" | "ip";
export declare const TargetTypeServerType: any;
/** Server where the traffic should be routed to. Only present for target type "server". */
export interface TargetTypeServerServer {
    /** ID of the Server. */
    id: number;
    /** IP of the Server that the traffic is routed to. Either the Server's primary IPv4 or, if an IPv6 was specified when adding the target, an IPv6 within the Server's /64 subnet. */
    ip: string;
}
export declare const TargetTypeServerServer: S.Schema<TargetTypeServerServer>;
export type TargetTypeServerHealthStatusItemStatus = "healthy" | "unhealthy" | "unknown";
export declare const TargetTypeServerHealthStatusItemStatus: any;
export interface TargetTypeServerHealthStatusItem {
    listen_port: number;
    status: TargetTypeServerHealthStatusItemStatus;
}
export declare const TargetTypeServerHealthStatusItem: S.Schema<TargetTypeServerHealthStatusItem>;
/** List of health statuses of the services on this target. Only present for target types "server" and "ip". */
export type TargetTypeServerHealthStatusList = Array<TargetTypeServerHealthStatusItem>;
export declare const TargetTypeServerHealthStatusList: S.Schema<TargetTypeServerHealthStatusList>;
export interface TargetTypeServer {
    /** Type of the resource. */
    type: TargetTypeServerType;
    /** Server where the traffic should be routed to. Only present for target type "server". */
    server: TargetTypeServerServer;
    /** List of health statuses of the services on this target. Only present for target types "server" and "ip". */
    health_status: TargetTypeServerHealthStatusList;
    /** Use the private network IP instead of the public IP. Only present for target types "server" and "label_selector". */
    use_private_ip: boolean;
}
export declare const TargetTypeServer: S.Schema<TargetTypeServer>;
/** Type of the resource. */
export type TargetTypeLabelSelectorType = "server" | "label_selector" | "ip";
export declare const TargetTypeLabelSelectorType: any;
/** Label selector used to determine targets. Only present for target type "label_selector". */
export type TargetTypeLabelSelectorLabelSelector = CreateLoadBalancerRequestTargetsItemLabelSelector;
export declare const TargetTypeLabelSelectorLabelSelector: S.Schema<CreateLoadBalancerRequestTargetsItemLabelSelector>;
/** Server where the traffic should be routed to. Only present for target type "server". */
export type TargetTypeLabelSelectorTargetsItemServer = TargetTypeServerServer;
export declare const TargetTypeLabelSelectorTargetsItemServer: S.Schema<TargetTypeServerServer>;
export type TargetTypeLabelSelectorTargetsItemHealthStatusItemStatus = "healthy" | "unhealthy" | "unknown";
export declare const TargetTypeLabelSelectorTargetsItemHealthStatusItemStatus: any;
export interface TargetTypeLabelSelectorTargetsItemHealthStatusItem {
    listen_port: number;
    status: TargetTypeLabelSelectorTargetsItemHealthStatusItemStatus;
}
export declare const TargetTypeLabelSelectorTargetsItemHealthStatusItem: S.Schema<TargetTypeLabelSelectorTargetsItemHealthStatusItem>;
/** List of health statuses of the services on this target. Only present for target types "server" and "ip". */
export type TargetTypeLabelSelectorTargetsItemHealthStatusList = Array<TargetTypeLabelSelectorTargetsItemHealthStatusItem>;
export declare const TargetTypeLabelSelectorTargetsItemHealthStatusList: S.Schema<TargetTypeLabelSelectorTargetsItemHealthStatusList>;
export interface TargetTypeLabelSelectorTargetsItem {
    /** Type of the resource. Here always "server". */
    type: string;
    /** Server where the traffic should be routed to. Only present for target type "server". */
    server: TargetTypeServerServer;
    /** List of health statuses of the services on this target. Only present for target types "server" and "ip". */
    health_status: TargetTypeLabelSelectorTargetsItemHealthStatusList;
    /** Use the private network IP instead of the public IP. Only present for target types "server" and "label_selector". */
    use_private_ip: boolean;
}
export declare const TargetTypeLabelSelectorTargetsItem: S.Schema<TargetTypeLabelSelectorTargetsItem>;
/** List of resolved label selector target Servers. */
export type TargetTypeLabelSelectorTargetsList = Array<TargetTypeLabelSelectorTargetsItem>;
export declare const TargetTypeLabelSelectorTargetsList: S.Schema<TargetTypeLabelSelectorTargetsList>;
export interface TargetTypeLabelSelector {
    /** Type of the resource. */
    type: TargetTypeLabelSelectorType;
    /** Label selector used to determine targets. Only present for target type "label_selector". */
    label_selector: CreateLoadBalancerRequestTargetsItemLabelSelector;
    /** List of resolved label selector target Servers. */
    targets: TargetTypeLabelSelectorTargetsList;
    /** Use the private network IP instead of the public IP. Only present for target types "server" and "label_selector". */
    use_private_ip: boolean;
}
export declare const TargetTypeLabelSelector: S.Schema<TargetTypeLabelSelector>;
/** Type of the resource. */
export type TargetTypeIPType = "server" | "label_selector" | "ip";
export declare const TargetTypeIPType: any;
/** IP target where the traffic should be routed to. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only present for target type `ip`. */
export type TargetTypeIPIp = CreateLoadBalancerRequestTargetsItemIp;
export declare const TargetTypeIPIp: S.Schema<CreateLoadBalancerRequestTargetsItemIp>;
export type TargetTypeIPHealthStatusItemStatus = "healthy" | "unhealthy" | "unknown";
export declare const TargetTypeIPHealthStatusItemStatus: any;
export interface TargetTypeIPHealthStatusItem {
    listen_port: number;
    status: TargetTypeIPHealthStatusItemStatus;
}
export declare const TargetTypeIPHealthStatusItem: S.Schema<TargetTypeIPHealthStatusItem>;
/** List of health statuses of the services on this target. Only present for target types "server" and "ip". */
export type TargetTypeIPHealthStatusList = Array<TargetTypeIPHealthStatusItem>;
export declare const TargetTypeIPHealthStatusList: S.Schema<TargetTypeIPHealthStatusList>;
export interface TargetTypeIP {
    /** Type of the resource. */
    type: TargetTypeIPType;
    /** IP target where the traffic should be routed to. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. Only present for target type `ip`. */
    ip: CreateLoadBalancerRequestTargetsItemIp;
    /** List of health statuses of the services on this target. Only present for target types "server" and "ip". */
    health_status: TargetTypeIPHealthStatusList;
}
export declare const TargetTypeIP: S.Schema<TargetTypeIP>;
export type CreateLoadBalancerResponseLoadBalancerTargetsItem = TargetTypeServer | TargetTypeLabelSelector | TargetTypeIP;
export declare const CreateLoadBalancerResponseLoadBalancerTargetsItem: S.Schema<CreateLoadBalancerResponseLoadBalancerTargetsItem>;
/** List of targets that belong to this Load Balancer. */
export type CreateLoadBalancerResponseLoadBalancerTargetsList = Array<CreateLoadBalancerResponseLoadBalancerTargetsItem>;
export declare const CreateLoadBalancerResponseLoadBalancerTargetsList: S.Schema<CreateLoadBalancerResponseLoadBalancerTargetsList>;
/** Type of the algorithm. */
export type CreateLoadBalancerResponseLoadBalancerAlgorithmType = "round_robin" | "least_connections";
export declare const CreateLoadBalancerResponseLoadBalancerAlgorithmType: any;
/** Algorithm of the Load Balancer. */
export interface CreateLoadBalancerResponseLoadBalancerAlgorithm {
    /** Type of the algorithm. */
    type: CreateLoadBalancerResponseLoadBalancerAlgorithmType;
}
export declare const CreateLoadBalancerResponseLoadBalancerAlgorithm: S.Schema<CreateLoadBalancerResponseLoadBalancerAlgorithm>;
export interface CreateLoadBalancerResponseLoadBalancer {
    /** ID of the [Load Balancer](#tag/load-balancers). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Public network information. */
    public_net: CreateLoadBalancerResponseLoadBalancerPublicNet;
    /** Private networks information. */
    private_net: CreateLoadBalancerResponseLoadBalancerPrivateNetList;
    location: CreateLoadBalancerResponseLoadBalancerLocation;
    load_balancer_type: CreateLoadBalancerResponseLoadBalancerLoadBalancerType;
    /** Protection configuration for the Resource. */
    protection: CreateLoadBalancerResponseLoadBalancerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateLoadBalancerResponseLoadBalancerLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** List of services that belong to this Load Balancer. */
    services: CreateLoadBalancerResponseLoadBalancerServicesList;
    /** List of targets that belong to this Load Balancer. */
    targets: CreateLoadBalancerResponseLoadBalancerTargetsList;
    /** Algorithm of the Load Balancer. */
    algorithm: CreateLoadBalancerResponseLoadBalancerAlgorithm;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number;
}
export declare const CreateLoadBalancerResponseLoadBalancer: S.Schema<CreateLoadBalancerResponseLoadBalancer>;
/** Status of the Action. */
export type CreateLoadBalancerResponseActionStatus = "running" | "success" | "error";
export declare const CreateLoadBalancerResponseActionStatus: any;
export interface CreateLoadBalancerResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateLoadBalancerResponseActionResourcesItem: S.Schema<CreateLoadBalancerResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateLoadBalancerResponseActionResourcesList = Array<CreateLoadBalancerResponseActionResourcesItem>;
export declare const CreateLoadBalancerResponseActionResourcesList: S.Schema<CreateLoadBalancerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateLoadBalancerResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateLoadBalancerResponseActionError: S.Schema<CreateLoadBalancerResponseActionError>;
export interface CreateLoadBalancerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateLoadBalancerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateLoadBalancerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateLoadBalancerResponseActionError | null;
}
export declare const CreateLoadBalancerResponseAction: S.Schema<CreateLoadBalancerResponseAction>;
export interface CreateLoadBalancerResponse {
    load_balancer: CreateLoadBalancerResponseLoadBalancer;
    action: CreateLoadBalancerResponseAction;
}
export declare const CreateLoadBalancerResponse: S.Schema<CreateLoadBalancerResponse>;
export interface DeleteLoadBalancerRequest {
    /** ID of the Load Balancer. */
    id: number;
}
export declare const DeleteLoadBalancerRequest: S.Schema<DeleteLoadBalancerRequest>;
export interface DeleteLoadBalancerResponse {
}
export declare const DeleteLoadBalancerResponse: S.Schema<DeleteLoadBalancerResponse>;
export interface GetLoadBalancerRequest {
    /** ID of the Load Balancer. */
    id: number;
}
export declare const GetLoadBalancerRequest: S.Schema<GetLoadBalancerRequest>;
/** IP address (v4). */
export type GetLoadBalancerResponseLoadBalancerPublicNetIpv4 = CreateLoadBalancerResponseLoadBalancerPublicNetIpv4;
export declare const GetLoadBalancerResponseLoadBalancerPublicNetIpv4: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv4>;
/** IP address (v6). */
export type GetLoadBalancerResponseLoadBalancerPublicNetIpv6 = CreateLoadBalancerResponseLoadBalancerPublicNetIpv6;
export declare const GetLoadBalancerResponseLoadBalancerPublicNetIpv6: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv6>;
/** Public network information. */
export type GetLoadBalancerResponseLoadBalancerPublicNet = CreateLoadBalancerResponseLoadBalancerPublicNet;
export declare const GetLoadBalancerResponseLoadBalancerPublicNet: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNet>;
export type GetLoadBalancerResponseLoadBalancerPrivateNetItem = CreateLoadBalancerResponseLoadBalancerPrivateNetItem;
export declare const GetLoadBalancerResponseLoadBalancerPrivateNetItem: S.Schema<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
/** Private networks information. */
export type GetLoadBalancerResponseLoadBalancerPrivateNetList = Array<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
export declare const GetLoadBalancerResponseLoadBalancerPrivateNetList: S.Schema<GetLoadBalancerResponseLoadBalancerPrivateNetList>;
export type GetLoadBalancerResponseLoadBalancerLocation = CreateLoadBalancerResponseLoadBalancerLocation;
export declare const GetLoadBalancerResponseLoadBalancerLocation: S.Schema<CreateLoadBalancerResponseLoadBalancerLocation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type GetLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation;
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation>;
/** Hourly price in this [Location](#tag/locations). */
export type GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceMonthly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceMonthly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPricePerTbTraffic = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPricePerTbTraffic: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
export type GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem;
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList = Array<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList: S.Schema<GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList>;
export interface GetLoadBalancerResponseLoadBalancerLoadBalancerType {
    /** ID of the Load Balancer type. */
    id: number;
    /** Unique identifier of the Load Balancer type. */
    name: string;
    /** Description of the Load Balancer type. */
    description: string;
    /** Number of maximum simultaneous open connections. */
    max_connections: number;
    /** Number of services a Load Balancer of this type can have. */
    max_services: number;
    /** Number of targets a single Load Balancer can have. */
    max_targets: number;
    /** Number of SSL Certificates that can be assigned to a single Load Balancer. */
    max_assigned_certificates: number;
    /** **Deprecated:** This field is deprecated. Use the `deprecation` object instead. Point in time when the Load Balancer type is deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation | null;
    /** Price per [Location](#tag/locations). */
    prices: GetLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList;
}
export declare const GetLoadBalancerResponseLoadBalancerLoadBalancerType: S.Schema<GetLoadBalancerResponseLoadBalancerLoadBalancerType>;
/** Protection configuration for the Resource. */
export type GetLoadBalancerResponseLoadBalancerProtection = CreateLoadBalancerResponseLoadBalancerProtection;
export declare const GetLoadBalancerResponseLoadBalancerProtection: S.Schema<CreateLoadBalancerResponseLoadBalancerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetLoadBalancerResponseLoadBalancerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetLoadBalancerResponseLoadBalancerLabelsMap: S.Schema<GetLoadBalancerResponseLoadBalancerLabelsMap>;
export type GetLoadBalancerResponseLoadBalancerServicesItem = ServiceTCP | ServiceHTTPProtocol | ServiceHTTPSProtocol;
export declare const GetLoadBalancerResponseLoadBalancerServicesItem: S.Schema<GetLoadBalancerResponseLoadBalancerServicesItem>;
/** List of services that belong to this Load Balancer. */
export type GetLoadBalancerResponseLoadBalancerServicesList = Array<GetLoadBalancerResponseLoadBalancerServicesItem>;
export declare const GetLoadBalancerResponseLoadBalancerServicesList: S.Schema<GetLoadBalancerResponseLoadBalancerServicesList>;
export type GetLoadBalancerResponseLoadBalancerTargetsItem = TargetTypeServer | TargetTypeLabelSelector | TargetTypeIP;
export declare const GetLoadBalancerResponseLoadBalancerTargetsItem: S.Schema<GetLoadBalancerResponseLoadBalancerTargetsItem>;
/** List of targets that belong to this Load Balancer. */
export type GetLoadBalancerResponseLoadBalancerTargetsList = Array<GetLoadBalancerResponseLoadBalancerTargetsItem>;
export declare const GetLoadBalancerResponseLoadBalancerTargetsList: S.Schema<GetLoadBalancerResponseLoadBalancerTargetsList>;
/** Type of the algorithm. */
export type GetLoadBalancerResponseLoadBalancerAlgorithmType = "round_robin" | "least_connections";
export declare const GetLoadBalancerResponseLoadBalancerAlgorithmType: any;
/** Algorithm of the Load Balancer. */
export interface GetLoadBalancerResponseLoadBalancerAlgorithm {
    /** Type of the algorithm. */
    type: GetLoadBalancerResponseLoadBalancerAlgorithmType;
}
export declare const GetLoadBalancerResponseLoadBalancerAlgorithm: S.Schema<GetLoadBalancerResponseLoadBalancerAlgorithm>;
export interface GetLoadBalancerResponseLoadBalancer {
    /** ID of the [Load Balancer](#tag/load-balancers). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Public network information. */
    public_net: CreateLoadBalancerResponseLoadBalancerPublicNet;
    /** Private networks information. */
    private_net: GetLoadBalancerResponseLoadBalancerPrivateNetList;
    location: CreateLoadBalancerResponseLoadBalancerLocation;
    load_balancer_type: GetLoadBalancerResponseLoadBalancerLoadBalancerType;
    /** Protection configuration for the Resource. */
    protection: CreateLoadBalancerResponseLoadBalancerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetLoadBalancerResponseLoadBalancerLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** List of services that belong to this Load Balancer. */
    services: GetLoadBalancerResponseLoadBalancerServicesList;
    /** List of targets that belong to this Load Balancer. */
    targets: GetLoadBalancerResponseLoadBalancerTargetsList;
    /** Algorithm of the Load Balancer. */
    algorithm: GetLoadBalancerResponseLoadBalancerAlgorithm;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number;
}
export declare const GetLoadBalancerResponseLoadBalancer: S.Schema<GetLoadBalancerResponseLoadBalancer>;
export interface GetLoadBalancerResponse {
    load_balancer: GetLoadBalancerResponseLoadBalancer;
}
export declare const GetLoadBalancerResponse: S.Schema<GetLoadBalancerResponse>;
export type GetLoadBalancerMetricsRequestTypeItem = "open_connections" | "connections_per_second" | "requests_per_second" | "bandwidth";
export declare const GetLoadBalancerMetricsRequestTypeItem: any;
export type GetLoadBalancerMetricsRequestTypeList = Array<GetLoadBalancerMetricsRequestTypeItem | (string & {})>;
export declare const GetLoadBalancerMetricsRequestTypeList: S.Schema<GetLoadBalancerMetricsRequestTypeList>;
export interface GetLoadBalancerMetricsRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** Type of metrics to get. */
    type: GetLoadBalancerMetricsRequestTypeList;
    /** Start of period to get Metrics for (must be in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    start: string;
    /** End of period to get Metrics for (must be in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    end: string;
    /** Resolution of results in seconds. */
    step?: string;
}
export declare const GetLoadBalancerMetricsRequest: S.Schema<GetLoadBalancerMetricsRequest>;
export type GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesItemList = Array<unknown>;
export declare const GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesItemList: S.Schema<GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesItemList>;
/** Metrics timestamps with values. */
export type GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesList = Array<GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesItemList>;
export declare const GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesList: S.Schema<GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesList>;
export interface GetLoadBalancerMetricsResponseMetricsTimeSeriesValue {
    /** Metrics timestamps with values. */
    values: GetLoadBalancerMetricsResponseMetricsTimeSeriesValueValuesList;
}
export declare const GetLoadBalancerMetricsResponseMetricsTimeSeriesValue: S.Schema<GetLoadBalancerMetricsResponseMetricsTimeSeriesValue>;
/** Hash with timeseries information, containing the name of timeseries as key. */
export type GetLoadBalancerMetricsResponseMetricsTimeSeriesMap = {
    [key: string]: GetLoadBalancerMetricsResponseMetricsTimeSeriesValue | undefined;
};
export declare const GetLoadBalancerMetricsResponseMetricsTimeSeriesMap: S.Schema<GetLoadBalancerMetricsResponseMetricsTimeSeriesMap>;
export interface GetLoadBalancerMetricsResponseMetrics {
    /** Start of period of metrics reported (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    start: string;
    /** End of period of metrics reported (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    end: string;
    /** Resolution of results in seconds. */
    step: number;
    /** Hash with timeseries information, containing the name of timeseries as key. */
    time_series: GetLoadBalancerMetricsResponseMetricsTimeSeriesMap;
}
export declare const GetLoadBalancerMetricsResponseMetrics: S.Schema<GetLoadBalancerMetricsResponseMetrics>;
export interface GetLoadBalancerMetricsResponse {
    metrics: GetLoadBalancerMetricsResponseMetrics;
}
export declare const GetLoadBalancerMetricsResponse: S.Schema<GetLoadBalancerMetricsResponse>;
export type ListLoadBalancersRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListLoadBalancersRequestSortItem: any;
export type ListLoadBalancersRequestSortList = Array<ListLoadBalancersRequestSortItem | (string & {})>;
export declare const ListLoadBalancersRequestSortList: S.Schema<ListLoadBalancersRequestSortList>;
export interface ListLoadBalancersRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListLoadBalancersRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListLoadBalancersRequest: S.Schema<ListLoadBalancersRequest>;
/** IP address (v4). */
export type ListLoadBalancersResponseLoadBalancersItemPublicNetIpv4 = CreateLoadBalancerResponseLoadBalancerPublicNetIpv4;
export declare const ListLoadBalancersResponseLoadBalancersItemPublicNetIpv4: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv4>;
/** IP address (v6). */
export type ListLoadBalancersResponseLoadBalancersItemPublicNetIpv6 = CreateLoadBalancerResponseLoadBalancerPublicNetIpv6;
export declare const ListLoadBalancersResponseLoadBalancersItemPublicNetIpv6: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv6>;
/** Public network information. */
export type ListLoadBalancersResponseLoadBalancersItemPublicNet = CreateLoadBalancerResponseLoadBalancerPublicNet;
export declare const ListLoadBalancersResponseLoadBalancersItemPublicNet: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNet>;
export type ListLoadBalancersResponseLoadBalancersItemPrivateNetItem = CreateLoadBalancerResponseLoadBalancerPrivateNetItem;
export declare const ListLoadBalancersResponseLoadBalancersItemPrivateNetItem: S.Schema<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
/** Private networks information. */
export type ListLoadBalancersResponseLoadBalancersItemPrivateNetList = Array<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
export declare const ListLoadBalancersResponseLoadBalancersItemPrivateNetList: S.Schema<ListLoadBalancersResponseLoadBalancersItemPrivateNetList>;
export type ListLoadBalancersResponseLoadBalancersItemLocation = CreateLoadBalancerResponseLoadBalancerLocation;
export declare const ListLoadBalancersResponseLoadBalancersItemLocation: S.Schema<CreateLoadBalancerResponseLoadBalancerLocation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypeDeprecation = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation;
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypeDeprecation: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation>;
/** Hourly price in this [Location](#tag/locations). */
export type ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItemPriceHourly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItemPriceHourly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItemPriceMonthly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItemPriceMonthly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItemPricePerTbTraffic = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItemPricePerTbTraffic: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
export type ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItem = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem;
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesItem: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesList = Array<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesList: S.Schema<ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesList>;
export interface ListLoadBalancersResponseLoadBalancersItemLoadBalancerType {
    /** ID of the Load Balancer type. */
    id: number;
    /** Unique identifier of the Load Balancer type. */
    name: string;
    /** Description of the Load Balancer type. */
    description: string;
    /** Number of maximum simultaneous open connections. */
    max_connections: number;
    /** Number of services a Load Balancer of this type can have. */
    max_services: number;
    /** Number of targets a single Load Balancer can have. */
    max_targets: number;
    /** Number of SSL Certificates that can be assigned to a single Load Balancer. */
    max_assigned_certificates: number;
    /** **Deprecated:** This field is deprecated. Use the `deprecation` object instead. Point in time when the Load Balancer type is deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation | null;
    /** Price per [Location](#tag/locations). */
    prices: ListLoadBalancersResponseLoadBalancersItemLoadBalancerTypePricesList;
}
export declare const ListLoadBalancersResponseLoadBalancersItemLoadBalancerType: S.Schema<ListLoadBalancersResponseLoadBalancersItemLoadBalancerType>;
/** Protection configuration for the Resource. */
export type ListLoadBalancersResponseLoadBalancersItemProtection = CreateLoadBalancerResponseLoadBalancerProtection;
export declare const ListLoadBalancersResponseLoadBalancersItemProtection: S.Schema<CreateLoadBalancerResponseLoadBalancerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListLoadBalancersResponseLoadBalancersItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListLoadBalancersResponseLoadBalancersItemLabelsMap: S.Schema<ListLoadBalancersResponseLoadBalancersItemLabelsMap>;
export type ListLoadBalancersResponseLoadBalancersItemServicesItem = ServiceTCP | ServiceHTTPProtocol | ServiceHTTPSProtocol;
export declare const ListLoadBalancersResponseLoadBalancersItemServicesItem: S.Schema<ListLoadBalancersResponseLoadBalancersItemServicesItem>;
/** List of services that belong to this Load Balancer. */
export type ListLoadBalancersResponseLoadBalancersItemServicesList = Array<ListLoadBalancersResponseLoadBalancersItemServicesItem>;
export declare const ListLoadBalancersResponseLoadBalancersItemServicesList: S.Schema<ListLoadBalancersResponseLoadBalancersItemServicesList>;
export type ListLoadBalancersResponseLoadBalancersItemTargetsItem = TargetTypeServer | TargetTypeLabelSelector | TargetTypeIP;
export declare const ListLoadBalancersResponseLoadBalancersItemTargetsItem: S.Schema<ListLoadBalancersResponseLoadBalancersItemTargetsItem>;
/** List of targets that belong to this Load Balancer. */
export type ListLoadBalancersResponseLoadBalancersItemTargetsList = Array<ListLoadBalancersResponseLoadBalancersItemTargetsItem>;
export declare const ListLoadBalancersResponseLoadBalancersItemTargetsList: S.Schema<ListLoadBalancersResponseLoadBalancersItemTargetsList>;
/** Type of the algorithm. */
export type ListLoadBalancersResponseLoadBalancersItemAlgorithmType = "round_robin" | "least_connections";
export declare const ListLoadBalancersResponseLoadBalancersItemAlgorithmType: any;
/** Algorithm of the Load Balancer. */
export interface ListLoadBalancersResponseLoadBalancersItemAlgorithm {
    /** Type of the algorithm. */
    type: ListLoadBalancersResponseLoadBalancersItemAlgorithmType;
}
export declare const ListLoadBalancersResponseLoadBalancersItemAlgorithm: S.Schema<ListLoadBalancersResponseLoadBalancersItemAlgorithm>;
export interface ListLoadBalancersResponseLoadBalancersItem {
    /** ID of the [Load Balancer](#tag/load-balancers). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Public network information. */
    public_net: CreateLoadBalancerResponseLoadBalancerPublicNet;
    /** Private networks information. */
    private_net: ListLoadBalancersResponseLoadBalancersItemPrivateNetList;
    location: CreateLoadBalancerResponseLoadBalancerLocation;
    load_balancer_type: ListLoadBalancersResponseLoadBalancersItemLoadBalancerType;
    /** Protection configuration for the Resource. */
    protection: CreateLoadBalancerResponseLoadBalancerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListLoadBalancersResponseLoadBalancersItemLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** List of services that belong to this Load Balancer. */
    services: ListLoadBalancersResponseLoadBalancersItemServicesList;
    /** List of targets that belong to this Load Balancer. */
    targets: ListLoadBalancersResponseLoadBalancersItemTargetsList;
    /** Algorithm of the Load Balancer. */
    algorithm: ListLoadBalancersResponseLoadBalancersItemAlgorithm;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number;
}
export declare const ListLoadBalancersResponseLoadBalancersItem: S.Schema<ListLoadBalancersResponseLoadBalancersItem>;
export type ListLoadBalancersResponseLoadBalancersList = Array<ListLoadBalancersResponseLoadBalancersItem>;
export declare const ListLoadBalancersResponseLoadBalancersList: S.Schema<ListLoadBalancersResponseLoadBalancersList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListLoadBalancersResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListLoadBalancersResponseMetaPagination: S.Schema<ListLoadBalancersResponseMetaPagination>;
export interface ListLoadBalancersResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListLoadBalancersResponseMetaPagination;
}
export declare const ListLoadBalancersResponseMeta: S.Schema<ListLoadBalancersResponseMeta>;
export interface ListLoadBalancersResponse {
    load_balancers: ListLoadBalancersResponseLoadBalancersList;
    meta: ListLoadBalancersResponseMeta;
}
export declare const ListLoadBalancersResponse: S.Schema<ListLoadBalancersResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateLoadBalancerRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateLoadBalancerRequestLabelsMap: S.Schema<UpdateLoadBalancerRequestLabelsMap>;
export interface UpdateLoadBalancerRequest {
    /** ID of the Load Balancer. */
    id: number;
    /** New Load Balancer name. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateLoadBalancerRequestLabelsMap;
}
export declare const UpdateLoadBalancerRequest: S.Schema<UpdateLoadBalancerRequest>;
/** IP address (v4). */
export type UpdateLoadBalancerResponseLoadBalancerPublicNetIpv4 = CreateLoadBalancerResponseLoadBalancerPublicNetIpv4;
export declare const UpdateLoadBalancerResponseLoadBalancerPublicNetIpv4: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv4>;
/** IP address (v6). */
export type UpdateLoadBalancerResponseLoadBalancerPublicNetIpv6 = CreateLoadBalancerResponseLoadBalancerPublicNetIpv6;
export declare const UpdateLoadBalancerResponseLoadBalancerPublicNetIpv6: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNetIpv6>;
/** Public network information. */
export type UpdateLoadBalancerResponseLoadBalancerPublicNet = CreateLoadBalancerResponseLoadBalancerPublicNet;
export declare const UpdateLoadBalancerResponseLoadBalancerPublicNet: S.Schema<CreateLoadBalancerResponseLoadBalancerPublicNet>;
export type UpdateLoadBalancerResponseLoadBalancerPrivateNetItem = CreateLoadBalancerResponseLoadBalancerPrivateNetItem;
export declare const UpdateLoadBalancerResponseLoadBalancerPrivateNetItem: S.Schema<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
/** Private networks information. */
export type UpdateLoadBalancerResponseLoadBalancerPrivateNetList = Array<CreateLoadBalancerResponseLoadBalancerPrivateNetItem>;
export declare const UpdateLoadBalancerResponseLoadBalancerPrivateNetList: S.Schema<UpdateLoadBalancerResponseLoadBalancerPrivateNetList>;
export type UpdateLoadBalancerResponseLoadBalancerLocation = CreateLoadBalancerResponseLoadBalancerLocation;
export declare const UpdateLoadBalancerResponseLoadBalancerLocation: S.Schema<CreateLoadBalancerResponseLoadBalancerLocation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation;
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation>;
/** Hourly price in this [Location](#tag/locations). */
export type UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceMonthly = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceMonthly: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPricePerTbTraffic = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly;
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPricePerTbTraffic: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItemPriceHourly>;
export type UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem = CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem;
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem: S.Schema<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList = Array<CreateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesItem>;
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList: S.Schema<UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList>;
export interface UpdateLoadBalancerResponseLoadBalancerLoadBalancerType {
    /** ID of the Load Balancer type. */
    id: number;
    /** Unique identifier of the Load Balancer type. */
    name: string;
    /** Description of the Load Balancer type. */
    description: string;
    /** Number of maximum simultaneous open connections. */
    max_connections: number;
    /** Number of services a Load Balancer of this type can have. */
    max_services: number;
    /** Number of targets a single Load Balancer can have. */
    max_targets: number;
    /** Number of SSL Certificates that can be assigned to a single Load Balancer. */
    max_assigned_certificates: number;
    /** **Deprecated:** This field is deprecated. Use the `deprecation` object instead. Point in time when the Load Balancer type is deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateLoadBalancerResponseLoadBalancerLoadBalancerTypeDeprecation | null;
    /** Price per [Location](#tag/locations). */
    prices: UpdateLoadBalancerResponseLoadBalancerLoadBalancerTypePricesList;
}
export declare const UpdateLoadBalancerResponseLoadBalancerLoadBalancerType: S.Schema<UpdateLoadBalancerResponseLoadBalancerLoadBalancerType>;
/** Protection configuration for the Resource. */
export type UpdateLoadBalancerResponseLoadBalancerProtection = CreateLoadBalancerResponseLoadBalancerProtection;
export declare const UpdateLoadBalancerResponseLoadBalancerProtection: S.Schema<CreateLoadBalancerResponseLoadBalancerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateLoadBalancerResponseLoadBalancerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateLoadBalancerResponseLoadBalancerLabelsMap: S.Schema<UpdateLoadBalancerResponseLoadBalancerLabelsMap>;
export type UpdateLoadBalancerResponseLoadBalancerServicesItem = ServiceTCP | ServiceHTTPProtocol | ServiceHTTPSProtocol;
export declare const UpdateLoadBalancerResponseLoadBalancerServicesItem: S.Schema<UpdateLoadBalancerResponseLoadBalancerServicesItem>;
/** List of services that belong to this Load Balancer. */
export type UpdateLoadBalancerResponseLoadBalancerServicesList = Array<UpdateLoadBalancerResponseLoadBalancerServicesItem>;
export declare const UpdateLoadBalancerResponseLoadBalancerServicesList: S.Schema<UpdateLoadBalancerResponseLoadBalancerServicesList>;
export type UpdateLoadBalancerResponseLoadBalancerTargetsItem = TargetTypeServer | TargetTypeLabelSelector | TargetTypeIP;
export declare const UpdateLoadBalancerResponseLoadBalancerTargetsItem: S.Schema<UpdateLoadBalancerResponseLoadBalancerTargetsItem>;
/** List of targets that belong to this Load Balancer. */
export type UpdateLoadBalancerResponseLoadBalancerTargetsList = Array<UpdateLoadBalancerResponseLoadBalancerTargetsItem>;
export declare const UpdateLoadBalancerResponseLoadBalancerTargetsList: S.Schema<UpdateLoadBalancerResponseLoadBalancerTargetsList>;
/** Type of the algorithm. */
export type UpdateLoadBalancerResponseLoadBalancerAlgorithmType = "round_robin" | "least_connections";
export declare const UpdateLoadBalancerResponseLoadBalancerAlgorithmType: any;
/** Algorithm of the Load Balancer. */
export interface UpdateLoadBalancerResponseLoadBalancerAlgorithm {
    /** Type of the algorithm. */
    type: UpdateLoadBalancerResponseLoadBalancerAlgorithmType;
}
export declare const UpdateLoadBalancerResponseLoadBalancerAlgorithm: S.Schema<UpdateLoadBalancerResponseLoadBalancerAlgorithm>;
export interface UpdateLoadBalancerResponseLoadBalancer {
    /** ID of the [Load Balancer](#tag/load-balancers). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Public network information. */
    public_net: CreateLoadBalancerResponseLoadBalancerPublicNet;
    /** Private networks information. */
    private_net: UpdateLoadBalancerResponseLoadBalancerPrivateNetList;
    location: CreateLoadBalancerResponseLoadBalancerLocation;
    load_balancer_type: UpdateLoadBalancerResponseLoadBalancerLoadBalancerType;
    /** Protection configuration for the Resource. */
    protection: CreateLoadBalancerResponseLoadBalancerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateLoadBalancerResponseLoadBalancerLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** List of services that belong to this Load Balancer. */
    services: UpdateLoadBalancerResponseLoadBalancerServicesList;
    /** List of targets that belong to this Load Balancer. */
    targets: UpdateLoadBalancerResponseLoadBalancerTargetsList;
    /** Algorithm of the Load Balancer. */
    algorithm: UpdateLoadBalancerResponseLoadBalancerAlgorithm;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number;
}
export declare const UpdateLoadBalancerResponseLoadBalancer: S.Schema<UpdateLoadBalancerResponseLoadBalancer>;
export interface UpdateLoadBalancerResponse {
    load_balancer: UpdateLoadBalancerResponseLoadBalancer;
}
export declare const UpdateLoadBalancerResponse: S.Schema<UpdateLoadBalancerResponse>;
export type CreateLoadBalancerError = HetznerOpError;
/** Create a Load Balancer Creates a Load Balancer. #### Operation specific errors */
export declare const createLoadBalancer: API.OperationMethod<CreateLoadBalancerRequest, CreateLoadBalancerResponse, CreateLoadBalancerError, HetznerOpContext>;
export type DeleteLoadBalancerError = HetznerOpError;
/** Delete a Load Balancer Deletes a Load Balancer. */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteLoadBalancerRequest, DeleteLoadBalancerResponse, DeleteLoadBalancerError, HetznerOpContext>;
export type GetLoadBalancerError = HetznerOpError;
/** Get a Load Balancer Gets a specific Load Balancer object. */
export declare const getLoadBalancer: API.OperationMethod<GetLoadBalancerRequest, GetLoadBalancerResponse, GetLoadBalancerError, HetznerOpContext>;
export type GetLoadBalancerMetricsError = HetznerOpError;
/** Get Metrics for a LoadBalancer You must specify the type of metric to get: `open_connections`, `connections_per_second`, `requests_per_second` or `bandwidth`. You can also specify more than one type by comma separation, e.g. `requests_per_second,bandwidth`. Depending on the type you will get different time series data: Metrics are available for the last 30 days only. If you do not provide the step argument we will automatically adjust it so that 200 samples are returned. We limit the number of samples to a maximum of 500 and will adjust the step parameter accordingly. */
export declare const getLoadBalancerMetrics: API.OperationMethod<GetLoadBalancerMetricsRequest, GetLoadBalancerMetricsResponse, GetLoadBalancerMetricsError, HetznerOpContext>;
export type ListLoadBalancersError = HetznerOpError;
/** List Load Balancers Gets all existing Load Balancers that you have available. */
export declare const listLoadBalancers: API.PaginatedOperationMethod<ListLoadBalancersRequest, ListLoadBalancersResponse, ListLoadBalancersError, HetznerOpContext, ListLoadBalancersResponseLoadBalancersItem>;
export type UpdateLoadBalancerError = HetznerOpError;
/** Update a Load Balancer Updates a Load Balancer. You can update a Load Balancer’s name and a Load Balancer’s labels. Note: if the Load Balancer object changes during the request, the response will be a “conflict” error. */
export declare const updateLoadBalancer: API.OperationMethod<UpdateLoadBalancerRequest, UpdateLoadBalancerResponse, UpdateLoadBalancerError, HetznerOpContext>;
//# sourceMappingURL=load_balancers.d.ts.map