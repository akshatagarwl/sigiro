import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface ChangeImageProtectionRequest {
    /** ID of the Image. */
    id: number;
    /** If true, prevents the snapshot from being deleted. */
    delete?: boolean;
}
export declare const ChangeImageProtectionRequest: S.Schema<ChangeImageProtectionRequest>;
/** Status of the Action. */
export type ChangeImageProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeImageProtectionResponseActionStatus: any;
export interface ChangeImageProtectionResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const ChangeImageProtectionResponseActionResourcesItem: S.Schema<ChangeImageProtectionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeImageProtectionResponseActionResourcesList = Array<ChangeImageProtectionResponseActionResourcesItem>;
export declare const ChangeImageProtectionResponseActionResourcesList: S.Schema<ChangeImageProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface ChangeImageProtectionResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const ChangeImageProtectionResponseActionError: S.Schema<ChangeImageProtectionResponseActionError>;
export interface ChangeImageProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeImageProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeImageProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeImageProtectionResponseActionError | null;
}
export declare const ChangeImageProtectionResponseAction: S.Schema<ChangeImageProtectionResponseAction>;
export interface ChangeImageProtectionResponse {
    action: ChangeImageProtectionResponseAction;
}
export declare const ChangeImageProtectionResponse: S.Schema<ChangeImageProtectionResponse>;
export interface GetImagesActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetImagesActionRequest: S.Schema<GetImagesActionRequest>;
/** Status of the Action. */
export type GetImagesActionResponseActionStatus = "running" | "success" | "error";
export declare const GetImagesActionResponseActionStatus: any;
export type GetImagesActionResponseActionResourcesItem = ChangeImageProtectionResponseActionResourcesItem;
export declare const GetImagesActionResponseActionResourcesItem: S.Schema<ChangeImageProtectionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetImagesActionResponseActionResourcesList = Array<ChangeImageProtectionResponseActionResourcesItem>;
export declare const GetImagesActionResponseActionResourcesList: S.Schema<GetImagesActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetImagesActionResponseActionError = ChangeImageProtectionResponseActionError;
export declare const GetImagesActionResponseActionError: S.Schema<ChangeImageProtectionResponseActionError>;
export interface GetImagesActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetImagesActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetImagesActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeImageProtectionResponseActionError | null;
}
export declare const GetImagesActionResponseAction: S.Schema<GetImagesActionResponseAction>;
export interface GetImagesActionResponse {
    action: GetImagesActionResponseAction;
}
export declare const GetImagesActionResponse: S.Schema<GetImagesActionResponse>;
export type ListImageActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListImageActionsRequestSortItem: any;
export type ListImageActionsRequestSortList = Array<ListImageActionsRequestSortItem | (string & {})>;
export declare const ListImageActionsRequestSortList: S.Schema<ListImageActionsRequestSortList>;
/** Status of the Action. */
export type ListImageActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListImageActionsRequestStatusItem: any;
export type ListImageActionsRequestStatusList = Array<ListImageActionsRequestStatusItem | (string & {})>;
export declare const ListImageActionsRequestStatusList: S.Schema<ListImageActionsRequestStatusList>;
export interface ListImageActionsRequest {
    /** ID of the Image. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListImageActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListImageActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListImageActionsRequest: S.Schema<ListImageActionsRequest>;
/** Status of the Action. */
export type ListImageActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListImageActionsResponseActionsItemStatus: any;
export type ListImageActionsResponseActionsItemResourcesItem = ChangeImageProtectionResponseActionResourcesItem;
export declare const ListImageActionsResponseActionsItemResourcesItem: S.Schema<ChangeImageProtectionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListImageActionsResponseActionsItemResourcesList = Array<ChangeImageProtectionResponseActionResourcesItem>;
export declare const ListImageActionsResponseActionsItemResourcesList: S.Schema<ListImageActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListImageActionsResponseActionsItemError = ChangeImageProtectionResponseActionError;
export declare const ListImageActionsResponseActionsItemError: S.Schema<ChangeImageProtectionResponseActionError>;
export interface ListImageActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListImageActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListImageActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeImageProtectionResponseActionError | null;
}
export declare const ListImageActionsResponseActionsItem: S.Schema<ListImageActionsResponseActionsItem>;
export type ListImageActionsResponseActionsList = Array<ListImageActionsResponseActionsItem>;
export declare const ListImageActionsResponseActionsList: S.Schema<ListImageActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListImageActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListImageActionsResponseMetaPagination: S.Schema<ListImageActionsResponseMetaPagination>;
export interface ListImageActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListImageActionsResponseMetaPagination;
}
export declare const ListImageActionsResponseMeta: S.Schema<ListImageActionsResponseMeta>;
export interface ListImageActionsResponse {
    actions: ListImageActionsResponseActionsList;
    meta: ListImageActionsResponseMeta;
}
export declare const ListImageActionsResponse: S.Schema<ListImageActionsResponse>;
export type ListImagesActionsRequestIdList = Array<number>;
export declare const ListImagesActionsRequestIdList: S.Schema<ListImagesActionsRequestIdList>;
export type ListImagesActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListImagesActionsRequestSortItem: any;
export type ListImagesActionsRequestSortList = Array<ListImagesActionsRequestSortItem | (string & {})>;
export declare const ListImagesActionsRequestSortList: S.Schema<ListImagesActionsRequestSortList>;
/** Status of the Action. */
export type ListImagesActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListImagesActionsRequestStatusItem: any;
export type ListImagesActionsRequestStatusList = Array<ListImagesActionsRequestStatusItem | (string & {})>;
export declare const ListImagesActionsRequestStatusList: S.Schema<ListImagesActionsRequestStatusList>;
export interface ListImagesActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListImagesActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListImagesActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListImagesActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListImagesActionsRequest: S.Schema<ListImagesActionsRequest>;
/** Status of the Action. */
export type ListImagesActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListImagesActionsResponseActionsItemStatus: any;
export type ListImagesActionsResponseActionsItemResourcesItem = ChangeImageProtectionResponseActionResourcesItem;
export declare const ListImagesActionsResponseActionsItemResourcesItem: S.Schema<ChangeImageProtectionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListImagesActionsResponseActionsItemResourcesList = Array<ChangeImageProtectionResponseActionResourcesItem>;
export declare const ListImagesActionsResponseActionsItemResourcesList: S.Schema<ListImagesActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListImagesActionsResponseActionsItemError = ChangeImageProtectionResponseActionError;
export declare const ListImagesActionsResponseActionsItemError: S.Schema<ChangeImageProtectionResponseActionError>;
export interface ListImagesActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListImagesActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListImagesActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeImageProtectionResponseActionError | null;
}
export declare const ListImagesActionsResponseActionsItem: S.Schema<ListImagesActionsResponseActionsItem>;
export type ListImagesActionsResponseActionsList = Array<ListImagesActionsResponseActionsItem>;
export declare const ListImagesActionsResponseActionsList: S.Schema<ListImagesActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListImagesActionsResponseMetaPagination = ListImageActionsResponseMetaPagination;
export declare const ListImagesActionsResponseMetaPagination: S.Schema<ListImageActionsResponseMetaPagination>;
export type ListImagesActionsResponseMeta = ListImageActionsResponseMeta;
export declare const ListImagesActionsResponseMeta: S.Schema<ListImageActionsResponseMeta>;
export interface ListImagesActionsResponse {
    actions: ListImagesActionsResponseActionsList;
    meta: ListImageActionsResponseMeta;
}
export declare const ListImagesActionsResponse: S.Schema<ListImagesActionsResponse>;
export type ChangeImageProtectionError = HetznerOpError;
/** Change Image Protection Changes the protection configuration of the Image. Can only be used on snapshots. */
export declare const changeImageProtection: API.OperationMethod<ChangeImageProtectionRequest, ChangeImageProtectionResponse, ChangeImageProtectionError, HetznerOpContext>;
export type GetImagesActionError = HetznerOpError;
/** Get an Action Returns a specific Action object. */
export declare const getImagesAction: API.OperationMethod<GetImagesActionRequest, GetImagesActionResponse, GetImagesActionError, HetznerOpContext>;
export type ListImageActionsError = HetznerOpError;
/** List Actions for an Image Returns all Action objects for an Image. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter. */
export declare const listImageActions: API.PaginatedOperationMethod<ListImageActionsRequest, ListImageActionsResponse, ListImageActionsError, HetznerOpContext, ListImageActionsResponseActionsItem>;
export type ListImagesActionsError = HetznerOpError;
/** List Actions Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` and `id` parameter. */
export declare const listImagesActions: API.PaginatedOperationMethod<ListImagesActionsRequest, ListImagesActionsResponse, ListImagesActionsError, HetznerOpContext, ListImagesActionsResponseActionsItem>;
//# sourceMappingURL=image_actions.d.ts.map