import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
export type CreateZoneRequestMode = "primary" | "secondary";
export declare const CreateZoneRequestMode: any;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateZoneRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateZoneRequestLabelsMap: S.Schema<CreateZoneRequestLabelsMap>;
/** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
export type CreateZoneRequestPrimaryNameserversItemTsigAlgorithm = "hmac-md5" | "hmac-sha1" | "hmac-sha256";
export declare const CreateZoneRequestPrimaryNameserversItemTsigAlgorithm: any;
/** Primary nameserver that returns [Zones](#tag/zones) via `AXFR`. Must allow queries from and may send `NOTIFY` queries to [Hetzner's secondary nameservers](https://docs.hetzner.com/dns-console/dns/general/authoritative-name-servers#secondary-dns-servers-old-name-servers-for-robot-customers). */
export interface CreateZoneRequestPrimaryNameserversItem {
    /** Public IPv4 or IPv6 address of the primary nameserver. Must be unique across all primary nameservers of this zone. */
    address: string;
    /** Port of the primary nameserver. */
    port?: number;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) key to use for the zone transfer. Must be base64 encoded. */
    tsig_key?: string;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
    tsig_algorithm?: CreateZoneRequestPrimaryNameserversItemTsigAlgorithm | (string & {});
}
export declare const CreateZoneRequestPrimaryNameserversItem: S.Schema<CreateZoneRequestPrimaryNameserversItem>;
/** Primary nameservers of the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in secondary mode. Ignored for [Zones](#tag/zones) in primary mode. */
export type CreateZoneRequestPrimaryNameserversList = Array<CreateZoneRequestPrimaryNameserversItem>;
export declare const CreateZoneRequestPrimaryNameserversList: S.Schema<CreateZoneRequestPrimaryNameserversList>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type CreateZoneRequestRrsetsItemType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const CreateZoneRequestRrsetsItemType: any;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export interface CreateZoneRequestRrsetsItemRecordsItem {
    /** Value of the record. For details about accepted values, see the [DNS record types documentation](https://docs.hetzner.com/networking/dns/record-types/overview/). */
    value: string;
    /** Comment of the record. */
    comment?: string;
}
export declare const CreateZoneRequestRrsetsItemRecordsItem: S.Schema<CreateZoneRequestRrsetsItemRecordsItem>;
/** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
export type CreateZoneRequestRrsetsItemRecordsList = Array<CreateZoneRequestRrsetsItemRecordsItem>;
export declare const CreateZoneRequestRrsetsItemRecordsList: S.Schema<CreateZoneRequestRrsetsItemRecordsList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateZoneRequestRrsetsItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateZoneRequestRrsetsItemLabelsMap: S.Schema<CreateZoneRequestRrsetsItemLabelsMap>;
export interface CreateZoneRequestRrsetsItem {
    /** Name of the [RRSet](#tag/zone-rrsets). The name must be in lower case, and must not end with a dot or the [Zone](#tag/zones) name. Names containing non-ASCII characters must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--4bi` (✉️). For the [Zone](#tag/zones) apex, use `@`. */
    name: string;
    /** Type of the [RRSet](#tag/zone-rrsets). */
    type: CreateZoneRequestRrsetsItemType | (string & {});
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl?: number | null;
    /** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
    records: CreateZoneRequestRrsetsItemRecordsList;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateZoneRequestRrsetsItemLabelsMap;
}
export declare const CreateZoneRequestRrsetsItem: S.Schema<CreateZoneRequestRrsetsItem>;
/** [RRSets](#tag/zone-rrsets) to be added to the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. Ignored for [Zones](#tag/zones) in secondary mode. */
export type CreateZoneRequestRrsetsList = Array<CreateZoneRequestRrsetsItem>;
export declare const CreateZoneRequestRrsetsList: S.Schema<CreateZoneRequestRrsetsList>;
export interface CreateZoneRequest {
    /** Name of the [Zone](#tag/zones). All names with [well-known public suffixes](https://publicsuffix.org/) (e.g. `.de`, `.com`, `.co.uk`) are supported. Subdomains are not supported. The name must be in lower case and must not end with a dot. [Internationalized domain names](https://en.wikipedia.org/wiki/Internationalized_domain_name) must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--mnchen-3ya.de` (`münchen.de`). */
    name: string;
    /** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
    mode: CreateZoneRequestMode | (string & {});
    /** Default Time To Live (TTL) of the [Zone](#tag/zones). Must be in between 60s and 2147483647s. This TTL is used for [RRSets](#tag/zone-rrsets) that do not explicitly define a TTL. */
    ttl?: number;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateZoneRequestLabelsMap;
    /** Primary nameservers of the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in secondary mode. Ignored for [Zones](#tag/zones) in primary mode. */
    primary_nameservers?: CreateZoneRequestPrimaryNameserversList;
    /** [RRSets](#tag/zone-rrsets) to be added to the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. Ignored for [Zones](#tag/zones) in secondary mode. */
    rrsets?: CreateZoneRequestRrsetsList;
    /** Zone file to import. Only applicable for [Zones](#tag/zones) in primary mode. Ignored for [Zones](#tag/zones) in secondary mode. If provided, `rrsets` must be empty. See [Zone file import](#tag/zones/zone-file-import) for more details. */
    zonefile?: string;
}
export declare const CreateZoneRequest: S.Schema<CreateZoneRequest>;
/** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
export type ZonePrimaryPrimaryNameserversItemTsigAlgorithm = "hmac-md5" | "hmac-sha1" | "hmac-sha256";
export declare const ZonePrimaryPrimaryNameserversItemTsigAlgorithm: any;
/** Primary nameserver that returns [Zones](#tag/zones) via `AXFR`. Must allow queries from and may send `NOTIFY` queries to [Hetzner's secondary nameservers](https://docs.hetzner.com/dns-console/dns/general/authoritative-name-servers#secondary-dns-servers-old-name-servers-for-robot-customers). */
export interface ZonePrimaryPrimaryNameserversItem {
    /** Public IPv4 or IPv6 address of the primary nameserver. Must be unique across all primary nameservers of this zone. */
    address: string;
    /** Port of the primary nameserver. */
    port?: number;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) key to use for the zone transfer. Must be base64 encoded. */
    tsig_key?: string;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
    tsig_algorithm?: ZonePrimaryPrimaryNameserversItemTsigAlgorithm;
}
export declare const ZonePrimaryPrimaryNameserversItem: S.Schema<ZonePrimaryPrimaryNameserversItem>;
/** Primary nameservers of the [Zone](#tag/zones). Only set if [Zone](#tag/zones) is in [secondary mode](#tag/zones/zone-modes), otherwise empty. */
export type ZonePrimaryPrimaryNameserversList = Array<ZonePrimaryPrimaryNameserversItem>;
export declare const ZonePrimaryPrimaryNameserversList: S.Schema<ZonePrimaryPrimaryNameserversList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ZonePrimaryLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ZonePrimaryLabelsMap: S.Schema<ZonePrimaryLabelsMap>;
/** Protection configuration for the Resource. */
export interface ZonePrimaryProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const ZonePrimaryProtection: S.Schema<ZonePrimaryProtection>;
/** Status of the [Zone](#tag/zones). */
export type ZonePrimaryStatus = "ok" | "updating" | "error";
export declare const ZonePrimaryStatus: any;
/** Authoritative Hetzner nameservers assigned to this [Zone](#tag/zones). */
export type ZonePrimaryAuthoritativeNameserversAssignedList = Array<string>;
export declare const ZonePrimaryAuthoritativeNameserversAssignedList: S.Schema<ZonePrimaryAuthoritativeNameserversAssignedList>;
/** Authoritative nameservers currently delegated to by the parent DNS zone. If these don't match the assigned authoritative nameservers, the DNS zone is currently not being served by Hetzner. */
export type ZonePrimaryAuthoritativeNameserversDelegatedList = Array<string>;
export declare const ZonePrimaryAuthoritativeNameserversDelegatedList: S.Schema<ZonePrimaryAuthoritativeNameserversDelegatedList>;
/** Status of the delegation. */
export type ZonePrimaryAuthoritativeNameserversDelegationStatus = "valid" | "partially-valid" | "invalid" | "lame" | "unregistered" | "unknown";
export declare const ZonePrimaryAuthoritativeNameserversDelegationStatus: any;
export interface ZonePrimaryAuthoritativeNameservers {
    /** Authoritative Hetzner nameservers assigned to this [Zone](#tag/zones). */
    assigned: ZonePrimaryAuthoritativeNameserversAssignedList;
    /** Authoritative nameservers currently delegated to by the parent DNS zone. If these don't match the assigned authoritative nameservers, the DNS zone is currently not being served by Hetzner. */
    delegated: ZonePrimaryAuthoritativeNameserversDelegatedList;
    /** Point in time (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format) when the DNS zone delegation was last checked. */
    delegation_last_check: string | null;
    /** Status of the delegation. */
    delegation_status?: ZonePrimaryAuthoritativeNameserversDelegationStatus;
}
export declare const ZonePrimaryAuthoritativeNameservers: S.Schema<ZonePrimaryAuthoritativeNameservers>;
/** Registrar of the domain. */
export type ZonePrimaryRegistrar = "hetzner" | "other" | "unknown";
export declare const ZonePrimaryRegistrar: any;
/** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
export type ZonePrimaryMode = "primary";
export declare const ZonePrimaryMode: any;
export interface ZonePrimary {
    /** ID of the [Zone](#tag/zones). */
    id: number;
    /** Name of the [Zone](#tag/zones). All names with [well-known public suffixes](https://publicsuffix.org/) (e.g. `.de`, `.com`, `.co.uk`) are supported. Subdomains are not supported. The name must be in lower case and must not end with a dot. [Internationalized domain names](https://en.wikipedia.org/wiki/Internationalized_domain_name) must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--mnchen-3ya.de` (`münchen.de`). */
    name: string;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Primary nameservers of the [Zone](#tag/zones). Only set if [Zone](#tag/zones) is in [secondary mode](#tag/zones/zone-modes), otherwise empty. */
    primary_nameservers?: ZonePrimaryPrimaryNameserversList;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ZonePrimaryLabelsMap;
    /** Protection configuration for the Resource. */
    protection: ZonePrimaryProtection;
    /** Default Time To Live (TTL) of the [Zone](#tag/zones). Must be in between 60s and 2147483647s. This TTL is used for [RRSets](#tag/zone-rrsets) that do not explicitly define a TTL. */
    ttl: number;
    /** Status of the [Zone](#tag/zones). */
    status: ZonePrimaryStatus;
    /** Number of resource records (RR) within the [Zone](#tag/zones). */
    record_count: number;
    authoritative_nameservers: ZonePrimaryAuthoritativeNameservers;
    /** Registrar of the domain. */
    registrar: ZonePrimaryRegistrar;
    /** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
    mode: ZonePrimaryMode;
}
export declare const ZonePrimary: S.Schema<ZonePrimary>;
/** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
export type ZoneSecondaryPrimaryNameserversItemTsigAlgorithm = "hmac-md5" | "hmac-sha1" | "hmac-sha256";
export declare const ZoneSecondaryPrimaryNameserversItemTsigAlgorithm: any;
/** Primary nameserver that returns [Zones](#tag/zones) via `AXFR`. Must allow queries from and may send `NOTIFY` queries to [Hetzner's secondary nameservers](https://docs.hetzner.com/dns-console/dns/general/authoritative-name-servers#secondary-dns-servers-old-name-servers-for-robot-customers). */
export interface ZoneSecondaryPrimaryNameserversItem {
    /** Public IPv4 or IPv6 address of the primary nameserver. Must be unique across all primary nameservers of this zone. */
    address: string;
    /** Port of the primary nameserver. */
    port?: number;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) key to use for the zone transfer. Must be base64 encoded. */
    tsig_key?: string;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
    tsig_algorithm?: ZoneSecondaryPrimaryNameserversItemTsigAlgorithm;
}
export declare const ZoneSecondaryPrimaryNameserversItem: S.Schema<ZoneSecondaryPrimaryNameserversItem>;
/** Primary nameservers of the [Zone](#tag/zones). Only set if [Zone](#tag/zones) is in [secondary mode](#tag/zones/zone-modes), otherwise empty. */
export type ZoneSecondaryPrimaryNameserversList = Array<ZoneSecondaryPrimaryNameserversItem>;
export declare const ZoneSecondaryPrimaryNameserversList: S.Schema<ZoneSecondaryPrimaryNameserversList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ZoneSecondaryLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ZoneSecondaryLabelsMap: S.Schema<ZoneSecondaryLabelsMap>;
/** Protection configuration for the Resource. */
export type ZoneSecondaryProtection = ZonePrimaryProtection;
export declare const ZoneSecondaryProtection: S.Schema<ZonePrimaryProtection>;
/** Status of the [Zone](#tag/zones). */
export type ZoneSecondaryStatus = "ok" | "updating" | "error";
export declare const ZoneSecondaryStatus: any;
/** Authoritative Hetzner nameservers assigned to this [Zone](#tag/zones). */
export type ZoneSecondaryAuthoritativeNameserversAssignedList = Array<string>;
export declare const ZoneSecondaryAuthoritativeNameserversAssignedList: S.Schema<ZoneSecondaryAuthoritativeNameserversAssignedList>;
/** Authoritative nameservers currently delegated to by the parent DNS zone. If these don't match the assigned authoritative nameservers, the DNS zone is currently not being served by Hetzner. */
export type ZoneSecondaryAuthoritativeNameserversDelegatedList = Array<string>;
export declare const ZoneSecondaryAuthoritativeNameserversDelegatedList: S.Schema<ZoneSecondaryAuthoritativeNameserversDelegatedList>;
/** Status of the delegation. */
export type ZoneSecondaryAuthoritativeNameserversDelegationStatus = "valid" | "partially-valid" | "invalid" | "lame" | "unregistered" | "unknown";
export declare const ZoneSecondaryAuthoritativeNameserversDelegationStatus: any;
export interface ZoneSecondaryAuthoritativeNameservers {
    /** Authoritative Hetzner nameservers assigned to this [Zone](#tag/zones). */
    assigned: ZoneSecondaryAuthoritativeNameserversAssignedList;
    /** Authoritative nameservers currently delegated to by the parent DNS zone. If these don't match the assigned authoritative nameservers, the DNS zone is currently not being served by Hetzner. */
    delegated: ZoneSecondaryAuthoritativeNameserversDelegatedList;
    /** Point in time (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format) when the DNS zone delegation was last checked. */
    delegation_last_check: string | null;
    /** Status of the delegation. */
    delegation_status?: ZoneSecondaryAuthoritativeNameserversDelegationStatus;
}
export declare const ZoneSecondaryAuthoritativeNameservers: S.Schema<ZoneSecondaryAuthoritativeNameservers>;
/** Registrar of the domain. */
export type ZoneSecondaryRegistrar = "hetzner" | "other" | "unknown";
export declare const ZoneSecondaryRegistrar: any;
/** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
export type ZoneSecondaryMode = "secondary";
export declare const ZoneSecondaryMode: any;
export interface ZoneSecondary {
    /** ID of the [Zone](#tag/zones). */
    id: number;
    /** Name of the [Zone](#tag/zones). All names with [well-known public suffixes](https://publicsuffix.org/) (e.g. `.de`, `.com`, `.co.uk`) are supported. Subdomains are not supported. The name must be in lower case and must not end with a dot. [Internationalized domain names](https://en.wikipedia.org/wiki/Internationalized_domain_name) must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--mnchen-3ya.de` (`münchen.de`). */
    name: string;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Primary nameservers of the [Zone](#tag/zones). Only set if [Zone](#tag/zones) is in [secondary mode](#tag/zones/zone-modes), otherwise empty. */
    primary_nameservers?: ZoneSecondaryPrimaryNameserversList;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ZoneSecondaryLabelsMap;
    /** Protection configuration for the Resource. */
    protection: ZonePrimaryProtection;
    /** Default Time To Live (TTL) of the [Zone](#tag/zones). Must be in between 60s and 2147483647s. This TTL is used for [RRSets](#tag/zone-rrsets) that do not explicitly define a TTL. */
    ttl: number;
    /** Status of the [Zone](#tag/zones). */
    status: ZoneSecondaryStatus;
    /** Number of resource records (RR) within the [Zone](#tag/zones). */
    record_count: number;
    authoritative_nameservers: ZoneSecondaryAuthoritativeNameservers;
    /** Registrar of the domain. */
    registrar: ZoneSecondaryRegistrar;
    /** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
    mode: ZoneSecondaryMode;
}
export declare const ZoneSecondary: S.Schema<ZoneSecondary>;
export type CreateZoneResponseZone = ZonePrimary | ZoneSecondary;
export declare const CreateZoneResponseZone: S.Schema<CreateZoneResponseZone>;
/** Status of the Action. */
export type CreateZoneResponseActionStatus = "running" | "success" | "error";
export declare const CreateZoneResponseActionStatus: any;
export interface CreateZoneResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateZoneResponseActionResourcesItem: S.Schema<CreateZoneResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateZoneResponseActionResourcesList = Array<CreateZoneResponseActionResourcesItem>;
export declare const CreateZoneResponseActionResourcesList: S.Schema<CreateZoneResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateZoneResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateZoneResponseActionError: S.Schema<CreateZoneResponseActionError>;
export interface CreateZoneResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateZoneResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateZoneResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateZoneResponseActionError | null;
}
export declare const CreateZoneResponseAction: S.Schema<CreateZoneResponseAction>;
export interface CreateZoneResponse {
    zone: CreateZoneResponseZone;
    action: CreateZoneResponseAction;
}
export declare const CreateZoneResponse: S.Schema<CreateZoneResponse>;
export interface DeleteZoneRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
}
export declare const DeleteZoneRequest: S.Schema<DeleteZoneRequest>;
/** Status of the Action. */
export type DeleteZoneResponseActionStatus = "running" | "success" | "error";
export declare const DeleteZoneResponseActionStatus: any;
export type DeleteZoneResponseActionResourcesItem = CreateZoneResponseActionResourcesItem;
export declare const DeleteZoneResponseActionResourcesItem: S.Schema<CreateZoneResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DeleteZoneResponseActionResourcesList = Array<CreateZoneResponseActionResourcesItem>;
export declare const DeleteZoneResponseActionResourcesList: S.Schema<DeleteZoneResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DeleteZoneResponseActionError = CreateZoneResponseActionError;
export declare const DeleteZoneResponseActionError: S.Schema<CreateZoneResponseActionError>;
export interface DeleteZoneResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DeleteZoneResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DeleteZoneResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateZoneResponseActionError | null;
}
export declare const DeleteZoneResponseAction: S.Schema<DeleteZoneResponseAction>;
export interface DeleteZoneResponse {
    action: DeleteZoneResponseAction;
}
export declare const DeleteZoneResponse: S.Schema<DeleteZoneResponse>;
export interface GetZoneRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
}
export declare const GetZoneRequest: S.Schema<GetZoneRequest>;
export type GetZoneResponseZone = ZonePrimary | ZoneSecondary;
export declare const GetZoneResponseZone: S.Schema<GetZoneResponseZone>;
export interface GetZoneResponse {
    zone: GetZoneResponseZone;
}
export declare const GetZoneResponse: S.Schema<GetZoneResponse>;
export interface GetZoneZonefileRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
}
export declare const GetZoneZonefileRequest: S.Schema<GetZoneZonefileRequest>;
export interface GetZoneZonefileResponse {
    /** Generated zone file. Example: ```dns $ORIGIN example.com. $TTL 3600 @ IN SOA hydrogen.ns.hetzner.com. dns.hetzner.com. 2024010100 86400 10800 3600000 3600 @ IN 10800 NS hydrogen.ns.hetzner.com. ; Some comment. @ IN 10800 NS oxygen.ns.hetzner.com. @ IN 10800 NS helium.ns.hetzner.de. ``` */
    zonefile: string;
}
export declare const GetZoneZonefileResponse: S.Schema<GetZoneZonefileResponse>;
/** Mode of the [Zone](#tag/zones). For more information, see [Zone Modes](#tag/zones/zone-modes). */
export type ListZonesRequestMode = "primary" | "secondary";
export declare const ListZonesRequestMode: any;
export type ListZonesRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListZonesRequestSortItem: any;
export type ListZonesRequestSortList = Array<ListZonesRequestSortItem | (string & {})>;
export declare const ListZonesRequestSortList: S.Schema<ListZonesRequestSortList>;
export interface ListZonesRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by their mode. The response will only contain the resources matching exactly the specified mode. */
    mode?: ListZonesRequestMode | (string & {});
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListZonesRequestSortList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListZonesRequest: S.Schema<ListZonesRequest>;
export type ListZonesResponseZonesItem = ZonePrimary | ZoneSecondary;
export declare const ListZonesResponseZonesItem: S.Schema<ListZonesResponseZonesItem>;
export type ListZonesResponseZonesList = Array<ListZonesResponseZonesItem>;
export declare const ListZonesResponseZonesList: S.Schema<ListZonesResponseZonesList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListZonesResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListZonesResponseMetaPagination: S.Schema<ListZonesResponseMetaPagination>;
export interface ListZonesResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListZonesResponseMetaPagination;
}
export declare const ListZonesResponseMeta: S.Schema<ListZonesResponseMeta>;
export interface ListZonesResponse {
    zones: ListZonesResponseZonesList;
    meta: ListZonesResponseMeta;
}
export declare const ListZonesResponse: S.Schema<ListZonesResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateZoneRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateZoneRequestLabelsMap: S.Schema<UpdateZoneRequestLabelsMap>;
export interface UpdateZoneRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateZoneRequestLabelsMap;
}
export declare const UpdateZoneRequest: S.Schema<UpdateZoneRequest>;
export type UpdateZoneResponseZone = ZonePrimary | ZoneSecondary;
export declare const UpdateZoneResponseZone: S.Schema<UpdateZoneResponseZone>;
export interface UpdateZoneResponse {
    zone: UpdateZoneResponseZone;
}
export declare const UpdateZoneResponse: S.Schema<UpdateZoneResponse>;
export type CreateZoneError = HetznerOpError;
/** Create a Zone Creates a [Zone](#tag/zones). A default `SOA` and three `NS` resource records with the assigned Hetzner nameservers are created automatically. */
export declare const createZone: API.OperationMethod<CreateZoneRequest, CreateZoneResponse, CreateZoneError, HetznerOpContext>;
export type DeleteZoneError = HetznerOpError;
/** Delete a Zone Deletes a [Zone](#tag/zones). */
export declare const deleteZone: API.OperationMethod<DeleteZoneRequest, DeleteZoneResponse, DeleteZoneError, HetznerOpContext>;
export type GetZoneError = HetznerOpError;
/** Get a Zone Returns a single [Zone](#tag/zones). */
export declare const getZone: API.OperationMethod<GetZoneRequest, GetZoneResponse, GetZoneError, HetznerOpContext>;
export type GetZoneZonefileError = HetznerOpError;
/** Export a Zone file Returns a generated [Zone](#tag/zones) file in BIND (RFC [1034](https://datatracker.ietf.org/doc/html/rfc1034)/[1035](https://datatracker.ietf.org/doc/html/rfc1035)) format. Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const getZoneZonefile: API.OperationMethod<GetZoneZonefileRequest, GetZoneZonefileResponse, GetZoneZonefileError, HetznerOpContext>;
export type ListZonesError = HetznerOpError;
/** List Zones Returns all [Zones](#tag/zones). Use the provided URI parameters to modify the result. */
export declare const listZones: API.PaginatedOperationMethod<ListZonesRequest, ListZonesResponse, ListZonesError, HetznerOpContext, ListZonesResponseZonesItem>;
export type UpdateZoneError = HetznerOpError;
/** Update a Zone Updates a [Zone](#tag/zones). To modify resource record sets ([RRSets](#tag/zone-rrsets)), use the [RRSet Actions endpoints](#tag/zone-rrset-actions). */
export declare const updateZone: API.OperationMethod<UpdateZoneRequest, UpdateZoneResponse, UpdateZoneError, HetznerOpContext>;
//# sourceMappingURL=zones.d.ts.map