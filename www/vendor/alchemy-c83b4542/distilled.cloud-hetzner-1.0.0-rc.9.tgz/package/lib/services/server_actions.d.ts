import * as S from "@distilled.cloud/core/schema";
import * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface AddServerToPlacementGroupRequest {
    /** ID of the Server. */
    id: number;
    /** ID of Placement Group the Server should be added to. */
    placement_group: number;
}
export declare const AddServerToPlacementGroupRequest: S.Schema<AddServerToPlacementGroupRequest>;
/** Status of the Action. */
export type AddServerToPlacementGroupResponseActionStatus = "running" | "success" | "error";
export declare const AddServerToPlacementGroupResponseActionStatus: any;
export interface AddServerToPlacementGroupResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AddServerToPlacementGroupResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AddServerToPlacementGroupResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const AddServerToPlacementGroupResponseActionResourcesList: S.Schema<AddServerToPlacementGroupResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AddServerToPlacementGroupResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AddServerToPlacementGroupResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface AddServerToPlacementGroupResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AddServerToPlacementGroupResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AddServerToPlacementGroupResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const AddServerToPlacementGroupResponseAction: S.Schema<AddServerToPlacementGroupResponseAction>;
export interface AddServerToPlacementGroupResponse {
    action: AddServerToPlacementGroupResponseAction;
}
export declare const AddServerToPlacementGroupResponse: S.Schema<AddServerToPlacementGroupResponse>;
export interface AttachServerIsoRequest {
    /** ID of the Server. */
    id: number;
    /** ID or name of ISO to attach to the Server as listed in GET `/isos`. */
    iso: string;
}
export declare const AttachServerIsoRequest: S.Schema<AttachServerIsoRequest>;
/** Status of the Action. */
export type AttachServerIsoResponseActionStatus = "running" | "success" | "error";
export declare const AttachServerIsoResponseActionStatus: any;
export type AttachServerIsoResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const AttachServerIsoResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AttachServerIsoResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const AttachServerIsoResponseActionResourcesList: S.Schema<AttachServerIsoResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type AttachServerIsoResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const AttachServerIsoResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface AttachServerIsoResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AttachServerIsoResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AttachServerIsoResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const AttachServerIsoResponseAction: S.Schema<AttachServerIsoResponseAction>;
export interface AttachServerIsoResponse {
    action: AttachServerIsoResponseAction;
}
export declare const AttachServerIsoResponse: S.Schema<AttachServerIsoResponse>;
/** Additional IPs to be assigned to this Server. */
export type AttachServerToNetworkRequestAliasIpsList = Array<string>;
export declare const AttachServerToNetworkRequestAliasIpsList: S.Schema<AttachServerToNetworkRequestAliasIpsList>;
export interface AttachServerToNetworkRequest {
    /** ID of the Server. */
    id: number;
    /** ID of an existing network to attach the Server to. */
    network: number;
    /** IP to request to be assigned to this Server; if you do not provide this then you will be auto assigned an IP address. */
    ip?: string;
    /** Additional IPs to be assigned to this Server. */
    alias_ips?: AttachServerToNetworkRequestAliasIpsList;
    /** IP range in CIDR block notation of the subnet to attach to. This allows for auto assigning an IP address for a specific subnet. Providing `ip` that is not part of `ip_range` will result in an error. */
    ip_range?: string;
}
export declare const AttachServerToNetworkRequest: S.Schema<AttachServerToNetworkRequest>;
/** Status of the Action. */
export type AttachServerToNetworkResponseActionStatus = "running" | "success" | "error";
export declare const AttachServerToNetworkResponseActionStatus: any;
export type AttachServerToNetworkResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const AttachServerToNetworkResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AttachServerToNetworkResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const AttachServerToNetworkResponseActionResourcesList: S.Schema<AttachServerToNetworkResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type AttachServerToNetworkResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const AttachServerToNetworkResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface AttachServerToNetworkResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AttachServerToNetworkResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AttachServerToNetworkResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const AttachServerToNetworkResponseAction: S.Schema<AttachServerToNetworkResponseAction>;
export interface AttachServerToNetworkResponse {
    action: AttachServerToNetworkResponseAction;
}
export declare const AttachServerToNetworkResponse: S.Schema<AttachServerToNetworkResponse>;
/** New alias IPs to set for this Server. */
export type ChangeServerAliasIpsRequestAliasIpsList = Array<string>;
export declare const ChangeServerAliasIpsRequestAliasIpsList: S.Schema<ChangeServerAliasIpsRequestAliasIpsList>;
export interface ChangeServerAliasIpsRequest {
    /** ID of the Server. */
    id: number;
    /** ID of an existing Network already attached to the Server. */
    network: number;
    /** New alias IPs to set for this Server. */
    alias_ips: ChangeServerAliasIpsRequestAliasIpsList;
}
export declare const ChangeServerAliasIpsRequest: S.Schema<ChangeServerAliasIpsRequest>;
/** Status of the Action. */
export type ChangeServerAliasIpsResponseActionStatus = "running" | "success" | "error";
export declare const ChangeServerAliasIpsResponseActionStatus: any;
export type ChangeServerAliasIpsResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ChangeServerAliasIpsResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeServerAliasIpsResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ChangeServerAliasIpsResponseActionResourcesList: S.Schema<ChangeServerAliasIpsResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeServerAliasIpsResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ChangeServerAliasIpsResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ChangeServerAliasIpsResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeServerAliasIpsResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeServerAliasIpsResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ChangeServerAliasIpsResponseAction: S.Schema<ChangeServerAliasIpsResponseAction>;
export interface ChangeServerAliasIpsResponse {
    action: ChangeServerAliasIpsResponseAction;
}
export declare const ChangeServerAliasIpsResponse: S.Schema<ChangeServerAliasIpsResponse>;
export interface ChangeServerDnsPtrRequest {
    /** ID of the Server. */
    id: number;
    /** Single IPv4 or IPv6 address to create pointer for. */
    ip: string;
    /** Domain Name to point to. PTR record content used for reverse DNS. Set to null to reset (IPv4) to the default value or remove (IPv6) the record. */
    dns_ptr?: string | null;
}
export declare const ChangeServerDnsPtrRequest: S.Schema<ChangeServerDnsPtrRequest>;
/** Status of the Action. */
export type ChangeServerDnsPtrResponseActionStatus = "running" | "success" | "error";
export declare const ChangeServerDnsPtrResponseActionStatus: any;
export type ChangeServerDnsPtrResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ChangeServerDnsPtrResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeServerDnsPtrResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ChangeServerDnsPtrResponseActionResourcesList: S.Schema<ChangeServerDnsPtrResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeServerDnsPtrResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ChangeServerDnsPtrResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ChangeServerDnsPtrResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeServerDnsPtrResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeServerDnsPtrResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ChangeServerDnsPtrResponseAction: S.Schema<ChangeServerDnsPtrResponseAction>;
export interface ChangeServerDnsPtrResponse {
    action: ChangeServerDnsPtrResponseAction;
}
export declare const ChangeServerDnsPtrResponse: S.Schema<ChangeServerDnsPtrResponse>;
export interface ChangeServerProtectionRequest {
    /** ID of the Server. */
    id: number;
    /** If true, prevents the Server from being deleted (currently delete and rebuild attribute needs to have the same value). */
    delete?: boolean;
    /** If true, prevents the Server from being rebuilt (currently delete and rebuild attribute needs to have the same value). */
    rebuild?: boolean;
}
export declare const ChangeServerProtectionRequest: S.Schema<ChangeServerProtectionRequest>;
/** Status of the Action. */
export type ChangeServerProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeServerProtectionResponseActionStatus: any;
export type ChangeServerProtectionResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ChangeServerProtectionResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeServerProtectionResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ChangeServerProtectionResponseActionResourcesList: S.Schema<ChangeServerProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeServerProtectionResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ChangeServerProtectionResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ChangeServerProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeServerProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeServerProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ChangeServerProtectionResponseAction: S.Schema<ChangeServerProtectionResponseAction>;
export interface ChangeServerProtectionResponse {
    action: ChangeServerProtectionResponseAction;
}
export declare const ChangeServerProtectionResponse: S.Schema<ChangeServerProtectionResponse>;
export interface ChangeServerTypeRequest {
    /** ID of the Server. */
    id: number;
    /** If false, do not upgrade the disk (this allows downgrading the Server type later). */
    upgrade_disk: boolean;
    /** ID or name of Server type the Server should migrate to. */
    server_type: string;
}
export declare const ChangeServerTypeRequest: S.Schema<ChangeServerTypeRequest>;
/** Status of the Action. */
export type ChangeServerTypeResponseActionStatus = "running" | "success" | "error";
export declare const ChangeServerTypeResponseActionStatus: any;
export type ChangeServerTypeResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ChangeServerTypeResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeServerTypeResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ChangeServerTypeResponseActionResourcesList: S.Schema<ChangeServerTypeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeServerTypeResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ChangeServerTypeResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ChangeServerTypeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeServerTypeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeServerTypeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ChangeServerTypeResponseAction: S.Schema<ChangeServerTypeResponseAction>;
export interface ChangeServerTypeResponse {
    action: ChangeServerTypeResponseAction;
}
export declare const ChangeServerTypeResponse: S.Schema<ChangeServerTypeResponse>;
/** Type of Image to create. */
export type CreateServerImageRequestType = "snapshot" | "backup";
export declare const CreateServerImageRequestType: any;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateServerImageRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateServerImageRequestLabelsMap: S.Schema<CreateServerImageRequestLabelsMap>;
export interface CreateServerImageRequest {
    /** ID of the Server. */
    id: number;
    /** Description of the Image, will be auto-generated if not set. */
    description?: string;
    /** Type of Image to create. */
    type?: CreateServerImageRequestType | (string & {});
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateServerImageRequestLabelsMap;
}
export declare const CreateServerImageRequest: S.Schema<CreateServerImageRequest>;
/** Type of the Image. */
export type CreateServerImageResponseImageType = "system" | "app" | "snapshot" | "backup";
export declare const CreateServerImageResponseImageType: any;
/** Status of the Image. */
export type CreateServerImageResponseImageStatus = "available" | "creating" | "unavailable";
export declare const CreateServerImageResponseImageStatus: any;
/** Information about the Server the Image was created from. */
export interface CreateServerImageResponseImageCreatedFrom {
    /** ID of the Server the Image was created from. */
    id: number;
    /** Server name at the time the Image was created. */
    name: string;
}
export declare const CreateServerImageResponseImageCreatedFrom: S.Schema<CreateServerImageResponseImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type CreateServerImageResponseImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const CreateServerImageResponseImageOsFlavor: any;
/** Protection configuration for the Resource. */
export interface CreateServerImageResponseImageProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreateServerImageResponseImageProtection: S.Schema<CreateServerImageResponseImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateServerImageResponseImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateServerImageResponseImageLabelsMap: S.Schema<CreateServerImageResponseImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type CreateServerImageResponseImageArchitecture = "x86" | "arm";
export declare const CreateServerImageResponseImageArchitecture: any;
export interface CreateServerImageResponseImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: CreateServerImageResponseImageType;
    /** Status of the Image. */
    status: CreateServerImageResponseImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: CreateServerImageResponseImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: CreateServerImageResponseImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateServerImageResponseImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateServerImageResponseImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: CreateServerImageResponseImageArchitecture;
}
export declare const CreateServerImageResponseImage: S.Schema<CreateServerImageResponseImage>;
/** Status of the Action. */
export type CreateServerImageResponseActionStatus = "running" | "success" | "error";
export declare const CreateServerImageResponseActionStatus: any;
export type CreateServerImageResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const CreateServerImageResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateServerImageResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const CreateServerImageResponseActionResourcesList: S.Schema<CreateServerImageResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type CreateServerImageResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const CreateServerImageResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface CreateServerImageResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateServerImageResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateServerImageResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const CreateServerImageResponseAction: S.Schema<CreateServerImageResponseAction>;
export interface CreateServerImageResponse {
    image?: CreateServerImageResponseImage;
    action?: CreateServerImageResponseAction;
}
export declare const CreateServerImageResponse: S.Schema<CreateServerImageResponse>;
export interface DetachServerFromNetworkRequest {
    /** ID of the Server. */
    id: number;
    /** ID of an existing network to detach the Server from. */
    network: number;
}
export declare const DetachServerFromNetworkRequest: S.Schema<DetachServerFromNetworkRequest>;
/** Status of the Action. */
export type DetachServerFromNetworkResponseActionStatus = "running" | "success" | "error";
export declare const DetachServerFromNetworkResponseActionStatus: any;
export type DetachServerFromNetworkResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const DetachServerFromNetworkResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DetachServerFromNetworkResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const DetachServerFromNetworkResponseActionResourcesList: S.Schema<DetachServerFromNetworkResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DetachServerFromNetworkResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const DetachServerFromNetworkResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface DetachServerFromNetworkResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DetachServerFromNetworkResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DetachServerFromNetworkResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const DetachServerFromNetworkResponseAction: S.Schema<DetachServerFromNetworkResponseAction>;
export interface DetachServerFromNetworkResponse {
    action: DetachServerFromNetworkResponseAction;
}
export declare const DetachServerFromNetworkResponse: S.Schema<DetachServerFromNetworkResponse>;
export interface DetachServerIsoRequest {
    /** ID of the Server. */
    id: number;
}
export declare const DetachServerIsoRequest: S.Schema<DetachServerIsoRequest>;
/** Status of the Action. */
export type DetachServerIsoResponseActionStatus = "running" | "success" | "error";
export declare const DetachServerIsoResponseActionStatus: any;
export type DetachServerIsoResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const DetachServerIsoResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DetachServerIsoResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const DetachServerIsoResponseActionResourcesList: S.Schema<DetachServerIsoResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DetachServerIsoResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const DetachServerIsoResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface DetachServerIsoResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DetachServerIsoResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DetachServerIsoResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const DetachServerIsoResponseAction: S.Schema<DetachServerIsoResponseAction>;
export interface DetachServerIsoResponse {
    action: DetachServerIsoResponseAction;
}
export declare const DetachServerIsoResponse: S.Schema<DetachServerIsoResponse>;
export interface DisableServerBackupRequest {
    /** ID of the Server. */
    id: number;
}
export declare const DisableServerBackupRequest: S.Schema<DisableServerBackupRequest>;
/** Status of the Action. */
export type DisableServerBackupResponseActionStatus = "running" | "success" | "error";
export declare const DisableServerBackupResponseActionStatus: any;
export type DisableServerBackupResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const DisableServerBackupResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DisableServerBackupResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const DisableServerBackupResponseActionResourcesList: S.Schema<DisableServerBackupResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DisableServerBackupResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const DisableServerBackupResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface DisableServerBackupResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DisableServerBackupResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DisableServerBackupResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const DisableServerBackupResponseAction: S.Schema<DisableServerBackupResponseAction>;
export interface DisableServerBackupResponse {
    action: DisableServerBackupResponseAction;
}
export declare const DisableServerBackupResponse: S.Schema<DisableServerBackupResponse>;
export interface DisableServerRescueRequest {
    /** ID of the Server. */
    id: number;
}
export declare const DisableServerRescueRequest: S.Schema<DisableServerRescueRequest>;
/** Status of the Action. */
export type DisableServerRescueResponseActionStatus = "running" | "success" | "error";
export declare const DisableServerRescueResponseActionStatus: any;
export type DisableServerRescueResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const DisableServerRescueResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DisableServerRescueResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const DisableServerRescueResponseActionResourcesList: S.Schema<DisableServerRescueResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DisableServerRescueResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const DisableServerRescueResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface DisableServerRescueResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DisableServerRescueResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DisableServerRescueResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const DisableServerRescueResponseAction: S.Schema<DisableServerRescueResponseAction>;
export interface DisableServerRescueResponse {
    action: DisableServerRescueResponseAction;
}
export declare const DisableServerRescueResponse: S.Schema<DisableServerRescueResponse>;
export interface EnableServerBackupRequest {
    /** ID of the Server. */
    id: number;
}
export declare const EnableServerBackupRequest: S.Schema<EnableServerBackupRequest>;
/** Status of the Action. */
export type EnableServerBackupResponseActionStatus = "running" | "success" | "error";
export declare const EnableServerBackupResponseActionStatus: any;
export type EnableServerBackupResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const EnableServerBackupResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type EnableServerBackupResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const EnableServerBackupResponseActionResourcesList: S.Schema<EnableServerBackupResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type EnableServerBackupResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const EnableServerBackupResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface EnableServerBackupResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: EnableServerBackupResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: EnableServerBackupResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const EnableServerBackupResponseAction: S.Schema<EnableServerBackupResponseAction>;
export interface EnableServerBackupResponse {
    action: EnableServerBackupResponseAction;
}
export declare const EnableServerBackupResponse: S.Schema<EnableServerBackupResponse>;
/** Type of rescue system to boot. */
export type EnableServerRescueRequestType = "linux64";
export declare const EnableServerRescueRequestType: any;
/** Array of SSH key IDs which should be injected into the rescue system. */
export type EnableServerRescueRequestSshKeysList = Array<number>;
export declare const EnableServerRescueRequestSshKeysList: S.Schema<EnableServerRescueRequestSshKeysList>;
export interface EnableServerRescueRequest {
    /** ID of the Server. */
    id: number;
    /** Type of rescue system to boot. */
    type?: EnableServerRescueRequestType | (string & {});
    /** Array of SSH key IDs which should be injected into the rescue system. */
    ssh_keys?: EnableServerRescueRequestSshKeysList;
}
export declare const EnableServerRescueRequest: S.Schema<EnableServerRescueRequest>;
/** Status of the Action. */
export type EnableServerRescueResponseActionStatus = "running" | "success" | "error";
export declare const EnableServerRescueResponseActionStatus: any;
export type EnableServerRescueResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const EnableServerRescueResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type EnableServerRescueResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const EnableServerRescueResponseActionResourcesList: S.Schema<EnableServerRescueResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type EnableServerRescueResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const EnableServerRescueResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface EnableServerRescueResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: EnableServerRescueResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: EnableServerRescueResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const EnableServerRescueResponseAction: S.Schema<EnableServerRescueResponseAction>;
export interface EnableServerRescueResponse {
    /** Password that will be set for this Server once the Action succeeds. */
    root_password?: string | Redacted.Redacted<string>;
    action?: EnableServerRescueResponseAction;
}
export declare const EnableServerRescueResponse: S.Schema<EnableServerRescueResponse>;
export interface GetServersActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetServersActionRequest: S.Schema<GetServersActionRequest>;
/** Status of the Action. */
export type GetServersActionResponseActionStatus = "running" | "success" | "error";
export declare const GetServersActionResponseActionStatus: any;
export type GetServersActionResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const GetServersActionResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetServersActionResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const GetServersActionResponseActionResourcesList: S.Schema<GetServersActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetServersActionResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const GetServersActionResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface GetServersActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetServersActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetServersActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const GetServersActionResponseAction: S.Schema<GetServersActionResponseAction>;
export interface GetServersActionResponse {
    action: GetServersActionResponseAction;
}
export declare const GetServersActionResponse: S.Schema<GetServersActionResponse>;
export type ListServerActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListServerActionsRequestSortItem: any;
export type ListServerActionsRequestSortList = Array<ListServerActionsRequestSortItem | (string & {})>;
export declare const ListServerActionsRequestSortList: S.Schema<ListServerActionsRequestSortList>;
/** Status of the Action. */
export type ListServerActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListServerActionsRequestStatusItem: any;
export type ListServerActionsRequestStatusList = Array<ListServerActionsRequestStatusItem | (string & {})>;
export declare const ListServerActionsRequestStatusList: S.Schema<ListServerActionsRequestStatusList>;
export interface ListServerActionsRequest {
    /** ID of the Server. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListServerActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListServerActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListServerActionsRequest: S.Schema<ListServerActionsRequest>;
/** Status of the Action. */
export type ListServerActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListServerActionsResponseActionsItemStatus: any;
export type ListServerActionsResponseActionsItemResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ListServerActionsResponseActionsItemResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListServerActionsResponseActionsItemResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ListServerActionsResponseActionsItemResourcesList: S.Schema<ListServerActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListServerActionsResponseActionsItemError = AddServerToPlacementGroupResponseActionError;
export declare const ListServerActionsResponseActionsItemError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ListServerActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListServerActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListServerActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ListServerActionsResponseActionsItem: S.Schema<ListServerActionsResponseActionsItem>;
export type ListServerActionsResponseActionsList = Array<ListServerActionsResponseActionsItem>;
export declare const ListServerActionsResponseActionsList: S.Schema<ListServerActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListServerActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListServerActionsResponseMetaPagination: S.Schema<ListServerActionsResponseMetaPagination>;
export interface ListServerActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListServerActionsResponseMetaPagination;
}
export declare const ListServerActionsResponseMeta: S.Schema<ListServerActionsResponseMeta>;
export interface ListServerActionsResponse {
    actions: ListServerActionsResponseActionsList;
    meta: ListServerActionsResponseMeta;
}
export declare const ListServerActionsResponse: S.Schema<ListServerActionsResponse>;
export type ListServersActionsRequestIdList = Array<number>;
export declare const ListServersActionsRequestIdList: S.Schema<ListServersActionsRequestIdList>;
export type ListServersActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListServersActionsRequestSortItem: any;
export type ListServersActionsRequestSortList = Array<ListServersActionsRequestSortItem | (string & {})>;
export declare const ListServersActionsRequestSortList: S.Schema<ListServersActionsRequestSortList>;
/** Status of the Action. */
export type ListServersActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListServersActionsRequestStatusItem: any;
export type ListServersActionsRequestStatusList = Array<ListServersActionsRequestStatusItem | (string & {})>;
export declare const ListServersActionsRequestStatusList: S.Schema<ListServersActionsRequestStatusList>;
export interface ListServersActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListServersActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListServersActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListServersActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListServersActionsRequest: S.Schema<ListServersActionsRequest>;
/** Status of the Action. */
export type ListServersActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListServersActionsResponseActionsItemStatus: any;
export type ListServersActionsResponseActionsItemResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ListServersActionsResponseActionsItemResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListServersActionsResponseActionsItemResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ListServersActionsResponseActionsItemResourcesList: S.Schema<ListServersActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListServersActionsResponseActionsItemError = AddServerToPlacementGroupResponseActionError;
export declare const ListServersActionsResponseActionsItemError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ListServersActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListServersActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListServersActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ListServersActionsResponseActionsItem: S.Schema<ListServersActionsResponseActionsItem>;
export type ListServersActionsResponseActionsList = Array<ListServersActionsResponseActionsItem>;
export declare const ListServersActionsResponseActionsList: S.Schema<ListServersActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListServersActionsResponseMetaPagination = ListServerActionsResponseMetaPagination;
export declare const ListServersActionsResponseMetaPagination: S.Schema<ListServerActionsResponseMetaPagination>;
export type ListServersActionsResponseMeta = ListServerActionsResponseMeta;
export declare const ListServersActionsResponseMeta: S.Schema<ListServerActionsResponseMeta>;
export interface ListServersActionsResponse {
    actions: ListServersActionsResponseActionsList;
    meta: ListServerActionsResponseMeta;
}
export declare const ListServersActionsResponse: S.Schema<ListServersActionsResponse>;
export interface PoweroffServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const PoweroffServerRequest: S.Schema<PoweroffServerRequest>;
/** Status of the Action. */
export type PoweroffServerResponseActionStatus = "running" | "success" | "error";
export declare const PoweroffServerResponseActionStatus: any;
export type PoweroffServerResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const PoweroffServerResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type PoweroffServerResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const PoweroffServerResponseActionResourcesList: S.Schema<PoweroffServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type PoweroffServerResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const PoweroffServerResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface PoweroffServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: PoweroffServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: PoweroffServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const PoweroffServerResponseAction: S.Schema<PoweroffServerResponseAction>;
export interface PoweroffServerResponse {
    action: PoweroffServerResponseAction;
}
export declare const PoweroffServerResponse: S.Schema<PoweroffServerResponse>;
export interface PoweronServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const PoweronServerRequest: S.Schema<PoweronServerRequest>;
/** Status of the Action. */
export type PoweronServerResponseActionStatus = "running" | "success" | "error";
export declare const PoweronServerResponseActionStatus: any;
export type PoweronServerResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const PoweronServerResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type PoweronServerResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const PoweronServerResponseActionResourcesList: S.Schema<PoweronServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type PoweronServerResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const PoweronServerResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface PoweronServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: PoweronServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: PoweronServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const PoweronServerResponseAction: S.Schema<PoweronServerResponseAction>;
export interface PoweronServerResponse {
    action: PoweronServerResponseAction;
}
export declare const PoweronServerResponse: S.Schema<PoweronServerResponse>;
export interface RebootServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const RebootServerRequest: S.Schema<RebootServerRequest>;
/** Status of the Action. */
export type RebootServerResponseActionStatus = "running" | "success" | "error";
export declare const RebootServerResponseActionStatus: any;
export type RebootServerResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const RebootServerResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RebootServerResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const RebootServerResponseActionResourcesList: S.Schema<RebootServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RebootServerResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const RebootServerResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface RebootServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RebootServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RebootServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const RebootServerResponseAction: S.Schema<RebootServerResponseAction>;
export interface RebootServerResponse {
    action: RebootServerResponseAction;
}
export declare const RebootServerResponse: S.Schema<RebootServerResponse>;
export interface RebuildServerRequest {
    /** ID of the Server. */
    id: number;
    /** ID or name of Image to rebuilt from. */
    image: string;
    /** Cloud-Init user data to use during Server rebuild. This field is limited to 32KiB. If not specified, the Server's previous user_data value will be re-used (if any was set). */
    user_data?: string;
}
export declare const RebuildServerRequest: S.Schema<RebuildServerRequest>;
/** Status of the Action. */
export type RebuildServerResponseActionStatus = "running" | "success" | "error";
export declare const RebuildServerResponseActionStatus: any;
export type RebuildServerResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const RebuildServerResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RebuildServerResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const RebuildServerResponseActionResourcesList: S.Schema<RebuildServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RebuildServerResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const RebuildServerResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface RebuildServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RebuildServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RebuildServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const RebuildServerResponseAction: S.Schema<RebuildServerResponseAction>;
export interface RebuildServerResponse {
    /** New root password when not using SSH keys. */
    root_password?: string | Redacted.Redacted<string> | null;
    action?: RebuildServerResponseAction;
}
export declare const RebuildServerResponse: S.Schema<RebuildServerResponse>;
export interface RemoveServerFromPlacementGroupRequest {
    /** ID of the Server. */
    id: number;
}
export declare const RemoveServerFromPlacementGroupRequest: S.Schema<RemoveServerFromPlacementGroupRequest>;
/** Status of the Action. */
export type RemoveServerFromPlacementGroupResponseActionStatus = "running" | "success" | "error";
export declare const RemoveServerFromPlacementGroupResponseActionStatus: any;
export type RemoveServerFromPlacementGroupResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const RemoveServerFromPlacementGroupResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RemoveServerFromPlacementGroupResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const RemoveServerFromPlacementGroupResponseActionResourcesList: S.Schema<RemoveServerFromPlacementGroupResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RemoveServerFromPlacementGroupResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const RemoveServerFromPlacementGroupResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface RemoveServerFromPlacementGroupResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RemoveServerFromPlacementGroupResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RemoveServerFromPlacementGroupResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const RemoveServerFromPlacementGroupResponseAction: S.Schema<RemoveServerFromPlacementGroupResponseAction>;
export interface RemoveServerFromPlacementGroupResponse {
    action: RemoveServerFromPlacementGroupResponseAction;
}
export declare const RemoveServerFromPlacementGroupResponse: S.Schema<RemoveServerFromPlacementGroupResponse>;
export interface RequestServerConsoleRequest {
    /** ID of the Server. */
    id: number;
}
export declare const RequestServerConsoleRequest: S.Schema<RequestServerConsoleRequest>;
/** Status of the Action. */
export type RequestServerConsoleResponseActionStatus = "running" | "success" | "error";
export declare const RequestServerConsoleResponseActionStatus: any;
export type RequestServerConsoleResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const RequestServerConsoleResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RequestServerConsoleResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const RequestServerConsoleResponseActionResourcesList: S.Schema<RequestServerConsoleResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RequestServerConsoleResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const RequestServerConsoleResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface RequestServerConsoleResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RequestServerConsoleResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RequestServerConsoleResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const RequestServerConsoleResponseAction: S.Schema<RequestServerConsoleResponseAction>;
export interface RequestServerConsoleResponse {
    /** URL of websocket proxy to use; this includes a token which is valid for a limited time only. */
    wss_url: string;
    /** VNC password to use for this connection (this password only works in combination with a wss_url with valid token). */
    password: string | Redacted.Redacted<string>;
    action: RequestServerConsoleResponseAction;
}
export declare const RequestServerConsoleResponse: S.Schema<RequestServerConsoleResponse>;
export interface ResetServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const ResetServerRequest: S.Schema<ResetServerRequest>;
/** Status of the Action. */
export type ResetServerResponseActionStatus = "running" | "success" | "error";
export declare const ResetServerResponseActionStatus: any;
export type ResetServerResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ResetServerResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ResetServerResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ResetServerResponseActionResourcesList: S.Schema<ResetServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ResetServerResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ResetServerResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ResetServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ResetServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ResetServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ResetServerResponseAction: S.Schema<ResetServerResponseAction>;
export interface ResetServerResponse {
    action: ResetServerResponseAction;
}
export declare const ResetServerResponse: S.Schema<ResetServerResponse>;
export interface ResetServerPasswordRequest {
    /** ID of the Server. */
    id: number;
}
export declare const ResetServerPasswordRequest: S.Schema<ResetServerPasswordRequest>;
/** Status of the Action. */
export type ResetServerPasswordResponseActionStatus = "running" | "success" | "error";
export declare const ResetServerPasswordResponseActionStatus: any;
export type ResetServerPasswordResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ResetServerPasswordResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ResetServerPasswordResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ResetServerPasswordResponseActionResourcesList: S.Schema<ResetServerPasswordResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ResetServerPasswordResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ResetServerPasswordResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ResetServerPasswordResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ResetServerPasswordResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ResetServerPasswordResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ResetServerPasswordResponseAction: S.Schema<ResetServerPasswordResponseAction>;
export interface ResetServerPasswordResponse {
    /** Password that will be set for this Server once the Action succeeds. */
    root_password?: string | Redacted.Redacted<string>;
    action?: ResetServerPasswordResponseAction;
}
export declare const ResetServerPasswordResponse: S.Schema<ResetServerPasswordResponse>;
export interface ShutdownServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const ShutdownServerRequest: S.Schema<ShutdownServerRequest>;
/** Status of the Action. */
export type ShutdownServerResponseActionStatus = "running" | "success" | "error";
export declare const ShutdownServerResponseActionStatus: any;
export type ShutdownServerResponseActionResourcesItem = AddServerToPlacementGroupResponseActionResourcesItem;
export declare const ShutdownServerResponseActionResourcesItem: S.Schema<AddServerToPlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ShutdownServerResponseActionResourcesList = Array<AddServerToPlacementGroupResponseActionResourcesItem>;
export declare const ShutdownServerResponseActionResourcesList: S.Schema<ShutdownServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ShutdownServerResponseActionError = AddServerToPlacementGroupResponseActionError;
export declare const ShutdownServerResponseActionError: S.Schema<AddServerToPlacementGroupResponseActionError>;
export interface ShutdownServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ShutdownServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ShutdownServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddServerToPlacementGroupResponseActionError | null;
}
export declare const ShutdownServerResponseAction: S.Schema<ShutdownServerResponseAction>;
export interface ShutdownServerResponse {
    action: ShutdownServerResponseAction;
}
export declare const ShutdownServerResponse: S.Schema<ShutdownServerResponse>;
export type AddServerToPlacementGroupError = HetznerOpError;
/** Add a Server to a Placement Group Adds a Server to a Placement Group. Server must be powered off for this command to succeed. #### Operation specific errors */
export declare const addServerToPlacementGroup: API.OperationMethod<AddServerToPlacementGroupRequest, AddServerToPlacementGroupResponse, AddServerToPlacementGroupError, HetznerOpContext>;
export type AttachServerIsoError = HetznerOpError;
/** Attach an ISO to a Server Attaches an ISO to a Server. The Server will immediately see it as a new disk. An already attached ISO will automatically be detached before the new ISO is attached. Servers with attached ISOs have a modified boot order: They will try to boot from the ISO first before falling back to hard disk. */
export declare const attachServerIso: API.OperationMethod<AttachServerIsoRequest, AttachServerIsoResponse, AttachServerIsoError, HetznerOpContext>;
export type AttachServerToNetworkError = HetznerOpError;
/** Attach a Server to a Network Attaches a Server to a network. This will complement the fixed public Server interface by adding an additional ethernet interface to the Server which is connected to the specified network. The Server will get an IP auto assigned from a subnet of type `server` in the same `network_zone`. Using the `alias_ips` attribute you can also define one or more additional IPs to the Servers. Please note that you will have to configure these IPs by hand on your Server since only the primary IP will be given out by DHCP. #### Operation specific errors */
export declare const attachServerToNetwork: API.OperationMethod<AttachServerToNetworkRequest, AttachServerToNetworkResponse, AttachServerToNetworkError, HetznerOpContext>;
export type ChangeServerAliasIpsError = HetznerOpError;
/** Change alias IPs of a Network Changes the alias IPs of an already attached Network. Note that the existing aliases for the specified Network will be replaced with these provided in the request body. So if you want to add an alias IP, you have to provide the existing ones from the Network plus the new alias IP in the request body. */
export declare const changeServerAliasIps: API.OperationMethod<ChangeServerAliasIpsRequest, ChangeServerAliasIpsResponse, ChangeServerAliasIpsError, HetznerOpContext>;
export type ChangeServerDnsPtrError = HetznerOpError;
/** Change reverse DNS entry for this Server Changes the hostname that will appear when getting the hostname belonging to the primary IPs (IPv4 and IPv6) of this Server. Floating IPs assigned to the Server are not affected by this. */
export declare const changeServerDnsPtr: API.OperationMethod<ChangeServerDnsPtrRequest, ChangeServerDnsPtrResponse, ChangeServerDnsPtrError, HetznerOpContext>;
export type ChangeServerProtectionError = HetznerOpError;
/** Change Server Protection Changes the protection configuration of the Server. */
export declare const changeServerProtection: API.OperationMethod<ChangeServerProtectionRequest, ChangeServerProtectionResponse, ChangeServerProtectionError, HetznerOpContext>;
export type ChangeServerTypeError = HetznerOpError;
/** Change the Type of a Server Changes the type (Cores, RAM and disk sizes) of a Server. Server must be powered off for this command to succeed. This copies the content of its disk, and starts it again. You can only migrate to Server types with the same `storage_type` and equal or bigger disks. Shrinking disks is not possible as it might destroy data. If the disk gets upgraded, the Server type can not be downgraded any more. If you plan to downgrade the Server type, set `upgrade_disk` to `false`. #### Operation specific errors */
export declare const changeServerType: API.OperationMethod<ChangeServerTypeRequest, ChangeServerTypeResponse, ChangeServerTypeError, HetznerOpContext>;
export type CreateServerImageError = HetznerOpError;
/** Create Image from a Server Creates an Image (snapshot) from a Server by copying the contents of its disks. This creates a snapshot of the current state of the disk and copies it into an Image. If the Server is currently running you must make sure that its disk content is consistent. Otherwise, the created Image may not be readable. To make sure disk content is consistent, we recommend to shut down the Server prior to creating an Image. You can either create a `backup` Image that is bound to the Server and therefore will be deleted when the Server is deleted, or you can create a `snapshot` Image which is completely independent of the Server it was created from and will survive Server deletion. Backup Images are only available when the backup option is enabled for the Server. Snapshot Images are billed on a per GB basis. */
export declare const createServerImage: API.OperationMethod<CreateServerImageRequest, CreateServerImageResponse, CreateServerImageError, HetznerOpContext>;
export type DetachServerFromNetworkError = HetznerOpError;
/** Detach a Server from a Network Detaches a Server from a network. The interface for this network will vanish. */
export declare const detachServerFromNetwork: API.OperationMethod<DetachServerFromNetworkRequest, DetachServerFromNetworkResponse, DetachServerFromNetworkError, HetznerOpContext>;
export type DetachServerIsoError = HetznerOpError;
/** Detach an ISO from a Server Detaches an ISO from a Server. In case no ISO Image is attached to the Server, the status of the returned Action is immediately set to `success`. */
export declare const detachServerIso: API.OperationMethod<DetachServerIsoRequest, DetachServerIsoResponse, DetachServerIsoError, HetznerOpContext>;
export type DisableServerBackupError = HetznerOpError;
/** Disable Backups for a Server Disables the automatic backup option and deletes all existing Backups for a Server. No more additional charges for backups will be made. Caution: This immediately removes all existing backups for the Server! */
export declare const disableServerBackup: API.OperationMethod<DisableServerBackupRequest, DisableServerBackupResponse, DisableServerBackupError, HetznerOpContext>;
export type DisableServerRescueError = HetznerOpError;
/** Disable Rescue Mode for a Server Disables the Hetzner Rescue System for a Server. This makes a Server start from its disks on next reboot. Rescue Mode is automatically disabled when you first boot into it or if you do not use it for 60 minutes. Disabling rescue mode will not reboot your Server — you will have to do this yourself. */
export declare const disableServerRescue: API.OperationMethod<DisableServerRescueRequest, DisableServerRescueResponse, DisableServerRescueError, HetznerOpContext>;
export type EnableServerBackupError = HetznerOpError;
/** Enable and Configure Backups for a Server Enables and configures the automatic daily backup option for the Server. Enabling automatic backups will increase the price of the Server by 20%. In return, you will get seven slots where Images of type backup can be stored. Backups are automatically created daily. */
export declare const enableServerBackup: API.OperationMethod<EnableServerBackupRequest, EnableServerBackupResponse, EnableServerBackupError, HetznerOpContext>;
export type EnableServerRescueError = HetznerOpError;
/** Enable Rescue Mode for a Server Enable the Hetzner Rescue System for this Server. The next time a Server with enabled rescue mode boots it will start a special minimal Linux distribution designed for repair and reinstall. In case a Server cannot boot on its own you can use this to access a Server’s disks. Rescue Mode is automatically disabled when you first boot into it or if you do not use it for 60 minutes. Enabling rescue mode will not [reboot](https://docs.hetzner.cloud/#server-actions-soft-reboot-a-server) your Server — you will have to do this yourself. */
export declare const enableServerRescue: API.OperationMethod<EnableServerRescueRequest, EnableServerRescueResponse, EnableServerRescueError, HetznerOpContext>;
export type GetServersActionError = HetznerOpError;
/** Get an Action Returns a specific Action object. */
export declare const getServersAction: API.OperationMethod<GetServersActionRequest, GetServersActionResponse, GetServersActionError, HetznerOpContext>;
export type ListServerActionsError = HetznerOpError;
/** List Actions for a Server Returns all Action objects for a Server. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter. */
export declare const listServerActions: API.PaginatedOperationMethod<ListServerActionsRequest, ListServerActionsResponse, ListServerActionsError, HetznerOpContext, ListServerActionsResponseActionsItem>;
export type ListServersActionsError = HetznerOpError;
/** List Actions Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` and `id` parameter. */
export declare const listServersActions: API.PaginatedOperationMethod<ListServersActionsRequest, ListServersActionsResponse, ListServersActionsError, HetznerOpContext, ListServersActionsResponseActionsItem>;
export type PoweroffServerError = HetznerOpError;
/** Power off a Server Cuts power to the Server. This forcefully stops it without giving the Server operating system time to gracefully stop. May lead to data loss, equivalent to pulling the power cord. Power off should only be used when shutdown does not work. */
export declare const poweroffServer: API.OperationMethod<PoweroffServerRequest, PoweroffServerResponse, PoweroffServerError, HetznerOpContext>;
export type PoweronServerError = HetznerOpError;
/** Power on a Server Starts a Server by turning its power on. */
export declare const poweronServer: API.OperationMethod<PoweronServerRequest, PoweronServerResponse, PoweronServerError, HetznerOpContext>;
export type RebootServerError = HetznerOpError;
/** Soft-reboot a Server Reboots a Server gracefully by sending an ACPI request. The Server operating system must support ACPI and react to the request, otherwise the Server will not reboot. */
export declare const rebootServer: API.OperationMethod<RebootServerRequest, RebootServerResponse, RebootServerError, HetznerOpContext>;
export type RebuildServerError = HetznerOpError;
/** Rebuild a Server from an Image Rebuilds a Server overwriting its disk with the content of an Image, thereby **destroying all data** on the target Server The Image can either be one you have created earlier (`backup` or `snapshot` Image) or it can be a completely fresh `system` Image provided by us. You can get a list of all available Images with `GET /images`. Your Server will automatically be powered off before the rebuild command executes. */
export declare const rebuildServer: API.OperationMethod<RebuildServerRequest, RebuildServerResponse, RebuildServerError, HetznerOpContext>;
export type RemoveServerFromPlacementGroupError = HetznerOpError;
/** Remove from Placement Group Removes a Server from a Placement Group. */
export declare const removeServerFromPlacementGroup: API.OperationMethod<RemoveServerFromPlacementGroupRequest, RemoveServerFromPlacementGroupResponse, RemoveServerFromPlacementGroupError, HetznerOpContext>;
export type RequestServerConsoleError = HetznerOpError;
/** Request Console for a Server Requests credentials for remote access via VNC over websocket to keyboard, monitor, and mouse for a Server. The provided URL is valid for 1 minute, after this period a new url needs to be created to connect to the Server. How long the connection is open after the initial connect is not subject to this timeout. */
export declare const requestServerConsole: API.OperationMethod<RequestServerConsoleRequest, RequestServerConsoleResponse, RequestServerConsoleError, HetznerOpContext>;
export type ResetServerError = HetznerOpError;
/** Reset a Server Cuts power to a Server and starts it again. This forcefully stops it without giving the Server operating system time to gracefully stop. This may lead to data loss, it’s equivalent to pulling the power cord and plugging it in again. Reset should only be used when reboot does not work. */
export declare const resetServer: API.OperationMethod<ResetServerRequest, ResetServerResponse, ResetServerError, HetznerOpContext>;
export type ResetServerPasswordError = HetznerOpError;
/** Reset root Password of a Server Resets the root password. Only works for Linux systems that are running the qemu guest agent. Server must be powered on (status `running`) in order for this operation to succeed. This will generate a new password for this Server and return it. If this does not succeed you can use the rescue system to netboot the Server and manually change your Server password by hand. */
export declare const resetServerPassword: API.OperationMethod<ResetServerPasswordRequest, ResetServerPasswordResponse, ResetServerPasswordError, HetznerOpContext>;
export type ShutdownServerError = HetznerOpError;
/** Shutdown a Server Shuts down a Server gracefully by sending an ACPI shutdown request. The Server operating system must support ACPI and react to the request, otherwise the Server will not shut down. Please note that the `action` status in this case only reflects whether the action was sent to the server. It does not mean that the server actually shut down successfully. If you need to ensure that the server is off, use the `poweroff` action. */
export declare const shutdownServer: API.OperationMethod<ShutdownServerRequest, ShutdownServerResponse, ShutdownServerError, HetznerOpContext>;
//# sourceMappingURL=server_actions.d.ts.map