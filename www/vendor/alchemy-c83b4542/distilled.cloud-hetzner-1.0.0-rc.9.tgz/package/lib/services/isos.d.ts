import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetIsoRequest {
    /** ID of the ISO. */
    id: number;
}
export declare const GetIsoRequest: S.Schema<GetIsoRequest>;
/** Type of the ISO. */
export type GetIsoResponseIsoType = "public" | "private";
export declare const GetIsoResponseIsoType: any;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export interface GetIsoResponseIsoDeprecation {
    /** Date of the deprecated resource removal. Once this date is reached, the resource will not be returned by resource type "list" endpoint, and the resource can not be used to create new resources. For example, if this is an image, you can not create new servers with this image after the mentioned date. */
    unavailable_after: string;
    /** Date of the deprecation announcement. */
    announced: string;
}
export declare const GetIsoResponseIsoDeprecation: S.Schema<GetIsoResponseIsoDeprecation>;
/** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
export type GetIsoResponseIsoArchitecture = "x86" | "arm";
export declare const GetIsoResponseIsoArchitecture: any;
export interface GetIsoResponseIso {
    /** ID of the [ISO](#tag/isos). */
    id: number;
    /** Unique identifier of the ISO. Only set for public ISOs. */
    name: string | null;
    /** Description of the ISO. */
    description: string;
    /** Type of the ISO. */
    type: GetIsoResponseIsoType | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: GetIsoResponseIsoDeprecation | null;
    /** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
    architecture: GetIsoResponseIsoArchitecture | null;
}
export declare const GetIsoResponseIso: S.Schema<GetIsoResponseIso>;
export interface GetIsoResponse {
    iso: GetIsoResponseIso;
}
export declare const GetIsoResponse: S.Schema<GetIsoResponse>;
/** CPU architecture of the Resource. */
export type ListIsosRequestArchitecture = "x86" | "arm";
export declare const ListIsosRequestArchitecture: any;
export interface ListIsosRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by cpu architecture. The response will only contain the resources with the specified cpu architecture. */
    architecture?: ListIsosRequestArchitecture | (string & {});
    /** Include Images with wildcard architecture (architecture is null). Architecture filter must be specified. */
    include_architecture_wildcard?: boolean;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListIsosRequest: S.Schema<ListIsosRequest>;
/** Type of the ISO. */
export type ListIsosResponseIsosItemType = "public" | "private";
export declare const ListIsosResponseIsosItemType: any;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type ListIsosResponseIsosItemDeprecation = GetIsoResponseIsoDeprecation;
export declare const ListIsosResponseIsosItemDeprecation: S.Schema<GetIsoResponseIsoDeprecation>;
/** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
export type ListIsosResponseIsosItemArchitecture = "x86" | "arm";
export declare const ListIsosResponseIsosItemArchitecture: any;
export interface ListIsosResponseIsosItem {
    /** ID of the [ISO](#tag/isos). */
    id: number;
    /** Unique identifier of the ISO. Only set for public ISOs. */
    name: string | null;
    /** Description of the ISO. */
    description: string;
    /** Type of the ISO. */
    type: ListIsosResponseIsosItemType | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: GetIsoResponseIsoDeprecation | null;
    /** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
    architecture: ListIsosResponseIsosItemArchitecture | null;
}
export declare const ListIsosResponseIsosItem: S.Schema<ListIsosResponseIsosItem>;
export type ListIsosResponseIsosList = Array<ListIsosResponseIsosItem>;
export declare const ListIsosResponseIsosList: S.Schema<ListIsosResponseIsosList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListIsosResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListIsosResponseMetaPagination: S.Schema<ListIsosResponseMetaPagination>;
export interface ListIsosResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListIsosResponseMetaPagination;
}
export declare const ListIsosResponseMeta: S.Schema<ListIsosResponseMeta>;
export interface ListIsosResponse {
    isos: ListIsosResponseIsosList;
    meta: ListIsosResponseMeta;
}
export declare const ListIsosResponse: S.Schema<ListIsosResponse>;
export type GetIsoError = HetznerOpError;
/** Get an ISO Returns a specific ISO object. */
export declare const getIso: API.OperationMethod<GetIsoRequest, GetIsoResponse, GetIsoError, HetznerOpContext>;
export type ListIsosError = HetznerOpError;
/** List ISOs Returns all available ISO objects. */
export declare const listIsos: API.PaginatedOperationMethod<ListIsosRequest, ListIsosResponse, ListIsosError, HetznerOpContext, ListIsosResponseIsosItem>;
//# sourceMappingURL=isos.d.ts.map