import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface AddNetworkRouteRequest {
    /** ID of the Network. */
    id: number;
    /** Destination network or host of the route. Packages addressed for IPs matching the destination IP prefix will be send to the specified gateway. Must be one of * private IPv4 ranges of RFC1918 * or `0.0.0.0/0`. Must not overlap with * an existing ip_range in any subnets * or with any destinations in other routes * or with `172.31.1.1`. `172.31.1.1` is being used as a gateway for the public network interface of [Servers](#tag/servers). */
    destination: string;
    /** Gateway of the route. Packages addressed for the specified destination will be send to this IP address. Cannot be * the first IP of the networks ip_range, * an IP behind a vSwitch or * `172.31.1.1`. `172.31.1.1` is being used as a gateway for the public network interface of [Servers](#tag/servers). */
    gateway: string;
}
export declare const AddNetworkRouteRequest: S.Schema<AddNetworkRouteRequest>;
/** Status of the Action. */
export type AddNetworkRouteResponseActionStatus = "running" | "success" | "error";
export declare const AddNetworkRouteResponseActionStatus: any;
export interface AddNetworkRouteResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AddNetworkRouteResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AddNetworkRouteResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const AddNetworkRouteResponseActionResourcesList: S.Schema<AddNetworkRouteResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AddNetworkRouteResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AddNetworkRouteResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface AddNetworkRouteResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AddNetworkRouteResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AddNetworkRouteResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const AddNetworkRouteResponseAction: S.Schema<AddNetworkRouteResponseAction>;
export interface AddNetworkRouteResponse {
    action: AddNetworkRouteResponseAction;
}
export declare const AddNetworkRouteResponse: S.Schema<AddNetworkRouteResponse>;
/** Type of subnet. */
export type AddNetworkSubnetRequestType = "cloud" | "server" | "vswitch";
export declare const AddNetworkSubnetRequestType: any;
export interface AddNetworkSubnetRequest {
    /** ID of the Network. */
    id: number;
    /** Type of subnet. */
    type: AddNetworkSubnetRequestType | (string & {});
    /** IP range of the subnet. Uses CIDR notation. Must be a subnet of the parent [Networks](#tag/networks) `ip_range`. Must not overlap with any other subnets or with any destinations in routes. Minimum network size is /30. We highly recommend that you pick a larger subnet with a /24 netmask. */
    ip_range?: string;
    /** Name of the [Network Zone](#tag/network-zones). The [Location](#tag/locations) contains the `network_zone` it belongs to. */
    network_zone: string;
    /** ID of the robot vSwitch. Must be supplied if the subnet is of type `vswitch`. */
    vswitch_id?: number;
}
export declare const AddNetworkSubnetRequest: S.Schema<AddNetworkSubnetRequest>;
/** Status of the Action. */
export type AddNetworkSubnetResponseActionStatus = "running" | "success" | "error";
export declare const AddNetworkSubnetResponseActionStatus: any;
export type AddNetworkSubnetResponseActionResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const AddNetworkSubnetResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AddNetworkSubnetResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const AddNetworkSubnetResponseActionResourcesList: S.Schema<AddNetworkSubnetResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type AddNetworkSubnetResponseActionError = AddNetworkRouteResponseActionError;
export declare const AddNetworkSubnetResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface AddNetworkSubnetResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AddNetworkSubnetResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AddNetworkSubnetResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const AddNetworkSubnetResponseAction: S.Schema<AddNetworkSubnetResponseAction>;
export interface AddNetworkSubnetResponse {
    action: AddNetworkSubnetResponseAction;
}
export declare const AddNetworkSubnetResponse: S.Schema<AddNetworkSubnetResponse>;
export interface ChangeNetworkIpRangeRequest {
    /** ID of the Network. */
    id: number;
    /** IP range of the [Network](#tag/networks). Uses CIDR notation. Must span all included subnets. Must be one of the private IPv4 ranges of RFC1918. Minimum network size is /24. We highly recommend that you pick a larger [Network](#tag/networks) with a /16 netmask. */
    ip_range: string;
}
export declare const ChangeNetworkIpRangeRequest: S.Schema<ChangeNetworkIpRangeRequest>;
/** Status of the Action. */
export type ChangeNetworkIpRangeResponseActionStatus = "running" | "success" | "error";
export declare const ChangeNetworkIpRangeResponseActionStatus: any;
export type ChangeNetworkIpRangeResponseActionResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const ChangeNetworkIpRangeResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeNetworkIpRangeResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const ChangeNetworkIpRangeResponseActionResourcesList: S.Schema<ChangeNetworkIpRangeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeNetworkIpRangeResponseActionError = AddNetworkRouteResponseActionError;
export declare const ChangeNetworkIpRangeResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface ChangeNetworkIpRangeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeNetworkIpRangeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeNetworkIpRangeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const ChangeNetworkIpRangeResponseAction: S.Schema<ChangeNetworkIpRangeResponseAction>;
export interface ChangeNetworkIpRangeResponse {
    action: ChangeNetworkIpRangeResponseAction;
}
export declare const ChangeNetworkIpRangeResponse: S.Schema<ChangeNetworkIpRangeResponse>;
export interface ChangeNetworkProtectionRequest {
    /** ID of the Network. */
    id: number;
    /** Delete protection setting. If true, prevents the [Network](#tag/networks) from being deleted. */
    delete?: boolean;
}
export declare const ChangeNetworkProtectionRequest: S.Schema<ChangeNetworkProtectionRequest>;
/** Status of the Action. */
export type ChangeNetworkProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeNetworkProtectionResponseActionStatus: any;
export type ChangeNetworkProtectionResponseActionResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const ChangeNetworkProtectionResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeNetworkProtectionResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const ChangeNetworkProtectionResponseActionResourcesList: S.Schema<ChangeNetworkProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeNetworkProtectionResponseActionError = AddNetworkRouteResponseActionError;
export declare const ChangeNetworkProtectionResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface ChangeNetworkProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeNetworkProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeNetworkProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const ChangeNetworkProtectionResponseAction: S.Schema<ChangeNetworkProtectionResponseAction>;
export interface ChangeNetworkProtectionResponse {
    action: ChangeNetworkProtectionResponseAction;
}
export declare const ChangeNetworkProtectionResponse: S.Schema<ChangeNetworkProtectionResponse>;
export interface DeleteNetworkRouteRequest {
    /** ID of the Network. */
    id: number;
    /** Destination network or host of the route. Packages addressed for IPs matching the destination IP prefix will be send to the specified gateway. Must be one of * private IPv4 ranges of RFC1918 * or `0.0.0.0/0`. Must not overlap with * an existing ip_range in any subnets * or with any destinations in other routes * or with `172.31.1.1`. `172.31.1.1` is being used as a gateway for the public network interface of [Servers](#tag/servers). */
    destination: string;
    /** Gateway of the route. Packages addressed for the specified destination will be send to this IP address. Cannot be * the first IP of the networks ip_range, * an IP behind a vSwitch or * `172.31.1.1`. `172.31.1.1` is being used as a gateway for the public network interface of [Servers](#tag/servers). */
    gateway: string;
}
export declare const DeleteNetworkRouteRequest: S.Schema<DeleteNetworkRouteRequest>;
/** Status of the Action. */
export type DeleteNetworkRouteResponseActionStatus = "running" | "success" | "error";
export declare const DeleteNetworkRouteResponseActionStatus: any;
export type DeleteNetworkRouteResponseActionResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const DeleteNetworkRouteResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DeleteNetworkRouteResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const DeleteNetworkRouteResponseActionResourcesList: S.Schema<DeleteNetworkRouteResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DeleteNetworkRouteResponseActionError = AddNetworkRouteResponseActionError;
export declare const DeleteNetworkRouteResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface DeleteNetworkRouteResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DeleteNetworkRouteResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DeleteNetworkRouteResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const DeleteNetworkRouteResponseAction: S.Schema<DeleteNetworkRouteResponseAction>;
export interface DeleteNetworkRouteResponse {
    action: DeleteNetworkRouteResponseAction;
}
export declare const DeleteNetworkRouteResponse: S.Schema<DeleteNetworkRouteResponse>;
export interface DeleteNetworkSubnetRequest {
    /** ID of the Network. */
    id: number;
    /** IP range in CIDR block notation of the subnet to delete. */
    ip_range: string;
}
export declare const DeleteNetworkSubnetRequest: S.Schema<DeleteNetworkSubnetRequest>;
/** Status of the Action. */
export type DeleteNetworkSubnetResponseActionStatus = "running" | "success" | "error";
export declare const DeleteNetworkSubnetResponseActionStatus: any;
export type DeleteNetworkSubnetResponseActionResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const DeleteNetworkSubnetResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DeleteNetworkSubnetResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const DeleteNetworkSubnetResponseActionResourcesList: S.Schema<DeleteNetworkSubnetResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DeleteNetworkSubnetResponseActionError = AddNetworkRouteResponseActionError;
export declare const DeleteNetworkSubnetResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface DeleteNetworkSubnetResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DeleteNetworkSubnetResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DeleteNetworkSubnetResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const DeleteNetworkSubnetResponseAction: S.Schema<DeleteNetworkSubnetResponseAction>;
export interface DeleteNetworkSubnetResponse {
    action: DeleteNetworkSubnetResponseAction;
}
export declare const DeleteNetworkSubnetResponse: S.Schema<DeleteNetworkSubnetResponse>;
export interface GetNetworksActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetNetworksActionRequest: S.Schema<GetNetworksActionRequest>;
/** Status of the Action. */
export type GetNetworksActionResponseActionStatus = "running" | "success" | "error";
export declare const GetNetworksActionResponseActionStatus: any;
export type GetNetworksActionResponseActionResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const GetNetworksActionResponseActionResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetNetworksActionResponseActionResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const GetNetworksActionResponseActionResourcesList: S.Schema<GetNetworksActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetNetworksActionResponseActionError = AddNetworkRouteResponseActionError;
export declare const GetNetworksActionResponseActionError: S.Schema<AddNetworkRouteResponseActionError>;
export interface GetNetworksActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetNetworksActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetNetworksActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const GetNetworksActionResponseAction: S.Schema<GetNetworksActionResponseAction>;
export interface GetNetworksActionResponse {
    action: GetNetworksActionResponseAction;
}
export declare const GetNetworksActionResponse: S.Schema<GetNetworksActionResponse>;
export type ListNetworkActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListNetworkActionsRequestSortItem: any;
export type ListNetworkActionsRequestSortList = Array<ListNetworkActionsRequestSortItem | (string & {})>;
export declare const ListNetworkActionsRequestSortList: S.Schema<ListNetworkActionsRequestSortList>;
/** Status of the Action. */
export type ListNetworkActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListNetworkActionsRequestStatusItem: any;
export type ListNetworkActionsRequestStatusList = Array<ListNetworkActionsRequestStatusItem | (string & {})>;
export declare const ListNetworkActionsRequestStatusList: S.Schema<ListNetworkActionsRequestStatusList>;
export interface ListNetworkActionsRequest {
    /** ID of the Network. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListNetworkActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListNetworkActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListNetworkActionsRequest: S.Schema<ListNetworkActionsRequest>;
/** Status of the Action. */
export type ListNetworkActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListNetworkActionsResponseActionsItemStatus: any;
export type ListNetworkActionsResponseActionsItemResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const ListNetworkActionsResponseActionsItemResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListNetworkActionsResponseActionsItemResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const ListNetworkActionsResponseActionsItemResourcesList: S.Schema<ListNetworkActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListNetworkActionsResponseActionsItemError = AddNetworkRouteResponseActionError;
export declare const ListNetworkActionsResponseActionsItemError: S.Schema<AddNetworkRouteResponseActionError>;
export interface ListNetworkActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListNetworkActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListNetworkActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const ListNetworkActionsResponseActionsItem: S.Schema<ListNetworkActionsResponseActionsItem>;
export type ListNetworkActionsResponseActionsList = Array<ListNetworkActionsResponseActionsItem>;
export declare const ListNetworkActionsResponseActionsList: S.Schema<ListNetworkActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListNetworkActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListNetworkActionsResponseMetaPagination: S.Schema<ListNetworkActionsResponseMetaPagination>;
export interface ListNetworkActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListNetworkActionsResponseMetaPagination;
}
export declare const ListNetworkActionsResponseMeta: S.Schema<ListNetworkActionsResponseMeta>;
export interface ListNetworkActionsResponse {
    actions: ListNetworkActionsResponseActionsList;
    meta: ListNetworkActionsResponseMeta;
}
export declare const ListNetworkActionsResponse: S.Schema<ListNetworkActionsResponse>;
export type ListNetworksActionsRequestIdList = Array<number>;
export declare const ListNetworksActionsRequestIdList: S.Schema<ListNetworksActionsRequestIdList>;
export type ListNetworksActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListNetworksActionsRequestSortItem: any;
export type ListNetworksActionsRequestSortList = Array<ListNetworksActionsRequestSortItem | (string & {})>;
export declare const ListNetworksActionsRequestSortList: S.Schema<ListNetworksActionsRequestSortList>;
/** Status of the Action. */
export type ListNetworksActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListNetworksActionsRequestStatusItem: any;
export type ListNetworksActionsRequestStatusList = Array<ListNetworksActionsRequestStatusItem | (string & {})>;
export declare const ListNetworksActionsRequestStatusList: S.Schema<ListNetworksActionsRequestStatusList>;
export interface ListNetworksActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListNetworksActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListNetworksActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListNetworksActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListNetworksActionsRequest: S.Schema<ListNetworksActionsRequest>;
/** Status of the Action. */
export type ListNetworksActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListNetworksActionsResponseActionsItemStatus: any;
export type ListNetworksActionsResponseActionsItemResourcesItem = AddNetworkRouteResponseActionResourcesItem;
export declare const ListNetworksActionsResponseActionsItemResourcesItem: S.Schema<AddNetworkRouteResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListNetworksActionsResponseActionsItemResourcesList = Array<AddNetworkRouteResponseActionResourcesItem>;
export declare const ListNetworksActionsResponseActionsItemResourcesList: S.Schema<ListNetworksActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListNetworksActionsResponseActionsItemError = AddNetworkRouteResponseActionError;
export declare const ListNetworksActionsResponseActionsItemError: S.Schema<AddNetworkRouteResponseActionError>;
export interface ListNetworksActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListNetworksActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListNetworksActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddNetworkRouteResponseActionError | null;
}
export declare const ListNetworksActionsResponseActionsItem: S.Schema<ListNetworksActionsResponseActionsItem>;
export type ListNetworksActionsResponseActionsList = Array<ListNetworksActionsResponseActionsItem>;
export declare const ListNetworksActionsResponseActionsList: S.Schema<ListNetworksActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListNetworksActionsResponseMetaPagination = ListNetworkActionsResponseMetaPagination;
export declare const ListNetworksActionsResponseMetaPagination: S.Schema<ListNetworkActionsResponseMetaPagination>;
export type ListNetworksActionsResponseMeta = ListNetworkActionsResponseMeta;
export declare const ListNetworksActionsResponseMeta: S.Schema<ListNetworkActionsResponseMeta>;
export interface ListNetworksActionsResponse {
    actions: ListNetworksActionsResponseActionsList;
    meta: ListNetworkActionsResponseMeta;
}
export declare const ListNetworksActionsResponse: S.Schema<ListNetworksActionsResponse>;
export type AddNetworkRouteError = HetznerOpError;
/** Add a route to a Network Adds a route entry to a [Network](#tag/networks). If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const addNetworkRoute: API.OperationMethod<AddNetworkRouteRequest, AddNetworkRouteResponse, AddNetworkRouteError, HetznerOpContext>;
export type AddNetworkSubnetError = HetznerOpError;
/** Add a subnet to a Network Adds a new subnet to the [Network](#tag/networks). If the subnet `ip_range` is not provided, the first available `/24` IP range will be used. If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const addNetworkSubnet: API.OperationMethod<AddNetworkSubnetRequest, AddNetworkSubnetResponse, AddNetworkSubnetError, HetznerOpContext>;
export type ChangeNetworkIpRangeError = HetznerOpError;
/** Change IP range of a Network Changes the IP range of a [Network](#tag/networks). The following restrictions apply to changing the IP range: - IP ranges can only be extended and never shrunk. - IPs can only be added to the end of the existing range, therefore only the netmask is allowed to be changed. To update the routes on the connected [Servers](#tag/servers), they need to be rebooted or the routes to be updated manually. For example if the [Network](#tag/networks) has a range of `10.0.0.0/16` to extend it the new range has to start with the IP `10.0.0.0` as well. The netmask `/16` can be changed to a smaller one then `16` therefore increasing the IP range. A valid entry would be `10.0.0.0/15`, `10.0.0.0/14` or `10.0.0.0/13` and so on. If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const changeNetworkIpRange: API.OperationMethod<ChangeNetworkIpRangeRequest, ChangeNetworkIpRangeResponse, ChangeNetworkIpRangeError, HetznerOpContext>;
export type ChangeNetworkProtectionError = HetznerOpError;
/** Change Network Protection Changes the protection settings of a [Network](#tag/networks). If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const changeNetworkProtection: API.OperationMethod<ChangeNetworkProtectionRequest, ChangeNetworkProtectionResponse, ChangeNetworkProtectionError, HetznerOpContext>;
export type DeleteNetworkRouteError = HetznerOpError;
/** Delete a route from a Network Delete a route entry from a [Network](#tag/networks). If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const deleteNetworkRoute: API.OperationMethod<DeleteNetworkRouteRequest, DeleteNetworkRouteResponse, DeleteNetworkRouteError, HetznerOpContext>;
export type DeleteNetworkSubnetError = HetznerOpError;
/** Delete a subnet from a Network Deletes a single subnet entry from a [Network](#tag/networks). Subnets containing attached resources can not be deleted, they must be detached beforehand. If a change is currently being performed on this [Network](#tag/networks), a error response with code `conflict` will be returned. */
export declare const deleteNetworkSubnet: API.OperationMethod<DeleteNetworkSubnetRequest, DeleteNetworkSubnetResponse, DeleteNetworkSubnetError, HetznerOpContext>;
export type GetNetworksActionError = HetznerOpError;
/** Get an Action Returns a single [Action](#tag/actions). */
export declare const getNetworksAction: API.OperationMethod<GetNetworksActionRequest, GetNetworksActionResponse, GetNetworksActionError, HetznerOpContext>;
export type ListNetworkActionsError = HetznerOpError;
/** List Actions for a Network Lists [Actions](#tag/actions) for a [Network](#tag/networks). Use the provided URI parameters to modify the result. */
export declare const listNetworkActions: API.PaginatedOperationMethod<ListNetworkActionsRequest, ListNetworkActionsResponse, ListNetworkActionsError, HetznerOpContext, ListNetworkActionsResponseActionsItem>;
export type ListNetworksActionsError = HetznerOpError;
/** List Actions Lists multiple [Actions](#tag/actions). Use the provided URI parameters to modify the result. */
export declare const listNetworksActions: API.PaginatedOperationMethod<ListNetworksActionsRequest, ListNetworksActionsResponse, ListNetworksActionsError, HetznerOpContext, ListNetworksActionsResponseActionsItem>;
//# sourceMappingURL=network_actions.d.ts.map