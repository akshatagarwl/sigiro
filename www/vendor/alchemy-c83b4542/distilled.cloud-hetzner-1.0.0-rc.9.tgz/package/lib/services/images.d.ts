import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface DeleteImageRequest {
    /** ID of the Image. */
    id: number;
}
export declare const DeleteImageRequest: S.Schema<DeleteImageRequest>;
export interface DeleteImageResponse {
}
export declare const DeleteImageResponse: S.Schema<DeleteImageResponse>;
export interface GetImageRequest {
    /** ID of the Image. */
    id: number;
}
export declare const GetImageRequest: S.Schema<GetImageRequest>;
/** Type of the Image. */
export type GetImageResponseImageType = "system" | "app" | "snapshot" | "backup";
export declare const GetImageResponseImageType: any;
/** Status of the Image. */
export type GetImageResponseImageStatus = "available" | "creating" | "unavailable";
export declare const GetImageResponseImageStatus: any;
/** Information about the Server the Image was created from. */
export interface GetImageResponseImageCreatedFrom {
    /** ID of the Server the Image was created from. */
    id: number;
    /** Server name at the time the Image was created. */
    name: string;
}
export declare const GetImageResponseImageCreatedFrom: S.Schema<GetImageResponseImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type GetImageResponseImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const GetImageResponseImageOsFlavor: any;
/** Protection configuration for the Resource. */
export interface GetImageResponseImageProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const GetImageResponseImageProtection: S.Schema<GetImageResponseImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetImageResponseImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetImageResponseImageLabelsMap: S.Schema<GetImageResponseImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type GetImageResponseImageArchitecture = "x86" | "arm";
export declare const GetImageResponseImageArchitecture: any;
export interface GetImageResponseImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: GetImageResponseImageType;
    /** Status of the Image. */
    status: GetImageResponseImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: GetImageResponseImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: GetImageResponseImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: GetImageResponseImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetImageResponseImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: GetImageResponseImageArchitecture;
}
export declare const GetImageResponseImage: S.Schema<GetImageResponseImage>;
export interface GetImageResponse {
    image?: GetImageResponseImage;
}
export declare const GetImageResponse: S.Schema<GetImageResponse>;
export type ListImagesRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListImagesRequestSortItem: any;
export type ListImagesRequestSortList = Array<ListImagesRequestSortItem | (string & {})>;
export declare const ListImagesRequestSortList: S.Schema<ListImagesRequestSortList>;
/** Type of the Image. */
export type ListImagesRequestTypeItem = "system" | "app" | "snapshot" | "backup";
export declare const ListImagesRequestTypeItem: any;
export type ListImagesRequestTypeList = Array<ListImagesRequestTypeItem | (string & {})>;
export declare const ListImagesRequestTypeList: S.Schema<ListImagesRequestTypeList>;
/** Status of the Image. */
export type ListImagesRequestStatusItem = "available" | "creating" | "unavailable";
export declare const ListImagesRequestStatusItem: any;
export type ListImagesRequestStatusList = Array<ListImagesRequestStatusItem | (string & {})>;
export declare const ListImagesRequestStatusList: S.Schema<ListImagesRequestStatusList>;
export type ListImagesRequestBoundToList = Array<string>;
export declare const ListImagesRequestBoundToList: S.Schema<ListImagesRequestBoundToList>;
/** CPU architecture of the Resource. */
export type ListImagesRequestArchitecture = "x86" | "arm";
export declare const ListImagesRequestArchitecture: any;
export interface ListImagesRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListImagesRequestSortList;
    /** Filter resources by type. May be used multiple times. The response will only contain the resources with the specified type. */
    type?: ListImagesRequestTypeList;
    /** Filter resources by status. May be used multiple times. The response will only contain the resources with the specified status. */
    status?: ListImagesRequestStatusList;
    /** Filter Images by their linked Server ID. May be used multiple times. Only available for Images of type `backup`. */
    bound_to?: ListImagesRequestBoundToList;
    /** Include deprecated Images. */
    include_deprecated?: boolean;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Filter resources by cpu architecture. The response will only contain the resources with the specified cpu architecture. */
    architecture?: ListImagesRequestArchitecture | (string & {});
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListImagesRequest: S.Schema<ListImagesRequest>;
/** Type of the Image. */
export type ListImagesResponseImagesItemType = "system" | "app" | "snapshot" | "backup";
export declare const ListImagesResponseImagesItemType: any;
/** Status of the Image. */
export type ListImagesResponseImagesItemStatus = "available" | "creating" | "unavailable";
export declare const ListImagesResponseImagesItemStatus: any;
/** Information about the Server the Image was created from. */
export type ListImagesResponseImagesItemCreatedFrom = GetImageResponseImageCreatedFrom;
export declare const ListImagesResponseImagesItemCreatedFrom: S.Schema<GetImageResponseImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type ListImagesResponseImagesItemOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const ListImagesResponseImagesItemOsFlavor: any;
/** Protection configuration for the Resource. */
export type ListImagesResponseImagesItemProtection = GetImageResponseImageProtection;
export declare const ListImagesResponseImagesItemProtection: S.Schema<GetImageResponseImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListImagesResponseImagesItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListImagesResponseImagesItemLabelsMap: S.Schema<ListImagesResponseImagesItemLabelsMap>;
/** CPU architecture compatible with the Image. */
export type ListImagesResponseImagesItemArchitecture = "x86" | "arm";
export declare const ListImagesResponseImagesItemArchitecture: any;
export interface ListImagesResponseImagesItem {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: ListImagesResponseImagesItemType;
    /** Status of the Image. */
    status: ListImagesResponseImagesItemStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: GetImageResponseImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: ListImagesResponseImagesItemOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: GetImageResponseImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListImagesResponseImagesItemLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: ListImagesResponseImagesItemArchitecture;
}
export declare const ListImagesResponseImagesItem: S.Schema<ListImagesResponseImagesItem>;
export type ListImagesResponseImagesList = Array<ListImagesResponseImagesItem>;
export declare const ListImagesResponseImagesList: S.Schema<ListImagesResponseImagesList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListImagesResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListImagesResponseMetaPagination: S.Schema<ListImagesResponseMetaPagination>;
export interface ListImagesResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListImagesResponseMetaPagination;
}
export declare const ListImagesResponseMeta: S.Schema<ListImagesResponseMeta>;
export interface ListImagesResponse {
    images: ListImagesResponseImagesList;
    meta: ListImagesResponseMeta;
}
export declare const ListImagesResponse: S.Schema<ListImagesResponse>;
/** Destination Image type to convert to. */
export type UpdateImageRequestType = "snapshot";
export declare const UpdateImageRequestType: any;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateImageRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateImageRequestLabelsMap: S.Schema<UpdateImageRequestLabelsMap>;
export interface UpdateImageRequest {
    /** ID of the Image. */
    id: number;
    /** New description of Image. */
    description?: string;
    /** Destination Image type to convert to. */
    type?: UpdateImageRequestType | (string & {});
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateImageRequestLabelsMap;
}
export declare const UpdateImageRequest: S.Schema<UpdateImageRequest>;
/** Type of the Image. */
export type UpdateImageResponseImageType = "system" | "app" | "snapshot" | "backup";
export declare const UpdateImageResponseImageType: any;
/** Status of the Image. */
export type UpdateImageResponseImageStatus = "available" | "creating" | "unavailable";
export declare const UpdateImageResponseImageStatus: any;
/** Information about the Server the Image was created from. */
export type UpdateImageResponseImageCreatedFrom = GetImageResponseImageCreatedFrom;
export declare const UpdateImageResponseImageCreatedFrom: S.Schema<GetImageResponseImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type UpdateImageResponseImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const UpdateImageResponseImageOsFlavor: any;
/** Protection configuration for the Resource. */
export type UpdateImageResponseImageProtection = GetImageResponseImageProtection;
export declare const UpdateImageResponseImageProtection: S.Schema<GetImageResponseImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateImageResponseImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateImageResponseImageLabelsMap: S.Schema<UpdateImageResponseImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type UpdateImageResponseImageArchitecture = "x86" | "arm";
export declare const UpdateImageResponseImageArchitecture: any;
export interface UpdateImageResponseImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: UpdateImageResponseImageType;
    /** Status of the Image. */
    status: UpdateImageResponseImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: GetImageResponseImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: UpdateImageResponseImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: GetImageResponseImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateImageResponseImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: UpdateImageResponseImageArchitecture;
}
export declare const UpdateImageResponseImage: S.Schema<UpdateImageResponseImage>;
export interface UpdateImageResponse {
    image?: UpdateImageResponseImage;
}
export declare const UpdateImageResponse: S.Schema<UpdateImageResponse>;
export type DeleteImageError = HetznerOpError;
/** Delete an Image Deletes an Image. Only Images of type `snapshot` and `backup` can be deleted. */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest, DeleteImageResponse, DeleteImageError, HetznerOpContext>;
export type GetImageError = HetznerOpError;
/** Get an Image Returns a specific Image object. */
export declare const getImage: API.OperationMethod<GetImageRequest, GetImageResponse, GetImageError, HetznerOpContext>;
export type ListImagesError = HetznerOpError;
/** List Images Returns all Image objects. You can select specific Image types only and sort the results by using URI parameters. */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest, ListImagesResponse, ListImagesError, HetznerOpContext, ListImagesResponseImagesItem>;
export type UpdateImageError = HetznerOpError;
/** Update an Image Updates the Image. You may change the description, convert a Backup Image to a Snapshot Image or change the Image labels. Only Images of type `snapshot` and `backup` can be updated. */
export declare const updateImage: API.OperationMethod<UpdateImageRequest, UpdateImageResponse, UpdateImageError, HetznerOpContext>;
//# sourceMappingURL=images.d.ts.map