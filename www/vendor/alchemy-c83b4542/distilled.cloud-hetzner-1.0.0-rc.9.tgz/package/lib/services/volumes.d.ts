import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateVolumeRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateVolumeRequestLabelsMap: S.Schema<CreateVolumeRequestLabelsMap>;
export interface CreateVolumeRequest {
    /** Size of the Volume in GB. */
    size: number;
    /** Name of the volume. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateVolumeRequestLabelsMap;
    /** Auto-mount Volume after attach. `server` must be provided. */
    automount?: boolean;
    /** Format Volume after creation. One of: `xfs`, `ext4`. */
    format?: string;
    /** Location to create the Volume in (can be omitted if Server is specified). */
    location?: string;
    /** Server to which to attach the Volume once it's created (Volume will be created in the same Location as the server). */
    server?: number;
}
export declare const CreateVolumeRequest: S.Schema<CreateVolumeRequest>;
/** Location of the Volume. Volume can only be attached to Servers in the same Location. */
export interface CreateVolumeResponseVolumeLocation {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Unique identifier of the [Location](#tag/locations). */
    name: string;
    /** Human readable description of the [Location](#tag/locations). */
    description: string;
    /** Country the [Location](#tag/locations) resides in. ISO 3166-1 alpha-2 code of the country. */
    country: string;
    /** Name of the closest city to the [Location](#tag/locations). City name or city name and state in short form. E.g. `Falkenstein` or `Ashburn, VA`. */
    city: string;
    /** Latitude of the city closest to the [Location](#tag/locations). */
    latitude: number;
    /** Longitude of the city closest to the [Location](#tag/locations). */
    longitude: number;
    /** Name of the Network Zone this [Location](#tag/locations) resides in. */
    network_zone: string;
}
export declare const CreateVolumeResponseVolumeLocation: S.Schema<CreateVolumeResponseVolumeLocation>;
/** Protection configuration for the Resource. */
export interface CreateVolumeResponseVolumeProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreateVolumeResponseVolumeProtection: S.Schema<CreateVolumeResponseVolumeProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateVolumeResponseVolumeLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateVolumeResponseVolumeLabelsMap: S.Schema<CreateVolumeResponseVolumeLabelsMap>;
/** Status of the Volume. */
export type CreateVolumeResponseVolumeStatus = "available" | "creating";
export declare const CreateVolumeResponseVolumeStatus: any;
export interface CreateVolumeResponseVolume {
    /** ID of the [Volume](#tag/volumes). */
    id: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** ID of the Server the Volume is attached to, null if it is not attached at all. */
    server: number | null;
    /** Location of the Volume. Volume can only be attached to Servers in the same Location. */
    location: CreateVolumeResponseVolumeLocation;
    /** Size in GB of the Volume. */
    size: number;
    /** Device path on the file system for the Volume. */
    linux_device: string;
    /** Protection configuration for the Resource. */
    protection: CreateVolumeResponseVolumeProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateVolumeResponseVolumeLabelsMap;
    /** Status of the Volume. */
    status: CreateVolumeResponseVolumeStatus;
    /** Filesystem of the Volume if formatted on creation, null if not formatted on creation. */
    format: string | null;
}
export declare const CreateVolumeResponseVolume: S.Schema<CreateVolumeResponseVolume>;
/** Status of the Action. */
export type CreateVolumeResponseActionStatus = "running" | "success" | "error";
export declare const CreateVolumeResponseActionStatus: any;
export interface CreateVolumeResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateVolumeResponseActionResourcesItem: S.Schema<CreateVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateVolumeResponseActionResourcesList = Array<CreateVolumeResponseActionResourcesItem>;
export declare const CreateVolumeResponseActionResourcesList: S.Schema<CreateVolumeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateVolumeResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateVolumeResponseActionError: S.Schema<CreateVolumeResponseActionError>;
export interface CreateVolumeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateVolumeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateVolumeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateVolumeResponseActionError | null;
}
export declare const CreateVolumeResponseAction: S.Schema<CreateVolumeResponseAction>;
/** Status of the Action. */
export type CreateVolumeResponseNextActionsItemStatus = "running" | "success" | "error";
export declare const CreateVolumeResponseNextActionsItemStatus: any;
export type CreateVolumeResponseNextActionsItemResourcesItem = CreateVolumeResponseActionResourcesItem;
export declare const CreateVolumeResponseNextActionsItemResourcesItem: S.Schema<CreateVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateVolumeResponseNextActionsItemResourcesList = Array<CreateVolumeResponseActionResourcesItem>;
export declare const CreateVolumeResponseNextActionsItemResourcesList: S.Schema<CreateVolumeResponseNextActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type CreateVolumeResponseNextActionsItemError = CreateVolumeResponseActionError;
export declare const CreateVolumeResponseNextActionsItemError: S.Schema<CreateVolumeResponseActionError>;
export interface CreateVolumeResponseNextActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateVolumeResponseNextActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateVolumeResponseNextActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateVolumeResponseActionError | null;
}
export declare const CreateVolumeResponseNextActionsItem: S.Schema<CreateVolumeResponseNextActionsItem>;
export type CreateVolumeResponseNextActionsList = Array<CreateVolumeResponseNextActionsItem>;
export declare const CreateVolumeResponseNextActionsList: S.Schema<CreateVolumeResponseNextActionsList>;
export interface CreateVolumeResponse {
    volume: CreateVolumeResponseVolume;
    action: CreateVolumeResponseAction;
    next_actions: CreateVolumeResponseNextActionsList;
}
export declare const CreateVolumeResponse: S.Schema<CreateVolumeResponse>;
export interface DeleteVolumeRequest {
    /** ID of the Volume. */
    id: number;
}
export declare const DeleteVolumeRequest: S.Schema<DeleteVolumeRequest>;
export interface DeleteVolumeResponse {
}
export declare const DeleteVolumeResponse: S.Schema<DeleteVolumeResponse>;
export interface GetVolumeRequest {
    /** ID of the Volume. */
    id: number;
}
export declare const GetVolumeRequest: S.Schema<GetVolumeRequest>;
/** Location of the Volume. Volume can only be attached to Servers in the same Location. */
export type GetVolumeResponseVolumeLocation = CreateVolumeResponseVolumeLocation;
export declare const GetVolumeResponseVolumeLocation: S.Schema<CreateVolumeResponseVolumeLocation>;
/** Protection configuration for the Resource. */
export type GetVolumeResponseVolumeProtection = CreateVolumeResponseVolumeProtection;
export declare const GetVolumeResponseVolumeProtection: S.Schema<CreateVolumeResponseVolumeProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetVolumeResponseVolumeLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetVolumeResponseVolumeLabelsMap: S.Schema<GetVolumeResponseVolumeLabelsMap>;
/** Status of the Volume. */
export type GetVolumeResponseVolumeStatus = "available" | "creating";
export declare const GetVolumeResponseVolumeStatus: any;
export interface GetVolumeResponseVolume {
    /** ID of the [Volume](#tag/volumes). */
    id: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** ID of the Server the Volume is attached to, null if it is not attached at all. */
    server: number | null;
    /** Location of the Volume. Volume can only be attached to Servers in the same Location. */
    location: CreateVolumeResponseVolumeLocation;
    /** Size in GB of the Volume. */
    size: number;
    /** Device path on the file system for the Volume. */
    linux_device: string;
    /** Protection configuration for the Resource. */
    protection: CreateVolumeResponseVolumeProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetVolumeResponseVolumeLabelsMap;
    /** Status of the Volume. */
    status: GetVolumeResponseVolumeStatus;
    /** Filesystem of the Volume if formatted on creation, null if not formatted on creation. */
    format: string | null;
}
export declare const GetVolumeResponseVolume: S.Schema<GetVolumeResponseVolume>;
export interface GetVolumeResponse {
    volume: GetVolumeResponseVolume;
}
export declare const GetVolumeResponse: S.Schema<GetVolumeResponse>;
/** Status of the Volume. */
export type ListVolumesRequestStatusItem = "available" | "creating";
export declare const ListVolumesRequestStatusItem: any;
export type ListVolumesRequestStatusList = Array<ListVolumesRequestStatusItem | (string & {})>;
export declare const ListVolumesRequestStatusList: S.Schema<ListVolumesRequestStatusList>;
export type ListVolumesRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListVolumesRequestSortItem: any;
export type ListVolumesRequestSortList = Array<ListVolumesRequestSortItem | (string & {})>;
export declare const ListVolumesRequestSortList: S.Schema<ListVolumesRequestSortList>;
export interface ListVolumesRequest {
    /** Filter resources by status. May be used multiple times. The response will only contain the resources with the specified status. */
    status?: ListVolumesRequestStatusList;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListVolumesRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListVolumesRequest: S.Schema<ListVolumesRequest>;
/** Location of the Volume. Volume can only be attached to Servers in the same Location. */
export type ListVolumesResponseVolumesItemLocation = CreateVolumeResponseVolumeLocation;
export declare const ListVolumesResponseVolumesItemLocation: S.Schema<CreateVolumeResponseVolumeLocation>;
/** Protection configuration for the Resource. */
export type ListVolumesResponseVolumesItemProtection = CreateVolumeResponseVolumeProtection;
export declare const ListVolumesResponseVolumesItemProtection: S.Schema<CreateVolumeResponseVolumeProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListVolumesResponseVolumesItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListVolumesResponseVolumesItemLabelsMap: S.Schema<ListVolumesResponseVolumesItemLabelsMap>;
/** Status of the Volume. */
export type ListVolumesResponseVolumesItemStatus = "available" | "creating";
export declare const ListVolumesResponseVolumesItemStatus: any;
export interface ListVolumesResponseVolumesItem {
    /** ID of the [Volume](#tag/volumes). */
    id: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** ID of the Server the Volume is attached to, null if it is not attached at all. */
    server: number | null;
    /** Location of the Volume. Volume can only be attached to Servers in the same Location. */
    location: CreateVolumeResponseVolumeLocation;
    /** Size in GB of the Volume. */
    size: number;
    /** Device path on the file system for the Volume. */
    linux_device: string;
    /** Protection configuration for the Resource. */
    protection: CreateVolumeResponseVolumeProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListVolumesResponseVolumesItemLabelsMap;
    /** Status of the Volume. */
    status: ListVolumesResponseVolumesItemStatus;
    /** Filesystem of the Volume if formatted on creation, null if not formatted on creation. */
    format: string | null;
}
export declare const ListVolumesResponseVolumesItem: S.Schema<ListVolumesResponseVolumesItem>;
export type ListVolumesResponseVolumesList = Array<ListVolumesResponseVolumesItem>;
export declare const ListVolumesResponseVolumesList: S.Schema<ListVolumesResponseVolumesList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListVolumesResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListVolumesResponseMetaPagination: S.Schema<ListVolumesResponseMetaPagination>;
export interface ListVolumesResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListVolumesResponseMetaPagination;
}
export declare const ListVolumesResponseMeta: S.Schema<ListVolumesResponseMeta>;
export interface ListVolumesResponse {
    volumes: ListVolumesResponseVolumesList;
    meta: ListVolumesResponseMeta;
}
export declare const ListVolumesResponse: S.Schema<ListVolumesResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateVolumeRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateVolumeRequestLabelsMap: S.Schema<UpdateVolumeRequestLabelsMap>;
export interface UpdateVolumeRequest {
    /** ID of the Volume. */
    id: number;
    /** New Volume name. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateVolumeRequestLabelsMap;
}
export declare const UpdateVolumeRequest: S.Schema<UpdateVolumeRequest>;
/** Location of the Volume. Volume can only be attached to Servers in the same Location. */
export type UpdateVolumeResponseVolumeLocation = CreateVolumeResponseVolumeLocation;
export declare const UpdateVolumeResponseVolumeLocation: S.Schema<CreateVolumeResponseVolumeLocation>;
/** Protection configuration for the Resource. */
export type UpdateVolumeResponseVolumeProtection = CreateVolumeResponseVolumeProtection;
export declare const UpdateVolumeResponseVolumeProtection: S.Schema<CreateVolumeResponseVolumeProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateVolumeResponseVolumeLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateVolumeResponseVolumeLabelsMap: S.Schema<UpdateVolumeResponseVolumeLabelsMap>;
/** Status of the Volume. */
export type UpdateVolumeResponseVolumeStatus = "available" | "creating";
export declare const UpdateVolumeResponseVolumeStatus: any;
export interface UpdateVolumeResponseVolume {
    /** ID of the [Volume](#tag/volumes). */
    id: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** ID of the Server the Volume is attached to, null if it is not attached at all. */
    server: number | null;
    /** Location of the Volume. Volume can only be attached to Servers in the same Location. */
    location: CreateVolumeResponseVolumeLocation;
    /** Size in GB of the Volume. */
    size: number;
    /** Device path on the file system for the Volume. */
    linux_device: string;
    /** Protection configuration for the Resource. */
    protection: CreateVolumeResponseVolumeProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateVolumeResponseVolumeLabelsMap;
    /** Status of the Volume. */
    status: UpdateVolumeResponseVolumeStatus;
    /** Filesystem of the Volume if formatted on creation, null if not formatted on creation. */
    format: string | null;
}
export declare const UpdateVolumeResponseVolume: S.Schema<UpdateVolumeResponseVolume>;
export interface UpdateVolumeResponse {
    volume: UpdateVolumeResponseVolume;
}
export declare const UpdateVolumeResponse: S.Schema<UpdateVolumeResponse>;
export type CreateVolumeError = HetznerOpError;
/** Create a Volume Creates a new Volume attached to a Server. If you want to create a Volume that is not attached to a Server, you need to provide the `location` key instead of `server`. This can be either the ID or the name of the Location this Volume will be created in. Note that a Volume can be attached to a Server only in the same Location as the Volume itself. Specifying the Server during Volume creation will automatically attach the Volume to that Server after it has been initialized. In that case, the `next_actions` key in the response is an array which contains a single `attach_volume` action. The minimum Volume size is 10GB and the maximum size is 10TB (10240GB). A volume’s name can consist of alphanumeric characters, dashes, underscores, and dots, but has to start and end with an alphanumeric character. The total length is limited to 64 characters. Volume names must be unique per Project. #### Operation specific errors */
export declare const createVolume: API.OperationMethod<CreateVolumeRequest, CreateVolumeResponse, CreateVolumeError, HetznerOpContext>;
export type DeleteVolumeError = HetznerOpError;
/** Delete a Volume Deletes a volume. All Volume data is irreversibly destroyed. The Volume must not be attached to a Server and it must not have delete protection enabled. */
export declare const deleteVolume: API.OperationMethod<DeleteVolumeRequest, DeleteVolumeResponse, DeleteVolumeError, HetznerOpContext>;
export type GetVolumeError = HetznerOpError;
/** Get a Volume Gets a specific Volume object. */
export declare const getVolume: API.OperationMethod<GetVolumeRequest, GetVolumeResponse, GetVolumeError, HetznerOpContext>;
export type ListVolumesError = HetznerOpError;
/** List Volumes Gets all existing Volumes that you have available. */
export declare const listVolumes: API.PaginatedOperationMethod<ListVolumesRequest, ListVolumesResponse, ListVolumesError, HetznerOpContext, ListVolumesResponseVolumesItem>;
export type UpdateVolumeError = HetznerOpError;
/** Update a Volume Updates the Volume properties. */
export declare const updateVolume: API.OperationMethod<UpdateVolumeRequest, UpdateVolumeResponse, UpdateVolumeError, HetznerOpContext>;
//# sourceMappingURL=volumes.d.ts.map