import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface AssignFloatingIpRequest {
    /** ID of the Floating IP. */
    id: number;
    /** [Server](#tag/servers) the [Floating IP](#tag/floating-ips) is assigned to. `null` if not assigned. */
    server: number | null;
}
export declare const AssignFloatingIpRequest: S.Schema<AssignFloatingIpRequest>;
/** Status of the Action. */
export type AssignFloatingIpResponseActionStatus = "running" | "success" | "error";
export declare const AssignFloatingIpResponseActionStatus: any;
export interface AssignFloatingIpResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AssignFloatingIpResponseActionResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AssignFloatingIpResponseActionResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const AssignFloatingIpResponseActionResourcesList: S.Schema<AssignFloatingIpResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AssignFloatingIpResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AssignFloatingIpResponseActionError: S.Schema<AssignFloatingIpResponseActionError>;
export interface AssignFloatingIpResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AssignFloatingIpResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AssignFloatingIpResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const AssignFloatingIpResponseAction: S.Schema<AssignFloatingIpResponseAction>;
export interface AssignFloatingIpResponse {
    action: AssignFloatingIpResponseAction;
}
export declare const AssignFloatingIpResponse: S.Schema<AssignFloatingIpResponse>;
export interface ChangeFloatingIpDnsPtrRequest {
    /** ID of the Floating IP. */
    id: number;
    /** Single IPv4 or IPv6 address to create pointer for. */
    ip: string;
    /** Domain Name to point to. PTR record content used for reverse DNS. Set to null to reset (IPv4) to the default value or remove (IPv6) the record. */
    dns_ptr?: string | null;
}
export declare const ChangeFloatingIpDnsPtrRequest: S.Schema<ChangeFloatingIpDnsPtrRequest>;
/** Status of the Action. */
export type ChangeFloatingIpDnsPtrResponseActionStatus = "running" | "success" | "error";
export declare const ChangeFloatingIpDnsPtrResponseActionStatus: any;
export type ChangeFloatingIpDnsPtrResponseActionResourcesItem = AssignFloatingIpResponseActionResourcesItem;
export declare const ChangeFloatingIpDnsPtrResponseActionResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeFloatingIpDnsPtrResponseActionResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const ChangeFloatingIpDnsPtrResponseActionResourcesList: S.Schema<ChangeFloatingIpDnsPtrResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeFloatingIpDnsPtrResponseActionError = AssignFloatingIpResponseActionError;
export declare const ChangeFloatingIpDnsPtrResponseActionError: S.Schema<AssignFloatingIpResponseActionError>;
export interface ChangeFloatingIpDnsPtrResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeFloatingIpDnsPtrResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeFloatingIpDnsPtrResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const ChangeFloatingIpDnsPtrResponseAction: S.Schema<ChangeFloatingIpDnsPtrResponseAction>;
export interface ChangeFloatingIpDnsPtrResponse {
    action: ChangeFloatingIpDnsPtrResponseAction;
}
export declare const ChangeFloatingIpDnsPtrResponse: S.Schema<ChangeFloatingIpDnsPtrResponse>;
export interface ChangeFloatingIpProtectionRequest {
    /** ID of the Floating IP. */
    id: number;
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const ChangeFloatingIpProtectionRequest: S.Schema<ChangeFloatingIpProtectionRequest>;
/** Status of the Action. */
export type ChangeFloatingIpProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeFloatingIpProtectionResponseActionStatus: any;
export type ChangeFloatingIpProtectionResponseActionResourcesItem = AssignFloatingIpResponseActionResourcesItem;
export declare const ChangeFloatingIpProtectionResponseActionResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeFloatingIpProtectionResponseActionResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const ChangeFloatingIpProtectionResponseActionResourcesList: S.Schema<ChangeFloatingIpProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeFloatingIpProtectionResponseActionError = AssignFloatingIpResponseActionError;
export declare const ChangeFloatingIpProtectionResponseActionError: S.Schema<AssignFloatingIpResponseActionError>;
export interface ChangeFloatingIpProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeFloatingIpProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeFloatingIpProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const ChangeFloatingIpProtectionResponseAction: S.Schema<ChangeFloatingIpProtectionResponseAction>;
export interface ChangeFloatingIpProtectionResponse {
    action: ChangeFloatingIpProtectionResponseAction;
}
export declare const ChangeFloatingIpProtectionResponse: S.Schema<ChangeFloatingIpProtectionResponse>;
export interface GetFloatingIpsActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetFloatingIpsActionRequest: S.Schema<GetFloatingIpsActionRequest>;
/** Status of the Action. */
export type GetFloatingIpsActionResponseActionStatus = "running" | "success" | "error";
export declare const GetFloatingIpsActionResponseActionStatus: any;
export type GetFloatingIpsActionResponseActionResourcesItem = AssignFloatingIpResponseActionResourcesItem;
export declare const GetFloatingIpsActionResponseActionResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetFloatingIpsActionResponseActionResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const GetFloatingIpsActionResponseActionResourcesList: S.Schema<GetFloatingIpsActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetFloatingIpsActionResponseActionError = AssignFloatingIpResponseActionError;
export declare const GetFloatingIpsActionResponseActionError: S.Schema<AssignFloatingIpResponseActionError>;
export interface GetFloatingIpsActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetFloatingIpsActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetFloatingIpsActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const GetFloatingIpsActionResponseAction: S.Schema<GetFloatingIpsActionResponseAction>;
export interface GetFloatingIpsActionResponse {
    action: GetFloatingIpsActionResponseAction;
}
export declare const GetFloatingIpsActionResponse: S.Schema<GetFloatingIpsActionResponse>;
export type ListFloatingIpActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListFloatingIpActionsRequestSortItem: any;
export type ListFloatingIpActionsRequestSortList = Array<ListFloatingIpActionsRequestSortItem | (string & {})>;
export declare const ListFloatingIpActionsRequestSortList: S.Schema<ListFloatingIpActionsRequestSortList>;
/** Status of the Action. */
export type ListFloatingIpActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListFloatingIpActionsRequestStatusItem: any;
export type ListFloatingIpActionsRequestStatusList = Array<ListFloatingIpActionsRequestStatusItem | (string & {})>;
export declare const ListFloatingIpActionsRequestStatusList: S.Schema<ListFloatingIpActionsRequestStatusList>;
export interface ListFloatingIpActionsRequest {
    /** ID of the Floating IP. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListFloatingIpActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListFloatingIpActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListFloatingIpActionsRequest: S.Schema<ListFloatingIpActionsRequest>;
/** Status of the Action. */
export type ListFloatingIpActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListFloatingIpActionsResponseActionsItemStatus: any;
export type ListFloatingIpActionsResponseActionsItemResourcesItem = AssignFloatingIpResponseActionResourcesItem;
export declare const ListFloatingIpActionsResponseActionsItemResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListFloatingIpActionsResponseActionsItemResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const ListFloatingIpActionsResponseActionsItemResourcesList: S.Schema<ListFloatingIpActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListFloatingIpActionsResponseActionsItemError = AssignFloatingIpResponseActionError;
export declare const ListFloatingIpActionsResponseActionsItemError: S.Schema<AssignFloatingIpResponseActionError>;
export interface ListFloatingIpActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListFloatingIpActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListFloatingIpActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const ListFloatingIpActionsResponseActionsItem: S.Schema<ListFloatingIpActionsResponseActionsItem>;
export type ListFloatingIpActionsResponseActionsList = Array<ListFloatingIpActionsResponseActionsItem>;
export declare const ListFloatingIpActionsResponseActionsList: S.Schema<ListFloatingIpActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListFloatingIpActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListFloatingIpActionsResponseMetaPagination: S.Schema<ListFloatingIpActionsResponseMetaPagination>;
export interface ListFloatingIpActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListFloatingIpActionsResponseMetaPagination;
}
export declare const ListFloatingIpActionsResponseMeta: S.Schema<ListFloatingIpActionsResponseMeta>;
export interface ListFloatingIpActionsResponse {
    actions: ListFloatingIpActionsResponseActionsList;
    meta: ListFloatingIpActionsResponseMeta;
}
export declare const ListFloatingIpActionsResponse: S.Schema<ListFloatingIpActionsResponse>;
export type ListFloatingIpsActionsRequestIdList = Array<number>;
export declare const ListFloatingIpsActionsRequestIdList: S.Schema<ListFloatingIpsActionsRequestIdList>;
export type ListFloatingIpsActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListFloatingIpsActionsRequestSortItem: any;
export type ListFloatingIpsActionsRequestSortList = Array<ListFloatingIpsActionsRequestSortItem | (string & {})>;
export declare const ListFloatingIpsActionsRequestSortList: S.Schema<ListFloatingIpsActionsRequestSortList>;
/** Status of the Action. */
export type ListFloatingIpsActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListFloatingIpsActionsRequestStatusItem: any;
export type ListFloatingIpsActionsRequestStatusList = Array<ListFloatingIpsActionsRequestStatusItem | (string & {})>;
export declare const ListFloatingIpsActionsRequestStatusList: S.Schema<ListFloatingIpsActionsRequestStatusList>;
export interface ListFloatingIpsActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListFloatingIpsActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListFloatingIpsActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListFloatingIpsActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListFloatingIpsActionsRequest: S.Schema<ListFloatingIpsActionsRequest>;
/** Status of the Action. */
export type ListFloatingIpsActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListFloatingIpsActionsResponseActionsItemStatus: any;
export type ListFloatingIpsActionsResponseActionsItemResourcesItem = AssignFloatingIpResponseActionResourcesItem;
export declare const ListFloatingIpsActionsResponseActionsItemResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListFloatingIpsActionsResponseActionsItemResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const ListFloatingIpsActionsResponseActionsItemResourcesList: S.Schema<ListFloatingIpsActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListFloatingIpsActionsResponseActionsItemError = AssignFloatingIpResponseActionError;
export declare const ListFloatingIpsActionsResponseActionsItemError: S.Schema<AssignFloatingIpResponseActionError>;
export interface ListFloatingIpsActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListFloatingIpsActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListFloatingIpsActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const ListFloatingIpsActionsResponseActionsItem: S.Schema<ListFloatingIpsActionsResponseActionsItem>;
export type ListFloatingIpsActionsResponseActionsList = Array<ListFloatingIpsActionsResponseActionsItem>;
export declare const ListFloatingIpsActionsResponseActionsList: S.Schema<ListFloatingIpsActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListFloatingIpsActionsResponseMetaPagination = ListFloatingIpActionsResponseMetaPagination;
export declare const ListFloatingIpsActionsResponseMetaPagination: S.Schema<ListFloatingIpActionsResponseMetaPagination>;
export type ListFloatingIpsActionsResponseMeta = ListFloatingIpActionsResponseMeta;
export declare const ListFloatingIpsActionsResponseMeta: S.Schema<ListFloatingIpActionsResponseMeta>;
export interface ListFloatingIpsActionsResponse {
    actions: ListFloatingIpsActionsResponseActionsList;
    meta: ListFloatingIpActionsResponseMeta;
}
export declare const ListFloatingIpsActionsResponse: S.Schema<ListFloatingIpsActionsResponse>;
export interface UnassignFloatingIpRequest {
    /** ID of the Floating IP. */
    id: number;
}
export declare const UnassignFloatingIpRequest: S.Schema<UnassignFloatingIpRequest>;
/** Status of the Action. */
export type UnassignFloatingIpResponseActionStatus = "running" | "success" | "error";
export declare const UnassignFloatingIpResponseActionStatus: any;
export type UnassignFloatingIpResponseActionResourcesItem = AssignFloatingIpResponseActionResourcesItem;
export declare const UnassignFloatingIpResponseActionResourcesItem: S.Schema<AssignFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type UnassignFloatingIpResponseActionResourcesList = Array<AssignFloatingIpResponseActionResourcesItem>;
export declare const UnassignFloatingIpResponseActionResourcesList: S.Schema<UnassignFloatingIpResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type UnassignFloatingIpResponseActionError = AssignFloatingIpResponseActionError;
export declare const UnassignFloatingIpResponseActionError: S.Schema<AssignFloatingIpResponseActionError>;
export interface UnassignFloatingIpResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: UnassignFloatingIpResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: UnassignFloatingIpResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignFloatingIpResponseActionError | null;
}
export declare const UnassignFloatingIpResponseAction: S.Schema<UnassignFloatingIpResponseAction>;
export interface UnassignFloatingIpResponse {
    action: UnassignFloatingIpResponseAction;
}
export declare const UnassignFloatingIpResponse: S.Schema<UnassignFloatingIpResponse>;
export type AssignFloatingIpError = HetznerOpError;
/** Assign a Floating IP to a Server Assigns a [Floating IP](#tag/floating-ips) to a [Server](#tag/servers). #### Operation specific errors */
export declare const assignFloatingIp: API.OperationMethod<AssignFloatingIpRequest, AssignFloatingIpResponse, AssignFloatingIpError, HetznerOpContext>;
export type ChangeFloatingIpDnsPtrError = HetznerOpError;
/** Change reverse DNS records for a Floating IP Change the reverse DNS records for this [Floating IP](#tag/floating-ips). Allows to modify the PTR records set for the IP address. */
export declare const changeFloatingIpDnsPtr: API.OperationMethod<ChangeFloatingIpDnsPtrRequest, ChangeFloatingIpDnsPtrResponse, ChangeFloatingIpDnsPtrError, HetznerOpContext>;
export type ChangeFloatingIpProtectionError = HetznerOpError;
/** Change Floating IP Protection Changes the protection settings configured for the [Floating IP](#tag/floating-ips). */
export declare const changeFloatingIpProtection: API.OperationMethod<ChangeFloatingIpProtectionRequest, ChangeFloatingIpProtectionResponse, ChangeFloatingIpProtectionError, HetznerOpContext>;
export type GetFloatingIpsActionError = HetznerOpError;
/** Get an Action Returns a single [Action](#tag/actions). */
export declare const getFloatingIpsAction: API.OperationMethod<GetFloatingIpsActionRequest, GetFloatingIpsActionResponse, GetFloatingIpsActionError, HetznerOpContext>;
export type ListFloatingIpActionsError = HetznerOpError;
/** List Actions for a Floating IP Lists [Actions](#tag/actions) for a [Floating IP](#tag/floating-ips). Use the provided URI parameters to modify the result. */
export declare const listFloatingIpActions: API.PaginatedOperationMethod<ListFloatingIpActionsRequest, ListFloatingIpActionsResponse, ListFloatingIpActionsError, HetznerOpContext, ListFloatingIpActionsResponseActionsItem>;
export type ListFloatingIpsActionsError = HetznerOpError;
/** List Actions Lists multiple [Actions](#tag/actions). Use the provided URI parameters to modify the result. */
export declare const listFloatingIpsActions: API.PaginatedOperationMethod<ListFloatingIpsActionsRequest, ListFloatingIpsActionsResponse, ListFloatingIpsActionsError, HetznerOpContext, ListFloatingIpsActionsResponseActionsItem>;
export type UnassignFloatingIpError = HetznerOpError;
/** Unassign a Floating IP Unassigns a [Floating IP](#tag/floating-ips). Results in the IP being unreachable. Can be assigned to another resource again. */
export declare const unassignFloatingIp: API.OperationMethod<UnassignFloatingIpRequest, UnassignFloatingIpResponse, UnassignFloatingIpError, HetznerOpContext>;
//# sourceMappingURL=floating_ip_actions.d.ts.map