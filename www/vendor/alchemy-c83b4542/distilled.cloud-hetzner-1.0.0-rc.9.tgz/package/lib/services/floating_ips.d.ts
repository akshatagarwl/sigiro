import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** The Floating IP type. */
export type CreateFloatingIpRequestType = "ipv4" | "ipv6";
export declare const CreateFloatingIpRequestType: any;
/** Home [Location](#tag/locations) for the [Floating IP](#tag/floating-ips). Either the ID or the name of the [Location](#tag/locations). Only optional if no [Server](#tag/servers) is provided. Routing is optimized for this [Locations](#tag/locations). */
export type CreateFloatingIpRequestHomeLocation = string | number;
export declare const CreateFloatingIpRequestHomeLocation: S.Schema<CreateFloatingIpRequestHomeLocation>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateFloatingIpRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateFloatingIpRequestLabelsMap: S.Schema<CreateFloatingIpRequestLabelsMap>;
export interface CreateFloatingIpRequest {
    /** The Floating IP type. */
    type: CreateFloatingIpRequestType | (string & {});
    /** [Server](#tag/servers) the [Floating IP](#tag/floating-ips) is assigned to. `null` if not assigned. */
    server?: number | null;
    /** Home [Location](#tag/locations) for the [Floating IP](#tag/floating-ips). Either the ID or the name of the [Location](#tag/locations). Only optional if no [Server](#tag/servers) is provided. Routing is optimized for this [Locations](#tag/locations). */
    home_location?: CreateFloatingIpRequestHomeLocation;
    /** Description of the Resource. */
    description?: string | null;
    /** Name of the Resource. Must be unique per Project. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateFloatingIpRequestLabelsMap;
}
export declare const CreateFloatingIpRequest: S.Schema<CreateFloatingIpRequest>;
/** The Floating IP type. */
export type CreateFloatingIpResponseFloatingIpType = "ipv4" | "ipv6";
export declare const CreateFloatingIpResponseFloatingIpType: any;
export interface CreateFloatingIpResponseFloatingIpDnsPtrItem {
    /** Single IPv4 or IPv6 address of the record. */
    ip: string;
    /** Domain Name to point to. PTR record content used for reverse DNS. */
    dns_ptr: string;
}
export declare const CreateFloatingIpResponseFloatingIpDnsPtrItem: S.Schema<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
/** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
export type CreateFloatingIpResponseFloatingIpDnsPtrList = Array<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
export declare const CreateFloatingIpResponseFloatingIpDnsPtrList: S.Schema<CreateFloatingIpResponseFloatingIpDnsPtrList>;
export interface CreateFloatingIpResponseFloatingIpHomeLocation {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Unique identifier of the [Location](#tag/locations). */
    name: string;
    /** Human readable description of the [Location](#tag/locations). */
    description: string;
    /** Country the [Location](#tag/locations) resides in. ISO 3166-1 alpha-2 code of the country. */
    country: string;
    /** Name of the closest city to the [Location](#tag/locations). City name or city name and state in short form. E.g. `Falkenstein` or `Ashburn, VA`. */
    city: string;
    /** Latitude of the city closest to the [Location](#tag/locations). */
    latitude: number;
    /** Longitude of the city closest to the [Location](#tag/locations). */
    longitude: number;
    /** Name of the Network Zone this [Location](#tag/locations) resides in. */
    network_zone: string;
}
export declare const CreateFloatingIpResponseFloatingIpHomeLocation: S.Schema<CreateFloatingIpResponseFloatingIpHomeLocation>;
/** Protection configuration for the Resource. */
export interface CreateFloatingIpResponseFloatingIpProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreateFloatingIpResponseFloatingIpProtection: S.Schema<CreateFloatingIpResponseFloatingIpProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateFloatingIpResponseFloatingIpLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateFloatingIpResponseFloatingIpLabelsMap: S.Schema<CreateFloatingIpResponseFloatingIpLabelsMap>;
export interface CreateFloatingIpResponseFloatingIp {
    /** ID of the [Floating IP](#tag/floating-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Description of the Resource. */
    description: string | null;
    /** IP address. */
    ip: string;
    /** The Floating IP type. */
    type: CreateFloatingIpResponseFloatingIpType;
    /** [Server](#tag/servers) the [Floating IP](#tag/floating-ips) is assigned to. `null` if not assigned. */
    server: number | null;
    /** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
    dns_ptr: CreateFloatingIpResponseFloatingIpDnsPtrList;
    home_location: CreateFloatingIpResponseFloatingIpHomeLocation;
    /** Indicates whether the [Floating IP](#tag/floating-ips) is blocked. */
    blocked: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateFloatingIpResponseFloatingIpProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateFloatingIpResponseFloatingIpLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const CreateFloatingIpResponseFloatingIp: S.Schema<CreateFloatingIpResponseFloatingIp>;
/** Status of the Action. */
export type CreateFloatingIpResponseActionStatus = "running" | "success" | "error";
export declare const CreateFloatingIpResponseActionStatus: any;
export interface CreateFloatingIpResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateFloatingIpResponseActionResourcesItem: S.Schema<CreateFloatingIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateFloatingIpResponseActionResourcesList = Array<CreateFloatingIpResponseActionResourcesItem>;
export declare const CreateFloatingIpResponseActionResourcesList: S.Schema<CreateFloatingIpResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateFloatingIpResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateFloatingIpResponseActionError: S.Schema<CreateFloatingIpResponseActionError>;
/** Action will only be returned if the [Floating IP](#tag/floating-ips) is getting assigned. */
export interface CreateFloatingIpResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateFloatingIpResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateFloatingIpResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateFloatingIpResponseActionError | null;
}
export declare const CreateFloatingIpResponseAction: S.Schema<CreateFloatingIpResponseAction>;
export interface CreateFloatingIpResponse {
    floating_ip: CreateFloatingIpResponseFloatingIp;
    /** Action will only be returned if the [Floating IP](#tag/floating-ips) is getting assigned. */
    action?: CreateFloatingIpResponseAction | null;
}
export declare const CreateFloatingIpResponse: S.Schema<CreateFloatingIpResponse>;
export interface DeleteFloatingIpRequest {
    /** ID of the Floating IP. */
    id: number;
}
export declare const DeleteFloatingIpRequest: S.Schema<DeleteFloatingIpRequest>;
export interface DeleteFloatingIpResponse {
}
export declare const DeleteFloatingIpResponse: S.Schema<DeleteFloatingIpResponse>;
export interface GetFloatingIpRequest {
    /** ID of the Floating IP. */
    id: number;
}
export declare const GetFloatingIpRequest: S.Schema<GetFloatingIpRequest>;
/** The Floating IP type. */
export type GetFloatingIpResponseFloatingIpType = "ipv4" | "ipv6";
export declare const GetFloatingIpResponseFloatingIpType: any;
export type GetFloatingIpResponseFloatingIpDnsPtrItem = CreateFloatingIpResponseFloatingIpDnsPtrItem;
export declare const GetFloatingIpResponseFloatingIpDnsPtrItem: S.Schema<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
/** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
export type GetFloatingIpResponseFloatingIpDnsPtrList = Array<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
export declare const GetFloatingIpResponseFloatingIpDnsPtrList: S.Schema<GetFloatingIpResponseFloatingIpDnsPtrList>;
export type GetFloatingIpResponseFloatingIpHomeLocation = CreateFloatingIpResponseFloatingIpHomeLocation;
export declare const GetFloatingIpResponseFloatingIpHomeLocation: S.Schema<CreateFloatingIpResponseFloatingIpHomeLocation>;
/** Protection configuration for the Resource. */
export type GetFloatingIpResponseFloatingIpProtection = CreateFloatingIpResponseFloatingIpProtection;
export declare const GetFloatingIpResponseFloatingIpProtection: S.Schema<CreateFloatingIpResponseFloatingIpProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetFloatingIpResponseFloatingIpLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetFloatingIpResponseFloatingIpLabelsMap: S.Schema<GetFloatingIpResponseFloatingIpLabelsMap>;
export interface GetFloatingIpResponseFloatingIp {
    /** ID of the [Floating IP](#tag/floating-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Description of the Resource. */
    description: string | null;
    /** IP address. */
    ip: string;
    /** The Floating IP type. */
    type: GetFloatingIpResponseFloatingIpType;
    /** [Server](#tag/servers) the [Floating IP](#tag/floating-ips) is assigned to. `null` if not assigned. */
    server: number | null;
    /** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
    dns_ptr: GetFloatingIpResponseFloatingIpDnsPtrList;
    home_location: CreateFloatingIpResponseFloatingIpHomeLocation;
    /** Indicates whether the [Floating IP](#tag/floating-ips) is blocked. */
    blocked: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateFloatingIpResponseFloatingIpProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetFloatingIpResponseFloatingIpLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const GetFloatingIpResponseFloatingIp: S.Schema<GetFloatingIpResponseFloatingIp>;
export interface GetFloatingIpResponse {
    floating_ip: GetFloatingIpResponseFloatingIp;
}
export declare const GetFloatingIpResponse: S.Schema<GetFloatingIpResponse>;
export type ListFloatingIpsRequestSortItem = "id" | "id:asc" | "id:desc" | "created" | "created:asc" | "created:desc";
export declare const ListFloatingIpsRequestSortItem: any;
export type ListFloatingIpsRequestSortList = Array<ListFloatingIpsRequestSortItem | (string & {})>;
export declare const ListFloatingIpsRequestSortList: S.Schema<ListFloatingIpsRequestSortList>;
export interface ListFloatingIpsRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListFloatingIpsRequestSortList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListFloatingIpsRequest: S.Schema<ListFloatingIpsRequest>;
/** The Floating IP type. */
export type ListFloatingIpsResponseFloatingIpsItemType = "ipv4" | "ipv6";
export declare const ListFloatingIpsResponseFloatingIpsItemType: any;
export type ListFloatingIpsResponseFloatingIpsItemDnsPtrItem = CreateFloatingIpResponseFloatingIpDnsPtrItem;
export declare const ListFloatingIpsResponseFloatingIpsItemDnsPtrItem: S.Schema<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
/** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
export type ListFloatingIpsResponseFloatingIpsItemDnsPtrList = Array<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
export declare const ListFloatingIpsResponseFloatingIpsItemDnsPtrList: S.Schema<ListFloatingIpsResponseFloatingIpsItemDnsPtrList>;
export type ListFloatingIpsResponseFloatingIpsItemHomeLocation = CreateFloatingIpResponseFloatingIpHomeLocation;
export declare const ListFloatingIpsResponseFloatingIpsItemHomeLocation: S.Schema<CreateFloatingIpResponseFloatingIpHomeLocation>;
/** Protection configuration for the Resource. */
export type ListFloatingIpsResponseFloatingIpsItemProtection = CreateFloatingIpResponseFloatingIpProtection;
export declare const ListFloatingIpsResponseFloatingIpsItemProtection: S.Schema<CreateFloatingIpResponseFloatingIpProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListFloatingIpsResponseFloatingIpsItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListFloatingIpsResponseFloatingIpsItemLabelsMap: S.Schema<ListFloatingIpsResponseFloatingIpsItemLabelsMap>;
export interface ListFloatingIpsResponseFloatingIpsItem {
    /** ID of the [Floating IP](#tag/floating-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Description of the Resource. */
    description: string | null;
    /** IP address. */
    ip: string;
    /** The Floating IP type. */
    type: ListFloatingIpsResponseFloatingIpsItemType;
    /** [Server](#tag/servers) the [Floating IP](#tag/floating-ips) is assigned to. `null` if not assigned. */
    server: number | null;
    /** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
    dns_ptr: ListFloatingIpsResponseFloatingIpsItemDnsPtrList;
    home_location: CreateFloatingIpResponseFloatingIpHomeLocation;
    /** Indicates whether the [Floating IP](#tag/floating-ips) is blocked. */
    blocked: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateFloatingIpResponseFloatingIpProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListFloatingIpsResponseFloatingIpsItemLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const ListFloatingIpsResponseFloatingIpsItem: S.Schema<ListFloatingIpsResponseFloatingIpsItem>;
export type ListFloatingIpsResponseFloatingIpsList = Array<ListFloatingIpsResponseFloatingIpsItem>;
export declare const ListFloatingIpsResponseFloatingIpsList: S.Schema<ListFloatingIpsResponseFloatingIpsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListFloatingIpsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListFloatingIpsResponseMetaPagination: S.Schema<ListFloatingIpsResponseMetaPagination>;
export interface ListFloatingIpsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListFloatingIpsResponseMetaPagination;
}
export declare const ListFloatingIpsResponseMeta: S.Schema<ListFloatingIpsResponseMeta>;
export interface ListFloatingIpsResponse {
    floating_ips: ListFloatingIpsResponseFloatingIpsList;
    meta: ListFloatingIpsResponseMeta;
}
export declare const ListFloatingIpsResponse: S.Schema<ListFloatingIpsResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateFloatingIpRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateFloatingIpRequestLabelsMap: S.Schema<UpdateFloatingIpRequestLabelsMap>;
export interface UpdateFloatingIpRequest {
    /** ID of the Floating IP. */
    id: number;
    /** Description of the Resource. */
    description?: string | null;
    /** Name of the Resource. Must be unique per Project. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateFloatingIpRequestLabelsMap;
}
export declare const UpdateFloatingIpRequest: S.Schema<UpdateFloatingIpRequest>;
/** The Floating IP type. */
export type UpdateFloatingIpResponseFloatingIpType = "ipv4" | "ipv6";
export declare const UpdateFloatingIpResponseFloatingIpType: any;
export type UpdateFloatingIpResponseFloatingIpDnsPtrItem = CreateFloatingIpResponseFloatingIpDnsPtrItem;
export declare const UpdateFloatingIpResponseFloatingIpDnsPtrItem: S.Schema<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
/** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
export type UpdateFloatingIpResponseFloatingIpDnsPtrList = Array<CreateFloatingIpResponseFloatingIpDnsPtrItem>;
export declare const UpdateFloatingIpResponseFloatingIpDnsPtrList: S.Schema<UpdateFloatingIpResponseFloatingIpDnsPtrList>;
export type UpdateFloatingIpResponseFloatingIpHomeLocation = CreateFloatingIpResponseFloatingIpHomeLocation;
export declare const UpdateFloatingIpResponseFloatingIpHomeLocation: S.Schema<CreateFloatingIpResponseFloatingIpHomeLocation>;
/** Protection configuration for the Resource. */
export type UpdateFloatingIpResponseFloatingIpProtection = CreateFloatingIpResponseFloatingIpProtection;
export declare const UpdateFloatingIpResponseFloatingIpProtection: S.Schema<CreateFloatingIpResponseFloatingIpProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateFloatingIpResponseFloatingIpLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateFloatingIpResponseFloatingIpLabelsMap: S.Schema<UpdateFloatingIpResponseFloatingIpLabelsMap>;
export interface UpdateFloatingIpResponseFloatingIp {
    /** ID of the [Floating IP](#tag/floating-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** Description of the Resource. */
    description: string | null;
    /** IP address. */
    ip: string;
    /** The Floating IP type. */
    type: UpdateFloatingIpResponseFloatingIpType;
    /** [Server](#tag/servers) the [Floating IP](#tag/floating-ips) is assigned to. `null` if not assigned. */
    server: number | null;
    /** List of reverse DNS entries for the [Floating IP](#tag/floating-ips). */
    dns_ptr: UpdateFloatingIpResponseFloatingIpDnsPtrList;
    home_location: CreateFloatingIpResponseFloatingIpHomeLocation;
    /** Indicates whether the [Floating IP](#tag/floating-ips) is blocked. */
    blocked: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateFloatingIpResponseFloatingIpProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateFloatingIpResponseFloatingIpLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
}
export declare const UpdateFloatingIpResponseFloatingIp: S.Schema<UpdateFloatingIpResponseFloatingIp>;
export interface UpdateFloatingIpResponse {
    floating_ip: UpdateFloatingIpResponseFloatingIp;
}
export declare const UpdateFloatingIpResponse: S.Schema<UpdateFloatingIpResponse>;
export type CreateFloatingIpError = HetznerOpError;
/** Create a Floating IP Create a [Floating IP](#tag/floating-ips). Provide the `server` attribute to assign the [Floating IP](#tag/floating-ips) to that server or provide a `home_location` to locate the [Floating IP](#tag/floating-ips) at. Note that the [Floating IP](#tag/floating-ips) can be assigned to a [Server](#tag/servers) in any [Location](#tag/locations) later on. For optimal routing it is advised to use the [Floating IP](#tag/floating-ips) in the same [Location](#tag/locations) it was created in. */
export declare const createFloatingIp: API.OperationMethod<CreateFloatingIpRequest, CreateFloatingIpResponse, CreateFloatingIpError, HetznerOpContext>;
export type DeleteFloatingIpError = HetznerOpError;
/** Delete a Floating IP Deletes a [Floating IP](#tag/floating-ips). If assigned to a [Server](#tag/servers) the [Floating IP](#tag/floating-ips) will be unassigned automatically until 1 May 2026. After this date, the [Floating IP](#tag/floating-ips) needs to be unassigned before it can be deleted. #### Operation specific errors */
export declare const deleteFloatingIp: API.OperationMethod<DeleteFloatingIpRequest, DeleteFloatingIpResponse, DeleteFloatingIpError, HetznerOpContext>;
export type GetFloatingIpError = HetznerOpError;
/** Get a Floating IP Returns a single [Floating IP](#tag/floating-ips). */
export declare const getFloatingIp: API.OperationMethod<GetFloatingIpRequest, GetFloatingIpResponse, GetFloatingIpError, HetznerOpContext>;
export type ListFloatingIpsError = HetznerOpError;
/** List Floating IPs List multiple [Floating IPs](#tag/floating-ips). Use the provided URI parameters to modify the result. */
export declare const listFloatingIps: API.PaginatedOperationMethod<ListFloatingIpsRequest, ListFloatingIpsResponse, ListFloatingIpsError, HetznerOpContext, ListFloatingIpsResponseFloatingIpsItem>;
export type UpdateFloatingIpError = HetznerOpError;
/** Update a Floating IP Update a [Floating IP](#tag/floating-ips). */
export declare const updateFloatingIp: API.OperationMethod<UpdateFloatingIpRequest, UpdateFloatingIpResponse, UpdateFloatingIpError, HetznerOpContext>;
//# sourceMappingURL=floating_ips.d.ts.map