import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Type of the [RRSet](#tag/zone-rrsets). */
export type CreateZoneRrsetRequestType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const CreateZoneRrsetRequestType: any;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export interface CreateZoneRrsetRequestRecordsItem {
    /** Value of the record. For details about accepted values, see the [DNS record types documentation](https://docs.hetzner.com/networking/dns/record-types/overview/). */
    value: string;
    /** Comment of the record. */
    comment?: string;
}
export declare const CreateZoneRrsetRequestRecordsItem: S.Schema<CreateZoneRrsetRequestRecordsItem>;
/** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
export type CreateZoneRrsetRequestRecordsList = Array<CreateZoneRrsetRequestRecordsItem>;
export declare const CreateZoneRrsetRequestRecordsList: S.Schema<CreateZoneRrsetRequestRecordsList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateZoneRrsetRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateZoneRrsetRequestLabelsMap: S.Schema<CreateZoneRrsetRequestLabelsMap>;
export interface CreateZoneRrsetRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Name of the [RRSet](#tag/zone-rrsets). The name must be in lower case, and must not end with a dot or the [Zone](#tag/zones) name. Names containing non-ASCII characters must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--4bi` (✉️). For the [Zone](#tag/zones) apex, use `@`. */
    name: string;
    /** Type of the [RRSet](#tag/zone-rrsets). */
    type: CreateZoneRrsetRequestType | (string & {});
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl?: number | null;
    /** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
    records: CreateZoneRrsetRequestRecordsList;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateZoneRrsetRequestLabelsMap;
}
export declare const CreateZoneRrsetRequest: S.Schema<CreateZoneRrsetRequest>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type CreateZoneRrsetResponseRrsetType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const CreateZoneRrsetResponseRrsetType: any;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateZoneRrsetResponseRrsetLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateZoneRrsetResponseRrsetLabelsMap: S.Schema<CreateZoneRrsetResponseRrsetLabelsMap>;
/** Protection of the [RRSet](#tag/zone-rrsets). */
export interface CreateZoneRrsetResponseRrsetProtection {
    /** Prevent the Resource from being changed. */
    change: boolean;
}
export declare const CreateZoneRrsetResponseRrsetProtection: S.Schema<CreateZoneRrsetResponseRrsetProtection>;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export type CreateZoneRrsetResponseRrsetRecordsItem = CreateZoneRrsetRequestRecordsItem;
export declare const CreateZoneRrsetResponseRrsetRecordsItem: S.Schema<CreateZoneRrsetRequestRecordsItem>;
/** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
export type CreateZoneRrsetResponseRrsetRecordsList = Array<CreateZoneRrsetRequestRecordsItem>;
export declare const CreateZoneRrsetResponseRrsetRecordsList: S.Schema<CreateZoneRrsetResponseRrsetRecordsList>;
export interface CreateZoneRrsetResponseRrset {
    /** ID of the RRSet. The ID is composed of the name and type, joined with a slash (e.g. `www/AAAA`). */
    id: string;
    /** Name of the [RRSet](#tag/zone-rrsets). The name must be in lower case, and must not end with a dot or the [Zone](#tag/zones) name. Names containing non-ASCII characters must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--4bi` (✉️). For the [Zone](#tag/zones) apex, use `@`. */
    name: string;
    /** Type of the [RRSet](#tag/zone-rrsets). */
    type: CreateZoneRrsetResponseRrsetType;
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl: number | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateZoneRrsetResponseRrsetLabelsMap;
    /** Protection of the [RRSet](#tag/zone-rrsets). */
    protection: CreateZoneRrsetResponseRrsetProtection;
    /** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
    records: CreateZoneRrsetResponseRrsetRecordsList;
    /** ID of the [Zone](#tag/zones). */
    zone: number;
}
export declare const CreateZoneRrsetResponseRrset: S.Schema<CreateZoneRrsetResponseRrset>;
/** Status of the Action. */
export type CreateZoneRrsetResponseActionStatus = "running" | "success" | "error";
export declare const CreateZoneRrsetResponseActionStatus: any;
export interface CreateZoneRrsetResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateZoneRrsetResponseActionResourcesItem: S.Schema<CreateZoneRrsetResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateZoneRrsetResponseActionResourcesList = Array<CreateZoneRrsetResponseActionResourcesItem>;
export declare const CreateZoneRrsetResponseActionResourcesList: S.Schema<CreateZoneRrsetResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateZoneRrsetResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateZoneRrsetResponseActionError: S.Schema<CreateZoneRrsetResponseActionError>;
export interface CreateZoneRrsetResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateZoneRrsetResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateZoneRrsetResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateZoneRrsetResponseActionError | null;
}
export declare const CreateZoneRrsetResponseAction: S.Schema<CreateZoneRrsetResponseAction>;
export interface CreateZoneRrsetResponse {
    rrset: CreateZoneRrsetResponseRrset;
    action: CreateZoneRrsetResponseAction;
}
export declare const CreateZoneRrsetResponse: S.Schema<CreateZoneRrsetResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type DeleteZoneRrsetRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const DeleteZoneRrsetRequestRrType: any;
export interface DeleteZoneRrsetRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: DeleteZoneRrsetRequestRrType | (string & {});
}
export declare const DeleteZoneRrsetRequest: S.Schema<DeleteZoneRrsetRequest>;
/** Status of the Action. */
export type DeleteZoneRrsetResponseActionStatus = "running" | "success" | "error";
export declare const DeleteZoneRrsetResponseActionStatus: any;
export type DeleteZoneRrsetResponseActionResourcesItem = CreateZoneRrsetResponseActionResourcesItem;
export declare const DeleteZoneRrsetResponseActionResourcesItem: S.Schema<CreateZoneRrsetResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DeleteZoneRrsetResponseActionResourcesList = Array<CreateZoneRrsetResponseActionResourcesItem>;
export declare const DeleteZoneRrsetResponseActionResourcesList: S.Schema<DeleteZoneRrsetResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DeleteZoneRrsetResponseActionError = CreateZoneRrsetResponseActionError;
export declare const DeleteZoneRrsetResponseActionError: S.Schema<CreateZoneRrsetResponseActionError>;
export interface DeleteZoneRrsetResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DeleteZoneRrsetResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DeleteZoneRrsetResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateZoneRrsetResponseActionError | null;
}
export declare const DeleteZoneRrsetResponseAction: S.Schema<DeleteZoneRrsetResponseAction>;
export interface DeleteZoneRrsetResponse {
    action: DeleteZoneRrsetResponseAction;
}
export declare const DeleteZoneRrsetResponse: S.Schema<DeleteZoneRrsetResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type GetZoneRrsetRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const GetZoneRrsetRequestRrType: any;
export interface GetZoneRrsetRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: GetZoneRrsetRequestRrType | (string & {});
}
export declare const GetZoneRrsetRequest: S.Schema<GetZoneRrsetRequest>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type GetZoneRrsetResponseRrsetType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const GetZoneRrsetResponseRrsetType: any;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetZoneRrsetResponseRrsetLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetZoneRrsetResponseRrsetLabelsMap: S.Schema<GetZoneRrsetResponseRrsetLabelsMap>;
/** Protection of the [RRSet](#tag/zone-rrsets). */
export type GetZoneRrsetResponseRrsetProtection = CreateZoneRrsetResponseRrsetProtection;
export declare const GetZoneRrsetResponseRrsetProtection: S.Schema<CreateZoneRrsetResponseRrsetProtection>;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export type GetZoneRrsetResponseRrsetRecordsItem = CreateZoneRrsetRequestRecordsItem;
export declare const GetZoneRrsetResponseRrsetRecordsItem: S.Schema<CreateZoneRrsetRequestRecordsItem>;
/** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
export type GetZoneRrsetResponseRrsetRecordsList = Array<CreateZoneRrsetRequestRecordsItem>;
export declare const GetZoneRrsetResponseRrsetRecordsList: S.Schema<GetZoneRrsetResponseRrsetRecordsList>;
export interface GetZoneRrsetResponseRrset {
    /** ID of the RRSet. The ID is composed of the name and type, joined with a slash (e.g. `www/AAAA`). */
    id: string;
    /** Name of the [RRSet](#tag/zone-rrsets). The name must be in lower case, and must not end with a dot or the [Zone](#tag/zones) name. Names containing non-ASCII characters must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--4bi` (✉️). For the [Zone](#tag/zones) apex, use `@`. */
    name: string;
    /** Type of the [RRSet](#tag/zone-rrsets). */
    type: GetZoneRrsetResponseRrsetType;
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl: number | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetZoneRrsetResponseRrsetLabelsMap;
    /** Protection of the [RRSet](#tag/zone-rrsets). */
    protection: CreateZoneRrsetResponseRrsetProtection;
    /** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
    records: GetZoneRrsetResponseRrsetRecordsList;
    /** ID of the [Zone](#tag/zones). */
    zone: number;
}
export declare const GetZoneRrsetResponseRrset: S.Schema<GetZoneRrsetResponseRrset>;
export interface GetZoneRrsetResponse {
    rrset: GetZoneRrsetResponseRrset;
}
export declare const GetZoneRrsetResponse: S.Schema<GetZoneRrsetResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type ListZoneRrsetsRequestTypeItem = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const ListZoneRrsetsRequestTypeItem: any;
export type ListZoneRrsetsRequestTypeList = Array<ListZoneRrsetsRequestTypeItem | (string & {})>;
export declare const ListZoneRrsetsRequestTypeList: S.Schema<ListZoneRrsetsRequestTypeList>;
export type ListZoneRrsetsRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListZoneRrsetsRequestSortItem: any;
export type ListZoneRrsetsRequestSortList = Array<ListZoneRrsetsRequestSortItem | (string & {})>;
export declare const ListZoneRrsetsRequestSortList: S.Schema<ListZoneRrsetsRequestSortList>;
export interface ListZoneRrsetsRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by their type. May be used multiple times. The response will only contain resources matching the specified types. */
    type?: ListZoneRrsetsRequestTypeList;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListZoneRrsetsRequestSortList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListZoneRrsetsRequest: S.Schema<ListZoneRrsetsRequest>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type ListZoneRrsetsResponseRrsetsItemType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const ListZoneRrsetsResponseRrsetsItemType: any;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListZoneRrsetsResponseRrsetsItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListZoneRrsetsResponseRrsetsItemLabelsMap: S.Schema<ListZoneRrsetsResponseRrsetsItemLabelsMap>;
/** Protection of the [RRSet](#tag/zone-rrsets). */
export type ListZoneRrsetsResponseRrsetsItemProtection = CreateZoneRrsetResponseRrsetProtection;
export declare const ListZoneRrsetsResponseRrsetsItemProtection: S.Schema<CreateZoneRrsetResponseRrsetProtection>;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export type ListZoneRrsetsResponseRrsetsItemRecordsItem = CreateZoneRrsetRequestRecordsItem;
export declare const ListZoneRrsetsResponseRrsetsItemRecordsItem: S.Schema<CreateZoneRrsetRequestRecordsItem>;
/** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
export type ListZoneRrsetsResponseRrsetsItemRecordsList = Array<CreateZoneRrsetRequestRecordsItem>;
export declare const ListZoneRrsetsResponseRrsetsItemRecordsList: S.Schema<ListZoneRrsetsResponseRrsetsItemRecordsList>;
export interface ListZoneRrsetsResponseRrsetsItem {
    /** ID of the RRSet. The ID is composed of the name and type, joined with a slash (e.g. `www/AAAA`). */
    id: string;
    /** Name of the [RRSet](#tag/zone-rrsets). The name must be in lower case, and must not end with a dot or the [Zone](#tag/zones) name. Names containing non-ASCII characters must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--4bi` (✉️). For the [Zone](#tag/zones) apex, use `@`. */
    name: string;
    /** Type of the [RRSet](#tag/zone-rrsets). */
    type: ListZoneRrsetsResponseRrsetsItemType;
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl: number | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListZoneRrsetsResponseRrsetsItemLabelsMap;
    /** Protection of the [RRSet](#tag/zone-rrsets). */
    protection: CreateZoneRrsetResponseRrsetProtection;
    /** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
    records: ListZoneRrsetsResponseRrsetsItemRecordsList;
    /** ID of the [Zone](#tag/zones). */
    zone: number;
}
export declare const ListZoneRrsetsResponseRrsetsItem: S.Schema<ListZoneRrsetsResponseRrsetsItem>;
export type ListZoneRrsetsResponseRrsetsList = Array<ListZoneRrsetsResponseRrsetsItem>;
export declare const ListZoneRrsetsResponseRrsetsList: S.Schema<ListZoneRrsetsResponseRrsetsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListZoneRrsetsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListZoneRrsetsResponseMetaPagination: S.Schema<ListZoneRrsetsResponseMetaPagination>;
export interface ListZoneRrsetsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListZoneRrsetsResponseMetaPagination;
}
export declare const ListZoneRrsetsResponseMeta: S.Schema<ListZoneRrsetsResponseMeta>;
export interface ListZoneRrsetsResponse {
    rrsets: ListZoneRrsetsResponseRrsetsList;
    meta: ListZoneRrsetsResponseMeta;
}
export declare const ListZoneRrsetsResponse: S.Schema<ListZoneRrsetsResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type UpdateZoneRrsetRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const UpdateZoneRrsetRequestRrType: any;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateZoneRrsetRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateZoneRrsetRequestLabelsMap: S.Schema<UpdateZoneRrsetRequestLabelsMap>;
export interface UpdateZoneRrsetRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: UpdateZoneRrsetRequestRrType | (string & {});
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateZoneRrsetRequestLabelsMap;
}
export declare const UpdateZoneRrsetRequest: S.Schema<UpdateZoneRrsetRequest>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type UpdateZoneRrsetResponseRrsetType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const UpdateZoneRrsetResponseRrsetType: any;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateZoneRrsetResponseRrsetLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateZoneRrsetResponseRrsetLabelsMap: S.Schema<UpdateZoneRrsetResponseRrsetLabelsMap>;
/** Protection of the [RRSet](#tag/zone-rrsets). */
export type UpdateZoneRrsetResponseRrsetProtection = CreateZoneRrsetResponseRrsetProtection;
export declare const UpdateZoneRrsetResponseRrsetProtection: S.Schema<CreateZoneRrsetResponseRrsetProtection>;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export type UpdateZoneRrsetResponseRrsetRecordsItem = CreateZoneRrsetRequestRecordsItem;
export declare const UpdateZoneRrsetResponseRrsetRecordsItem: S.Schema<CreateZoneRrsetRequestRecordsItem>;
/** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
export type UpdateZoneRrsetResponseRrsetRecordsList = Array<CreateZoneRrsetRequestRecordsItem>;
export declare const UpdateZoneRrsetResponseRrsetRecordsList: S.Schema<UpdateZoneRrsetResponseRrsetRecordsList>;
export interface UpdateZoneRrsetResponseRrset {
    /** ID of the RRSet. The ID is composed of the name and type, joined with a slash (e.g. `www/AAAA`). */
    id: string;
    /** Name of the [RRSet](#tag/zone-rrsets). The name must be in lower case, and must not end with a dot or the [Zone](#tag/zones) name. Names containing non-ASCII characters must be transcribed to [Punycode](https://wikipedia.org/wiki/Punycode) representation with ACE prefix, e.g. `xn--4bi` (✉️). For the [Zone](#tag/zones) apex, use `@`. */
    name: string;
    /** Type of the [RRSet](#tag/zone-rrsets). */
    type: UpdateZoneRrsetResponseRrsetType;
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl: number | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateZoneRrsetResponseRrsetLabelsMap;
    /** Protection of the [RRSet](#tag/zone-rrsets). */
    protection: CreateZoneRrsetResponseRrsetProtection;
    /** Records of the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. The order of records returned in responses is not guaranteed to be consistent. */
    records: UpdateZoneRrsetResponseRrsetRecordsList;
    /** ID of the [Zone](#tag/zones). */
    zone: number;
}
export declare const UpdateZoneRrsetResponseRrset: S.Schema<UpdateZoneRrsetResponseRrset>;
export interface UpdateZoneRrsetResponse {
    rrset: UpdateZoneRrsetResponseRrset;
}
export declare const UpdateZoneRrsetResponse: S.Schema<UpdateZoneRrsetResponse>;
export type CreateZoneRrsetError = HetznerOpError;
/** Create an RRSet Create an [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const createZoneRrset: API.OperationMethod<CreateZoneRrsetRequest, CreateZoneRrsetResponse, CreateZoneRrsetError, HetznerOpContext>;
export type DeleteZoneRrsetError = HetznerOpError;
/** Delete an RRSet Deletes an [RRSet](#tag/zone-rrsets) from the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const deleteZoneRrset: API.OperationMethod<DeleteZoneRrsetRequest, DeleteZoneRrsetResponse, DeleteZoneRrsetError, HetznerOpContext>;
export type GetZoneRrsetError = HetznerOpError;
/** Get an RRSet Returns a single [RRSet](#tag/zone-rrsets) from the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const getZoneRrset: API.OperationMethod<GetZoneRrsetRequest, GetZoneRrsetResponse, GetZoneRrsetError, HetznerOpContext>;
export type ListZoneRrsetsError = HetznerOpError;
/** List RRSets Returns all [RRSets](#tag/zone-rrsets) in the [Zone](#tag/zones). Use the provided URI parameters to modify the result. The maximum value for `per_page` on this endpoint is `100` instead of `50`. Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const listZoneRrsets: API.PaginatedOperationMethod<ListZoneRrsetsRequest, ListZoneRrsetsResponse, ListZoneRrsetsError, HetznerOpContext, ListZoneRrsetsResponseRrsetsItem>;
export type UpdateZoneRrsetError = HetznerOpError;
/** Update an RRSet Updates an [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const updateZoneRrset: API.OperationMethod<UpdateZoneRrsetRequest, UpdateZoneRrsetResponse, UpdateZoneRrsetError, HetznerOpContext>;
//# sourceMappingURL=zone_rrsets.d.ts.map