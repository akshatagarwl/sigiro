import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
declare const PrimaryIpLimitExceeded_base: S.Class<PrimaryIpLimitExceeded, S.TaggedStruct<"PrimaryIpLimitExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
/** The project has no remaining Primary IP quota (Hetzner `resource_limit_exceeded`, HTTP 403). Often transient — Servers hold auto-created Primary IP pairs that free up on delete — retry. */
export declare class PrimaryIpLimitExceeded extends /*@__PURE__*/ PrimaryIpLimitExceeded_base {
}
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreatePrimaryIpRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreatePrimaryIpRequestLabelsMap: S.Schema<CreatePrimaryIpRequestLabelsMap>;
/** [Primary IP](#tag/primary-ips) type. */
export type CreatePrimaryIpRequestType = "ipv4" | "ipv6";
export declare const CreatePrimaryIpRequestType: any;
/** [Location](#tag/locations) ID or name the [Primary IP](#tag/primary-ips) will be bound to. Omit if `assignee_id`/`assignee_type` or `datacenter` are provided. */
export type CreatePrimaryIpRequestLocation = string | number;
export declare const CreatePrimaryIpRequestLocation: S.Schema<CreatePrimaryIpRequestLocation>;
/** Type of resource to assign the [Primary IP](#tag/primary-ips) to. Omitted if the [Primary IP](#tag/primary-ips) should not get assigned. */
export type CreatePrimaryIpRequestAssigneeType = "server";
export declare const CreatePrimaryIpRequestAssigneeType: any;
export interface CreatePrimaryIpRequest {
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreatePrimaryIpRequestLabelsMap;
    /** [Primary IP](#tag/primary-ips) type. */
    type: CreatePrimaryIpRequestType | (string & {});
    /** [Location](#tag/locations) ID or name the [Primary IP](#tag/primary-ips) will be bound to. Omit if `assignee_id`/`assignee_type` or `datacenter` are provided. */
    location?: CreatePrimaryIpRequestLocation;
    /** Type of resource to assign the [Primary IP](#tag/primary-ips) to. Omitted if the [Primary IP](#tag/primary-ips) should not get assigned. */
    assignee_type?: CreatePrimaryIpRequestAssigneeType | (string & {});
    /** ID of resource to assign the [Primary IP](#tag/primary-ips) to. Omitted if the [Primary IP](#tag/primary-ips) should not get assigned. */
    assignee_id?: number | null;
    /** Auto deletion state. If enabled the [Primary IP](#tag/primary-ips) will be deleted once the assigned resource gets deleted. */
    auto_delete?: boolean;
}
export declare const CreatePrimaryIpRequest: S.Schema<CreatePrimaryIpRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreatePrimaryIpResponsePrimaryIpLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreatePrimaryIpResponsePrimaryIpLabelsMap: S.Schema<CreatePrimaryIpResponsePrimaryIpLabelsMap>;
/** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
export interface CreatePrimaryIpResponsePrimaryIpLocation {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Unique identifier of the [Location](#tag/locations). */
    name: string;
    /** Human readable description of the [Location](#tag/locations). */
    description: string;
    /** Country the [Location](#tag/locations) resides in. ISO 3166-1 alpha-2 code of the country. */
    country: string;
    /** Name of the closest city to the [Location](#tag/locations). City name or city name and state in short form. E.g. `Falkenstein` or `Ashburn, VA`. */
    city: string;
    /** Latitude of the city closest to the [Location](#tag/locations). */
    latitude: number;
    /** Longitude of the city closest to the [Location](#tag/locations). */
    longitude: number;
    /** Name of the Network Zone this [Location](#tag/locations) resides in. */
    network_zone: string;
}
export declare const CreatePrimaryIpResponsePrimaryIpLocation: S.Schema<CreatePrimaryIpResponsePrimaryIpLocation>;
export interface CreatePrimaryIpResponsePrimaryIpDnsPtrItem {
    /** Single IPv4 or IPv6 address of the record. */
    ip: string;
    /** Domain Name to point to. PTR record content used for reverse DNS. */
    dns_ptr: string;
}
export declare const CreatePrimaryIpResponsePrimaryIpDnsPtrItem: S.Schema<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
/** List of reverse DNS records. */
export type CreatePrimaryIpResponsePrimaryIpDnsPtrList = Array<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
export declare const CreatePrimaryIpResponsePrimaryIpDnsPtrList: S.Schema<CreatePrimaryIpResponsePrimaryIpDnsPtrList>;
/** Protection configuration for the Resource. */
export interface CreatePrimaryIpResponsePrimaryIpProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreatePrimaryIpResponsePrimaryIpProtection: S.Schema<CreatePrimaryIpResponsePrimaryIpProtection>;
/** [Primary IP](#tag/primary-ips) type. */
export type CreatePrimaryIpResponsePrimaryIpType = "ipv4" | "ipv6";
export declare const CreatePrimaryIpResponsePrimaryIpType: any;
/** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
export type CreatePrimaryIpResponsePrimaryIpAssigneeType = "server";
export declare const CreatePrimaryIpResponsePrimaryIpAssigneeType: any;
export interface CreatePrimaryIpResponsePrimaryIp {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreatePrimaryIpResponsePrimaryIpLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Blocked state of the [Primary IP](#tag/primary-ips). */
    blocked: boolean;
    /** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
    location: CreatePrimaryIpResponsePrimaryIpLocation;
    /** IP address. */
    ip: string;
    /** List of reverse DNS records. */
    dns_ptr: CreatePrimaryIpResponsePrimaryIpDnsPtrList;
    /** Protection configuration for the Resource. */
    protection: CreatePrimaryIpResponsePrimaryIpProtection;
    /** [Primary IP](#tag/primary-ips) type. */
    type: CreatePrimaryIpResponsePrimaryIpType;
    /** Auto deletion state. If enabled the [Primary IP](#tag/primary-ips) will be deleted once the assigned resource gets deleted. */
    auto_delete: boolean;
    /** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_type: CreatePrimaryIpResponsePrimaryIpAssigneeType;
    /** ID of resource the [Primary IP](#tag/primary-ips) is assigned to. `null` if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_id: number | null;
}
export declare const CreatePrimaryIpResponsePrimaryIp: S.Schema<CreatePrimaryIpResponsePrimaryIp>;
/** Status of the Action. */
export type CreatePrimaryIpResponseActionStatus = "running" | "success" | "error";
export declare const CreatePrimaryIpResponseActionStatus: any;
export interface CreatePrimaryIpResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreatePrimaryIpResponseActionResourcesItem: S.Schema<CreatePrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreatePrimaryIpResponseActionResourcesList = Array<CreatePrimaryIpResponseActionResourcesItem>;
export declare const CreatePrimaryIpResponseActionResourcesList: S.Schema<CreatePrimaryIpResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreatePrimaryIpResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreatePrimaryIpResponseActionError: S.Schema<CreatePrimaryIpResponseActionError>;
/** Action will only be returned if the [Primary IP](#tag/primary-ips) is getting assigned. */
export interface CreatePrimaryIpResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreatePrimaryIpResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreatePrimaryIpResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreatePrimaryIpResponseActionError | null;
}
export declare const CreatePrimaryIpResponseAction: S.Schema<CreatePrimaryIpResponseAction>;
export interface CreatePrimaryIpResponse {
    primary_ip: CreatePrimaryIpResponsePrimaryIp;
    /** Action will only be returned if the [Primary IP](#tag/primary-ips) is getting assigned. */
    action?: CreatePrimaryIpResponseAction | null;
}
export declare const CreatePrimaryIpResponse: S.Schema<CreatePrimaryIpResponse>;
export interface DeletePrimaryIpRequest {
    /** ID of the Primary IP. */
    id: number;
}
export declare const DeletePrimaryIpRequest: S.Schema<DeletePrimaryIpRequest>;
export interface DeletePrimaryIpResponse {
}
export declare const DeletePrimaryIpResponse: S.Schema<DeletePrimaryIpResponse>;
export interface GetPrimaryIpRequest {
    /** ID of the Primary IP. */
    id: number;
}
export declare const GetPrimaryIpRequest: S.Schema<GetPrimaryIpRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetPrimaryIpResponsePrimaryIpLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetPrimaryIpResponsePrimaryIpLabelsMap: S.Schema<GetPrimaryIpResponsePrimaryIpLabelsMap>;
/** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
export type GetPrimaryIpResponsePrimaryIpLocation = CreatePrimaryIpResponsePrimaryIpLocation;
export declare const GetPrimaryIpResponsePrimaryIpLocation: S.Schema<CreatePrimaryIpResponsePrimaryIpLocation>;
export type GetPrimaryIpResponsePrimaryIpDnsPtrItem = CreatePrimaryIpResponsePrimaryIpDnsPtrItem;
export declare const GetPrimaryIpResponsePrimaryIpDnsPtrItem: S.Schema<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
/** List of reverse DNS records. */
export type GetPrimaryIpResponsePrimaryIpDnsPtrList = Array<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
export declare const GetPrimaryIpResponsePrimaryIpDnsPtrList: S.Schema<GetPrimaryIpResponsePrimaryIpDnsPtrList>;
/** Protection configuration for the Resource. */
export type GetPrimaryIpResponsePrimaryIpProtection = CreatePrimaryIpResponsePrimaryIpProtection;
export declare const GetPrimaryIpResponsePrimaryIpProtection: S.Schema<CreatePrimaryIpResponsePrimaryIpProtection>;
/** [Primary IP](#tag/primary-ips) type. */
export type GetPrimaryIpResponsePrimaryIpType = "ipv4" | "ipv6";
export declare const GetPrimaryIpResponsePrimaryIpType: any;
/** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
export type GetPrimaryIpResponsePrimaryIpAssigneeType = "server";
export declare const GetPrimaryIpResponsePrimaryIpAssigneeType: any;
export interface GetPrimaryIpResponsePrimaryIp {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetPrimaryIpResponsePrimaryIpLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Blocked state of the [Primary IP](#tag/primary-ips). */
    blocked: boolean;
    /** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
    location: CreatePrimaryIpResponsePrimaryIpLocation;
    /** IP address. */
    ip: string;
    /** List of reverse DNS records. */
    dns_ptr: GetPrimaryIpResponsePrimaryIpDnsPtrList;
    /** Protection configuration for the Resource. */
    protection: CreatePrimaryIpResponsePrimaryIpProtection;
    /** [Primary IP](#tag/primary-ips) type. */
    type: GetPrimaryIpResponsePrimaryIpType;
    /** Auto deletion state. If enabled the [Primary IP](#tag/primary-ips) will be deleted once the assigned resource gets deleted. */
    auto_delete: boolean;
    /** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_type: GetPrimaryIpResponsePrimaryIpAssigneeType;
    /** ID of resource the [Primary IP](#tag/primary-ips) is assigned to. `null` if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_id: number | null;
}
export declare const GetPrimaryIpResponsePrimaryIp: S.Schema<GetPrimaryIpResponsePrimaryIp>;
export interface GetPrimaryIpResponse {
    primary_ip: GetPrimaryIpResponsePrimaryIp;
}
export declare const GetPrimaryIpResponse: S.Schema<GetPrimaryIpResponse>;
export type ListPrimaryIpsRequestSortItem = "id" | "id:asc" | "id:desc" | "created" | "created:asc" | "created:desc";
export declare const ListPrimaryIpsRequestSortItem: any;
export type ListPrimaryIpsRequestSortList = Array<ListPrimaryIpsRequestSortItem | (string & {})>;
export declare const ListPrimaryIpsRequestSortList: S.Schema<ListPrimaryIpsRequestSortList>;
export interface ListPrimaryIpsRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Filter results by IP address. */
    ip?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListPrimaryIpsRequestSortList;
}
export declare const ListPrimaryIpsRequest: S.Schema<ListPrimaryIpsRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListPrimaryIpsResponsePrimaryIpsItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListPrimaryIpsResponsePrimaryIpsItemLabelsMap: S.Schema<ListPrimaryIpsResponsePrimaryIpsItemLabelsMap>;
/** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
export type ListPrimaryIpsResponsePrimaryIpsItemLocation = CreatePrimaryIpResponsePrimaryIpLocation;
export declare const ListPrimaryIpsResponsePrimaryIpsItemLocation: S.Schema<CreatePrimaryIpResponsePrimaryIpLocation>;
export type ListPrimaryIpsResponsePrimaryIpsItemDnsPtrItem = CreatePrimaryIpResponsePrimaryIpDnsPtrItem;
export declare const ListPrimaryIpsResponsePrimaryIpsItemDnsPtrItem: S.Schema<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
/** List of reverse DNS records. */
export type ListPrimaryIpsResponsePrimaryIpsItemDnsPtrList = Array<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
export declare const ListPrimaryIpsResponsePrimaryIpsItemDnsPtrList: S.Schema<ListPrimaryIpsResponsePrimaryIpsItemDnsPtrList>;
/** Protection configuration for the Resource. */
export type ListPrimaryIpsResponsePrimaryIpsItemProtection = CreatePrimaryIpResponsePrimaryIpProtection;
export declare const ListPrimaryIpsResponsePrimaryIpsItemProtection: S.Schema<CreatePrimaryIpResponsePrimaryIpProtection>;
/** [Primary IP](#tag/primary-ips) type. */
export type ListPrimaryIpsResponsePrimaryIpsItemType = "ipv4" | "ipv6";
export declare const ListPrimaryIpsResponsePrimaryIpsItemType: any;
/** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
export type ListPrimaryIpsResponsePrimaryIpsItemAssigneeType = "server";
export declare const ListPrimaryIpsResponsePrimaryIpsItemAssigneeType: any;
export interface ListPrimaryIpsResponsePrimaryIpsItem {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListPrimaryIpsResponsePrimaryIpsItemLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Blocked state of the [Primary IP](#tag/primary-ips). */
    blocked: boolean;
    /** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
    location: CreatePrimaryIpResponsePrimaryIpLocation;
    /** IP address. */
    ip: string;
    /** List of reverse DNS records. */
    dns_ptr: ListPrimaryIpsResponsePrimaryIpsItemDnsPtrList;
    /** Protection configuration for the Resource. */
    protection: CreatePrimaryIpResponsePrimaryIpProtection;
    /** [Primary IP](#tag/primary-ips) type. */
    type: ListPrimaryIpsResponsePrimaryIpsItemType;
    /** Auto deletion state. If enabled the [Primary IP](#tag/primary-ips) will be deleted once the assigned resource gets deleted. */
    auto_delete: boolean;
    /** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_type: ListPrimaryIpsResponsePrimaryIpsItemAssigneeType;
    /** ID of resource the [Primary IP](#tag/primary-ips) is assigned to. `null` if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_id: number | null;
}
export declare const ListPrimaryIpsResponsePrimaryIpsItem: S.Schema<ListPrimaryIpsResponsePrimaryIpsItem>;
export type ListPrimaryIpsResponsePrimaryIpsList = Array<ListPrimaryIpsResponsePrimaryIpsItem>;
export declare const ListPrimaryIpsResponsePrimaryIpsList: S.Schema<ListPrimaryIpsResponsePrimaryIpsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListPrimaryIpsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListPrimaryIpsResponseMetaPagination: S.Schema<ListPrimaryIpsResponseMetaPagination>;
export interface ListPrimaryIpsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListPrimaryIpsResponseMetaPagination;
}
export declare const ListPrimaryIpsResponseMeta: S.Schema<ListPrimaryIpsResponseMeta>;
export interface ListPrimaryIpsResponse {
    primary_ips: ListPrimaryIpsResponsePrimaryIpsList;
    meta: ListPrimaryIpsResponseMeta;
}
export declare const ListPrimaryIpsResponse: S.Schema<ListPrimaryIpsResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdatePrimaryIpRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdatePrimaryIpRequestLabelsMap: S.Schema<UpdatePrimaryIpRequestLabelsMap>;
export interface UpdatePrimaryIpRequest {
    /** ID of the Primary IP. */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdatePrimaryIpRequestLabelsMap;
    /** Auto deletion state. If enabled the [Primary IP](#tag/primary-ips) will be deleted once the assigned resource gets deleted. */
    auto_delete?: boolean;
}
export declare const UpdatePrimaryIpRequest: S.Schema<UpdatePrimaryIpRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdatePrimaryIpResponsePrimaryIpLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdatePrimaryIpResponsePrimaryIpLabelsMap: S.Schema<UpdatePrimaryIpResponsePrimaryIpLabelsMap>;
/** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
export type UpdatePrimaryIpResponsePrimaryIpLocation = CreatePrimaryIpResponsePrimaryIpLocation;
export declare const UpdatePrimaryIpResponsePrimaryIpLocation: S.Schema<CreatePrimaryIpResponsePrimaryIpLocation>;
export type UpdatePrimaryIpResponsePrimaryIpDnsPtrItem = CreatePrimaryIpResponsePrimaryIpDnsPtrItem;
export declare const UpdatePrimaryIpResponsePrimaryIpDnsPtrItem: S.Schema<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
/** List of reverse DNS records. */
export type UpdatePrimaryIpResponsePrimaryIpDnsPtrList = Array<CreatePrimaryIpResponsePrimaryIpDnsPtrItem>;
export declare const UpdatePrimaryIpResponsePrimaryIpDnsPtrList: S.Schema<UpdatePrimaryIpResponsePrimaryIpDnsPtrList>;
/** Protection configuration for the Resource. */
export type UpdatePrimaryIpResponsePrimaryIpProtection = CreatePrimaryIpResponsePrimaryIpProtection;
export declare const UpdatePrimaryIpResponsePrimaryIpProtection: S.Schema<CreatePrimaryIpResponsePrimaryIpProtection>;
/** [Primary IP](#tag/primary-ips) type. */
export type UpdatePrimaryIpResponsePrimaryIpType = "ipv4" | "ipv6";
export declare const UpdatePrimaryIpResponsePrimaryIpType: any;
/** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
export type UpdatePrimaryIpResponsePrimaryIpAssigneeType = "server";
export declare const UpdatePrimaryIpResponsePrimaryIpAssigneeType: any;
export interface UpdatePrimaryIpResponsePrimaryIp {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdatePrimaryIpResponsePrimaryIpLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Blocked state of the [Primary IP](#tag/primary-ips). */
    blocked: boolean;
    /** [Location](#tag/locations) of the [Primary IP](#tag/primary-ips). */
    location: CreatePrimaryIpResponsePrimaryIpLocation;
    /** IP address. */
    ip: string;
    /** List of reverse DNS records. */
    dns_ptr: UpdatePrimaryIpResponsePrimaryIpDnsPtrList;
    /** Protection configuration for the Resource. */
    protection: CreatePrimaryIpResponsePrimaryIpProtection;
    /** [Primary IP](#tag/primary-ips) type. */
    type: UpdatePrimaryIpResponsePrimaryIpType;
    /** Auto deletion state. If enabled the [Primary IP](#tag/primary-ips) will be deleted once the assigned resource gets deleted. */
    auto_delete: boolean;
    /** Type of resource the [Primary IP](#tag/primary-ips) is assigned to. As of 01 August 2026 `unassigned` will be returned if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_type: UpdatePrimaryIpResponsePrimaryIpAssigneeType;
    /** ID of resource the [Primary IP](#tag/primary-ips) is assigned to. `null` if the [Primary IP](#tag/primary-ips) is not assigned. */
    assignee_id: number | null;
}
export declare const UpdatePrimaryIpResponsePrimaryIp: S.Schema<UpdatePrimaryIpResponsePrimaryIp>;
export interface UpdatePrimaryIpResponse {
    primary_ip: UpdatePrimaryIpResponsePrimaryIp;
}
export declare const UpdatePrimaryIpResponse: S.Schema<UpdatePrimaryIpResponse>;
export type CreatePrimaryIpError = PrimaryIpLimitExceeded | HetznerOpError;
/** Create a Primary IP Create a new [Primary IP](#tag/primary-ips). Can optionally be assigned to a resource by providing an `assignee_id` and `assignee_type`. If not assigned to a resource the `location` key needs to be provided. This can be either the ID or the name of the [Location](#tag/locations) this [Primary IP](#tag/primary-ips) shall be created in. A [Primary IP](#tag/primary-ips) can only be assigned to resource in the same [Location](#tag/locations) later on. #### Operation specific errors */
export declare const createPrimaryIp: API.OperationMethod<CreatePrimaryIpRequest, CreatePrimaryIpResponse, CreatePrimaryIpError, HetznerOpContext>;
export type DeletePrimaryIpError = HetznerOpError;
/** Delete a Primary IP Deletes a [Primary IP](#tag/primary-ips). The [Server](#tag/servers) must be powered off (status `off`) in order for this operation to succeed. If assigned to a [Server](#tag/servers) the [Primary IP](#tag/primary-ips) will be unassigned automatically until 1 May 2026. After this date, the [Primary IP](#tag/primary-ips) needs to be unassigned before it can be deleted. #### Operation specific errors */
export declare const deletePrimaryIp: API.OperationMethod<DeletePrimaryIpRequest, DeletePrimaryIpResponse, DeletePrimaryIpError, HetznerOpContext>;
export type GetPrimaryIpError = HetznerOpError;
/** Get a Primary IP Returns a [Primary IP](#tag/primary-ips). */
export declare const getPrimaryIp: API.OperationMethod<GetPrimaryIpRequest, GetPrimaryIpResponse, GetPrimaryIpError, HetznerOpContext>;
export type ListPrimaryIpsError = HetznerOpError;
/** List Primary IPs List multiple [Primary IPs](#tag/primary-ips). Use the provided URI parameters to modify the result. */
export declare const listPrimaryIps: API.PaginatedOperationMethod<ListPrimaryIpsRequest, ListPrimaryIpsResponse, ListPrimaryIpsError, HetznerOpContext, ListPrimaryIpsResponsePrimaryIpsItem>;
export type UpdatePrimaryIpError = HetznerOpError;
/** Update a Primary IP Update a [Primary IP](#tag/primary-ips). If another change is concurrently performed on this [Primary IP](#tag/primary-ips), a error response with code `conflict` will be returned. */
export declare const updatePrimaryIp: API.OperationMethod<UpdatePrimaryIpRequest, UpdatePrimaryIpResponse, UpdatePrimaryIpError, HetznerOpContext>;
//# sourceMappingURL=primary_ips.d.ts.map