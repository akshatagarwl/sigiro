import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Type of the resource. */
export type ApplyFirewallToResourcesRequestApplyToItemType = "server" | "label_selector";
export declare const ApplyFirewallToResourcesRequestApplyToItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export interface ApplyFirewallToResourcesRequestApplyToItemServer {
    /** ID of the [Server](#tag/servers). */
    id: number;
}
export declare const ApplyFirewallToResourcesRequestApplyToItemServer: S.Schema<ApplyFirewallToResourcesRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export interface ApplyFirewallToResourcesRequestApplyToItemLabelSelector {
    /** The selector. */
    selector: string;
}
export declare const ApplyFirewallToResourcesRequestApplyToItemLabelSelector: S.Schema<ApplyFirewallToResourcesRequestApplyToItemLabelSelector>;
export interface ApplyFirewallToResourcesRequestApplyToItem {
    /** Type of the resource. */
    type: ApplyFirewallToResourcesRequestApplyToItemType | (string & {});
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: ApplyFirewallToResourcesRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: ApplyFirewallToResourcesRequestApplyToItemLabelSelector;
}
export declare const ApplyFirewallToResourcesRequestApplyToItem: S.Schema<ApplyFirewallToResourcesRequestApplyToItem>;
/** Resources to apply the [Firewall](#tag/firewalls) to. Extends existing resources. */
export type ApplyFirewallToResourcesRequestApplyToList = Array<ApplyFirewallToResourcesRequestApplyToItem>;
export declare const ApplyFirewallToResourcesRequestApplyToList: S.Schema<ApplyFirewallToResourcesRequestApplyToList>;
export interface ApplyFirewallToResourcesRequest {
    /** ID of the Firewall. */
    id: number;
    /** Resources to apply the [Firewall](#tag/firewalls) to. Extends existing resources. */
    apply_to: ApplyFirewallToResourcesRequestApplyToList;
}
export declare const ApplyFirewallToResourcesRequest: S.Schema<ApplyFirewallToResourcesRequest>;
/** Status of the Action. */
export type ApplyFirewallToResourcesResponseActionsItemStatus = "running" | "success" | "error";
export declare const ApplyFirewallToResourcesResponseActionsItemStatus: any;
export interface ApplyFirewallToResourcesResponseActionsItemResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const ApplyFirewallToResourcesResponseActionsItemResourcesItem: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type ApplyFirewallToResourcesResponseActionsItemResourcesList = Array<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
export declare const ApplyFirewallToResourcesResponseActionsItemResourcesList: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface ApplyFirewallToResourcesResponseActionsItemError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const ApplyFirewallToResourcesResponseActionsItemError: S.Schema<ApplyFirewallToResourcesResponseActionsItemError>;
export interface ApplyFirewallToResourcesResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ApplyFirewallToResourcesResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ApplyFirewallToResourcesResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ApplyFirewallToResourcesResponseActionsItemError | null;
}
export declare const ApplyFirewallToResourcesResponseActionsItem: S.Schema<ApplyFirewallToResourcesResponseActionsItem>;
export type ApplyFirewallToResourcesResponseActionsList = Array<ApplyFirewallToResourcesResponseActionsItem>;
export declare const ApplyFirewallToResourcesResponseActionsList: S.Schema<ApplyFirewallToResourcesResponseActionsList>;
export interface ApplyFirewallToResourcesResponse {
    actions: ApplyFirewallToResourcesResponseActionsList;
}
export declare const ApplyFirewallToResourcesResponse: S.Schema<ApplyFirewallToResourcesResponse>;
export interface GetFirewallsActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetFirewallsActionRequest: S.Schema<GetFirewallsActionRequest>;
/** Status of the Action. */
export type GetFirewallsActionResponseActionStatus = "running" | "success" | "error";
export declare const GetFirewallsActionResponseActionStatus: any;
export type GetFirewallsActionResponseActionResourcesItem = ApplyFirewallToResourcesResponseActionsItemResourcesItem;
export declare const GetFirewallsActionResponseActionResourcesItem: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type GetFirewallsActionResponseActionResourcesList = Array<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
export declare const GetFirewallsActionResponseActionResourcesList: S.Schema<GetFirewallsActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetFirewallsActionResponseActionError = ApplyFirewallToResourcesResponseActionsItemError;
export declare const GetFirewallsActionResponseActionError: S.Schema<ApplyFirewallToResourcesResponseActionsItemError>;
export interface GetFirewallsActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetFirewallsActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetFirewallsActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ApplyFirewallToResourcesResponseActionsItemError | null;
}
export declare const GetFirewallsActionResponseAction: S.Schema<GetFirewallsActionResponseAction>;
export interface GetFirewallsActionResponse {
    action: GetFirewallsActionResponseAction;
}
export declare const GetFirewallsActionResponse: S.Schema<GetFirewallsActionResponse>;
export type ListFirewallActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListFirewallActionsRequestSortItem: any;
export type ListFirewallActionsRequestSortList = Array<ListFirewallActionsRequestSortItem | (string & {})>;
export declare const ListFirewallActionsRequestSortList: S.Schema<ListFirewallActionsRequestSortList>;
/** Status of the Action. */
export type ListFirewallActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListFirewallActionsRequestStatusItem: any;
export type ListFirewallActionsRequestStatusList = Array<ListFirewallActionsRequestStatusItem | (string & {})>;
export declare const ListFirewallActionsRequestStatusList: S.Schema<ListFirewallActionsRequestStatusList>;
export interface ListFirewallActionsRequest {
    /** ID of the Firewall. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListFirewallActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListFirewallActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListFirewallActionsRequest: S.Schema<ListFirewallActionsRequest>;
/** Status of the Action. */
export type ListFirewallActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListFirewallActionsResponseActionsItemStatus: any;
export type ListFirewallActionsResponseActionsItemResourcesItem = ApplyFirewallToResourcesResponseActionsItemResourcesItem;
export declare const ListFirewallActionsResponseActionsItemResourcesItem: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type ListFirewallActionsResponseActionsItemResourcesList = Array<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
export declare const ListFirewallActionsResponseActionsItemResourcesList: S.Schema<ListFirewallActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListFirewallActionsResponseActionsItemError = ApplyFirewallToResourcesResponseActionsItemError;
export declare const ListFirewallActionsResponseActionsItemError: S.Schema<ApplyFirewallToResourcesResponseActionsItemError>;
export interface ListFirewallActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListFirewallActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListFirewallActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ApplyFirewallToResourcesResponseActionsItemError | null;
}
export declare const ListFirewallActionsResponseActionsItem: S.Schema<ListFirewallActionsResponseActionsItem>;
export type ListFirewallActionsResponseActionsList = Array<ListFirewallActionsResponseActionsItem>;
export declare const ListFirewallActionsResponseActionsList: S.Schema<ListFirewallActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListFirewallActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListFirewallActionsResponseMetaPagination: S.Schema<ListFirewallActionsResponseMetaPagination>;
export interface ListFirewallActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListFirewallActionsResponseMetaPagination;
}
export declare const ListFirewallActionsResponseMeta: S.Schema<ListFirewallActionsResponseMeta>;
export interface ListFirewallActionsResponse {
    actions: ListFirewallActionsResponseActionsList;
    meta: ListFirewallActionsResponseMeta;
}
export declare const ListFirewallActionsResponse: S.Schema<ListFirewallActionsResponse>;
export type ListFirewallsActionsRequestIdList = Array<number>;
export declare const ListFirewallsActionsRequestIdList: S.Schema<ListFirewallsActionsRequestIdList>;
export type ListFirewallsActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListFirewallsActionsRequestSortItem: any;
export type ListFirewallsActionsRequestSortList = Array<ListFirewallsActionsRequestSortItem | (string & {})>;
export declare const ListFirewallsActionsRequestSortList: S.Schema<ListFirewallsActionsRequestSortList>;
/** Status of the Action. */
export type ListFirewallsActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListFirewallsActionsRequestStatusItem: any;
export type ListFirewallsActionsRequestStatusList = Array<ListFirewallsActionsRequestStatusItem | (string & {})>;
export declare const ListFirewallsActionsRequestStatusList: S.Schema<ListFirewallsActionsRequestStatusList>;
export interface ListFirewallsActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListFirewallsActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListFirewallsActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListFirewallsActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListFirewallsActionsRequest: S.Schema<ListFirewallsActionsRequest>;
/** Status of the Action. */
export type ListFirewallsActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListFirewallsActionsResponseActionsItemStatus: any;
export type ListFirewallsActionsResponseActionsItemResourcesItem = ApplyFirewallToResourcesResponseActionsItemResourcesItem;
export declare const ListFirewallsActionsResponseActionsItemResourcesItem: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type ListFirewallsActionsResponseActionsItemResourcesList = Array<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
export declare const ListFirewallsActionsResponseActionsItemResourcesList: S.Schema<ListFirewallsActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListFirewallsActionsResponseActionsItemError = ApplyFirewallToResourcesResponseActionsItemError;
export declare const ListFirewallsActionsResponseActionsItemError: S.Schema<ApplyFirewallToResourcesResponseActionsItemError>;
export interface ListFirewallsActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListFirewallsActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListFirewallsActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ApplyFirewallToResourcesResponseActionsItemError | null;
}
export declare const ListFirewallsActionsResponseActionsItem: S.Schema<ListFirewallsActionsResponseActionsItem>;
export type ListFirewallsActionsResponseActionsList = Array<ListFirewallsActionsResponseActionsItem>;
export declare const ListFirewallsActionsResponseActionsList: S.Schema<ListFirewallsActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListFirewallsActionsResponseMetaPagination = ListFirewallActionsResponseMetaPagination;
export declare const ListFirewallsActionsResponseMetaPagination: S.Schema<ListFirewallActionsResponseMetaPagination>;
export type ListFirewallsActionsResponseMeta = ListFirewallActionsResponseMeta;
export declare const ListFirewallsActionsResponseMeta: S.Schema<ListFirewallActionsResponseMeta>;
export interface ListFirewallsActionsResponse {
    actions: ListFirewallsActionsResponseActionsList;
    meta: ListFirewallActionsResponseMeta;
}
export declare const ListFirewallsActionsResponse: S.Schema<ListFirewallsActionsResponse>;
/** Type of the resource. */
export type RemoveFirewallFromResourcesRequestRemoveFromItemType = "server" | "label_selector";
export declare const RemoveFirewallFromResourcesRequestRemoveFromItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type RemoveFirewallFromResourcesRequestRemoveFromItemServer = ApplyFirewallToResourcesRequestApplyToItemServer;
export declare const RemoveFirewallFromResourcesRequestRemoveFromItemServer: S.Schema<ApplyFirewallToResourcesRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export type RemoveFirewallFromResourcesRequestRemoveFromItemLabelSelector = ApplyFirewallToResourcesRequestApplyToItemLabelSelector;
export declare const RemoveFirewallFromResourcesRequestRemoveFromItemLabelSelector: S.Schema<ApplyFirewallToResourcesRequestApplyToItemLabelSelector>;
export interface RemoveFirewallFromResourcesRequestRemoveFromItem {
    /** Type of the resource. */
    type: RemoveFirewallFromResourcesRequestRemoveFromItemType | (string & {});
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: ApplyFirewallToResourcesRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: ApplyFirewallToResourcesRequestApplyToItemLabelSelector;
}
export declare const RemoveFirewallFromResourcesRequestRemoveFromItem: S.Schema<RemoveFirewallFromResourcesRequestRemoveFromItem>;
/** Resources to remove the [Firewall](#tag/firewalls) from. */
export type RemoveFirewallFromResourcesRequestRemoveFromList = Array<RemoveFirewallFromResourcesRequestRemoveFromItem>;
export declare const RemoveFirewallFromResourcesRequestRemoveFromList: S.Schema<RemoveFirewallFromResourcesRequestRemoveFromList>;
export interface RemoveFirewallFromResourcesRequest {
    /** ID of the Firewall. */
    id: number;
    /** Resources to remove the [Firewall](#tag/firewalls) from. */
    remove_from: RemoveFirewallFromResourcesRequestRemoveFromList;
}
export declare const RemoveFirewallFromResourcesRequest: S.Schema<RemoveFirewallFromResourcesRequest>;
/** Status of the Action. */
export type RemoveFirewallFromResourcesResponseActionsItemStatus = "running" | "success" | "error";
export declare const RemoveFirewallFromResourcesResponseActionsItemStatus: any;
export type RemoveFirewallFromResourcesResponseActionsItemResourcesItem = ApplyFirewallToResourcesResponseActionsItemResourcesItem;
export declare const RemoveFirewallFromResourcesResponseActionsItemResourcesItem: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type RemoveFirewallFromResourcesResponseActionsItemResourcesList = Array<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
export declare const RemoveFirewallFromResourcesResponseActionsItemResourcesList: S.Schema<RemoveFirewallFromResourcesResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RemoveFirewallFromResourcesResponseActionsItemError = ApplyFirewallToResourcesResponseActionsItemError;
export declare const RemoveFirewallFromResourcesResponseActionsItemError: S.Schema<ApplyFirewallToResourcesResponseActionsItemError>;
export interface RemoveFirewallFromResourcesResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RemoveFirewallFromResourcesResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RemoveFirewallFromResourcesResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ApplyFirewallToResourcesResponseActionsItemError | null;
}
export declare const RemoveFirewallFromResourcesResponseActionsItem: S.Schema<RemoveFirewallFromResourcesResponseActionsItem>;
export type RemoveFirewallFromResourcesResponseActionsList = Array<RemoveFirewallFromResourcesResponseActionsItem>;
export declare const RemoveFirewallFromResourcesResponseActionsList: S.Schema<RemoveFirewallFromResourcesResponseActionsList>;
export interface RemoveFirewallFromResourcesResponse {
    actions: RemoveFirewallFromResourcesResponseActionsList;
}
export declare const RemoveFirewallFromResourcesResponse: S.Schema<RemoveFirewallFromResourcesResponse>;
/** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
export type SetFirewallRulesRequestRulesItemDirection = "in" | "out";
export declare const SetFirewallRulesRequestRulesItemDirection: any;
/** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type SetFirewallRulesRequestRulesItemSourceIpsList = Array<string>;
export declare const SetFirewallRulesRequestRulesItemSourceIpsList: S.Schema<SetFirewallRulesRequestRulesItemSourceIpsList>;
/** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type SetFirewallRulesRequestRulesItemDestinationIpsList = Array<string>;
export declare const SetFirewallRulesRequestRulesItemDestinationIpsList: S.Schema<SetFirewallRulesRequestRulesItemDestinationIpsList>;
/** Network protocol to apply the rule for. */
export type SetFirewallRulesRequestRulesItemProtocol = "tcp" | "udp" | "icmp" | "esp" | "gre";
export declare const SetFirewallRulesRequestRulesItemProtocol: any;
export interface SetFirewallRulesRequestRulesItem {
    /** Description of the rule. */
    description?: string | null;
    /** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
    direction: SetFirewallRulesRequestRulesItemDirection | (string & {});
    /** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    source_ips?: SetFirewallRulesRequestRulesItemSourceIpsList;
    /** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    destination_ips?: SetFirewallRulesRequestRulesItemDestinationIpsList;
    /** Network protocol to apply the rule for. */
    protocol: SetFirewallRulesRequestRulesItemProtocol | (string & {});
    /** Port or port range to apply the rule for. Only applicable for protocols `tcp` and `udp`. A port range can be specified by separating lower and upper bounds with a dash. `1024-5000` will include all ports starting from 1024 up to port 5000. */
    port?: string;
}
export declare const SetFirewallRulesRequestRulesItem: S.Schema<SetFirewallRulesRequestRulesItem>;
/** Array of rules. Rules are limited to 50 entries per [Firewall](#tag/firewalls) and [500 effective rules](https://docs.hetzner.com/cloud/firewalls/overview#limits). Existing rules will be replaced. */
export type SetFirewallRulesRequestRulesList = Array<SetFirewallRulesRequestRulesItem>;
export declare const SetFirewallRulesRequestRulesList: S.Schema<SetFirewallRulesRequestRulesList>;
export interface SetFirewallRulesRequest {
    /** ID of the Firewall. */
    id: number;
    /** Array of rules. Rules are limited to 50 entries per [Firewall](#tag/firewalls) and [500 effective rules](https://docs.hetzner.com/cloud/firewalls/overview#limits). Existing rules will be replaced. */
    rules: SetFirewallRulesRequestRulesList;
}
export declare const SetFirewallRulesRequest: S.Schema<SetFirewallRulesRequest>;
/** Status of the Action. */
export type SetFirewallRulesResponseActionsItemStatus = "running" | "success" | "error";
export declare const SetFirewallRulesResponseActionsItemStatus: any;
export type SetFirewallRulesResponseActionsItemResourcesItem = ApplyFirewallToResourcesResponseActionsItemResourcesItem;
export declare const SetFirewallRulesResponseActionsItemResourcesItem: S.Schema<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type SetFirewallRulesResponseActionsItemResourcesList = Array<ApplyFirewallToResourcesResponseActionsItemResourcesItem>;
export declare const SetFirewallRulesResponseActionsItemResourcesList: S.Schema<SetFirewallRulesResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type SetFirewallRulesResponseActionsItemError = ApplyFirewallToResourcesResponseActionsItemError;
export declare const SetFirewallRulesResponseActionsItemError: S.Schema<ApplyFirewallToResourcesResponseActionsItemError>;
export interface SetFirewallRulesResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: SetFirewallRulesResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: SetFirewallRulesResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ApplyFirewallToResourcesResponseActionsItemError | null;
}
export declare const SetFirewallRulesResponseActionsItem: S.Schema<SetFirewallRulesResponseActionsItem>;
export type SetFirewallRulesResponseActionsList = Array<SetFirewallRulesResponseActionsItem>;
export declare const SetFirewallRulesResponseActionsList: S.Schema<SetFirewallRulesResponseActionsList>;
export interface SetFirewallRulesResponse {
    actions: SetFirewallRulesResponseActionsList;
}
export declare const SetFirewallRulesResponse: S.Schema<SetFirewallRulesResponse>;
export type ApplyFirewallToResourcesError = HetznerOpError;
/** Apply to Resources Applies a [Firewall](#tag/firewalls) to multiple resources. Supported resources: - [Servers](#tag/servers) (with a public network interface) - [Label Selectors](#description/label-selector) A [Server](#tag/servers) can be applied to [a maximum of 5 Firewalls](https://docs.hetzner.com/cloud/firewalls/overview#limits). This limit applies to [Servers](#tag/servers) applied via a matching [Label Selector](#description/label-selector) as well. Updates to resources matching or no longer matching a [Label Selector](#description/label-selector) can take up to a few seconds to be processed. A [Firewall](#tag/firewalls) is applied to a resource once the related [Action](#tag/actions) with command `apply_firewall` successfully finished. #### Operation specific errors */
export declare const applyFirewallToResources: API.OperationMethod<ApplyFirewallToResourcesRequest, ApplyFirewallToResourcesResponse, ApplyFirewallToResourcesError, HetznerOpContext>;
export type GetFirewallsActionError = HetznerOpError;
/** Get an Action Returns the specific [Action](#tag/actions). */
export declare const getFirewallsAction: API.OperationMethod<GetFirewallsActionRequest, GetFirewallsActionResponse, GetFirewallsActionError, HetznerOpContext>;
export type ListFirewallActionsError = HetznerOpError;
/** List Actions for a Firewall Returns all [Actions](#tag/actions) for the [Firewall](#tag/firewalls). Use the provided URI parameters to modify the result. */
export declare const listFirewallActions: API.PaginatedOperationMethod<ListFirewallActionsRequest, ListFirewallActionsResponse, ListFirewallActionsError, HetznerOpContext, ListFirewallActionsResponseActionsItem>;
export type ListFirewallsActionsError = HetznerOpError;
/** List Actions Returns all [Actions](#tag/actions) for [Firewalls](#tag/firewalls). Use the provided URI parameters to modify the result. */
export declare const listFirewallsActions: API.PaginatedOperationMethod<ListFirewallsActionsRequest, ListFirewallsActionsResponse, ListFirewallsActionsError, HetznerOpContext, ListFirewallsActionsResponseActionsItem>;
export type RemoveFirewallFromResourcesError = HetznerOpError;
/** Remove from Resources Removes a [Firewall](#tag/firewalls) from multiple resources. Supported resources: - [Servers](#tag/servers) (with a public network interface) A [Firewall](#tag/firewalls) is removed from a resource once the related [Action](#tag/actions) with command `remove_firewall` successfully finished. #### Operation specific errors */
export declare const removeFirewallFromResources: API.OperationMethod<RemoveFirewallFromResourcesRequest, RemoveFirewallFromResourcesResponse, RemoveFirewallFromResourcesError, HetznerOpContext>;
export type SetFirewallRulesError = HetznerOpError;
/** Set Rules Set the rules of a [Firewall](#tag/firewalls). Overwrites the existing rules with the given ones. Pass an empty array to remove all rules. Rules are limited to 50 entries per [Firewall](#tag/firewalls) and [500 effective rules](https://docs.hetzner.com/cloud/firewalls/overview#limits). */
export declare const setFirewallRules: API.OperationMethod<SetFirewallRulesRequest, SetFirewallRulesResponse, SetFirewallRulesError, HetznerOpContext>;
//# sourceMappingURL=firewall_actions.d.ts.map