import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetLoadBalancerTypeRequest {
    /** ID of the Load Balancer Type. */
    id: number;
}
export declare const GetLoadBalancerTypeRequest: S.Schema<GetLoadBalancerTypeRequest>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export interface GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation {
    /** Date of the deprecated resource removal. Once this date is reached, the resource will not be returned by resource type "list" endpoint, and the resource can not be used to create new resources. For example, if this is an image, you can not create new servers with this image after the mentioned date. */
    unavailable_after: string;
    /** Date of the deprecation announcement. */
    announced: string;
}
export declare const GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation>;
/** Hourly price in this [Location](#tag/locations). */
export interface GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly {
    /** Price without VAT. */
    net: string;
    /** Price with VAT added. */
    gross: string;
}
export declare const GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceMonthly = GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
export declare const GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceMonthly: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPricePerTbTraffic = GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
export declare const GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPricePerTbTraffic: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly>;
export interface GetLoadBalancerTypeResponseLoadBalancerTypePricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Hourly price in this [Location](#tag/locations). */
    price_hourly: GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
    /** Free traffic per month in bytes in this [Location](#tag/locations). */
    included_traffic: number;
    /** Additional traffic price per TB in this [Location](#tag/locations). */
    price_per_tb_traffic: GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
}
export declare const GetLoadBalancerTypeResponseLoadBalancerTypePricesItem: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type GetLoadBalancerTypeResponseLoadBalancerTypePricesList = Array<GetLoadBalancerTypeResponseLoadBalancerTypePricesItem>;
export declare const GetLoadBalancerTypeResponseLoadBalancerTypePricesList: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesList>;
export interface GetLoadBalancerTypeResponseLoadBalancerType {
    /** ID of the Load Balancer type. */
    id: number;
    /** Unique identifier of the Load Balancer type. */
    name: string;
    /** Description of the Load Balancer type. */
    description: string;
    /** Number of maximum simultaneous open connections. */
    max_connections: number;
    /** Number of services a Load Balancer of this type can have. */
    max_services: number;
    /** Number of targets a single Load Balancer can have. */
    max_targets: number;
    /** Number of SSL Certificates that can be assigned to a single Load Balancer. */
    max_assigned_certificates: number;
    /** **Deprecated:** This field is deprecated. Use the `deprecation` object instead. Point in time when the Load Balancer type is deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation | null;
    /** Price per [Location](#tag/locations). */
    prices: GetLoadBalancerTypeResponseLoadBalancerTypePricesList;
}
export declare const GetLoadBalancerTypeResponseLoadBalancerType: S.Schema<GetLoadBalancerTypeResponseLoadBalancerType>;
export interface GetLoadBalancerTypeResponse {
    load_balancer_type: GetLoadBalancerTypeResponseLoadBalancerType;
}
export declare const GetLoadBalancerTypeResponse: S.Schema<GetLoadBalancerTypeResponse>;
export interface ListLoadBalancerTypesRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListLoadBalancerTypesRequest: S.Schema<ListLoadBalancerTypesRequest>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type ListLoadBalancerTypesResponseLoadBalancerTypesItemDeprecation = GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItemDeprecation: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation>;
/** Hourly price in this [Location](#tag/locations). */
export type ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItemPriceHourly = GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItemPriceHourly: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItemPriceMonthly = GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItemPriceMonthly: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItemPricePerTbTraffic = GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItemPricePerTbTraffic: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItemPriceHourly>;
export type ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItem = GetLoadBalancerTypeResponseLoadBalancerTypePricesItem;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesItem: S.Schema<GetLoadBalancerTypeResponseLoadBalancerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesList = Array<GetLoadBalancerTypeResponseLoadBalancerTypePricesItem>;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesList: S.Schema<ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesList>;
export interface ListLoadBalancerTypesResponseLoadBalancerTypesItem {
    /** ID of the Load Balancer type. */
    id: number;
    /** Unique identifier of the Load Balancer type. */
    name: string;
    /** Description of the Load Balancer type. */
    description: string;
    /** Number of maximum simultaneous open connections. */
    max_connections: number;
    /** Number of services a Load Balancer of this type can have. */
    max_services: number;
    /** Number of targets a single Load Balancer can have. */
    max_targets: number;
    /** Number of SSL Certificates that can be assigned to a single Load Balancer. */
    max_assigned_certificates: number;
    /** **Deprecated:** This field is deprecated. Use the `deprecation` object instead. Point in time when the Load Balancer type is deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: GetLoadBalancerTypeResponseLoadBalancerTypeDeprecation | null;
    /** Price per [Location](#tag/locations). */
    prices: ListLoadBalancerTypesResponseLoadBalancerTypesItemPricesList;
}
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesItem: S.Schema<ListLoadBalancerTypesResponseLoadBalancerTypesItem>;
export type ListLoadBalancerTypesResponseLoadBalancerTypesList = Array<ListLoadBalancerTypesResponseLoadBalancerTypesItem>;
export declare const ListLoadBalancerTypesResponseLoadBalancerTypesList: S.Schema<ListLoadBalancerTypesResponseLoadBalancerTypesList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListLoadBalancerTypesResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListLoadBalancerTypesResponseMetaPagination: S.Schema<ListLoadBalancerTypesResponseMetaPagination>;
export interface ListLoadBalancerTypesResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListLoadBalancerTypesResponseMetaPagination;
}
export declare const ListLoadBalancerTypesResponseMeta: S.Schema<ListLoadBalancerTypesResponseMeta>;
export interface ListLoadBalancerTypesResponse {
    load_balancer_types: ListLoadBalancerTypesResponseLoadBalancerTypesList;
    meta: ListLoadBalancerTypesResponseMeta;
}
export declare const ListLoadBalancerTypesResponse: S.Schema<ListLoadBalancerTypesResponse>;
export type GetLoadBalancerTypeError = HetznerOpError;
/** Get a Load Balancer Type Gets a specific Load Balancer type object. */
export declare const getLoadBalancerType: API.OperationMethod<GetLoadBalancerTypeRequest, GetLoadBalancerTypeResponse, GetLoadBalancerTypeError, HetznerOpContext>;
export type ListLoadBalancerTypesError = HetznerOpError;
/** List Load Balancer Types Gets all Load Balancer type objects. */
export declare const listLoadBalancerTypes: API.PaginatedOperationMethod<ListLoadBalancerTypesRequest, ListLoadBalancerTypesResponse, ListLoadBalancerTypesError, HetznerOpContext, ListLoadBalancerTypesResponseLoadBalancerTypesItem>;
//# sourceMappingURL=load_balancer_types.d.ts.map