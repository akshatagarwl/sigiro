import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetServerTypeRequest {
    /** ID of the Server Type. */
    id: number;
}
export declare const GetServerTypeRequest: S.Schema<GetServerTypeRequest>;
/** Hourly price in this [Location](#tag/locations). */
export interface GetServerTypeResponseServerTypePricesItemPriceHourly {
    /** Price without VAT. */
    net: string;
    /** Price with VAT added. */
    gross: string;
}
export declare const GetServerTypeResponseServerTypePricesItemPriceHourly: S.Schema<GetServerTypeResponseServerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetServerTypeResponseServerTypePricesItemPriceMonthly = GetServerTypeResponseServerTypePricesItemPriceHourly;
export declare const GetServerTypeResponseServerTypePricesItemPriceMonthly: S.Schema<GetServerTypeResponseServerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type GetServerTypeResponseServerTypePricesItemPricePerTbTraffic = GetServerTypeResponseServerTypePricesItemPriceHourly;
export declare const GetServerTypeResponseServerTypePricesItemPricePerTbTraffic: S.Schema<GetServerTypeResponseServerTypePricesItemPriceHourly>;
export interface GetServerTypeResponseServerTypePricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Hourly price in this [Location](#tag/locations). */
    price_hourly: GetServerTypeResponseServerTypePricesItemPriceHourly;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: GetServerTypeResponseServerTypePricesItemPriceHourly;
    /** Free traffic per month in bytes in this [Location](#tag/locations). */
    included_traffic: number;
    /** Additional traffic price per TB in this [Location](#tag/locations). */
    price_per_tb_traffic: GetServerTypeResponseServerTypePricesItemPriceHourly;
}
export declare const GetServerTypeResponseServerTypePricesItem: S.Schema<GetServerTypeResponseServerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type GetServerTypeResponseServerTypePricesList = Array<GetServerTypeResponseServerTypePricesItem>;
export declare const GetServerTypeResponseServerTypePricesList: S.Schema<GetServerTypeResponseServerTypePricesList>;
/** Type of Server boot drive. Local has higher speed. Network has better availability. */
export type GetServerTypeResponseServerTypeStorageType = "local" | "network";
export declare const GetServerTypeResponseServerTypeStorageType: any;
/** Type of cpu. */
export type GetServerTypeResponseServerTypeCpuType = "shared" | "dedicated";
export declare const GetServerTypeResponseServerTypeCpuType: any;
/** CPU architecture of the Server Type. */
export type GetServerTypeResponseServerTypeArchitecture = "x86" | "arm";
export declare const GetServerTypeResponseServerTypeArchitecture: any;
/** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
export interface GetServerTypeResponseServerTypeDeprecation {
    /** Date of the deprecated resource removal. Once this date is reached, the resource will not be returned by resource type "list" endpoint, and the resource can not be used to create new resources. For example, if this is an image, you can not create new servers with this image after the mentioned date. */
    unavailable_after: string;
    /** Date of the deprecation announcement. */
    announced: string;
}
export declare const GetServerTypeResponseServerTypeDeprecation: S.Schema<GetServerTypeResponseServerTypeDeprecation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type GetServerTypeResponseServerTypeLocationsItemDeprecation = GetServerTypeResponseServerTypeDeprecation;
export declare const GetServerTypeResponseServerTypeLocationsItemDeprecation: S.Schema<GetServerTypeResponseServerTypeDeprecation>;
/** A [Location](#tag/locations) (containing only id and name) and Server Type specific metadata. */
export interface GetServerTypeResponseServerTypeLocationsItem {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Name of the [Location](#tag/locations). */
    name: string;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: GetServerTypeResponseServerTypeDeprecation | null;
    /** Whether the [Server Type](#tag/server-types) is recommended in this [Location](#tag/locations). */
    recommended: boolean;
    /** Whether the [Server Type](#tag/server-types) is temporarily unavailable in this [Location](#tag/locations). */
    available: boolean;
}
export declare const GetServerTypeResponseServerTypeLocationsItem: S.Schema<GetServerTypeResponseServerTypeLocationsItem>;
/** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
export type GetServerTypeResponseServerTypeLocationsList = Array<GetServerTypeResponseServerTypeLocationsItem>;
export declare const GetServerTypeResponseServerTypeLocationsList: S.Schema<GetServerTypeResponseServerTypeLocationsList>;
export interface GetServerTypeResponseServerType {
    /** ID of the Server type. */
    id: number;
    /** Unique identifier of the Server type. */
    name: string;
    /** Description of the Server type. */
    description: string;
    /** Number of cpu cores a Server of this type will have. */
    cores: number;
    /** Memory a Server of this type will have in GB. */
    memory: number;
    /** Disk size a Server of this type will have in GB. */
    disk: number;
    /** This field is deprecated. Use the deprecation object instead. */
    deprecated: boolean;
    /** Price per [Location](#tag/locations). */
    prices: GetServerTypeResponseServerTypePricesList;
    /** Type of Server boot drive. Local has higher speed. Network has better availability. */
    storage_type: GetServerTypeResponseServerTypeStorageType;
    /** Type of cpu. */
    cpu_type: GetServerTypeResponseServerTypeCpuType;
    /** Category of Server Type. */
    category?: string;
    /** CPU architecture of the Server Type. */
    architecture: GetServerTypeResponseServerTypeArchitecture;
    /** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
    deprecation?: GetServerTypeResponseServerTypeDeprecation | null;
    /** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
    locations: GetServerTypeResponseServerTypeLocationsList;
}
export declare const GetServerTypeResponseServerType: S.Schema<GetServerTypeResponseServerType>;
export interface GetServerTypeResponse {
    server_type: GetServerTypeResponseServerType;
}
export declare const GetServerTypeResponse: S.Schema<GetServerTypeResponse>;
export interface ListServerTypesRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListServerTypesRequest: S.Schema<ListServerTypesRequest>;
/** Hourly price in this [Location](#tag/locations). */
export type ListServerTypesResponseServerTypesItemPricesItemPriceHourly = GetServerTypeResponseServerTypePricesItemPriceHourly;
export declare const ListServerTypesResponseServerTypesItemPricesItemPriceHourly: S.Schema<GetServerTypeResponseServerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type ListServerTypesResponseServerTypesItemPricesItemPriceMonthly = GetServerTypeResponseServerTypePricesItemPriceHourly;
export declare const ListServerTypesResponseServerTypesItemPricesItemPriceMonthly: S.Schema<GetServerTypeResponseServerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type ListServerTypesResponseServerTypesItemPricesItemPricePerTbTraffic = GetServerTypeResponseServerTypePricesItemPriceHourly;
export declare const ListServerTypesResponseServerTypesItemPricesItemPricePerTbTraffic: S.Schema<GetServerTypeResponseServerTypePricesItemPriceHourly>;
export type ListServerTypesResponseServerTypesItemPricesItem = GetServerTypeResponseServerTypePricesItem;
export declare const ListServerTypesResponseServerTypesItemPricesItem: S.Schema<GetServerTypeResponseServerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type ListServerTypesResponseServerTypesItemPricesList = Array<GetServerTypeResponseServerTypePricesItem>;
export declare const ListServerTypesResponseServerTypesItemPricesList: S.Schema<ListServerTypesResponseServerTypesItemPricesList>;
/** Type of Server boot drive. Local has higher speed. Network has better availability. */
export type ListServerTypesResponseServerTypesItemStorageType = "local" | "network";
export declare const ListServerTypesResponseServerTypesItemStorageType: any;
/** Type of cpu. */
export type ListServerTypesResponseServerTypesItemCpuType = "shared" | "dedicated";
export declare const ListServerTypesResponseServerTypesItemCpuType: any;
/** CPU architecture of the Server Type. */
export type ListServerTypesResponseServerTypesItemArchitecture = "x86" | "arm";
export declare const ListServerTypesResponseServerTypesItemArchitecture: any;
/** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
export type ListServerTypesResponseServerTypesItemDeprecation = GetServerTypeResponseServerTypeDeprecation;
export declare const ListServerTypesResponseServerTypesItemDeprecation: S.Schema<GetServerTypeResponseServerTypeDeprecation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type ListServerTypesResponseServerTypesItemLocationsItemDeprecation = GetServerTypeResponseServerTypeDeprecation;
export declare const ListServerTypesResponseServerTypesItemLocationsItemDeprecation: S.Schema<GetServerTypeResponseServerTypeDeprecation>;
/** A [Location](#tag/locations) (containing only id and name) and Server Type specific metadata. */
export type ListServerTypesResponseServerTypesItemLocationsItem = GetServerTypeResponseServerTypeLocationsItem;
export declare const ListServerTypesResponseServerTypesItemLocationsItem: S.Schema<GetServerTypeResponseServerTypeLocationsItem>;
/** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
export type ListServerTypesResponseServerTypesItemLocationsList = Array<GetServerTypeResponseServerTypeLocationsItem>;
export declare const ListServerTypesResponseServerTypesItemLocationsList: S.Schema<ListServerTypesResponseServerTypesItemLocationsList>;
export interface ListServerTypesResponseServerTypesItem {
    /** ID of the Server type. */
    id: number;
    /** Unique identifier of the Server type. */
    name: string;
    /** Description of the Server type. */
    description: string;
    /** Number of cpu cores a Server of this type will have. */
    cores: number;
    /** Memory a Server of this type will have in GB. */
    memory: number;
    /** Disk size a Server of this type will have in GB. */
    disk: number;
    /** This field is deprecated. Use the deprecation object instead. */
    deprecated: boolean;
    /** Price per [Location](#tag/locations). */
    prices: ListServerTypesResponseServerTypesItemPricesList;
    /** Type of Server boot drive. Local has higher speed. Network has better availability. */
    storage_type: ListServerTypesResponseServerTypesItemStorageType;
    /** Type of cpu. */
    cpu_type: ListServerTypesResponseServerTypesItemCpuType;
    /** Category of Server Type. */
    category?: string;
    /** CPU architecture of the Server Type. */
    architecture: ListServerTypesResponseServerTypesItemArchitecture;
    /** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
    deprecation?: GetServerTypeResponseServerTypeDeprecation | null;
    /** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
    locations: ListServerTypesResponseServerTypesItemLocationsList;
}
export declare const ListServerTypesResponseServerTypesItem: S.Schema<ListServerTypesResponseServerTypesItem>;
export type ListServerTypesResponseServerTypesList = Array<ListServerTypesResponseServerTypesItem>;
export declare const ListServerTypesResponseServerTypesList: S.Schema<ListServerTypesResponseServerTypesList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListServerTypesResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListServerTypesResponseMetaPagination: S.Schema<ListServerTypesResponseMetaPagination>;
export interface ListServerTypesResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListServerTypesResponseMetaPagination;
}
export declare const ListServerTypesResponseMeta: S.Schema<ListServerTypesResponseMeta>;
export interface ListServerTypesResponse {
    server_types: ListServerTypesResponseServerTypesList;
    meta: ListServerTypesResponseMeta;
}
export declare const ListServerTypesResponse: S.Schema<ListServerTypesResponse>;
export type GetServerTypeError = HetznerOpError;
/** Get a Server Type Gets a specific Server type object. */
export declare const getServerType: API.OperationMethod<GetServerTypeRequest, GetServerTypeResponse, GetServerTypeError, HetznerOpContext>;
export type ListServerTypesError = HetznerOpError;
/** List Server Types Gets all Server type objects. */
export declare const listServerTypes: API.PaginatedOperationMethod<ListServerTypesRequest, ListServerTypesResponse, ListServerTypesError, HetznerOpContext, ListServerTypesResponseServerTypesItem>;
//# sourceMappingURL=server_types.d.ts.map