import * as S from "@distilled.cloud/core/schema";
import * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
declare const ServerLimitExceeded_base: S.Class<ServerLimitExceeded, S.TaggedStruct<"ServerLimitExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
/** The project has no remaining Server quota (Hetzner `resource_limit_exceeded`, HTTP 403). Often a race after a delete — retry. */
export declare class ServerLimitExceeded extends /*@__PURE__*/ ServerLimitExceeded_base {
}
declare const ServerPlacementError_base: S.Class<ServerPlacementError, S.TaggedStruct<"ServerPlacementError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
/** The Server could not be placed (Hetzner `resource_unavailable` / `placement_error`, HTTP 412). Spread groups and location capacity recover — retry. */
export declare class ServerPlacementError extends /*@__PURE__*/ ServerPlacementError_base {
}
export type CreateServerRequestSshKeysItem = number | string;
export declare const CreateServerRequestSshKeysItem: S.Schema<CreateServerRequestSshKeysItem>;
/** SSH key IDs (`integer`) or names (`string`) which should be injected into the Server at creation time. */
export type CreateServerRequestSshKeysList = Array<CreateServerRequestSshKeysItem>;
export declare const CreateServerRequestSshKeysList: S.Schema<CreateServerRequestSshKeysList>;
/** Volume IDs which should be attached to the Server at the creation time. Volumes must be in the same Location. */
export type CreateServerRequestVolumesList = Array<number>;
export declare const CreateServerRequestVolumesList: S.Schema<CreateServerRequestVolumesList>;
/** Network IDs which should be attached to the Server private network interface at the creation time. */
export type CreateServerRequestNetworksList = Array<number>;
export declare const CreateServerRequestNetworksList: S.Schema<CreateServerRequestNetworksList>;
export interface CreateServerRequestFirewallsItem {
    /** ID of the Firewall. */
    firewall: number;
}
export declare const CreateServerRequestFirewallsItem: S.Schema<CreateServerRequestFirewallsItem>;
/** Firewalls which should be applied on the Server's public network interface at creation time. */
export type CreateServerRequestFirewallsList = Array<CreateServerRequestFirewallsItem>;
export declare const CreateServerRequestFirewallsList: S.Schema<CreateServerRequestFirewallsList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateServerRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateServerRequestLabelsMap: S.Schema<CreateServerRequestLabelsMap>;
/** Public Network options. */
export interface CreateServerRequestPublicNet {
    /** Attach an IPv4 on the public NIC. If false, no IPv4 address will be attached. */
    enable_ipv4?: boolean;
    /** Attach an IPv6 on the public NIC. If false, no IPv6 address will be attached. */
    enable_ipv6?: boolean;
    /** ID of the ipv4 Primary IP to use. If omitted and enable_ipv4 is true, a new ipv4 Primary IP will automatically be created. */
    ipv4?: number | null;
    /** ID of the ipv6 Primary IP to use. If omitted and enable_ipv6 is true, a new ipv6 Primary IP will automatically be created. */
    ipv6?: number | null;
}
export declare const CreateServerRequestPublicNet: S.Schema<CreateServerRequestPublicNet>;
export interface CreateServerRequest {
    /** Name of the Server to create (must be unique per Project and a valid hostname as per RFC 1123). */
    name: string;
    /** ID or name of the Location to create the Server in. */
    location?: string;
    /** ID or name of the Server type this Server should be created with. */
    server_type: string;
    /** This automatically triggers a [Power on a Server-Server Action](#tag/server-actions/poweron_server) after the creation is finished and is returned in the `next_actions` response object. */
    start_after_create?: boolean;
    /** ID or name of the Image the Server is created from. */
    image: string;
    /** ID of the Placement Group the Server should be in. */
    placement_group?: number;
    /** SSH key IDs (`integer`) or names (`string`) which should be injected into the Server at creation time. */
    ssh_keys?: CreateServerRequestSshKeysList;
    /** Volume IDs which should be attached to the Server at the creation time. Volumes must be in the same Location. */
    volumes?: CreateServerRequestVolumesList;
    /** Network IDs which should be attached to the Server private network interface at the creation time. */
    networks?: CreateServerRequestNetworksList;
    /** Firewalls which should be applied on the Server's public network interface at creation time. */
    firewalls?: CreateServerRequestFirewallsList;
    /** Cloud-Init user data to use during Server creation. This field is limited to 32KiB. */
    user_data?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateServerRequestLabelsMap;
    /** Auto-mount Volumes after attach. */
    automount?: boolean;
    /** Public Network options. */
    public_net?: CreateServerRequestPublicNet;
}
export declare const CreateServerRequest: S.Schema<CreateServerRequest>;
/** Status of the Server. */
export type CreateServerResponseServerStatus = "running" | "initializing" | "starting" | "stopping" | "off" | "deleting" | "migrating" | "rebuilding" | "unknown";
export declare const CreateServerResponseServerStatus: any;
/** IP address (v4) and its reverse DNS entry of this Server. */
export interface CreateServerResponseServerPublicNetIpv4 {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id?: number;
    /** IP address (v4) of this Server. */
    ip: string;
    /** If the IP is blocked by our anti abuse dept. */
    blocked: boolean;
    /** Reverse DNS PTR entry for the IPv4 addresses of this Server. */
    dns_ptr: string;
}
export declare const CreateServerResponseServerPublicNetIpv4: S.Schema<CreateServerResponseServerPublicNetIpv4>;
export interface CreateServerResponseServerPublicNetIpv6DnsPtrItem {
    /** Single IPv6 address of this Server for which the reverse DNS entry has been set up. */
    ip: string;
    /** DNS pointer for the specific IP address. */
    dns_ptr: string;
}
export declare const CreateServerResponseServerPublicNetIpv6DnsPtrItem: S.Schema<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
/** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
export type CreateServerResponseServerPublicNetIpv6DnsPtrList = Array<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
export declare const CreateServerResponseServerPublicNetIpv6DnsPtrList: S.Schema<CreateServerResponseServerPublicNetIpv6DnsPtrList>;
/** IPv6 network assigned to this Server and its reverse DNS entry. */
export interface CreateServerResponseServerPublicNetIpv6 {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id?: number;
    /** IP address (v6) of this Server. */
    ip: string;
    /** If the IP is blocked by our anti abuse dept. */
    blocked: boolean;
    /** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
    dns_ptr: CreateServerResponseServerPublicNetIpv6DnsPtrList | null;
}
export declare const CreateServerResponseServerPublicNetIpv6: S.Schema<CreateServerResponseServerPublicNetIpv6>;
/** IDs of Floating IPs assigned to this Server. */
export type CreateServerResponseServerPublicNetFloatingIpsList = Array<number>;
export declare const CreateServerResponseServerPublicNetFloatingIpsList: S.Schema<CreateServerResponseServerPublicNetFloatingIpsList>;
/** Status of the Firewall on the Server. */
export type CreateServerResponseServerPublicNetFirewallsItemStatus = "applied" | "pending";
export declare const CreateServerResponseServerPublicNetFirewallsItemStatus: any;
export interface CreateServerResponseServerPublicNetFirewallsItem {
    /** ID of the [Firewall](#tag/firewalls). */
    id?: number;
    /** Status of the Firewall on the Server. */
    status?: CreateServerResponseServerPublicNetFirewallsItemStatus;
}
export declare const CreateServerResponseServerPublicNetFirewallsItem: S.Schema<CreateServerResponseServerPublicNetFirewallsItem>;
/** Firewalls applied to the public network interface of this Server. */
export type CreateServerResponseServerPublicNetFirewallsList = Array<CreateServerResponseServerPublicNetFirewallsItem>;
export declare const CreateServerResponseServerPublicNetFirewallsList: S.Schema<CreateServerResponseServerPublicNetFirewallsList>;
/** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
export interface CreateServerResponseServerPublicNet {
    /** IP address (v4) and its reverse DNS entry of this Server. */
    ipv4: CreateServerResponseServerPublicNetIpv4 | null;
    /** IPv6 network assigned to this Server and its reverse DNS entry. */
    ipv6: CreateServerResponseServerPublicNetIpv6 | null;
    /** IDs of Floating IPs assigned to this Server. */
    floating_ips: CreateServerResponseServerPublicNetFloatingIpsList;
    /** Firewalls applied to the public network interface of this Server. */
    firewalls?: CreateServerResponseServerPublicNetFirewallsList;
}
export declare const CreateServerResponseServerPublicNet: S.Schema<CreateServerResponseServerPublicNet>;
/** Additional IP addresses of the server on the network. */
export type CreateServerResponseServerPrivateNetItemAliasIpsList = Array<string>;
export declare const CreateServerResponseServerPrivateNetItemAliasIpsList: S.Schema<CreateServerResponseServerPrivateNetItemAliasIpsList>;
export interface CreateServerResponseServerPrivateNetItem {
    /** The Network ID the server is attached to. */
    network?: number;
    /** The server IP address on the network. */
    ip?: string;
    /** Additional IP addresses of the server on the network. */
    alias_ips?: CreateServerResponseServerPrivateNetItemAliasIpsList;
    /** The server MAC address on the network. */
    mac_address?: string;
}
export declare const CreateServerResponseServerPrivateNetItem: S.Schema<CreateServerResponseServerPrivateNetItem>;
/** Private networks information. */
export type CreateServerResponseServerPrivateNetList = Array<CreateServerResponseServerPrivateNetItem>;
export declare const CreateServerResponseServerPrivateNetList: S.Schema<CreateServerResponseServerPrivateNetList>;
/** Hourly price in this [Location](#tag/locations). */
export interface CreateServerResponseServerServerTypePricesItemPriceHourly {
    /** Price without VAT. */
    net: string;
    /** Price with VAT added. */
    gross: string;
}
export declare const CreateServerResponseServerServerTypePricesItemPriceHourly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type CreateServerResponseServerServerTypePricesItemPriceMonthly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const CreateServerResponseServerServerTypePricesItemPriceMonthly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type CreateServerResponseServerServerTypePricesItemPricePerTbTraffic = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const CreateServerResponseServerServerTypePricesItemPricePerTbTraffic: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
export interface CreateServerResponseServerServerTypePricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Hourly price in this [Location](#tag/locations). */
    price_hourly: CreateServerResponseServerServerTypePricesItemPriceHourly;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: CreateServerResponseServerServerTypePricesItemPriceHourly;
    /** Free traffic per month in bytes in this [Location](#tag/locations). */
    included_traffic: number;
    /** Additional traffic price per TB in this [Location](#tag/locations). */
    price_per_tb_traffic: CreateServerResponseServerServerTypePricesItemPriceHourly;
}
export declare const CreateServerResponseServerServerTypePricesItem: S.Schema<CreateServerResponseServerServerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type CreateServerResponseServerServerTypePricesList = Array<CreateServerResponseServerServerTypePricesItem>;
export declare const CreateServerResponseServerServerTypePricesList: S.Schema<CreateServerResponseServerServerTypePricesList>;
/** Type of Server boot drive. Local has higher speed. Network has better availability. */
export type CreateServerResponseServerServerTypeStorageType = "local" | "network";
export declare const CreateServerResponseServerServerTypeStorageType: any;
/** Type of cpu. */
export type CreateServerResponseServerServerTypeCpuType = "shared" | "dedicated";
export declare const CreateServerResponseServerServerTypeCpuType: any;
/** CPU architecture of the Server Type. */
export type CreateServerResponseServerServerTypeArchitecture = "x86" | "arm";
export declare const CreateServerResponseServerServerTypeArchitecture: any;
/** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
export interface CreateServerResponseServerServerTypeDeprecation {
    /** Date of the deprecated resource removal. Once this date is reached, the resource will not be returned by resource type "list" endpoint, and the resource can not be used to create new resources. For example, if this is an image, you can not create new servers with this image after the mentioned date. */
    unavailable_after: string;
    /** Date of the deprecation announcement. */
    announced: string;
}
export declare const CreateServerResponseServerServerTypeDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type CreateServerResponseServerServerTypeLocationsItemDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const CreateServerResponseServerServerTypeLocationsItemDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** A [Location](#tag/locations) (containing only id and name) and Server Type specific metadata. */
export interface CreateServerResponseServerServerTypeLocationsItem {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Name of the [Location](#tag/locations). */
    name: string;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateServerResponseServerServerTypeDeprecation | null;
    /** Whether the [Server Type](#tag/server-types) is recommended in this [Location](#tag/locations). */
    recommended: boolean;
    /** Whether the [Server Type](#tag/server-types) is temporarily unavailable in this [Location](#tag/locations). */
    available: boolean;
}
export declare const CreateServerResponseServerServerTypeLocationsItem: S.Schema<CreateServerResponseServerServerTypeLocationsItem>;
/** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
export type CreateServerResponseServerServerTypeLocationsList = Array<CreateServerResponseServerServerTypeLocationsItem>;
export declare const CreateServerResponseServerServerTypeLocationsList: S.Schema<CreateServerResponseServerServerTypeLocationsList>;
export interface CreateServerResponseServerServerType {
    /** ID of the Server type. */
    id: number;
    /** Unique identifier of the Server type. */
    name: string;
    /** Description of the Server type. */
    description: string;
    /** Number of cpu cores a Server of this type will have. */
    cores: number;
    /** Memory a Server of this type will have in GB. */
    memory: number;
    /** Disk size a Server of this type will have in GB. */
    disk: number;
    /** This field is deprecated. Use the deprecation object instead. */
    deprecated: boolean;
    /** Price per [Location](#tag/locations). */
    prices: CreateServerResponseServerServerTypePricesList;
    /** Type of Server boot drive. Local has higher speed. Network has better availability. */
    storage_type: CreateServerResponseServerServerTypeStorageType;
    /** Type of cpu. */
    cpu_type: CreateServerResponseServerServerTypeCpuType;
    /** Category of Server Type. */
    category?: string;
    /** CPU architecture of the Server Type. */
    architecture: CreateServerResponseServerServerTypeArchitecture;
    /** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
    deprecation?: CreateServerResponseServerServerTypeDeprecation | null;
    /** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
    locations: CreateServerResponseServerServerTypeLocationsList;
}
export declare const CreateServerResponseServerServerType: S.Schema<CreateServerResponseServerServerType>;
/** Location this Resource is located at. */
export interface CreateServerResponseServerLocation {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Unique identifier of the [Location](#tag/locations). */
    name: string;
    /** Human readable description of the [Location](#tag/locations). */
    description: string;
    /** Country the [Location](#tag/locations) resides in. ISO 3166-1 alpha-2 code of the country. */
    country: string;
    /** Name of the closest city to the [Location](#tag/locations). City name or city name and state in short form. E.g. `Falkenstein` or `Ashburn, VA`. */
    city: string;
    /** Latitude of the city closest to the [Location](#tag/locations). */
    latitude: number;
    /** Longitude of the city closest to the [Location](#tag/locations). */
    longitude: number;
    /** Name of the Network Zone this [Location](#tag/locations) resides in. */
    network_zone: string;
}
export declare const CreateServerResponseServerLocation: S.Schema<CreateServerResponseServerLocation>;
/** Type of the Image. */
export type CreateServerResponseServerImageType = "system" | "app" | "snapshot" | "backup";
export declare const CreateServerResponseServerImageType: any;
/** Status of the Image. */
export type CreateServerResponseServerImageStatus = "available" | "creating" | "unavailable";
export declare const CreateServerResponseServerImageStatus: any;
/** Information about the Server the Image was created from. */
export interface CreateServerResponseServerImageCreatedFrom {
    /** ID of the Server the Image was created from. */
    id: number;
    /** Server name at the time the Image was created. */
    name: string;
}
export declare const CreateServerResponseServerImageCreatedFrom: S.Schema<CreateServerResponseServerImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type CreateServerResponseServerImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const CreateServerResponseServerImageOsFlavor: any;
/** Protection configuration for the Resource. */
export interface CreateServerResponseServerImageProtection {
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const CreateServerResponseServerImageProtection: S.Schema<CreateServerResponseServerImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateServerResponseServerImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateServerResponseServerImageLabelsMap: S.Schema<CreateServerResponseServerImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type CreateServerResponseServerImageArchitecture = "x86" | "arm";
export declare const CreateServerResponseServerImageArchitecture: any;
/** Image the server is based on. */
export interface CreateServerResponseServerImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: CreateServerResponseServerImageType;
    /** Status of the Image. */
    status: CreateServerResponseServerImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: CreateServerResponseServerImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: CreateServerResponseServerImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateServerResponseServerImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateServerResponseServerImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: CreateServerResponseServerImageArchitecture;
}
export declare const CreateServerResponseServerImage: S.Schema<CreateServerResponseServerImage>;
/** Type of the ISO. */
export type CreateServerResponseServerIsoType = "public" | "private";
export declare const CreateServerResponseServerIsoType: any;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type CreateServerResponseServerIsoDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const CreateServerResponseServerIsoDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
export type CreateServerResponseServerIsoArchitecture = "x86" | "arm";
export declare const CreateServerResponseServerIsoArchitecture: any;
/** ISO Image that is attached to this Server. Null if no ISO is attached. */
export interface CreateServerResponseServerIso {
    /** ID of the [ISO](#tag/isos). */
    id: number;
    /** Unique identifier of the ISO. Only set for public ISOs. */
    name: string | null;
    /** Description of the ISO. */
    description: string;
    /** Type of the ISO. */
    type: CreateServerResponseServerIsoType | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateServerResponseServerServerTypeDeprecation | null;
    /** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
    architecture: CreateServerResponseServerIsoArchitecture | null;
}
export declare const CreateServerResponseServerIso: S.Schema<CreateServerResponseServerIso>;
/** Protection configuration for the Server. */
export interface CreateServerResponseServerProtection {
    /** If true, prevents the Server from being deleted. */
    delete: boolean;
    /** If true, prevents the Server from being rebuilt. */
    rebuild: boolean;
}
export declare const CreateServerResponseServerProtection: S.Schema<CreateServerResponseServerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateServerResponseServerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateServerResponseServerLabelsMap: S.Schema<CreateServerResponseServerLabelsMap>;
/** IDs of Volumes assigned to this Server. */
export type CreateServerResponseServerVolumesList = Array<number>;
export declare const CreateServerResponseServerVolumesList: S.Schema<CreateServerResponseServerVolumesList>;
/** Load Balancer IDs assigned to the server. */
export type CreateServerResponseServerLoadBalancersList = Array<number>;
export declare const CreateServerResponseServerLoadBalancersList: S.Schema<CreateServerResponseServerLoadBalancersList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateServerResponseServerPlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateServerResponseServerPlacementGroupLabelsMap: S.Schema<CreateServerResponseServerPlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type CreateServerResponseServerPlacementGroupType = "spread";
export declare const CreateServerResponseServerPlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type CreateServerResponseServerPlacementGroupServersList = Array<number>;
export declare const CreateServerResponseServerPlacementGroupServersList: S.Schema<CreateServerResponseServerPlacementGroupServersList>;
/** The placement group the server is assigned to. */
export interface CreateServerResponseServerPlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateServerResponseServerPlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: CreateServerResponseServerPlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: CreateServerResponseServerPlacementGroupServersList;
}
export declare const CreateServerResponseServerPlacementGroup: S.Schema<CreateServerResponseServerPlacementGroup>;
export interface CreateServerResponseServer {
    /** ID of the [Server](#tag/servers). */
    id: number;
    /** Name of the Server (must be unique per Project and a valid hostname as per RFC 1123). */
    name: string;
    /** Status of the Server. */
    status: CreateServerResponseServerStatus;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
    public_net: CreateServerResponseServerPublicNet;
    /** Private networks information. */
    private_net: CreateServerResponseServerPrivateNetList;
    server_type: CreateServerResponseServerServerType;
    /** Location this Resource is located at. */
    location: CreateServerResponseServerLocation;
    /** Image the server is based on. */
    image: CreateServerResponseServerImage | null;
    /** ISO Image that is attached to this Server. Null if no ISO is attached. */
    iso: CreateServerResponseServerIso | null;
    /** True if rescue mode is enabled. Server will then boot into rescue system on next reboot. */
    rescue_enabled: boolean;
    /** True if Server has been locked and is not available to user. */
    locked: boolean;
    /** Time window (UTC) in which the backup will run, or null if the backups are not enabled. */
    backup_window: string | null;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number | null;
    /** Protection configuration for the Server. */
    protection: CreateServerResponseServerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateServerResponseServerLabelsMap;
    /** IDs of Volumes assigned to this Server. */
    volumes?: CreateServerResponseServerVolumesList;
    /** Load Balancer IDs assigned to the server. */
    load_balancers?: CreateServerResponseServerLoadBalancersList;
    /** Size of the primary Disk. */
    primary_disk_size: number;
    /** The placement group the server is assigned to. */
    placement_group?: CreateServerResponseServerPlacementGroup | null;
}
export declare const CreateServerResponseServer: S.Schema<CreateServerResponseServer>;
/** Status of the Action. */
export type CreateServerResponseActionStatus = "running" | "success" | "error";
export declare const CreateServerResponseActionStatus: any;
export interface CreateServerResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateServerResponseActionResourcesItem: S.Schema<CreateServerResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateServerResponseActionResourcesList = Array<CreateServerResponseActionResourcesItem>;
export declare const CreateServerResponseActionResourcesList: S.Schema<CreateServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateServerResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateServerResponseActionError: S.Schema<CreateServerResponseActionError>;
export interface CreateServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateServerResponseActionError | null;
}
export declare const CreateServerResponseAction: S.Schema<CreateServerResponseAction>;
/** Status of the Action. */
export type CreateServerResponseNextActionsItemStatus = "running" | "success" | "error";
export declare const CreateServerResponseNextActionsItemStatus: any;
export type CreateServerResponseNextActionsItemResourcesItem = CreateServerResponseActionResourcesItem;
export declare const CreateServerResponseNextActionsItemResourcesItem: S.Schema<CreateServerResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateServerResponseNextActionsItemResourcesList = Array<CreateServerResponseActionResourcesItem>;
export declare const CreateServerResponseNextActionsItemResourcesList: S.Schema<CreateServerResponseNextActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type CreateServerResponseNextActionsItemError = CreateServerResponseActionError;
export declare const CreateServerResponseNextActionsItemError: S.Schema<CreateServerResponseActionError>;
export interface CreateServerResponseNextActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateServerResponseNextActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateServerResponseNextActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateServerResponseActionError | null;
}
export declare const CreateServerResponseNextActionsItem: S.Schema<CreateServerResponseNextActionsItem>;
export type CreateServerResponseNextActionsList = Array<CreateServerResponseNextActionsItem>;
export declare const CreateServerResponseNextActionsList: S.Schema<CreateServerResponseNextActionsList>;
export interface CreateServerResponse {
    server: CreateServerResponseServer;
    action: CreateServerResponseAction;
    next_actions: CreateServerResponseNextActionsList;
    /** Root password when no SSH keys have been specified. */
    root_password: string | Redacted.Redacted<string> | null;
}
export declare const CreateServerResponse: S.Schema<CreateServerResponse>;
export interface DeleteServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const DeleteServerRequest: S.Schema<DeleteServerRequest>;
/** Status of the Action. */
export type DeleteServerResponseActionStatus = "running" | "success" | "error";
export declare const DeleteServerResponseActionStatus: any;
export type DeleteServerResponseActionResourcesItem = CreateServerResponseActionResourcesItem;
export declare const DeleteServerResponseActionResourcesItem: S.Schema<CreateServerResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DeleteServerResponseActionResourcesList = Array<CreateServerResponseActionResourcesItem>;
export declare const DeleteServerResponseActionResourcesList: S.Schema<DeleteServerResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DeleteServerResponseActionError = CreateServerResponseActionError;
export declare const DeleteServerResponseActionError: S.Schema<CreateServerResponseActionError>;
export interface DeleteServerResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DeleteServerResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DeleteServerResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateServerResponseActionError | null;
}
export declare const DeleteServerResponseAction: S.Schema<DeleteServerResponseAction>;
export interface DeleteServerResponse {
    action?: DeleteServerResponseAction;
}
export declare const DeleteServerResponse: S.Schema<DeleteServerResponse>;
export interface GetServerRequest {
    /** ID of the Server. */
    id: number;
}
export declare const GetServerRequest: S.Schema<GetServerRequest>;
/** Status of the Server. */
export type GetServerResponseServerStatus = "running" | "initializing" | "starting" | "stopping" | "off" | "deleting" | "migrating" | "rebuilding" | "unknown";
export declare const GetServerResponseServerStatus: any;
/** IP address (v4) and its reverse DNS entry of this Server. */
export type GetServerResponseServerPublicNetIpv4 = CreateServerResponseServerPublicNetIpv4;
export declare const GetServerResponseServerPublicNetIpv4: S.Schema<CreateServerResponseServerPublicNetIpv4>;
export type GetServerResponseServerPublicNetIpv6DnsPtrItem = CreateServerResponseServerPublicNetIpv6DnsPtrItem;
export declare const GetServerResponseServerPublicNetIpv6DnsPtrItem: S.Schema<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
/** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
export type GetServerResponseServerPublicNetIpv6DnsPtrList = Array<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
export declare const GetServerResponseServerPublicNetIpv6DnsPtrList: S.Schema<GetServerResponseServerPublicNetIpv6DnsPtrList>;
/** IPv6 network assigned to this Server and its reverse DNS entry. */
export interface GetServerResponseServerPublicNetIpv6 {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id?: number;
    /** IP address (v6) of this Server. */
    ip: string;
    /** If the IP is blocked by our anti abuse dept. */
    blocked: boolean;
    /** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
    dns_ptr: GetServerResponseServerPublicNetIpv6DnsPtrList | null;
}
export declare const GetServerResponseServerPublicNetIpv6: S.Schema<GetServerResponseServerPublicNetIpv6>;
/** IDs of Floating IPs assigned to this Server. */
export type GetServerResponseServerPublicNetFloatingIpsList = Array<number>;
export declare const GetServerResponseServerPublicNetFloatingIpsList: S.Schema<GetServerResponseServerPublicNetFloatingIpsList>;
/** Status of the Firewall on the Server. */
export type GetServerResponseServerPublicNetFirewallsItemStatus = "applied" | "pending";
export declare const GetServerResponseServerPublicNetFirewallsItemStatus: any;
export interface GetServerResponseServerPublicNetFirewallsItem {
    /** ID of the [Firewall](#tag/firewalls). */
    id?: number;
    /** Status of the Firewall on the Server. */
    status?: GetServerResponseServerPublicNetFirewallsItemStatus;
}
export declare const GetServerResponseServerPublicNetFirewallsItem: S.Schema<GetServerResponseServerPublicNetFirewallsItem>;
/** Firewalls applied to the public network interface of this Server. */
export type GetServerResponseServerPublicNetFirewallsList = Array<GetServerResponseServerPublicNetFirewallsItem>;
export declare const GetServerResponseServerPublicNetFirewallsList: S.Schema<GetServerResponseServerPublicNetFirewallsList>;
/** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
export interface GetServerResponseServerPublicNet {
    /** IP address (v4) and its reverse DNS entry of this Server. */
    ipv4: CreateServerResponseServerPublicNetIpv4 | null;
    /** IPv6 network assigned to this Server and its reverse DNS entry. */
    ipv6: GetServerResponseServerPublicNetIpv6 | null;
    /** IDs of Floating IPs assigned to this Server. */
    floating_ips: GetServerResponseServerPublicNetFloatingIpsList;
    /** Firewalls applied to the public network interface of this Server. */
    firewalls?: GetServerResponseServerPublicNetFirewallsList;
}
export declare const GetServerResponseServerPublicNet: S.Schema<GetServerResponseServerPublicNet>;
/** Additional IP addresses of the server on the network. */
export type GetServerResponseServerPrivateNetItemAliasIpsList = Array<string>;
export declare const GetServerResponseServerPrivateNetItemAliasIpsList: S.Schema<GetServerResponseServerPrivateNetItemAliasIpsList>;
export interface GetServerResponseServerPrivateNetItem {
    /** The Network ID the server is attached to. */
    network?: number;
    /** The server IP address on the network. */
    ip?: string;
    /** Additional IP addresses of the server on the network. */
    alias_ips?: GetServerResponseServerPrivateNetItemAliasIpsList;
    /** The server MAC address on the network. */
    mac_address?: string;
}
export declare const GetServerResponseServerPrivateNetItem: S.Schema<GetServerResponseServerPrivateNetItem>;
/** Private networks information. */
export type GetServerResponseServerPrivateNetList = Array<GetServerResponseServerPrivateNetItem>;
export declare const GetServerResponseServerPrivateNetList: S.Schema<GetServerResponseServerPrivateNetList>;
/** Hourly price in this [Location](#tag/locations). */
export type GetServerResponseServerServerTypePricesItemPriceHourly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const GetServerResponseServerServerTypePricesItemPriceHourly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetServerResponseServerServerTypePricesItemPriceMonthly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const GetServerResponseServerServerTypePricesItemPriceMonthly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type GetServerResponseServerServerTypePricesItemPricePerTbTraffic = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const GetServerResponseServerServerTypePricesItemPricePerTbTraffic: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
export type GetServerResponseServerServerTypePricesItem = CreateServerResponseServerServerTypePricesItem;
export declare const GetServerResponseServerServerTypePricesItem: S.Schema<CreateServerResponseServerServerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type GetServerResponseServerServerTypePricesList = Array<CreateServerResponseServerServerTypePricesItem>;
export declare const GetServerResponseServerServerTypePricesList: S.Schema<GetServerResponseServerServerTypePricesList>;
/** Type of Server boot drive. Local has higher speed. Network has better availability. */
export type GetServerResponseServerServerTypeStorageType = "local" | "network";
export declare const GetServerResponseServerServerTypeStorageType: any;
/** Type of cpu. */
export type GetServerResponseServerServerTypeCpuType = "shared" | "dedicated";
export declare const GetServerResponseServerServerTypeCpuType: any;
/** CPU architecture of the Server Type. */
export type GetServerResponseServerServerTypeArchitecture = "x86" | "arm";
export declare const GetServerResponseServerServerTypeArchitecture: any;
/** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
export type GetServerResponseServerServerTypeDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const GetServerResponseServerServerTypeDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type GetServerResponseServerServerTypeLocationsItemDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const GetServerResponseServerServerTypeLocationsItemDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** A [Location](#tag/locations) (containing only id and name) and Server Type specific metadata. */
export type GetServerResponseServerServerTypeLocationsItem = CreateServerResponseServerServerTypeLocationsItem;
export declare const GetServerResponseServerServerTypeLocationsItem: S.Schema<CreateServerResponseServerServerTypeLocationsItem>;
/** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
export type GetServerResponseServerServerTypeLocationsList = Array<CreateServerResponseServerServerTypeLocationsItem>;
export declare const GetServerResponseServerServerTypeLocationsList: S.Schema<GetServerResponseServerServerTypeLocationsList>;
export interface GetServerResponseServerServerType {
    /** ID of the Server type. */
    id: number;
    /** Unique identifier of the Server type. */
    name: string;
    /** Description of the Server type. */
    description: string;
    /** Number of cpu cores a Server of this type will have. */
    cores: number;
    /** Memory a Server of this type will have in GB. */
    memory: number;
    /** Disk size a Server of this type will have in GB. */
    disk: number;
    /** This field is deprecated. Use the deprecation object instead. */
    deprecated: boolean;
    /** Price per [Location](#tag/locations). */
    prices: GetServerResponseServerServerTypePricesList;
    /** Type of Server boot drive. Local has higher speed. Network has better availability. */
    storage_type: GetServerResponseServerServerTypeStorageType;
    /** Type of cpu. */
    cpu_type: GetServerResponseServerServerTypeCpuType;
    /** Category of Server Type. */
    category?: string;
    /** CPU architecture of the Server Type. */
    architecture: GetServerResponseServerServerTypeArchitecture;
    /** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
    deprecation?: CreateServerResponseServerServerTypeDeprecation | null;
    /** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
    locations: GetServerResponseServerServerTypeLocationsList;
}
export declare const GetServerResponseServerServerType: S.Schema<GetServerResponseServerServerType>;
/** Location this Resource is located at. */
export type GetServerResponseServerLocation = CreateServerResponseServerLocation;
export declare const GetServerResponseServerLocation: S.Schema<CreateServerResponseServerLocation>;
/** Type of the Image. */
export type GetServerResponseServerImageType = "system" | "app" | "snapshot" | "backup";
export declare const GetServerResponseServerImageType: any;
/** Status of the Image. */
export type GetServerResponseServerImageStatus = "available" | "creating" | "unavailable";
export declare const GetServerResponseServerImageStatus: any;
/** Information about the Server the Image was created from. */
export type GetServerResponseServerImageCreatedFrom = CreateServerResponseServerImageCreatedFrom;
export declare const GetServerResponseServerImageCreatedFrom: S.Schema<CreateServerResponseServerImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type GetServerResponseServerImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const GetServerResponseServerImageOsFlavor: any;
/** Protection configuration for the Resource. */
export type GetServerResponseServerImageProtection = CreateServerResponseServerImageProtection;
export declare const GetServerResponseServerImageProtection: S.Schema<CreateServerResponseServerImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetServerResponseServerImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetServerResponseServerImageLabelsMap: S.Schema<GetServerResponseServerImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type GetServerResponseServerImageArchitecture = "x86" | "arm";
export declare const GetServerResponseServerImageArchitecture: any;
/** Image the server is based on. */
export interface GetServerResponseServerImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: GetServerResponseServerImageType;
    /** Status of the Image. */
    status: GetServerResponseServerImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: CreateServerResponseServerImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: GetServerResponseServerImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateServerResponseServerImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetServerResponseServerImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: GetServerResponseServerImageArchitecture;
}
export declare const GetServerResponseServerImage: S.Schema<GetServerResponseServerImage>;
/** Type of the ISO. */
export type GetServerResponseServerIsoType = "public" | "private";
export declare const GetServerResponseServerIsoType: any;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type GetServerResponseServerIsoDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const GetServerResponseServerIsoDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
export type GetServerResponseServerIsoArchitecture = "x86" | "arm";
export declare const GetServerResponseServerIsoArchitecture: any;
/** ISO Image that is attached to this Server. Null if no ISO is attached. */
export interface GetServerResponseServerIso {
    /** ID of the [ISO](#tag/isos). */
    id: number;
    /** Unique identifier of the ISO. Only set for public ISOs. */
    name: string | null;
    /** Description of the ISO. */
    description: string;
    /** Type of the ISO. */
    type: GetServerResponseServerIsoType | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateServerResponseServerServerTypeDeprecation | null;
    /** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
    architecture: GetServerResponseServerIsoArchitecture | null;
}
export declare const GetServerResponseServerIso: S.Schema<GetServerResponseServerIso>;
/** Protection configuration for the Server. */
export type GetServerResponseServerProtection = CreateServerResponseServerProtection;
export declare const GetServerResponseServerProtection: S.Schema<CreateServerResponseServerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetServerResponseServerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetServerResponseServerLabelsMap: S.Schema<GetServerResponseServerLabelsMap>;
/** IDs of Volumes assigned to this Server. */
export type GetServerResponseServerVolumesList = Array<number>;
export declare const GetServerResponseServerVolumesList: S.Schema<GetServerResponseServerVolumesList>;
/** Load Balancer IDs assigned to the server. */
export type GetServerResponseServerLoadBalancersList = Array<number>;
export declare const GetServerResponseServerLoadBalancersList: S.Schema<GetServerResponseServerLoadBalancersList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetServerResponseServerPlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetServerResponseServerPlacementGroupLabelsMap: S.Schema<GetServerResponseServerPlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type GetServerResponseServerPlacementGroupType = "spread";
export declare const GetServerResponseServerPlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type GetServerResponseServerPlacementGroupServersList = Array<number>;
export declare const GetServerResponseServerPlacementGroupServersList: S.Schema<GetServerResponseServerPlacementGroupServersList>;
/** The placement group the server is assigned to. */
export interface GetServerResponseServerPlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetServerResponseServerPlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: GetServerResponseServerPlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: GetServerResponseServerPlacementGroupServersList;
}
export declare const GetServerResponseServerPlacementGroup: S.Schema<GetServerResponseServerPlacementGroup>;
export interface GetServerResponseServer {
    /** ID of the [Server](#tag/servers). */
    id: number;
    /** Name of the Server (must be unique per Project and a valid hostname as per RFC 1123). */
    name: string;
    /** Status of the Server. */
    status: GetServerResponseServerStatus;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
    public_net: GetServerResponseServerPublicNet;
    /** Private networks information. */
    private_net: GetServerResponseServerPrivateNetList;
    server_type: GetServerResponseServerServerType;
    /** Location this Resource is located at. */
    location: CreateServerResponseServerLocation;
    /** Image the server is based on. */
    image: GetServerResponseServerImage | null;
    /** ISO Image that is attached to this Server. Null if no ISO is attached. */
    iso: GetServerResponseServerIso | null;
    /** True if rescue mode is enabled. Server will then boot into rescue system on next reboot. */
    rescue_enabled: boolean;
    /** True if Server has been locked and is not available to user. */
    locked: boolean;
    /** Time window (UTC) in which the backup will run, or null if the backups are not enabled. */
    backup_window: string | null;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number | null;
    /** Protection configuration for the Server. */
    protection: CreateServerResponseServerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetServerResponseServerLabelsMap;
    /** IDs of Volumes assigned to this Server. */
    volumes?: GetServerResponseServerVolumesList;
    /** Load Balancer IDs assigned to the server. */
    load_balancers?: GetServerResponseServerLoadBalancersList;
    /** Size of the primary Disk. */
    primary_disk_size: number;
    /** The placement group the server is assigned to. */
    placement_group?: GetServerResponseServerPlacementGroup | null;
}
export declare const GetServerResponseServer: S.Schema<GetServerResponseServer>;
export interface GetServerResponse {
    server?: GetServerResponseServer;
}
export declare const GetServerResponse: S.Schema<GetServerResponse>;
export type GetServerMetricsRequestTypeItem = "cpu" | "disk" | "network";
export declare const GetServerMetricsRequestTypeItem: any;
export type GetServerMetricsRequestTypeList = Array<GetServerMetricsRequestTypeItem | (string & {})>;
export declare const GetServerMetricsRequestTypeList: S.Schema<GetServerMetricsRequestTypeList>;
export interface GetServerMetricsRequest {
    /** ID of the Server. */
    id: number;
    /** Type of metrics to get. */
    type: GetServerMetricsRequestTypeList;
    /** Start of period to get Metrics for (must be in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    start: string;
    /** End of period to get Metrics for (must be in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    end: string;
    /** Resolution of results in seconds. */
    step?: string;
}
export declare const GetServerMetricsRequest: S.Schema<GetServerMetricsRequest>;
export type GetServerMetricsResponseMetricsTimeSeriesValueValuesItemList = Array<unknown>;
export declare const GetServerMetricsResponseMetricsTimeSeriesValueValuesItemList: S.Schema<GetServerMetricsResponseMetricsTimeSeriesValueValuesItemList>;
/** Metrics timestamps with values. */
export type GetServerMetricsResponseMetricsTimeSeriesValueValuesList = Array<GetServerMetricsResponseMetricsTimeSeriesValueValuesItemList>;
export declare const GetServerMetricsResponseMetricsTimeSeriesValueValuesList: S.Schema<GetServerMetricsResponseMetricsTimeSeriesValueValuesList>;
export interface GetServerMetricsResponseMetricsTimeSeriesValue {
    /** Metrics timestamps with values. */
    values: GetServerMetricsResponseMetricsTimeSeriesValueValuesList;
}
export declare const GetServerMetricsResponseMetricsTimeSeriesValue: S.Schema<GetServerMetricsResponseMetricsTimeSeriesValue>;
/** Hash with timeseries information, containing the name of timeseries as key. */
export type GetServerMetricsResponseMetricsTimeSeriesMap = {
    [key: string]: GetServerMetricsResponseMetricsTimeSeriesValue | undefined;
};
export declare const GetServerMetricsResponseMetricsTimeSeriesMap: S.Schema<GetServerMetricsResponseMetricsTimeSeriesMap>;
export interface GetServerMetricsResponseMetrics {
    /** Start of period of metrics reported (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    start: string;
    /** End of period of metrics reported (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    end: string;
    /** Resolution of results in seconds. */
    step: number;
    /** Hash with timeseries information, containing the name of timeseries as key. */
    time_series: GetServerMetricsResponseMetricsTimeSeriesMap;
}
export declare const GetServerMetricsResponseMetrics: S.Schema<GetServerMetricsResponseMetrics>;
export interface GetServerMetricsResponse {
    metrics: GetServerMetricsResponseMetrics;
}
export declare const GetServerMetricsResponse: S.Schema<GetServerMetricsResponse>;
export type ListServersRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListServersRequestSortItem: any;
export type ListServersRequestSortList = Array<ListServersRequestSortItem | (string & {})>;
export declare const ListServersRequestSortList: S.Schema<ListServersRequestSortList>;
/** Status of the Server. */
export type ListServersRequestStatusItem = "running" | "initializing" | "starting" | "stopping" | "off" | "deleting" | "migrating" | "rebuilding" | "unknown";
export declare const ListServersRequestStatusItem: any;
export type ListServersRequestStatusList = Array<ListServersRequestStatusItem | (string & {})>;
export declare const ListServersRequestStatusList: S.Schema<ListServersRequestStatusList>;
export interface ListServersRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListServersRequestSortList;
    /** Filter resources by status. May be used multiple times. The response will only contain the resources with the specified status. */
    status?: ListServersRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListServersRequest: S.Schema<ListServersRequest>;
/** Status of the Server. */
export type ListServersResponseServersItemStatus = "running" | "initializing" | "starting" | "stopping" | "off" | "deleting" | "migrating" | "rebuilding" | "unknown";
export declare const ListServersResponseServersItemStatus: any;
/** IP address (v4) and its reverse DNS entry of this Server. */
export type ListServersResponseServersItemPublicNetIpv4 = CreateServerResponseServerPublicNetIpv4;
export declare const ListServersResponseServersItemPublicNetIpv4: S.Schema<CreateServerResponseServerPublicNetIpv4>;
export type ListServersResponseServersItemPublicNetIpv6DnsPtrItem = CreateServerResponseServerPublicNetIpv6DnsPtrItem;
export declare const ListServersResponseServersItemPublicNetIpv6DnsPtrItem: S.Schema<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
/** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
export type ListServersResponseServersItemPublicNetIpv6DnsPtrList = Array<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
export declare const ListServersResponseServersItemPublicNetIpv6DnsPtrList: S.Schema<ListServersResponseServersItemPublicNetIpv6DnsPtrList>;
/** IPv6 network assigned to this Server and its reverse DNS entry. */
export interface ListServersResponseServersItemPublicNetIpv6 {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id?: number;
    /** IP address (v6) of this Server. */
    ip: string;
    /** If the IP is blocked by our anti abuse dept. */
    blocked: boolean;
    /** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
    dns_ptr: ListServersResponseServersItemPublicNetIpv6DnsPtrList | null;
}
export declare const ListServersResponseServersItemPublicNetIpv6: S.Schema<ListServersResponseServersItemPublicNetIpv6>;
/** IDs of Floating IPs assigned to this Server. */
export type ListServersResponseServersItemPublicNetFloatingIpsList = Array<number>;
export declare const ListServersResponseServersItemPublicNetFloatingIpsList: S.Schema<ListServersResponseServersItemPublicNetFloatingIpsList>;
/** Status of the Firewall on the Server. */
export type ListServersResponseServersItemPublicNetFirewallsItemStatus = "applied" | "pending";
export declare const ListServersResponseServersItemPublicNetFirewallsItemStatus: any;
export interface ListServersResponseServersItemPublicNetFirewallsItem {
    /** ID of the [Firewall](#tag/firewalls). */
    id?: number;
    /** Status of the Firewall on the Server. */
    status?: ListServersResponseServersItemPublicNetFirewallsItemStatus;
}
export declare const ListServersResponseServersItemPublicNetFirewallsItem: S.Schema<ListServersResponseServersItemPublicNetFirewallsItem>;
/** Firewalls applied to the public network interface of this Server. */
export type ListServersResponseServersItemPublicNetFirewallsList = Array<ListServersResponseServersItemPublicNetFirewallsItem>;
export declare const ListServersResponseServersItemPublicNetFirewallsList: S.Schema<ListServersResponseServersItemPublicNetFirewallsList>;
/** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
export interface ListServersResponseServersItemPublicNet {
    /** IP address (v4) and its reverse DNS entry of this Server. */
    ipv4: CreateServerResponseServerPublicNetIpv4 | null;
    /** IPv6 network assigned to this Server and its reverse DNS entry. */
    ipv6: ListServersResponseServersItemPublicNetIpv6 | null;
    /** IDs of Floating IPs assigned to this Server. */
    floating_ips: ListServersResponseServersItemPublicNetFloatingIpsList;
    /** Firewalls applied to the public network interface of this Server. */
    firewalls?: ListServersResponseServersItemPublicNetFirewallsList;
}
export declare const ListServersResponseServersItemPublicNet: S.Schema<ListServersResponseServersItemPublicNet>;
/** Additional IP addresses of the server on the network. */
export type ListServersResponseServersItemPrivateNetItemAliasIpsList = Array<string>;
export declare const ListServersResponseServersItemPrivateNetItemAliasIpsList: S.Schema<ListServersResponseServersItemPrivateNetItemAliasIpsList>;
export interface ListServersResponseServersItemPrivateNetItem {
    /** The Network ID the server is attached to. */
    network?: number;
    /** The server IP address on the network. */
    ip?: string;
    /** Additional IP addresses of the server on the network. */
    alias_ips?: ListServersResponseServersItemPrivateNetItemAliasIpsList;
    /** The server MAC address on the network. */
    mac_address?: string;
}
export declare const ListServersResponseServersItemPrivateNetItem: S.Schema<ListServersResponseServersItemPrivateNetItem>;
/** Private networks information. */
export type ListServersResponseServersItemPrivateNetList = Array<ListServersResponseServersItemPrivateNetItem>;
export declare const ListServersResponseServersItemPrivateNetList: S.Schema<ListServersResponseServersItemPrivateNetList>;
/** Hourly price in this [Location](#tag/locations). */
export type ListServersResponseServersItemServerTypePricesItemPriceHourly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const ListServersResponseServersItemServerTypePricesItemPriceHourly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type ListServersResponseServersItemServerTypePricesItemPriceMonthly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const ListServersResponseServersItemServerTypePricesItemPriceMonthly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type ListServersResponseServersItemServerTypePricesItemPricePerTbTraffic = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const ListServersResponseServersItemServerTypePricesItemPricePerTbTraffic: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
export type ListServersResponseServersItemServerTypePricesItem = CreateServerResponseServerServerTypePricesItem;
export declare const ListServersResponseServersItemServerTypePricesItem: S.Schema<CreateServerResponseServerServerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type ListServersResponseServersItemServerTypePricesList = Array<CreateServerResponseServerServerTypePricesItem>;
export declare const ListServersResponseServersItemServerTypePricesList: S.Schema<ListServersResponseServersItemServerTypePricesList>;
/** Type of Server boot drive. Local has higher speed. Network has better availability. */
export type ListServersResponseServersItemServerTypeStorageType = "local" | "network";
export declare const ListServersResponseServersItemServerTypeStorageType: any;
/** Type of cpu. */
export type ListServersResponseServersItemServerTypeCpuType = "shared" | "dedicated";
export declare const ListServersResponseServersItemServerTypeCpuType: any;
/** CPU architecture of the Server Type. */
export type ListServersResponseServersItemServerTypeArchitecture = "x86" | "arm";
export declare const ListServersResponseServersItemServerTypeArchitecture: any;
/** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
export type ListServersResponseServersItemServerTypeDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const ListServersResponseServersItemServerTypeDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type ListServersResponseServersItemServerTypeLocationsItemDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const ListServersResponseServersItemServerTypeLocationsItemDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** A [Location](#tag/locations) (containing only id and name) and Server Type specific metadata. */
export type ListServersResponseServersItemServerTypeLocationsItem = CreateServerResponseServerServerTypeLocationsItem;
export declare const ListServersResponseServersItemServerTypeLocationsItem: S.Schema<CreateServerResponseServerServerTypeLocationsItem>;
/** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
export type ListServersResponseServersItemServerTypeLocationsList = Array<CreateServerResponseServerServerTypeLocationsItem>;
export declare const ListServersResponseServersItemServerTypeLocationsList: S.Schema<ListServersResponseServersItemServerTypeLocationsList>;
export interface ListServersResponseServersItemServerType {
    /** ID of the Server type. */
    id: number;
    /** Unique identifier of the Server type. */
    name: string;
    /** Description of the Server type. */
    description: string;
    /** Number of cpu cores a Server of this type will have. */
    cores: number;
    /** Memory a Server of this type will have in GB. */
    memory: number;
    /** Disk size a Server of this type will have in GB. */
    disk: number;
    /** This field is deprecated. Use the deprecation object instead. */
    deprecated: boolean;
    /** Price per [Location](#tag/locations). */
    prices: ListServersResponseServersItemServerTypePricesList;
    /** Type of Server boot drive. Local has higher speed. Network has better availability. */
    storage_type: ListServersResponseServersItemServerTypeStorageType;
    /** Type of cpu. */
    cpu_type: ListServersResponseServersItemServerTypeCpuType;
    /** Category of Server Type. */
    category?: string;
    /** CPU architecture of the Server Type. */
    architecture: ListServersResponseServersItemServerTypeArchitecture;
    /** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
    deprecation?: CreateServerResponseServerServerTypeDeprecation | null;
    /** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
    locations: ListServersResponseServersItemServerTypeLocationsList;
}
export declare const ListServersResponseServersItemServerType: S.Schema<ListServersResponseServersItemServerType>;
/** Location this Resource is located at. */
export type ListServersResponseServersItemLocation = CreateServerResponseServerLocation;
export declare const ListServersResponseServersItemLocation: S.Schema<CreateServerResponseServerLocation>;
/** Type of the Image. */
export type ListServersResponseServersItemImageType = "system" | "app" | "snapshot" | "backup";
export declare const ListServersResponseServersItemImageType: any;
/** Status of the Image. */
export type ListServersResponseServersItemImageStatus = "available" | "creating" | "unavailable";
export declare const ListServersResponseServersItemImageStatus: any;
/** Information about the Server the Image was created from. */
export type ListServersResponseServersItemImageCreatedFrom = CreateServerResponseServerImageCreatedFrom;
export declare const ListServersResponseServersItemImageCreatedFrom: S.Schema<CreateServerResponseServerImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type ListServersResponseServersItemImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const ListServersResponseServersItemImageOsFlavor: any;
/** Protection configuration for the Resource. */
export type ListServersResponseServersItemImageProtection = CreateServerResponseServerImageProtection;
export declare const ListServersResponseServersItemImageProtection: S.Schema<CreateServerResponseServerImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListServersResponseServersItemImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListServersResponseServersItemImageLabelsMap: S.Schema<ListServersResponseServersItemImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type ListServersResponseServersItemImageArchitecture = "x86" | "arm";
export declare const ListServersResponseServersItemImageArchitecture: any;
/** Image the server is based on. */
export interface ListServersResponseServersItemImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: ListServersResponseServersItemImageType;
    /** Status of the Image. */
    status: ListServersResponseServersItemImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: CreateServerResponseServerImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: ListServersResponseServersItemImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateServerResponseServerImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListServersResponseServersItemImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: ListServersResponseServersItemImageArchitecture;
}
export declare const ListServersResponseServersItemImage: S.Schema<ListServersResponseServersItemImage>;
/** Type of the ISO. */
export type ListServersResponseServersItemIsoType = "public" | "private";
export declare const ListServersResponseServersItemIsoType: any;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type ListServersResponseServersItemIsoDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const ListServersResponseServersItemIsoDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
export type ListServersResponseServersItemIsoArchitecture = "x86" | "arm";
export declare const ListServersResponseServersItemIsoArchitecture: any;
/** ISO Image that is attached to this Server. Null if no ISO is attached. */
export interface ListServersResponseServersItemIso {
    /** ID of the [ISO](#tag/isos). */
    id: number;
    /** Unique identifier of the ISO. Only set for public ISOs. */
    name: string | null;
    /** Description of the ISO. */
    description: string;
    /** Type of the ISO. */
    type: ListServersResponseServersItemIsoType | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateServerResponseServerServerTypeDeprecation | null;
    /** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
    architecture: ListServersResponseServersItemIsoArchitecture | null;
}
export declare const ListServersResponseServersItemIso: S.Schema<ListServersResponseServersItemIso>;
/** Protection configuration for the Server. */
export type ListServersResponseServersItemProtection = CreateServerResponseServerProtection;
export declare const ListServersResponseServersItemProtection: S.Schema<CreateServerResponseServerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListServersResponseServersItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListServersResponseServersItemLabelsMap: S.Schema<ListServersResponseServersItemLabelsMap>;
/** IDs of Volumes assigned to this Server. */
export type ListServersResponseServersItemVolumesList = Array<number>;
export declare const ListServersResponseServersItemVolumesList: S.Schema<ListServersResponseServersItemVolumesList>;
/** Load Balancer IDs assigned to the server. */
export type ListServersResponseServersItemLoadBalancersList = Array<number>;
export declare const ListServersResponseServersItemLoadBalancersList: S.Schema<ListServersResponseServersItemLoadBalancersList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListServersResponseServersItemPlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListServersResponseServersItemPlacementGroupLabelsMap: S.Schema<ListServersResponseServersItemPlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type ListServersResponseServersItemPlacementGroupType = "spread";
export declare const ListServersResponseServersItemPlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type ListServersResponseServersItemPlacementGroupServersList = Array<number>;
export declare const ListServersResponseServersItemPlacementGroupServersList: S.Schema<ListServersResponseServersItemPlacementGroupServersList>;
/** The placement group the server is assigned to. */
export interface ListServersResponseServersItemPlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListServersResponseServersItemPlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: ListServersResponseServersItemPlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: ListServersResponseServersItemPlacementGroupServersList;
}
export declare const ListServersResponseServersItemPlacementGroup: S.Schema<ListServersResponseServersItemPlacementGroup>;
export interface ListServersResponseServersItem {
    /** ID of the [Server](#tag/servers). */
    id: number;
    /** Name of the Server (must be unique per Project and a valid hostname as per RFC 1123). */
    name: string;
    /** Status of the Server. */
    status: ListServersResponseServersItemStatus;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
    public_net: ListServersResponseServersItemPublicNet;
    /** Private networks information. */
    private_net: ListServersResponseServersItemPrivateNetList;
    server_type: ListServersResponseServersItemServerType;
    /** Location this Resource is located at. */
    location: CreateServerResponseServerLocation;
    /** Image the server is based on. */
    image: ListServersResponseServersItemImage | null;
    /** ISO Image that is attached to this Server. Null if no ISO is attached. */
    iso: ListServersResponseServersItemIso | null;
    /** True if rescue mode is enabled. Server will then boot into rescue system on next reboot. */
    rescue_enabled: boolean;
    /** True if Server has been locked and is not available to user. */
    locked: boolean;
    /** Time window (UTC) in which the backup will run, or null if the backups are not enabled. */
    backup_window: string | null;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number | null;
    /** Protection configuration for the Server. */
    protection: CreateServerResponseServerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListServersResponseServersItemLabelsMap;
    /** IDs of Volumes assigned to this Server. */
    volumes?: ListServersResponseServersItemVolumesList;
    /** Load Balancer IDs assigned to the server. */
    load_balancers?: ListServersResponseServersItemLoadBalancersList;
    /** Size of the primary Disk. */
    primary_disk_size: number;
    /** The placement group the server is assigned to. */
    placement_group?: ListServersResponseServersItemPlacementGroup | null;
}
export declare const ListServersResponseServersItem: S.Schema<ListServersResponseServersItem>;
export type ListServersResponseServersList = Array<ListServersResponseServersItem>;
export declare const ListServersResponseServersList: S.Schema<ListServersResponseServersList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListServersResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListServersResponseMetaPagination: S.Schema<ListServersResponseMetaPagination>;
export interface ListServersResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListServersResponseMetaPagination;
}
export declare const ListServersResponseMeta: S.Schema<ListServersResponseMeta>;
export interface ListServersResponse {
    servers: ListServersResponseServersList;
    meta: ListServersResponseMeta;
}
export declare const ListServersResponse: S.Schema<ListServersResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateServerRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateServerRequestLabelsMap: S.Schema<UpdateServerRequestLabelsMap>;
export interface UpdateServerRequest {
    /** ID of the Server. */
    id: number;
    /** New name to set. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateServerRequestLabelsMap;
}
export declare const UpdateServerRequest: S.Schema<UpdateServerRequest>;
/** Status of the Server. */
export type UpdateServerResponseServerStatus = "running" | "initializing" | "starting" | "stopping" | "off" | "deleting" | "migrating" | "rebuilding" | "unknown";
export declare const UpdateServerResponseServerStatus: any;
/** IP address (v4) and its reverse DNS entry of this Server. */
export type UpdateServerResponseServerPublicNetIpv4 = CreateServerResponseServerPublicNetIpv4;
export declare const UpdateServerResponseServerPublicNetIpv4: S.Schema<CreateServerResponseServerPublicNetIpv4>;
export type UpdateServerResponseServerPublicNetIpv6DnsPtrItem = CreateServerResponseServerPublicNetIpv6DnsPtrItem;
export declare const UpdateServerResponseServerPublicNetIpv6DnsPtrItem: S.Schema<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
/** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
export type UpdateServerResponseServerPublicNetIpv6DnsPtrList = Array<CreateServerResponseServerPublicNetIpv6DnsPtrItem>;
export declare const UpdateServerResponseServerPublicNetIpv6DnsPtrList: S.Schema<UpdateServerResponseServerPublicNetIpv6DnsPtrList>;
/** IPv6 network assigned to this Server and its reverse DNS entry. */
export interface UpdateServerResponseServerPublicNetIpv6 {
    /** ID of the [Primary IP](#tag/primary-ips). */
    id?: number;
    /** IP address (v6) of this Server. */
    ip: string;
    /** If the IP is blocked by our anti abuse dept. */
    blocked: boolean;
    /** Reverse DNS PTR entries for the IPv6 addresses of this Server. */
    dns_ptr: UpdateServerResponseServerPublicNetIpv6DnsPtrList | null;
}
export declare const UpdateServerResponseServerPublicNetIpv6: S.Schema<UpdateServerResponseServerPublicNetIpv6>;
/** IDs of Floating IPs assigned to this Server. */
export type UpdateServerResponseServerPublicNetFloatingIpsList = Array<number>;
export declare const UpdateServerResponseServerPublicNetFloatingIpsList: S.Schema<UpdateServerResponseServerPublicNetFloatingIpsList>;
/** Status of the Firewall on the Server. */
export type UpdateServerResponseServerPublicNetFirewallsItemStatus = "applied" | "pending";
export declare const UpdateServerResponseServerPublicNetFirewallsItemStatus: any;
export interface UpdateServerResponseServerPublicNetFirewallsItem {
    /** ID of the [Firewall](#tag/firewalls). */
    id?: number;
    /** Status of the Firewall on the Server. */
    status?: UpdateServerResponseServerPublicNetFirewallsItemStatus;
}
export declare const UpdateServerResponseServerPublicNetFirewallsItem: S.Schema<UpdateServerResponseServerPublicNetFirewallsItem>;
/** Firewalls applied to the public network interface of this Server. */
export type UpdateServerResponseServerPublicNetFirewallsList = Array<UpdateServerResponseServerPublicNetFirewallsItem>;
export declare const UpdateServerResponseServerPublicNetFirewallsList: S.Schema<UpdateServerResponseServerPublicNetFirewallsList>;
/** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
export interface UpdateServerResponseServerPublicNet {
    /** IP address (v4) and its reverse DNS entry of this Server. */
    ipv4: CreateServerResponseServerPublicNetIpv4 | null;
    /** IPv6 network assigned to this Server and its reverse DNS entry. */
    ipv6: UpdateServerResponseServerPublicNetIpv6 | null;
    /** IDs of Floating IPs assigned to this Server. */
    floating_ips: UpdateServerResponseServerPublicNetFloatingIpsList;
    /** Firewalls applied to the public network interface of this Server. */
    firewalls?: UpdateServerResponseServerPublicNetFirewallsList;
}
export declare const UpdateServerResponseServerPublicNet: S.Schema<UpdateServerResponseServerPublicNet>;
/** Additional IP addresses of the server on the network. */
export type UpdateServerResponseServerPrivateNetItemAliasIpsList = Array<string>;
export declare const UpdateServerResponseServerPrivateNetItemAliasIpsList: S.Schema<UpdateServerResponseServerPrivateNetItemAliasIpsList>;
export interface UpdateServerResponseServerPrivateNetItem {
    /** The Network ID the server is attached to. */
    network?: number;
    /** The server IP address on the network. */
    ip?: string;
    /** Additional IP addresses of the server on the network. */
    alias_ips?: UpdateServerResponseServerPrivateNetItemAliasIpsList;
    /** The server MAC address on the network. */
    mac_address?: string;
}
export declare const UpdateServerResponseServerPrivateNetItem: S.Schema<UpdateServerResponseServerPrivateNetItem>;
/** Private networks information. */
export type UpdateServerResponseServerPrivateNetList = Array<UpdateServerResponseServerPrivateNetItem>;
export declare const UpdateServerResponseServerPrivateNetList: S.Schema<UpdateServerResponseServerPrivateNetList>;
/** Hourly price in this [Location](#tag/locations). */
export type UpdateServerResponseServerServerTypePricesItemPriceHourly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const UpdateServerResponseServerServerTypePricesItemPriceHourly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type UpdateServerResponseServerServerTypePricesItemPriceMonthly = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const UpdateServerResponseServerServerTypePricesItemPriceMonthly: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type UpdateServerResponseServerServerTypePricesItemPricePerTbTraffic = CreateServerResponseServerServerTypePricesItemPriceHourly;
export declare const UpdateServerResponseServerServerTypePricesItemPricePerTbTraffic: S.Schema<CreateServerResponseServerServerTypePricesItemPriceHourly>;
export type UpdateServerResponseServerServerTypePricesItem = CreateServerResponseServerServerTypePricesItem;
export declare const UpdateServerResponseServerServerTypePricesItem: S.Schema<CreateServerResponseServerServerTypePricesItem>;
/** Price per [Location](#tag/locations). */
export type UpdateServerResponseServerServerTypePricesList = Array<CreateServerResponseServerServerTypePricesItem>;
export declare const UpdateServerResponseServerServerTypePricesList: S.Schema<UpdateServerResponseServerServerTypePricesList>;
/** Type of Server boot drive. Local has higher speed. Network has better availability. */
export type UpdateServerResponseServerServerTypeStorageType = "local" | "network";
export declare const UpdateServerResponseServerServerTypeStorageType: any;
/** Type of cpu. */
export type UpdateServerResponseServerServerTypeCpuType = "shared" | "dedicated";
export declare const UpdateServerResponseServerServerTypeCpuType: any;
/** CPU architecture of the Server Type. */
export type UpdateServerResponseServerServerTypeArchitecture = "x86" | "arm";
export declare const UpdateServerResponseServerServerTypeArchitecture: any;
/** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
export type UpdateServerResponseServerServerTypeDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const UpdateServerResponseServerServerTypeDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type UpdateServerResponseServerServerTypeLocationsItemDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const UpdateServerResponseServerServerTypeLocationsItemDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** A [Location](#tag/locations) (containing only id and name) and Server Type specific metadata. */
export type UpdateServerResponseServerServerTypeLocationsItem = CreateServerResponseServerServerTypeLocationsItem;
export declare const UpdateServerResponseServerServerTypeLocationsItem: S.Schema<CreateServerResponseServerServerTypeLocationsItem>;
/** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
export type UpdateServerResponseServerServerTypeLocationsList = Array<CreateServerResponseServerServerTypeLocationsItem>;
export declare const UpdateServerResponseServerServerTypeLocationsList: S.Schema<UpdateServerResponseServerServerTypeLocationsList>;
export interface UpdateServerResponseServerServerType {
    /** ID of the Server type. */
    id: number;
    /** Unique identifier of the Server type. */
    name: string;
    /** Description of the Server type. */
    description: string;
    /** Number of cpu cores a Server of this type will have. */
    cores: number;
    /** Memory a Server of this type will have in GB. */
    memory: number;
    /** Disk size a Server of this type will have in GB. */
    disk: number;
    /** This field is deprecated. Use the deprecation object instead. */
    deprecated: boolean;
    /** Price per [Location](#tag/locations). */
    prices: UpdateServerResponseServerServerTypePricesList;
    /** Type of Server boot drive. Local has higher speed. Network has better availability. */
    storage_type: UpdateServerResponseServerServerTypeStorageType;
    /** Type of cpu. */
    cpu_type: UpdateServerResponseServerServerTypeCpuType;
    /** Category of Server Type. */
    category?: string;
    /** CPU architecture of the Server Type. */
    architecture: UpdateServerResponseServerServerTypeArchitecture;
    /** This field is deprecated. Use the `deprecation` object in the `locations` field instead (`.locations[].deprecation`). */
    deprecation?: CreateServerResponseServerServerTypeDeprecation | null;
    /** Supported [Location](#tag/locations) and per [Location](#tag/locations) details for the [Server Type](#tag/server-types). A [Server Type](#tag/server-types) is: - only supported in the [Location](#tag/locations) that are listed. - deprecated in the [Location](#tag/locations) when the `deprecation` property is set. - permanently unavailable in the [Location](#tag/locations) when the `deprecation.unavailable_after` date is in the past. - temporarily unavailable in the [Location](#tag/locations) when the `deprecation.available` is false. */
    locations: UpdateServerResponseServerServerTypeLocationsList;
}
export declare const UpdateServerResponseServerServerType: S.Schema<UpdateServerResponseServerServerType>;
/** Location this Resource is located at. */
export type UpdateServerResponseServerLocation = CreateServerResponseServerLocation;
export declare const UpdateServerResponseServerLocation: S.Schema<CreateServerResponseServerLocation>;
/** Type of the Image. */
export type UpdateServerResponseServerImageType = "system" | "app" | "snapshot" | "backup";
export declare const UpdateServerResponseServerImageType: any;
/** Status of the Image. */
export type UpdateServerResponseServerImageStatus = "available" | "creating" | "unavailable";
export declare const UpdateServerResponseServerImageStatus: any;
/** Information about the Server the Image was created from. */
export type UpdateServerResponseServerImageCreatedFrom = CreateServerResponseServerImageCreatedFrom;
export declare const UpdateServerResponseServerImageCreatedFrom: S.Schema<CreateServerResponseServerImageCreatedFrom>;
/** Flavor of operating system contained in the Image. */
export type UpdateServerResponseServerImageOsFlavor = "ubuntu" | "centos" | "debian" | "fedora" | "rocky" | "alma" | "opensuse" | "unknown";
export declare const UpdateServerResponseServerImageOsFlavor: any;
/** Protection configuration for the Resource. */
export type UpdateServerResponseServerImageProtection = CreateServerResponseServerImageProtection;
export declare const UpdateServerResponseServerImageProtection: S.Schema<CreateServerResponseServerImageProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateServerResponseServerImageLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateServerResponseServerImageLabelsMap: S.Schema<UpdateServerResponseServerImageLabelsMap>;
/** CPU architecture compatible with the Image. */
export type UpdateServerResponseServerImageArchitecture = "x86" | "arm";
export declare const UpdateServerResponseServerImageArchitecture: any;
/** Image the server is based on. */
export interface UpdateServerResponseServerImage {
    /** ID of the [Image](#tag/images). */
    id: number;
    /** Type of the Image. */
    type: UpdateServerResponseServerImageType;
    /** Status of the Image. */
    status: UpdateServerResponseServerImageStatus;
    /** Unique identifier of the Image. This value is only set for system Images. */
    name: string | null;
    /** Description of the Image. */
    description: string;
    /** Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. */
    image_size: number | null;
    /** Size of the disk contained in the Image in GB. */
    disk_size: number;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Information about the Server the Image was created from. */
    created_from: CreateServerResponseServerImageCreatedFrom | null;
    /** ID of Server the Image is bound to. Only set for Images of type `backup`. */
    bound_to: number | null;
    /** Flavor of operating system contained in the Image. */
    os_flavor: UpdateServerResponseServerImageOsFlavor;
    /** Operating system version. */
    os_version: string | null;
    /** Indicates that rapid deploy of the Image is available. */
    rapid_deploy?: boolean;
    /** Protection configuration for the Resource. */
    protection: CreateServerResponseServerImageProtection;
    /** Point in time when the Image is considered to be deprecated (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deprecated: string | null;
    /** Point in time where the Image was deleted (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    deleted: string | null;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateServerResponseServerImageLabelsMap;
    /** CPU architecture compatible with the Image. */
    architecture: UpdateServerResponseServerImageArchitecture;
}
export declare const UpdateServerResponseServerImage: S.Schema<UpdateServerResponseServerImage>;
/** Type of the ISO. */
export type UpdateServerResponseServerIsoType = "public" | "private";
export declare const UpdateServerResponseServerIsoType: any;
/** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
export type UpdateServerResponseServerIsoDeprecation = CreateServerResponseServerServerTypeDeprecation;
export declare const UpdateServerResponseServerIsoDeprecation: S.Schema<CreateServerResponseServerServerTypeDeprecation>;
/** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
export type UpdateServerResponseServerIsoArchitecture = "x86" | "arm";
export declare const UpdateServerResponseServerIsoArchitecture: any;
/** ISO Image that is attached to this Server. Null if no ISO is attached. */
export interface UpdateServerResponseServerIso {
    /** ID of the [ISO](#tag/isos). */
    id: number;
    /** Unique identifier of the ISO. Only set for public ISOs. */
    name: string | null;
    /** Description of the ISO. */
    description: string;
    /** Type of the ISO. */
    type: UpdateServerResponseServerIsoType | null;
    /** Describes if, when and how the resource is deprecated. If this field is set to `null` the resource is not deprecated. If a value is set, it is considered deprecated. */
    deprecation: CreateServerResponseServerServerTypeDeprecation | null;
    /** CPU architecture compatible with the ISO. Null indicates no restriction on the architecture (wildcard). */
    architecture: UpdateServerResponseServerIsoArchitecture | null;
}
export declare const UpdateServerResponseServerIso: S.Schema<UpdateServerResponseServerIso>;
/** Protection configuration for the Server. */
export type UpdateServerResponseServerProtection = CreateServerResponseServerProtection;
export declare const UpdateServerResponseServerProtection: S.Schema<CreateServerResponseServerProtection>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateServerResponseServerLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateServerResponseServerLabelsMap: S.Schema<UpdateServerResponseServerLabelsMap>;
/** IDs of Volumes assigned to this Server. */
export type UpdateServerResponseServerVolumesList = Array<number>;
export declare const UpdateServerResponseServerVolumesList: S.Schema<UpdateServerResponseServerVolumesList>;
/** Load Balancer IDs assigned to the server. */
export type UpdateServerResponseServerLoadBalancersList = Array<number>;
export declare const UpdateServerResponseServerLoadBalancersList: S.Schema<UpdateServerResponseServerLoadBalancersList>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateServerResponseServerPlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateServerResponseServerPlacementGroupLabelsMap: S.Schema<UpdateServerResponseServerPlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type UpdateServerResponseServerPlacementGroupType = "spread";
export declare const UpdateServerResponseServerPlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type UpdateServerResponseServerPlacementGroupServersList = Array<number>;
export declare const UpdateServerResponseServerPlacementGroupServersList: S.Schema<UpdateServerResponseServerPlacementGroupServersList>;
/** The placement group the server is assigned to. */
export interface UpdateServerResponseServerPlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateServerResponseServerPlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: UpdateServerResponseServerPlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: UpdateServerResponseServerPlacementGroupServersList;
}
export declare const UpdateServerResponseServerPlacementGroup: S.Schema<UpdateServerResponseServerPlacementGroup>;
export interface UpdateServerResponseServer {
    /** ID of the [Server](#tag/servers). */
    id: number;
    /** Name of the Server (must be unique per Project and a valid hostname as per RFC 1123). */
    name: string;
    /** Status of the Server. */
    status: UpdateServerResponseServerStatus;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`. */
    public_net: UpdateServerResponseServerPublicNet;
    /** Private networks information. */
    private_net: UpdateServerResponseServerPrivateNetList;
    server_type: UpdateServerResponseServerServerType;
    /** Location this Resource is located at. */
    location: CreateServerResponseServerLocation;
    /** Image the server is based on. */
    image: UpdateServerResponseServerImage | null;
    /** ISO Image that is attached to this Server. Null if no ISO is attached. */
    iso: UpdateServerResponseServerIso | null;
    /** True if rescue mode is enabled. Server will then boot into rescue system on next reboot. */
    rescue_enabled: boolean;
    /** True if Server has been locked and is not available to user. */
    locked: boolean;
    /** Time window (UTC) in which the backup will run, or null if the backups are not enabled. */
    backup_window: string | null;
    /** Outbound Traffic for the current billing period in bytes. */
    outgoing_traffic: number | null;
    /** Inbound Traffic for the current billing period in bytes. */
    ingoing_traffic: number | null;
    /** Free Traffic for the current billing period in bytes. */
    included_traffic: number | null;
    /** Protection configuration for the Server. */
    protection: CreateServerResponseServerProtection;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateServerResponseServerLabelsMap;
    /** IDs of Volumes assigned to this Server. */
    volumes?: UpdateServerResponseServerVolumesList;
    /** Load Balancer IDs assigned to the server. */
    load_balancers?: UpdateServerResponseServerLoadBalancersList;
    /** Size of the primary Disk. */
    primary_disk_size: number;
    /** The placement group the server is assigned to. */
    placement_group?: UpdateServerResponseServerPlacementGroup | null;
}
export declare const UpdateServerResponseServer: S.Schema<UpdateServerResponseServer>;
export interface UpdateServerResponse {
    server?: UpdateServerResponseServer;
}
export declare const UpdateServerResponse: S.Schema<UpdateServerResponse>;
export type CreateServerError = ServerLimitExceeded | ServerPlacementError | HetznerOpError;
/** Create a Server Creates a new Server. Returns preliminary information about the Server as well as an Action that covers progress of creation. #### Operation specific errors */
export declare const createServer: API.OperationMethod<CreateServerRequest, CreateServerResponse, CreateServerError, HetznerOpContext>;
export type DeleteServerError = HetznerOpError;
/** Delete a Server Deletes a Server. This immediately removes the Server from your account, and it is no longer accessible. Any resources attached to the server (like Volumes, Primary IPs, Floating IPs, Firewalls, Placement Groups) are detached while the server is deleted. */
export declare const deleteServer: API.OperationMethod<DeleteServerRequest, DeleteServerResponse, DeleteServerError, HetznerOpContext>;
export type GetServerError = HetznerOpError;
/** Get a Server Returns a specific Server object. The Server must exist inside the Project. */
export declare const getServer: API.OperationMethod<GetServerRequest, GetServerResponse, GetServerError, HetznerOpContext>;
export type GetServerMetricsError = HetznerOpError;
/** Get Metrics for a Server Get Metrics for specified Server. You must specify the type of metric to get: cpu, disk or network. You can also specify more than one type by comma separation, e.g. cpu,disk. Depending on the type you will get different time series data Metrics are available for the last 30 days only. If you do not provide the step argument we will automatically adjust it so that a maximum of 200 samples are returned. We limit the number of samples returned to a maximum of 500 and will adjust the step parameter accordingly. */
export declare const getServerMetrics: API.OperationMethod<GetServerMetricsRequest, GetServerMetricsResponse, GetServerMetricsError, HetznerOpContext>;
export type ListServersError = HetznerOpError;
/** List Servers Returns all existing Server objects. */
export declare const listServers: API.PaginatedOperationMethod<ListServersRequest, ListServersResponse, ListServersError, HetznerOpContext, ListServersResponseServersItem>;
export type UpdateServerError = HetznerOpError;
/** Update a Server Updates a Server. You can update a Server’s name and a Server’s labels. Please note that Server names must be unique per Project and valid hostnames as per RFC 1123 (i.e. may only contain letters, digits, periods, and dashes). */
export declare const updateServer: API.OperationMethod<UpdateServerRequest, UpdateServerResponse, UpdateServerError, HetznerOpContext>;
//# sourceMappingURL=servers.d.ts.map