import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetPricingRequest {
}
export declare const GetPricingRequest: S.Schema<GetPricingRequest>;
/** Type of [Primary IP](#tag/primary-ips) the price is for. */
export type GetPricingResponsePricingPrimaryIpsItemType = "ipv4" | "ipv6";
export declare const GetPricingResponsePricingPrimaryIpsItemType: any;
/** Hourly price in this [Location](#tag/locations). */
export interface GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly {
    /** Price without VAT. */
    net: string;
    /** Price with VAT added. */
    gross: string;
}
export declare const GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetPricingResponsePricingPrimaryIpsItemPricesItemPriceMonthly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingPrimaryIpsItemPricesItemPriceMonthly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
export interface GetPricingResponsePricingPrimaryIpsItemPricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Hourly price in this [Location](#tag/locations). */
    price_hourly: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
}
export declare const GetPricingResponsePricingPrimaryIpsItemPricesItem: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItem>;
/** Price of the [Primary IP](#tag/primary-ips) type per [Location](#tag/locations). */
export type GetPricingResponsePricingPrimaryIpsItemPricesList = Array<GetPricingResponsePricingPrimaryIpsItemPricesItem>;
export declare const GetPricingResponsePricingPrimaryIpsItemPricesList: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesList>;
export interface GetPricingResponsePricingPrimaryIpsItem {
    /** Type of [Primary IP](#tag/primary-ips) the price is for. */
    type: GetPricingResponsePricingPrimaryIpsItemType;
    /** Price of the [Primary IP](#tag/primary-ips) type per [Location](#tag/locations). */
    prices: GetPricingResponsePricingPrimaryIpsItemPricesList;
}
export declare const GetPricingResponsePricingPrimaryIpsItem: S.Schema<GetPricingResponsePricingPrimaryIpsItem>;
/** Price of [Primary IPs](#tag/primary-ips) per type and per [Location](#tag/locations). */
export type GetPricingResponsePricingPrimaryIpsList = Array<GetPricingResponsePricingPrimaryIpsItem>;
export declare const GetPricingResponsePricingPrimaryIpsList: S.Schema<GetPricingResponsePricingPrimaryIpsList>;
/** Type of [Floating IP](#tag/floating-ips) the price is for. */
export type GetPricingResponsePricingFloatingIpsItemType = "ipv4" | "ipv6";
export declare const GetPricingResponsePricingFloatingIpsItemType: any;
/** Monthly price in this [Location](#tag/locations). */
export type GetPricingResponsePricingFloatingIpsItemPricesItemPriceMonthly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingFloatingIpsItemPricesItemPriceMonthly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
export interface GetPricingResponsePricingFloatingIpsItemPricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
}
export declare const GetPricingResponsePricingFloatingIpsItemPricesItem: S.Schema<GetPricingResponsePricingFloatingIpsItemPricesItem>;
/** Price of the [Floating IP](#tag/floating-ips) type per [Location](#tag/locations). */
export type GetPricingResponsePricingFloatingIpsItemPricesList = Array<GetPricingResponsePricingFloatingIpsItemPricesItem>;
export declare const GetPricingResponsePricingFloatingIpsItemPricesList: S.Schema<GetPricingResponsePricingFloatingIpsItemPricesList>;
export interface GetPricingResponsePricingFloatingIpsItem {
    /** Type of [Floating IP](#tag/floating-ips) the price is for. */
    type: GetPricingResponsePricingFloatingIpsItemType;
    /** Price of the [Floating IP](#tag/floating-ips) type per [Location](#tag/locations). */
    prices: GetPricingResponsePricingFloatingIpsItemPricesList;
}
export declare const GetPricingResponsePricingFloatingIpsItem: S.Schema<GetPricingResponsePricingFloatingIpsItem>;
/** Price of [Floating IPs](#tag/floating-ips) per type and per [Location](#tag/locations). */
export type GetPricingResponsePricingFloatingIpsList = Array<GetPricingResponsePricingFloatingIpsItem>;
export declare const GetPricingResponsePricingFloatingIpsList: S.Schema<GetPricingResponsePricingFloatingIpsList>;
/** Price of [Images](#tag/images) per GB/month. */
export type GetPricingResponsePricingImagePricePerGbMonth = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingImagePricePerGbMonth: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Price of [Images](#tag/images). */
export interface GetPricingResponsePricingImage {
    /** Price of [Images](#tag/images) per GB/month. */
    price_per_gb_month: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
}
export declare const GetPricingResponsePricingImage: S.Schema<GetPricingResponsePricingImage>;
/** Price of [Volumes](#tag/volumes) per GB/month. */
export type GetPricingResponsePricingVolumePricePerGbMonth = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingVolumePricePerGbMonth: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Price of [Volumes](#tag/volumes). */
export interface GetPricingResponsePricingVolume {
    /** Price of [Volumes](#tag/volumes) per GB/month. */
    price_per_gb_month: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
}
export declare const GetPricingResponsePricingVolume: S.Schema<GetPricingResponsePricingVolume>;
/** Price of [Server](#tag/servers) backups. */
export interface GetPricingResponsePricingServerBackup {
    /** Price increase of the [Server](#tag/servers) base price in percentage. */
    percentage: string;
}
export declare const GetPricingResponsePricingServerBackup: S.Schema<GetPricingResponsePricingServerBackup>;
/** Hourly price in this [Location](#tag/locations). */
export type GetPricingResponsePricingServerTypesItemPricesItemPriceHourly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingServerTypesItemPricesItemPriceHourly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetPricingResponsePricingServerTypesItemPricesItemPriceMonthly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingServerTypesItemPricesItemPriceMonthly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type GetPricingResponsePricingServerTypesItemPricesItemPricePerTbTraffic = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingServerTypesItemPricesItemPricePerTbTraffic: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
export interface GetPricingResponsePricingServerTypesItemPricesItem {
    /** Name of the [Location](#tag/locations) the price is for. */
    location: string;
    /** Hourly price in this [Location](#tag/locations). */
    price_hourly: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
    /** Monthly price in this [Location](#tag/locations). */
    price_monthly: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
    /** Free traffic per month in bytes in this [Location](#tag/locations). */
    included_traffic: number;
    /** Additional traffic price per TB in this [Location](#tag/locations). */
    price_per_tb_traffic: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
}
export declare const GetPricingResponsePricingServerTypesItemPricesItem: S.Schema<GetPricingResponsePricingServerTypesItemPricesItem>;
/** Price of the [Server Types](#tag/server-types) per [Location](#tag/locations). */
export type GetPricingResponsePricingServerTypesItemPricesList = Array<GetPricingResponsePricingServerTypesItemPricesItem>;
export declare const GetPricingResponsePricingServerTypesItemPricesList: S.Schema<GetPricingResponsePricingServerTypesItemPricesList>;
export interface GetPricingResponsePricingServerTypesItem {
    /** ID of the [Server Types](#tag/server-types) the price is for. */
    id: number;
    /** Name of the [Server Types](#tag/server-types) the price is for. */
    name: string;
    /** Price of the [Server Types](#tag/server-types) per [Location](#tag/locations). */
    prices: GetPricingResponsePricingServerTypesItemPricesList;
}
export declare const GetPricingResponsePricingServerTypesItem: S.Schema<GetPricingResponsePricingServerTypesItem>;
/** Price of Server per [type](#tag/server-types) and per [Location](#tag/locations). */
export type GetPricingResponsePricingServerTypesList = Array<GetPricingResponsePricingServerTypesItem>;
export declare const GetPricingResponsePricingServerTypesList: S.Schema<GetPricingResponsePricingServerTypesList>;
/** Hourly price in this [Location](#tag/locations). */
export type GetPricingResponsePricingLoadBalancerTypesItemPricesItemPriceHourly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingLoadBalancerTypesItemPricesItemPriceHourly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Monthly price in this [Location](#tag/locations). */
export type GetPricingResponsePricingLoadBalancerTypesItemPricesItemPriceMonthly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingLoadBalancerTypesItemPricesItemPriceMonthly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Additional traffic price per TB in this [Location](#tag/locations). */
export type GetPricingResponsePricingLoadBalancerTypesItemPricesItemPricePerTbTraffic = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingLoadBalancerTypesItemPricesItemPricePerTbTraffic: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
export type GetPricingResponsePricingLoadBalancerTypesItemPricesItem = GetPricingResponsePricingServerTypesItemPricesItem;
export declare const GetPricingResponsePricingLoadBalancerTypesItemPricesItem: S.Schema<GetPricingResponsePricingServerTypesItemPricesItem>;
/** Price of the [Load Balancer Types](#tag/load-balancer-types) per [Location](#tag/locations). */
export type GetPricingResponsePricingLoadBalancerTypesItemPricesList = Array<GetPricingResponsePricingServerTypesItemPricesItem>;
export declare const GetPricingResponsePricingLoadBalancerTypesItemPricesList: S.Schema<GetPricingResponsePricingLoadBalancerTypesItemPricesList>;
export interface GetPricingResponsePricingLoadBalancerTypesItem {
    /** ID of the [Load Balancer Types](#tag/load-balancer-types) the price is for. */
    id: number;
    /** Name of the [Load Balancer Types](#tag/load-balancer-types) the price is for. */
    name: string;
    /** Price of the [Load Balancer Types](#tag/load-balancer-types) per [Location](#tag/locations). */
    prices: GetPricingResponsePricingLoadBalancerTypesItemPricesList;
}
export declare const GetPricingResponsePricingLoadBalancerTypesItem: S.Schema<GetPricingResponsePricingLoadBalancerTypesItem>;
/** Price of Load Balancer per [type](#tag/load-balancer-types) and per [Location](#tag/locations). */
export type GetPricingResponsePricingLoadBalancerTypesList = Array<GetPricingResponsePricingLoadBalancerTypesItem>;
export declare const GetPricingResponsePricingLoadBalancerTypesList: S.Schema<GetPricingResponsePricingLoadBalancerTypesList>;
/** Price of one [Floating IP](#tag/floating-ips) per month. */
export type GetPricingResponsePricingFloatingIpPriceMonthly = GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
export declare const GetPricingResponsePricingFloatingIpPriceMonthly: S.Schema<GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly>;
/** Price of [Floating IPs](#tag/floating-ips). **Deprecated**: This field is deprecated, please refer to the `floating_ips` field instead. See the [Changelog](https://docs.hetzner.cloud/changelog#2024-08-29-field-floating_ip-in-pricing-response-is-now-deprecated) for more details. */
export interface GetPricingResponsePricingFloatingIp {
    /** Price of one [Floating IP](#tag/floating-ips) per month. */
    price_monthly: GetPricingResponsePricingPrimaryIpsItemPricesItemPriceHourly;
}
export declare const GetPricingResponsePricingFloatingIp: S.Schema<GetPricingResponsePricingFloatingIp>;
export interface GetPricingResponsePricing {
    /** Currency the returned prices are expressed in, coded according to [ISO 4217](https://wikipedia.org/wiki/ISO_4217). */
    currency: string;
    /** VAT rate used for calculating prices with VAT. */
    vat_rate: string;
    /** Price of [Primary IPs](#tag/primary-ips) per type and per [Location](#tag/locations). */
    primary_ips: GetPricingResponsePricingPrimaryIpsList;
    /** Price of [Floating IPs](#tag/floating-ips) per type and per [Location](#tag/locations). */
    floating_ips: GetPricingResponsePricingFloatingIpsList;
    /** Price of [Images](#tag/images). */
    image: GetPricingResponsePricingImage;
    /** Price of [Volumes](#tag/volumes). */
    volume: GetPricingResponsePricingVolume;
    /** Price of [Server](#tag/servers) backups. */
    server_backup: GetPricingResponsePricingServerBackup;
    /** Price of Server per [type](#tag/server-types) and per [Location](#tag/locations). */
    server_types: GetPricingResponsePricingServerTypesList;
    /** Price of Load Balancer per [type](#tag/load-balancer-types) and per [Location](#tag/locations). */
    load_balancer_types: GetPricingResponsePricingLoadBalancerTypesList;
    /** Price of [Floating IPs](#tag/floating-ips). **Deprecated**: This field is deprecated, please refer to the `floating_ips` field instead. See the [Changelog](https://docs.hetzner.cloud/changelog#2024-08-29-field-floating_ip-in-pricing-response-is-now-deprecated) for more details. */
    floating_ip: GetPricingResponsePricingFloatingIp;
}
export declare const GetPricingResponsePricing: S.Schema<GetPricingResponsePricing>;
export interface GetPricingResponse {
    pricing: GetPricingResponsePricing;
}
export declare const GetPricingResponse: S.Schema<GetPricingResponse>;
export type GetPricingError = HetznerOpError;
/** Get all prices Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations. Both net and gross prices are included in the response. */
export declare const getPricing: API.OperationMethod<GetPricingRequest, GetPricingResponse, GetPricingError, HetznerOpContext>;
//# sourceMappingURL=pricing.d.ts.map