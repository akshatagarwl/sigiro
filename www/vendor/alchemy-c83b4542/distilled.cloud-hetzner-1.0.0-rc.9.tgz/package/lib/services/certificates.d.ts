import * as S from "@distilled.cloud/core/schema";
import * as Redacted from "effect/Redacted";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateCertificateRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateCertificateRequestLabelsMap: S.Schema<CreateCertificateRequestLabelsMap>;
/** Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. */
export type CreateCertificateRequestType = "uploaded" | "managed";
export declare const CreateCertificateRequestType: any;
/** Domains and subdomains that should be contained in the Certificate issued by *Let's Encrypt*. Required for type `managed` Certificates. */
export type CreateCertificateRequestDomainNamesList = Array<string>;
export declare const CreateCertificateRequestDomainNamesList: S.Schema<CreateCertificateRequestDomainNamesList>;
export interface CreateCertificateRequest {
    /** Name of the Certificate. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateCertificateRequestLabelsMap;
    /** Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. */
    type?: CreateCertificateRequestType | (string & {});
    /** Certificate and chain in PEM format, in order so that each record directly certifies the one preceding. Required for type `uploaded` Certificates. */
    certificate?: string;
    /** Certificate key in PEM format. Required for type `uploaded` Certificates. */
    private_key?: string | Redacted.Redacted<string>;
    /** Domains and subdomains that should be contained in the Certificate issued by *Let's Encrypt*. Required for type `managed` Certificates. */
    domain_names?: CreateCertificateRequestDomainNamesList;
}
export declare const CreateCertificateRequest: S.Schema<CreateCertificateRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateCertificateResponseCertificateLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateCertificateResponseCertificateLabelsMap: S.Schema<CreateCertificateResponseCertificateLabelsMap>;
/** Type of the Certificate. */
export type CreateCertificateResponseCertificateType = "uploaded" | "managed";
export declare const CreateCertificateResponseCertificateType: any;
/** Domains and subdomains covered by the Certificate. */
export type CreateCertificateResponseCertificateDomainNamesList = Array<string>;
export declare const CreateCertificateResponseCertificateDomainNamesList: S.Schema<CreateCertificateResponseCertificateDomainNamesList>;
/** Status of the issuance process of the Certificate. */
export type CreateCertificateResponseCertificateStatusIssuance = "pending" | "completed" | "failed";
export declare const CreateCertificateResponseCertificateStatusIssuance: any;
/** Status of the renewal process of the Certificate. */
export type CreateCertificateResponseCertificateStatusRenewal = "scheduled" | "pending" | "failed" | "unavailable";
export declare const CreateCertificateResponseCertificateStatusRenewal: any;
/** If issuance or renewal reports `failed`, this property contains information about what happened. */
export interface CreateCertificateResponseCertificateStatusError {
    code?: string;
    message?: string;
}
export declare const CreateCertificateResponseCertificateStatusError: S.Schema<CreateCertificateResponseCertificateStatusError>;
/** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
export interface CreateCertificateResponseCertificateStatus {
    /** Status of the issuance process of the Certificate. */
    issuance?: CreateCertificateResponseCertificateStatusIssuance;
    /** Status of the renewal process of the Certificate. */
    renewal?: CreateCertificateResponseCertificateStatusRenewal;
    /** If issuance or renewal reports `failed`, this property contains information about what happened. */
    error?: CreateCertificateResponseCertificateStatusError | null;
}
export declare const CreateCertificateResponseCertificateStatus: S.Schema<CreateCertificateResponseCertificateStatus>;
export interface CreateCertificateResponseCertificateUsedByItem {
    /** ID of resource referenced. */
    id: number;
    /** Type of resource referenced. */
    type: string;
}
export declare const CreateCertificateResponseCertificateUsedByItem: S.Schema<CreateCertificateResponseCertificateUsedByItem>;
/** Resources currently using the Certificate. */
export type CreateCertificateResponseCertificateUsedByList = Array<CreateCertificateResponseCertificateUsedByItem>;
export declare const CreateCertificateResponseCertificateUsedByList: S.Schema<CreateCertificateResponseCertificateUsedByList>;
export interface CreateCertificateResponseCertificate {
    /** ID of the [Certificate](#tag/certificates). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreateCertificateResponseCertificateLabelsMap;
    /** Type of the Certificate. */
    type?: CreateCertificateResponseCertificateType;
    /** Certificate and chain in PEM format, in order so that each record directly certifies the one preceding. */
    certificate: string | null;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Point in time when the Certificate becomes valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_before: string | null;
    /** Point in time when the Certificate stops being valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_after: string | null;
    /** Domains and subdomains covered by the Certificate. */
    domain_names: CreateCertificateResponseCertificateDomainNamesList;
    /** SHA256 fingerprint of the Certificate. */
    fingerprint: string | null;
    /** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
    status?: CreateCertificateResponseCertificateStatus | null;
    /** Resources currently using the Certificate. */
    used_by: CreateCertificateResponseCertificateUsedByList;
}
export declare const CreateCertificateResponseCertificate: S.Schema<CreateCertificateResponseCertificate>;
/** Status of the Action. */
export type CreateCertificateResponseActionStatus = "running" | "success" | "error";
export declare const CreateCertificateResponseActionStatus: any;
export interface CreateCertificateResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateCertificateResponseActionResourcesItem: S.Schema<CreateCertificateResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreateCertificateResponseActionResourcesList = Array<CreateCertificateResponseActionResourcesItem>;
export declare const CreateCertificateResponseActionResourcesList: S.Schema<CreateCertificateResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateCertificateResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateCertificateResponseActionError: S.Schema<CreateCertificateResponseActionError>;
export interface CreateCertificateResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateCertificateResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateCertificateResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateCertificateResponseActionError | null;
}
export declare const CreateCertificateResponseAction: S.Schema<CreateCertificateResponseAction>;
export interface CreateCertificateResponse {
    certificate: CreateCertificateResponseCertificate;
    action?: CreateCertificateResponseAction | null;
}
export declare const CreateCertificateResponse: S.Schema<CreateCertificateResponse>;
export interface DeleteCertificateRequest {
    /** ID of the Certificate. */
    id: number;
}
export declare const DeleteCertificateRequest: S.Schema<DeleteCertificateRequest>;
export interface DeleteCertificateResponse {
}
export declare const DeleteCertificateResponse: S.Schema<DeleteCertificateResponse>;
export interface GetCertificateRequest {
    /** ID of the Certificate. */
    id: number;
}
export declare const GetCertificateRequest: S.Schema<GetCertificateRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetCertificateResponseCertificateLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetCertificateResponseCertificateLabelsMap: S.Schema<GetCertificateResponseCertificateLabelsMap>;
/** Type of the Certificate. */
export type GetCertificateResponseCertificateType = "uploaded" | "managed";
export declare const GetCertificateResponseCertificateType: any;
/** Domains and subdomains covered by the Certificate. */
export type GetCertificateResponseCertificateDomainNamesList = Array<string>;
export declare const GetCertificateResponseCertificateDomainNamesList: S.Schema<GetCertificateResponseCertificateDomainNamesList>;
/** Status of the issuance process of the Certificate. */
export type GetCertificateResponseCertificateStatusIssuance = "pending" | "completed" | "failed";
export declare const GetCertificateResponseCertificateStatusIssuance: any;
/** Status of the renewal process of the Certificate. */
export type GetCertificateResponseCertificateStatusRenewal = "scheduled" | "pending" | "failed" | "unavailable";
export declare const GetCertificateResponseCertificateStatusRenewal: any;
/** If issuance or renewal reports `failed`, this property contains information about what happened. */
export type GetCertificateResponseCertificateStatusError = CreateCertificateResponseCertificateStatusError;
export declare const GetCertificateResponseCertificateStatusError: S.Schema<CreateCertificateResponseCertificateStatusError>;
/** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
export interface GetCertificateResponseCertificateStatus {
    /** Status of the issuance process of the Certificate. */
    issuance?: GetCertificateResponseCertificateStatusIssuance;
    /** Status of the renewal process of the Certificate. */
    renewal?: GetCertificateResponseCertificateStatusRenewal;
    /** If issuance or renewal reports `failed`, this property contains information about what happened. */
    error?: CreateCertificateResponseCertificateStatusError | null;
}
export declare const GetCertificateResponseCertificateStatus: S.Schema<GetCertificateResponseCertificateStatus>;
export type GetCertificateResponseCertificateUsedByItem = CreateCertificateResponseCertificateUsedByItem;
export declare const GetCertificateResponseCertificateUsedByItem: S.Schema<CreateCertificateResponseCertificateUsedByItem>;
/** Resources currently using the Certificate. */
export type GetCertificateResponseCertificateUsedByList = Array<CreateCertificateResponseCertificateUsedByItem>;
export declare const GetCertificateResponseCertificateUsedByList: S.Schema<GetCertificateResponseCertificateUsedByList>;
export interface GetCertificateResponseCertificate {
    /** ID of the [Certificate](#tag/certificates). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetCertificateResponseCertificateLabelsMap;
    /** Type of the Certificate. */
    type?: GetCertificateResponseCertificateType;
    /** Certificate and chain in PEM format, in order so that each record directly certifies the one preceding. */
    certificate: string | null;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Point in time when the Certificate becomes valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_before: string | null;
    /** Point in time when the Certificate stops being valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_after: string | null;
    /** Domains and subdomains covered by the Certificate. */
    domain_names: GetCertificateResponseCertificateDomainNamesList;
    /** SHA256 fingerprint of the Certificate. */
    fingerprint: string | null;
    /** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
    status?: GetCertificateResponseCertificateStatus | null;
    /** Resources currently using the Certificate. */
    used_by: GetCertificateResponseCertificateUsedByList;
}
export declare const GetCertificateResponseCertificate: S.Schema<GetCertificateResponseCertificate>;
export interface GetCertificateResponse {
    certificate: GetCertificateResponseCertificate;
}
export declare const GetCertificateResponse: S.Schema<GetCertificateResponse>;
export type ListCertificatesRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListCertificatesRequestSortItem: any;
export type ListCertificatesRequestSortList = Array<ListCertificatesRequestSortItem | (string & {})>;
export declare const ListCertificatesRequestSortList: S.Schema<ListCertificatesRequestSortList>;
/** Type of the Certificate. */
export type ListCertificatesRequestTypeItem = "uploaded" | "managed";
export declare const ListCertificatesRequestTypeItem: any;
export type ListCertificatesRequestTypeList = Array<ListCertificatesRequestTypeItem | (string & {})>;
export declare const ListCertificatesRequestTypeList: S.Schema<ListCertificatesRequestTypeList>;
export interface ListCertificatesRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListCertificatesRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Filter resources by type. May be used multiple times. The response will only contain the resources with the specified type. */
    type?: ListCertificatesRequestTypeList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListCertificatesRequest: S.Schema<ListCertificatesRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListCertificatesResponseCertificatesItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListCertificatesResponseCertificatesItemLabelsMap: S.Schema<ListCertificatesResponseCertificatesItemLabelsMap>;
/** Type of the Certificate. */
export type ListCertificatesResponseCertificatesItemType = "uploaded" | "managed";
export declare const ListCertificatesResponseCertificatesItemType: any;
/** Domains and subdomains covered by the Certificate. */
export type ListCertificatesResponseCertificatesItemDomainNamesList = Array<string>;
export declare const ListCertificatesResponseCertificatesItemDomainNamesList: S.Schema<ListCertificatesResponseCertificatesItemDomainNamesList>;
/** Status of the issuance process of the Certificate. */
export type ListCertificatesResponseCertificatesItemStatusIssuance = "pending" | "completed" | "failed";
export declare const ListCertificatesResponseCertificatesItemStatusIssuance: any;
/** Status of the renewal process of the Certificate. */
export type ListCertificatesResponseCertificatesItemStatusRenewal = "scheduled" | "pending" | "failed" | "unavailable";
export declare const ListCertificatesResponseCertificatesItemStatusRenewal: any;
/** If issuance or renewal reports `failed`, this property contains information about what happened. */
export type ListCertificatesResponseCertificatesItemStatusError = CreateCertificateResponseCertificateStatusError;
export declare const ListCertificatesResponseCertificatesItemStatusError: S.Schema<CreateCertificateResponseCertificateStatusError>;
/** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
export interface ListCertificatesResponseCertificatesItemStatus {
    /** Status of the issuance process of the Certificate. */
    issuance?: ListCertificatesResponseCertificatesItemStatusIssuance;
    /** Status of the renewal process of the Certificate. */
    renewal?: ListCertificatesResponseCertificatesItemStatusRenewal;
    /** If issuance or renewal reports `failed`, this property contains information about what happened. */
    error?: CreateCertificateResponseCertificateStatusError | null;
}
export declare const ListCertificatesResponseCertificatesItemStatus: S.Schema<ListCertificatesResponseCertificatesItemStatus>;
export type ListCertificatesResponseCertificatesItemUsedByItem = CreateCertificateResponseCertificateUsedByItem;
export declare const ListCertificatesResponseCertificatesItemUsedByItem: S.Schema<CreateCertificateResponseCertificateUsedByItem>;
/** Resources currently using the Certificate. */
export type ListCertificatesResponseCertificatesItemUsedByList = Array<CreateCertificateResponseCertificateUsedByItem>;
export declare const ListCertificatesResponseCertificatesItemUsedByList: S.Schema<ListCertificatesResponseCertificatesItemUsedByList>;
export interface ListCertificatesResponseCertificatesItem {
    /** ID of the [Certificate](#tag/certificates). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListCertificatesResponseCertificatesItemLabelsMap;
    /** Type of the Certificate. */
    type?: ListCertificatesResponseCertificatesItemType;
    /** Certificate and chain in PEM format, in order so that each record directly certifies the one preceding. */
    certificate: string | null;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Point in time when the Certificate becomes valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_before: string | null;
    /** Point in time when the Certificate stops being valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_after: string | null;
    /** Domains and subdomains covered by the Certificate. */
    domain_names: ListCertificatesResponseCertificatesItemDomainNamesList;
    /** SHA256 fingerprint of the Certificate. */
    fingerprint: string | null;
    /** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
    status?: ListCertificatesResponseCertificatesItemStatus | null;
    /** Resources currently using the Certificate. */
    used_by: ListCertificatesResponseCertificatesItemUsedByList;
}
export declare const ListCertificatesResponseCertificatesItem: S.Schema<ListCertificatesResponseCertificatesItem>;
export type ListCertificatesResponseCertificatesList = Array<ListCertificatesResponseCertificatesItem>;
export declare const ListCertificatesResponseCertificatesList: S.Schema<ListCertificatesResponseCertificatesList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListCertificatesResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListCertificatesResponseMetaPagination: S.Schema<ListCertificatesResponseMetaPagination>;
export interface ListCertificatesResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListCertificatesResponseMetaPagination;
}
export declare const ListCertificatesResponseMeta: S.Schema<ListCertificatesResponseMeta>;
export interface ListCertificatesResponse {
    certificates: ListCertificatesResponseCertificatesList;
    meta: ListCertificatesResponseMeta;
}
export declare const ListCertificatesResponse: S.Schema<ListCertificatesResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateCertificateRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateCertificateRequestLabelsMap: S.Schema<UpdateCertificateRequestLabelsMap>;
export interface UpdateCertificateRequest {
    /** ID of the Certificate. */
    id: number;
    /** New Certificate name. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateCertificateRequestLabelsMap;
}
export declare const UpdateCertificateRequest: S.Schema<UpdateCertificateRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateCertificateResponseCertificateLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateCertificateResponseCertificateLabelsMap: S.Schema<UpdateCertificateResponseCertificateLabelsMap>;
/** Type of the Certificate. */
export type UpdateCertificateResponseCertificateType = "uploaded" | "managed";
export declare const UpdateCertificateResponseCertificateType: any;
/** Domains and subdomains covered by the Certificate. */
export type UpdateCertificateResponseCertificateDomainNamesList = Array<string>;
export declare const UpdateCertificateResponseCertificateDomainNamesList: S.Schema<UpdateCertificateResponseCertificateDomainNamesList>;
/** Status of the issuance process of the Certificate. */
export type UpdateCertificateResponseCertificateStatusIssuance = "pending" | "completed" | "failed";
export declare const UpdateCertificateResponseCertificateStatusIssuance: any;
/** Status of the renewal process of the Certificate. */
export type UpdateCertificateResponseCertificateStatusRenewal = "scheduled" | "pending" | "failed" | "unavailable";
export declare const UpdateCertificateResponseCertificateStatusRenewal: any;
/** If issuance or renewal reports `failed`, this property contains information about what happened. */
export type UpdateCertificateResponseCertificateStatusError = CreateCertificateResponseCertificateStatusError;
export declare const UpdateCertificateResponseCertificateStatusError: S.Schema<CreateCertificateResponseCertificateStatusError>;
/** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
export interface UpdateCertificateResponseCertificateStatus {
    /** Status of the issuance process of the Certificate. */
    issuance?: UpdateCertificateResponseCertificateStatusIssuance;
    /** Status of the renewal process of the Certificate. */
    renewal?: UpdateCertificateResponseCertificateStatusRenewal;
    /** If issuance or renewal reports `failed`, this property contains information about what happened. */
    error?: CreateCertificateResponseCertificateStatusError | null;
}
export declare const UpdateCertificateResponseCertificateStatus: S.Schema<UpdateCertificateResponseCertificateStatus>;
export type UpdateCertificateResponseCertificateUsedByItem = CreateCertificateResponseCertificateUsedByItem;
export declare const UpdateCertificateResponseCertificateUsedByItem: S.Schema<CreateCertificateResponseCertificateUsedByItem>;
/** Resources currently using the Certificate. */
export type UpdateCertificateResponseCertificateUsedByList = Array<CreateCertificateResponseCertificateUsedByItem>;
export declare const UpdateCertificateResponseCertificateUsedByList: S.Schema<UpdateCertificateResponseCertificateUsedByList>;
export interface UpdateCertificateResponseCertificate {
    /** ID of the [Certificate](#tag/certificates). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdateCertificateResponseCertificateLabelsMap;
    /** Type of the Certificate. */
    type?: UpdateCertificateResponseCertificateType;
    /** Certificate and chain in PEM format, in order so that each record directly certifies the one preceding. */
    certificate: string | null;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Point in time when the Certificate becomes valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_before: string | null;
    /** Point in time when the Certificate stops being valid (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    not_valid_after: string | null;
    /** Domains and subdomains covered by the Certificate. */
    domain_names: UpdateCertificateResponseCertificateDomainNamesList;
    /** SHA256 fingerprint of the Certificate. */
    fingerprint: string | null;
    /** Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates. */
    status?: UpdateCertificateResponseCertificateStatus | null;
    /** Resources currently using the Certificate. */
    used_by: UpdateCertificateResponseCertificateUsedByList;
}
export declare const UpdateCertificateResponseCertificate: S.Schema<UpdateCertificateResponseCertificate>;
export interface UpdateCertificateResponse {
    certificate: UpdateCertificateResponseCertificate;
}
export declare const UpdateCertificateResponse: S.Schema<UpdateCertificateResponse>;
export type CreateCertificateError = HetznerOpError;
/** Create a Certificate Creates a new Certificate. The default type **uploaded** allows for uploading your existing `certificate` and `private_key` in PEM format. You have to monitor its expiration date and handle renewal yourself. In contrast, type **managed** requests a new Certificate from *Let's Encrypt* for the specified `domain_names`. Only domains managed by *Hetzner DNS* are supported. We handle renewal and timely alert the project owner via email if problems occur. For type `managed` Certificates the `action` key of the response contains the Action that allows for tracking the issuance process. For type `uploaded` Certificates the `action` is always null. */
export declare const createCertificate: API.OperationMethod<CreateCertificateRequest, CreateCertificateResponse, CreateCertificateError, HetznerOpContext>;
export type DeleteCertificateError = HetznerOpError;
/** Delete a Certificate Deletes a Certificate. */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateRequest, DeleteCertificateResponse, DeleteCertificateError, HetznerOpContext>;
export type GetCertificateError = HetznerOpError;
/** Get a Certificate Gets a specific Certificate object. */
export declare const getCertificate: API.OperationMethod<GetCertificateRequest, GetCertificateResponse, GetCertificateError, HetznerOpContext>;
export type ListCertificatesError = HetznerOpError;
/** List Certificates Returns all Certificate objects. */
export declare const listCertificates: API.PaginatedOperationMethod<ListCertificatesRequest, ListCertificatesResponse, ListCertificatesError, HetznerOpContext, ListCertificatesResponseCertificatesItem>;
export type UpdateCertificateError = HetznerOpError;
/** Update a Certificate Updates the Certificate properties. Note: if the Certificate object changes during the request, the response will be a “conflict” error. */
export declare const updateCertificate: API.OperationMethod<UpdateCertificateRequest, UpdateCertificateResponse, UpdateCertificateError, HetznerOpContext>;
//# sourceMappingURL=certificates.d.ts.map