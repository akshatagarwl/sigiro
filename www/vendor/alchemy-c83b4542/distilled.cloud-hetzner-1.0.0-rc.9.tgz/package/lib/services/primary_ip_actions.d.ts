import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Type of resource assigning the Primary IP to. */
export type AssignPrimaryIpRequestAssigneeType = "server";
export declare const AssignPrimaryIpRequestAssigneeType: any;
export interface AssignPrimaryIpRequest {
    /** ID of the Primary IP. */
    id: number;
    /** Type of resource assigning the Primary IP to. */
    assignee_type: AssignPrimaryIpRequestAssigneeType | (string & {});
    /** ID of a resource of type `assignee_type`. */
    assignee_id: number;
}
export declare const AssignPrimaryIpRequest: S.Schema<AssignPrimaryIpRequest>;
/** Status of the Action. */
export type AssignPrimaryIpResponseActionStatus = "running" | "success" | "error";
export declare const AssignPrimaryIpResponseActionStatus: any;
export interface AssignPrimaryIpResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AssignPrimaryIpResponseActionResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AssignPrimaryIpResponseActionResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const AssignPrimaryIpResponseActionResourcesList: S.Schema<AssignPrimaryIpResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AssignPrimaryIpResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AssignPrimaryIpResponseActionError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface AssignPrimaryIpResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AssignPrimaryIpResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AssignPrimaryIpResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const AssignPrimaryIpResponseAction: S.Schema<AssignPrimaryIpResponseAction>;
export interface AssignPrimaryIpResponse {
    action: AssignPrimaryIpResponseAction;
}
export declare const AssignPrimaryIpResponse: S.Schema<AssignPrimaryIpResponse>;
export interface ChangePrimaryIpDnsPtrRequest {
    /** ID of the Primary IP. */
    id: number;
    /** Single IPv4 or IPv6 address to create pointer for. */
    ip: string;
    /** Domain Name to point to. PTR record content used for reverse DNS. Set to null to reset (IPv4) to the default value or remove (IPv6) the record. */
    dns_ptr?: string | null;
}
export declare const ChangePrimaryIpDnsPtrRequest: S.Schema<ChangePrimaryIpDnsPtrRequest>;
/** Status of the Action. */
export type ChangePrimaryIpDnsPtrResponseActionStatus = "running" | "success" | "error";
export declare const ChangePrimaryIpDnsPtrResponseActionStatus: any;
export type ChangePrimaryIpDnsPtrResponseActionResourcesItem = AssignPrimaryIpResponseActionResourcesItem;
export declare const ChangePrimaryIpDnsPtrResponseActionResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangePrimaryIpDnsPtrResponseActionResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const ChangePrimaryIpDnsPtrResponseActionResourcesList: S.Schema<ChangePrimaryIpDnsPtrResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangePrimaryIpDnsPtrResponseActionError = AssignPrimaryIpResponseActionError;
export declare const ChangePrimaryIpDnsPtrResponseActionError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface ChangePrimaryIpDnsPtrResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangePrimaryIpDnsPtrResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangePrimaryIpDnsPtrResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const ChangePrimaryIpDnsPtrResponseAction: S.Schema<ChangePrimaryIpDnsPtrResponseAction>;
export interface ChangePrimaryIpDnsPtrResponse {
    action: ChangePrimaryIpDnsPtrResponseAction;
}
export declare const ChangePrimaryIpDnsPtrResponse: S.Schema<ChangePrimaryIpDnsPtrResponse>;
export interface ChangePrimaryIpProtectionRequest {
    /** ID of the Primary IP. */
    id: number;
    /** Prevent the Resource from being deleted. */
    delete: boolean;
}
export declare const ChangePrimaryIpProtectionRequest: S.Schema<ChangePrimaryIpProtectionRequest>;
/** Status of the Action. */
export type ChangePrimaryIpProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangePrimaryIpProtectionResponseActionStatus: any;
export type ChangePrimaryIpProtectionResponseActionResourcesItem = AssignPrimaryIpResponseActionResourcesItem;
export declare const ChangePrimaryIpProtectionResponseActionResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangePrimaryIpProtectionResponseActionResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const ChangePrimaryIpProtectionResponseActionResourcesList: S.Schema<ChangePrimaryIpProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangePrimaryIpProtectionResponseActionError = AssignPrimaryIpResponseActionError;
export declare const ChangePrimaryIpProtectionResponseActionError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface ChangePrimaryIpProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangePrimaryIpProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangePrimaryIpProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const ChangePrimaryIpProtectionResponseAction: S.Schema<ChangePrimaryIpProtectionResponseAction>;
export interface ChangePrimaryIpProtectionResponse {
    action: ChangePrimaryIpProtectionResponseAction;
}
export declare const ChangePrimaryIpProtectionResponse: S.Schema<ChangePrimaryIpProtectionResponse>;
export interface GetPrimaryIpsActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetPrimaryIpsActionRequest: S.Schema<GetPrimaryIpsActionRequest>;
/** Status of the Action. */
export type GetPrimaryIpsActionResponseActionStatus = "running" | "success" | "error";
export declare const GetPrimaryIpsActionResponseActionStatus: any;
export type GetPrimaryIpsActionResponseActionResourcesItem = AssignPrimaryIpResponseActionResourcesItem;
export declare const GetPrimaryIpsActionResponseActionResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetPrimaryIpsActionResponseActionResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const GetPrimaryIpsActionResponseActionResourcesList: S.Schema<GetPrimaryIpsActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetPrimaryIpsActionResponseActionError = AssignPrimaryIpResponseActionError;
export declare const GetPrimaryIpsActionResponseActionError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface GetPrimaryIpsActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetPrimaryIpsActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetPrimaryIpsActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const GetPrimaryIpsActionResponseAction: S.Schema<GetPrimaryIpsActionResponseAction>;
export interface GetPrimaryIpsActionResponse {
    action: GetPrimaryIpsActionResponseAction;
}
export declare const GetPrimaryIpsActionResponse: S.Schema<GetPrimaryIpsActionResponse>;
export type ListPrimaryIpActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListPrimaryIpActionsRequestSortItem: any;
export type ListPrimaryIpActionsRequestSortList = Array<ListPrimaryIpActionsRequestSortItem | (string & {})>;
export declare const ListPrimaryIpActionsRequestSortList: S.Schema<ListPrimaryIpActionsRequestSortList>;
/** Status of the Action. */
export type ListPrimaryIpActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListPrimaryIpActionsRequestStatusItem: any;
export type ListPrimaryIpActionsRequestStatusList = Array<ListPrimaryIpActionsRequestStatusItem | (string & {})>;
export declare const ListPrimaryIpActionsRequestStatusList: S.Schema<ListPrimaryIpActionsRequestStatusList>;
export interface ListPrimaryIpActionsRequest {
    /** ID of the Primary IP. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListPrimaryIpActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListPrimaryIpActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListPrimaryIpActionsRequest: S.Schema<ListPrimaryIpActionsRequest>;
/** Status of the Action. */
export type ListPrimaryIpActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListPrimaryIpActionsResponseActionsItemStatus: any;
export type ListPrimaryIpActionsResponseActionsItemResourcesItem = AssignPrimaryIpResponseActionResourcesItem;
export declare const ListPrimaryIpActionsResponseActionsItemResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListPrimaryIpActionsResponseActionsItemResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const ListPrimaryIpActionsResponseActionsItemResourcesList: S.Schema<ListPrimaryIpActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListPrimaryIpActionsResponseActionsItemError = AssignPrimaryIpResponseActionError;
export declare const ListPrimaryIpActionsResponseActionsItemError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface ListPrimaryIpActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListPrimaryIpActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListPrimaryIpActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const ListPrimaryIpActionsResponseActionsItem: S.Schema<ListPrimaryIpActionsResponseActionsItem>;
export type ListPrimaryIpActionsResponseActionsList = Array<ListPrimaryIpActionsResponseActionsItem>;
export declare const ListPrimaryIpActionsResponseActionsList: S.Schema<ListPrimaryIpActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListPrimaryIpActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListPrimaryIpActionsResponseMetaPagination: S.Schema<ListPrimaryIpActionsResponseMetaPagination>;
export interface ListPrimaryIpActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListPrimaryIpActionsResponseMetaPagination;
}
export declare const ListPrimaryIpActionsResponseMeta: S.Schema<ListPrimaryIpActionsResponseMeta>;
export interface ListPrimaryIpActionsResponse {
    actions: ListPrimaryIpActionsResponseActionsList;
    meta: ListPrimaryIpActionsResponseMeta;
}
export declare const ListPrimaryIpActionsResponse: S.Schema<ListPrimaryIpActionsResponse>;
export type ListPrimaryIpsActionsRequestIdList = Array<number>;
export declare const ListPrimaryIpsActionsRequestIdList: S.Schema<ListPrimaryIpsActionsRequestIdList>;
export type ListPrimaryIpsActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListPrimaryIpsActionsRequestSortItem: any;
export type ListPrimaryIpsActionsRequestSortList = Array<ListPrimaryIpsActionsRequestSortItem | (string & {})>;
export declare const ListPrimaryIpsActionsRequestSortList: S.Schema<ListPrimaryIpsActionsRequestSortList>;
/** Status of the Action. */
export type ListPrimaryIpsActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListPrimaryIpsActionsRequestStatusItem: any;
export type ListPrimaryIpsActionsRequestStatusList = Array<ListPrimaryIpsActionsRequestStatusItem | (string & {})>;
export declare const ListPrimaryIpsActionsRequestStatusList: S.Schema<ListPrimaryIpsActionsRequestStatusList>;
export interface ListPrimaryIpsActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListPrimaryIpsActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListPrimaryIpsActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListPrimaryIpsActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListPrimaryIpsActionsRequest: S.Schema<ListPrimaryIpsActionsRequest>;
/** Status of the Action. */
export type ListPrimaryIpsActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListPrimaryIpsActionsResponseActionsItemStatus: any;
export type ListPrimaryIpsActionsResponseActionsItemResourcesItem = AssignPrimaryIpResponseActionResourcesItem;
export declare const ListPrimaryIpsActionsResponseActionsItemResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListPrimaryIpsActionsResponseActionsItemResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const ListPrimaryIpsActionsResponseActionsItemResourcesList: S.Schema<ListPrimaryIpsActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListPrimaryIpsActionsResponseActionsItemError = AssignPrimaryIpResponseActionError;
export declare const ListPrimaryIpsActionsResponseActionsItemError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface ListPrimaryIpsActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListPrimaryIpsActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListPrimaryIpsActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const ListPrimaryIpsActionsResponseActionsItem: S.Schema<ListPrimaryIpsActionsResponseActionsItem>;
export type ListPrimaryIpsActionsResponseActionsList = Array<ListPrimaryIpsActionsResponseActionsItem>;
export declare const ListPrimaryIpsActionsResponseActionsList: S.Schema<ListPrimaryIpsActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListPrimaryIpsActionsResponseMetaPagination = ListPrimaryIpActionsResponseMetaPagination;
export declare const ListPrimaryIpsActionsResponseMetaPagination: S.Schema<ListPrimaryIpActionsResponseMetaPagination>;
export type ListPrimaryIpsActionsResponseMeta = ListPrimaryIpActionsResponseMeta;
export declare const ListPrimaryIpsActionsResponseMeta: S.Schema<ListPrimaryIpActionsResponseMeta>;
export interface ListPrimaryIpsActionsResponse {
    actions: ListPrimaryIpsActionsResponseActionsList;
    meta: ListPrimaryIpActionsResponseMeta;
}
export declare const ListPrimaryIpsActionsResponse: S.Schema<ListPrimaryIpsActionsResponse>;
export interface UnassignPrimaryIpRequest {
    /** ID of the Primary IP. */
    id: number;
}
export declare const UnassignPrimaryIpRequest: S.Schema<UnassignPrimaryIpRequest>;
/** Status of the Action. */
export type UnassignPrimaryIpResponseActionStatus = "running" | "success" | "error";
export declare const UnassignPrimaryIpResponseActionStatus: any;
export type UnassignPrimaryIpResponseActionResourcesItem = AssignPrimaryIpResponseActionResourcesItem;
export declare const UnassignPrimaryIpResponseActionResourcesItem: S.Schema<AssignPrimaryIpResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type UnassignPrimaryIpResponseActionResourcesList = Array<AssignPrimaryIpResponseActionResourcesItem>;
export declare const UnassignPrimaryIpResponseActionResourcesList: S.Schema<UnassignPrimaryIpResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type UnassignPrimaryIpResponseActionError = AssignPrimaryIpResponseActionError;
export declare const UnassignPrimaryIpResponseActionError: S.Schema<AssignPrimaryIpResponseActionError>;
export interface UnassignPrimaryIpResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: UnassignPrimaryIpResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: UnassignPrimaryIpResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AssignPrimaryIpResponseActionError | null;
}
export declare const UnassignPrimaryIpResponseAction: S.Schema<UnassignPrimaryIpResponseAction>;
export interface UnassignPrimaryIpResponse {
    action: UnassignPrimaryIpResponseAction;
}
export declare const UnassignPrimaryIpResponse: S.Schema<UnassignPrimaryIpResponse>;
export type AssignPrimaryIpError = HetznerOpError;
/** Assign a Primary IP to a resource Assign a [Primary IP](#tag/primary-ips) to a resource. A [Server](#tag/servers) can only have one [Primary IP](#tag/primary-ips) of type `ipv4` and one of type `ipv6` assigned. If you need more IPs use [Floating IPs](#tag/floating-ips). A [Server](#tag/servers) must be powered off (status `off`) in order for this operation to succeed. #### Operation specific errors */
export declare const assignPrimaryIp: API.OperationMethod<AssignPrimaryIpRequest, AssignPrimaryIpResponse, AssignPrimaryIpError, HetznerOpContext>;
export type ChangePrimaryIpDnsPtrError = HetznerOpError;
/** Change reverse DNS records for a Primary IP Change the reverse DNS records for this [Primary IP](#tag/primary-ips). Allows to modify the PTR records set for the IP address. */
export declare const changePrimaryIpDnsPtr: API.OperationMethod<ChangePrimaryIpDnsPtrRequest, ChangePrimaryIpDnsPtrResponse, ChangePrimaryIpDnsPtrError, HetznerOpContext>;
export type ChangePrimaryIpProtectionError = HetznerOpError;
/** Change Primary IP Protection Changes the protection configuration of a [Primary IP](#tag/primary-ips). A [Primary IPs](#tag/primary-ips) deletion protection can only be enabled if its `auto_delete` property is set to `false`. */
export declare const changePrimaryIpProtection: API.OperationMethod<ChangePrimaryIpProtectionRequest, ChangePrimaryIpProtectionResponse, ChangePrimaryIpProtectionError, HetznerOpContext>;
export type GetPrimaryIpsActionError = HetznerOpError;
/** Get an Action Returns a single [Action](#tag/actions). */
export declare const getPrimaryIpsAction: API.OperationMethod<GetPrimaryIpsActionRequest, GetPrimaryIpsActionResponse, GetPrimaryIpsActionError, HetznerOpContext>;
export type ListPrimaryIpActionsError = HetznerOpError;
/** List Actions for a Primary IP Returns all [Actions](#tag/actions) for a [Primary IP](#tag/primary-ips). Use the provided URI parameters to modify the result. */
export declare const listPrimaryIpActions: API.PaginatedOperationMethod<ListPrimaryIpActionsRequest, ListPrimaryIpActionsResponse, ListPrimaryIpActionsError, HetznerOpContext, ListPrimaryIpActionsResponseActionsItem>;
export type ListPrimaryIpsActionsError = HetznerOpError;
/** List Actions Lists multiple [Actions](#tag/actions). Use the provided URI parameters to modify the result. */
export declare const listPrimaryIpsActions: API.PaginatedOperationMethod<ListPrimaryIpsActionsRequest, ListPrimaryIpsActionsResponse, ListPrimaryIpsActionsError, HetznerOpContext, ListPrimaryIpsActionsResponseActionsItem>;
export type UnassignPrimaryIpError = HetznerOpError;
/** Unassign a Primary IP from a resource Unassign a [Primary IP](#tag/primary-ips) from a resource. A [Server](#tag/servers) must be powered off (status `off`) in order for this operation to succeed. A [Server](#tag/servers) requires at least one network interface (public or private) to be powered on. #### Operation specific errors */
export declare const unassignPrimaryIp: API.OperationMethod<UnassignPrimaryIpRequest, UnassignPrimaryIpResponse, UnassignPrimaryIpError, HetznerOpContext>;
//# sourceMappingURL=primary_ip_actions.d.ts.map