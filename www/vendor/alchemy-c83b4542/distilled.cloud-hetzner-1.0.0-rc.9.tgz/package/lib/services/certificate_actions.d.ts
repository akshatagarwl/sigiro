import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetCertificatesActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetCertificatesActionRequest: S.Schema<GetCertificatesActionRequest>;
/** Status of the Action. */
export type GetCertificatesActionResponseActionStatus = "running" | "success" | "error";
export declare const GetCertificatesActionResponseActionStatus: any;
export interface GetCertificatesActionResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const GetCertificatesActionResponseActionResourcesItem: S.Schema<GetCertificatesActionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetCertificatesActionResponseActionResourcesList = Array<GetCertificatesActionResponseActionResourcesItem>;
export declare const GetCertificatesActionResponseActionResourcesList: S.Schema<GetCertificatesActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface GetCertificatesActionResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const GetCertificatesActionResponseActionError: S.Schema<GetCertificatesActionResponseActionError>;
export interface GetCertificatesActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetCertificatesActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetCertificatesActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: GetCertificatesActionResponseActionError | null;
}
export declare const GetCertificatesActionResponseAction: S.Schema<GetCertificatesActionResponseAction>;
export interface GetCertificatesActionResponse {
    action: GetCertificatesActionResponseAction;
}
export declare const GetCertificatesActionResponse: S.Schema<GetCertificatesActionResponse>;
export type ListCertificateActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListCertificateActionsRequestSortItem: any;
export type ListCertificateActionsRequestSortList = Array<ListCertificateActionsRequestSortItem | (string & {})>;
export declare const ListCertificateActionsRequestSortList: S.Schema<ListCertificateActionsRequestSortList>;
/** Status of the Action. */
export type ListCertificateActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListCertificateActionsRequestStatusItem: any;
export type ListCertificateActionsRequestStatusList = Array<ListCertificateActionsRequestStatusItem | (string & {})>;
export declare const ListCertificateActionsRequestStatusList: S.Schema<ListCertificateActionsRequestStatusList>;
export interface ListCertificateActionsRequest {
    /** ID of the Certificate. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListCertificateActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListCertificateActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListCertificateActionsRequest: S.Schema<ListCertificateActionsRequest>;
/** Status of the Action. */
export type ListCertificateActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListCertificateActionsResponseActionsItemStatus: any;
export type ListCertificateActionsResponseActionsItemResourcesItem = GetCertificatesActionResponseActionResourcesItem;
export declare const ListCertificateActionsResponseActionsItemResourcesItem: S.Schema<GetCertificatesActionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListCertificateActionsResponseActionsItemResourcesList = Array<GetCertificatesActionResponseActionResourcesItem>;
export declare const ListCertificateActionsResponseActionsItemResourcesList: S.Schema<ListCertificateActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListCertificateActionsResponseActionsItemError = GetCertificatesActionResponseActionError;
export declare const ListCertificateActionsResponseActionsItemError: S.Schema<GetCertificatesActionResponseActionError>;
export interface ListCertificateActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListCertificateActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListCertificateActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: GetCertificatesActionResponseActionError | null;
}
export declare const ListCertificateActionsResponseActionsItem: S.Schema<ListCertificateActionsResponseActionsItem>;
export type ListCertificateActionsResponseActionsList = Array<ListCertificateActionsResponseActionsItem>;
export declare const ListCertificateActionsResponseActionsList: S.Schema<ListCertificateActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListCertificateActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListCertificateActionsResponseMetaPagination: S.Schema<ListCertificateActionsResponseMetaPagination>;
export interface ListCertificateActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListCertificateActionsResponseMetaPagination;
}
export declare const ListCertificateActionsResponseMeta: S.Schema<ListCertificateActionsResponseMeta>;
export interface ListCertificateActionsResponse {
    actions: ListCertificateActionsResponseActionsList;
    meta: ListCertificateActionsResponseMeta;
}
export declare const ListCertificateActionsResponse: S.Schema<ListCertificateActionsResponse>;
export type ListCertificatesActionsRequestIdList = Array<number>;
export declare const ListCertificatesActionsRequestIdList: S.Schema<ListCertificatesActionsRequestIdList>;
export type ListCertificatesActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListCertificatesActionsRequestSortItem: any;
export type ListCertificatesActionsRequestSortList = Array<ListCertificatesActionsRequestSortItem | (string & {})>;
export declare const ListCertificatesActionsRequestSortList: S.Schema<ListCertificatesActionsRequestSortList>;
/** Status of the Action. */
export type ListCertificatesActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListCertificatesActionsRequestStatusItem: any;
export type ListCertificatesActionsRequestStatusList = Array<ListCertificatesActionsRequestStatusItem | (string & {})>;
export declare const ListCertificatesActionsRequestStatusList: S.Schema<ListCertificatesActionsRequestStatusList>;
export interface ListCertificatesActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListCertificatesActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListCertificatesActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListCertificatesActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListCertificatesActionsRequest: S.Schema<ListCertificatesActionsRequest>;
/** Status of the Action. */
export type ListCertificatesActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListCertificatesActionsResponseActionsItemStatus: any;
export type ListCertificatesActionsResponseActionsItemResourcesItem = GetCertificatesActionResponseActionResourcesItem;
export declare const ListCertificatesActionsResponseActionsItemResourcesItem: S.Schema<GetCertificatesActionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListCertificatesActionsResponseActionsItemResourcesList = Array<GetCertificatesActionResponseActionResourcesItem>;
export declare const ListCertificatesActionsResponseActionsItemResourcesList: S.Schema<ListCertificatesActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListCertificatesActionsResponseActionsItemError = GetCertificatesActionResponseActionError;
export declare const ListCertificatesActionsResponseActionsItemError: S.Schema<GetCertificatesActionResponseActionError>;
export interface ListCertificatesActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListCertificatesActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListCertificatesActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: GetCertificatesActionResponseActionError | null;
}
export declare const ListCertificatesActionsResponseActionsItem: S.Schema<ListCertificatesActionsResponseActionsItem>;
export type ListCertificatesActionsResponseActionsList = Array<ListCertificatesActionsResponseActionsItem>;
export declare const ListCertificatesActionsResponseActionsList: S.Schema<ListCertificatesActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListCertificatesActionsResponseMetaPagination = ListCertificateActionsResponseMetaPagination;
export declare const ListCertificatesActionsResponseMetaPagination: S.Schema<ListCertificateActionsResponseMetaPagination>;
export type ListCertificatesActionsResponseMeta = ListCertificateActionsResponseMeta;
export declare const ListCertificatesActionsResponseMeta: S.Schema<ListCertificateActionsResponseMeta>;
export interface ListCertificatesActionsResponse {
    actions: ListCertificatesActionsResponseActionsList;
    meta: ListCertificateActionsResponseMeta;
}
export declare const ListCertificatesActionsResponse: S.Schema<ListCertificatesActionsResponse>;
export interface RetryCertificateRequest {
    /** ID of the Certificate. */
    id: number;
}
export declare const RetryCertificateRequest: S.Schema<RetryCertificateRequest>;
/** Status of the Action. */
export type RetryCertificateResponseActionStatus = "running" | "success" | "error";
export declare const RetryCertificateResponseActionStatus: any;
export type RetryCertificateResponseActionResourcesItem = GetCertificatesActionResponseActionResourcesItem;
export declare const RetryCertificateResponseActionResourcesItem: S.Schema<GetCertificatesActionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RetryCertificateResponseActionResourcesList = Array<GetCertificatesActionResponseActionResourcesItem>;
export declare const RetryCertificateResponseActionResourcesList: S.Schema<RetryCertificateResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RetryCertificateResponseActionError = GetCertificatesActionResponseActionError;
export declare const RetryCertificateResponseActionError: S.Schema<GetCertificatesActionResponseActionError>;
export interface RetryCertificateResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RetryCertificateResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RetryCertificateResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: GetCertificatesActionResponseActionError | null;
}
export declare const RetryCertificateResponseAction: S.Schema<RetryCertificateResponseAction>;
export interface RetryCertificateResponse {
    action: RetryCertificateResponseAction;
}
export declare const RetryCertificateResponse: S.Schema<RetryCertificateResponse>;
export type GetCertificatesActionError = HetznerOpError;
/** Get an Action Returns a specific Action object. */
export declare const getCertificatesAction: API.OperationMethod<GetCertificatesActionRequest, GetCertificatesActionResponse, GetCertificatesActionError, HetznerOpContext>;
export type ListCertificateActionsError = HetznerOpError;
/** List Actions for a Certificate Returns all Action objects for a Certificate. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter. Only type `managed` Certificates can have Actions. For type `uploaded` Certificates the `actions` key will always contain an empty array. */
export declare const listCertificateActions: API.PaginatedOperationMethod<ListCertificateActionsRequest, ListCertificateActionsResponse, ListCertificateActionsError, HetznerOpContext, ListCertificateActionsResponseActionsItem>;
export type ListCertificatesActionsError = HetznerOpError;
/** List Actions Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` and `id` parameter. */
export declare const listCertificatesActions: API.PaginatedOperationMethod<ListCertificatesActionsRequest, ListCertificatesActionsResponse, ListCertificatesActionsError, HetznerOpContext, ListCertificatesActionsResponseActionsItem>;
export type RetryCertificateError = HetznerOpError;
/** Retry Issuance or Renewal Retry a failed Certificate issuance or renewal. Only applicable if the type of the Certificate is `managed` and the issuance or renewal status is `failed`. #### Operation specific errors */
export declare const retryCertificate: API.OperationMethod<RetryCertificateRequest, RetryCertificateResponse, RetryCertificateError, HetznerOpContext>;
//# sourceMappingURL=certificate_actions.d.ts.map