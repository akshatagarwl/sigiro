import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetLocationRequest {
    /** ID of the Location. */
    id: number;
}
export declare const GetLocationRequest: S.Schema<GetLocationRequest>;
export interface GetLocationResponseLocation {
    /** ID of the [Location](#tag/locations). */
    id: number;
    /** Unique identifier of the [Location](#tag/locations). */
    name: string;
    /** Human readable description of the [Location](#tag/locations). */
    description: string;
    /** Country the [Location](#tag/locations) resides in. ISO 3166-1 alpha-2 code of the country. */
    country: string;
    /** Name of the closest city to the [Location](#tag/locations). City name or city name and state in short form. E.g. `Falkenstein` or `Ashburn, VA`. */
    city: string;
    /** Latitude of the city closest to the [Location](#tag/locations). */
    latitude: number;
    /** Longitude of the city closest to the [Location](#tag/locations). */
    longitude: number;
    /** Name of the Network Zone this [Location](#tag/locations) resides in. */
    network_zone: string;
}
export declare const GetLocationResponseLocation: S.Schema<GetLocationResponseLocation>;
export interface GetLocationResponse {
    location: GetLocationResponseLocation;
}
export declare const GetLocationResponse: S.Schema<GetLocationResponse>;
export type ListLocationsRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc";
export declare const ListLocationsRequestSortItem: any;
export type ListLocationsRequestSortList = Array<ListLocationsRequestSortItem | (string & {})>;
export declare const ListLocationsRequestSortList: S.Schema<ListLocationsRequestSortList>;
export interface ListLocationsRequest {
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListLocationsRequestSortList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListLocationsRequest: S.Schema<ListLocationsRequest>;
export type ListLocationsResponseLocationsItem = GetLocationResponseLocation;
export declare const ListLocationsResponseLocationsItem: S.Schema<GetLocationResponseLocation>;
/** List of [Locations](#tag/locations). */
export type ListLocationsResponseLocationsList = Array<GetLocationResponseLocation>;
export declare const ListLocationsResponseLocationsList: S.Schema<ListLocationsResponseLocationsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListLocationsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListLocationsResponseMetaPagination: S.Schema<ListLocationsResponseMetaPagination>;
export interface ListLocationsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListLocationsResponseMetaPagination;
}
export declare const ListLocationsResponseMeta: S.Schema<ListLocationsResponseMeta>;
export interface ListLocationsResponse {
    /** List of [Locations](#tag/locations). */
    locations: ListLocationsResponseLocationsList;
    meta: ListLocationsResponseMeta;
}
export declare const ListLocationsResponse: S.Schema<ListLocationsResponse>;
export type GetLocationError = HetznerOpError;
/** Get a Location Returns a [Location](#tag/locations). */
export declare const getLocation: API.OperationMethod<GetLocationRequest, GetLocationResponse, GetLocationError, HetznerOpContext>;
export type ListLocationsError = HetznerOpError;
/** List Locations Returns all [Locations](#tag/locations). */
export declare const listLocations: API.PaginatedOperationMethod<ListLocationsRequest, ListLocationsResponse, ListLocationsError, HetznerOpContext, GetLocationResponseLocation>;
//# sourceMappingURL=locations.d.ts.map