import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
export type ChangeZonePrimaryNameserversRequestPrimaryNameserversItemTsigAlgorithm = "hmac-md5" | "hmac-sha1" | "hmac-sha256";
export declare const ChangeZonePrimaryNameserversRequestPrimaryNameserversItemTsigAlgorithm: any;
/** Primary nameserver that returns [Zones](#tag/zones) via `AXFR`. Must allow queries from and may send `NOTIFY` queries to [Hetzner's secondary nameservers](https://docs.hetzner.com/dns-console/dns/general/authoritative-name-servers#secondary-dns-servers-old-name-servers-for-robot-customers). */
export interface ChangeZonePrimaryNameserversRequestPrimaryNameserversItem {
    /** Public IPv4 or IPv6 address of the primary nameserver. Must be unique across all primary nameservers of this zone. */
    address: string;
    /** Port of the primary nameserver. */
    port?: number;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) key to use for the zone transfer. Must be base64 encoded. */
    tsig_key?: string;
    /** [Transaction signature (TSIG)](https://en.wikipedia.org/wiki/TSIG) algorithm used to generate the TSIG key. */
    tsig_algorithm?: ChangeZonePrimaryNameserversRequestPrimaryNameserversItemTsigAlgorithm | (string & {});
}
export declare const ChangeZonePrimaryNameserversRequestPrimaryNameserversItem: S.Schema<ChangeZonePrimaryNameserversRequestPrimaryNameserversItem>;
/** Primary nameservers of the [Zone](#tag/zones). */
export type ChangeZonePrimaryNameserversRequestPrimaryNameserversList = Array<ChangeZonePrimaryNameserversRequestPrimaryNameserversItem>;
export declare const ChangeZonePrimaryNameserversRequestPrimaryNameserversList: S.Schema<ChangeZonePrimaryNameserversRequestPrimaryNameserversList>;
export interface ChangeZonePrimaryNameserversRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Primary nameservers of the [Zone](#tag/zones). */
    primary_nameservers: ChangeZonePrimaryNameserversRequestPrimaryNameserversList;
}
export declare const ChangeZonePrimaryNameserversRequest: S.Schema<ChangeZonePrimaryNameserversRequest>;
/** Status of the Action. */
export type ChangeZonePrimaryNameserversResponseActionStatus = "running" | "success" | "error";
export declare const ChangeZonePrimaryNameserversResponseActionStatus: any;
export interface ChangeZonePrimaryNameserversResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const ChangeZonePrimaryNameserversResponseActionResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeZonePrimaryNameserversResponseActionResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const ChangeZonePrimaryNameserversResponseActionResourcesList: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface ChangeZonePrimaryNameserversResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const ChangeZonePrimaryNameserversResponseActionError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface ChangeZonePrimaryNameserversResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeZonePrimaryNameserversResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeZonePrimaryNameserversResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const ChangeZonePrimaryNameserversResponseAction: S.Schema<ChangeZonePrimaryNameserversResponseAction>;
export interface ChangeZonePrimaryNameserversResponse {
    action: ChangeZonePrimaryNameserversResponseAction;
}
export declare const ChangeZonePrimaryNameserversResponse: S.Schema<ChangeZonePrimaryNameserversResponse>;
export interface ChangeZoneProtectionRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Prevents the [Zone](#tag/zones) from being deleted. */
    delete?: boolean;
}
export declare const ChangeZoneProtectionRequest: S.Schema<ChangeZoneProtectionRequest>;
/** Status of the Action. */
export type ChangeZoneProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeZoneProtectionResponseActionStatus: any;
export type ChangeZoneProtectionResponseActionResourcesItem = ChangeZonePrimaryNameserversResponseActionResourcesItem;
export declare const ChangeZoneProtectionResponseActionResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeZoneProtectionResponseActionResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const ChangeZoneProtectionResponseActionResourcesList: S.Schema<ChangeZoneProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeZoneProtectionResponseActionError = ChangeZonePrimaryNameserversResponseActionError;
export declare const ChangeZoneProtectionResponseActionError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface ChangeZoneProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeZoneProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeZoneProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const ChangeZoneProtectionResponseAction: S.Schema<ChangeZoneProtectionResponseAction>;
export interface ChangeZoneProtectionResponse {
    action: ChangeZoneProtectionResponseAction;
}
export declare const ChangeZoneProtectionResponse: S.Schema<ChangeZoneProtectionResponse>;
export interface ChangeZoneTtlRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Default Time To Live (TTL) of the [Zone](#tag/zones). Must be in between 60s and 2147483647s. This TTL is used for [RRSets](#tag/zone-rrsets) that do not explicitly define a TTL. */
    ttl: number;
}
export declare const ChangeZoneTtlRequest: S.Schema<ChangeZoneTtlRequest>;
/** Status of the Action. */
export type ChangeZoneTtlResponseActionStatus = "running" | "success" | "error";
export declare const ChangeZoneTtlResponseActionStatus: any;
export type ChangeZoneTtlResponseActionResourcesItem = ChangeZonePrimaryNameserversResponseActionResourcesItem;
export declare const ChangeZoneTtlResponseActionResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeZoneTtlResponseActionResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const ChangeZoneTtlResponseActionResourcesList: S.Schema<ChangeZoneTtlResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeZoneTtlResponseActionError = ChangeZonePrimaryNameserversResponseActionError;
export declare const ChangeZoneTtlResponseActionError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface ChangeZoneTtlResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeZoneTtlResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeZoneTtlResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const ChangeZoneTtlResponseAction: S.Schema<ChangeZoneTtlResponseAction>;
export interface ChangeZoneTtlResponse {
    action: ChangeZoneTtlResponseAction;
}
export declare const ChangeZoneTtlResponse: S.Schema<ChangeZoneTtlResponse>;
export interface GetZonesActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetZonesActionRequest: S.Schema<GetZonesActionRequest>;
/** Status of the Action. */
export type GetZonesActionResponseActionStatus = "running" | "success" | "error";
export declare const GetZonesActionResponseActionStatus: any;
export type GetZonesActionResponseActionResourcesItem = ChangeZonePrimaryNameserversResponseActionResourcesItem;
export declare const GetZonesActionResponseActionResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetZonesActionResponseActionResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const GetZonesActionResponseActionResourcesList: S.Schema<GetZonesActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetZonesActionResponseActionError = ChangeZonePrimaryNameserversResponseActionError;
export declare const GetZonesActionResponseActionError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface GetZonesActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetZonesActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetZonesActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const GetZonesActionResponseAction: S.Schema<GetZonesActionResponseAction>;
export interface GetZonesActionResponse {
    action: GetZonesActionResponseAction;
}
export declare const GetZonesActionResponse: S.Schema<GetZonesActionResponse>;
export interface ImportZoneZonefileRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Zone file to import. See [Zone file import](#tag/zones/zone-file-import) for more details. */
    zonefile: string;
}
export declare const ImportZoneZonefileRequest: S.Schema<ImportZoneZonefileRequest>;
/** Status of the Action. */
export type ImportZoneZonefileResponseActionStatus = "running" | "success" | "error";
export declare const ImportZoneZonefileResponseActionStatus: any;
export type ImportZoneZonefileResponseActionResourcesItem = ChangeZonePrimaryNameserversResponseActionResourcesItem;
export declare const ImportZoneZonefileResponseActionResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ImportZoneZonefileResponseActionResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const ImportZoneZonefileResponseActionResourcesList: S.Schema<ImportZoneZonefileResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ImportZoneZonefileResponseActionError = ChangeZonePrimaryNameserversResponseActionError;
export declare const ImportZoneZonefileResponseActionError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface ImportZoneZonefileResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ImportZoneZonefileResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ImportZoneZonefileResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const ImportZoneZonefileResponseAction: S.Schema<ImportZoneZonefileResponseAction>;
export interface ImportZoneZonefileResponse {
    action: ImportZoneZonefileResponseAction;
}
export declare const ImportZoneZonefileResponse: S.Schema<ImportZoneZonefileResponse>;
export type ListZoneActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListZoneActionsRequestSortItem: any;
export type ListZoneActionsRequestSortList = Array<ListZoneActionsRequestSortItem | (string & {})>;
export declare const ListZoneActionsRequestSortList: S.Schema<ListZoneActionsRequestSortList>;
/** Status of the Action. */
export type ListZoneActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListZoneActionsRequestStatusItem: any;
export type ListZoneActionsRequestStatusList = Array<ListZoneActionsRequestStatusItem | (string & {})>;
export declare const ListZoneActionsRequestStatusList: S.Schema<ListZoneActionsRequestStatusList>;
export interface ListZoneActionsRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListZoneActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListZoneActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListZoneActionsRequest: S.Schema<ListZoneActionsRequest>;
/** Status of the Action. */
export type ListZoneActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListZoneActionsResponseActionsItemStatus: any;
export type ListZoneActionsResponseActionsItemResourcesItem = ChangeZonePrimaryNameserversResponseActionResourcesItem;
export declare const ListZoneActionsResponseActionsItemResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListZoneActionsResponseActionsItemResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const ListZoneActionsResponseActionsItemResourcesList: S.Schema<ListZoneActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListZoneActionsResponseActionsItemError = ChangeZonePrimaryNameserversResponseActionError;
export declare const ListZoneActionsResponseActionsItemError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface ListZoneActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListZoneActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListZoneActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const ListZoneActionsResponseActionsItem: S.Schema<ListZoneActionsResponseActionsItem>;
export type ListZoneActionsResponseActionsList = Array<ListZoneActionsResponseActionsItem>;
export declare const ListZoneActionsResponseActionsList: S.Schema<ListZoneActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListZoneActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListZoneActionsResponseMetaPagination: S.Schema<ListZoneActionsResponseMetaPagination>;
export interface ListZoneActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListZoneActionsResponseMetaPagination;
}
export declare const ListZoneActionsResponseMeta: S.Schema<ListZoneActionsResponseMeta>;
export interface ListZoneActionsResponse {
    actions: ListZoneActionsResponseActionsList;
    meta: ListZoneActionsResponseMeta;
}
export declare const ListZoneActionsResponse: S.Schema<ListZoneActionsResponse>;
export type ListZonesActionsRequestIdList = Array<number>;
export declare const ListZonesActionsRequestIdList: S.Schema<ListZonesActionsRequestIdList>;
export type ListZonesActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListZonesActionsRequestSortItem: any;
export type ListZonesActionsRequestSortList = Array<ListZonesActionsRequestSortItem | (string & {})>;
export declare const ListZonesActionsRequestSortList: S.Schema<ListZonesActionsRequestSortList>;
/** Status of the Action. */
export type ListZonesActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListZonesActionsRequestStatusItem: any;
export type ListZonesActionsRequestStatusList = Array<ListZonesActionsRequestStatusItem | (string & {})>;
export declare const ListZonesActionsRequestStatusList: S.Schema<ListZonesActionsRequestStatusList>;
export interface ListZonesActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListZonesActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListZonesActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListZonesActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListZonesActionsRequest: S.Schema<ListZonesActionsRequest>;
/** Status of the Action. */
export type ListZonesActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListZonesActionsResponseActionsItemStatus: any;
export type ListZonesActionsResponseActionsItemResourcesItem = ChangeZonePrimaryNameserversResponseActionResourcesItem;
export declare const ListZonesActionsResponseActionsItemResourcesItem: S.Schema<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListZonesActionsResponseActionsItemResourcesList = Array<ChangeZonePrimaryNameserversResponseActionResourcesItem>;
export declare const ListZonesActionsResponseActionsItemResourcesList: S.Schema<ListZonesActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListZonesActionsResponseActionsItemError = ChangeZonePrimaryNameserversResponseActionError;
export declare const ListZonesActionsResponseActionsItemError: S.Schema<ChangeZonePrimaryNameserversResponseActionError>;
export interface ListZonesActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListZonesActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListZonesActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: ChangeZonePrimaryNameserversResponseActionError | null;
}
export declare const ListZonesActionsResponseActionsItem: S.Schema<ListZonesActionsResponseActionsItem>;
export type ListZonesActionsResponseActionsList = Array<ListZonesActionsResponseActionsItem>;
export declare const ListZonesActionsResponseActionsList: S.Schema<ListZonesActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListZonesActionsResponseMetaPagination = ListZoneActionsResponseMetaPagination;
export declare const ListZonesActionsResponseMetaPagination: S.Schema<ListZoneActionsResponseMetaPagination>;
export type ListZonesActionsResponseMeta = ListZoneActionsResponseMeta;
export declare const ListZonesActionsResponseMeta: S.Schema<ListZoneActionsResponseMeta>;
export interface ListZonesActionsResponse {
    actions: ListZonesActionsResponseActionsList;
    meta: ListZoneActionsResponseMeta;
}
export declare const ListZonesActionsResponse: S.Schema<ListZonesActionsResponse>;
export type ChangeZonePrimaryNameserversError = HetznerOpError;
/** Change a Zone's Primary Nameservers Overwrites the primary nameservers of a [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in secondary mode. #### Operation specific errors */
export declare const changeZonePrimaryNameservers: API.OperationMethod<ChangeZonePrimaryNameserversRequest, ChangeZonePrimaryNameserversResponse, ChangeZonePrimaryNameserversError, HetznerOpContext>;
export type ChangeZoneProtectionError = HetznerOpError;
/** Change a Zone's Protection Changes the protection configuration of a [Zone](#tag/zones). */
export declare const changeZoneProtection: API.OperationMethod<ChangeZoneProtectionRequest, ChangeZoneProtectionResponse, ChangeZoneProtectionError, HetznerOpContext>;
export type ChangeZoneTtlError = HetznerOpError;
/** Change a Zone's Default TTL Changes the default Time To Live (TTL) of a [Zone](#tag/zones). This TTL is used for [RRSets](#tag/zone-rrsets) that do not explicitly define a TTL. Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const changeZoneTtl: API.OperationMethod<ChangeZoneTtlRequest, ChangeZoneTtlResponse, ChangeZoneTtlError, HetznerOpContext>;
export type GetZonesActionError = HetznerOpError;
/** Get an Action Returns a specific [Action](#tag/actions). */
export declare const getZonesAction: API.OperationMethod<GetZonesActionRequest, GetZonesActionResponse, GetZonesActionError, HetznerOpContext>;
export type ImportZoneZonefileError = HetznerOpError;
/** Import a Zone file Imports a zone file, replacing all resource record sets ([RRSets](#tag/zone-rrsets)). The import will fail if existing [RRSet](#tag/zone-rrsets) are `change` protected. See [Zone file import](#tag/zones/zone-file-import) for more details. Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const importZoneZonefile: API.OperationMethod<ImportZoneZonefileRequest, ImportZoneZonefileResponse, ImportZoneZonefileError, HetznerOpContext>;
export type ListZoneActionsError = HetznerOpError;
/** List Actions for a Zone Returns all [Actions](#tag/actions) for a [Zone](#tag/zones). Use the provided URI parameters to modify the result. */
export declare const listZoneActions: API.PaginatedOperationMethod<ListZoneActionsRequest, ListZoneActionsResponse, ListZoneActionsError, HetznerOpContext, ListZoneActionsResponseActionsItem>;
export type ListZonesActionsError = HetznerOpError;
/** List Actions Returns all [Zone](#tag/zones) [Actions](#tag/actions). Use the provided URI parameters to modify the result. */
export declare const listZonesActions: API.PaginatedOperationMethod<ListZonesActionsRequest, ListZonesActionsResponse, ListZonesActionsError, HetznerOpContext, ListZonesActionsResponseActionsItem>;
//# sourceMappingURL=zone_actions.d.ts.map