import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateFirewallRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateFirewallRequestLabelsMap: S.Schema<CreateFirewallRequestLabelsMap>;
/** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
export type CreateFirewallRequestRulesItemDirection = "in" | "out";
export declare const CreateFirewallRequestRulesItemDirection: any;
/** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type CreateFirewallRequestRulesItemSourceIpsList = Array<string>;
export declare const CreateFirewallRequestRulesItemSourceIpsList: S.Schema<CreateFirewallRequestRulesItemSourceIpsList>;
/** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type CreateFirewallRequestRulesItemDestinationIpsList = Array<string>;
export declare const CreateFirewallRequestRulesItemDestinationIpsList: S.Schema<CreateFirewallRequestRulesItemDestinationIpsList>;
/** Network protocol to apply the rule for. */
export type CreateFirewallRequestRulesItemProtocol = "tcp" | "udp" | "icmp" | "esp" | "gre";
export declare const CreateFirewallRequestRulesItemProtocol: any;
export interface CreateFirewallRequestRulesItem {
    /** Description of the rule. */
    description?: string | null;
    /** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
    direction: CreateFirewallRequestRulesItemDirection | (string & {});
    /** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    source_ips?: CreateFirewallRequestRulesItemSourceIpsList;
    /** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    destination_ips?: CreateFirewallRequestRulesItemDestinationIpsList;
    /** Network protocol to apply the rule for. */
    protocol: CreateFirewallRequestRulesItemProtocol | (string & {});
    /** Port or port range to apply the rule for. Only applicable for protocols `tcp` and `udp`. A port range can be specified by separating lower and upper bounds with a dash. `1024-5000` will include all ports starting from 1024 up to port 5000. */
    port?: string;
}
export declare const CreateFirewallRequestRulesItem: S.Schema<CreateFirewallRequestRulesItem>;
/** Array of rules. Rules are limited to 50 entries per [Firewall](#tag/firewalls) and [500 effective rules](https://docs.hetzner.com/cloud/firewalls/overview#limits). */
export type CreateFirewallRequestRulesList = Array<CreateFirewallRequestRulesItem>;
export declare const CreateFirewallRequestRulesList: S.Schema<CreateFirewallRequestRulesList>;
/** Type of the resource. */
export type CreateFirewallRequestApplyToItemType = "server" | "label_selector";
export declare const CreateFirewallRequestApplyToItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export interface CreateFirewallRequestApplyToItemServer {
    /** ID of the [Server](#tag/servers). */
    id: number;
}
export declare const CreateFirewallRequestApplyToItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export interface CreateFirewallRequestApplyToItemLabelSelector {
    /** The selector. */
    selector: string;
}
export declare const CreateFirewallRequestApplyToItemLabelSelector: S.Schema<CreateFirewallRequestApplyToItemLabelSelector>;
export interface CreateFirewallRequestApplyToItem {
    /** Type of the resource. */
    type: CreateFirewallRequestApplyToItemType | (string & {});
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: CreateFirewallRequestApplyToItemLabelSelector;
}
export declare const CreateFirewallRequestApplyToItem: S.Schema<CreateFirewallRequestApplyToItem>;
/** Resources to apply the [Firewall](#tag/firewalls) to. Resources added directly are taking precedence over those added via a [Label Selector](#description/label-selector). */
export type CreateFirewallRequestApplyToList = Array<CreateFirewallRequestApplyToItem>;
export declare const CreateFirewallRequestApplyToList: S.Schema<CreateFirewallRequestApplyToList>;
export interface CreateFirewallRequest {
    /** Name of the [Firewall](#tag/firewalls). Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateFirewallRequestLabelsMap;
    /** Array of rules. Rules are limited to 50 entries per [Firewall](#tag/firewalls) and [500 effective rules](https://docs.hetzner.com/cloud/firewalls/overview#limits). */
    rules?: CreateFirewallRequestRulesList;
    /** Resources to apply the [Firewall](#tag/firewalls) to. Resources added directly are taking precedence over those added via a [Label Selector](#description/label-selector). */
    apply_to?: CreateFirewallRequestApplyToList;
}
export declare const CreateFirewallRequest: S.Schema<CreateFirewallRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreateFirewallResponseFirewallLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreateFirewallResponseFirewallLabelsMap: S.Schema<CreateFirewallResponseFirewallLabelsMap>;
/** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
export type CreateFirewallResponseFirewallRulesItemDirection = "in" | "out";
export declare const CreateFirewallResponseFirewallRulesItemDirection: any;
/** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type CreateFirewallResponseFirewallRulesItemSourceIpsList = Array<string>;
export declare const CreateFirewallResponseFirewallRulesItemSourceIpsList: S.Schema<CreateFirewallResponseFirewallRulesItemSourceIpsList>;
/** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type CreateFirewallResponseFirewallRulesItemDestinationIpsList = Array<string>;
export declare const CreateFirewallResponseFirewallRulesItemDestinationIpsList: S.Schema<CreateFirewallResponseFirewallRulesItemDestinationIpsList>;
/** Network protocol to apply the rule for. */
export type CreateFirewallResponseFirewallRulesItemProtocol = "tcp" | "udp" | "icmp" | "esp" | "gre";
export declare const CreateFirewallResponseFirewallRulesItemProtocol: any;
export interface CreateFirewallResponseFirewallRulesItem {
    /** Description of the rule. */
    description?: string | null;
    /** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
    direction: CreateFirewallResponseFirewallRulesItemDirection;
    /** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    source_ips: CreateFirewallResponseFirewallRulesItemSourceIpsList;
    /** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    destination_ips: CreateFirewallResponseFirewallRulesItemDestinationIpsList;
    /** Network protocol to apply the rule for. */
    protocol: CreateFirewallResponseFirewallRulesItemProtocol;
    /** Port or port range to apply the rule for. Only applicable for protocols `tcp` and `udp`. A port range can be specified by separating lower and upper bounds with a dash. `1024-5000` will include all ports starting from 1024 up to port 5000. */
    port: string | null;
}
export declare const CreateFirewallResponseFirewallRulesItem: S.Schema<CreateFirewallResponseFirewallRulesItem>;
export type CreateFirewallResponseFirewallRulesList = Array<CreateFirewallResponseFirewallRulesItem>;
export declare const CreateFirewallResponseFirewallRulesList: S.Schema<CreateFirewallResponseFirewallRulesList>;
/** The type of resource to apply. */
export type CreateFirewallResponseFirewallAppliedToItemType = "server" | "label_selector";
export declare const CreateFirewallResponseFirewallAppliedToItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type CreateFirewallResponseFirewallAppliedToItemServer = CreateFirewallRequestApplyToItemServer;
export declare const CreateFirewallResponseFirewallAppliedToItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export type CreateFirewallResponseFirewallAppliedToItemLabelSelector = CreateFirewallRequestApplyToItemLabelSelector;
export declare const CreateFirewallResponseFirewallAppliedToItemLabelSelector: S.Schema<CreateFirewallRequestApplyToItemLabelSelector>;
/** Type of resource. */
export type CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType = "server";
export declare const CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemServer = CreateFirewallRequestApplyToItemServer;
export declare const CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
export interface CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem {
    /** Type of resource. */
    type?: CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
}
export declare const CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem: S.Schema<CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem>;
/** Resources applied to via this [Label Selector](#description/label-selector). */
export type CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesList = Array<CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem>;
export declare const CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesList: S.Schema<CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesList>;
export interface CreateFirewallResponseFirewallAppliedToItem {
    /** The type of resource to apply. */
    type: CreateFirewallResponseFirewallAppliedToItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: CreateFirewallRequestApplyToItemLabelSelector;
    /** Resources applied to via this [Label Selector](#description/label-selector). */
    applied_to_resources?: CreateFirewallResponseFirewallAppliedToItemAppliedToResourcesList;
}
export declare const CreateFirewallResponseFirewallAppliedToItem: S.Schema<CreateFirewallResponseFirewallAppliedToItem>;
export type CreateFirewallResponseFirewallAppliedToList = Array<CreateFirewallResponseFirewallAppliedToItem>;
export declare const CreateFirewallResponseFirewallAppliedToList: S.Schema<CreateFirewallResponseFirewallAppliedToList>;
export interface CreateFirewallResponseFirewall {
    /** ID of the [Firewall](#tag/firewalls). */
    id: number;
    /** Name of the [Firewall](#tag/firewalls). Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreateFirewallResponseFirewallLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    rules: CreateFirewallResponseFirewallRulesList;
    applied_to: CreateFirewallResponseFirewallAppliedToList;
}
export declare const CreateFirewallResponseFirewall: S.Schema<CreateFirewallResponseFirewall>;
/** Status of the Action. */
export type CreateFirewallResponseActionsItemStatus = "running" | "success" | "error";
export declare const CreateFirewallResponseActionsItemStatus: any;
export interface CreateFirewallResponseActionsItemResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreateFirewallResponseActionsItemResourcesItem: S.Schema<CreateFirewallResponseActionsItemResourcesItem>;
/** Resources the Action relates to. */
export type CreateFirewallResponseActionsItemResourcesList = Array<CreateFirewallResponseActionsItemResourcesItem>;
export declare const CreateFirewallResponseActionsItemResourcesList: S.Schema<CreateFirewallResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreateFirewallResponseActionsItemError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreateFirewallResponseActionsItemError: S.Schema<CreateFirewallResponseActionsItemError>;
export interface CreateFirewallResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreateFirewallResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreateFirewallResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreateFirewallResponseActionsItemError | null;
}
export declare const CreateFirewallResponseActionsItem: S.Schema<CreateFirewallResponseActionsItem>;
export type CreateFirewallResponseActionsList = Array<CreateFirewallResponseActionsItem>;
export declare const CreateFirewallResponseActionsList: S.Schema<CreateFirewallResponseActionsList>;
export interface CreateFirewallResponse {
    firewall?: CreateFirewallResponseFirewall;
    actions?: CreateFirewallResponseActionsList;
}
export declare const CreateFirewallResponse: S.Schema<CreateFirewallResponse>;
export interface DeleteFirewallRequest {
    /** ID of the Firewall. */
    id: number;
}
export declare const DeleteFirewallRequest: S.Schema<DeleteFirewallRequest>;
export interface DeleteFirewallResponse {
}
export declare const DeleteFirewallResponse: S.Schema<DeleteFirewallResponse>;
export interface GetFirewallRequest {
    /** ID of the Firewall. */
    id: number;
}
export declare const GetFirewallRequest: S.Schema<GetFirewallRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetFirewallResponseFirewallLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetFirewallResponseFirewallLabelsMap: S.Schema<GetFirewallResponseFirewallLabelsMap>;
/** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
export type GetFirewallResponseFirewallRulesItemDirection = "in" | "out";
export declare const GetFirewallResponseFirewallRulesItemDirection: any;
/** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type GetFirewallResponseFirewallRulesItemSourceIpsList = Array<string>;
export declare const GetFirewallResponseFirewallRulesItemSourceIpsList: S.Schema<GetFirewallResponseFirewallRulesItemSourceIpsList>;
/** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type GetFirewallResponseFirewallRulesItemDestinationIpsList = Array<string>;
export declare const GetFirewallResponseFirewallRulesItemDestinationIpsList: S.Schema<GetFirewallResponseFirewallRulesItemDestinationIpsList>;
/** Network protocol to apply the rule for. */
export type GetFirewallResponseFirewallRulesItemProtocol = "tcp" | "udp" | "icmp" | "esp" | "gre";
export declare const GetFirewallResponseFirewallRulesItemProtocol: any;
export interface GetFirewallResponseFirewallRulesItem {
    /** Description of the rule. */
    description?: string | null;
    /** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
    direction: GetFirewallResponseFirewallRulesItemDirection;
    /** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    source_ips: GetFirewallResponseFirewallRulesItemSourceIpsList;
    /** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    destination_ips: GetFirewallResponseFirewallRulesItemDestinationIpsList;
    /** Network protocol to apply the rule for. */
    protocol: GetFirewallResponseFirewallRulesItemProtocol;
    /** Port or port range to apply the rule for. Only applicable for protocols `tcp` and `udp`. A port range can be specified by separating lower and upper bounds with a dash. `1024-5000` will include all ports starting from 1024 up to port 5000. */
    port: string | null;
}
export declare const GetFirewallResponseFirewallRulesItem: S.Schema<GetFirewallResponseFirewallRulesItem>;
export type GetFirewallResponseFirewallRulesList = Array<GetFirewallResponseFirewallRulesItem>;
export declare const GetFirewallResponseFirewallRulesList: S.Schema<GetFirewallResponseFirewallRulesList>;
/** The type of resource to apply. */
export type GetFirewallResponseFirewallAppliedToItemType = "server" | "label_selector";
export declare const GetFirewallResponseFirewallAppliedToItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type GetFirewallResponseFirewallAppliedToItemServer = CreateFirewallRequestApplyToItemServer;
export declare const GetFirewallResponseFirewallAppliedToItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export type GetFirewallResponseFirewallAppliedToItemLabelSelector = CreateFirewallRequestApplyToItemLabelSelector;
export declare const GetFirewallResponseFirewallAppliedToItemLabelSelector: S.Schema<CreateFirewallRequestApplyToItemLabelSelector>;
/** Type of resource. */
export type GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType = "server";
export declare const GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItemServer = CreateFirewallRequestApplyToItemServer;
export declare const GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
export interface GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItem {
    /** Type of resource. */
    type?: GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
}
export declare const GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItem: S.Schema<GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItem>;
/** Resources applied to via this [Label Selector](#description/label-selector). */
export type GetFirewallResponseFirewallAppliedToItemAppliedToResourcesList = Array<GetFirewallResponseFirewallAppliedToItemAppliedToResourcesItem>;
export declare const GetFirewallResponseFirewallAppliedToItemAppliedToResourcesList: S.Schema<GetFirewallResponseFirewallAppliedToItemAppliedToResourcesList>;
export interface GetFirewallResponseFirewallAppliedToItem {
    /** The type of resource to apply. */
    type: GetFirewallResponseFirewallAppliedToItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: CreateFirewallRequestApplyToItemLabelSelector;
    /** Resources applied to via this [Label Selector](#description/label-selector). */
    applied_to_resources?: GetFirewallResponseFirewallAppliedToItemAppliedToResourcesList;
}
export declare const GetFirewallResponseFirewallAppliedToItem: S.Schema<GetFirewallResponseFirewallAppliedToItem>;
export type GetFirewallResponseFirewallAppliedToList = Array<GetFirewallResponseFirewallAppliedToItem>;
export declare const GetFirewallResponseFirewallAppliedToList: S.Schema<GetFirewallResponseFirewallAppliedToList>;
export interface GetFirewallResponseFirewall {
    /** ID of the [Firewall](#tag/firewalls). */
    id: number;
    /** Name of the [Firewall](#tag/firewalls). Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: GetFirewallResponseFirewallLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    rules: GetFirewallResponseFirewallRulesList;
    applied_to: GetFirewallResponseFirewallAppliedToList;
}
export declare const GetFirewallResponseFirewall: S.Schema<GetFirewallResponseFirewall>;
export interface GetFirewallResponse {
    firewall: GetFirewallResponseFirewall;
}
export declare const GetFirewallResponse: S.Schema<GetFirewallResponse>;
export type ListFirewallsRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListFirewallsRequestSortItem: any;
export type ListFirewallsRequestSortList = Array<ListFirewallsRequestSortItem | (string & {})>;
export declare const ListFirewallsRequestSortList: S.Schema<ListFirewallsRequestSortList>;
export interface ListFirewallsRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListFirewallsRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListFirewallsRequest: S.Schema<ListFirewallsRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListFirewallsResponseFirewallsItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListFirewallsResponseFirewallsItemLabelsMap: S.Schema<ListFirewallsResponseFirewallsItemLabelsMap>;
/** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
export type ListFirewallsResponseFirewallsItemRulesItemDirection = "in" | "out";
export declare const ListFirewallsResponseFirewallsItemRulesItemDirection: any;
/** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type ListFirewallsResponseFirewallsItemRulesItemSourceIpsList = Array<string>;
export declare const ListFirewallsResponseFirewallsItemRulesItemSourceIpsList: S.Schema<ListFirewallsResponseFirewallsItemRulesItemSourceIpsList>;
/** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type ListFirewallsResponseFirewallsItemRulesItemDestinationIpsList = Array<string>;
export declare const ListFirewallsResponseFirewallsItemRulesItemDestinationIpsList: S.Schema<ListFirewallsResponseFirewallsItemRulesItemDestinationIpsList>;
/** Network protocol to apply the rule for. */
export type ListFirewallsResponseFirewallsItemRulesItemProtocol = "tcp" | "udp" | "icmp" | "esp" | "gre";
export declare const ListFirewallsResponseFirewallsItemRulesItemProtocol: any;
export interface ListFirewallsResponseFirewallsItemRulesItem {
    /** Description of the rule. */
    description?: string | null;
    /** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
    direction: ListFirewallsResponseFirewallsItemRulesItemDirection;
    /** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    source_ips: ListFirewallsResponseFirewallsItemRulesItemSourceIpsList;
    /** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    destination_ips: ListFirewallsResponseFirewallsItemRulesItemDestinationIpsList;
    /** Network protocol to apply the rule for. */
    protocol: ListFirewallsResponseFirewallsItemRulesItemProtocol;
    /** Port or port range to apply the rule for. Only applicable for protocols `tcp` and `udp`. A port range can be specified by separating lower and upper bounds with a dash. `1024-5000` will include all ports starting from 1024 up to port 5000. */
    port: string | null;
}
export declare const ListFirewallsResponseFirewallsItemRulesItem: S.Schema<ListFirewallsResponseFirewallsItemRulesItem>;
export type ListFirewallsResponseFirewallsItemRulesList = Array<ListFirewallsResponseFirewallsItemRulesItem>;
export declare const ListFirewallsResponseFirewallsItemRulesList: S.Schema<ListFirewallsResponseFirewallsItemRulesList>;
/** The type of resource to apply. */
export type ListFirewallsResponseFirewallsItemAppliedToItemType = "server" | "label_selector";
export declare const ListFirewallsResponseFirewallsItemAppliedToItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type ListFirewallsResponseFirewallsItemAppliedToItemServer = CreateFirewallRequestApplyToItemServer;
export declare const ListFirewallsResponseFirewallsItemAppliedToItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export type ListFirewallsResponseFirewallsItemAppliedToItemLabelSelector = CreateFirewallRequestApplyToItemLabelSelector;
export declare const ListFirewallsResponseFirewallsItemAppliedToItemLabelSelector: S.Schema<CreateFirewallRequestApplyToItemLabelSelector>;
/** Type of resource. */
export type ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItemType = "server";
export declare const ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItemServer = CreateFirewallRequestApplyToItemServer;
export declare const ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
export interface ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItem {
    /** Type of resource. */
    type?: ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
}
export declare const ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItem: S.Schema<ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItem>;
/** Resources applied to via this [Label Selector](#description/label-selector). */
export type ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesList = Array<ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesItem>;
export declare const ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesList: S.Schema<ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesList>;
export interface ListFirewallsResponseFirewallsItemAppliedToItem {
    /** The type of resource to apply. */
    type: ListFirewallsResponseFirewallsItemAppliedToItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: CreateFirewallRequestApplyToItemLabelSelector;
    /** Resources applied to via this [Label Selector](#description/label-selector). */
    applied_to_resources?: ListFirewallsResponseFirewallsItemAppliedToItemAppliedToResourcesList;
}
export declare const ListFirewallsResponseFirewallsItemAppliedToItem: S.Schema<ListFirewallsResponseFirewallsItemAppliedToItem>;
export type ListFirewallsResponseFirewallsItemAppliedToList = Array<ListFirewallsResponseFirewallsItemAppliedToItem>;
export declare const ListFirewallsResponseFirewallsItemAppliedToList: S.Schema<ListFirewallsResponseFirewallsItemAppliedToList>;
export interface ListFirewallsResponseFirewallsItem {
    /** ID of the [Firewall](#tag/firewalls). */
    id: number;
    /** Name of the [Firewall](#tag/firewalls). Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: ListFirewallsResponseFirewallsItemLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    rules: ListFirewallsResponseFirewallsItemRulesList;
    applied_to: ListFirewallsResponseFirewallsItemAppliedToList;
}
export declare const ListFirewallsResponseFirewallsItem: S.Schema<ListFirewallsResponseFirewallsItem>;
export type ListFirewallsResponseFirewallsList = Array<ListFirewallsResponseFirewallsItem>;
export declare const ListFirewallsResponseFirewallsList: S.Schema<ListFirewallsResponseFirewallsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListFirewallsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListFirewallsResponseMetaPagination: S.Schema<ListFirewallsResponseMetaPagination>;
export interface ListFirewallsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListFirewallsResponseMetaPagination;
}
export declare const ListFirewallsResponseMeta: S.Schema<ListFirewallsResponseMeta>;
export interface ListFirewallsResponse {
    firewalls: ListFirewallsResponseFirewallsList;
    meta: ListFirewallsResponseMeta;
}
export declare const ListFirewallsResponse: S.Schema<ListFirewallsResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdateFirewallRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateFirewallRequestLabelsMap: S.Schema<UpdateFirewallRequestLabelsMap>;
export interface UpdateFirewallRequest {
    /** ID of the Firewall. */
    id: number;
    /** Name of the [Firewall](#tag/firewalls). Must be unique per Project. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateFirewallRequestLabelsMap;
}
export declare const UpdateFirewallRequest: S.Schema<UpdateFirewallRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdateFirewallResponseFirewallLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdateFirewallResponseFirewallLabelsMap: S.Schema<UpdateFirewallResponseFirewallLabelsMap>;
/** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
export type UpdateFirewallResponseFirewallRulesItemDirection = "in" | "out";
export declare const UpdateFirewallResponseFirewallRulesItemDirection: any;
/** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type UpdateFirewallResponseFirewallRulesItemSourceIpsList = Array<string>;
export declare const UpdateFirewallResponseFirewallRulesItemSourceIpsList: S.Schema<UpdateFirewallResponseFirewallRulesItemSourceIpsList>;
/** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
export type UpdateFirewallResponseFirewallRulesItemDestinationIpsList = Array<string>;
export declare const UpdateFirewallResponseFirewallRulesItemDestinationIpsList: S.Schema<UpdateFirewallResponseFirewallRulesItemDestinationIpsList>;
/** Network protocol to apply the rule for. */
export type UpdateFirewallResponseFirewallRulesItemProtocol = "tcp" | "udp" | "icmp" | "esp" | "gre";
export declare const UpdateFirewallResponseFirewallRulesItemProtocol: any;
export interface UpdateFirewallResponseFirewallRulesItem {
    /** Description of the rule. */
    description?: string | null;
    /** Traffic direction in which the rule should be applied to. Use `source_ips` for direction `in` and `destination_ips` for direction `out` to specify IPs. */
    direction: UpdateFirewallResponseFirewallRulesItemDirection;
    /** List of permitted IPv4/IPv6 addresses for incoming traffic. The `direction` must be set to `in`. IPs must be provided in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    source_ips: UpdateFirewallResponseFirewallRulesItemSourceIpsList;
    /** List of permitted IPv4/IPv6 addresses for outgoing traffic. The `direction` must be set to `out`. IPs must be in [CIDR block notation](https://wikipedia.org/wiki/CIDR). You can specify 100 CIDR blocks at most. The CIDR blocks may refer to networks (with empty host bits) or single hosts. For example, a network could be defined with `10.0.1.0/24` or `2001:db8:ff00:42::/64`, and a single host with `10.0.1.1/32` or `2001:db8:ff00:42::8329/128`. Use `0.0.0.0/0` to allow any IPv4 addresses and `::/0` to allow any IPv6 addresses. IPv6 CIDRs will be transformed to their canonical form according to [RFC5952](https://datatracker.ietf.org/doc/html/rfc5952#section-4). */
    destination_ips: UpdateFirewallResponseFirewallRulesItemDestinationIpsList;
    /** Network protocol to apply the rule for. */
    protocol: UpdateFirewallResponseFirewallRulesItemProtocol;
    /** Port or port range to apply the rule for. Only applicable for protocols `tcp` and `udp`. A port range can be specified by separating lower and upper bounds with a dash. `1024-5000` will include all ports starting from 1024 up to port 5000. */
    port: string | null;
}
export declare const UpdateFirewallResponseFirewallRulesItem: S.Schema<UpdateFirewallResponseFirewallRulesItem>;
export type UpdateFirewallResponseFirewallRulesList = Array<UpdateFirewallResponseFirewallRulesItem>;
export declare const UpdateFirewallResponseFirewallRulesList: S.Schema<UpdateFirewallResponseFirewallRulesList>;
/** The type of resource to apply. */
export type UpdateFirewallResponseFirewallAppliedToItemType = "server" | "label_selector";
export declare const UpdateFirewallResponseFirewallAppliedToItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type UpdateFirewallResponseFirewallAppliedToItemServer = CreateFirewallRequestApplyToItemServer;
export declare const UpdateFirewallResponseFirewallAppliedToItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
/** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
export type UpdateFirewallResponseFirewallAppliedToItemLabelSelector = CreateFirewallRequestApplyToItemLabelSelector;
export declare const UpdateFirewallResponseFirewallAppliedToItemLabelSelector: S.Schema<CreateFirewallRequestApplyToItemLabelSelector>;
/** Type of resource. */
export type UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType = "server";
export declare const UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType: any;
/** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
export type UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemServer = CreateFirewallRequestApplyToItemServer;
export declare const UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemServer: S.Schema<CreateFirewallRequestApplyToItemServer>;
export interface UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem {
    /** Type of resource. */
    type?: UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
}
export declare const UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem: S.Schema<UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem>;
/** Resources applied to via this [Label Selector](#description/label-selector). */
export type UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesList = Array<UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesItem>;
export declare const UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesList: S.Schema<UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesList>;
export interface UpdateFirewallResponseFirewallAppliedToItem {
    /** The type of resource to apply. */
    type: UpdateFirewallResponseFirewallAppliedToItemType;
    /** [Server](#tag/servers) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `server`, otherwise `null`. */
    server?: CreateFirewallRequestApplyToItemServer;
    /** [Label Selector](#description/label-selector) the [Firewall](#tag/firewalls) is applied to. Only set for `type` `label_selector`, otherwise `null`. */
    label_selector?: CreateFirewallRequestApplyToItemLabelSelector;
    /** Resources applied to via this [Label Selector](#description/label-selector). */
    applied_to_resources?: UpdateFirewallResponseFirewallAppliedToItemAppliedToResourcesList;
}
export declare const UpdateFirewallResponseFirewallAppliedToItem: S.Schema<UpdateFirewallResponseFirewallAppliedToItem>;
export type UpdateFirewallResponseFirewallAppliedToList = Array<UpdateFirewallResponseFirewallAppliedToItem>;
export declare const UpdateFirewallResponseFirewallAppliedToList: S.Schema<UpdateFirewallResponseFirewallAppliedToList>;
export interface UpdateFirewallResponseFirewall {
    /** ID of the [Firewall](#tag/firewalls). */
    id: number;
    /** Name of the [Firewall](#tag/firewalls). Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: UpdateFirewallResponseFirewallLabelsMap;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    rules: UpdateFirewallResponseFirewallRulesList;
    applied_to: UpdateFirewallResponseFirewallAppliedToList;
}
export declare const UpdateFirewallResponseFirewall: S.Schema<UpdateFirewallResponseFirewall>;
export interface UpdateFirewallResponse {
    firewall: UpdateFirewallResponseFirewall;
}
export declare const UpdateFirewallResponse: S.Schema<UpdateFirewallResponse>;
export type CreateFirewallError = HetznerOpError;
/** Create a Firewall Create a [Firewall](#tag/firewalls). #### Operation specific errors */
export declare const createFirewall: API.OperationMethod<CreateFirewallRequest, CreateFirewallResponse, CreateFirewallError, HetznerOpContext>;
export type DeleteFirewallError = HetznerOpError;
/** Delete a Firewall Deletes the [Firewall](#tag/firewalls). #### Operation specific errors */
export declare const deleteFirewall: API.OperationMethod<DeleteFirewallRequest, DeleteFirewallResponse, DeleteFirewallError, HetznerOpContext>;
export type GetFirewallError = HetznerOpError;
/** Get a Firewall Returns a single [Firewall](#tag/firewalls). */
export declare const getFirewall: API.OperationMethod<GetFirewallRequest, GetFirewallResponse, GetFirewallError, HetznerOpContext>;
export type ListFirewallsError = HetznerOpError;
/** List Firewalls Returns all [Firewalls](#tag/firewalls). Use the provided URI parameters to modify the result. */
export declare const listFirewalls: API.PaginatedOperationMethod<ListFirewallsRequest, ListFirewallsResponse, ListFirewallsError, HetznerOpContext, ListFirewallsResponseFirewallsItem>;
export type UpdateFirewallError = HetznerOpError;
/** Update a Firewall Update a [Firewall](#tag/firewalls). In case of a parallel running change on the [Firewall](#tag/firewalls) a `conflict` error will be returned. */
export declare const updateFirewall: API.OperationMethod<UpdateFirewallRequest, UpdateFirewallResponse, UpdateFirewallError, HetznerOpContext>;
//# sourceMappingURL=firewalls.d.ts.map