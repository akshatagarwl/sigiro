import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface AttachVolumeRequest {
    /** ID of the Volume. */
    id: number;
    /** ID of the Server the Volume will be attached to. */
    server: number;
    /** Auto-mount the Volume after attaching it. */
    automount?: boolean;
}
export declare const AttachVolumeRequest: S.Schema<AttachVolumeRequest>;
/** Status of the Action. */
export type AttachVolumeResponseActionStatus = "running" | "success" | "error";
export declare const AttachVolumeResponseActionStatus: any;
export interface AttachVolumeResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AttachVolumeResponseActionResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AttachVolumeResponseActionResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const AttachVolumeResponseActionResourcesList: S.Schema<AttachVolumeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AttachVolumeResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AttachVolumeResponseActionError: S.Schema<AttachVolumeResponseActionError>;
export interface AttachVolumeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AttachVolumeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AttachVolumeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const AttachVolumeResponseAction: S.Schema<AttachVolumeResponseAction>;
export interface AttachVolumeResponse {
    action: AttachVolumeResponseAction;
}
export declare const AttachVolumeResponse: S.Schema<AttachVolumeResponse>;
export interface ChangeVolumeProtectionRequest {
    /** ID of the Volume. */
    id: number;
    /** If true, prevents the Volume from being deleted. */
    delete?: boolean;
}
export declare const ChangeVolumeProtectionRequest: S.Schema<ChangeVolumeProtectionRequest>;
/** Status of the Action. */
export type ChangeVolumeProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeVolumeProtectionResponseActionStatus: any;
export type ChangeVolumeProtectionResponseActionResourcesItem = AttachVolumeResponseActionResourcesItem;
export declare const ChangeVolumeProtectionResponseActionResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeVolumeProtectionResponseActionResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const ChangeVolumeProtectionResponseActionResourcesList: S.Schema<ChangeVolumeProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeVolumeProtectionResponseActionError = AttachVolumeResponseActionError;
export declare const ChangeVolumeProtectionResponseActionError: S.Schema<AttachVolumeResponseActionError>;
export interface ChangeVolumeProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeVolumeProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeVolumeProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const ChangeVolumeProtectionResponseAction: S.Schema<ChangeVolumeProtectionResponseAction>;
export interface ChangeVolumeProtectionResponse {
    action: ChangeVolumeProtectionResponseAction;
}
export declare const ChangeVolumeProtectionResponse: S.Schema<ChangeVolumeProtectionResponse>;
export interface DetachVolumeRequest {
    /** ID of the Volume. */
    id: number;
}
export declare const DetachVolumeRequest: S.Schema<DetachVolumeRequest>;
/** Status of the Action. */
export type DetachVolumeResponseActionStatus = "running" | "success" | "error";
export declare const DetachVolumeResponseActionStatus: any;
export type DetachVolumeResponseActionResourcesItem = AttachVolumeResponseActionResourcesItem;
export declare const DetachVolumeResponseActionResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type DetachVolumeResponseActionResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const DetachVolumeResponseActionResourcesList: S.Schema<DetachVolumeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type DetachVolumeResponseActionError = AttachVolumeResponseActionError;
export declare const DetachVolumeResponseActionError: S.Schema<AttachVolumeResponseActionError>;
export interface DetachVolumeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: DetachVolumeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: DetachVolumeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const DetachVolumeResponseAction: S.Schema<DetachVolumeResponseAction>;
export interface DetachVolumeResponse {
    action: DetachVolumeResponseAction;
}
export declare const DetachVolumeResponse: S.Schema<DetachVolumeResponse>;
export interface GetVolumesActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetVolumesActionRequest: S.Schema<GetVolumesActionRequest>;
/** Status of the Action. */
export type GetVolumesActionResponseActionStatus = "running" | "success" | "error";
export declare const GetVolumesActionResponseActionStatus: any;
export type GetVolumesActionResponseActionResourcesItem = AttachVolumeResponseActionResourcesItem;
export declare const GetVolumesActionResponseActionResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetVolumesActionResponseActionResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const GetVolumesActionResponseActionResourcesList: S.Schema<GetVolumesActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetVolumesActionResponseActionError = AttachVolumeResponseActionError;
export declare const GetVolumesActionResponseActionError: S.Schema<AttachVolumeResponseActionError>;
export interface GetVolumesActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetVolumesActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetVolumesActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const GetVolumesActionResponseAction: S.Schema<GetVolumesActionResponseAction>;
export interface GetVolumesActionResponse {
    action: GetVolumesActionResponseAction;
}
export declare const GetVolumesActionResponse: S.Schema<GetVolumesActionResponse>;
export type ListVolumeActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListVolumeActionsRequestSortItem: any;
export type ListVolumeActionsRequestSortList = Array<ListVolumeActionsRequestSortItem | (string & {})>;
export declare const ListVolumeActionsRequestSortList: S.Schema<ListVolumeActionsRequestSortList>;
/** Status of the Action. */
export type ListVolumeActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListVolumeActionsRequestStatusItem: any;
export type ListVolumeActionsRequestStatusList = Array<ListVolumeActionsRequestStatusItem | (string & {})>;
export declare const ListVolumeActionsRequestStatusList: S.Schema<ListVolumeActionsRequestStatusList>;
export interface ListVolumeActionsRequest {
    /** ID of the Volume. */
    id: number;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListVolumeActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListVolumeActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListVolumeActionsRequest: S.Schema<ListVolumeActionsRequest>;
/** Status of the Action. */
export type ListVolumeActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListVolumeActionsResponseActionsItemStatus: any;
export type ListVolumeActionsResponseActionsItemResourcesItem = AttachVolumeResponseActionResourcesItem;
export declare const ListVolumeActionsResponseActionsItemResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListVolumeActionsResponseActionsItemResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const ListVolumeActionsResponseActionsItemResourcesList: S.Schema<ListVolumeActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListVolumeActionsResponseActionsItemError = AttachVolumeResponseActionError;
export declare const ListVolumeActionsResponseActionsItemError: S.Schema<AttachVolumeResponseActionError>;
export interface ListVolumeActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListVolumeActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListVolumeActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const ListVolumeActionsResponseActionsItem: S.Schema<ListVolumeActionsResponseActionsItem>;
export type ListVolumeActionsResponseActionsList = Array<ListVolumeActionsResponseActionsItem>;
export declare const ListVolumeActionsResponseActionsList: S.Schema<ListVolumeActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListVolumeActionsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListVolumeActionsResponseMetaPagination: S.Schema<ListVolumeActionsResponseMetaPagination>;
export interface ListVolumeActionsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListVolumeActionsResponseMetaPagination;
}
export declare const ListVolumeActionsResponseMeta: S.Schema<ListVolumeActionsResponseMeta>;
export interface ListVolumeActionsResponse {
    actions: ListVolumeActionsResponseActionsList;
    meta: ListVolumeActionsResponseMeta;
}
export declare const ListVolumeActionsResponse: S.Schema<ListVolumeActionsResponse>;
export type ListVolumesActionsRequestIdList = Array<number>;
export declare const ListVolumesActionsRequestIdList: S.Schema<ListVolumesActionsRequestIdList>;
export type ListVolumesActionsRequestSortItem = "id" | "id:asc" | "id:desc" | "command" | "command:asc" | "command:desc" | "status" | "status:asc" | "status:desc" | "started" | "started:asc" | "started:desc" | "finished" | "finished:asc" | "finished:desc";
export declare const ListVolumesActionsRequestSortItem: any;
export type ListVolumesActionsRequestSortList = Array<ListVolumesActionsRequestSortItem | (string & {})>;
export declare const ListVolumesActionsRequestSortList: S.Schema<ListVolumesActionsRequestSortList>;
/** Status of the Action. */
export type ListVolumesActionsRequestStatusItem = "running" | "success" | "error";
export declare const ListVolumesActionsRequestStatusItem: any;
export type ListVolumesActionsRequestStatusList = Array<ListVolumesActionsRequestStatusItem | (string & {})>;
export declare const ListVolumesActionsRequestStatusList: S.Schema<ListVolumesActionsRequestStatusList>;
export interface ListVolumesActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id?: ListVolumesActionsRequestIdList;
    /** Sort actions by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListVolumesActionsRequestSortList;
    /** Filter the actions by status. May be used multiple times. The response will only contain actions matching the specified statuses. */
    status?: ListVolumesActionsRequestStatusList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListVolumesActionsRequest: S.Schema<ListVolumesActionsRequest>;
/** Status of the Action. */
export type ListVolumesActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const ListVolumesActionsResponseActionsItemStatus: any;
export type ListVolumesActionsResponseActionsItemResourcesItem = AttachVolumeResponseActionResourcesItem;
export declare const ListVolumesActionsResponseActionsItemResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ListVolumesActionsResponseActionsItemResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const ListVolumesActionsResponseActionsItemResourcesList: S.Schema<ListVolumesActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ListVolumesActionsResponseActionsItemError = AttachVolumeResponseActionError;
export declare const ListVolumesActionsResponseActionsItemError: S.Schema<AttachVolumeResponseActionError>;
export interface ListVolumesActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ListVolumesActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ListVolumesActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const ListVolumesActionsResponseActionsItem: S.Schema<ListVolumesActionsResponseActionsItem>;
export type ListVolumesActionsResponseActionsList = Array<ListVolumesActionsResponseActionsItem>;
export declare const ListVolumesActionsResponseActionsList: S.Schema<ListVolumesActionsResponseActionsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export type ListVolumesActionsResponseMetaPagination = ListVolumeActionsResponseMetaPagination;
export declare const ListVolumesActionsResponseMetaPagination: S.Schema<ListVolumeActionsResponseMetaPagination>;
export type ListVolumesActionsResponseMeta = ListVolumeActionsResponseMeta;
export declare const ListVolumesActionsResponseMeta: S.Schema<ListVolumeActionsResponseMeta>;
export interface ListVolumesActionsResponse {
    actions: ListVolumesActionsResponseActionsList;
    meta: ListVolumeActionsResponseMeta;
}
export declare const ListVolumesActionsResponse: S.Schema<ListVolumesActionsResponse>;
export interface ResizeVolumeRequest {
    /** ID of the Volume. */
    id: number;
    /** New Volume size in GB (must be greater than current size). */
    size: number;
}
export declare const ResizeVolumeRequest: S.Schema<ResizeVolumeRequest>;
/** Status of the Action. */
export type ResizeVolumeResponseActionStatus = "running" | "success" | "error";
export declare const ResizeVolumeResponseActionStatus: any;
export type ResizeVolumeResponseActionResourcesItem = AttachVolumeResponseActionResourcesItem;
export declare const ResizeVolumeResponseActionResourcesItem: S.Schema<AttachVolumeResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ResizeVolumeResponseActionResourcesList = Array<AttachVolumeResponseActionResourcesItem>;
export declare const ResizeVolumeResponseActionResourcesList: S.Schema<ResizeVolumeResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ResizeVolumeResponseActionError = AttachVolumeResponseActionError;
export declare const ResizeVolumeResponseActionError: S.Schema<AttachVolumeResponseActionError>;
export interface ResizeVolumeResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ResizeVolumeResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ResizeVolumeResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AttachVolumeResponseActionError | null;
}
export declare const ResizeVolumeResponseAction: S.Schema<ResizeVolumeResponseAction>;
export interface ResizeVolumeResponse {
    action: ResizeVolumeResponseAction;
}
export declare const ResizeVolumeResponse: S.Schema<ResizeVolumeResponse>;
export type AttachVolumeError = HetznerOpError;
/** Attach Volume to a Server Attaches a Volume to a Server. Works only if the Server is in the same Location as the Volume. */
export declare const attachVolume: API.OperationMethod<AttachVolumeRequest, AttachVolumeResponse, AttachVolumeError, HetznerOpContext>;
export type ChangeVolumeProtectionError = HetznerOpError;
/** Change Volume Protection Changes the protection configuration of a Volume. */
export declare const changeVolumeProtection: API.OperationMethod<ChangeVolumeProtectionRequest, ChangeVolumeProtectionResponse, ChangeVolumeProtectionError, HetznerOpContext>;
export type DetachVolumeError = HetznerOpError;
/** Detach Volume Detaches a Volume from the Server it’s attached to. You may attach it to a Server again at a later time. */
export declare const detachVolume: API.OperationMethod<DetachVolumeRequest, DetachVolumeResponse, DetachVolumeError, HetznerOpContext>;
export type GetVolumesActionError = HetznerOpError;
/** Get an Action Returns a specific Action object. */
export declare const getVolumesAction: API.OperationMethod<GetVolumesActionRequest, GetVolumesActionResponse, GetVolumesActionError, HetznerOpContext>;
export type ListVolumeActionsError = HetznerOpError;
/** List Actions for a Volume Returns all Action objects for a Volume. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter. */
export declare const listVolumeActions: API.PaginatedOperationMethod<ListVolumeActionsRequest, ListVolumeActionsResponse, ListVolumeActionsError, HetznerOpContext, ListVolumeActionsResponseActionsItem>;
export type ListVolumesActionsError = HetznerOpError;
/** List Actions Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` and `id` parameter. */
export declare const listVolumesActions: API.PaginatedOperationMethod<ListVolumesActionsRequest, ListVolumesActionsResponse, ListVolumesActionsError, HetznerOpContext, ListVolumesActionsResponseActionsItem>;
export type ResizeVolumeError = HetznerOpError;
/** Resize Volume Changes the size of a Volume. Note that downsizing a Volume is not possible. */
export declare const resizeVolume: API.OperationMethod<ResizeVolumeRequest, ResizeVolumeResponse, ResizeVolumeError, HetznerOpContext>;
//# sourceMappingURL=volume_actions.d.ts.map