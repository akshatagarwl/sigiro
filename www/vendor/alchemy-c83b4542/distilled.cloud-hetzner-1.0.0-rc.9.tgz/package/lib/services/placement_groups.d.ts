import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreatePlacementGroupRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreatePlacementGroupRequestLabelsMap: S.Schema<CreatePlacementGroupRequestLabelsMap>;
/** Define the Placement Group Type. */
export type CreatePlacementGroupRequestType = "spread";
export declare const CreatePlacementGroupRequestType: any;
export interface CreatePlacementGroupRequest {
    /** Name of the Placement Group. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels?: CreatePlacementGroupRequestLabelsMap;
    /** Define the Placement Group Type. */
    type: CreatePlacementGroupRequestType | (string & {});
}
export declare const CreatePlacementGroupRequest: S.Schema<CreatePlacementGroupRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type CreatePlacementGroupResponsePlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const CreatePlacementGroupResponsePlacementGroupLabelsMap: S.Schema<CreatePlacementGroupResponsePlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type CreatePlacementGroupResponsePlacementGroupType = "spread";
export declare const CreatePlacementGroupResponsePlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type CreatePlacementGroupResponsePlacementGroupServersList = Array<number>;
export declare const CreatePlacementGroupResponsePlacementGroupServersList: S.Schema<CreatePlacementGroupResponsePlacementGroupServersList>;
export interface CreatePlacementGroupResponsePlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: CreatePlacementGroupResponsePlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: CreatePlacementGroupResponsePlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: CreatePlacementGroupResponsePlacementGroupServersList;
}
export declare const CreatePlacementGroupResponsePlacementGroup: S.Schema<CreatePlacementGroupResponsePlacementGroup>;
/** Status of the Action. */
export type CreatePlacementGroupResponseActionStatus = "running" | "success" | "error";
export declare const CreatePlacementGroupResponseActionStatus: any;
export interface CreatePlacementGroupResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const CreatePlacementGroupResponseActionResourcesItem: S.Schema<CreatePlacementGroupResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type CreatePlacementGroupResponseActionResourcesList = Array<CreatePlacementGroupResponseActionResourcesItem>;
export declare const CreatePlacementGroupResponseActionResourcesList: S.Schema<CreatePlacementGroupResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface CreatePlacementGroupResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const CreatePlacementGroupResponseActionError: S.Schema<CreatePlacementGroupResponseActionError>;
export interface CreatePlacementGroupResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: CreatePlacementGroupResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: CreatePlacementGroupResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: CreatePlacementGroupResponseActionError | null;
}
export declare const CreatePlacementGroupResponseAction: S.Schema<CreatePlacementGroupResponseAction>;
export interface CreatePlacementGroupResponse {
    placement_group: CreatePlacementGroupResponsePlacementGroup;
    action?: CreatePlacementGroupResponseAction | null;
}
export declare const CreatePlacementGroupResponse: S.Schema<CreatePlacementGroupResponse>;
export interface DeletePlacementGroupRequest {
    /** ID of the Placement Group. */
    id: number;
}
export declare const DeletePlacementGroupRequest: S.Schema<DeletePlacementGroupRequest>;
export interface DeletePlacementGroupResponse {
}
export declare const DeletePlacementGroupResponse: S.Schema<DeletePlacementGroupResponse>;
export interface GetPlacementGroupRequest {
    /** ID of the Placement Group. */
    id: number;
}
export declare const GetPlacementGroupRequest: S.Schema<GetPlacementGroupRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type GetPlacementGroupResponsePlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const GetPlacementGroupResponsePlacementGroupLabelsMap: S.Schema<GetPlacementGroupResponsePlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type GetPlacementGroupResponsePlacementGroupType = "spread";
export declare const GetPlacementGroupResponsePlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type GetPlacementGroupResponsePlacementGroupServersList = Array<number>;
export declare const GetPlacementGroupResponsePlacementGroupServersList: S.Schema<GetPlacementGroupResponsePlacementGroupServersList>;
export interface GetPlacementGroupResponsePlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: GetPlacementGroupResponsePlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: GetPlacementGroupResponsePlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: GetPlacementGroupResponsePlacementGroupServersList;
}
export declare const GetPlacementGroupResponsePlacementGroup: S.Schema<GetPlacementGroupResponsePlacementGroup>;
export interface GetPlacementGroupResponse {
    placement_group: GetPlacementGroupResponsePlacementGroup;
}
export declare const GetPlacementGroupResponse: S.Schema<GetPlacementGroupResponse>;
export type ListPlacementGroupsRequestSortItem = "id" | "id:asc" | "id:desc" | "name" | "name:asc" | "name:desc" | "created" | "created:asc" | "created:desc";
export declare const ListPlacementGroupsRequestSortItem: any;
export type ListPlacementGroupsRequestSortList = Array<ListPlacementGroupsRequestSortItem | (string & {})>;
export declare const ListPlacementGroupsRequestSortList: S.Schema<ListPlacementGroupsRequestSortList>;
/** Type of Placement Group. */
export type ListPlacementGroupsRequestTypeItem = "spread";
export declare const ListPlacementGroupsRequestTypeItem: any;
export type ListPlacementGroupsRequestTypeList = Array<ListPlacementGroupsRequestTypeItem | (string & {})>;
export declare const ListPlacementGroupsRequestTypeList: S.Schema<ListPlacementGroupsRequestTypeList>;
export interface ListPlacementGroupsRequest {
    /** Sort resources by field and direction. May be used multiple times. For more information, see "[Sorting](#description/sorting)". */
    sort?: ListPlacementGroupsRequestSortList;
    /** Filter resources by their name. The response will only contain the resources matching exactly the specified name. */
    name?: string;
    /** Filter resources by labels. The response will only contain resources matching the label selector. For more information, see "[Label Selector](#description/label-selector)". */
    label_selector?: string;
    /** Filter resources by type. May be used multiple times. The response will only contain the resources with the specified type. */
    type?: ListPlacementGroupsRequestTypeList;
    /** Page number to return. For more information, see "[Pagination](#description/pagination)". */
    page?: number;
    /** Maximum number of entries returned per page. For more information, see "[Pagination](#description/pagination)". */
    per_page?: number;
}
export declare const ListPlacementGroupsRequest: S.Schema<ListPlacementGroupsRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type ListPlacementGroupsResponsePlacementGroupsItemLabelsMap = {
    [key: string]: string | undefined;
};
export declare const ListPlacementGroupsResponsePlacementGroupsItemLabelsMap: S.Schema<ListPlacementGroupsResponsePlacementGroupsItemLabelsMap>;
/** Type of Placement Group. */
export type ListPlacementGroupsResponsePlacementGroupsItemType = "spread";
export declare const ListPlacementGroupsResponsePlacementGroupsItemType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type ListPlacementGroupsResponsePlacementGroupsItemServersList = Array<number>;
export declare const ListPlacementGroupsResponsePlacementGroupsItemServersList: S.Schema<ListPlacementGroupsResponsePlacementGroupsItemServersList>;
export interface ListPlacementGroupsResponsePlacementGroupsItem {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: ListPlacementGroupsResponsePlacementGroupsItemLabelsMap;
    /** Type of Placement Group. */
    type: ListPlacementGroupsResponsePlacementGroupsItemType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: ListPlacementGroupsResponsePlacementGroupsItemServersList;
}
export declare const ListPlacementGroupsResponsePlacementGroupsItem: S.Schema<ListPlacementGroupsResponsePlacementGroupsItem>;
export type ListPlacementGroupsResponsePlacementGroupsList = Array<ListPlacementGroupsResponsePlacementGroupsItem>;
export declare const ListPlacementGroupsResponsePlacementGroupsList: S.Schema<ListPlacementGroupsResponsePlacementGroupsList>;
/** See "[Pagination](#description/pagination)" for more information. */
export interface ListPlacementGroupsResponseMetaPagination {
    /** Current page number. */
    page: number;
    /** Maximum number of entries returned per page. */
    per_page: number;
    /** Page number of the previous page. Can be null if the current page is the first one. */
    previous_page: number | null;
    /** Page number of the next page. Can be null if the current page is the last one. */
    next_page: number | null;
    /** Page number of the last page available. Can be null if the current page is the last one. */
    last_page: number | null;
    /** Total number of entries that exist for this query. Can be null if unknown. */
    total_entries: number | null;
}
export declare const ListPlacementGroupsResponseMetaPagination: S.Schema<ListPlacementGroupsResponseMetaPagination>;
export interface ListPlacementGroupsResponseMeta {
    /** See "[Pagination](#description/pagination)" for more information. */
    pagination: ListPlacementGroupsResponseMetaPagination;
}
export declare const ListPlacementGroupsResponseMeta: S.Schema<ListPlacementGroupsResponseMeta>;
export interface ListPlacementGroupsResponse {
    placement_groups: ListPlacementGroupsResponsePlacementGroupsList;
    meta: ListPlacementGroupsResponseMeta;
}
export declare const ListPlacementGroupsResponse: S.Schema<ListPlacementGroupsResponse>;
/** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
export type UpdatePlacementGroupRequestLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdatePlacementGroupRequestLabelsMap: S.Schema<UpdatePlacementGroupRequestLabelsMap>;
export interface UpdatePlacementGroupRequest {
    /** ID of the Placement Group. */
    id: number;
    /** New Placement Group name. */
    name?: string;
    /** User-defined labels (`key/value` pairs) for the Resource. Note that the set of [Labels](#description/labels) provided in the request will overwrite the existing one. For more information, see "[Labels](#description/labels)". */
    labels?: UpdatePlacementGroupRequestLabelsMap;
}
export declare const UpdatePlacementGroupRequest: S.Schema<UpdatePlacementGroupRequest>;
/** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
export type UpdatePlacementGroupResponsePlacementGroupLabelsMap = {
    [key: string]: string | undefined;
};
export declare const UpdatePlacementGroupResponsePlacementGroupLabelsMap: S.Schema<UpdatePlacementGroupResponsePlacementGroupLabelsMap>;
/** Type of Placement Group. */
export type UpdatePlacementGroupResponsePlacementGroupType = "spread";
export declare const UpdatePlacementGroupResponsePlacementGroupType: any;
/** Array of IDs of Servers that are part of this Placement Group. */
export type UpdatePlacementGroupResponsePlacementGroupServersList = Array<number>;
export declare const UpdatePlacementGroupResponsePlacementGroupServersList: S.Schema<UpdatePlacementGroupResponsePlacementGroupServersList>;
export interface UpdatePlacementGroupResponsePlacementGroup {
    /** ID of the [Placement Group](#tag/placement-groups). */
    id: number;
    /** Name of the Resource. Must be unique per Project. */
    name: string;
    /** User-defined labels (`key/value` pairs) for the Resource. For more information, see "[Labels](#description/labels)". */
    labels: UpdatePlacementGroupResponsePlacementGroupLabelsMap;
    /** Type of Placement Group. */
    type: UpdatePlacementGroupResponsePlacementGroupType;
    /** Point in time when the Resource was created (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    created: string;
    /** Array of IDs of Servers that are part of this Placement Group. */
    servers: UpdatePlacementGroupResponsePlacementGroupServersList;
}
export declare const UpdatePlacementGroupResponsePlacementGroup: S.Schema<UpdatePlacementGroupResponsePlacementGroup>;
export interface UpdatePlacementGroupResponse {
    placement_group: UpdatePlacementGroupResponsePlacementGroup;
}
export declare const UpdatePlacementGroupResponse: S.Schema<UpdatePlacementGroupResponse>;
export type CreatePlacementGroupError = HetznerOpError;
/** Create a PlacementGroup Creates a new Placement Group. */
export declare const createPlacementGroup: API.OperationMethod<CreatePlacementGroupRequest, CreatePlacementGroupResponse, CreatePlacementGroupError, HetznerOpContext>;
export type DeletePlacementGroupError = HetznerOpError;
/** Delete a PlacementGroup Deletes a Placement Group. */
export declare const deletePlacementGroup: API.OperationMethod<DeletePlacementGroupRequest, DeletePlacementGroupResponse, DeletePlacementGroupError, HetznerOpContext>;
export type GetPlacementGroupError = HetznerOpError;
/** Get a PlacementGroup Gets a specific Placement Group object. */
export declare const getPlacementGroup: API.OperationMethod<GetPlacementGroupRequest, GetPlacementGroupResponse, GetPlacementGroupError, HetznerOpContext>;
export type ListPlacementGroupsError = HetznerOpError;
/** List Placement Groups Returns all Placement Group objects. */
export declare const listPlacementGroups: API.PaginatedOperationMethod<ListPlacementGroupsRequest, ListPlacementGroupsResponse, ListPlacementGroupsError, HetznerOpContext, ListPlacementGroupsResponsePlacementGroupsItem>;
export type UpdatePlacementGroupError = HetznerOpError;
/** Update a PlacementGroup Updates the Placement Group properties. Note: if the Placement Group object changes during the request, the response will be a “conflict” error. */
export declare const updatePlacementGroup: API.OperationMethod<UpdatePlacementGroupRequest, UpdatePlacementGroupResponse, UpdatePlacementGroupError, HetznerOpContext>;
//# sourceMappingURL=placement_groups.d.ts.map