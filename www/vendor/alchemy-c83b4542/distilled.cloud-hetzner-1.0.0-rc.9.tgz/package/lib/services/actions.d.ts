import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
export interface GetActionRequest {
    /** ID of the Action. */
    id: number;
}
export declare const GetActionRequest: S.Schema<GetActionRequest>;
/** Status of the Action. */
export type GetActionResponseActionStatus = "running" | "success" | "error";
export declare const GetActionResponseActionStatus: any;
export interface GetActionResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const GetActionResponseActionResourcesItem: S.Schema<GetActionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetActionResponseActionResourcesList = Array<GetActionResponseActionResourcesItem>;
export declare const GetActionResponseActionResourcesList: S.Schema<GetActionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface GetActionResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const GetActionResponseActionError: S.Schema<GetActionResponseActionError>;
export interface GetActionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetActionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetActionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: GetActionResponseActionError | null;
}
export declare const GetActionResponseAction: S.Schema<GetActionResponseAction>;
export interface GetActionResponse {
    action: GetActionResponseAction;
}
export declare const GetActionResponse: S.Schema<GetActionResponse>;
export type GetActionsRequestIdList = Array<number>;
export declare const GetActionsRequestIdList: S.Schema<GetActionsRequestIdList>;
export interface GetActionsRequest {
    /** Filter the actions by ID. May be used multiple times. The response will only contain actions matching the specified IDs. */
    id: GetActionsRequestIdList;
}
export declare const GetActionsRequest: S.Schema<GetActionsRequest>;
/** Status of the Action. */
export type GetActionsResponseActionsItemStatus = "running" | "success" | "error";
export declare const GetActionsResponseActionsItemStatus: any;
export type GetActionsResponseActionsItemResourcesItem = GetActionResponseActionResourcesItem;
export declare const GetActionsResponseActionsItemResourcesItem: S.Schema<GetActionResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type GetActionsResponseActionsItemResourcesList = Array<GetActionResponseActionResourcesItem>;
export declare const GetActionsResponseActionsItemResourcesList: S.Schema<GetActionsResponseActionsItemResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type GetActionsResponseActionsItemError = GetActionResponseActionError;
export declare const GetActionsResponseActionsItemError: S.Schema<GetActionResponseActionError>;
export interface GetActionsResponseActionsItem {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: GetActionsResponseActionsItemStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: GetActionsResponseActionsItemResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: GetActionResponseActionError | null;
}
export declare const GetActionsResponseActionsItem: S.Schema<GetActionsResponseActionsItem>;
export type GetActionsResponseActionsList = Array<GetActionsResponseActionsItem>;
export declare const GetActionsResponseActionsList: S.Schema<GetActionsResponseActionsList>;
export interface GetActionsResponse {
    actions: GetActionsResponseActionsList;
}
export declare const GetActionsResponse: S.Schema<GetActionsResponse>;
export type GetActionError = HetznerOpError;
/** Get an Action Returns a specific Action object. */
export declare const getAction: API.OperationMethod<GetActionRequest, GetActionResponse, GetActionError, HetznerOpContext>;
export type GetActionsError = HetznerOpError;
/** Get multiple Actions Returns multiple Action objects specified by the `id` parameter. **Note**: This endpoint previously allowed listing all actions in the project. This functionality was deprecated in July 2023 and removed on 30 January 2025. - Announcement: https://docs.hetzner.cloud/changelog#2023-07-20-actions-list-endpoint-is-deprecated - Removal: https://docs.hetzner.cloud/changelog#2025-01-30-listing-arbitrary-actions-in-the-actions-list-endpoint-is-removed */
export declare const getActions: API.OperationMethod<GetActionsRequest, GetActionsResponse, GetActionsError, HetznerOpContext>;
//# sourceMappingURL=actions.d.ts.map