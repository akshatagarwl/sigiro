import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type HetznerOpError, type HetznerOpContext } from "../protocol.ts";
export type { HetznerOpError, HetznerOpContext };
/** Type of the [RRSet](#tag/zone-rrsets). */
export type AddZoneRrsetRecordsRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const AddZoneRrsetRecordsRequestRrType: any;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export interface AddZoneRrsetRecordsRequestRecordsItem {
    /** Value of the record. For details about accepted values, see the [DNS record types documentation](https://docs.hetzner.com/networking/dns/record-types/overview/). */
    value: string;
    /** Comment of the record. */
    comment?: string;
}
export declare const AddZoneRrsetRecordsRequestRecordsItem: S.Schema<AddZoneRrsetRecordsRequestRecordsItem>;
/** Records to add to the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
export type AddZoneRrsetRecordsRequestRecordsList = Array<AddZoneRrsetRecordsRequestRecordsItem>;
export declare const AddZoneRrsetRecordsRequestRecordsList: S.Schema<AddZoneRrsetRecordsRequestRecordsList>;
export interface AddZoneRrsetRecordsRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: AddZoneRrsetRecordsRequestRrType | (string & {});
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). If not set, the [Zone's](#tag/zones) Default TTL is used. If set, and the RRSet being updated already has a TTL, the values must be the same. */
    ttl?: number | null;
    /** Records to add to the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
    records: AddZoneRrsetRecordsRequestRecordsList;
}
export declare const AddZoneRrsetRecordsRequest: S.Schema<AddZoneRrsetRecordsRequest>;
/** Status of the Action. */
export type AddZoneRrsetRecordsResponseActionStatus = "running" | "success" | "error";
export declare const AddZoneRrsetRecordsResponseActionStatus: any;
export interface AddZoneRrsetRecordsResponseActionResourcesItem {
    /** ID of the Resource. */
    id: number;
    /** Type of the Resource. */
    type: string;
}
export declare const AddZoneRrsetRecordsResponseActionResourcesItem: S.Schema<AddZoneRrsetRecordsResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type AddZoneRrsetRecordsResponseActionResourcesList = Array<AddZoneRrsetRecordsResponseActionResourcesItem>;
export declare const AddZoneRrsetRecordsResponseActionResourcesList: S.Schema<AddZoneRrsetRecordsResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export interface AddZoneRrsetRecordsResponseActionError {
    /** Fixed error code for machines. */
    code: string;
    /** Error message for humans. */
    message: string;
}
export declare const AddZoneRrsetRecordsResponseActionError: S.Schema<AddZoneRrsetRecordsResponseActionError>;
export interface AddZoneRrsetRecordsResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: AddZoneRrsetRecordsResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: AddZoneRrsetRecordsResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddZoneRrsetRecordsResponseActionError | null;
}
export declare const AddZoneRrsetRecordsResponseAction: S.Schema<AddZoneRrsetRecordsResponseAction>;
export interface AddZoneRrsetRecordsResponse {
    action: AddZoneRrsetRecordsResponseAction;
}
export declare const AddZoneRrsetRecordsResponse: S.Schema<AddZoneRrsetRecordsResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type ChangeZoneRrsetProtectionRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const ChangeZoneRrsetProtectionRequestRrType: any;
export interface ChangeZoneRrsetProtectionRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: ChangeZoneRrsetProtectionRequestRrType | (string & {});
    /** Prevent the Resource from being changed. */
    change: boolean;
}
export declare const ChangeZoneRrsetProtectionRequest: S.Schema<ChangeZoneRrsetProtectionRequest>;
/** Status of the Action. */
export type ChangeZoneRrsetProtectionResponseActionStatus = "running" | "success" | "error";
export declare const ChangeZoneRrsetProtectionResponseActionStatus: any;
export type ChangeZoneRrsetProtectionResponseActionResourcesItem = AddZoneRrsetRecordsResponseActionResourcesItem;
export declare const ChangeZoneRrsetProtectionResponseActionResourcesItem: S.Schema<AddZoneRrsetRecordsResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeZoneRrsetProtectionResponseActionResourcesList = Array<AddZoneRrsetRecordsResponseActionResourcesItem>;
export declare const ChangeZoneRrsetProtectionResponseActionResourcesList: S.Schema<ChangeZoneRrsetProtectionResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeZoneRrsetProtectionResponseActionError = AddZoneRrsetRecordsResponseActionError;
export declare const ChangeZoneRrsetProtectionResponseActionError: S.Schema<AddZoneRrsetRecordsResponseActionError>;
export interface ChangeZoneRrsetProtectionResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeZoneRrsetProtectionResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeZoneRrsetProtectionResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddZoneRrsetRecordsResponseActionError | null;
}
export declare const ChangeZoneRrsetProtectionResponseAction: S.Schema<ChangeZoneRrsetProtectionResponseAction>;
export interface ChangeZoneRrsetProtectionResponse {
    action: ChangeZoneRrsetProtectionResponseAction;
}
export declare const ChangeZoneRrsetProtectionResponse: S.Schema<ChangeZoneRrsetProtectionResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type ChangeZoneRrsetTtlRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const ChangeZoneRrsetTtlRequestRrType: any;
export interface ChangeZoneRrsetTtlRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: ChangeZoneRrsetTtlRequestRrType | (string & {});
    /** Time To Live (TTL) of the [RRSet](#tag/zone-rrsets). Must be in between 60s and 2147483647s. If not set, the [Zone's](#tag/zones) Default TTL is used. */
    ttl: number | null;
}
export declare const ChangeZoneRrsetTtlRequest: S.Schema<ChangeZoneRrsetTtlRequest>;
/** Status of the Action. */
export type ChangeZoneRrsetTtlResponseActionStatus = "running" | "success" | "error";
export declare const ChangeZoneRrsetTtlResponseActionStatus: any;
export type ChangeZoneRrsetTtlResponseActionResourcesItem = AddZoneRrsetRecordsResponseActionResourcesItem;
export declare const ChangeZoneRrsetTtlResponseActionResourcesItem: S.Schema<AddZoneRrsetRecordsResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type ChangeZoneRrsetTtlResponseActionResourcesList = Array<AddZoneRrsetRecordsResponseActionResourcesItem>;
export declare const ChangeZoneRrsetTtlResponseActionResourcesList: S.Schema<ChangeZoneRrsetTtlResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type ChangeZoneRrsetTtlResponseActionError = AddZoneRrsetRecordsResponseActionError;
export declare const ChangeZoneRrsetTtlResponseActionError: S.Schema<AddZoneRrsetRecordsResponseActionError>;
export interface ChangeZoneRrsetTtlResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: ChangeZoneRrsetTtlResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: ChangeZoneRrsetTtlResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddZoneRrsetRecordsResponseActionError | null;
}
export declare const ChangeZoneRrsetTtlResponseAction: S.Schema<ChangeZoneRrsetTtlResponseAction>;
export interface ChangeZoneRrsetTtlResponse {
    action: ChangeZoneRrsetTtlResponseAction;
}
export declare const ChangeZoneRrsetTtlResponse: S.Schema<ChangeZoneRrsetTtlResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type RemoveZoneRrsetRecordsRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const RemoveZoneRrsetRecordsRequestRrType: any;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export type RemoveZoneRrsetRecordsRequestRecordsItem = AddZoneRrsetRecordsRequestRecordsItem;
export declare const RemoveZoneRrsetRecordsRequestRecordsItem: S.Schema<AddZoneRrsetRecordsRequestRecordsItem>;
/** Records to remove from the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
export type RemoveZoneRrsetRecordsRequestRecordsList = Array<AddZoneRrsetRecordsRequestRecordsItem>;
export declare const RemoveZoneRrsetRecordsRequestRecordsList: S.Schema<RemoveZoneRrsetRecordsRequestRecordsList>;
export interface RemoveZoneRrsetRecordsRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: RemoveZoneRrsetRecordsRequestRrType | (string & {});
    /** Records to remove from the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
    records: RemoveZoneRrsetRecordsRequestRecordsList;
}
export declare const RemoveZoneRrsetRecordsRequest: S.Schema<RemoveZoneRrsetRecordsRequest>;
/** Status of the Action. */
export type RemoveZoneRrsetRecordsResponseActionStatus = "running" | "success" | "error";
export declare const RemoveZoneRrsetRecordsResponseActionStatus: any;
export type RemoveZoneRrsetRecordsResponseActionResourcesItem = AddZoneRrsetRecordsResponseActionResourcesItem;
export declare const RemoveZoneRrsetRecordsResponseActionResourcesItem: S.Schema<AddZoneRrsetRecordsResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type RemoveZoneRrsetRecordsResponseActionResourcesList = Array<AddZoneRrsetRecordsResponseActionResourcesItem>;
export declare const RemoveZoneRrsetRecordsResponseActionResourcesList: S.Schema<RemoveZoneRrsetRecordsResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type RemoveZoneRrsetRecordsResponseActionError = AddZoneRrsetRecordsResponseActionError;
export declare const RemoveZoneRrsetRecordsResponseActionError: S.Schema<AddZoneRrsetRecordsResponseActionError>;
export interface RemoveZoneRrsetRecordsResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: RemoveZoneRrsetRecordsResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: RemoveZoneRrsetRecordsResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddZoneRrsetRecordsResponseActionError | null;
}
export declare const RemoveZoneRrsetRecordsResponseAction: S.Schema<RemoveZoneRrsetRecordsResponseAction>;
export interface RemoveZoneRrsetRecordsResponse {
    action: RemoveZoneRrsetRecordsResponseAction;
}
export declare const RemoveZoneRrsetRecordsResponse: S.Schema<RemoveZoneRrsetRecordsResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type SetZoneRrsetRecordsRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const SetZoneRrsetRecordsRequestRrType: any;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export type SetZoneRrsetRecordsRequestRecordsItem = AddZoneRrsetRecordsRequestRecordsItem;
export declare const SetZoneRrsetRecordsRequestRecordsItem: S.Schema<AddZoneRrsetRecordsRequestRecordsItem>;
/** Records to set in the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
export type SetZoneRrsetRecordsRequestRecordsList = Array<AddZoneRrsetRecordsRequestRecordsItem>;
export declare const SetZoneRrsetRecordsRequestRecordsList: S.Schema<SetZoneRrsetRecordsRequestRecordsList>;
export interface SetZoneRrsetRecordsRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: SetZoneRrsetRecordsRequestRrType | (string & {});
    /** Records to set in the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
    records: SetZoneRrsetRecordsRequestRecordsList;
}
export declare const SetZoneRrsetRecordsRequest: S.Schema<SetZoneRrsetRecordsRequest>;
/** Status of the Action. */
export type SetZoneRrsetRecordsResponseActionStatus = "running" | "success" | "error";
export declare const SetZoneRrsetRecordsResponseActionStatus: any;
export type SetZoneRrsetRecordsResponseActionResourcesItem = AddZoneRrsetRecordsResponseActionResourcesItem;
export declare const SetZoneRrsetRecordsResponseActionResourcesItem: S.Schema<AddZoneRrsetRecordsResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type SetZoneRrsetRecordsResponseActionResourcesList = Array<AddZoneRrsetRecordsResponseActionResourcesItem>;
export declare const SetZoneRrsetRecordsResponseActionResourcesList: S.Schema<SetZoneRrsetRecordsResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type SetZoneRrsetRecordsResponseActionError = AddZoneRrsetRecordsResponseActionError;
export declare const SetZoneRrsetRecordsResponseActionError: S.Schema<AddZoneRrsetRecordsResponseActionError>;
export interface SetZoneRrsetRecordsResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: SetZoneRrsetRecordsResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: SetZoneRrsetRecordsResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddZoneRrsetRecordsResponseActionError | null;
}
export declare const SetZoneRrsetRecordsResponseAction: S.Schema<SetZoneRrsetRecordsResponseAction>;
export interface SetZoneRrsetRecordsResponse {
    action: SetZoneRrsetRecordsResponseAction;
}
export declare const SetZoneRrsetRecordsResponse: S.Schema<SetZoneRrsetRecordsResponse>;
/** Type of the [RRSet](#tag/zone-rrsets). */
export type UpdateZoneRrsetRecordsRequestRrType = "A" | "AAAA" | "CAA" | "CNAME" | "DS" | "HINFO" | "HTTPS" | "MX" | "NS" | "PTR" | "RP" | "SOA" | "SRV" | "SVCB" | "TLSA" | "TXT";
export declare const UpdateZoneRrsetRecordsRequestRrType: any;
/** Record of a [RRSet](#tag/zone-rrsets). The `value` is used to identify the record in an [RRSet](#tag/zone-rrsets). */
export interface UpdateZoneRrsetRecordsRequestRecordsItem {
    /** Value of the record to update. */
    value: string;
    /** New comment for the record. */
    comment: string;
}
export declare const UpdateZoneRrsetRecordsRequestRecordsItem: S.Schema<UpdateZoneRrsetRecordsRequestRecordsItem>;
/** Records to update in the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
export type UpdateZoneRrsetRecordsRequestRecordsList = Array<UpdateZoneRrsetRecordsRequestRecordsItem>;
export declare const UpdateZoneRrsetRecordsRequestRecordsList: S.Schema<UpdateZoneRrsetRecordsRequestRecordsList>;
export interface UpdateZoneRrsetRecordsRequest {
    /** ID or Name of the Zone. */
    id_or_name: string;
    rr_name: string;
    rr_type: UpdateZoneRrsetRecordsRequestRrType | (string & {});
    /** Records to update in the [RRSet](#tag/zone-rrsets). Must not be empty and must only contain distinct record values. */
    records: UpdateZoneRrsetRecordsRequestRecordsList;
}
export declare const UpdateZoneRrsetRecordsRequest: S.Schema<UpdateZoneRrsetRecordsRequest>;
/** Status of the Action. */
export type UpdateZoneRrsetRecordsResponseActionStatus = "running" | "success" | "error";
export declare const UpdateZoneRrsetRecordsResponseActionStatus: any;
export type UpdateZoneRrsetRecordsResponseActionResourcesItem = AddZoneRrsetRecordsResponseActionResourcesItem;
export declare const UpdateZoneRrsetRecordsResponseActionResourcesItem: S.Schema<AddZoneRrsetRecordsResponseActionResourcesItem>;
/** Resources the Action relates to. */
export type UpdateZoneRrsetRecordsResponseActionResourcesList = Array<AddZoneRrsetRecordsResponseActionResourcesItem>;
export declare const UpdateZoneRrsetRecordsResponseActionResourcesList: S.Schema<UpdateZoneRrsetRecordsResponseActionResourcesList>;
/** Error message for the Action if an error occurred, otherwise null. */
export type UpdateZoneRrsetRecordsResponseActionError = AddZoneRrsetRecordsResponseActionError;
export declare const UpdateZoneRrsetRecordsResponseActionError: S.Schema<AddZoneRrsetRecordsResponseActionError>;
export interface UpdateZoneRrsetRecordsResponseAction {
    /** ID of the [Action](#description/actions). */
    id: number;
    /** Command executed in the Action. */
    command: string;
    /** Status of the Action. */
    status: UpdateZoneRrsetRecordsResponseActionStatus;
    /** Point in time when the Action was started (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). */
    started: string;
    /** Point in time when the Action was finished (in [RFC3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) format). Only set if the Action is finished otherwise null. */
    finished: string | null;
    /** Progress of the Action in percent. */
    progress: number;
    /** Resources the Action relates to. */
    resources: UpdateZoneRrsetRecordsResponseActionResourcesList;
    /** Error message for the Action if an error occurred, otherwise null. */
    error: AddZoneRrsetRecordsResponseActionError | null;
}
export declare const UpdateZoneRrsetRecordsResponseAction: S.Schema<UpdateZoneRrsetRecordsResponseAction>;
export interface UpdateZoneRrsetRecordsResponse {
    action: UpdateZoneRrsetRecordsResponseAction;
}
export declare const UpdateZoneRrsetRecordsResponse: S.Schema<UpdateZoneRrsetRecordsResponse>;
export type AddZoneRrsetRecordsError = HetznerOpError;
/** Add Records to an RRSet Adds resource records (RRs) to an [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). For convenience, the [RRSet](#tag/zone-rrsets) will be automatically created if it doesn't exist. Otherwise, the new records are appended to the existing [RRSet](#tag/zone-rrsets). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const addZoneRrsetRecords: API.OperationMethod<AddZoneRrsetRecordsRequest, AddZoneRrsetRecordsResponse, AddZoneRrsetRecordsError, HetznerOpContext>;
export type ChangeZoneRrsetProtectionError = HetznerOpError;
/** Change an RRSet's Protection Changes the protection of an [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const changeZoneRrsetProtection: API.OperationMethod<ChangeZoneRrsetProtectionRequest, ChangeZoneRrsetProtectionResponse, ChangeZoneRrsetProtectionError, HetznerOpContext>;
export type ChangeZoneRrsetTtlError = HetznerOpError;
/** Change an RRSet's TTL Changes the Time To Live (TTL) of an [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const changeZoneRrsetTtl: API.OperationMethod<ChangeZoneRrsetTtlRequest, ChangeZoneRrsetTtlResponse, ChangeZoneRrsetTtlError, HetznerOpContext>;
export type RemoveZoneRrsetRecordsError = HetznerOpError;
/** Remove Records from an RRSet Removes resource records (RRs) from an existing [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). For convenience, the [RRSet](#tag/zone-rrsets) will be automatically deleted if it doesn't contain any RRs afterwards. Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const removeZoneRrsetRecords: API.OperationMethod<RemoveZoneRrsetRecordsRequest, RemoveZoneRrsetRecordsResponse, RemoveZoneRrsetRecordsError, HetznerOpContext>;
export type SetZoneRrsetRecordsError = HetznerOpError;
/** Set Records of an RRSet Overwrites the resource records (RRs) of an existing [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const setZoneRrsetRecords: API.OperationMethod<SetZoneRrsetRecordsRequest, SetZoneRrsetRecordsResponse, SetZoneRrsetRecordsError, HetznerOpContext>;
export type UpdateZoneRrsetRecordsError = HetznerOpError;
/** Update Records of an RRSet Updates resource records' (RRs) comments of an existing [RRSet](#tag/zone-rrsets) in the [Zone](#tag/zones). Only applicable for [Zones](#tag/zones) in primary mode. #### Operation specific errors */
export declare const updateZoneRrsetRecords: API.OperationMethod<UpdateZoneRrsetRecordsRequest, UpdateZoneRrsetRecordsResponse, UpdateZoneRrsetRecordsError, HetznerOpContext>;
//# sourceMappingURL=zone_rrset_actions.d.ts.map