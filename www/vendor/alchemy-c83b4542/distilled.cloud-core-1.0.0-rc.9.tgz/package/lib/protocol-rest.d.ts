/**
 * Generic REST protocol factory for simple bearer/header-auth JSON APIs
 * (Neon, Fly.io, PlanetScale, Supabase, Turso, …).
 *
 * `makeRestProtocol(options)` builds a core {@link API.Protocol} layer:
 *
 *   request:  credentials resolved from the CALLING fiber's context on every
 *             request (the layer itself is memoized per process — see
 *             `core/api`), auth headers + base URL from the provider's
 *             options, request built by `buildRequest` from
 *             `core/protocol-http` (deep-unwrapping any `Redacted` input
 *             values first)
 *
 *   response: 2xx JSON → optional `transformResponse` → recursive wire→TS
 *             key mapping (`mapKeys`) → `Redacted` wrapping of members
 *             marked with {@link SensitiveValue}; non-2xx → typed error:
 *             per-op matcher classes (`matchTypedError`), then the status
 *             map (default `HTTP_STATUS_MAP`), then an `InternalServerError`
 *             for unmapped 5xx, then the provider's `unknownError` fallback
 *             — with `retryAfter` durations stamped from the standard hint
 *             headers on retryable statuses.
 *
 * Anything provider-specific (envelope quirks, bespoke error codes) belongs
 * in the provider package — via these options or a hand-written protocol.
 */
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as AST from "effect/SchemaAST";
import * as API from "./api.ts";
export declare const sensitiveValueSymbol: unique symbol;
/**
 * Marks a string member as sensitive (mirrors `smithy.api#sensitive`).
 * The REST protocol wraps decoded values in `Redacted` on the way out and
 * accepts `string | Redacted<string>` on the way in (unwrapped before
 * serialization). Takes an ignored argument so generators can inline the
 * smithy trait value (`T.SensitiveValue({})`).
 */
export declare const SensitiveValue: (_value?: unknown) => import("./trait.ts").Annotation;
export declare const rawResponseSymbol: unique symbol;
/**
 * Marks the sole output member that carries a bare (array/scalar) response
 * body (mirrors `com.distilled.openapi#rawResponse`).
 */
export declare const RawResponse: (_value?: unknown) => import("./trait.ts").Annotation;
export declare const rawResponseRootSymbol: unique symbol;
/**
 * Marks a response schema whose ENTIRE value is the response body (the
 * generator's `rootPipe` for synthesized bare-payload wrappers): the emitted
 * response type IS the payload type and the protocol returns the mapped body
 * directly.
 */
export declare const RawResponseRoot: () => import("./trait.ts").Annotation;
/**
 * Deep-unwrap `Redacted` values in an input (plain objects/arrays only —
 * class instances, files, and binary payloads pass through untouched).
 * Sensitive input members accept `string | Redacted<string>`; the wire wants
 * the raw string.
 */
export declare const unwrapRedactedDeep: (value: unknown) => unknown;
/**
 * Walk a decoded (TS-named) value alongside its schema AST, wrapping members
 * marked {@link SensitiveValue} in `Redacted`. Keys the schema doesn't model
 * pass through verbatim.
 */
export declare const wrapSensitive: (ast: AST.AST, value: unknown) => unknown;
/** What the wire said about a failure, for the `unknownError` fallback. */
export interface RestErrorInfo {
    readonly status: number;
    /** Error code from the envelope (services vary between string and number). */
    readonly code?: string | number;
    readonly message: string;
    /** Parsed JSON body, or the raw text when the body wasn't JSON. */
    readonly body: unknown;
    readonly headers: Record<string, string | undefined>;
}
export interface RestErrorEnvelope {
    readonly code?: string | number;
    readonly message?: string;
}
export interface RestProtocolOptions<C> {
    /**
     * Resolve credentials ON THE CALLING FIBER — evaluated per request, never
     * at layer build time, so context-provided credentials and token refreshes
     * are picked up. Typically `Effect.gen(function* () { const resolve =
     * yield* Credentials; return yield* resolve; })` for the distilled
     * credentials-service convention. Its error/requirement channels are
     * erased at the protocol boundary (Protocol effects carry none) and
     * reintroduced for callers by the generated `<Sdk>OpError` /
     * `<Sdk>OpContext` annotations.
     */
    readonly credentials: Effect.Effect<C, any, any>;
    /** API base URL from the resolved credentials. */
    readonly baseUrl: (credentials: C) => string;
    /** Auth (and any fixed) headers from the resolved credentials. */
    readonly headers: (credentials: C) => Record<string, string>;
    /**
     * Extract `{ code?, message? }` from a parsed non-2xx JSON body. Default:
     * lenient `{ code?, message? | error? }` (covers the common REST error
     * envelopes).
     */
    readonly errorEnvelope?: (body: unknown) => RestErrorEnvelope | undefined;
    /**
     * HTTP status → error class constructed as `new Cls({ message, retryAfter
     * })`. Default: core `HTTP_STATUS_MAP`. Consulted after per-op typed error
     * matching; unmapped 5xx fall back to `InternalServerError`, everything
     * else to {@link unknownError}.
     */
    readonly statusMap?: Readonly<Record<number, new (args: any) => any>>;
    /** Fallback error for failures nothing else matched. */
    readonly unknownError: (info: RestErrorInfo) => unknown;
    /** Transform the parsed 2xx JSON before decoding (e.g. stripNulls). */
    readonly transformResponse?: (body: unknown) => unknown;
    /** Passed through to `buildRequest` (member-header transforms). */
    readonly mapMemberHeader?: (name: string, value: string) => string;
    /** Passed through to `buildRequest` (wire names for unmodeled input keys). */
    readonly unknownKeyToWire?: (key: string) => string;
}
/**
 * Build a `Layer<Protocol>` for a simple REST JSON API. Assign the result to
 * a module-level const in the provider's `protocol.ts` — `API.make` memoizes
 * protocol layers by value identity.
 */
export declare const makeRestProtocol: <C>(options: RestProtocolOptions<C>) => Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol-rest.d.ts.map