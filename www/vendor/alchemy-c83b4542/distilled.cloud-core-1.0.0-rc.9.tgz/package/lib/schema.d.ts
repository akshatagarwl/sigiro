/**
 * `any`-collapsing re-export of `effect/Schema` for generated service files.
 *
 * This is the single, shared definition consumed by every code-generated
 * provider package via `@distilled.cloud/core/schema`. Do not copy it into
 * individual packages.
 *
 * Every real TYPE (`Schema`, `Codec`, `Top`, …) is re-exported untouched, so
 * the `Schema.Schema<Foo>` annotations on generated consts (and the public
 * `.d.ts`) stay precise. The schema *construction surface* (`Struct`,
 * `optional`, `suspend`, …) and the leaf scalar schemas are retyped to `any`,
 * so the compiler instantiates none of the heavy Schema generics while
 * building a service file — the explicit annotations carry the real types.
 *
 * Overriding a *value* export never affects the same-named *type* export (they
 * live in separate namespaces and continue to flow through `export *`), so
 * `Schema.Literal<"x">`-style type usages remain precise.
 *
 * Runtime behaviour is identical — every override aliases the exact same
 * runtime value from `effect/Schema`.
 */
export * from "effect/Schema";
export type AnyFn = (...args: any[]) => any;
export declare const optional: AnyFn;
export declare const Struct: AnyFn;
export declare const suspend: AnyFn;
export declare const Array: AnyFn;
export declare const Record: AnyFn;
export declare const Union: AnyFn;
export declare const Literal: AnyFn;
export declare const Literals: AnyFn;
export declare const NullOr: AnyFn;
export declare const Tuple: AnyFn;
export declare const encodeKeys: AnyFn;
export declare const String: any;
export declare const Number: any;
export declare const Boolean: any;
export declare const Date: any;
export declare const Unknown: any;
export declare const Null: any;
export declare const Void: any;
export declare const Any: any;
//# sourceMappingURL=schema.d.ts.map