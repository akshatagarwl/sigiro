export {};
//# sourceMappingURL=graphql.types.d.ts.map