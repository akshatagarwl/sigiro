/**
 * Generic REST protocol machinery, shared by SDK protocol layers.
 *
 * Everything here is driven purely by the trait annotations in
 * `core/trait.ts` — nothing is provider-specific. An SDK protocol (e.g.
 * cloudflare's) supplies credentials/base-URL, calls {@link buildRequest} to
 * encode, and layers its own response-envelope handling on top of the
 * decode-side helpers ({@link getProps}/{@link mapKeys}/
 * {@link matchTypedError}).
 */
import type * as AST from "effect/SchemaAST";
import * as HttpClientRequest from "effect/unstable/http/HttpClientRequest";
import { type ErrorMatcher, type KeyDictionaryEntries } from "./trait.ts";
export declare const getProps: (ast: AST.AST) => readonly AST.PropertySignature[];
export declare const getAnn: (ast: AST.AST, symbol: symbol) => unknown;
export declare const getPropAnn: (prop: AST.PropertySignature, symbol: symbol) => unknown;
export declare const hasPropAnn: (prop: AST.PropertySignature, symbol: symbol) => boolean;
export declare const nameOf: (prop: AST.PropertySignature, symbol: symbol) => string;
/** Resolve wrappers to the real node: Suspend, encoding, optional/null unions. */
export declare const resolveNode: (ast: AST.AST) => AST.AST;
/** Binary/opaque values that must never be treated as key-value objects. */
export declare const isOpaqueValue: (v: unknown) => boolean;
/**
 * Deep-rename keys via a plain dictionary (see `T.KeyDictionary`). An entry
 * may list several wire spellings; encode uses the first (canonical) one and
 * decode maps every listed spelling back to the TS name.
 */
export declare const mapKeysByDictionary: (dict: KeyDictionaryEntries, value: unknown, direction: "encode" | "decode") => unknown;
/**
 * Recursively rename keys between TS names and wire names, per the schema.
 *
 * `fallback` is the nearest ancestor `T.KeyDictionary` — schema-known members
 * always map via their own annotations, but opaque values (Document members,
 * keys the schema doesn't know) deep-rename via the dictionary so nested
 * TS-cased content still reaches the wire in wire case. Content with no
 * dictionary in scope passes through verbatim.
 */
export declare const mapKeys: (ast: AST.AST, value: unknown, direction: "encode" | "decode", fallback?: KeyDictionaryEntries) => unknown;
export interface BuildRequestOptions {
    readonly input: unknown;
    readonly inputAst: AST.AST;
    /** Base URL the operation's URI template is appended to. */
    readonly baseUrl: string;
    /** Headers applied before member-bound headers (credentials etc.). */
    readonly headers?: Record<string, string>;
    /**
     * Transform a member-bound header value before it is set (e.g.
     * Bearer-prefixing a raw token supplied as an Authorization member).
     */
    readonly mapMemberHeader?: (name: string, value: string) => string;
    /**
     * Wire name for input keys the schema doesn't declare (spec drift —
     * unknown keys pass through as body fields rather than being dropped).
     * Defaults to the key verbatim.
     */
    readonly unknownKeyToWire?: (key: string) => string;
}
export declare const buildRequest: ({ input, inputAst, baseUrl, headers: baseHeaders, mapMemberHeader, unknownKeyToWire, }: BuildRequestOptions) => HttpClientRequest.HttpClientRequest;
/**
 * Whether one matcher matches one wire error: every present field must
 * match; a matcher (or a message object) with no constraints matches
 * nothing.
 */
export declare const matchesExpression: (m: ErrorMatcher, code: number | undefined, status: number, message: string) => boolean;
/**
 * Pick the operation's typed error class for a failed response: among all
 * declared classes whose matchers (see `applyErrorMatchers`) match the wire
 * failure, the most specific matcher wins (ties break by declaration order).
 */
export declare const matchTypedError: (errorClasses: ReadonlyArray<unknown>, status: number, errors: ReadonlyArray<{
    code?: number;
    message: string;
}>) => unknown | undefined;
//# sourceMappingURL=protocol-http.d.ts.map