import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as S from "effect/Schema";
import type * as AST from "effect/SchemaAST";
import type * as Stream from "effect/Stream";
import * as Pagination from "./pagination.ts";
import { type Policy as RetryPolicy } from "./retry.ts";
import * as HttpClient from "effect/unstable/http/HttpClient";
import type * as HttpClientError from "effect/unstable/http/HttpClientError";
import type * as HttpClientRequest from "effect/unstable/http/HttpClientRequest";
import type * as HttpClientResponse from "effect/unstable/http/HttpClientResponse";
/**
 * The view of an operation's config that protocols receive on every
 * encode/decode call. The object is the same memoized config instance for
 * every call to a given operation, so protocols can key per-operation
 * preprocessing (handler construction, error maps) off its identity in a
 * WeakMap.
 */
export interface ProtocolOperationConfig {
    readonly input?: S.Top;
    readonly output?: S.Top;
    readonly errors?: ReadonlyArray<ApiErrorClass>;
    /**
     * The wire operation name (e.g. the Smithy operation shape name). RPC-style
     * protocols address operations by name (AWS JSON's `X-Amz-Target`, AWS
     * Query's `Action=`) and unwrap responses by it; REST protocols ignore it.
     */
    readonly operationName?: string;
    /**
     * The smithy `smithy.api#endpoint` hostPrefix (e.g. `sync-` for Step
     * Functions' StartSyncExecution). Protocols prepend it to the resolved
     * endpoint host, substituting `{memberName}` labels from the input.
     */
    readonly endpointHostPrefix?: string;
    readonly pagination?: Pagination.PaginatedTrait;
}
declare const Protocol_base: Context.ServiceClass<Protocol, "Protocol", {
    readonly encode: (args: {
        readonly input: unknown;
        readonly inputAst: AST.AST;
        /** The operation's config (memoized per operation — see {@link ProtocolOperationConfig}). */
        readonly config: ProtocolOperationConfig;
    }) => Effect.Effect<HttpClientRequest.HttpClientRequest>;
    readonly decode: (args: {
        readonly response: HttpClientResponse.HttpClientResponse;
        readonly outputAst: AST.AST;
        /**
         * The operation's declared error classes (from `OperationConfig.errors`).
         * Protocols use these to surface wire failures as the operation's typed
         * errors — e.g. by consulting matcher metadata stamped on the class.
         */
        readonly errors: ReadonlyArray<ApiErrorClass>;
        /** The operation's config (memoized per operation — see {@link ProtocolOperationConfig}). */
        readonly config: ProtocolOperationConfig;
    }) => Effect.Effect<unknown>;
}>;
/**
 * The Protocol service knows how to turn a value into an HTTP request using
 * only the input schema's trait annotations, and how to turn a response back
 * into an output value using the output schema's trait annotations.
 *
 * Swap implementations by providing a different `Layer<Protocol>`.
 */
export declare class Protocol extends Protocol_base {
}
export type ApiErrorClass = {
    new (...args: any[]): {
        readonly _tag: string;
        readonly message: string;
    };
};
/**
 * The shape of a generated SDK operation — usable two ways (mirrors the
 * distilled repo's OperationMethod):
 *
 * 1. Direct call: `yield* operation(input)` — an Effect with requirements.
 * 2. Yield first: `const fn = yield* operation` — captures the current
 *    context and returns a requirement-free call function.
 *
 * Generated service files annotate every exported operation with this type
 * explicitly (against their hand-emitted interfaces), so the compiler never
 * has to infer it back out of the schema generics.
 */
export type OperationMethod<I, O, E, R> = Effect.Effect<(input: I) => Effect.Effect<O, E, never>, never, R> & ((input: I) => Effect.Effect<O, E, R>);
export interface OperationConfig<I extends S.Top, O extends S.Top, PE, PR, E extends readonly ApiErrorClass[] = readonly ApiErrorClass[]> {
    input?: I;
    output?: O;
    errors?: E;
    /**
     * The protocol layer that knows how to encode/decode this operation's wire
     * format. Built once per process and shared across all operations that
     * reference the same layer value — it must resolve call-dependent services
     * (credentials etc.) inside encode/decode, not at build time.
     */
    protocol: Layer.Layer<Protocol, PE, PR>;
    /**
     * SDK-specific retry service tag (see `core/retry`). When provided and the
     * caller's context carries a policy under this tag, every call is retried
     * per that policy (e.g. `Layer.succeed(Cloudflare.Retry.Retry, factory)`).
     */
    retry?: Context.Key<any, RetryPolicy>;
    /**
     * The wire operation name for RPC-style protocols (see
     * {@link ProtocolOperationConfig.operationName}).
     */
    operationName?: string;
    /**
     * Host prefix from the smithy endpoint trait (see
     * {@link ProtocolOperationConfig.endpointHostPrefix}).
     */
    endpointHostPrefix?: string;
}
export declare function make<I extends S.Top, O extends S.Top, PE, PR, const E extends readonly ApiErrorClass[] = readonly []>(configFn: () => OperationConfig<I, O, PE, PR, E>): OperationMethod<S.Schema.Type<I>, S.Schema.Type<O>, InstanceType<E[number]> | PE | HttpClientError.HttpClientError, PR | HttpClient.HttpClient>;
/**
 * STRUCTURAL fallback for the element type `.items()` yields: the array
 * element of the page response itself, or of its `result` member.
 *
 * It can only see shapes it was taught, so any other envelope
 * (`{ branches: […] }`, `{ data: […] }`, …) lands on `unknown` — which is
 * why generators pass the item type EXPLICITLY as
 * {@link PaginatedOperationMethod}'s `Item` argument, resolved from the
 * pagination trait's `items` path against the response shape. This default
 * only applies to hand-written operations.
 */
export type PaginatedItem<A> = A extends ReadonlyArray<infer Item> ? Item : A extends {
    result: ReadonlyArray<infer Item>;
} ? Item : A extends {
    result?: ReadonlyArray<infer Item> | null | undefined;
} ? Item : unknown;
/**
 * The callable half of a paginated operation: the operation call itself, plus
 * `.pages(input)` streaming every page response and `.items(input)` streaming
 * the individual items across pages.
 *
 * Used twice in {@link PaginatedOperationMethod} — once with the operation's
 * requirements (`R`) for the direct-call style, once with `R = never` for the
 * value `yield* operation` hands back, which has the caller's context baked in.
 */
export interface PaginatedCall<I, O, E, R, Item> {
    (input: I): Effect.Effect<O, E, R>;
    readonly pages: (input: I) => Stream.Stream<O, E, R>;
    readonly items: (input: I) => Stream.Stream<Item, E, R>;
}
/**
 * A paginated operation: usable both ways an {@link OperationMethod} is, with
 * `.pages` / `.items` on BOTH — the operation object for
 * `yield* op.items(input)`, and the requirement-free call function for
 * `const op = yield* operation; yield* op.items(input)` (distilled #145).
 */
export type PaginatedOperationMethod<I, O, E, R, Item = PaginatedItem<O>> = Effect.Effect<PaginatedCall<I, O, E, never, Item>, never, R> & PaginatedCall<I, O, E, R, Item>;
export interface PaginatedOperationConfig<I extends S.Top, O extends S.Top, PE, PR, E extends readonly ApiErrorClass[] = readonly ApiErrorClass[]> extends OperationConfig<I, O, PE, PR, E> {
    /** How to advance between pages (mirrors the `smithy.api#paginated` trait). */
    pagination: Pagination.PaginatedTrait;
}
/**
 * Like {@link make}, plus `.pages()` / `.items()` streaming built on the
 * operation's pagination trait. The SDK can pass a provider-specific
 * {@link Pagination.PaginationStrategy} (e.g. Cloudflare stops page-mode
 * traversal on the first empty page); the default dispatches on
 * `pagination.mode`.
 */
export declare function makePaginated<I extends S.Top, O extends S.Top, PE, PR, const E extends readonly ApiErrorClass[] = readonly []>(configFn: () => PaginatedOperationConfig<I, O, PE, PR, E>, strategy?: Pagination.PaginationStrategy): PaginatedOperationMethod<S.Schema.Type<I>, S.Schema.Type<O>, InstanceType<E[number]> | PE | HttpClientError.HttpClientError, PR | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=api.d.ts.map