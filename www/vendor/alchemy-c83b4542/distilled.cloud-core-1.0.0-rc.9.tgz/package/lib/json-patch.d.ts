/**
 * JSON Patch (RFC 6902) Implementation
 *
 * Provides a unified spec patching system for all SDKs. Patches apply in
 * `convert` so `.generated-specs` is the patched Smithy model. generate does
 * not patch. Prefer `operationNaming: "verbNoun"` for operationId renames —
 * JSON pointers at `/paths/~1foo/operationId` go stale when upstream prefixes
 * paths.
 *
 * Pure functions only — callers load patch files themselves (the generators
 * use Effect's FileSystem) and hand the parsed operations to `applyPatch`.
 */
export interface JsonPatchOperation {
    op: "add" | "remove" | "replace" | "move" | "copy" | "test";
    path: string;
    value?: unknown;
    from?: string;
}
export type JsonPatch = JsonPatchOperation[];
export interface PatchFile {
    description?: string;
    patches: JsonPatch;
}
/** Parse a JSON Pointer (RFC 6901) path into segments. */
export declare function parseJsonPointer(pointer: string): string[];
/** Get a value at a JSON Pointer path. */
/**
 * The target location of a patch operation is absent from the document —
 * spec drift (renamed/removed upstream), not a malformed patch.
 */
export declare class StaleTargetError extends Error {
    readonly name = "StaleTargetError";
}
export declare function getValueAtPath(obj: unknown, pointer: string): unknown;
/** Set a value at a JSON Pointer path. */
export declare function setValueAtPath(obj: unknown, pointer: string, value: unknown): void;
/** Remove a value at a JSON Pointer path. */
export declare function removeValueAtPath(obj: unknown, pointer: string): void;
/** Apply a single JSON Patch operation (mutates `obj` in place). */
export declare function applyOperation(obj: unknown, operation: JsonPatchOperation): void;
/** Apply a JSON Patch to an object (mutates in place). */
export declare function applyPatch(obj: unknown, patch: JsonPatch): void;
/**
 * Whether a per-operation failure is a {@link StaleTargetError} (the
 * operation/shape the patch targets was renamed or removed upstream) as
 * opposed to a malformed patch. Accepts the thrown value or its message.
 * Convert fails the run on these by default (`onStalePatch: "fail"`);
 * `"warn"` restores skip-and-continue.
 */
export declare function isStaleTargetError(error: unknown): boolean;
//# sourceMappingURL=json-patch.d.ts.map