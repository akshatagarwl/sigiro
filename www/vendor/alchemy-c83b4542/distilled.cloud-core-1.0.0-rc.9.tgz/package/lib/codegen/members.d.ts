export interface MemberBase {
    /** Original smithy member name. */
    readonly name: string;
    /** TS-facing name (per `nameFn`, deduplicated within the structure). */
    readonly tsName: string;
    readonly target: string;
    readonly required: boolean;
    readonly doc: string | undefined;
    readonly traits: Record<string, any>;
}
/**
 * Base analysis of a structure's members: TS naming (with collision
 * dedup — a clashing name falls back to the original, then a numeric
 * suffix), required-ness, and one-line docs. Binding classification and
 * anything provider-specific layer on top via `traits`.
 */
export declare const memberBases: (def: any, nameFn?: (memberName: string) => string) => MemberBase[];
/**
 * The wire name a bound member serializes under, per the smithy HTTP
 * binding traits: labels use the member name (URI placeholders), query and
 * header use the trait value when it's a non-empty string, everything else
 * uses `jsonName` when present.
 */
export declare const smithyWireName: (traits: Record<string, any>, memberName: string, binding: "label" | "query" | "header" | "other") => string;
//# sourceMappingURL=members.d.ts.map