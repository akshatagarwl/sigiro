import { Effect } from "effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { type SdkSpec } from "./generator.ts";
export interface GeneratorCliOptions {
    /** Command description shown in --help. */
    readonly description: string;
    /** Absolute package root (usually `path.resolve(import.meta.dir, "..")`). */
    readonly root: string;
    /** Model directory default (relative to root). Default `.generated-specs`. */
    readonly smithyDir?: string;
    /** Output directory default (relative to root). Default `src/services`. */
    readonly outDir?: string;
    /** Model files to skip (e.g. a shared protocols model). */
    readonly excludeModel?: (file: string) => boolean;
    /**
     * Where the models are, when they aren't a flat directory of `<resource>.json`.
     * AWS vendors Amazon's own repo, whose models sit at
     * `models/<service>/service/<version>/<service>-<version>.json`.
     *
     * Returns the model files to compile; manual specs are merged in after,
     * as usual.
     */
    readonly discoverModels?: (ctx: {
        readonly smithyDir: string;
    }) => Effect.Effect<ReadonlyArray<{
        readonly file: string;
        readonly dir: string;
    }>, never, FileSystem.FileSystem | Path.Path>;
    /**
     * Side effects to run before generating — e.g. AWS copies `partitions.json`
     * out of the smithy submodule, runtime data its endpoint resolver reads.
     */
    readonly prepare?: (ctx: {
        readonly root: string;
        readonly outDir: string;
    }) => Effect.Effect<void, never, FileSystem.FileSystem | Path.Path>;
    /**
     * The output module's name, when it isn't the model's filename. AWS names
     * modules after the service's `aws.api#service` sdkId (`amazon-s3.json` →
     * `s3.ts`), so the public surface reads `AWS.S3.getObject`.
     */
    readonly resourceName?: (ctx: {
        readonly model: any;
        readonly file: string;
    }) => string;
    /** Barrel export name for a resource. Default: the resource name itself. */
    readonly barrelExportName?: (resource: string) => string;
    /**
     * The closing pass over the output directory. Defaults to formatting;
     * AWS lint-fixes first (see `codegen/format.ts`).
     */
    readonly finalize?: (dir: string) => Effect.Effect<void>;
    /**
     * Keep generating after a model fails, instead of stopping at the first.
     * AWS compiles 430 services in one run, and one broken model shouldn't
     * hide the state of the other 429. The run still FAILS at the end — the
     * failures are reported together rather than swallowed.
     */
    readonly continueOnModelError?: boolean;
    /** Directory of hand-authored models merged after the generated ones. */
    readonly manualSpecsDir?: string;
    /**
     * RFC-6902 patches apply in convert, never here. Only `false` is accepted
     * so a string is a type error rather than a silently ignored setting.
     */
    readonly patchesDir?: false;
    /**
     * Model transform applied before generation (e.g. AWS dropping
     * unreachable foreign-namespace shapes from a vendored model). Does not
     * write back to `.generated-specs` — convert owns the committed model.
     */
    readonly transformModel?: (model: any, resource: string) => string | void;
    /** The provider spec — built per model (metadata may vary per model). */
    readonly spec: (model: any) => SdkSpec;
}
/** Run the generator CLI (BunRuntime main — call at module top level). */
export declare const runGeneratorCli: (options: GeneratorCliOptions) => void;
//# sourceMappingURL=cli.d.ts.map