export {};
//# sourceMappingURL=graphql-client.test.d.ts.map