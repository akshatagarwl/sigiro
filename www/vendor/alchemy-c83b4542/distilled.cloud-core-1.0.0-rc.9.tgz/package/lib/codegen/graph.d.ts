export type ShapeMap = Record<string, any>;
/**
 * Direct dependencies of a shape: structure/union member targets, list
 * member, map key/value. Operations/services are not traversed here —
 * providers seed reachability from operation I/O explicitly.
 */
export declare const shapeDeps: (def: any) => string[];
/**
 * Every shape reachable from `roots` through `deps`, excluding prelude
 * shapes and ids missing from the map.
 */
export declare const reachableFrom: (shapes: ShapeMap, roots: Iterable<string>, deps?: (def: any) => string[]) => Set<string>;
/**
 * Dependencies-first topological order over `ids`. Cycles are tolerated:
 * a back-edge is simply skipped, so mutually-recursive shapes come out in
 * discovery order and emitters break the cycle with `S.suspend` at
 * forward references (see {@link forwardRef}).
 */
export declare const topoOrder: (shapes: ShapeMap, ids: Iterable<string>, deps?: (def: any) => string[]) => string[];
/** Position index for {@link forwardRef} decisions. */
export declare const orderIndex: (order: readonly string[]) => Map<string, number>;
/**
 * Whether a reference from the shape at `selfIdx` to `target` points
 * forward in emission order (including into a cycle) and therefore needs
 * `S.suspend(() => …)` to defer evaluation.
 */
export declare const isForwardRef: (indexOf: ReadonlyMap<string, number>, target: string, selfIdx: number) => boolean;
/**
 * All shape ids that participate in a dependency cycle (Tarjan SCC —
 * components of size > 1, plus direct self-loops). Used by generators
 * that must know cyclicity independent of emission position (e.g. to add
 * an explicit `S.Schema<T>` return type on suspended thunks and break
 * circular type inference).
 */
export declare const cyclicShapeIds: (shapes: ShapeMap, ids: Iterable<string>, deps?: (def: any) => string[]) => Set<string>;
//# sourceMappingURL=graph.d.ts.map