import { type JsonPatchOperation } from "../json-patch.ts";
export type OnStalePatch = "fail" | "warn";
export interface ApplyPatchesResult {
    files: number;
    applied: number;
    stale: number;
    errors: string[];
}
/** Smithy-model JSON pointers — OpenAPI has no `/shapes` tree. */
export declare const isSmithyPatchPath: (pointer: string) => boolean;
/**
 * RFC-6902 files in `dir`: every `*.json`, `*.manual.json` last (those
 * usually target post-rename shape names). Missing dir → `[]`.
 */
export declare const listRfc6902PatchFiles: (dir: string) => Promise<string[]>;
export declare const applyRfc6902Files: (target: unknown, files: readonly string[], opts?: {
    readonly onStalePatch?: OnStalePatch;
    readonly include?: (op: JsonPatchOperation) => boolean;
    readonly label?: (file: string) => string;
}) => Promise<ApplyPatchesResult>;
/**
 * An RFC-6902 `move` that renames an operation shape leaves the service's
 * `operations` list pointing at the old id. Drop entries whose target no
 * longer exists and append operation shapes the list is missing, keeping
 * the existing order. Returns the number of services whose list changed.
 */
export declare const syncServiceOperations: (model: {
    shapes?: Record<string, any>;
}) => number;
/**
 * Every `target` in a Smithy model must resolve to a shape or a prelude
 * (`smithy.api#…`) id. Returns the dangling ones as `"<owner> → <target>"`.
 * A convert that produces any is broken — generate would emit references
 * to types that do not exist.
 */
export declare const danglingTargets: (model: {
    shapes?: Record<string, any>;
}) => string[];
/**
 * Last step of every convert: Smithy RFC-6902 patches, then verbNoun
 * operation names, then an optional model transform, then a reference
 * check. Writes models back so `.generated-specs` is what generate
 * compiles. `outDir` may be nested (GCP `stable/` / `unstable/`).
 *
 * Input must be FRESHLY converted models. Smithy patches are `move`/`add`
 * ops that are not idempotent, and a `transform` may not be either, so
 * running this over a model that already went through it is an error —
 * re-run the package's `convert` instead.
 */
export declare const finalizeConvert: (o: {
    readonly root: string;
    readonly outDir?: string;
    readonly patchesDir?: string | false;
    readonly exclude?: (file: string) => boolean;
    readonly include?: (resource: string) => boolean;
    readonly transform?: (model: any, resource: string) => string | void;
    readonly operationNaming?: "as-is" | "verbNoun";
    readonly onStalePatch?: OnStalePatch;
}) => Promise<void>;
/**
 * Metadata marker stamped by {@link finalizeConvert}. Guards against a
 * second pass over the same file (see the note on finalizeConvert).
 */
export declare const FINALIZED_KEY = "distilled.finalized";
//# sourceMappingURL=patches.d.ts.map