export {};
//# sourceMappingURL=rewrite-operation-ids.test.d.ts.map