/**
 * The generic smithy→SDK service generator (dev-time only).
 *
 * One driver compiles a Smithy JSON model into an Effect SDK service module.
 * Everything provider-specific arrives through {@link SdkSpec}: import
 * header, trait vocabulary (which trait ids mean payload/file/nullable/…),
 * the `T.*` pipe expressions to emit for each binding, how operations are
 * declared (protocol/retry/error names), and naming policies. The driver
 * owns the pipeline: operation discovery, reachability, topological order,
 * schema/interface emission, error classes, pagination validation, and
 * operation consts.
 *
 * A provider's `scripts/generate.ts` reduces to: load models (its own
 * pipeline — docs-derived specs, patches, …), define its {@link SdkSpec},
 * call {@link generateService} per model, write files.
 */
import { local, q, tsKey, upperFirst } from "./naming.ts";
import { type ShapeMap } from "./graph.ts";
import { errorUnionAlias, operationConst } from "./emit.ts";
import { type OpEntry } from "./operations.ts";
/**
 * Error categories, derived from the STANDARD Smithy error traits.
 *
 * `smithy.api#httpError` and `smithy.api#retryable` are how every Smithy
 * model — AWS's included — says what kind of failure an error is. The
 * categories the runtime acts on (`core/category.ts`, and `isTransientError`
 * in `core/retry.ts`) are a reading of those two traits, so the reading
 * belongs here, once, for every provider.
 *
 * A model that wants its errors classified states the status the API
 * actually returns:
 *
 *   "traits": { "smithy.api#error": "client", "smithy.api#httpError": 404 }
 *
 * and the error class is emitted with `.pipe(C.withNotFoundError)`. A model
 * with no `httpError` gets no categories — the same as today.
 */
export declare const errorCategories: (traits: Record<string, any> | undefined, 
/** Categories a provider knows that the traits don't say (AWS's spec file). */
extra?: readonly string[]) => string[];
/** A member's resolved binding. The four generic kinds plus provider extras. */
export type MemberBinding = "label" | "query" | "header" | "body" | (string & {});
export interface EmittedMember {
    readonly name: string;
    readonly tsName: string;
    readonly wire: string;
    readonly target: string;
    readonly binding: MemberBinding;
    readonly required: boolean;
    readonly nullable: boolean;
    readonly doc: string | undefined;
    readonly traits: Record<string, any>;
}
export interface PaginationProfile {
    /** Protocol const for paginated ops. Defaults to operationDecl.protocol. */
    readonly protocol?: string;
    /** Strategy expression passed as makePaginated's second argument. */
    readonly strategy?: string;
    /** Items path fallback when the trait omits `items`. */
    readonly itemsFallback: string;
    /** Output names accepted even when not modeled (delivered by the protocol). */
    readonly syntheticOutputs?: readonly string[];
    /**
     * Extra interface field + struct member appended to paginated outputs
     * that don't already model them (what the protocol delivers beyond the
     * modeled shape — e.g. cloudflare's `resultInfo` from the envelope's
     * `result_info`). `imports` are pulled from the pagination module in the
     * header.
     */
    readonly injectOutputMember?: {
        readonly tsName: string;
        readonly interfaceLines: readonly string[];
        readonly structLine: string;
        readonly imports?: readonly string[];
    };
}
export interface OperationEmit {
    readonly op: OpEntry;
    readonly opName: string;
    readonly exportName: string;
    readonly inputName: string;
    readonly outputName: string;
    /**
     * The output as a TS type and as a schema expression. These differ from
     * {@link outputName} when the operation's output IS a prelude shape
     * (e.g. stripe's freeform `smithy.api#Document` responses): the bare
     * local name isn't declared in the module, so it must resolve through
     * the prelude maps (`unknown` / `S.Unknown`) instead.
     */
    readonly outputTsType: string;
    readonly outputSchema: string;
    /** Declared error class names present in the model. */
    readonly errorNames: readonly string[];
    readonly doc: string | undefined;
    /** The validated pagination trait, when the op paginates. */
    readonly pagination: unknown | undefined;
}
export interface SdkSpec {
    /** Namespace fallback for models with no operations. Default `"smithy.unknown"`. */
    readonly namespaceFallback?: string;
    /** PURE marker before schema consts. Default: the shared single marker. */
    readonly pure?: string;
    /** Prelude scalar → schema expression map. Default {@link JSON_PRELUDE}. */
    readonly prelude?: Record<string, string>;
    /** Prelude scalar → TS type map. Default {@link TS_JSON_PRELUDE}. */
    readonly tsPrelude?: Record<string, string>;
    /** Wire member name → TS-facing name. Default: identity. */
    readonly memberName?: (name: string) => string;
    /** Operation shape name → exported const name. Default: lowerFirst. */
    readonly opExportName?: (name: string) => string;
    /**
     * Emit the one-line smithy doc comment above shapes and error classes.
     * Default true. AWS turns this off — its models carry multi-kilobyte HTML
     * docs per shape and the SDK only surfaces operation-level docs.
     */
    readonly shapeDocs?: boolean;
    /**
     * Extra reachability roots beyond the operations' I/O shapes. AWS seeds
     * the error shapes here so their member targets are emitted (error class
     * fields reference schema consts); the error shapes themselves are still
     * emitted as error classes, not schemas.
     */
    readonly extraRoots?: (selected: readonly OpEntry[], shapes: ShapeMap) => Iterable<string>;
    /**
     * Provider member bindings as data, checked in order between the generic
     * header binding and `smithy.api#httpPayload`. The driver's cascade:
     * label → query → header → extraBindings → rawBody (httpPayload) → body.
     *
     * `pipe` is emitted for the member; `tsType` overrides its interface
     * type (e.g. file uploads → `(File | Blob)[]`).
     */
    readonly extraBindings?: ReadonlyArray<{
        readonly trait: string;
        readonly binding: MemberBinding;
        readonly pipe: string;
        readonly tsType?: string;
        /**
         * Bare-payload form: when this binding is the sole member of a
         * (non-paginated) output structure, the whole response IS that
         * member's value — the driver emits the member's type directly and
         * pipes the schema through this root marker for the protocol.
         */
        readonly rootPipe?: string;
    }>;
    /**
     * Which wire-name rule a binding follows. Defaults: the three generic
     * kinds map to themselves, everything else to `"other"` (jsonName).
     */
    readonly wireKind?: (binding: MemberBinding) => "label" | "query" | "header" | "other";
    /** Trait id marking a member nullable (`S.NullOr` + `| null`). */
    readonly nullableTrait?: string;
    /**
     * Blanket-nullable optionals: every optional body member types and
     * decodes as `X | null` in addition to being omittable (`?: X | null`,
     * `S.optional(S.NullOr(X))`). The cloudflare docs pipeline sets this —
     * the v4 API freely returns explicit nulls for absent optional fields,
     * and the v0 SDK surface modeled every optional that way.
     */
    readonly optionalsNullable?: boolean;
    /**
     * Member traits emitted as pipes when present: trait id → pipe builder
     * name in the SDK's traits module. The trait's value is JSON-inlined as
     * the argument (e.g. `"…#keyDictionary": "T.KeyDictionary"` →
     * `T.KeyDictionary({…})`).
     */
    readonly memberTraitPipes?: Readonly<Record<string, string>>;
    /**
     * Extra schema pipes appended after the generic ones, for anything the
     * data tables can't express. The driver emits `T.Label/T.Query/T.Header`
     * (wire-aware), `T.HttpBody()` for rawBody, and `T.Body(wire)` renames —
     * the SDK's traits module must export those core builders under these
     * names.
     */
    readonly memberExtraPipes?: (m: EmittedMember) => string[];
    /** Full override of member pipe emission (rarely needed). */
    readonly memberPipes?: (m: EmittedMember) => string[];
    /** Function override for member TS types beyond the binding table. */
    readonly memberTsType?: (m: EmittedMember, tsRef: (target: string) => string) => string | undefined;
    /**
     * Struct-level pipes for a shape (after the member struct): the http
     * trait on op inputs, service-wide key-dictionary stamping, etc.
     */
    readonly structPipes?: (ctx: {
        readonly id: string;
        readonly isOpIo: boolean;
        readonly httpTrait: unknown | undefined;
    }) => string[];
    /**
     * Pagination profiles. A profile is the codegen-side description of one
     * paginated wire variant: the Protocol const that decodes it, the
     * strategy passed to makePaginated, the trait-validation rules, and any
     * output member the protocol delivers beyond the modeled shape. SDKs
     * with several pagination styles declare several profiles and select
     * per-op via {@link SdkSpec.paginationProfileFor}.
     */
    readonly paginationProfiles?: Readonly<Record<string, PaginationProfile>>;
    /**
     * Select the profile for a paginated op (from its `smithy.api#paginated`
     * trait / shape). Default: the sole declared profile; with several
     * profiles this becomes required for ops to paginate.
     */
    readonly paginationProfileFor?: (trait: any, op: OpEntry) => string | undefined;
    /**
     * Service-wide fallback key dictionary stamped on op I/O roots (emitted
     * as a `KEY_DICTIONARY` header const + `T.KeyDictionary(KEY_DICTIONARY)`
     * root pipe). `doc` is the const's doc comment. An entry may list several
     * wire spellings (first = canonical encode name; decode accepts all).
     */
    readonly rootKeyDictionary?: {
        readonly dict: Record<string, string | ReadonlyArray<string>>;
        readonly doc: string;
    };
    /** Banner suffix: `AUTO-GENERATED by scripts/generate.ts from <note>`. */
    readonly sourceNote?: string;
    /**
     * Operation aliases: re-export the canonical op (and its
     * Request/Response/Error types) under each alias name. Skipped when the
     * target wasn't emitted or the alias name is taken.
     */
    readonly opAliases?: ReadonlyArray<{
        readonly alias: string;
        readonly target: string;
    }>;
    /**
     * Full shape-emission override, checked before the driver's own shape
     * handling. Return the emitted lines to own a shape (e.g. AWS's
     * newtypes, structural unions, event streams), or undefined to let the
     * driver emit it. `selfIdx` is the shape's position in emission order
     * for forward-ref decisions.
     */
    readonly shapeOverride?: (ctx: {
        readonly id: string;
        readonly def: any;
        readonly name: string;
        readonly selfIdx: number;
        readonly ref: (target: string, selfIdx: number) => string;
        readonly tsRef: (target: string) => string;
        readonly members: (d: any) => EmittedMember[];
    }) => string[] | undefined;
    /**
     * Union emission style. `"opaque-cases"`: the TS type is the case union
     * and the schema is `S.Unknown.pipe(T.UnionCases([...case key sets]))` —
     * the protocol discriminates by key-set at decode time (for APIs that
     * return every case's keys with nulls, like Cloudflare's).
     */
    readonly unionStyle?: "opaque-cases";
    /** Full override of union emission. */
    readonly union?: (ctx: {
        readonly name: string;
        readonly caseTargets: readonly string[];
        readonly caseKeys: readonly (readonly string[])[];
        readonly tsRef: (target: string) => string;
    }) => string[];
    /**
     * Trait id carrying error matchers: when present on an error shape, the
     * class is wrapped in `T.applyErrorMatchers(<cls>, <trait value>)`.
     */
    readonly errorMatchersTrait?: string;
    /** Error-class emission details. All optional. */
    readonly errors?: {
        /**
         * Full override of one error class's emission (mirrors shapeOverride):
         * return the emitted lines to own the error, or undefined to fall back
         * to the driver's field/wrap-based emission.
         */
        readonly override?: (ctx: {
            readonly id: string;
            readonly def: any;
            readonly name: string;
        }) => string[] | undefined;
        /**
         * Field lines used when the error shape declares no members.
         * Default: `code` (integer) + `message` (string) — the common REST
         * error envelope.
         */
        readonly defaultFields?: (prelude: Record<string, string>) => string[];
        /** Field line for a declared member. Default: prelude-mapped schema. */
        readonly field?: (name: string, target: string) => string;
        /** Optional wrapper (e.g. matcher application) from the shape's traits. */
        readonly wrap?: (traits: Record<string, any>) => ((cls: string) => string) | undefined;
    };
    /**
     * Declarative operation emission — the names the op consts are built
     * from. `operation` overrides this entirely when a provider needs full
     * control of the emitted shape.
     */
    readonly operationDecl?: {
        /** Requirements type in the OperationMethod annotation. */
        readonly contextType: string;
        /** Base of the per-op error union alias (e.g. `CloudflareOpError`). */
        readonly commonErrorType: string;
        /** Error classes appended to every op's `errors: [...]` list. */
        readonly commonErrorClasses: readonly string[];
        readonly protocol: string;
        /** The retry tag expression (e.g. `Retry.Retry`). */
        readonly retry: string;
        /**
         * Extra config lines inserted before the pagination entry (e.g. AWS's
         * `operationName` and `endpointHostPrefix`).
         */
        readonly extraConfig?: (ctx: OperationEmit) => string[];
    };
    /** Full override of operation const emission. */
    readonly operation?: (ctx: OperationEmit) => string;
    /**
     * Module header override. The default builds the banner + imports from
     * {@link SdkSpec.operationDecl} names and the conventional module layout
     * (`../traits.ts`, `../protocol.ts`, `../pagination.ts`, `../errors.ts`,
     * `../retry.ts`), re-exports the op error/context types, and emits the
     * `KEY_DICTIONARY` const when {@link SdkSpec.rootKeyDictionary} is set.
     */
    readonly header?: (ctx: {
        readonly hasPaginated: boolean;
        readonly model: any;
    }) => string;
    /** Final pass over the assembled module (e.g. pruning unused imports). */
    readonly postProcess?: (code: string) => string;
    /**
     * Trailing sections after operations (e.g. route-alias re-exports).
     * Receives the set of emitted op export names (mutable — additions are
     * visible to subsequent alias checks).
     */
    readonly footer?: (ctx: {
        readonly emittedOps: Set<string>;
    }) => string[];
}
export interface GeneratedService {
    code: string;
    operations: number;
}
/** Compile one Smithy model into a service module. */
export declare const generateService: (model: any, spec: SdkSpec) => GeneratedService;
export { errorUnionAlias, operationConst, upperFirst, tsKey, q, local };
//# sourceMappingURL=generator.d.ts.map