/** GraphQL-native introspection compiler. No traversal limits or RPC projection. */
import { type TypeRef } from "./graphql.ts";
export interface GraphQLArgument {
    readonly type: string;
    readonly description?: string;
    readonly defaultValue?: string;
}
export interface GraphQLField {
    readonly type: string;
    readonly args: Record<string, GraphQLArgument>;
    readonly errors: readonly string[];
    readonly description?: string;
    readonly deprecated?: string | true;
}
export interface GraphQLType {
    readonly kind: string;
    readonly description?: string;
    readonly fields?: Record<string, GraphQLField>;
    readonly inputFields?: Record<string, GraphQLArgument>;
    readonly enumValues?: readonly string[];
    readonly possibleTypes?: readonly string[];
    readonly interfaces?: readonly string[];
    /** TypeScript scalar representation; custom JSON scalars default to unknown. */
    readonly scalar?: string;
}
export interface GraphQLErrorDefinition {
    readonly description?: string;
    readonly category?: string;
    readonly retryable?: boolean;
    readonly matchers: readonly {
        readonly code?: string;
        readonly message?: string;
        readonly messageIncludes?: string;
    }[];
}
export interface GraphQLModel {
    readonly version: 1;
    readonly queryType: string;
    readonly mutationType?: string;
    readonly subscriptionType?: string;
    readonly types: Record<string, GraphQLType>;
    readonly errors: Record<string, GraphQLErrorDefinition>;
    readonly globalErrors: readonly string[];
}
export declare const graphqlTypeString: (ref: TypeRef) => string;
/** Retain every schema coordinate, wrapper, default and abstract-type relationship. */
export declare const convertGraphQLClient: (introspection: unknown, options?: {
    readonly scalars?: Readonly<Record<string, string>>;
}) => GraphQLModel;
/** Reject dangling schema/error references after patches, before generating code. */
export declare const validateGraphQLModel: (model: GraphQLModel) => void;
export interface GenerateGraphQLClientOptions {
    readonly transportImport: string;
    readonly transportName?: string;
    readonly requirementsType: string;
    readonly requirementsImport: string;
    /** Optional legacy-name aliases, e.g. createProject -> projectCreate. */
    readonly operationAliases?: Readonly<Record<string, string>>;
}
/** Emit schema-indexed types and the matching runtime graph from one patched model. */
export declare const generateGraphQLClient: (model: GraphQLModel, options: GenerateGraphQLClientOptions) => string;
//# sourceMappingURL=graphql-client.d.ts.map