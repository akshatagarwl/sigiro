import { type OpenApiConvertOptions } from "./openapi.ts";
export interface OpenApiSpecEntry {
    /** Output model name — written to `<outDir>/<name>.json`. */
    readonly name: string;
    /** Spec file path, relative to `root` (or absolute). */
    readonly specPath: string;
    /**
     * Hook between patching and conversion (e.g. path prefixing, server
     * rewrites). May mutate the spec in place or return a replacement.
     */
    readonly preprocess?: (spec: any) => unknown | void | Promise<unknown | void>;
    /** Per-spec converter option overrides (merged over the shared options). */
    readonly options?: Partial<OpenApiConvertOptions>;
}
export interface RunOpenApiConvertOptions {
    /** Absolute package root (usually `path.resolve(import.meta.dir, "..")`). */
    readonly root: string;
    readonly specs: readonly OpenApiSpecEntry[];
    /**
     * RFC-6902 patch chain root, relative to `root`. Default `"patches"`;
     * `false` disables. Layout: `<patchesDir>/<name>/*.json` when the
     * per-spec directory exists; for single-spec providers a flat
     * `<patchesDir>/*.json` also works. Ops under `/shapes` or `/metadata`
     * apply to the Smithy model after conversion; the rest apply to OpenAPI.
     */
    readonly patchesDir?: string | false;
    /** Output directory, relative to `root`. Default `".generated-specs"`. */
    readonly outDir?: string;
    /**
     * Spec text parser. Default `JSON.parse` — the seam for YAML specs
     * (`parse: (text) => YAML.parse(text)`).
     */
    readonly parse?: (text: string, specPath: string) => unknown;
    /** Shared converter options (per-spec `options` merge over these). */
    readonly options: OpenApiConvertOptions;
    /**
     * What to do when a patch JSON pointer does not resolve. Default `"fail"`:
     * silent skip is how a whole patch chain can vanish after an upstream path
     * prefix change. `"warn"` restores the old skip-and-continue behaviour.
     */
    readonly onStalePatch?: "fail" | "warn";
    /**
     * Run {@link finalizeConvert} on the written models (reference check +
     * finalized marker; naming already happened in the converter). Default
     * true. Pass false when the caller finalizes once after several convert
     * steps (Fly machines + sprites + addons).
     */
    readonly finalize?: boolean;
}
/** Run the OpenAPI→Smithy conversion pipeline (plain async — call from a script). */
export declare const runOpenApiConvert: (o: RunOpenApiConvertOptions) => Promise<void>;
//# sourceMappingURL=openapi-cli.d.ts.map