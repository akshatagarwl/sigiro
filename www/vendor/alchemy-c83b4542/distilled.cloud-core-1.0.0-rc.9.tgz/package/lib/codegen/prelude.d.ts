/** Prelude shape → schema expression (JSON-wire flavor). */
export declare const JSON_PRELUDE: Record<string, string>;
/** TypeScript type for each prelude shape, mirroring {@link JSON_PRELUDE}. */
export declare const TS_JSON_PRELUDE: Record<string, string>;
/**
 * Schema reference resolver: prelude shapes map through the prelude table,
 * forward references (including into cycles) wrap in `S.suspend`.
 */
export declare const makeSchemaRef: (prelude: Record<string, string>, indexOf: ReadonlyMap<string, number>) => ((target: string, selfIdx: number) => string);
/**
 * TypeScript type reference resolver. Named shapes all get an emitted
 * interface / type alias, so forward references are always fine.
 */
export declare const makeTsRef: (tsPrelude: Record<string, string>) => ((target: string) => string);
//# sourceMappingURL=prelude.d.ts.map