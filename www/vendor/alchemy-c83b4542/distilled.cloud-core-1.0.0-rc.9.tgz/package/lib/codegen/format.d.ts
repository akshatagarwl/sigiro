/**
 * Post-generation formatting (dev-time only).
 *
 * The emitters produce a canonical token stream, not formatted source, so
 * every generator formats what it wrote before finishing. Without it a
 * generate run leaves the whole output directory dirty against the committed
 * (formatted) files, and a real regression is indistinguishable from
 * whitespace in the diff.
 *
 * Lives here so the shared {@link runGeneratorCli} and the providers with
 * their own pipelines run the identical step.
 */
import { Effect } from "effect";
/** Run a dev-time tool, failing the generate run if it does. */
export declare const runTool: (argv: readonly string[]) => Effect.Effect<void, never, never>;
/** Format a generated directory in place. */
export declare const formatGenerated: (dir: string) => Effect.Effect<void, never, never>;
/**
 * Lint-fix then format. `oxlint --fix` can leave its rewrites unformatted,
 * so the formatter has to run after it, not before.
 */
export declare const lintAndFormatGenerated: (dir: string) => Effect.Effect<void, never, never>;
//# sourceMappingURL=format.d.ts.map