/** Set to a non-empty value to read specs from `specs/.local` instead. */
export declare const LOCAL_ENV = "DISTILLED_SPECS_LOCAL";
/** The local working copy of a mirror, relative to a package root. */
export declare const LOCAL_DIR: string;
/** Repository name of the mirror feeding `packages/<pkg>`. */
export declare const mirrorRepositoryName: (pkg: string) => string;
/** Whether this process reads specs from `specs/.local`. */
export declare const isLocalSpecs: () => boolean;
/**
 * Resolve a package-relative spec path to an absolute one.
 *
 * @param root      absolute package root (`path.resolve(import.meta.dir, "..")`)
 * @param specPath  the production path, relative to `root` (or absolute)
 */
export declare const resolveSpecPath: (root: string, specPath: string) => string;
//# sourceMappingURL=spec-path.d.ts.map