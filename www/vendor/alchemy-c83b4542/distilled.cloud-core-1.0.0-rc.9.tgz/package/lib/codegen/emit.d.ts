/** PURE annotates calls, never property reads. Both @ and # forms are supported. */
export declare const PURE = "/*@__PURE__*/ ";
/** `export interface X { … }` (or the empty-body form). */
export declare const interfaceDecl: (name: string, fields: string[]) => string;
export interface SuspendConstOptions {
    readonly name: string;
    /** The schema expression inside the suspend thunk. */
    readonly expr: string;
    /** PURE marker(s), e.g. `"/*@__PURE__*​/ "`. Emitted verbatim before the expression. */
    readonly pure?: string;
    /** When set, `.annotate({ identifier: <name> })` is appended after the suspend. */
    readonly annotateIdentifier?: boolean;
    /** Extra annotation object source to use instead of the identifier default. */
    readonly annotation?: string;
    /**
     * Explicit thunk return type (`(): S.Schema<X> =>`) — used for shapes in
     * dependency cycles to stop circular type inference.
     */
    readonly thunkType?: string;
    /** CF-style multiline body (`S.suspend(() =>\n<expr>,\n)`). */
    readonly multiline?: boolean;
    /** The cast target; defaults to `S.Schema<name>`. */
    readonly castTo?: string;
}
/**
 * The `export const X = S.suspend(…) … as any as S.Schema<X>;` skeleton
 * shared by both generators.
 */
export declare const suspendConst: (o: SuspendConstOptions) => string;
/**
 * Member-level lazy reference: `S.suspend(() => X).annotate({ identifier })`.
 * The `typed` form adds an explicit `S.Schema<X>` thunk return type — used
 * for references into dependency cycles to stop circular type inference.
 */
export declare const suspendRef: (name: string, typed?: boolean) => string;
export interface EnumDeclOptions {
    readonly name: string;
    readonly values: readonly string[];
    readonly pure?: string;
    /** The schema const expression; both SDKs use `S.String` (open enums). */
    readonly schemaExpr?: string;
}
/**
 * String-union enum ALIAS: the spec's documented values as a CLOSED literal
 * union (`type X = "a" | "b"`) — response readers match documented values
 * exhaustively. INPUT references re-open the alias inline
 * (`X | (string & {})`) so consumers can send tomorrow's values without an
 * SDK update. The schema stays `S.String` in both directions (the
 * protocols never validate enum membership, so undocumented wire values
 * always pass through at runtime).
 */
export declare const enumDecl: (o: EnumDeclOptions) => string[];
export interface ErrorClassOptions {
    readonly name: string;
    /** The error tag; defaults to `name`. */
    readonly tag?: string;
    /** Field lines (`  key: S.String,`). */
    readonly fields: readonly string[];
    /** Optional extra argument(s) after the fields object (annotations). */
    readonly annotations?: string;
    /** `.pipe(…)` suffix (e.g. category decorators). */
    readonly pipes?: string;
    /** Wrap the class expression (e.g. `T.applyErrorMatchers(<cls>, …)`). */
    readonly wrap?: (cls: string) => string;
}
/**
 * `export class X extends /*@__PURE__*​/ S.TaggedError<X>()("X", { … }) {}`
 *
 * The PURE markers are what make an unused error class droppable. A class
 * whose heritage clause is an unannotated call can never be tree-shaken —
 * the bundler has to assume the call has side effects — so a consumer
 * importing one operation would retain every error class in the module
 * (distilled #191).
 *
 * `wrap` needs its own marker as well as the inner one: a pure call's
 * ARGUMENTS are still evaluated, so annotating only
 * `T.applyErrorMatchers(S.TaggedError…(…), […])` leaves the inner call
 * holding the class alive. Verified against esbuild in both directions.
 */
export declare const errorClass: (o: ErrorClassOptions) => string;
export interface OperationConstOptions {
    /** The exported (usually lowerFirst) operation name. */
    readonly exportName: string;
    /** Full type annotation (e.g. `API.OperationMethod<A, B, E, R>`). */
    readonly typeAnnotation: string;
    /** `API.make` or `API.makePaginated` (with namespace prefix). */
    readonly factory: string;
    /** The config object source (including braces). */
    readonly config: string;
    /** Optional extra factory argument (e.g. a pagination strategy). */
    readonly extraArg?: string;
    readonly pure?: string;
    /**
     * Widen the factory result to `any`, for annotations the factory's
     * generic signature can't prove. The one case today: a paginated
     * operation's `items` element type comes from the pagination trait's
     * `items` PATH — a runtime string — so the factory can only infer the
     * structural fallback while the annotation names the real element type.
     *
     * Unlike the schema consts' `as any as S.Schema<X>`, the target doesn't
     * need restating here: the const carries its own annotation, which IS
     * the assignment target, so a bare `as any` lands in the same place.
     * Restating it would double every paginated operation's declaration —
     * ~40k lines across the SDKs — for no added checking.
     */
    readonly castToAnnotation?: boolean;
}
/** `export const op: T = API.make(() => ({ … }));` */
export declare const operationConst: (o: OperationConstOptions) => string;
export interface InterfaceFieldOptions {
    readonly name: string;
    readonly type: string;
    readonly optional: boolean;
    readonly doc?: string;
}
/** Interface field line(s): optional doc comment + `  name?: Type;`. */
export declare const interfaceField: (o: InterfaceFieldOptions) => string[];
/** `export type <Op>Error = A | B | <CommonErrors>;` */
export declare const errorUnionAlias: (opName: string, errorNames: readonly string[], commonRef: string) => string;
/** Namespaced barrel: `export * as name from "./file.ts";` per entry. */
export declare const barrel: (header: string, entries: ReadonlyArray<{
    name: string;
    path: string;
}>) => string;
//# sourceMappingURL=emit.d.ts.map