import * as Schema from "effect/Schema";
import * as G from "./graphql.ts";
import type { GraphQLModel } from "./codegen/graphql-client.ts";
declare const ProjectNotFound_base: Schema.Class<ProjectNotFound, Schema.TaggedStruct<"ProjectNotFound", {
    message: Schema.String;
    code: Schema.optional<Schema.String>;
    path: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
    locations: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>>;
    extensions: Schema.optional<Schema.Unknown>;
    traceId: Schema.optional<Schema.String>;
    status: Schema.optional<Schema.Number>;
    retryAfter: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
export declare class ProjectNotFound extends ProjectNotFound_base {
}
declare const ServicesUnavailable_base: Schema.Class<ServicesUnavailable, Schema.TaggedStruct<"ServicesUnavailable", {
    message: Schema.String;
    code: Schema.optional<Schema.String>;
    path: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
    locations: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>>;
    extensions: Schema.optional<Schema.Unknown>;
    traceId: Schema.optional<Schema.String>;
    status: Schema.optional<Schema.Number>;
    retryAfter: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
export declare class ServicesUnavailable extends ServicesUnavailable_base {
}
declare const Unauthorized_base: Schema.Class<Unauthorized, Schema.TaggedStruct<"Unauthorized", {
    message: Schema.String;
    code: Schema.optional<Schema.String>;
    path: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
    locations: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>>;
    extensions: Schema.optional<Schema.Unknown>;
    traceId: Schema.optional<Schema.String>;
    status: Schema.optional<Schema.Number>;
    retryAfter: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
export declare class Unauthorized extends Unauthorized_base {
}
declare const ProjectDescriptionUnavailable_base: Schema.Class<ProjectDescriptionUnavailable, Schema.TaggedStruct<"ProjectDescriptionUnavailable", {
    message: Schema.String;
    code: Schema.optional<Schema.String>;
    path: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
    locations: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>>;
    extensions: Schema.optional<Schema.Unknown>;
    traceId: Schema.optional<Schema.String>;
    status: Schema.optional<Schema.Number>;
    retryAfter: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
export declare class ProjectDescriptionUnavailable extends ProjectDescriptionUnavailable_base {
}
declare const ServiceDescriptionUnavailable_base: Schema.Class<ServiceDescriptionUnavailable, Schema.TaggedStruct<"ServiceDescriptionUnavailable", {
    message: Schema.String;
    code: Schema.optional<Schema.String>;
    path: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
    locations: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>>;
    extensions: Schema.optional<Schema.Unknown>;
    traceId: Schema.optional<Schema.String>;
    status: Schema.optional<Schema.Number>;
    retryAfter: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceDescriptionUnavailable extends ServiceDescriptionUnavailable_base {
}
declare const PageInfoUnavailable_base: Schema.Class<PageInfoUnavailable, Schema.TaggedStruct<"PageInfoUnavailable", {
    message: Schema.String;
    code: Schema.optional<Schema.String>;
    path: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
    locations: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>>;
    extensions: Schema.optional<Schema.Unknown>;
    traceId: Schema.optional<Schema.String>;
    status: Schema.optional<Schema.Number>;
    retryAfter: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
export declare class PageInfoUnavailable extends PageInfoUnavailable_base {
}
export declare const errorClasses: {
    ProjectNotFound: typeof ProjectNotFound;
    ServicesUnavailable: typeof ServicesUnavailable;
    Unauthorized: typeof Unauthorized;
    ProjectDescriptionUnavailable: typeof ProjectDescriptionUnavailable;
    ServiceDescriptionUnavailable: typeof ServiceDescriptionUnavailable;
    PageInfoUnavailable: typeof PageInfoUnavailable;
};
export type FixtureSchema = {
    query: "Query";
    mutation: "Mutation";
    subscription: never;
    globalErrors: "Unauthorized";
    errors: {
        ProjectNotFound: ProjectNotFound;
        ServicesUnavailable: ServicesUnavailable;
        Unauthorized: Unauthorized;
        ProjectDescriptionUnavailable: ProjectDescriptionUnavailable;
        ServiceDescriptionUnavailable: ServiceDescriptionUnavailable;
        PageInfoUnavailable: PageInfoUnavailable;
    };
    scalars: {
        ID: string;
        String: string;
        Int: number;
        Boolean: boolean;
        JSON: unknown;
        Status: "ACTIVE" | "ARCHIVED";
    };
    possibleTypes: {
        Node: "Project" | "Service";
        SearchResult: "Project" | "Service";
    };
    types: {
        Query: {
            project: G.Field<{
                id: string;
            }, "Project", "ProjectNotFound">;
            projects: G.Field<{
                filter?: {
                    name?: string | null;
                    statuses?: Array<"ACTIVE" | "ARCHIVED"> | null;
                    metadata?: unknown;
                } | null;
            }, "[Project]!">;
            node: G.Field<{
                id: string;
            }, "Node">;
            search: G.Field<{
                text: string;
            }, "[SearchResult!]!">;
            services: G.Field<{
                first?: number | null;
                after?: string | null;
            }, "ServiceConnection!", "ServicesUnavailable">;
            ping: G.Field<{}, "Boolean!">;
        };
        Mutation: {
            editProject: G.Field<{
                id: string;
                name: string;
            }, "Project!", "ProjectNotFound">;
            deleteProject: G.Field<{
                id: string;
            }, "Boolean!", "ProjectNotFound">;
        };
        Project: {
            id: G.Field<{}, "ID!">;
            name: G.Field<{}, "String!">;
            description: G.Field<{}, "String", "ProjectDescriptionUnavailable">;
            parent: G.Field<{}, "Project">;
            services: G.Field<{
                first?: number | null;
                after?: string | null;
                filter?: {
                    name?: string | null;
                } | null;
            }, "ServiceConnection", "ServicesUnavailable">;
        };
        Service: {
            id: G.Field<{}, "ID!">;
            parent: G.Field<{}, "Project">;
            name: G.Field<{}, "String!">;
            description: G.Field<{}, "String", "ServiceDescriptionUnavailable">;
            project: G.Field<{}, "Project!">;
            status: G.Field<{}, "Status!">;
        };
        ServiceConnection: {
            edges: G.Field<{}, "[ServiceEdge!]!">;
            pageInfo: G.Field<{}, "PageInfo!">;
        };
        ServiceEdge: {
            cursor: G.Field<{}, "String!">;
            node: G.Field<{}, "Service!">;
        };
        PageInfo: {
            endCursor: G.Field<{}, "String">;
            hasNextPage: G.Field<{}, "Boolean!", "PageInfoUnavailable">;
        };
        Node: {
            id: G.Field<{}, "ID!">;
            parent: G.Field<{}, "Project">;
        };
        SearchResult: {};
    };
};
export declare const fixtureModel: GraphQLModel;
/** A deliberately small recursive schema for GraphQL compiler/runtime tests. */
export declare const fixtureSDL = "\n  scalar JSON\n\n  enum Status {\n    ACTIVE\n    ARCHIVED\n  }\n\n  input ProjectFilter {\n    name: String\n    statuses: [Status!] = [ACTIVE]\n    metadata: JSON\n  }\n\n  interface Node {\n    id: ID!\n    parent: Project\n  }\n\n  type Project implements Node {\n    id: ID!\n    name: String!\n    description: String\n    parent: Project\n    services(\n      first: Int = 20\n      after: String\n      filter: ProjectFilter\n    ): ServiceConnection\n  }\n\n  type Service implements Node {\n    id: ID!\n    parent: Project\n    name: String!\n    description: String\n    project: Project!\n    status: Status!\n  }\n\n  type ServiceConnection {\n    edges: [ServiceEdge!]!\n    pageInfo: PageInfo!\n  }\n\n  type ServiceEdge {\n    cursor: String!\n    node: Service!\n  }\n\n  type PageInfo {\n    endCursor: String\n    hasNextPage: Boolean!\n  }\n\n  union SearchResult = Project | Service\n\n  type Query {\n    project(id: ID!): Project\n    projects(filter: ProjectFilter): [Project]!\n    node(id: ID!): Node\n    search(text: String!): [SearchResult!]!\n    services(first: Int = 20, after: String): ServiceConnection!\n    ping: Boolean!\n  }\n\n  type Mutation {\n    editProject(id: ID!, name: String!): Project!\n    deleteProject(id: ID!): Boolean!\n  }\n";
/** Includes characters that must travel in variables, never in GraphQL text. */
export declare const adversarialArgument = "quoted \"value\" \\ path\nline\t\0 \uD83D\uDE00";
export declare const partialProjectEnvelope: {
    readonly data: {
        readonly project: {
            readonly id: "p1";
            readonly services: null;
        };
        readonly ping: true;
    };
    readonly errors: readonly [{
        readonly message: "Services temporarily unavailable";
        readonly path: readonly ["project", "services"];
        readonly locations: readonly [{
            readonly line: 1;
            readonly column: 25;
        }];
        readonly extensions: {
            readonly code: "UNAVAILABLE";
            readonly incident: "incident-1";
        };
    }];
};
export declare const multipleErrorEnvelope: {
    readonly data: {
        readonly production: null;
        readonly staging: {
            readonly id: "p2";
            readonly services: null;
        };
    };
    readonly errors: readonly [{
        readonly message: "Project not found";
        readonly path: readonly ["production"];
        readonly extensions: {
            readonly code: "NOT_FOUND";
        };
    }, {
        readonly message: "Services temporarily unavailable";
        readonly path: readonly ["staging", "services"];
        readonly extensions: {
            readonly code: "UNAVAILABLE";
        };
    }];
};
export {};
//# sourceMappingURL=graphql.fixture.d.ts.map