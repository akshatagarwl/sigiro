import * as Effect from "effect/Effect";
import * as S from "effect/Schema";
import * as Stream from "effect/Stream";
import type { GraphQLModel } from "./codegen/graphql-client.ts";
export type { GraphQLModel } from "./codegen/graphql-client.ts";
/** A generated field's arguments, GraphQL output reference, and error tags. */
export interface Field<Args, Ref extends string, E extends string = never> {
    readonly args: Args;
    readonly type: Ref;
    readonly errors: E;
}
export interface Schema {
    types: Record<string, Record<string, Field<any, string, string>>>;
    scalars: Record<string, unknown>;
    errors: Record<string, GraphQLIssue>;
    possibleTypes: Record<string, string>;
    query: string;
    mutation: string;
    subscription: string;
    globalErrors: string;
}
type Named<T extends string> = T extends `${infer R}!` ? Named<R> : T extends `[${infer R}]` ? Named<R> : T;
type Fields<C extends Schema, N extends string> = N extends keyof C["types"] ? C["types"][N] : {};
type TypeOf<F> = F extends Field<any, infer T, any> ? T : never;
type ArgsOf<F> = F extends Field<infer A, any, any> ? A : never;
type TagsOf<F> = F extends Field<any, any, infer E> ? E : never;
type Where<A> = {} extends A ? {
    readonly where?: A;
} : {
    readonly where: A;
};
type Directives = {
    readonly $include?: boolean;
    readonly $skip?: boolean;
};
type FieldSelection<C extends Schema, F> = Named<TypeOf<F>> extends keyof C["scalars"] ? ({} extends ArgsOf<F> ? boolean : never) | (Where<ArgsOf<F>> & Directives & {
    readonly select?: true;
}) : (keyof ArgsOf<F> extends never ? Selection<C, Named<TypeOf<F>>> : never) | (Where<ArgsOf<F>> & Directives & {
    readonly select: Selection<C, Named<TypeOf<F>>>;
});
type Alias<C extends Schema, N extends string> = {
    [K in keyof Fields<C, N>]: {
        readonly [P in K]: FieldSelection<C, Fields<C, N>[K]>;
    };
}[keyof Fields<C, N>];
/** Mobius-style field selection. Arguments are passed in `where`. */
export type Selection<C extends Schema, N extends string> = {
    readonly [K in keyof Fields<C, N>]?: FieldSelection<C, Fields<C, N>[K]>;
} & {
    readonly __typename?: boolean;
    readonly __alias?: Readonly<Record<string, Alias<C, N>>>;
    readonly __on?: N extends keyof C["possibleTypes"] ? {
        readonly [K in C["possibleTypes"][N]]?: Selection<C, K>;
    } : never;
};
type Selected<Q> = Q extends {
    readonly select: infer P;
} ? P : Q;
type Keys<Q> = {
    [K in keyof Q]: Q[K] extends false | undefined ? never : K;
}[keyof Q];
type Simplify<A> = {
    [K in keyof A]: A[K];
};
type AliasValue<C extends Schema, N extends string, Q> = {
    [K in Extract<Keys<Q>, keyof Fields<C, N>>]: Result<C, TypeOf<Fields<C, N>[K]>, Selected<Q[K]>>;
}[Extract<Keys<Q>, keyof Fields<C, N>>];
type AliasResult<C extends Schema, N extends string, Q> = Q extends {
    readonly __alias: infer A;
} ? Simplify<{
    [K in keyof A as Conditional<A[K][keyof A[K]]> extends true ? never : K]: AliasValue<C, N, A[K]>;
} & {
    [K in keyof A as Conditional<A[K][keyof A[K]]> extends true ? K : never]?: AliasValue<C, N, A[K]>;
}> : {};
type Conditional<Q> = boolean extends Q ? true : Q extends {
    readonly $include: infer I;
} ? [I] extends [true] ? Q extends {
    readonly $skip: infer S;
} ? [S] extends [false] ? false : true : false : true : Q extends {
    readonly $skip: infer S;
} ? [S] extends [false] ? false : true : false;
type ObjectFields<C extends Schema, N extends string, Q> = {
    [K in Extract<Keys<Q>, keyof Fields<C, N>> as Conditional<Q[K]> extends true ? never : K]: Result<C, TypeOf<Fields<C, N>[K]>, Selected<Q[K]>>;
} & {
    [K in Extract<Keys<Q>, keyof Fields<C, N>> as Conditional<Q[K]> extends true ? K : never]?: Result<C, TypeOf<Fields<C, N>[K]>, Selected<Q[K]>>;
};
type ObjectResult<C extends Schema, N extends string, Q> = Simplify<ObjectFields<C, N, Q> & (Q extends {
    readonly __typename: true;
} ? {
    __typename: N;
} : {}) & AliasResult<C, N, Q>>;
type Branch<C extends Schema, N extends string, Q, T extends string> = T extends unknown ? Simplify<Omit<ObjectResult<C, N, Q>, "__typename"> & (Q extends {
    readonly __on: infer O;
} ? T extends keyof O ? ObjectResult<C, T, O[T]> : {} : {}) & {
    __typename: T;
}> : never;
type Value<C extends Schema, T extends string, Q> = T extends `[${infer I}]` ? Array<Result<C, I, Q>> : T extends keyof C["scalars"] ? C["scalars"][T] : T extends keyof C["possibleTypes"] ? Branch<C, T, Q, C["possibleTypes"][T]> : ObjectResult<C, T, Q>;
/** Selected output, preserving list and nullable wrappers. */
export type Result<C extends Schema, Ref extends string, Q> = Ref extends `${infer T}!` ? Value<C, T, Q> : Value<C, Ref, Q> | null;
type SelectionTags<C extends Schema, N extends string, Q> = string extends N ? string : Q extends object ? {
    [K in Extract<Keys<Q>, keyof Fields<C, N>>]: TagsOf<Fields<C, N>[K]> | SelectionTags<C, Named<TypeOf<Fields<C, N>[K]>>, Selected<Q[K]>>;
}[Extract<Keys<Q>, keyof Fields<C, N>>] | (Q extends {
    readonly __on: infer O;
} ? {
    [K in keyof O & string]: SelectionTags<C, K, O[K]>;
}[keyof O & string] : never) | (Q extends {
    readonly __alias: infer A;
} ? {
    [K in keyof A]: SelectionTags<C, N, A[K]>;
}[keyof A] : never) : never;
/** Known selected errors plus provider-wide errors and an honest fallback. */
export type Errors<C extends Schema, N extends string, Q> = (SelectionTags<C, N, Q> extends infer Tags ? C["errors"][Extract<C["globalErrors"] | Tags, keyof C["errors"]>] : never) | UnknownGraphQLError;
type Root<C extends Schema, K extends OperationKind> = K extends "query" ? C["query"] : C["mutation"];
type OperationSelection<C extends Schema, N extends string, K extends keyof Fields<C, N>, Q> = {
    [P in K]: {
        select: Q;
    };
};
export declare const errorFields: {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    retryAfter: S.optional<S.Number>;
};
export interface GraphQLIssue {
    readonly _tag: string;
    readonly message: string;
    readonly code?: string;
    readonly path?: ReadonlyArray<string | number>;
    readonly locations?: ReadonlyArray<{
        readonly line: number;
        readonly column: number;
    }>;
    readonly extensions?: unknown;
    readonly traceId?: string;
    readonly status?: number;
    /** Server retry hint in seconds. */
    readonly retryAfter?: number;
}
declare const UnknownGraphQLError_base: S.Class<UnknownGraphQLError, S.TaggedStruct<"UnknownGraphQLError", {
    readonly message: S.String;
    readonly code: S.optional<S.String>;
    readonly path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    readonly locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    readonly extensions: S.optional<S.Unknown>;
    readonly traceId: S.optional<S.String>;
    readonly status: S.optional<S.Number>;
    readonly retryAfter: S.optional<S.Number>;
    readonly coordinate: S.optional<S.String>;
}>, import("effect/Cause").YieldableError>;
export declare class UnknownGraphQLError extends UnknownGraphQLError_base {
}
declare const GraphQLFailure_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLFailure";
} & Readonly<A>;
/** All errors from one GraphQL execution, with the original partial response. */
export declare class GraphQLFailure<E extends GraphQLIssue = GraphQLIssue> extends GraphQLFailure_base<{
    readonly errors: readonly [E, ...E[]];
    readonly data: unknown;
    readonly status: number;
}> {
    get message(): string;
}
declare const GraphQLTransportError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLTransportError";
} & Readonly<A>;
export declare class GraphQLTransportError extends GraphQLTransportError_base<{
    readonly message: string;
    readonly cause?: unknown;
    readonly status?: number;
    readonly retryAfter?: number;
}> {
}
declare const GraphQLDecodeError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLDecodeError";
} & Readonly<A>;
export declare class GraphQLDecodeError extends GraphQLDecodeError_base<{
    readonly message: string;
    readonly path?: ReadonlyArray<string | number>;
    readonly cause?: unknown;
}> {
}
declare const GraphQLRequestError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "GraphQLRequestError";
} & Readonly<A>;
export declare class GraphQLRequestError extends GraphQLRequestError_base<{
    readonly message: string;
}> {
}
export type ClientError = GraphQLTransportError | GraphQLDecodeError | GraphQLRequestError;
/** True only when every issue has an allowed tag; mixed failures are never hidden. */
export declare const isErrorTag: (error: unknown, tags: string | readonly string[]) => boolean;
/** Recover only an aggregate whose every issue matches. The original aggregate is also supplied. */
export declare const catchTags: <const T extends readonly string[] | string, B, E2, R2>(tags: T, handler: (error: GraphQLIssue & {
    readonly _tag: T extends string ? T : T[number];
}, failure: GraphQLFailure) => Effect.Effect<B, E2, R2>) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A | B, E | E2, R | R2>;
export type OperationKind = "query" | "mutation";
export interface GraphQLRequest {
    readonly query: string;
    readonly variables: Record<string, unknown>;
    readonly operationName: string;
    readonly kind: OperationKind;
}
export interface GraphQLResponse {
    readonly body: unknown;
    readonly status: number;
    readonly headers: Readonly<Record<string, string | undefined>>;
}
export type Transport<R> = (request: GraphQLRequest) => Effect.Effect<GraphQLResponse, GraphQLTransportError | GraphQLDecodeError, R>;
interface Position {
    readonly field: string;
    readonly key: string;
    readonly coordinate: string;
    readonly type: string;
    readonly errors: readonly string[];
    readonly children: readonly Position[];
    readonly branches: Readonly<Record<string, readonly Position[]>>;
    readonly typename?: boolean;
    readonly conditional: boolean;
}
export interface CompiledQuery extends GraphQLRequest {
    readonly rootType: string;
    readonly positions: readonly Position[];
}
/** Compile one selection to a GraphQL AST, variables, and an error/decoder path map. */
export declare const compile: (model: GraphQLModel, kind: OperationKind, selection: unknown, operationName?: string) => CompiledQuery;
type ErrorConstructor = new (args: any) => GraphQLIssue;
export interface Report<A, E extends GraphQLIssue> {
    readonly data: A | null | undefined;
    readonly errors: ReadonlyArray<E>;
    readonly status: number;
    readonly extensions?: unknown;
}
type Failure<C extends Schema, N extends string, Q> = ClientError | GraphQLFailure<Errors<C, N, Q>>;
type FieldAt<C extends Schema, N extends string, K extends string> = K extends keyof Fields<C, N> ? Fields<C, N>[K] : never;
type ConnectionEdge<C extends Schema, Ref extends string> = Named<TypeOf<FieldAt<C, Named<Ref>, "edges">>>;
type ConnectionNode<C extends Schema, Ref extends string> = TypeOf<FieldAt<C, ConnectionEdge<C, Ref>, "node">>;
export interface ObjectOperation<C extends Schema, K extends OperationKind, N extends keyof Fields<C, Root<C, K>> & string, R> {
    <const Q extends Selection<C, Named<TypeOf<Fields<C, Root<C, K>>[N]>>>>(args: ArgsOf<Fields<C, Root<C, K>>[N]>, select: Q): Effect.Effect<Result<C, TypeOf<Fields<C, Root<C, K>>[N]>, Q>, Failure<C, Root<C, K>, OperationSelection<C, Root<C, K>, N, Q>>, R>;
}
export interface ScalarOperation<C extends Schema, K extends OperationKind, N extends keyof Fields<C, Root<C, K>> & string, R> {
    (args: ArgsOf<Fields<C, Root<C, K>>[N]>): Effect.Effect<Result<C, TypeOf<Fields<C, Root<C, K>>[N]>, true>, Failure<C, Root<C, K>, OperationSelection<C, Root<C, K>, N, true>>, R>;
}
export interface Pagination<C extends Schema, K extends OperationKind, N extends keyof Fields<C, Root<C, K>> & string, R> {
    pages<const Q extends Selection<C, Named<TypeOf<Fields<C, Root<C, K>>[N]>>>>(args: ArgsOf<Fields<C, Root<C, K>>[N]>, select: Q): Stream.Stream<Result<C, TypeOf<Fields<C, Root<C, K>>[N]>, Q>, ClientError | GraphQLFailure<Errors<C, Root<C, K>, OperationSelection<C, Root<C, K>, N, Q>> | Errors<C, Named<TypeOf<Fields<C, Root<C, K>>[N]>>, {
        pageInfo: {
            endCursor: true;
            hasNextPage: true;
        };
    }>>, R>;
    items<const Q extends Selection<C, Named<ConnectionNode<C, TypeOf<Fields<C, Root<C, K>>[N]>>>>>(args: ArgsOf<Fields<C, Root<C, K>>[N]>, select: Q): Stream.Stream<Result<C, ConnectionNode<C, TypeOf<Fields<C, Root<C, K>>[N]>>, Q>, Failure<C, Root<C, K>, OperationSelection<C, Root<C, K>, N, {
        edges: {
            node: Q;
        };
        pageInfo: {
            endCursor: true;
            hasNextPage: true;
        };
    }>>, R>;
}
export type Operation<C extends Schema, K extends OperationKind, N extends keyof Fields<C, Root<C, K>> & string, R> = Named<TypeOf<Fields<C, Root<C, K>>[N]>> extends keyof C["scalars"] ? ScalarOperation<C, K, N, R> : ObjectOperation<C, K, N, R> & (K extends "query" ? "after" extends keyof ArgsOf<Fields<C, Root<C, K>>[N]> ? [ConnectionNode<C, TypeOf<Fields<C, Root<C, K>>[N]>>] extends [
    never
] ? {} : Pagination<C, K, N, R> : {} : {});
/** Construct an Effect client; credentials and HTTP are resolved by the transport per call. */
export declare const makeClient: <C extends Schema, R>(model: GraphQLModel, transport: Transport<R>, classes: Readonly<Record<string, ErrorConstructor>>) => {
    query: <const Q extends Selection<C, C["query"]>>(selection: Q) => Effect.Effect<Result<C, `${C["query"]}!`, Q>, Failure<C, C["query"], Q>, R>;
    mutation: <const Q extends Selection<C, C["mutation"]>>(selection: Q) => Effect.Effect<Result<C, `${C["mutation"]}!`, Q>, Failure<C, C["mutation"], Q>, R>;
    report: {
        query: <const Q extends Selection<C, C["query"]>>(selection: Q) => Effect.Effect<Report<Result<C, `${C["query"]}!`, Q>, Errors<C, C["query"], Q>>, ClientError, R>;
        mutation: <const Q extends Selection<C, C["mutation"]>>(selection: Q) => Effect.Effect<Report<Result<C, `${C["mutation"]}!`, Q>, Errors<C, C["mutation"], Q>>, ClientError, R>;
    };
    operation: <K extends OperationKind, N extends keyof Fields<C, Root<C, K>> & string>(kind: K, name: N) => Operation<C, K, N, R>;
};
//# sourceMappingURL=graphql.d.ts.map